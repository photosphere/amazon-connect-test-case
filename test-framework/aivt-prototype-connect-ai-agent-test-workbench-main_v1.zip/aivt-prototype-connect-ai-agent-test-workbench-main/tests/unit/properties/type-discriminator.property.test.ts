// Feature: rag-test-cases, Property 4: Type-Discriminator Validator Accepts Exactly Valid Shapes
import { describe, it, expect, beforeEach, vi } from "vitest";
import fc from "fast-check";
import {
  handler,
  _setDBService,
  _setAgentToolsFetcher,
  type APIGatewayEvent,
} from "@backend/handlers/cases";
import { DynamoDBService } from "@backend/services/dynamodb";
import {
  CASE_NAME_MAX,
  CASE_DESCRIPTION_MAX,
  RAG_QUESTION_MAX,
  RAG_GROUND_TRUTH_MAX,
  INITIAL_UTTERANCE_MAX,
  CUSTOMER_KNOWLEDGE_MAX_PAIRS,
  CUSTOMER_KNOWLEDGE_KEY_MAX,
  CUSTOMER_KNOWLEDGE_VALUE_MAX,
  SUCCESS_CRITERIA_MAX_STEPS,
  PARAMETER_CHECKS_MAX,
} from "@shared/constants";

// ---------------------------------------------------------------------------
// Mock DynamoDB service — all property tests route through the handler
// ---------------------------------------------------------------------------

const TENANT_ID = "tenant-prop-test";
const SUITE_ID = "suite-prop-test";

function createMockDB(): DynamoDBService {
  return {
    createSuite: vi.fn().mockResolvedValue(undefined),
    getSuite: vi.fn().mockResolvedValue({
      tenantId: TENANT_ID,
      suiteId: SUITE_ID,
      name: "Property Test Suite",
      agentId: "agent-123",
      assistantId: "assistant-456",
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z",
    }),
    updateSuite: vi.fn().mockResolvedValue(undefined),
    deleteSuite: vi.fn().mockResolvedValue(undefined),
    listSuites: vi.fn().mockResolvedValue([]),
    createCase: vi.fn().mockResolvedValue(undefined),
    getCase: vi.fn().mockResolvedValue(null),
    updateCase: vi.fn().mockResolvedValue(undefined),
    deleteCase: vi.fn().mockResolvedValue(undefined),
    listCases: vi.fn().mockResolvedValue([]),
  } as unknown as DynamoDBService;
}

function makeCreateEvent(body: Record<string, unknown>): APIGatewayEvent {
  return {
    httpMethod: "POST",
    resource: "/suites/{suiteId}/cases",
    pathParameters: { suiteId: SUITE_ID },
    body: JSON.stringify(body),
    requestContext: {
      authorizer: { claims: { sub: TENANT_ID } },
    },
  };
}

// ---------------------------------------------------------------------------
// Arbitraries — generators for valid and invalid shapes
// ---------------------------------------------------------------------------

/** Non-blank string (at least one non-whitespace char) within given bounds. */
function nonBlankString(minLength: number, maxLength: number): fc.Arbitrary<string> {
  return fc
    .string({ minLength, maxLength })
    .filter((s) => s.trim().length > 0);
}

/** Valid tool step for successCriteria. */
const validToolStepArb = fc.record({
  toolName: nonBlankString(1, 50),
  required: fc.boolean(),
  parameterChecks: fc.option(
    fc.array(
      fc.record({
        paramName: fc.string({ minLength: 1, maxLength: 50 }),
        expectedValue: fc.string({ maxLength: 100 }),
      }),
      { minLength: 0, maxLength: PARAMETER_CHECKS_MAX },
    ),
    { nil: undefined },
  ),
});

/** Optional sessionData within bounds: max 20 pairs, non-empty keys, string values. */
const validSessionDataArb: fc.Arbitrary<Record<string, string> | undefined> = fc.option(
  fc.dictionary(
    fc.string({ minLength: 1, maxLength: CUSTOMER_KNOWLEDGE_KEY_MAX }).filter(
      (s) => s.trim().length > 0 && s !== "__proto__" && s !== "constructor",
    ),
    fc.string({ maxLength: CUSTOMER_KNOWLEDGE_VALUE_MAX }),
    { minKeys: 0, maxKeys: CUSTOMER_KNOWLEDGE_MAX_PAIRS },
  ),
  { nil: undefined },
);

/**
 * Generator for a valid RAG case record (shape b).
 * Required: type="rag", description (non-empty ≤2000), question (non-empty ≤1000),
 * groundTruthAnswer (non-empty ≤4000). No simulator fields.
 */
const validRagCaseArb: fc.Arbitrary<Record<string, unknown>> = fc.record({
  type: fc.constant("rag"),
  name: fc.option(fc.string({ minLength: 0, maxLength: CASE_NAME_MAX }), { nil: undefined }),
  description: nonBlankString(1, CASE_DESCRIPTION_MAX),
  question: nonBlankString(1, RAG_QUESTION_MAX),
  groundTruthAnswer: nonBlankString(1, RAG_GROUND_TRUTH_MAX),
  sessionData: validSessionDataArb,
}).map((r) => {
  const obj: Record<string, unknown> = {
    type: r.type,
    description: r.description,
    question: r.question,
    groundTruthAnswer: r.groundTruthAnswer,
  };
  if (r.name !== undefined) obj.name = r.name;
  if (r.sessionData !== undefined) obj.sessionData = r.sessionData;
  return obj;
});

/**
 * Generator for a valid tool_sequence case record (shape a).
 * Required: description (non-empty ≤2000), initialUtterance (non-empty ≤1000),
 * successCriteria (1..30 steps with non-empty toolName).
 */
const validToolSequenceCaseArb: fc.Arbitrary<Record<string, unknown>> = fc.record({
  type: fc.constantFrom("tool_sequence" as const, undefined as unknown as "tool_sequence"),
  name: fc.option(fc.string({ minLength: 0, maxLength: CASE_NAME_MAX }), { nil: undefined }),
  description: nonBlankString(1, CASE_DESCRIPTION_MAX),
  initialUtterance: nonBlankString(1, INITIAL_UTTERANCE_MAX),
  successCriteria: fc.array(validToolStepArb, { minLength: 1, maxLength: SUCCESS_CRITERIA_MAX_STEPS }),
  customerKnowledge: fc.option(
    fc.dictionary(
      fc.string({ minLength: 1, maxLength: CUSTOMER_KNOWLEDGE_KEY_MAX }).filter(
        (s) => s !== "__proto__" && s !== "constructor",
      ),
      fc.string({ maxLength: CUSTOMER_KNOWLEDGE_VALUE_MAX }),
      { minKeys: 0, maxKeys: CUSTOMER_KNOWLEDGE_MAX_PAIRS },
    ),
    { nil: undefined },
  ),
  persona: fc.option(fc.string({ maxLength: 100 }), { nil: undefined }),
  style: fc.option(fc.constantFrom("DIRECT", "EMPATHETIC", "CASUAL", "PROFESSIONAL"), { nil: undefined }),
  goalDescription: fc.option(fc.string({ maxLength: CASE_DESCRIPTION_MAX }), { nil: undefined }),
  sessionData: validSessionDataArb,
}).map((r) => {
  const obj: Record<string, unknown> = {
    description: r.description,
    initialUtterance: r.initialUtterance,
    successCriteria: r.successCriteria,
  };
  // type may be explicitly "tool_sequence" or absent (defaults to tool_sequence)
  if (r.type !== undefined) obj.type = r.type;
  if (r.name !== undefined) obj.name = r.name;
  if (r.customerKnowledge !== undefined) obj.customerKnowledge = r.customerKnowledge;
  if (r.persona !== undefined) obj.persona = r.persona;
  if (r.style !== undefined) obj.style = r.style;
  if (r.goalDescription !== undefined) obj.goalDescription = r.goalDescription;
  if (r.sessionData !== undefined) obj.sessionData = r.sessionData;
  return obj;
});

/** Extraneous simulator fields that RAG cases must NOT have. */
const RAG_EXTRANEOUS_FIELDS = [
  "persona",
  "style",
  "customerKnowledge",
  "initialUtterance",
  "goalDescription",
  "primingMessage",
  "successCriteria",
];

/**
 * Generator for invalid case records. Produces records that violate
 * at least one constraint: missing required fields, extraneous simulator
 * fields on RAG type, empty question, invalid type, etc.
 */
const invalidCaseArb: fc.Arbitrary<Record<string, unknown>> = fc.oneof(
  // Invalid: RAG case with extraneous simulator field
  validRagCaseArb.chain((ragCase) =>
    fc.constantFrom(...RAG_EXTRANEOUS_FIELDS).map((field) => ({
      ...ragCase,
      [field]: "some value",
    })),
  ),

  // Invalid: RAG case with missing question
  validRagCaseArb.map((ragCase) => {
    const { question, ...rest } = ragCase;
    return rest;
  }),

  // Invalid: RAG case with empty (whitespace-only) question
  validRagCaseArb.map((ragCase) => ({
    ...ragCase,
    question: "   ",
  })),

  // Invalid: RAG case with missing groundTruthAnswer
  validRagCaseArb.map((ragCase) => {
    const { groundTruthAnswer, ...rest } = ragCase;
    return rest;
  }),

  // Invalid: RAG case with empty (whitespace-only) groundTruthAnswer
  validRagCaseArb.map((ragCase) => ({
    ...ragCase,
    groundTruthAnswer: "   ",
  })),

  // Invalid: tool_sequence case with missing successCriteria
  validToolSequenceCaseArb.map((tsCase) => {
    const { successCriteria, ...rest } = tsCase;
    return { ...rest, type: "tool_sequence" };
  }),

  // Invalid: tool_sequence case with empty successCriteria array
  validToolSequenceCaseArb.map((tsCase) => ({
    ...tsCase,
    type: "tool_sequence",
    successCriteria: [],
  })),

  // Invalid: tool_sequence case with missing initialUtterance
  validToolSequenceCaseArb.map((tsCase) => {
    const { initialUtterance, ...rest } = tsCase;
    return { ...rest, type: "tool_sequence" };
  }),

  // Invalid: tool_sequence case with empty initialUtterance
  validToolSequenceCaseArb.map((tsCase) => ({
    ...tsCase,
    type: "tool_sequence",
    initialUtterance: "   ",
  })),

  // Invalid: unknown type value
  fc.record({
    type: fc.string({ minLength: 1, maxLength: 20 }).filter(
      (s) => s !== "rag" && s !== "tool_sequence",
    ),
    description: nonBlankString(1, 100),
    question: nonBlankString(1, 100),
  }),

  // Invalid: RAG case with question exceeding max length
  validRagCaseArb.map((ragCase) => ({
    ...ragCase,
    question: "x".repeat(RAG_QUESTION_MAX + 1),
  })),

  // Invalid: RAG case with groundTruthAnswer exceeding max length
  validRagCaseArb.map((ragCase) => ({
    ...ragCase,
    groundTruthAnswer: "x".repeat(RAG_GROUND_TRUTH_MAX + 1),
  })),
);

// ---------------------------------------------------------------------------
// Property 4: Type-Discriminator Validator Accepts Exactly Valid Shapes
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 11.4, 1.3, 1.4, 1.5**
 *
 * Property 4: Type-Discriminator Validator Accepts Exactly Valid Shapes
 *
 * The validator accepts records satisfying shape (a) valid tool_sequence or
 * shape (b) valid rag and rejects all others. No third valid shape exists.
 */
describe("Property 4: Type-Discriminator Validator Accepts Exactly Valid Shapes", () => {
  beforeEach(() => {
    _setDBService(createMockDB());
    _setAgentToolsFetcher(() => Promise.resolve(null));
  });

  it("accepts all valid RAG case shapes (shape b)", async () => {
    await fc.assert(
      fc.asyncProperty(validRagCaseArb, async (ragCase) => {
        const event = makeCreateEvent(ragCase);
        const response = await handler(event);
        expect(response.statusCode).toBe(201);
        const body = JSON.parse(response.body);
        expect(body.type).toBe("rag");
        expect(body.question).toBeDefined();
        expect(body.groundTruthAnswer).toBeDefined();
      }),
      { numRuns: 100 },
    );
  });

  it("accepts all valid tool_sequence case shapes (shape a)", async () => {
    await fc.assert(
      fc.asyncProperty(validToolSequenceCaseArb, async (tsCase) => {
        const event = makeCreateEvent(tsCase);
        const response = await handler(event);
        expect(response.statusCode).toBe(201);
        const body = JSON.parse(response.body);
        expect(body.type).toBe("tool_sequence");
        expect(body.initialUtterance).toBeDefined();
        expect(body.successCriteria).toBeDefined();
      }),
      { numRuns: 100 },
    );
  });

  it("rejects all invalid shapes with HTTP 400", async () => {
    await fc.assert(
      fc.asyncProperty(invalidCaseArb, async (invalidCase) => {
        const event = makeCreateEvent(invalidCase);
        const response = await handler(event);
        expect(response.statusCode).toBe(400);
      }),
      { numRuns: 100 },
    );
  });

  it("no third valid shape exists — only 'rag' and 'tool_sequence' types produce 201", async () => {
    // Generate arbitrary records with arbitrary type values (neither rag nor tool_sequence)
    // and confirm they are always rejected.
    await fc.assert(
      fc.asyncProperty(
        fc.record({
          type: fc.string({ minLength: 1, maxLength: 30 }).filter(
            (s) => s !== "rag" && s !== "tool_sequence",
          ),
          description: nonBlankString(1, 200),
          question: nonBlankString(1, 100),
          groundTruthAnswer: nonBlankString(1, 200),
          initialUtterance: nonBlankString(1, 100),
          successCriteria: fc.array(validToolStepArb, { minLength: 1, maxLength: 5 }),
        }),
        async (record) => {
          const event = makeCreateEvent(record);
          const response = await handler(event);
          expect(response.statusCode).toBe(400);
          const body = JSON.parse(response.body);
          expect(body.error).toContain("Invalid type");
        },
      ),
      { numRuns: 100 },
    );
  });
});
