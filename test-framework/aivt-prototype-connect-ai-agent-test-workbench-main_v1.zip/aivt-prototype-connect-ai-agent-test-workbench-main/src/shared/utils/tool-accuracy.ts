/**
 * Tool selection accuracy scoring utility.
 *
 * Computes accuracy by checking whether expected tools appear as an ordered
 * subsequence within the actual tool invocation list. The score is the ratio
 * of matched required steps to total required steps.
 *
 * Optional steps don't affect the denominator but count positively if
 * present in the correct relative order.
 *
 * @module tool-accuracy
 */

import { ToolStep } from "../types";

/**
 * Result of a tool accuracy calculation including the score and optional bonus.
 */
export interface ToolAccuracyResult {
  /** Score from 0.0 to 1.0 representing matched required steps / total required steps. */
  score: number;
  /** Number of optional steps that were matched in the correct order. */
  optionalMatched: number;
  /** Total number of optional steps in the expected sequence. */
  optionalTotal: number;
}

/**
 * Calculates tool selection accuracy using ordered subsequence matching.
 *
 * Walks through the expected tool steps in order, attempting to find each one
 * in the actual invocation list while maintaining relative ordering (i.e., the
 * search position in `actual` only advances forward).
 *
 * Score formula: matched_required_steps / total_required_steps
 *
 * - If there are no required steps, the score is 1.0 (vacuously true).
 * - Optional steps do not affect the denominator.
 * - Optional steps that appear in the correct relative order are tracked in
 *   `optionalMatched` for informational purposes.
 *
 * @param expected - Ordered list of expected tool steps (required and optional)
 * @param actual - Ordered list of tool names actually invoked during the conversation
 * @returns ToolAccuracyResult with score 0.0–1.0 and optional step counts
 *
 * @example
 * // All required tools present in order
 * calculateToolAccuracy(
 *   [{ toolName: "A", required: true }, { toolName: "B", required: true }],
 *   ["A", "X", "B"]
 * )
 * // Returns { score: 1.0, optionalMatched: 0, optionalTotal: 0 }
 *
 * @example
 * // One required tool missing
 * calculateToolAccuracy(
 *   [{ toolName: "A", required: true }, { toolName: "B", required: true }, { toolName: "C", required: true }],
 *   ["A", "C"]
 * )
 * // Returns { score: 0.667, optionalMatched: 0, optionalTotal: 0 }
 */
export function calculateToolAccuracy(
  expected: ToolStep[],
  actual: string[]
): ToolAccuracyResult {
  if (!expected || expected.length === 0) {
    return { score: 1.0, optionalMatched: 0, optionalTotal: 0 };
  }

  const totalRequired = expected.filter((step) => step.required).length;
  const totalOptional = expected.filter((step) => !step.required).length;

  // If there are no required steps, score is 1.0 (vacuously true)
  if (totalRequired === 0) {
    // Still count optional matches for informational purposes
    const optionalMatched = countOrderedMatches(
      expected.filter((s) => !s.required),
      actual
    );
    return { score: 1.0, optionalMatched, optionalTotal: totalOptional };
  }

  if (!actual || actual.length === 0) {
    return { score: 0.0, optionalMatched: 0, optionalTotal: totalOptional };
  }

  // Walk through expected steps in order, tracking position in actual list.
  // For each expected step (required or optional), try to find it at or after
  // the current search position in actual. This preserves relative ordering.
  let actualIndex = 0;
  let matchedRequired = 0;
  let matchedOptional = 0;

  for (const step of expected) {
    // Search for this tool name from the current position forward
    const foundIndex = findNextOccurrence(actual, step.toolName, actualIndex);

    if (foundIndex !== -1) {
      // Found in the correct relative order
      if (step.required) {
        matchedRequired++;
      } else {
        matchedOptional++;
      }
      // Advance past this match for subsequent searches
      actualIndex = foundIndex + 1;
    }
    // If not found, we skip it — required misses lower the score,
    // optional misses have no penalty
  }

  const score = matchedRequired / totalRequired;

  return {
    score: Math.round(score * 1000) / 1000, // Round to 3 decimal places
    optionalMatched: matchedOptional,
    optionalTotal: totalOptional,
  };
}

/**
 * Finds the next occurrence of a tool name in the actual list starting from a given index.
 *
 * @param actual - The list of actual tool names invoked
 * @param toolName - The tool name to search for
 * @param startIndex - The index to start searching from (inclusive)
 * @returns The index of the found occurrence, or -1 if not found
 */
function findNextOccurrence(
  actual: string[],
  toolName: string,
  startIndex: number
): number {
  for (let i = startIndex; i < actual.length; i++) {
    if (actual[i] === toolName) {
      return i;
    }
  }
  return -1;
}

/**
 * Counts how many steps from the given list appear as an ordered subsequence in actual.
 */
function countOrderedMatches(steps: ToolStep[], actual: string[]): number {
  let actualIndex = 0;
  let matched = 0;

  for (const step of steps) {
    const foundIndex = findNextOccurrence(actual, step.toolName, actualIndex);
    if (foundIndex !== -1) {
      matched++;
      actualIndex = foundIndex + 1;
    }
  }

  return matched;
}
