// Feature: connect-agent-test-platform, Property 3: Conversation role flipping
// Feature: connect-agent-test-platform, Property 4: Simulator system prompt construction
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import {
  flipConversationRoles,
  buildSimulatorPrompt,
  STYLE_INSTRUCTIONS,
} from "@backend/orchestration/customer-simulator";
import { CommunicationStyle } from "@shared/enums";
import type { TranscriptTurn, ToolSequenceTestCase } from "@shared/types";

// ---------------------------------------------------------------------------
// Shared Arbitraries
// ---------------------------------------------------------------------------

/** Arbitrary for a turn role. */
const roleArb = fc.constantFrom<"customer" | "agent">("customer", "agent");

/** Arbitrary for non-empty text content. */
const textArb = fc.string({ minLength: 1, maxLength: 200 });

/** Arbitrary for a single TranscriptTurn. */
const transcriptTurnArb = (turnNumber: number): fc.Arbitrary<TranscriptTurn> =>
  fc.record({
    turnNumber: fc.constant(turnNumber),
    role: roleArb,
    text: textArb,
    timestamp: fc.constant(new Date().toISOString()),
    elapsedMs: fc.nat(10000),
  });

/** Arbitrary for a conversation history of 1–30 turns. */
const historyArb = fc
  .integer({ min: 1, max: 30 })
  .chain((length) =>
    fc.tuple(
      ...Array.from({ length }, (_, i) => transcriptTurnArb(i + 1))
    )
  )
  .map((turns) => turns as TranscriptTurn[]);

/** Arbitrary for CommunicationStyle. */
const styleArb = fc.constantFrom(
  CommunicationStyle.DIRECT,
  CommunicationStyle.INDIRECT,
  CommunicationStyle.COLLOQUIAL,
  CommunicationStyle.QUESTION,
  CommunicationStyle.COMPLAINT
);

/** Arbitrary for a non-empty knowledge key. */
const knowledgeKeyArb = fc
  .string({ minLength: 1, maxLength: 50 })
  .filter((s) => s.trim().length > 0);

/** Arbitrary for a non-empty knowledge value. */
const knowledgeValueArb = fc
  .string({ minLength: 1, maxLength: 100 })
  .filter((s) => s.trim().length > 0);

/** Arbitrary for customer knowledge (0–10 key-value pairs). */
const customerKnowledgeArb = fc
  .array(fc.tuple(knowledgeKeyArb, knowledgeValueArb), {
    minLength: 0,
    maxLength: 10,
  })
  .map((pairs) => Object.fromEntries(pairs));

/** Arbitrary for a minimal TestCase suitable for prompt construction. */
const testCaseArb: fc.Arbitrary<ToolSequenceTestCase> = fc.record({
  type: fc.constant("tool_sequence" as const),
  suiteId: fc.constant("suite-1"),
  caseId: fc.constant("case-1"),
  name: fc.constant("test case"),
  description: fc.constant("test description"),
  persona: fc.constant("Customer"),
  style: styleArb,
  customerKnowledge: customerKnowledgeArb,
  initialUtterance: fc.string({ minLength: 1, maxLength: 200 }),
  successCriteria: fc.constant([{ toolName: "tool1", required: true }]),
});

// ---------------------------------------------------------------------------
// Property 3: Conversation role flipping
// ---------------------------------------------------------------------------

describe("Property 3: Conversation role flipping", () => {
  /**
   * Validates: Requirements 8.2, 8.4
   */

  it("output length equals input length — no turns added or removed", () => {
    fc.assert(
      fc.property(historyArb, (history) => {
        const result = flipConversationRoles(history);
        expect(result).toHaveLength(history.length);
      }),
      { numRuns: 100 }
    );
  });

  it("every 'customer' turn becomes role 'assistant'", () => {
    fc.assert(
      fc.property(historyArb, (history) => {
        const result = flipConversationRoles(history);
        history.forEach((turn, i) => {
          if (turn.role === "customer") {
            expect(result[i].role).toBe("assistant");
          }
        });
      }),
      { numRuns: 100 }
    );
  });

  it("every 'agent' turn becomes role 'user'", () => {
    fc.assert(
      fc.property(historyArb, (history) => {
        const result = flipConversationRoles(history);
        history.forEach((turn, i) => {
          if (turn.role === "agent") {
            expect(result[i].role).toBe("user");
          }
        });
      }),
      { numRuns: 100 }
    );
  });

  it("text content is preserved unchanged for every turn", () => {
    fc.assert(
      fc.property(historyArb, (history) => {
        const result = flipConversationRoles(history);
        history.forEach((turn, i) => {
          const messageContent = result[i].content;
          expect(messageContent).toBeDefined();
          expect(messageContent![0]).toHaveProperty("text", turn.text);
        });
      }),
      { numRuns: 100 }
    );
  });

  it("only 'assistant' and 'user' roles appear in output", () => {
    fc.assert(
      fc.property(historyArb, (history) => {
        const result = flipConversationRoles(history);
        result.forEach((msg) => {
          expect(["assistant", "user"]).toContain(msg.role);
        });
      }),
      { numRuns: 100 }
    );
  });
});

// ---------------------------------------------------------------------------
// Property 4: Simulator system prompt construction
// ---------------------------------------------------------------------------

describe("Property 4: Simulator system prompt construction", () => {
  /**
   * Validates: Requirements 8.6, 8.7
   */

  it("system prompt contains the goal text (initialUtterance)", () => {
    fc.assert(
      fc.property(testCaseArb, (testCase) => {
        const prompt = buildSimulatorPrompt(testCase);
        expect(prompt).toContain(testCase.initialUtterance);
      }),
      { numRuns: 100 }
    );
  });

  it("system prompt contains the style-appropriate instruction", () => {
    fc.assert(
      fc.property(testCaseArb, (testCase) => {
        const prompt = buildSimulatorPrompt(testCase);
        const expectedInstruction = STYLE_INSTRUCTIONS[testCase.style];
        expect(prompt).toContain(expectedInstruction);
      }),
      { numRuns: 100 }
    );
  });

  it("system prompt contains all customer knowledge values", () => {
    fc.assert(
      fc.property(testCaseArb, (testCase) => {
        const prompt = buildSimulatorPrompt(testCase);
        const entries = Object.entries(testCase.customerKnowledge);
        entries.forEach(([key, value]) => {
          expect(prompt).toContain(value);
          expect(prompt).toContain(key);
        });
      }),
      { numRuns: 100 }
    );
  });

  it("system prompt mentions personal details should only be revealed when asked", () => {
    fc.assert(
      fc.property(testCaseArb, (testCase) => {
        const prompt = buildSimulatorPrompt(testCase);
        // The prompt should instruct the model to only provide details when asked
        expect(prompt.toLowerCase()).toContain("when");
        expect(prompt.toLowerCase()).toContain("ask");
      }),
      { numRuns: 100 }
    );
  });

  it("system prompt contains all three required components simultaneously", () => {
    fc.assert(
      fc.property(testCaseArb, (testCase) => {
        const prompt = buildSimulatorPrompt(testCase);

        // (a) Goal text present
        const hasGoal = prompt.includes(testCase.initialUtterance);

        // (b) Style instruction present
        const hasStyle = prompt.includes(STYLE_INSTRUCTIONS[testCase.style]);

        // (c) All customer knowledge values present
        const entries = Object.entries(testCase.customerKnowledge);
        const hasAllKnowledge =
          entries.length === 0 || entries.every(([, value]) => prompt.includes(value));

        expect(hasGoal).toBe(true);
        expect(hasStyle).toBe(true);
        expect(hasAllKnowledge).toBe(true);
      }),
      { numRuns: 100 }
    );
  });
});
