/**
 * Unit tests for the Prompts_Store CRUD methods on `DynamoDBService`.
 *
 * These tests exercise the transactional write contract that the design's
 * Data Models section pins down for `putPromptOverride` and
 * `deletePromptOverride`, plus the best-effort eviction path on
 * `evictOldestHistoryEntry`. The DDB document client is mocked end-to-end
 * with `vi.fn()` so each test can capture the exact `TransactWriteItems`
 * payload the service builds and assert on its shape without going near
 * the real AWS SDK transport layer.
 *
 * The four key invariants under test:
 *
 *   1. With `priorVersion === 0` (no prior override), the transaction
 *      contains exactly ONE item — a conditional `Put` of the OVERRIDE
 *      row asserting `attribute_not_exists(version)`. There is no history
 *      Put because the implicit default state is never persisted as a
 *      HISTORY row.
 *
 *   2. With `priorVersion > 0`, the transaction contains exactly TWO
 *      items: a `Put` of the prior override snapshotted as a HISTORY row
 *      (key `HISTORY#{paddedPriorVersion}`), followed by a conditional
 *      `Put` of the new OVERRIDE row asserting `version = :priorVersion`.
 *      Eviction is intentionally NOT part of the transaction — it is a
 *      separate `DeleteItem` on `evictOldestHistoryEntry`.
 *
 *   3. Optimistic-concurrency violation: AWS surfaces the conditional
 *      check failure either as a top-level
 *      `ConditionalCheckFailedException` (single-item writes) or wrapped
 *      in a `TransactionCanceledException` whose `CancellationReasons[]`
 *      carry `Code: "ConditionalCheckFailed"` (transactional writes).
 *      Either shape MUST surface to the caller as the typed
 *      `PromptOverrideVersionConflictError`. Other errors propagate
 *      unchanged.
 *
 *   4. `evictOldestHistoryEntry` is best-effort: when the count is over
 *      the cap, it issues exactly one `DeleteCommand` against the oldest
 *      entry; when under the cap, it issues none; when DDB throws, the
 *      error is swallowed and a warning is logged.
 *
 * The test file mocks the `DynamoDBDocumentClient.send` surface via
 * `vi.fn()` and inspects each command via its `constructor.name` so it
 * does not have to import the SDK's `instanceof` constructors directly.
 *
 * _Validates: Requirements 4.2, 7.2_
 */

import {
  afterEach,
  beforeEach,
  describe,
  expect,
  it,
  vi,
  type MockInstance,
} from "vitest";
import type { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

import {
  createDynamoDBService,
  PromptOverrideVersionConflictError,
} from "../../src/backend/services/dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../src/shared/constants";
import type { PromptOverride } from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Test fixtures
// ---------------------------------------------------------------------------

const TABLE_NAME = "TestPromptsTable";

/** A canonical "prior" override used by the priorVersion>0 tests. */
function makePriorOverride(): PromptOverride {
  return {
    promptKey: "failure_analysis",
    text: "Analyze the failure: {transcript}",
    modelKey: "claude_sonnet_4_6",
    inferenceParameters: { maxTokens: 2048 },
    version: 5,
    lastModifiedAt: "2024-06-01T12:00:00.000Z",
    lastModifiedBy: "user-prior",
  };
}

/** A canonical "new" override used by the put-path tests. */
function makeNewOverride(version: number): PromptOverride {
  return {
    promptKey: "failure_analysis",
    text: "Analyze the failure carefully: {transcript}",
    modelKey: "claude_haiku_4_5",
    inferenceParameters: { maxTokens: 4096 },
    version,
    lastModifiedAt: "2024-06-02T13:30:00.000Z",
    lastModifiedBy: "user-new",
  };
}

/**
 * Build a `DynamoDBDocumentClient`-shaped mock whose `send` is a
 * `vi.fn()`. The handler is provided per-test so it can return command
 * outputs or throw on demand. Returns the mock client + the underlying
 * `send` spy so tests can introspect the calls.
 */
function makeMockClient(
  handler: (cmd: unknown) => Promise<unknown> = async () => ({})
): { client: DynamoDBDocumentClient; send: ReturnType<typeof vi.fn> } {
  const send = vi.fn().mockImplementation(handler);
  const client = { send } as unknown as DynamoDBDocumentClient;
  return { client, send };
}

/**
 * Locate the (single) `TransactWriteCommand` in a list of recorded
 * `send` invocations, and return its `input.TransactItems` array. Throws
 * a descriptive error if none or multiple are found, so test failures
 * point at the right line.
 */
function getTransactItems(
  send: ReturnType<typeof vi.fn>
): Array<Record<string, unknown>> {
  const calls = send.mock.calls.filter(
    (c) => (c[0] as object).constructor.name === "TransactWriteCommand"
  );
  if (calls.length !== 1) {
    throw new Error(
      `Expected exactly 1 TransactWriteCommand, observed ${calls.length}`
    );
  }
  const cmd = calls[0][0] as { input: { TransactItems: unknown[] } };
  return cmd.input.TransactItems as Array<Record<string, unknown>>;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("Prompts_Store: putPromptOverride", () => {
  let warnSpy: MockInstance;

  beforeEach(() => {
    warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
  });

  afterEach(() => {
    warnSpy.mockRestore();
  });

  it("with priorVersion=0 builds a transaction with ONE item: a conditional Put on attribute_not_exists", async () => {
    const { client, send } = makeMockClient(async () => ({}));
    const service = createDynamoDBService(TABLE_NAME, client);

    const newOverride = makeNewOverride(1);
    await service.putPromptOverride(newOverride, /*priorVersion=*/ 0, null);

    const items = getTransactItems(send);
    expect(items).toHaveLength(1);

    // The single item is the conditional Put on the OVERRIDE row.
    const putItem = items[0] as { Put: Record<string, unknown> };
    expect(putItem.Put).toBeDefined();

    const put = putItem.Put;
    expect(put.TableName).toBe(TABLE_NAME);
    expect(put.ConditionExpression).toBe("attribute_not_exists(version)");
    // No ExpressionAttributeValues when there is no `:priorVersion` placeholder.
    expect(put.ExpressionAttributeValues).toBeUndefined();

    const item = put.Item as Record<string, unknown>;
    expect(item.PK).toBe(`${PK_PATTERNS.PROMPT}${newOverride.promptKey}`);
    expect(item.SK).toBe(SK_PATTERNS.OVERRIDE);
    // The override fields are spread into the row alongside the keys.
    expect(item.promptKey).toBe(newOverride.promptKey);
    expect(item.version).toBe(newOverride.version);
    expect(item.text).toBe(newOverride.text);
    expect(item.modelKey).toBe(newOverride.modelKey);
    expect(item.lastModifiedBy).toBe(newOverride.lastModifiedBy);
  });

  it("with priorVersion>0 builds a transaction with TWO items: history Put + conditional override Put with version equality", async () => {
    const { client, send } = makeMockClient(async () => ({}));
    const service = createDynamoDBService(TABLE_NAME, client);

    const priorOverride = makePriorOverride();
    const newOverride = makeNewOverride(priorOverride.version + 1);

    await service.putPromptOverride(
      newOverride,
      priorOverride.version,
      priorOverride,
      "edit"
    );

    const items = getTransactItems(send);
    expect(items).toHaveLength(2);

    // ---- Item 1: history Put snapshotting the prior override. ----
    const historyItem = items[0] as { Put: Record<string, unknown> };
    expect(historyItem.Put).toBeDefined();
    const historyPut = historyItem.Put;
    expect(historyPut.TableName).toBe(TABLE_NAME);

    const historyRow = historyPut.Item as Record<string, unknown>;
    expect(historyRow.PK).toBe(
      `${PK_PATTERNS.PROMPT}${priorOverride.promptKey}`
    );
    // padVersion zero-pads to 10 digits so SK lex-order matches numeric order.
    expect(historyRow.SK).toBe(
      `${SK_PATTERNS.HISTORY}${"0000000005"}`
    );
    expect(historyRow.version).toBe(priorOverride.version);
    expect(historyRow.changeKind).toBe("edit");
    expect(historyRow.text).toBe(priorOverride.text);
    expect(historyRow.modelKey).toBe(priorOverride.modelKey);
    expect(historyRow.modifiedBy).toBe(priorOverride.lastModifiedBy);
    expect(historyRow.modifiedAt).toBe(priorOverride.lastModifiedAt);

    // ---- Item 2: conditional override Put asserting version equality. ----
    const overrideItem = items[1] as { Put: Record<string, unknown> };
    expect(overrideItem.Put).toBeDefined();
    const overridePut = overrideItem.Put;
    expect(overridePut.ConditionExpression).toBe(
      "version = :priorVersion"
    );
    expect(overridePut.ExpressionAttributeValues).toEqual({
      ":priorVersion": priorOverride.version,
    });

    const overrideRow = overridePut.Item as Record<string, unknown>;
    expect(overrideRow.PK).toBe(
      `${PK_PATTERNS.PROMPT}${newOverride.promptKey}`
    );
    expect(overrideRow.SK).toBe(SK_PATTERNS.OVERRIDE);
    expect(overrideRow.version).toBe(newOverride.version);
    expect(overrideRow.text).toBe(newOverride.text);
    expect(overrideRow.modelKey).toBe(newOverride.modelKey);
  });

  it("does NOT include an eviction action in the transaction itself (eviction is a separate DeleteItem)", async () => {
    const { client, send } = makeMockClient(async () => ({}));
    const service = createDynamoDBService(TABLE_NAME, client);

    const priorOverride = makePriorOverride();
    const newOverride = makeNewOverride(priorOverride.version + 1);

    await service.putPromptOverride(
      newOverride,
      priorOverride.version,
      priorOverride
    );

    const items = getTransactItems(send);

    // No Delete action of any flavour should appear in the transaction.
    for (const item of items) {
      expect(item.Delete).toBeUndefined();
      expect(item.Update).toBeUndefined();
      expect(item.ConditionCheck).toBeUndefined();
    }

    // And the only command sent during the put is the transaction; no
    // separate DeleteCommand was issued from inside putPromptOverride.
    const commandNames = send.mock.calls.map(
      (c) => (c[0] as object).constructor.name
    );
    expect(commandNames).toEqual(["TransactWriteCommand"]);
    expect(commandNames).not.toContain("DeleteCommand");
  });

  it("propagates a wrapped TransactionCanceledException with ConditionalCheckFailed reason as PromptOverrideVersionConflictError", async () => {
    // Simulates: caller's prior GetItem returned version=5, but a
    // concurrent writer bumped the row to version=6 before the
    // transaction commits, so DDB cancels the transaction with a
    // `ConditionalCheckFailed` reason on the OVERRIDE put.
    const cancelledError = Object.assign(new Error("Transaction cancelled"), {
      name: "TransactionCanceledException",
      CancellationReasons: [
        // Index 0 is the history Put — succeeded with no condition.
        { Code: "None" },
        // Index 1 is the conditional OVERRIDE Put — this is where the
        // concurrent edit collided.
        { Code: "ConditionalCheckFailed" },
      ],
    });
    const { client } = makeMockClient(async () => {
      throw cancelledError;
    });
    const service = createDynamoDBService(TABLE_NAME, client);

    const priorOverride = makePriorOverride();
    const newOverride = makeNewOverride(priorOverride.version + 1);

    await expect(
      service.putPromptOverride(
        newOverride,
        priorOverride.version,
        priorOverride
      )
    ).rejects.toBeInstanceOf(PromptOverrideVersionConflictError);

    // Re-issue and capture so we can introspect the typed error fields.
    const { client: client2 } = makeMockClient(async () => {
      throw cancelledError;
    });
    const service2 = createDynamoDBService(TABLE_NAME, client2);
    let captured: unknown;
    try {
      await service2.putPromptOverride(
        newOverride,
        priorOverride.version,
        priorOverride
      );
    } catch (err) {
      captured = err;
    }
    expect(captured).toBeInstanceOf(PromptOverrideVersionConflictError);
    const typed = captured as PromptOverrideVersionConflictError;
    expect(typed.promptKey).toBe(newOverride.promptKey);
    expect(typed.observedPriorVersion).toBe(priorOverride.version);
  });

  it("propagates a top-level ConditionalCheckFailedException as PromptOverrideVersionConflictError", async () => {
    // Simulates the single-item-write shape: AWS surfaces the failed
    // condition directly without wrapping it in a TransactionCancelled.
    // The Prompts_Store helper must map both shapes to the typed error.
    const directError = Object.assign(
      new Error("The conditional request failed"),
      { name: "ConditionalCheckFailedException" }
    );
    const { client } = makeMockClient(async () => {
      throw directError;
    });
    const service = createDynamoDBService(TABLE_NAME, client);

    const newOverride = makeNewOverride(1);

    await expect(
      service.putPromptOverride(newOverride, /*priorVersion=*/ 0, null)
    ).rejects.toBeInstanceOf(PromptOverrideVersionConflictError);
  });

  it("propagates non-conditional errors unchanged (e.g. a network/throttling error)", async () => {
    const throttle = Object.assign(new Error("Rate exceeded"), {
      name: "ProvisionedThroughputExceededException",
    });
    const { client } = makeMockClient(async () => {
      throw throttle;
    });
    const service = createDynamoDBService(TABLE_NAME, client);

    const newOverride = makeNewOverride(1);

    await expect(
      service.putPromptOverride(newOverride, /*priorVersion=*/ 0, null)
    ).rejects.toThrowError(throttle);
  });
});

describe("Prompts_Store: deletePromptOverride", () => {
  let warnSpy: MockInstance;

  beforeEach(() => {
    warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
  });

  afterEach(() => {
    warnSpy.mockRestore();
  });

  /** A canonical reset event used by the priorOverride!=null tests. */
  function makeResetEvent() {
    return {
      modifiedAt: "2024-06-15T09:00:00.000Z",
      modifiedBy: "user-resetter",
      modifiedByEmail: "resetter@example.com",
    };
  }

  it("is a no-op when priorOverride is null (no DDB call issued)", async () => {
    const { client, send } = makeMockClient(async () => ({}));
    const service = createDynamoDBService(TABLE_NAME, client);

    await service.deletePromptOverride(
      "failure_analysis",
      null,
      makeResetEvent()
    );

    expect(send).not.toHaveBeenCalled();
  });

  it("builds a transaction with THREE items: prior-edit snapshot + reset event + conditional Delete on version equality", async () => {
    const { client, send } = makeMockClient(async () => ({}));
    const service = createDynamoDBService(TABLE_NAME, client);

    const priorOverride = makePriorOverride();
    const resetEvent = makeResetEvent();
    await service.deletePromptOverride(
      priorOverride.promptKey,
      priorOverride,
      resetEvent
    );

    const items = getTransactItems(send);
    expect(items).toHaveLength(3);

    // ---- Item 1: prior-edit snapshot at the prior version's slot. ----
    // The reset bug-fix split the prior row's snapshot from the reset
    // event itself: this row preserves the prior edit's audit trail
    // verbatim, including the body fields (text, modelKey,
    // inferenceParameters) so a forensic reader can see exactly what
    // the prompt was running before the reset wiped the OVERRIDE.
    const priorSnapshotItem = items[0] as { Put: Record<string, unknown> };
    expect(priorSnapshotItem.Put).toBeDefined();
    const priorRow = priorSnapshotItem.Put.Item as Record<string, unknown>;
    expect(priorRow.PK).toBe(
      `${PK_PATTERNS.PROMPT}${priorOverride.promptKey}`
    );
    expect(priorRow.SK).toBe(`${SK_PATTERNS.HISTORY}0000000005`);
    expect(priorRow.changeKind).toBe("edit");
    expect(priorRow.version).toBe(priorOverride.version);
    expect(priorRow.text).toBe(priorOverride.text);
    expect(priorRow.modelKey).toBe(priorOverride.modelKey);
    expect(priorRow.modifiedBy).toBe(priorOverride.lastModifiedBy);
    expect(priorRow.modifiedAt).toBe(priorOverride.lastModifiedAt);

    // ---- Item 2: reset event row at priorVersion+1 with no body. ----
    // A reset returns the prompt to the bundled default; the lack of
    // sparse fields (text, modelKey, inferenceParameters) signals
    // "use defaults" to any forensic reader. The row carries the
    // resetter's identity and a fresh timestamp — distinct from the
    // prior override's timestamp — so the change-history table can
    // attribute the reset to who performed it and when.
    const resetItem = items[1] as { Put: Record<string, unknown> };
    expect(resetItem.Put).toBeDefined();
    const resetRow = resetItem.Put.Item as Record<string, unknown>;
    expect(resetRow.PK).toBe(
      `${PK_PATTERNS.PROMPT}${priorOverride.promptKey}`
    );
    expect(resetRow.SK).toBe(`${SK_PATTERNS.HISTORY}0000000006`);
    expect(resetRow.version).toBe(priorOverride.version + 1);
    expect(resetRow.changeKind).toBe("reset");
    expect(resetRow.modifiedAt).toBe(resetEvent.modifiedAt);
    expect(resetRow.modifiedBy).toBe(resetEvent.modifiedBy);
    expect(resetRow.modifiedByEmail).toBe(resetEvent.modifiedByEmail);
    // Body fields MUST be absent on the reset event row.
    expect(resetRow.text).toBeUndefined();
    expect(resetRow.modelKey).toBeUndefined();
    expect(resetRow.inferenceParameters).toBeUndefined();

    // ---- Item 3: conditional Delete of the OVERRIDE row. ----
    const deleteItem = items[2] as { Delete: Record<string, unknown> };
    expect(deleteItem.Delete).toBeDefined();
    const del = deleteItem.Delete;
    expect(del.TableName).toBe(TABLE_NAME);
    expect(del.Key).toEqual({
      PK: `${PK_PATTERNS.PROMPT}${priorOverride.promptKey}`,
      SK: SK_PATTERNS.OVERRIDE,
    });
    expect(del.ConditionExpression).toBe("version = :priorVersion");
    expect(del.ExpressionAttributeValues).toEqual({
      ":priorVersion": priorOverride.version,
    });
  });

  it("omits modifiedByEmail on the reset event row when not provided", async () => {
    const { client, send } = makeMockClient(async () => ({}));
    const service = createDynamoDBService(TABLE_NAME, client);

    const priorOverride = makePriorOverride();
    await service.deletePromptOverride(
      priorOverride.promptKey,
      priorOverride,
      {
        modifiedAt: "2024-06-15T09:00:00.000Z",
        modifiedBy: "user-resetter",
      }
    );

    const items = getTransactItems(send);
    const resetRow = (items[1] as { Put: { Item: Record<string, unknown> } })
      .Put.Item;
    expect(resetRow.modifiedBy).toBe("user-resetter");
    expect(resetRow.modifiedByEmail).toBeUndefined();
  });

  it("propagates a TransactionCanceledException with ConditionalCheckFailed reason as PromptOverrideVersionConflictError", async () => {
    const cancelledError = Object.assign(new Error("Transaction cancelled"), {
      name: "TransactionCanceledException",
      CancellationReasons: [
        // Item 0: prior-edit snapshot Put — succeeded, no condition.
        { Code: "None" },
        // Item 1: reset event Put — succeeded, no condition.
        { Code: "None" },
        // Item 2: conditional Delete — collided with a concurrent edit.
        { Code: "ConditionalCheckFailed" },
      ],
    });
    const { client } = makeMockClient(async () => {
      throw cancelledError;
    });
    const service = createDynamoDBService(TABLE_NAME, client);

    const priorOverride = makePriorOverride();

    await expect(
      service.deletePromptOverride(
        priorOverride.promptKey,
        priorOverride,
        makeResetEvent()
      )
    ).rejects.toBeInstanceOf(PromptOverrideVersionConflictError);
  });
});

describe("Prompts_Store: getLatestHistoryVersion", () => {
  it("returns 0 when no history rows exist for the prompt", async () => {
    // Empty `Items` mirrors the post-deploy state for a prompt that
    // has never been edited or reset — the very state the post-reset
    // edit handler hits when it asks "what version should the next
    // edit land at?" and there's no override either.
    const send = vi.fn().mockImplementation(async () => ({ Items: [] }));
    const client = { send } as unknown as DynamoDBDocumentClient;
    const service = createDynamoDBService(TABLE_NAME, client);

    const observed = await service.getLatestHistoryVersion("failure_analysis");
    expect(observed).toBe(0);
  });

  it("returns the highest version when history rows exist (post-reset edit collision avoidance)", async () => {
    // After an edit-then-reset the persisted history is
    // [{v=1, edit}, {v=2, reset}]. The next edit must land at v=3,
    // NOT v=1 (which would collide with the v=1 history row). The
    // service issues a Query with Limit=1, ScanIndexForward=false so
    // the first item returned is the highest-version row — the mock
    // returns that single item directly.
    const send = vi.fn().mockImplementation(async () => ({
      Items: [
        {
          PK: "PROMPT#failure_analysis",
          SK: "HISTORY#0000000002",
          version: 2,
          changeKind: "reset",
        },
      ],
    }));
    const client = { send } as unknown as DynamoDBDocumentClient;
    const service = createDynamoDBService(TABLE_NAME, client);

    const observed = await service.getLatestHistoryVersion("failure_analysis");
    expect(observed).toBe(2);

    // Verify the Query was issued with the right shape (Limit=1, descending).
    const calls = send.mock.calls.filter(
      (c) => (c[0] as object).constructor.name === "QueryCommand"
    );
    expect(calls).toHaveLength(1);
    const cmd = calls[0][0] as {
      input: {
        Limit?: number;
        ScanIndexForward?: boolean;
        KeyConditionExpression?: string;
      };
    };
    expect(cmd.input.Limit).toBe(1);
    expect(cmd.input.ScanIndexForward).toBe(false);
    expect(cmd.input.KeyConditionExpression).toContain("begins_with(SK");
  });

  it("returns 0 when the latest item is missing the version attribute (defensive)", async () => {
    // Defensive guard: a HISTORY row missing its `version` attribute
    // is malformed — the helper falls back to 0 rather than crashing
    // the handler with `NaN+1` arithmetic downstream.
    const send = vi.fn().mockImplementation(async () => ({
      Items: [{ PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000001" }],
    }));
    const client = { send } as unknown as DynamoDBDocumentClient;
    const service = createDynamoDBService(TABLE_NAME, client);

    const observed = await service.getLatestHistoryVersion("failure_analysis");
    expect(observed).toBe(0);
  });
});

describe("Prompts_Store: evictOldestHistoryEntry", () => {
  let warnSpy: MockInstance;

  beforeEach(() => {
    warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
  });

  afterEach(() => {
    warnSpy.mockRestore();
  });

  it("does nothing when the history count is at or below the cap", async () => {
    // Returning exactly `maxEntries` items means we are at the cap, not
    // over it; eviction should not fire.
    const items = [
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000001", version: 1 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000002", version: 2 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000003", version: 3 },
    ];
    const send = vi.fn().mockImplementation(async (cmd: unknown) => {
      if ((cmd as object).constructor.name === "QueryCommand") {
        return { Items: items };
      }
      return {};
    });
    const client = { send } as unknown as DynamoDBDocumentClient;
    const service = createDynamoDBService(TABLE_NAME, client);

    await service.evictOldestHistoryEntry("failure_analysis", 3);

    // Exactly one Query, no Delete.
    const commandNames = send.mock.calls.map(
      (c) => (c[0] as object).constructor.name
    );
    expect(commandNames).toEqual(["QueryCommand"]);
    expect(commandNames).not.toContain("DeleteCommand");
  });

  it("issues a single DeleteCommand against the OLDEST entry when the count exceeds the cap by one", async () => {
    // Return cap+1=4 items in oldest-first order — the helper deletes
    // the first (oldest) one. The query is `ScanIndexForward: true`
    // and now bounded to `Limit: cap + 5` so a typical reset surplus
    // (which can exceed the cap by 2 in a single user action) is
    // drained in one round trip.
    const items = [
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000001", version: 1 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000002", version: 2 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000003", version: 3 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000004", version: 4 },
    ];
    const send = vi.fn().mockImplementation(async (cmd: unknown) => {
      const name = (cmd as object).constructor.name;
      if (name === "QueryCommand") {
        return { Items: items };
      }
      if (name === "DeleteCommand") {
        return {};
      }
      return {};
    });
    const client = { send } as unknown as DynamoDBDocumentClient;
    const service = createDynamoDBService(TABLE_NAME, client);

    await service.evictOldestHistoryEntry("failure_analysis", 3);

    const deleteCalls = send.mock.calls.filter(
      (c) => (c[0] as object).constructor.name === "DeleteCommand"
    );
    expect(deleteCalls).toHaveLength(1);

    const deleteCmd = deleteCalls[0][0] as {
      input: { TableName: string; Key: Record<string, string> };
    };
    expect(deleteCmd.input.TableName).toBe(TABLE_NAME);
    expect(deleteCmd.input.Key).toEqual({
      PK: "PROMPT#failure_analysis",
      SK: "HISTORY#0000000001",
    });
  });

  it("drains ALL surplus entries when the count exceeds the cap by more than one (reset overshoot)", async () => {
    // A reset transaction adds two HISTORY rows in one go (the
    // prior-edit snapshot AND the reset event), so a steady-state
    // edit history at the cap can be pushed to cap+2 by a single
    // reset. The helper now drains both surplus rows in one pass
    // rather than only the oldest one — otherwise the next eviction
    // would have to clean up after the previous one indefinitely.
    const items = [
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000001", version: 1 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000002", version: 2 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000003", version: 3 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000004", version: 4 },
      { PK: "PROMPT#failure_analysis", SK: "HISTORY#0000000005", version: 5 },
    ];
    const send = vi.fn().mockImplementation(async (cmd: unknown) => {
      const name = (cmd as object).constructor.name;
      if (name === "QueryCommand") {
        return { Items: items };
      }
      if (name === "DeleteCommand") {
        return {};
      }
      return {};
    });
    const client = { send } as unknown as DynamoDBDocumentClient;
    const service = createDynamoDBService(TABLE_NAME, client);

    // Cap=3, items=5 → surplus=2 → expect 2 deletes targeting the
    // two oldest rows.
    await service.evictOldestHistoryEntry("failure_analysis", 3);

    const deleteCalls = send.mock.calls.filter(
      (c) => (c[0] as object).constructor.name === "DeleteCommand"
    );
    expect(deleteCalls).toHaveLength(2);
    const deletedSks = deleteCalls.map(
      (c) =>
        (c[0] as { input: { Key: { SK: string } } }).input.Key.SK
    );
    expect(deletedSks).toEqual([
      "HISTORY#0000000001",
      "HISTORY#0000000002",
    ]);
  });

  it("swallows DDB errors and logs at warning level (best-effort eviction)", async () => {
    const send = vi.fn().mockImplementation(async () => {
      throw new Error("DDB transient failure");
    });
    const client = { send } as unknown as DynamoDBDocumentClient;
    const service = createDynamoDBService(TABLE_NAME, client);

    // Should NOT throw — best-effort by design.
    await expect(
      service.evictOldestHistoryEntry("failure_analysis", 3)
    ).resolves.toBeUndefined();

    expect(warnSpy).toHaveBeenCalled();
    const args = warnSpy.mock.calls[0]?.[0] as string;
    expect(args).toContain("evictOldestHistoryEntry failed");
    expect(args).toContain("failure_analysis");
  });
});
