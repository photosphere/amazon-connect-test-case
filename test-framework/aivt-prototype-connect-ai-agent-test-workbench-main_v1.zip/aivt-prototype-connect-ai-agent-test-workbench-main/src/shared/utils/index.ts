/**
 * Shared utility functions for the Connect Agent Test Platform.
 *
 * @module utils
 */

export { extractToolName } from "./tool-extraction";
export type { ConversationSessionDataEntry } from "./tool-extraction";
export { isFillerResponse } from "./filler-detection";
export { calculateBackoffDelay } from "./backoff";
export { formatElapsedTime, formatDurationMs } from "./time-formatting";
export { calculateAccuracy } from "./accuracy";
export { generateSessionName } from "./session-name";
export { compareRuns } from "./run-comparison";
export type {
  ComparisonCategory,
  ComparisonEntry,
  RunComparisonResult,
} from "./run-comparison";
export { diffAgentConfigs } from "./config-diff";
export type {
  ConfigChangeType,
  ConfigChange,
  ConfigDiffResult,
} from "./config-diff";
export { sortResults } from "./results-sorting";
export type { SortableResult } from "./results-sorting";
export { filterResults } from "./results-filtering";
export type { FilterableResult, FilterCriteria } from "./results-filtering";
export { calculateToolAccuracy } from "./tool-accuracy";
export type { ToolAccuracyResult } from "./tool-accuracy";
export { assembleCaseEvaluation } from "./evaluation-result";
export type {
  CaseEvaluation,
  EvaluationErrorCode,
  FailureContext,
} from "./evaluation-result";
export { deduplicateParameters } from "./parameter-dedup";
export type { ToolSchema, KnowledgeTemplateEntry } from "./parameter-dedup";
export { computeProgressDisplay } from "./progress-display";
export type { ProgressState, ProgressDisplay } from "./progress-display";
export { extractTenantId, extractTenantIdFromEvent } from "./tenant-extraction";
export type { CognitoClaims } from "./tenant-extraction";
export { extractFriendlyModelName } from "./model-naming";
export { bucketByTargetField } from "./recommendation-bucketing";
export type { BucketedRecommendations } from "./recommendation-bucketing";
