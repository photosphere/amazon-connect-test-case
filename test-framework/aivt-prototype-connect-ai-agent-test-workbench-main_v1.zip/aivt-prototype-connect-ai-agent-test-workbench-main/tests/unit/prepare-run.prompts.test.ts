/**
 * Unit tests for PrepareRun's prompt-pinning step.
 *
 * Task 17.1 extended `prepare-run.ts` to resolve every key in
 * `RUN_PROMPT_KEYS` against the override store at run start and pin the
 * resulting `ResolvedPromptSnapshot` triples on `AgentSnapshot.prompts`
 * before the run record reaches RUNNING. These tests pin that contract:
 *
 *   1. `AgentSnapshot.prompts` carries an entry for every
 *      `RUN_PROMPT_KEYS` key, equal to `resolvePrompt(key, overrides)`
 *      (defaults when the override Map is empty; the override's text and
 *      modelKey when one is present).
 *   2. `writeSnapshot` runs strictly before `createRun` so the run
 *      record never reaches RUNNING without its prompts pinned (R11.1).
 *   3. A `listPromptOverrides` rejection aborts the run before any
 *      partial state lands in DDB — no snapshot, no run record — and
 *      surfaces a `PromptResolutionFailedError` carrying the original
 *      cause (R11.2).
 *
 * The existing `prepare-run.test.ts` covers the `hasRagCases` output
 * field; this sibling file isolates the prompt-pinning concerns so the
 * `vi.hoisted` mock surface and `vi.resetModules()` reset that this
 * group needs do not perturb the existing tests.
 *
 * Requirements: 11.1, 11.2
 */

import {
  describe,
  it,
  expect,
  beforeEach,
  afterEach,
  vi,
} from "vitest";

import {
  resolvePrompt,
  RUN_PROMPT_KEYS,
} from "../../src/backend/orchestration/prompt-registry";
import type {
  PromptKey,
  PromptOverride,
} from "../../src/backend/orchestration/prompt-registry";

// ---------------------------------------------------------------------------
// Hoisted mocks
// ---------------------------------------------------------------------------
//
// `vi.mock` is hoisted above all imports, so any mock fns the factory
// references must be declared via `vi.hoisted` so they exist at hoist
// time. We reuse the same three hoisted mocks across every test and
// reset them in `beforeEach`; the mock factory below wires every
// `new DynamoDBService()` instance to these three fns so the cached
// singleton inside `prepare-run.ts` ends up routing through them.
//
const { createRunMock, writeSnapshotMock, listPromptOverridesMock } =
  vi.hoisted(() => ({
    createRunMock: vi.fn(),
    writeSnapshotMock: vi.fn(),
    listPromptOverridesMock: vi.fn(),
  }));

vi.mock("../../src/backend/services/dynamodb", () => ({
  DynamoDBService: vi.fn().mockImplementation(() => ({
    createRun: createRunMock,
    writeSnapshot: writeSnapshotMock,
    listPromptOverrides: listPromptOverridesMock,
  })),
}));

import type { PrepareRunInput } from "../../src/backend/orchestration/handlers/prepare-run";

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------

const baseAgentSnapshot = {
  agentId: "agent-1",
  name: "agent-1",
  systemPrompt: "you are a helpful agent",
  modelId: "model-1",
  tools: [],
};

function makeInput(
  overrides: Partial<PrepareRunInput> = {},
): PrepareRunInput {
  return {
    suiteId: "suite-1",
    tenantId: "tenant-1",
    runId: "run-test-prompts-1",
    startTime: "2026-06-09T14:00:00.000Z",
    concurrency: 9,
    agentSnapshot: baseAgentSnapshot,
    testCases: [],
    ...overrides,
  };
}

/**
 * Dynamically import the handler module after `vi.resetModules()` so
 * the in-module `dynamoService` singleton is reset between tests.
 * Without this, the first test's `new DynamoDBService()` call would
 * cache an instance forever and the "fail-closed" test would not see
 * a fresh `buildPromptsMap` invocation against the rejecting
 * `listPromptOverrides` mock.
 */
async function importHandler() {
  return await import(
    "../../src/backend/orchestration/handlers/prepare-run"
  );
}

// ---------------------------------------------------------------------------
// Shared setup
// ---------------------------------------------------------------------------

const ORIGINAL_ENV = process.env.ASSISTANT_ID;

beforeEach(() => {
  process.env.ASSISTANT_ID = "asst-test";

  // Default behaviour: every test starts with all three DDB calls
  // succeeding and no overrides — so the resolver returns the bundled
  // defaults for every promptKey. Individual tests override this to
  // exercise the override-present and listPromptOverrides-rejects
  // paths.
  createRunMock.mockReset().mockResolvedValue(undefined);
  writeSnapshotMock.mockReset().mockResolvedValue(undefined);
  listPromptOverridesMock
    .mockReset()
    .mockResolvedValue(new Map<PromptKey, PromptOverride>());

  // Reset module cache so the handler's `dynamoService` singleton is
  // re-initialised against fresh mocks for every test. The hoisted
  // mocks are stable across resets (they are declared at module scope
  // here and the `vi.mock` factory closes over them), so the
  // re-loaded handler still routes through the same fns.
  vi.resetModules();
});

afterEach(() => {
  if (ORIGINAL_ENV === undefined) {
    delete process.env.ASSISTANT_ID;
  } else {
    process.env.ASSISTANT_ID = ORIGINAL_ENV;
  }
});

// ---------------------------------------------------------------------------
// Group 1 — AgentSnapshot.prompts shape (pristine + override paths)
// ---------------------------------------------------------------------------

describe("PrepareRun handler — AgentSnapshot.prompts shape", () => {
  it("pins every RUN_PROMPT_KEYS key to its bundled default when no overrides exist", async () => {
    const { handler } = await importHandler();
    await handler(makeInput());

    expect(writeSnapshotMock).toHaveBeenCalledOnce();
    const [, snapshot] = writeSnapshotMock.mock.calls[0] as [
      string,
      { prompts?: Record<string, unknown> },
    ];
    expect(snapshot.prompts).toBeDefined();
    const prompts = snapshot.prompts as Record<
      PromptKey,
      {
        text: string;
        modelKey: string;
        modelId: string;
        inferenceParameters: Readonly<Record<string, unknown>>;
        capabilityProfileKey: string;
        version: number;
      }
    >;

    // Every snapshot entry must equal what `resolvePrompt(key, empty)`
    // would return — that's the contract `prepare-run.ts` is supposed
    // to honour for the pristine path. We source the expected values
    // from the resolver directly (rather than hard-coding text bodies
    // here) so this test doesn't break every time a default is reworded.
    const emptyOverrides = new Map<PromptKey, PromptOverride>();
    for (const key of RUN_PROMPT_KEYS) {
      const expected = resolvePrompt(key, emptyOverrides);
      const actual = prompts[key];
      expect(
        actual,
        `missing snapshot entry for promptKey="${key}"`,
      ).toBeDefined();
      expect(actual.text).toBe(expected.text);
      expect(actual.modelKey).toBe(expected.modelKey);
      expect(actual.modelId).toBe(expected.modelId);
      expect(actual.inferenceParameters).toEqual(
        expected.inferenceParameters,
      );
      expect(actual.capabilityProfileKey).toBe(
        expected.capabilityProfile.key,
      );
      expect(actual.version).toBe(expected.version);
    }

    // Sanity: no extra keys leaked in (e.g. one of the interactive
    // prompts that should be excluded from the run-pinned set).
    expect(Object.keys(prompts).sort()).toEqual([...RUN_PROMPT_KEYS].sort());
  });

  it("pins an override's text and modelKey for the overridden key while other keys resolve to defaults", async () => {
    // The override text below contains every placeholder declared by
    // the customer_simulator definition (scenario, opening_line,
    // style_instruction, customer_details). Without them, the resolver
    // would invoke its stale-placeholder fallback and silently swap in
    // the bundled defaultText with version=0 — which would cause this
    // test to assert against the wrong text.
    const overrideText =
      'OVERRIDE — Your goal: {scenario}. Opening: "{opening_line}". Style: {style_instruction}. Details: {customer_details}.';
    const overridden: PromptOverride = {
      promptKey: "customer_simulator",
      text: overrideText,
      modelKey: "nova_pro",
      version: 7,
      lastModifiedAt: "2026-06-09T13:59:00.000Z",
      lastModifiedBy: "tester",
    };
    const overrides = new Map<PromptKey, PromptOverride>([
      ["customer_simulator", overridden],
    ]);
    listPromptOverridesMock.mockResolvedValue(overrides);

    const { handler } = await importHandler();
    await handler(makeInput());

    const [, snapshot] = writeSnapshotMock.mock.calls[0] as [
      string,
      { prompts: Record<PromptKey, {
        text: string;
        modelKey: string;
        version: number;
      }> },
    ];

    // The overridden key reflects the override's text, modelKey and
    // version verbatim.
    const overriddenEntry = snapshot.prompts["customer_simulator"];
    expect(overriddenEntry.text).toBe(overrideText);
    expect(overriddenEntry.modelKey).toBe("nova_pro");
    expect(overriddenEntry.version).toBe(7);

    // Every other run-pinned key still resolves to its bundled
    // default — the override only shadows the one key it targets.
    const emptyOverrides = new Map<PromptKey, PromptOverride>();
    for (const key of RUN_PROMPT_KEYS) {
      if (key === "customer_simulator") continue;
      const expected = resolvePrompt(key, emptyOverrides);
      expect(snapshot.prompts[key].text).toBe(expected.text);
      expect(snapshot.prompts[key].modelKey).toBe(expected.modelKey);
      expect(snapshot.prompts[key].version).toBe(expected.version);
    }
  });
});

// ---------------------------------------------------------------------------
// Group 2 — Capture order (writeSnapshot before createRun)
// ---------------------------------------------------------------------------

describe("PrepareRun handler — capture order (R11.1)", () => {
  it("calls writeSnapshot before createRun so the run record never reaches RUNNING without prompts pinned", async () => {
    const { handler } = await importHandler();
    await handler(makeInput());

    expect(writeSnapshotMock).toHaveBeenCalledOnce();
    expect(createRunMock).toHaveBeenCalledOnce();

    // `invocationCallOrder` is a monotonically increasing counter that
    // vitest assigns across all `vi.fn()` instances in a test, so it's
    // the canonical way to assert one mock fired before another even
    // when they live on different module surfaces.
    const writeOrder = writeSnapshotMock.mock.invocationCallOrder[0];
    const createOrder = createRunMock.mock.invocationCallOrder[0];
    expect(writeOrder).toBeLessThan(createOrder);
  });
});

// ---------------------------------------------------------------------------
// Group 3 — Fail-closed on listPromptOverrides rejection (R11.2)
// ---------------------------------------------------------------------------

describe("PrepareRun handler — fail-closed on prompt resolution failure (R11.2)", () => {
  it("throws PromptResolutionFailedError without writing a partial snapshot or creating a run", async () => {
    const cause = new Error("ddb-down");
    listPromptOverridesMock.mockRejectedValue(cause);

    const { handler, PromptResolutionFailedError } = await importHandler();

    let caught: unknown;
    try {
      await handler(makeInput());
    } catch (err) {
      caught = err;
    }

    expect(caught).toBeInstanceOf(PromptResolutionFailedError);
    expect((caught as { code?: string }).code).toBe(
      "PROMPT_RESOLUTION_FAILED",
    );
    // The original DDB rejection is reachable via the standard ES2022
    // `cause` slot so operators can inspect why the registry pin
    // failed without parsing the wrapper message.
    expect((caught as { cause?: unknown }).cause).toBe(cause);

    // Fail-closed: nothing about this run lands in DDB.
    expect(writeSnapshotMock).not.toHaveBeenCalled();
    expect(createRunMock).not.toHaveBeenCalled();
  });
});
