// @vitest-environment jsdom
/**
 * Unit tests for useImplementRecommendations hook.
 *
 * Tests the hook's integrated behavior (state transitions + API interactions)
 * using renderHook with mocked API modules.
 *
 * Requirements: 1.1–1.8, 2.1–2.5, 4.1–4.8, 7.1–7.5, 8.1–8.4
 *
 * @module frontend/hooks/__tests__/useImplementRecommendations.test
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderHook, act, cleanup } from '@testing-library/react';
import { ApiClientError } from '../../api/client';
import type {
  PerSuiteRecommendation,
  ExperimentRecord,
  ExperimentStatus,
  DriftedField,
} from '../../../../shared/types';

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

// The hook imports from '../api' (the barrel). We mock that barrel and keep
// ApiClientError as the real implementation so instanceof checks work.
vi.mock('../../api', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../api')>();
  return {
    ...actual,
    fetchRecommendations: vi.fn(),
    applyRecommendations: vi.fn(),
    createExperiment: vi.fn(),
    getExperiment: vi.fn(),
    applyVariant: vi.fn(),
    listExperiments: vi.fn(),
  };
});

import {
  fetchRecommendations,
  applyRecommendations,
  createExperiment,
  getExperiment,
} from '../../api';
import {
  useImplementRecommendations,
  POLLING_WARNING_THRESHOLD_MS,
} from '../useImplementRecommendations';

const mockFetchRecommendations = fetchRecommendations as ReturnType<typeof vi.fn>;
const mockApplyRecommendations = applyRecommendations as ReturnType<typeof vi.fn>;
const mockCreateExperiment = createExperiment as ReturnType<typeof vi.fn>;
const mockGetExperiment = getExperiment as ReturnType<typeof vi.fn>;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeRecommendation(index: number): PerSuiteRecommendation {
  return {
    targetField: 'system_prompt',
    targetName: 'system_prompt',
    currentText: `old-${index}`,
    suggestedText: `new-${index}`,
    rationale: `reason-${index}`,
    priority: index + 1,
    predictedImpact: { liftedCaseIds: [], rationale: '' },
  };
}

function makeExperimentRecord(status: ExperimentStatus): ExperimentRecord {
  return {
    experimentId: 'exp-001',
    runId: 'run-001',
    agentId: 'agent-001',
    status,
    variantConfigs: [],
    temporaryAgentIds: { A: 'a1', B: 'b1', C: 'c1' },
    variantRunIds: { A: 'r1', B: 'r2', C: 'r3' },
    baselineRunId: 'baseline-001',
    sfnExecutionArn: 'arn:aws:states:us-east-1:123:execution:exp',
    cleanupStatus: 'pending',
    createdAt: '2024-01-01T00:00:00Z',
  };
}

const DEFAULT_PROPS = {
  runId: 'run-001',
  suiteId: 'suite-001',
  agentId: 'agent-001',
};

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('useImplementRecommendations', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  // =========================================================================
  // Direct Apply Happy Path
  // idle → loading_recommendations → confirming → applying → success
  // =========================================================================

  describe('Direct Apply happy path', () => {
    it('transitions idle → loading → confirming → applying → success', async () => {
      const recommendations = [makeRecommendation(0), makeRecommendation(1)];
      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations,
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });
      mockApplyRecommendations.mockResolvedValueOnce({
        success: true,
        newVersionId: 'v2-abc',
      });

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      // Initial state
      expect(result.current.state).toBe('idle');

      // startDirectApply → loading_recommendations → confirming
      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('confirming');
      expect(result.current.context.recommendations).toEqual(recommendations);
      expect(result.current.context.selectedIndices).toEqual([0, 1]);

      // confirmApply → applying → success
      await act(async () => {
        result.current.confirmApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('success');
      expect(result.current.context.newVersionId).toBe('v2-abc');
      expect(mockApplyRecommendations).toHaveBeenCalledWith(
        'run-001',
        'agent-001',
        [0, 1],
      );
    });
  });

  // =========================================================================
  // Conflict Path
  // applying → conflict → forceApply → success
  // =========================================================================

  describe('Conflict path', () => {
    it('transitions applying → conflict on 409, then forceApply → success', async () => {
      const recommendations = [makeRecommendation(0)];
      const driftedFields: DriftedField[] = [
        {
          targetField: 'system_prompt',
          targetName: 'system_prompt',
          expectedText: 'old-0',
          actualText: 'someone-else-changed-this',
        },
      ];

      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations,
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });

      // First apply throws 409
      mockApplyRecommendations.mockRejectedValueOnce(
        new ApiClientError(409, 'Conflict detected', false, {
          details: { driftedFields },
        }),
      );

      // Force apply succeeds
      mockApplyRecommendations.mockResolvedValueOnce({
        success: true,
        newVersionId: 'v3-forced',
      });

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      // Get to confirming state
      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });
      expect(result.current.state).toBe('confirming');

      // confirmApply → conflict
      await act(async () => {
        result.current.confirmApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('conflict');
      expect(result.current.context.driftedFields).toEqual(driftedFields);

      // forceApply → success
      await act(async () => {
        result.current.forceApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('success');
      expect(result.current.context.newVersionId).toBe('v3-forced');
      // Verify force: true was passed
      expect(mockApplyRecommendations).toHaveBeenLastCalledWith(
        'run-001',
        'agent-001',
        [0],
        true,
      );
    });
  });

  // =========================================================================
  // Error Recovery — preserves recommendations
  // =========================================================================

  describe('Error recovery', () => {
    it('non-409 error preserves loaded recommendations', async () => {
      const recommendations = [makeRecommendation(0), makeRecommendation(1)];
      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations,
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });

      // Apply throws a 500 error
      mockApplyRecommendations.mockRejectedValueOnce(
        new ApiClientError(500, 'Internal server error', true),
      );

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      // Get to confirming
      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });
      expect(result.current.state).toBe('confirming');

      // confirmApply → error (preserving data)
      await act(async () => {
        result.current.confirmApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('error');
      expect(result.current.context.errorMessage).toBe('Internal server error');
      // Recommendations are preserved
      expect(result.current.context.recommendations).toEqual(recommendations);
      expect(result.current.context.selectedIndices).toEqual([0, 1]);
    });
  });

  // =========================================================================
  // Experiment Path
  // idle → experiment_starting → experiment_polling → experiment_completed
  // =========================================================================

  describe('Experiment path', () => {
    it('transitions through experiment creation and polling to completion', async () => {
      mockCreateExperiment.mockResolvedValueOnce({
        experimentId: 'exp-001',
        status: 'generating_variants' as ExperimentStatus,
      });

      // First poll returns running
      mockGetExperiment.mockResolvedValueOnce(makeExperimentRecord('running'));
      // Second poll returns completed
      mockGetExperiment.mockResolvedValueOnce(makeExperimentRecord('completed'));

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      // startExperiment (need to be in confirming first per VALID_TRANSITIONS)
      // Actually from the hook code, startExperiment dispatches directly to
      // experiment_starting. Let's get to confirming first.
      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations: [makeRecommendation(0)],
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });

      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });
      expect(result.current.state).toBe('confirming');

      // startExperiment from confirming
      await act(async () => {
        result.current.startExperiment();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('experiment_polling');
      expect(result.current.context.experimentId).toBe('exp-001');
      expect(result.current.context.pollingStartedAt).not.toBeNull();

      // The polling useEffect will trigger the first poll immediately
      // Advance timers to flush the immediate poll
      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      // After first poll (running), still in experiment_polling
      expect(result.current.state).toBe('experiment_polling');
      expect(result.current.context.experimentStatus).toBe('running');

      // Advance to next poll (5 seconds)
      await act(async () => {
        await vi.advanceTimersByTimeAsync(5_000);
      });

      // After second poll (completed), transitions to experiment_completed
      expect(result.current.state).toBe('experiment_completed');
      expect(result.current.context.experimentStatus).toBe('completed');
    });
  });

  // =========================================================================
  // 30-minute warning
  // =========================================================================

  describe('30-minute warning', () => {
    it('pollingStartedAt is set when entering experiment_polling and POLLING_WARNING_THRESHOLD_MS is 30 min', async () => {
      const nowMs = 1700000000000;
      vi.setSystemTime(nowMs);

      mockCreateExperiment.mockResolvedValueOnce({
        experimentId: 'exp-002',
        status: 'generating_variants' as ExperimentStatus,
      });

      // Keep polling alive — return non-terminal status
      mockGetExperiment.mockResolvedValue(makeExperimentRecord('running'));

      // Get to confirming first
      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations: [makeRecommendation(0)],
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      await act(async () => {
        result.current.startExperiment();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('experiment_polling');
      expect(result.current.context.pollingStartedAt).toBe(nowMs);

      // Verify the threshold constant is 30 minutes
      expect(POLLING_WARNING_THRESHOLD_MS).toBe(30 * 60 * 1_000);

      // After 30 minutes, pollingStartedAt is still set and can be used for the warning
      await act(async () => {
        await vi.advanceTimersByTimeAsync(POLLING_WARNING_THRESHOLD_MS);
      });

      // The hook is still polling (state remains experiment_polling)
      expect(result.current.state).toBe('experiment_polling');
      // pollingStartedAt hasn't changed — consumers compute elapsed time from it
      expect(result.current.context.pollingStartedAt).toBe(nowMs);
    });
  });

  // =========================================================================
  // Polling cleanup on unmount
  // =========================================================================

  describe('Polling cleanup on unmount', () => {
    it('stops polling when the component unmounts', async () => {
      mockCreateExperiment.mockResolvedValueOnce({
        experimentId: 'exp-003',
        status: 'generating_variants' as ExperimentStatus,
      });

      // Always return non-terminal to keep polling
      mockGetExperiment.mockResolvedValue(makeExperimentRecord('running'));

      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations: [makeRecommendation(0)],
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });

      const { result, unmount } = renderHook(() =>
        useImplementRecommendations(DEFAULT_PROPS),
      );

      // Get to experiment_polling
      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });
      await act(async () => {
        result.current.startExperiment();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('experiment_polling');

      // Flush the immediate poll
      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      // Record calls so far
      const callsBeforeUnmount = mockGetExperiment.mock.calls.length;

      // Unmount
      unmount();

      // Advance timers — no more polling should occur
      await vi.advanceTimersByTimeAsync(30_000);

      expect(mockGetExperiment.mock.calls.length).toBe(callsBeforeUnmount);
    });
  });

  // =========================================================================
  // Zero-selection guard
  // =========================================================================

  describe('Zero-selection guard', () => {
    it('confirmApply with empty selectedIndices stays in confirming', async () => {
      const recommendations = [makeRecommendation(0)];
      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations,
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      // Get to confirming
      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });
      expect(result.current.state).toBe('confirming');

      // Clear selections
      act(() => {
        result.current.setSelectedIndices([]);
      });
      expect(result.current.context.selectedIndices).toEqual([]);

      // Try to confirmApply — should NOT proceed
      await act(async () => {
        result.current.confirmApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      // Still in confirming — guard prevented transition
      expect(result.current.state).toBe('confirming');
      // API was never called
      expect(mockApplyRecommendations).not.toHaveBeenCalled();
    });
  });

  // =========================================================================
  // Dismiss / Cancel clears state
  // =========================================================================

  describe('Dismiss and Cancel', () => {
    it('cancelDialog from confirming returns to idle and clears context', async () => {
      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations: [makeRecommendation(0)],
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });
      expect(result.current.state).toBe('confirming');
      expect(result.current.context.recommendations.length).toBe(1);

      act(() => {
        result.current.cancelDialog();
      });

      expect(result.current.state).toBe('idle');
      expect(result.current.context.recommendations).toEqual([]);
      expect(result.current.context.selectedIndices).toEqual([]);
      expect(result.current.context.errorMessage).toBeNull();
    });

    it('dismissSuccess from success returns to idle', async () => {
      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations: [makeRecommendation(0)],
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });
      mockApplyRecommendations.mockResolvedValueOnce({
        success: true,
        newVersionId: 'v2',
      });

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });
      await act(async () => {
        result.current.confirmApply();
        await vi.advanceTimersByTimeAsync(0);
      });
      expect(result.current.state).toBe('success');

      act(() => {
        result.current.dismissSuccess();
      });

      expect(result.current.state).toBe('idle');
      expect(result.current.context.newVersionId).toBeNull();
    });
  });

  // =========================================================================
  // isLoading derived state
  // =========================================================================

  describe('isLoading derived state', () => {
    it('isLoading is true during loading_recommendations, applying, and experiment_starting', async () => {
      // Test loading_recommendations
      let resolveRecommendations: (value: any) => void;
      mockFetchRecommendations.mockReturnValueOnce(
        new Promise((resolve) => {
          resolveRecommendations = resolve;
        }),
      );

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('loading_recommendations');
      expect(result.current.isLoading).toBe(true);

      // Resolve the fetch
      await act(async () => {
        resolveRecommendations!({
          recommendations: [makeRecommendation(0)],
          agentName: 'TestAgent',
          agentId: 'agent-001',
        });
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('confirming');
      expect(result.current.isLoading).toBe(false);
    });
  });

  // =========================================================================
  // Experiment failure path
  // =========================================================================

  describe('Experiment failure', () => {
    it('experiment polling failure transitions to experiment_failed', async () => {
      mockCreateExperiment.mockResolvedValueOnce({
        experimentId: 'exp-004',
        status: 'generating_variants' as ExperimentStatus,
      });

      // The polling effect fires immediately when entering experiment_polling.
      // We set up getExperiment to reject so the immediate poll fails.
      mockGetExperiment.mockRejectedValue(
        new ApiClientError(500, 'Experiment polling failed', true),
      );

      mockFetchRecommendations.mockResolvedValueOnce({
        recommendations: [makeRecommendation(0)],
        agentName: 'TestAgent',
        agentId: 'agent-001',
      });

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      // Start experiment and let the immediate poll fire (which will fail)
      await act(async () => {
        result.current.startExperiment();
        await vi.advanceTimersByTimeAsync(0);
      });

      // The immediate poll in useEffect failed, transitioning to experiment_failed
      expect(result.current.state).toBe('experiment_failed');
      expect(result.current.context.errorMessage).toBe('Experiment polling failed');
    });
  });

  // =========================================================================
  // Fetch recommendations failure
  // =========================================================================

  describe('Fetch recommendations failure', () => {
    it('fetch failure transitions to error without opening ConfirmationDialog', async () => {
      mockFetchRecommendations.mockRejectedValueOnce(
        new ApiClientError(500, 'Server is down', true),
      );

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      await act(async () => {
        result.current.startDirectApply();
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('error');
      expect(result.current.context.errorMessage).toBe('Server is down');
      expect(result.current.context.recommendations).toEqual([]);
    });
  });

  // =========================================================================
  // applyVariant (TournamentView)
  // =========================================================================

  describe('applyVariant (TournamentView)', () => {
    it('populates variant context and transitions through confirming', async () => {
      const variantRecs = [
        {
          targetField: 'system_prompt' as const,
          targetName: 'system_prompt',
          currentText: 'old',
          suggestedText: 'new-variant-B',
          rationale: 'variant B improvement',
        },
      ];

      const { result } = renderHook(() => useImplementRecommendations(DEFAULT_PROPS));

      await act(async () => {
        result.current.applyVariant('B', variantRecs);
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.state).toBe('confirming');
      expect(result.current.context.applyingVariant).toBe('B');
      expect(result.current.context.variantRecommendations).toEqual(variantRecs);
      expect(result.current.context.selectedIndices).toEqual([0]);
    });
  });
});
