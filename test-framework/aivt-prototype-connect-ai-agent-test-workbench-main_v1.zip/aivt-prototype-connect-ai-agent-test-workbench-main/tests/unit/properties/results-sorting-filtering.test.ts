// Feature: connect-agent-test-platform, Property 9: Results sorting by status priority
// Feature: connect-agent-test-platform, Property 10: Results filter correctness
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { sortResults, SortableResult } from "@shared/utils/results-sorting";
import {
  filterResults,
  FilterableResult,
  FilterCriteria,
} from "@shared/utils/results-filtering";
import { CaseStatus } from "@shared/enums";

// ---------------------------------------------------------------------------
// Shared Arbitraries
// ---------------------------------------------------------------------------

const allStatuses = [
  CaseStatus.ERROR,
  CaseStatus.TIMED_OUT,
  CaseStatus.FAILED,
  CaseStatus.PENDING_EVALUATION,
  CaseStatus.PASSED,
];

/** Priority map matching the implementation — lower number = higher priority. */
const STATUS_PRIORITY: Record<CaseStatus, number> = {
  [CaseStatus.ERROR]: 0,
  [CaseStatus.TIMED_OUT]: 1,
  [CaseStatus.FAILED]: 2,
  [CaseStatus.PENDING_EVALUATION]: 3,
  [CaseStatus.PASSED]: 4,
};

/** Arbitrary for a CaseStatus value. */
const caseStatusArb = fc.constantFrom(...allStatuses);

/** Arbitrary for a non-empty test case name (used in sorting). */
const nameArb = fc.string({ minLength: 1, maxLength: 60 });

/** Arbitrary for a tool name string. */
const toolNameArb = fc.string({ minLength: 1, maxLength: 40 }).filter((s) => s.trim().length > 0);

/** Arbitrary for a SortableResult. */
const sortableResultArb: fc.Arbitrary<SortableResult> = fc.record({
  status: caseStatusArb,
  name: nameArb,
});

/** Arbitrary for a FilterableResult. */
const filterableResultArb: fc.Arbitrary<FilterableResult> = fc.record({
  status: caseStatusArb,
  toolsInvoked: fc.array(toolNameArb, { minLength: 0, maxLength: 5 }),
});

// ---------------------------------------------------------------------------
// Property 9: Results Sorting by Status Priority
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 10.3, 10.5**
 *
 * Property 9: Results sorting by status priority
 * For any set of test results, the sorted output places all "error" status
 * results first, then "timed_out", then "failed", then "passed", with results
 * within each status group sorted alphabetically by test case name
 * (case-insensitive).
 */
describe("Feature: connect-agent-test-platform, Property 9: Results sorting by status priority", () => {
  it("adjacent pairs satisfy the ordering invariant: higher-or-equal priority, then alphabetical", () => {
    fc.assert(
      fc.property(
        fc.array(sortableResultArb, { minLength: 0, maxLength: 50 }),
        (results) => {
          const sorted = sortResults(results);

          // Length is preserved
          expect(sorted).toHaveLength(results.length);

          // Check adjacent pair invariant
          for (let i = 0; i < sorted.length - 1; i++) {
            const a = sorted[i];
            const b = sorted[i + 1];
            const priA = STATUS_PRIORITY[a.status];
            const priB = STATUS_PRIORITY[b.status];

            if (priA === priB) {
              // Same status group → alphabetical (case-insensitive, non-strict)
              expect(
                a.name.toLowerCase().localeCompare(b.name.toLowerCase()),
              ).toBeLessThanOrEqual(0);
            } else {
              // Different status → higher priority (lower number) comes first
              expect(priA).toBeLessThan(priB);
            }
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("sorting is idempotent — sorting an already sorted array yields the same result", () => {
    fc.assert(
      fc.property(
        fc.array(sortableResultArb, { minLength: 0, maxLength: 50 }),
        (results) => {
          const sorted1 = sortResults(results);
          const sorted2 = sortResults(sorted1);
          expect(sorted2).toEqual(sorted1);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("does not mutate the input array", () => {
    fc.assert(
      fc.property(
        fc.array(sortableResultArb, { minLength: 1, maxLength: 30 }),
        (results) => {
          const snapshot = results.map((r) => ({ ...r }));
          sortResults(results);
          expect(results).toEqual(snapshot);
        },
      ),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 10: Results Filter Correctness
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 10.3, 10.5**
 *
 * Property 10: Results filter correctness
 * For any set of test results and a filter predicate (by status and/or by tool
 * invoked), the filtered output contains exactly those results that match all
 * applied filter criteria, and no results that fail to match.
 */
describe("Feature: connect-agent-test-platform, Property 10: Results filter correctness", () => {
  /** Arbitrary for filter criteria that can contain status filter and/or tool filter. */
  const filterCriteriaArb: fc.Arbitrary<FilterCriteria> = fc.record({
    status: fc.option(
      fc.uniqueArray(caseStatusArb, { minLength: 1, maxLength: 4 }),
      { nil: undefined },
    ),
    toolInvoked: fc.option(toolNameArb, { nil: undefined }),
  });

  /** Determines whether a result matches a given criteria (reference implementation). */
  function matchesCriteria(result: FilterableResult, criteria: FilterCriteria): boolean {
    if (criteria.status && criteria.status.length > 0) {
      if (!criteria.status.includes(result.status)) {
        return false;
      }
    }
    if (criteria.toolInvoked) {
      const toolLower = criteria.toolInvoked.toLowerCase();
      if (!result.toolsInvoked.some((t) => t.toLowerCase() === toolLower)) {
        return false;
      }
    }
    return true;
  }

  it("every item in the filtered output matches the filter criteria", () => {
    fc.assert(
      fc.property(
        fc.array(filterableResultArb, { minLength: 0, maxLength: 50 }),
        filterCriteriaArb,
        (results, criteria) => {
          const filtered = filterResults(results, criteria);

          for (const item of filtered) {
            expect(matchesCriteria(item, criteria)).toBe(true);
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("every item NOT in the filtered output fails to match the filter criteria", () => {
    fc.assert(
      fc.property(
        fc.array(filterableResultArb, { minLength: 0, maxLength: 50 }),
        filterCriteriaArb,
        (results, criteria) => {
          const filtered = filterResults(results, criteria);
          const excluded = results.filter((r) => !filtered.includes(r));

          for (const item of excluded) {
            expect(matchesCriteria(item, criteria)).toBe(false);
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("filtered output length equals count of matching items in input", () => {
    fc.assert(
      fc.property(
        fc.array(filterableResultArb, { minLength: 0, maxLength: 50 }),
        filterCriteriaArb,
        (results, criteria) => {
          const filtered = filterResults(results, criteria);
          const expectedCount = results.filter((r) => matchesCriteria(r, criteria)).length;
          expect(filtered).toHaveLength(expectedCount);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("with empty/undefined criteria, all results are returned", () => {
    fc.assert(
      fc.property(
        fc.array(filterableResultArb, { minLength: 0, maxLength: 30 }),
        (results) => {
          const withUndefined = filterResults(results, undefined);
          const withEmpty = filterResults(results, {});
          expect(withUndefined).toHaveLength(results.length);
          expect(withEmpty).toHaveLength(results.length);
        },
      ),
      { numRuns: 100 },
    );
  });
});
