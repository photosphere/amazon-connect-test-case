export { apiClient, ApiClientError, RuntimeConfigUnavailableError } from './client';
export type { ApiError } from './client';
export { loadConfig, getConfig, getConfigStatus } from './config';
export type {
  RuntimeConfig,
  RuntimeConfigError,
  RuntimeConfigErrorCode,
  RuntimeConfigStatus,
} from './config';
export { subscribeToNotifications, notifyError } from './notifications';
export type { ApiNotification } from './notifications';

export {
  PromptApiError,
  listPrompts,
  getPrompt,
  updatePrompt,
  resetPrompt,
  getHistory,
  getActiveRuns,
} from './prompts';
export type {
  PromptErrorCode,
  PromptListItem,
  AllowedModelEntry,
  HistoryEntry,
  ListPromptsResponse,
  GetPromptResponse,
  UpdatePromptRequest,
  UpdatePromptResponse,
  ResetPromptResponse,
  GetHistoryResponse,
  ActiveRunsResponse,
} from './prompts';

export {
  fetchRecommendations,
  applyRecommendations,
  createExperiment,
  getExperiment,
  applyVariant,
  listExperiments,
  revertApply,
  getApplyStatus,
} from './recommendations';
export type {
  FetchRecommendationsResponse,
  ListExperimentsResponse,
} from './recommendations';

// Re-export the shared registry literal-union types the prompt-management
// frontend components consume. Importing them through the API barrel
// keeps consumers (`components/Prompts/*`, `pages/Prompt*`) decoupled
// from the shared-source layout — they only need to know the API
// surface, not the on-disk path to `shared/types.ts`.
export type {
  ModelKey,
  PromptKey,
  Placeholder,
  InferenceParameterSchema,
} from '../../../shared/types';

// Re-export shared types consumed by the implement-recommendations
// frontend components through the API barrel (same decoupling pattern).
export type {
  ApplyRecommendationsResponse,
  ExperimentCreateResponse,
  ExperimentRecord,
  ExperimentStatus,
  PerSuiteRecommendation,
  Recommendation,
  DriftedField,
} from '../../../shared/types';
