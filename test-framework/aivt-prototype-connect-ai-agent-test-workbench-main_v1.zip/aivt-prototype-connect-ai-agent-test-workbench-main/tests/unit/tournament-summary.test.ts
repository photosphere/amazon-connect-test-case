/**
 * Unit tests for the Tournament Summary module.
 *
 * Tests the deterministic computation of:
 * - Per-variant highlights (improved/regressed cases)
 * - Winning variant selection (pass rate + tiebreaks)
 * - Bedrock summary generation with graceful degradation on failure
 * - Correct Bedrock Converse configuration sourced from the
 *   `tournament_summary` registry entry (Wave 2 — Task 17.5)
 *
 * The tournament summary generator resolves its prompt via
 * `resolvePromptForRun(...)` per the Wave-2 migration of the
 * prompt-management spec. These tests inject a stub Prompts_Store via
 * `_setPromptStore` so the resolver returns the registry's bundled
 * defaults without touching DynamoDB. Same pattern as
 * `tests/unit/variant-generator.test.ts` and
 * `tests/unit/customer-simulator.test.ts`.
 */

import { describe, it, expect, vi, afterEach, beforeEach } from "vitest";
import {
  generateTournamentSummary,
  _setBedrockClient,
  type TournamentSummaryInput,
} from "@backend/orchestration/tournament-summary";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "@backend/orchestration/prompt-registry/runtime";
import { PROMPT_REGISTRY } from "@backend/orchestration/prompt-registry";
import type { DynamoDBService } from "@backend/services/dynamodb";
import { CaseStatus } from "@shared/enums";
import type { TestCaseResult, VariantConfig } from "@shared/types";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const RUN_ID = "run-tournament-summary-test";

function makeResult(
  caseId: string,
  status: CaseStatus,
  opts?: {
    goalSuccessScore?: number;
    helpfulnessScore?: number;
    toolAccuracyScore?: number;
  }
): TestCaseResult {
  return {
    runId: "run-1",
    caseId,
    status,
    toolsInvoked: [],
    turnCount: 1,
    latencyMs: 100,
    goalSuccessScore: opts?.goalSuccessScore,
    helpfulnessScore: opts?.helpfulnessScore,
    toolAccuracyScore: opts?.toolAccuracyScore,
  };
}

function makeMockBedrockClient(responseText: string) {
  return {
    send: vi.fn().mockResolvedValue({
      output: {
        message: {
          content: [{ text: responseText }],
        },
      },
    }),
  };
}

function makeMockBedrockClientThatThrows(error: Error) {
  return {
    send: vi.fn().mockRejectedValue(error),
  };
}

const baseVariantConfigs: VariantConfig[] = [
  { variantLetter: "A", strategy: "conciseness", recommendations: [] },
  { variantLetter: "B", strategy: "example-heavy", recommendations: [] },
  { variantLetter: "C", strategy: "restructured", recommendations: [] },
];

/**
 * Inject a stub Prompts_Store so `resolvePromptForRun("tournament_summary", ...)`
 * returns the registry's bundled defaults without touching DynamoDB.
 *
 * The tournament summary generator uses `resolvePromptForRun`, which
 * reads the run snapshot first and falls back to the live registry. We
 * wire `getSnapshot` to return null so the resolver always traverses
 * the live-registry fallback path, then return an empty overrides map
 * so the resolver yields the bundled `tournament_summary` definition
 * (Claude Sonnet 4.6, default text, default inference values).
 */
function injectDefaultPromptStore(): void {
  _clearPromptRegistryCaches();
  const store = {
    getSnapshot: vi.fn().mockResolvedValue(null),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  } as unknown as DynamoDBService;
  _setPromptRegistryStore(store);
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("generateTournamentSummary", () => {
  beforeEach(() => {
    _setBedrockClient(null);
    injectDefaultPromptStore();
  });

  afterEach(() => {
    _setBedrockClient(null);
    _setPromptRegistryStore(null);
    _clearPromptRegistryCaches();
  });

  it("selects the winning variant deterministically based on pass rate", async () => {
    _setBedrockClient(makeMockBedrockClient("Variant B performed best."));

    const input: TournamentSummaryInput = {
      runId: RUN_ID,
      baselineResults: [
        makeResult("case-1", CaseStatus.FAILED),
        makeResult("case-2", CaseStatus.PASSED),
      ],
      variantResults: {
        A: [
          makeResult("case-1", CaseStatus.PASSED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
        B: [
          makeResult("case-1", CaseStatus.PASSED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
        C: [
          makeResult("case-1", CaseStatus.FAILED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
      },
      variantConfigs: baseVariantConfigs,
    };

    const result = await generateTournamentSummary(input);

    // A and B both 100% pass rate, tie broken by goalSuccessScore — both 0 here
    // so first in sort order (A) wins
    expect(result.winningVariant).toBe("A");
    expect(result.summary).toBe("Variant B performed best.");
  });

  it("breaks ties by avgGoalSuccessScore", async () => {
    _setBedrockClient(makeMockBedrockClient("Variant C won due to higher goal success."));

    const input: TournamentSummaryInput = {
      runId: RUN_ID,
      baselineResults: [
        makeResult("case-1", CaseStatus.PASSED, { goalSuccessScore: 0.5 }),
        makeResult("case-2", CaseStatus.PASSED, { goalSuccessScore: 0.5 }),
      ],
      variantResults: {
        A: [
          makeResult("case-1", CaseStatus.PASSED, { goalSuccessScore: 0.6 }),
          makeResult("case-2", CaseStatus.PASSED, { goalSuccessScore: 0.6 }),
        ],
        B: [
          makeResult("case-1", CaseStatus.PASSED, { goalSuccessScore: 0.7 }),
          makeResult("case-2", CaseStatus.PASSED, { goalSuccessScore: 0.7 }),
        ],
        C: [
          makeResult("case-1", CaseStatus.PASSED, { goalSuccessScore: 0.9 }),
          makeResult("case-2", CaseStatus.PASSED, { goalSuccessScore: 0.9 }),
        ],
      },
      variantConfigs: baseVariantConfigs,
    };

    const result = await generateTournamentSummary(input);

    // All 100% pass rate, C has highest avgGoalSuccessScore (0.9)
    expect(result.winningVariant).toBe("C");
  });

  it("computes per-variant highlights (improved/regressed)", async () => {
    _setBedrockClient(makeMockBedrockClient("Summary text."));

    const input: TournamentSummaryInput = {
      runId: RUN_ID,
      baselineResults: [
        makeResult("case-1", CaseStatus.FAILED),
        makeResult("case-2", CaseStatus.PASSED),
        makeResult("case-3", CaseStatus.FAILED),
      ],
      variantResults: {
        A: [
          makeResult("case-1", CaseStatus.PASSED), // improved
          makeResult("case-2", CaseStatus.FAILED), // regressed
          makeResult("case-3", CaseStatus.FAILED), // unchanged
        ],
        B: [
          makeResult("case-1", CaseStatus.PASSED), // improved
          makeResult("case-2", CaseStatus.PASSED), // unchanged
          makeResult("case-3", CaseStatus.PASSED), // improved
        ],
        C: [
          makeResult("case-1", CaseStatus.FAILED), // unchanged
          makeResult("case-2", CaseStatus.PASSED), // unchanged
          makeResult("case-3", CaseStatus.FAILED), // unchanged
        ],
      },
      variantConfigs: baseVariantConfigs,
    };

    const result = await generateTournamentSummary(input);

    expect(result.perVariantHighlights.A.improved).toEqual(["case-1"]);
    expect(result.perVariantHighlights.A.regressed).toEqual(["case-2"]);
    expect(result.perVariantHighlights.B.improved).toEqual(["case-1", "case-3"]);
    expect(result.perVariantHighlights.B.regressed).toEqual([]);
    expect(result.perVariantHighlights.C.improved).toEqual([]);
    expect(result.perVariantHighlights.C.regressed).toEqual([]);
  });

  it("returns null winningVariant when all variants have empty results", async () => {
    _setBedrockClient(makeMockBedrockClient("No winner could be determined."));

    const input: TournamentSummaryInput = {
      runId: RUN_ID,
      baselineResults: [makeResult("case-1", CaseStatus.PASSED)],
      variantResults: {
        A: [],
        B: [],
        C: [],
      },
      variantConfigs: baseVariantConfigs,
    };

    const result = await generateTournamentSummary(input);

    expect(result.winningVariant).toBeNull();
  });

  it("returns fallback summary when Bedrock call fails", async () => {
    _setBedrockClient(
      makeMockBedrockClientThatThrows(new Error("Bedrock service unavailable"))
    );

    const input: TournamentSummaryInput = {
      runId: RUN_ID,
      baselineResults: [
        makeResult("case-1", CaseStatus.FAILED),
        makeResult("case-2", CaseStatus.PASSED),
      ],
      variantResults: {
        A: [
          makeResult("case-1", CaseStatus.PASSED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
        B: [
          makeResult("case-1", CaseStatus.FAILED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
        C: [
          makeResult("case-1", CaseStatus.FAILED),
          makeResult("case-2", CaseStatus.FAILED),
        ],
      },
      variantConfigs: baseVariantConfigs,
    };

    const result = await generateTournamentSummary(input);

    // Deterministic results still computed correctly
    expect(result.winningVariant).toBe("A");
    expect(result.summary).toBe(
      "Summary generation failed. See quantitative results above."
    );
    // Highlights still computed
    expect(result.perVariantHighlights.A.improved).toEqual(["case-1"]);
    expect(result.perVariantHighlights.A.regressed).toEqual([]);
  });

  it("handles cases only present in baseline (not in variant)", async () => {
    _setBedrockClient(makeMockBedrockClient("Summary."));

    const input: TournamentSummaryInput = {
      runId: RUN_ID,
      baselineResults: [
        makeResult("case-1", CaseStatus.PASSED),
        makeResult("case-2", CaseStatus.FAILED),
        makeResult("case-extra", CaseStatus.PASSED), // not in variants
      ],
      variantResults: {
        A: [
          makeResult("case-1", CaseStatus.PASSED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
        B: [
          makeResult("case-1", CaseStatus.PASSED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
        C: [
          makeResult("case-1", CaseStatus.PASSED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
      },
      variantConfigs: baseVariantConfigs,
    };

    const result = await generateTournamentSummary(input);

    // case-extra is not in any variant, so it shouldn't appear in highlights
    expect(result.perVariantHighlights.A.improved).toEqual(["case-2"]);
    expect(result.perVariantHighlights.A.regressed).toEqual([]);
  });

  it("uses the AI-generated summary from Bedrock response", async () => {
    const expectedSummary =
      "Variant B achieved 100% pass rate compared to 50% baseline, fixing case-1 without regressions.";
    _setBedrockClient(makeMockBedrockClient(expectedSummary));

    const input: TournamentSummaryInput = {
      runId: RUN_ID,
      baselineResults: [
        makeResult("case-1", CaseStatus.FAILED),
        makeResult("case-2", CaseStatus.PASSED),
      ],
      variantResults: {
        A: [
          makeResult("case-1", CaseStatus.FAILED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
        B: [
          makeResult("case-1", CaseStatus.PASSED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
        C: [
          makeResult("case-1", CaseStatus.FAILED),
          makeResult("case-2", CaseStatus.PASSED),
        ],
      },
      variantConfigs: baseVariantConfigs,
    };

    const result = await generateTournamentSummary(input);

    expect(result.summary).toBe(expectedSummary);
    expect(result.winningVariant).toBe("B");
  });

  // ---------------------------------------------------------------------
  // Wave-2 migration assertions (Task 17.5).
  // ---------------------------------------------------------------------

  it("calls Bedrock with the registry-resolved Converse shape (Anthropic 4.x: maxTokens only, no temperature)", async () => {
    const mock = makeMockBedrockClient("Variant A wins.");
    _setBedrockClient(mock);

    const input: TournamentSummaryInput = {
      runId: RUN_ID,
      baselineResults: [makeResult("case-1", CaseStatus.FAILED)],
      variantResults: {
        A: [makeResult("case-1", CaseStatus.PASSED)],
        B: [makeResult("case-1", CaseStatus.FAILED)],
        C: [makeResult("case-1", CaseStatus.FAILED)],
      },
      variantConfigs: baseVariantConfigs,
    };

    await generateTournamentSummary(input);

    expect(mock.send).toHaveBeenCalledTimes(1);
    const command = mock.send.mock.calls[0][0];
    const cmdInput = command.input;

    // The registry's bundled `tournament_summary` default points at the
    // `claude_sonnet_4_6` model whose capability profile is
    // `anthropic_claude_4x` — so `buildInferenceConfig` emits exactly
    // `{ inferenceConfig: { maxTokens: <default> } }` with no
    // `temperature`, `topP`, `topK`, or `stopSequences`. The Anthropic
    // 4.x profile forbids those keys per R17.4. This explicit assertion
    // catches any future regression that silently switches the default
    // model and lets `temperature` slip onto the wire (the orphan
    // legacy literal `"us.anthropic.claude-sonnet-4-20250514-v1:0"`
    // with `temperature: 0` was retired by Task 17.5).
    const definition = PROMPT_REGISTRY.tournament_summary;
    expect(cmdInput.inferenceConfig.maxTokens).toBe(
      definition.defaultInferenceValues.maxTokens,
    );
    expect(cmdInput.inferenceConfig.temperature).toBeUndefined();
    expect(cmdInput.inferenceConfig.topP).toBeUndefined();
    expect(cmdInput.additionalModelRequestFields).toBeUndefined();

    // Verify the modelId comes from the registry's resolved
    // SupportedModel entry, not from a hard-coded literal or env var.
    expect(cmdInput.modelId).toMatch(/^us\.anthropic\.claude-sonnet/);

    // Verify the system prompt was rendered from the registry's
    // bundled default text — the orphan legacy literal in
    // `tournament-summary.ts` was deleted by Task 17.5.
    const systemText = cmdInput.system?.[0]?.text ?? "";
    expect(systemText).toContain("expert test results analyst");
    expect(systemText).toBe(definition.defaultText);
  });

  it("does not read process.env.BEDROCK_MODEL_ID (registry is the source of truth)", () => {
    // The Wave-2 migration removed the `process.env.*_MODEL_ID ?? "..."`
    // fallback (and the orphan `claude-sonnet-4-20250514-v1:0` default)
    // from the source. The static AST allow-list test
    // (`tests/properties/prompts-registry-only-resolution.property.test.ts`)
    // pins this at the source-tree level, but we also assert it here
    // as a fast feedback signal — same regression-guard pattern as
    // `tests/unit/variant-generator.test.ts`.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const fs = require("node:fs");
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const path = require("node:path");
    const sourcePath = path.resolve(
      __dirname,
      "..",
      "..",
      "src/backend/orchestration/tournament-summary.ts",
    );
    const source = fs.readFileSync(sourcePath, "utf8");
    expect(source).not.toMatch(
      /process\.env\.[A-Z][A-Z0-9_]*_MODEL_ID\s*\?\?/,
    );
    // The orphan legacy default is gone too.
    expect(source).not.toContain("claude-sonnet-4-20250514-v1:0");
  });

  it("calls resolvePromptForRun with tournament_summary and the supplied runId (snapshot path)", async () => {
    // Inject a snapshot that pins tournament_summary so the resolver
    // takes the snapshot-first path. Verifies the runId is plumbed
    // through to the resolver and the snapshot triple wins.
    _clearPromptRegistryCaches();
    const definition = PROMPT_REGISTRY.tournament_summary;
    const snapshotPrompts = {
      tournament_summary: {
        text: definition.defaultText,
        modelKey: definition.defaultModelKey,
        modelId: "us.anthropic.claude-sonnet-4-6",
        inferenceParameters: definition.defaultInferenceValues,
        version: 0,
        capabilityProfileKey: "anthropic_claude_4x_lax" as const,
      },
    };
    const getSnapshot = vi.fn().mockResolvedValue({
      prompts: snapshotPrompts,
    });
    const listPromptOverrides = vi.fn();
    const store = {
      getSnapshot,
      listPromptOverrides,
    } as unknown as DynamoDBService;
    _setPromptRegistryStore(store);

    const mock = makeMockBedrockClient("Snapshot-resolved summary.");
    _setBedrockClient(mock);

    const customRunId = "run-snapshot-path-tournament";
    const input: TournamentSummaryInput = {
      runId: customRunId,
      baselineResults: [makeResult("case-1", CaseStatus.FAILED)],
      variantResults: {
        A: [makeResult("case-1", CaseStatus.PASSED)],
        B: [makeResult("case-1", CaseStatus.FAILED)],
        C: [makeResult("case-1", CaseStatus.FAILED)],
      },
      variantConfigs: baseVariantConfigs,
    };

    const result = await generateTournamentSummary(input);

    expect(result.winningVariant).toBe("A");
    expect(result.summary).toBe("Snapshot-resolved summary.");
    // Snapshot path consulted with the supplied runId.
    expect(getSnapshot).toHaveBeenCalledWith(customRunId);
    // Live store NOT consulted because the snapshot pinned the prompt.
    expect(listPromptOverrides).not.toHaveBeenCalled();
  });
});
