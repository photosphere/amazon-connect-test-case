/**
 * Property 5: Model_Capability_Profile compliance.
 *
 * For any `(promptKey, modelKey)` pair the resolver could return — both
 * pairs where `modelKey` is the prompt's bundled default and pairs where
 * it is a persisted override — the **wire-shape output** of the
 * `(resolvePrompt → buildInferenceConfig)` pipeline must be compliant
 * with the resolved model's capability profile:
 *
 *   1. Top-level `inferenceConfig` keys ⊆ `capabilityProfile.acceptsTopLevel`.
 *   2. Additional `additionalModelRequestFields.inferenceConfig` keys ⊆
 *      `capabilityProfile.acceptsAdditional`.
 *   3. The union of both bucket key sets is disjoint from
 *      `capabilityProfile.forbids` (no forbidden key ever reaches the wire).
 *
 * The property is asserted at the `buildInferenceConfig` boundary rather
 * than at the resolver boundary because the resolver returns the persisted
 * `inferenceParameters` map verbatim — the design intentionally allows a
 * Prompt's schema to declare keys (e.g. `temperature`, `topP` on
 * `customer_simulator` and `variant_generation`) that some models in the
 * prompt's `allowedModels[]` forbid (e.g. Anthropic Claude 4.x). The
 * validation pipeline drops those at edit time per R10.4, and the
 * `buildInferenceConfig` helper drops them silently at request-build time
 * — both layers conspire to produce a compliant wire shape regardless of
 * what the input schema declares. This test pins that downstream
 * invariant: whatever the resolver returns, the request that goes on the
 * wire is profile-compliant.
 *
 * Two scenarios are exercised:
 *
 *   - **Bundled-default case.** No override is in effect. The resolver
 *     returns the prompt's `defaultInferenceValues` and the prompt's
 *     `defaultModelKey`. Iterating over every `(promptKey, modelKey)` in
 *     the catalog where `modelKey ∈ allowedModels[]` covers every
 *     resolvable default-state pair.
 *
 *   - **Persisted-override case.** A sparse override is materialised
 *     in-memory (mirroring the Prompts_Store row shape) carrying a
 *     generated `inferenceParameters` body that is itself valid for the
 *     `(prompt, model)` pair per `validInferenceParametersArb`. The
 *     resolver merges-then-returns it and `buildInferenceConfig` shapes it
 *     into the wire form. Even though the generator produces compliant
 *     bodies (the validation pipeline would too), this still exercises
 *     the "override-with-arbitrary-allowed-key-subset" branch and pins
 *     the wire-shape invariant under that path.
 *
 * The bundled-default arm of this test catches the cross-profile
 * carry-over case the design specifically calls out: `customer_simulator`
 * and `variant_generation` declare `temperature` and `topP` in their
 * default inference values, but their `allowedModels[]` includes Anthropic
 * Claude models whose profile forbids both keys. When the resolver
 * surfaces the bundled default for those (prompt, anthropic_model) pairs,
 * `buildInferenceConfig` must drop the forbidden keys — and this test
 * fails immediately if the helper ever stops doing so.
 *
 * Generators are the shared `promptKeyArb`, `validInferenceParametersArb`
 * (and `validTextArb` for the persisted-override case) from
 * `tests/properties/generators.ts`; no new arbitraries land here.
 *
 * **Validates: Requirements 15.5, 17.4**
 */

import fc from "fast-check";
import { describe, expect, it } from "vitest";

import {
  buildInferenceConfig,
  CAPABILITY_PROFILES,
  PROMPT_REGISTRY,
  resolvePrompt,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";
import type {
  ModelCapabilityProfile,
  ModelKey,
  PromptKey,
  PromptOverride,
} from "../../src/backend/orchestration/prompt-registry";

import {
  promptKeyArb,
  validInferenceParametersArb,
  validTextArb,
} from "./generators";

// ---------------------------------------------------------------------------
// Compliance assertion helper
//
// Centralises the three-clause check so failure messages name the
// offending (promptKey, modelKey, bucket, key) tuple. Pulled out of the
// per-scenario test bodies so the bundled-default loop and the
// fast-check property below report failures in the same shape.
// ---------------------------------------------------------------------------

function expectCompliantWireShape(
  promptKey: PromptKey,
  modelKey: ModelKey,
  profile: ModelCapabilityProfile,
  built: ReturnType<typeof buildInferenceConfig>,
): void {
  const acceptedTopLevel = new Set<string>(profile.acceptsTopLevel);
  const acceptedAdditional = new Set<string>(profile.acceptsAdditional);
  const forbidden = new Set<string>(profile.forbids);

  // Clause 1: top-level inferenceConfig keys ⊆ acceptsTopLevel.
  for (const key of Object.keys(built.inferenceConfig)) {
    expect(
      acceptedTopLevel.has(key),
      `[${promptKey} → ${modelKey} (${profile.key})] top-level inferenceConfig key "${key}" is not in acceptsTopLevel [${profile.acceptsTopLevel.join(", ")}]`,
    ).toBe(true);

    // Clause 3a: top-level keys must not be in `forbids`.
    expect(
      forbidden.has(key),
      `[${promptKey} → ${modelKey} (${profile.key})] top-level inferenceConfig key "${key}" appears in forbids [${profile.forbids.join(", ")}]`,
    ).toBe(false);
  }

  // Clauses 2 & 3b apply only when the helper emitted an additional bucket.
  if (built.additionalModelRequestFields !== undefined) {
    const additionalKeys = Object.keys(
      built.additionalModelRequestFields.inferenceConfig,
    );

    // Helper contract: when present, the additional bucket carries at
    // least one key. An empty additional bucket would still satisfy
    // Clause 2 trivially, but its presence with no keys would be a bug
    // in the helper rather than a compliance violation; we therefore
    // assert the bucket is non-empty so a regression in the helper's
    // omit-when-empty behaviour surfaces here too.
    expect(
      additionalKeys.length > 0,
      `[${promptKey} → ${modelKey} (${profile.key})] buildInferenceConfig emitted an empty additionalModelRequestFields bucket; the helper should omit it entirely when no additional keys are present`,
    ).toBe(true);

    for (const key of additionalKeys) {
      // Clause 2: additional inferenceConfig keys ⊆ acceptsAdditional.
      expect(
        acceptedAdditional.has(key),
        `[${promptKey} → ${modelKey} (${profile.key})] additional inferenceConfig key "${key}" is not in acceptsAdditional [${profile.acceptsAdditional.join(", ")}]`,
      ).toBe(true);

      // Clause 3b: additional keys must not be in `forbids`.
      expect(
        forbidden.has(key),
        `[${promptKey} → ${modelKey} (${profile.key})] additional inferenceConfig key "${key}" appears in forbids [${profile.forbids.join(", ")}]`,
      ).toBe(false);
    }
  }
}

// ---------------------------------------------------------------------------
// 1. Bundled-default case — every resolvable (promptKey, modelKey) pair
//    where modelKey ∈ allowedModels[] is exercised with no override in
//    effect. The resolver returns the prompt's `defaultInferenceValues`
//    and the chosen model; `buildInferenceConfig` must produce a
//    compliant wire shape.
//
//    To exercise the modelKey degree of freedom (the resolver only
//    surfaces `defaultModelKey` when no override is in effect), we
//    construct a sparse override that carries ONLY `modelKey` — no
//    `text`, no `inferenceParameters`. The default-fallback invariant
//    (R10.1) means the resolver still uses `defaultText` and
//    `defaultInferenceValues`, but with the chosen `modelKey`. This
//    covers every (promptKey, allowedModelKey) pair the resolver could
//    surface for a bundled-defaults inferenceParameters body.
// ---------------------------------------------------------------------------

describe("Property 5 — Capability-profile compliance (bundled defaults)", () => {
  const promptKeys = Object.keys(PROMPT_REGISTRY) as PromptKey[];

  // Build the cross-product of (promptKey, modelKey) pairs eagerly so
  // vitest's `it.each` can name each case in the test report. This
  // surfaces the offending pair in the test name even before the
  // assertion message fires.
  const cases: Array<[PromptKey, ModelKey]> = [];
  for (const promptKey of promptKeys) {
    for (const modelKey of PROMPT_REGISTRY[promptKey].allowedModels) {
      cases.push([promptKey, modelKey]);
    }
  }

  it.each(cases)(
    "[%s → %s] buildInferenceConfig emits a profile-compliant wire shape over the bundled defaults",
    (promptKey, modelKey) => {
      // Sparse override carrying only modelKey — text and
      // inferenceParameters fall back to the registry defaults per the
      // resolver's default-fallback invariant.
      const overrides = new Map<PromptKey, PromptOverride>();
      overrides.set(promptKey, {
        promptKey,
        modelKey,
        version: 1,
        lastModifiedAt: "1970-01-01T00:00:00.000Z",
        lastModifiedBy: "property-test",
      });

      const resolved = resolvePrompt(promptKey, overrides);
      const profile =
        CAPABILITY_PROFILES[SUPPORTED_MODELS[modelKey].capabilityProfileKey];
      const built = buildInferenceConfig(resolved);

      expectCompliantWireShape(promptKey, modelKey, profile, built);
    },
  );
});

// ---------------------------------------------------------------------------
// 2. Persisted-override case — fast-check property over arbitrary
//    (promptKey, modelKey, validText, validInferenceParameters) tuples.
//    The validInferenceParametersArb generator already filters out keys
//    forbidden by the resolved model's profile, so each iteration tests
//    that valid override bodies survive the resolver-then-helper
//    pipeline without the helper accidentally introducing a forbidden
//    key.
//
//    R15.6 requires ≥ 100 iterations; we run 150 to leave headroom for
//    fast-check's shrinker without inflating CI runtime — every
//    iteration is one in-memory `resolvePrompt` + one `buildInferenceConfig`,
//    both of which are pure and run in microseconds.
// ---------------------------------------------------------------------------

describe("Property 5 — Capability-profile compliance (persisted overrides)", () => {
  it("for any (promptKey, modelKey, validText, validInferenceParameters) tuple, the wire shape is profile-compliant", () => {
    fc.assert(
      fc.property(
        promptKeyArb.chain((promptKey) => {
          const prompt = PROMPT_REGISTRY[promptKey];
          return fc
            .constantFrom(...prompt.allowedModels)
            .chain((modelKey) => {
              const model = SUPPORTED_MODELS[modelKey];
              return fc
                .tuple(
                  validTextArb(prompt),
                  validInferenceParametersArb(prompt, model),
                )
                .map(([text, inferenceParameters]) => ({
                  promptKey,
                  modelKey,
                  text,
                  inferenceParameters,
                }));
            });
        }),
        ({ promptKey, modelKey, text, inferenceParameters }) => {
          const overrides = new Map<PromptKey, PromptOverride>();
          overrides.set(promptKey, {
            promptKey,
            text,
            modelKey,
            inferenceParameters,
            version: 1,
            lastModifiedAt: "1970-01-01T00:00:00.000Z",
            lastModifiedBy: "property-test",
          });

          const resolved = resolvePrompt(promptKey, overrides);
          const profile =
            CAPABILITY_PROFILES[
              SUPPORTED_MODELS[modelKey].capabilityProfileKey
            ];
          const built = buildInferenceConfig(resolved);

          expectCompliantWireShape(promptKey, modelKey, profile, built);
        },
      ),
      // R15.6: ≥ 100 iterations.
      { numRuns: 150 },
    );
  });
});

// ---------------------------------------------------------------------------
// 3. Targeted regression — `customer_simulator` and `variant_generation`
//    declare `temperature` (and `topP`) in their `defaultInferenceValues`,
//    and their `allowedModels[]` includes Anthropic Claude 4.x models
//    whose profile forbids both keys. The bundled-default `it.each`
//    above already covers these pairs, but pulling them out as a named
//    regression test makes the intent unmissable: this is the exact
//    case the design's "validation pipeline drops these at edit time per
//    R10.4 / the buildInferenceConfig helper drops them silently" note
//    refers to. If a future refactor accidentally lets `temperature`
//    bubble onto an Anthropic Converse request, this test names it.
// ---------------------------------------------------------------------------

describe("Property 5 — Capability-profile compliance (targeted regression)", () => {
  const cases: Array<[PromptKey, ModelKey]> = [
    ["customer_simulator", "claude_sonnet_4_6"],
    ["customer_simulator", "claude_haiku_4_5"],
    ["customer_simulator", "claude_opus_4_8"],
    ["variant_generation", "claude_sonnet_4_6"],
    ["variant_generation", "claude_haiku_4_5"],
    ["variant_generation", "claude_opus_4_8"],
  ];

  it.each(cases)(
    "[%s → %s] bundled defaults declare temperature/topP but the wire shape carries only maxTokens",
    (promptKey, modelKey) => {
      const overrides = new Map<PromptKey, PromptOverride>();
      overrides.set(promptKey, {
        promptKey,
        modelKey,
        version: 1,
        lastModifiedAt: "1970-01-01T00:00:00.000Z",
        lastModifiedBy: "property-test",
      });

      const resolved = resolvePrompt(promptKey, overrides);
      const built = buildInferenceConfig(resolved);

      // The resolver MUST surface `temperature` (or at least one
      // forbidden-by-anthropic key) in `inferenceParameters` so this
      // test is exercising the drop-at-helper path; a future refactor
      // that prunes the schema would silently turn this regression test
      // into a no-op without the assertion below.
      expect(
        Object.prototype.hasOwnProperty.call(
          resolved.inferenceParameters,
          "temperature",
        ),
        `[${promptKey}] expected the bundled defaultInferenceValues to declare a "temperature" key so this regression test exercises the drop-at-helper path`,
      ).toBe(true);

      // The wire shape must contain ONLY `maxTokens` for Anthropic
      // models — no `temperature`, no `topP`, no
      // `additionalModelRequestFields` bucket at all.
      expect(Object.keys(built.inferenceConfig).sort()).toEqual(["maxTokens"]);
      expect(built.additionalModelRequestFields).toBeUndefined();
    },
  );
});
