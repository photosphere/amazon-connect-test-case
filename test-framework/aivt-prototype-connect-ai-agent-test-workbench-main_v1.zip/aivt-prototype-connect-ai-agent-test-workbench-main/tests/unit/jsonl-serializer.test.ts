/**
 * Unit tests for the jsonl-serializer module.
 *
 * Covers:
 * - serializeRagCaseToJsonl: empty chunks, knowledgeBaseId derivation, multi-chunk verbatim
 * - assembleJsonlFile: \n joining, no blank lines, correct indexMap
 *
 * Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 11.1
 */

import { describe, it, expect } from "vitest";
import {
  serializeRagCaseToJsonl,
  assembleJsonlFile,
  type RagCaseInput,
} from "../../src/backend/orchestration/jsonl-serializer";

describe("serializeRagCaseToJsonl", () => {
  it("produces retrievalResults: [] when retrievedChunks is empty", () => {
    const input: RagCaseInput = {
      question: "What is the refund policy?",
      groundTruthAnswer: "You can get a refund within 30 days.",
      agentResponse: "Our refund policy allows returns within 30 days.",
      retrievedChunks: [],
      knowledgeBaseId: undefined,
      modelIdentifier: "us.anthropic.claude-sonnet-4-6",
    };

    const line = serializeRagCaseToJsonl(input);
    const parsed = JSON.parse(line);

    expect(parsed.conversationTurns[0].output.retrievedPassages.retrievalResults).toEqual([]);
  });

  it("uses sentinel knowledgeBaseIdentifier when no chunks have knowledgeBaseId", () => {
    const input: RagCaseInput = {
      question: "How do I reset my password?",
      groundTruthAnswer: "Go to settings and click reset.",
      agentResponse: "Navigate to your settings page.",
      retrievedChunks: [
        { text: "Password reset instructions...", index: 0 },
      ],
      knowledgeBaseId: undefined,
      modelIdentifier: "us.anthropic.claude-sonnet-4-6",
    };

    const line = serializeRagCaseToJsonl(input);
    const parsed = JSON.parse(line);

    expect(parsed.conversationTurns[0].output.knowledgeBaseIdentifier).toBe(
      "connect-orchestration-retrieve",
    );
  });

  it("derives knowledgeBaseIdentifier from first chunk with knowledgeBaseId", () => {
    const input: RagCaseInput = {
      question: "What are the fees?",
      groundTruthAnswer: "The fee is $5.",
      agentResponse: "There is a $5 fee.",
      retrievedChunks: [
        { text: "No KB id on this chunk", index: 0 },
        { text: "Chunk with KB id", knowledgeBaseId: "kb-abc-123", index: 1 },
        { text: "Another chunk with KB id", knowledgeBaseId: "kb-xyz-456", index: 2 },
      ],
      knowledgeBaseId: undefined,
      modelIdentifier: "us.anthropic.claude-sonnet-4-6",
    };

    const line = serializeRagCaseToJsonl(input);
    const parsed = JSON.parse(line);

    // Should use the first chunk that has a knowledgeBaseId
    expect(parsed.conversationTurns[0].output.knowledgeBaseIdentifier).toBe("kb-abc-123");
  });

  it("uses explicit knowledgeBaseId when provided, overriding chunk derivation", () => {
    const input: RagCaseInput = {
      question: "What are the fees?",
      groundTruthAnswer: "The fee is $5.",
      agentResponse: "There is a $5 fee.",
      retrievedChunks: [
        { text: "Chunk text", knowledgeBaseId: "kb-from-chunk", index: 0 },
      ],
      knowledgeBaseId: "kb-explicit-override",
      modelIdentifier: "us.anthropic.claude-sonnet-4-6",
    };

    const line = serializeRagCaseToJsonl(input);
    const parsed = JSON.parse(line);

    expect(parsed.conversationTurns[0].output.knowledgeBaseIdentifier).toBe("kb-explicit-override");
  });

  it("preserves all chunk texts verbatim in a multi-chunk case", () => {
    const chunkTexts = [
      "First chunk with special chars: <>&\"'\n\ttab",
      "Second chunk with unicode: café ñ 🎉",
      "Third chunk\nwith newlines\nand   spaces",
    ];

    const input: RagCaseInput = {
      question: "Tell me about the menu",
      groundTruthAnswer: "The menu has coffee and pastries.",
      agentResponse: "We serve café items.",
      retrievedChunks: chunkTexts.map((text, i) => ({
        text,
        index: i,
        knowledgeBaseId: "kb-1",
      })),
      knowledgeBaseId: undefined,
      modelIdentifier: "us.anthropic.claude-sonnet-4-6",
    };

    const line = serializeRagCaseToJsonl(input);
    const parsed = JSON.parse(line);

    const results = parsed.conversationTurns[0].output.retrievedPassages.retrievalResults;
    expect(results).toHaveLength(3);
    expect(results[0].content.text).toBe(chunkTexts[0]);
    expect(results[1].content.text).toBe(chunkTexts[1]);
    expect(results[2].content.text).toBe(chunkTexts[2]);
  });

  it("preserves question, groundTruthAnswer, and agentResponse verbatim", () => {
    const input: RagCaseInput = {
      question: "Question with \"quotes\" and\nnewlines",
      groundTruthAnswer: "Answer with\ttabs and\r\nCRLF",
      agentResponse: "Response with <html> & special © chars",
      retrievedChunks: [],
      knowledgeBaseId: undefined,
      modelIdentifier: "model-id",
    };

    const line = serializeRagCaseToJsonl(input);
    const parsed = JSON.parse(line);

    const turn = parsed.conversationTurns[0];
    expect(turn.prompt.content[0].text).toBe(input.question);
    expect(turn.referenceResponses[0].content[0].text).toBe(input.groundTruthAnswer);
    expect(turn.output.text).toBe(input.agentResponse);
  });

  it("produces a single-line JSON string (no embedded unescaped newlines)", () => {
    const input: RagCaseInput = {
      question: "Test\nwith\nnewlines",
      groundTruthAnswer: "Answer\nwith\nnewlines",
      agentResponse: "Response\nwith\nnewlines",
      retrievedChunks: [{ text: "Chunk\nwith\nnewlines", index: 0 }],
      knowledgeBaseId: undefined,
      modelIdentifier: "model-id",
    };

    const line = serializeRagCaseToJsonl(input);

    // The serialized line should not contain actual newline characters
    // (they should be escaped as \n in JSON)
    expect(line).not.toContain("\n");
    // But when parsed, the values should contain the original newlines
    const parsed = JSON.parse(line);
    expect(parsed.conversationTurns[0].prompt.content[0].text).toContain("\n");
  });

  it("includes chunk title as name and metadata when present", () => {
    const input: RagCaseInput = {
      question: "Q",
      groundTruthAnswer: "A",
      agentResponse: "R",
      retrievedChunks: [
        {
          text: "chunk text",
          title: "FAQ Section",
          knowledgeBaseId: "kb-1",
          contentId: "content-42",
          index: 0,
        },
      ],
      knowledgeBaseId: undefined,
      modelIdentifier: "model-id",
    };

    const line = serializeRagCaseToJsonl(input);
    const parsed = JSON.parse(line);

    const result = parsed.conversationTurns[0].output.retrievedPassages.retrievalResults[0];
    expect(result.name).toBe("FAQ Section");
    expect(result.metadata.knowledgeBaseId).toBe("kb-1");
    expect(result.metadata.contentId).toBe("content-42");
  });

  it("omits name and metadata fields when chunk has no title/contentId/knowledgeBaseId", () => {
    const input: RagCaseInput = {
      question: "Q",
      groundTruthAnswer: "A",
      agentResponse: "R",
      retrievedChunks: [{ text: "bare chunk", index: 0 }],
      knowledgeBaseId: "kb-explicit",
      modelIdentifier: "model-id",
    };

    const line = serializeRagCaseToJsonl(input);
    const parsed = JSON.parse(line);

    const result = parsed.conversationTurns[0].output.retrievedPassages.retrievalResults[0];
    expect(result.name).toBeUndefined();
    expect(result.metadata).toBeUndefined();
  });
});

describe("assembleJsonlFile", () => {
  it("joins lines with newline, no blank lines, and builds correct indexMap", () => {
    const cases = [
      { caseId: "case-1", line: '{"conversationTurns":[{"prompt":"q1"}]}' },
      { caseId: "case-2", line: '{"conversationTurns":[{"prompt":"q2"}]}' },
      { caseId: "case-3", line: '{"conversationTurns":[{"prompt":"q3"}]}' },
    ];

    const { body, indexMap } = assembleJsonlFile(cases);

    // Lines joined with \n
    const lines = body.split("\n");
    expect(lines).toHaveLength(3);
    expect(lines[0]).toBe(cases[0].line);
    expect(lines[1]).toBe(cases[1].line);
    expect(lines[2]).toBe(cases[2].line);

    // No leading or trailing blank lines
    expect(body).not.toMatch(/^\n/);
    expect(body).not.toMatch(/\n$/);

    // Correct indexMap
    expect(indexMap).toEqual({
      0: "case-1",
      1: "case-2",
      2: "case-3",
    });
  });

  it("returns empty body and empty indexMap for zero cases", () => {
    const { body, indexMap } = assembleJsonlFile([]);

    expect(body).toBe("");
    expect(indexMap).toEqual({});
  });

  it("handles a single case without trailing newline", () => {
    const cases = [{ caseId: "only-case", line: '{"data":"value"}' }];

    const { body, indexMap } = assembleJsonlFile(cases);

    expect(body).toBe('{"data":"value"}');
    expect(body).not.toContain("\n");
    expect(indexMap).toEqual({ 0: "only-case" });
  });

  it("preserves case ordering in both body and indexMap", () => {
    const cases = [
      { caseId: "z-last-alpha", line: "line-z" },
      { caseId: "a-first-alpha", line: "line-a" },
      { caseId: "m-middle-alpha", line: "line-m" },
    ];

    const { body, indexMap } = assembleJsonlFile(cases);

    // Order is input order, not sorted
    expect(body).toBe("line-z\nline-a\nline-m");
    expect(indexMap[0]).toBe("z-last-alpha");
    expect(indexMap[1]).toBe("a-first-alpha");
    expect(indexMap[2]).toBe("m-middle-alpha");
  });
});
