/**
 * Tournament Summary Generator
 *
 * Calls Bedrock Converse to produce a natural-language summary comparing
 * baseline vs variant results. The winning variant is computed deterministically
 * via `selectWinningVariant` — the AI summary only explains the quantitative
 * result.
 *
 * Resolves the `tournament_summary` prompt for the executing run via
 * {@link resolvePromptForRun} (R11.2 — the run's pinned snapshot is the
 * source of truth, falling back to the live registry for pre-feature
 * runs). The Bedrock Converse `inferenceConfig` is built from the
 * resolved prompt by {@link buildInferenceConfig} so the wire shape
 * always matches the resolved model's capability profile (R17.4).
 *
 * The default `tournament_summary` model is Anthropic Claude Sonnet 4.6
 * (`anthropic_claude_4x` profile). The profile forbids `temperature` and
 * `topP` so any inference values the registry might carry for those
 * keys are silently dropped on the wire per R17.4 — the model runs at
 * Anthropic's default sampling temperature. The summary call is short
 * (`maxTokens: 4096`) and the user message embeds the deterministic
 * winner line so the natural-language output is constrained to "explain
 * what already happened" rather than re-derive it.
 *
 * If the Bedrock call fails, returns the deterministic result with a
 * fallback summary string. A `PromptResolutionError` from
 * {@link resolvePromptForRun} (R16.3) propagates unchanged — the caller
 * surfaces the structured error rather than have it re-wrapped as a
 * Bedrock failure.
 *
 * Migrated from a hardcoded inline `SYSTEM_PROMPT` literal and a
 * `BEDROCK_MODEL_ID` env-var fallback (with an orphan legacy default
 * Claude Sonnet 4 model id) to the registry (Wave 2 — Task 17.5 of
 * the prompt-management spec). The legacy `BEDROCK_MODEL_ID` env var
 * is still set in `lib/orchestration-construct.ts` as a Wave-2 safety
 * net and is removed in Wave 3.
 *
 * Requirements: 8.5, 17.4, 1.3, 10.1, 11.2, 11.3
 *
 * @module tournament-summary
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ContentBlock,
  type ConverseCommandInput,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";

import { selectWinningVariant } from "./variant-selection";
import { aggregateScores } from "./score-aggregation";
import { CaseStatus } from "../../shared/enums";
import {
  buildInferenceConfig,
  type ResolvedPrompt,
} from "./prompt-registry";
import { resolvePromptForRun } from "./prompt-registry/runtime";
import type {
  TestCaseResult,
  VariantConfig,
  VariantScore,
  TournamentSummary,
} from "../../shared/types";

// ---------------------------------------------------------------------------
// Public Types
// ---------------------------------------------------------------------------

export interface TournamentSummaryInput {
  baselineResults: TestCaseResult[];
  variantResults: Record<"A" | "B" | "C", TestCaseResult[]>;
  variantConfigs: VariantConfig[];
  /**
   * The run id whose pinned snapshot supplies the `tournament_summary`
   * prompt (R11.2 / R11.3). The empty string falls back to the live
   * registry — used by unit tests and the rare pre-feature run path
   * where no snapshot was captured at run start.
   */
  runId: string;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";

const FALLBACK_SUMMARY =
  "Summary generation failed. See quantitative results above.";

// ---------------------------------------------------------------------------
// Bedrock Client (lazy singleton with test injection)
// ---------------------------------------------------------------------------

type SendableBedrockClient = Pick<BedrockRuntimeClient, "send">;

let bedrockClient: SendableBedrockClient | null = null;

function getBedrockClient(): SendableBedrockClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

/** @internal — allows test injection */
export function _setBedrockClient(client: SendableBedrockClient | null): void {
  bedrockClient = client;
}

// ---------------------------------------------------------------------------
// Per-Variant Highlights Computation
// ---------------------------------------------------------------------------

/**
 * Computes improved and regressed case lists for a variant by comparing
 * each test case's status between baseline and the variant.
 *
 * improved = cases that failed in baseline but passed in variant
 * regressed = cases that passed in baseline but failed in variant
 */
function computeHighlights(
  baselineResults: TestCaseResult[],
  variantResults: TestCaseResult[]
): { improved: string[]; regressed: string[] } {
  const baselineStatusMap = new Map<string, CaseStatus>();
  for (const result of baselineResults) {
    baselineStatusMap.set(result.caseId, result.status);
  }

  const improved: string[] = [];
  const regressed: string[] = [];

  for (const variantResult of variantResults) {
    const baselineStatus = baselineStatusMap.get(variantResult.caseId);
    if (baselineStatus === undefined) {
      continue; // Case not in baseline, skip
    }

    if (
      baselineStatus === CaseStatus.FAILED &&
      variantResult.status === CaseStatus.PASSED
    ) {
      improved.push(variantResult.caseId);
    } else if (
      baselineStatus === CaseStatus.PASSED &&
      variantResult.status === CaseStatus.FAILED
    ) {
      regressed.push(variantResult.caseId);
    }
  }

  return { improved, regressed };
}

// ---------------------------------------------------------------------------
// Variant Score Computation
// ---------------------------------------------------------------------------

/**
 * Computes VariantScore objects from variant results for use in
 * `selectWinningVariant`.
 */
function computeVariantScores(
  variantResults: Record<"A" | "B" | "C", TestCaseResult[]>
): VariantScore[] {
  const variants: Array<"A" | "B" | "C"> = ["A", "B", "C"];

  return variants.map((variant) => {
    const results = variantResults[variant];

    // If variant has no results, mark as error
    if (!results || results.length === 0) {
      return {
        variant,
        passRate: 0,
        avgGoalSuccessScore: 0,
        avgHelpfulnessScore: 0,
        avgToolAccuracyScore: 0,
        status: "error" as const,
      };
    }

    const scores = aggregateScores(results);
    return {
      variant,
      passRate: scores.passRate,
      avgGoalSuccessScore: scores.avgGoalSuccessScore,
      avgHelpfulnessScore: scores.avgHelpfulnessScore,
      avgToolAccuracyScore: scores.avgToolAccuracyScore,
      status: "completed" as const,
    };
  });
}

// ---------------------------------------------------------------------------
// Bedrock Summary User Message
// ---------------------------------------------------------------------------

function buildUserMessage(
  baselineScores: ReturnType<typeof aggregateScores>,
  variantScores: VariantScore[],
  perVariantHighlights: Record<"A" | "B" | "C", { improved: string[]; regressed: string[] }>,
  winningVariant: "A" | "B" | "C" | null,
  variantConfigs: VariantConfig[]
): string {
  const configSummary = variantConfigs
    .map((v) => `Variant ${v.variantLetter}: strategy="${v.strategy}"`)
    .join("\n");

  const scoreSummary = variantScores
    .map(
      (s) =>
        `Variant ${s.variant}: passRate=${(s.passRate * 100).toFixed(1)}%, ` +
        `goalSuccess=${(s.avgGoalSuccessScore * 100).toFixed(1)}%, ` +
        `helpfulness=${(s.avgHelpfulnessScore * 100).toFixed(1)}%, ` +
        `toolAccuracy=${(s.avgToolAccuracyScore * 100).toFixed(1)}%, ` +
        `status=${s.status}`
    )
    .join("\n");

  const highlightsSummary = (["A", "B", "C"] as const)
    .map((v) => {
      const h = perVariantHighlights[v];
      return (
        `Variant ${v}: improved=[${h.improved.join(", ")}], ` +
        `regressed=[${h.regressed.join(", ")}]`
      );
    })
    .join("\n");

  const winnerLine =
    winningVariant !== null
      ? `The deterministic winner is Variant ${winningVariant} (highest pass rate, tiebreak by goal success score).`
      : "No winning variant — all variants errored or had no results.";

  return `## Baseline Scores
passRate=${(baselineScores.passRate * 100).toFixed(1)}%, goalSuccess=${(baselineScores.avgGoalSuccessScore * 100).toFixed(1)}%, helpfulness=${(baselineScores.avgHelpfulnessScore * 100).toFixed(1)}%, toolAccuracy=${(baselineScores.avgToolAccuracyScore * 100).toFixed(1)}%

## Variant Strategies
${configSummary}

## Variant Scores
${scoreSummary}

## Per-Variant Highlights (compared to baseline)
${highlightsSummary}

## Winner
${winnerLine}

Produce a 2-4 sentence summary explaining this outcome. Focus on what changed and why the winner (or lack thereof) makes sense.`;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Generates a tournament summary by:
 * 1. Computing per-variant highlights (improved/regressed cases) deterministically
 * 2. Computing the winning variant deterministically via selectWinningVariant
 * 3. Calling Bedrock Converse against the run-pinned `tournament_summary`
 *    prompt for a natural-language explanation
 *
 * R11.2 / R11.3: the prompt is resolved exactly once at the top of the
 * function via {@link resolvePromptForRun}. The resolver's per-warm
 * cache (keyed by `runId`) means subsequent invocations within the same
 * Lambda warm reuse the cached snapshot read without hitting DynamoDB
 * again. A resolution failure propagates as a `PromptResolutionError`
 * (R16.3); we intentionally do NOT catch it inside the Bedrock
 * try/catch below so the structured error surfaces with its original
 * shape rather than being silently degraded to the fallback summary.
 *
 * If the Bedrock call itself fails, returns the deterministic result
 * with a fallback summary string — graceful degradation per the design.
 *
 * Requirements: 8.5, 17.4, 1.3, 10.1, 11.2, 11.3
 */
export async function generateTournamentSummary(
  input: TournamentSummaryInput
): Promise<TournamentSummary> {
  const { baselineResults, variantResults, variantConfigs, runId } = input;

  // R11.2 / R11.3: resolve the prompt once per call. The runtime helper
  // caches the snapshot read per warm so repeated invocations for the
  // same run issue at most one DDB read. A failure here propagates
  // naturally as a `PromptResolutionError` (R16.3) — we intentionally
  // do NOT catch it inside the Bedrock try/catch below so the
  // structured error surfaces with its original shape rather than
  // being silently degraded to the fallback summary.
  const prompt = await resolvePromptForRun("tournament_summary", runId);

  // 1. Compute per-variant highlights (deterministic)
  const perVariantHighlights: Record<
    "A" | "B" | "C",
    { improved: string[]; regressed: string[] }
  > = {
    A: computeHighlights(baselineResults, variantResults.A),
    B: computeHighlights(baselineResults, variantResults.B),
    C: computeHighlights(baselineResults, variantResults.C),
  };

  // 2. Compute variant scores and select winner (deterministic)
  const scores = computeVariantScores(variantResults);
  const winningVariant = selectWinningVariant(scores);

  // 3. Compute baseline aggregate scores for the summary prompt
  const baselineScores = aggregateScores(baselineResults);

  // 4. Call Bedrock for natural-language explanation
  let summary: string;
  try {
    summary = await callBedrockSummary(
      prompt,
      baselineScores,
      scores,
      perVariantHighlights,
      winningVariant,
      variantConfigs
    );
  } catch {
    // Graceful degradation: return deterministic results with fallback text
    summary = FALLBACK_SUMMARY;
  }

  return {
    winningVariant,
    summary,
    perVariantHighlights,
  };
}

// ---------------------------------------------------------------------------
// Bedrock Call
// ---------------------------------------------------------------------------

/**
 * Issue the Bedrock Converse call against the registry-resolved prompt.
 * The `prompt` argument is the {@link ResolvedPrompt} returned once per
 * `generateTournamentSummary` invocation by {@link resolvePromptForRun}
 * — the helper does NOT re-resolve.
 */
async function callBedrockSummary(
  prompt: ResolvedPrompt,
  baselineScores: ReturnType<typeof aggregateScores>,
  variantScores: VariantScore[],
  perVariantHighlights: Record<"A" | "B" | "C", { improved: string[]; regressed: string[] }>,
  winningVariant: "A" | "B" | "C" | null,
  variantConfigs: VariantConfig[]
): Promise<string> {
  const userMessage = buildUserMessage(
    baselineScores,
    variantScores,
    perVariantHighlights,
    winningVariant,
    variantConfigs
  );

  const messages: Message[] = [
    {
      role: "user",
      content: [{ text: userMessage }] as ContentBlock[],
    },
  ];

  // The wire-shape helper places the resolved inference parameters
  // into the exact arguments the Converse SDK expects for the
  // resolved model's capability profile. For Anthropic Claude 4.x
  // (the default `tournament_summary` model) this emits
  // `{ inferenceConfig: { maxTokens } }` with no `temperature`,
  // `topP`, `topK`, or `stopSequences` — those keys are forbidden by
  // the profile (R17.4) and are silently dropped here. The summary
  // model runs at Anthropic's default sampling temperature, which is
  // acceptable because the user message embeds the deterministic
  // winner line so the model only "explains" rather than re-derives.
  // For `amazon_nova` profile models the helper emits the
  // appropriate top-level + additional-fields split. Same pattern as
  // `variant-generator.ts`, `customer-simulator.ts`, etc.
  const built = buildInferenceConfig(prompt);

  // The casts on `inferenceConfig` and `additionalModelRequestFields`
  // bridge the SDK's strict types (`InferenceConfiguration` for the
  // top-level config, `DocumentType` for the additional fields) and
  // our runtime payload — `buildInferenceConfig` already enforced the
  // exact key set against the resolved capability profile, so the
  // values are guaranteed JSON-encodable at runtime.
  const command = new ConverseCommand({
    modelId: prompt.modelId,
    system: [{ text: prompt.text }],
    messages,
    inferenceConfig:
      built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(built.additionalModelRequestFields
      ? {
          additionalModelRequestFields:
            built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  const client = getBedrockClient();
  const resp = await client.send(command);

  const text = resp.output?.message?.content
    ?.map((b) => ("text" in b ? b.text ?? "" : ""))
    .join("");

  if (!text || text.trim().length === 0) {
    throw new Error("Bedrock returned an empty tournament summary response.");
  }

  return text.trim();
}
