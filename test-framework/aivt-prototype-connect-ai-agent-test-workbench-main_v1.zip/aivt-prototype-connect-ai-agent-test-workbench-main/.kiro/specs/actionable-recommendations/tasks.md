# Implementation Plan: Actionable Recommendations

## Overview

This plan extends the existing platform end-to-end so test runs become actionable. Foundations land first (shared types, then capture paths) so every downstream task compiles against a stable contract; the per-case Analysis Lambda gains persistence and the new `tool_examples` Tool_Surface; a new sibling Lambda (`suite-recommend.ts`) produces the prioritized per-suite recommendations; the frontend gains a `RecommendedChangesPanel` on the Run Dashboard with explicit empty/error states and deep-links to the canonical Failure Analysis view; example-based unit tests, the six property tests from the design, and integration tests against the deployed stack close out the build.

Every task references its target file from the design's Reuse Map. The codebase already exists — every task either extends a file in place or adds one new file the design explicitly creates (`suite-recommend.ts`, `recommendation-bucketing.ts`, `failure-grouping.ts`, `RecommendedChangesPanel.tsx`).

## Tasks

- [x] 1. Extend shared types in `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/shared/types.ts`
  - Add `examples: string[]` (required field, default `[]` on read) to the `ToolDefinition` interface so all consumers — `AgentSummary`/`AgentDetail`, `AgentSnapshot`, the analysis prompt builder, the config-diff utility — read the same shape.
  - Add the new `ToolSurface` discriminated string union with the four values `"tool_description" | "tool_instruction" | "tool_examples" | "system_prompt"` exactly as specified in the design's Shared Recommendation Type section.
  - Add the new `ToolExamplesOperation` type and the new `Recommendation` interface (fields: `targetField: ToolSurface`, `targetName: string`, `currentText: string`, `suggestedText: string`, `rationale: string`).
  - Add the new `PerSuiteRecommendation extends Recommendation` interface with the `priority: number` field and the nested `predictedImpact: { liftedCaseIds: string[]; rationale: string }` shape.
  - JSDoc each new type with the field invariants from R13.3 (no-op rejection, tool_examples add/remove/replace text-presence rules, monotonic-priority contract) so engineers reading the type pick up the contract without re-reading the spec.
  - Do not modify the existing `AgentSnapshot` shape beyond the per-tool field added via the `ToolDefinition` extension — top-level keys (`tools`, `systemPrompt`, `modelId`, `capturedAt`) stay byte-for-byte the same per R3.2.
  - _Requirements: 1.5, 3.2, 5.1, 13.1, 13.2_

- [x] 2.1 Extend the Discovery Lambda at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/handlers/discovery.ts` to surface tool examples
  - In the `getAgentDetail` mapper for `toolConfigurations[]`, add `examples: Array.isArray(tool.examples) ? [...tool.examples] : []` so absent / null / non-array `examples` fields all collapse to `[]` and the field is never omitted from the response.
  - Apply the same mapping in any other location inside this file that constructs a `ToolDefinition` (e.g. `mapToAgentSummary`'s tool count path needs no change, but if any other code path materializes `ToolDefinition` add the `examples` key to keep the type satisfied).
  - Preserve the array order verbatim (do not sort, do not trim, do not deduplicate) and preserve every example string verbatim including embedded whitespace, newlines, and quote characters.
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

- [x] 2.2 Extend `snapshotAgent` in `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/handlers/runs.ts` to capture tool examples
  - In the `tools` mapper inside `snapshotAgent`, add `examples: Array.isArray(tool.examples) ? [...tool.examples] : []` mirroring the Discovery Lambda mapping so the snapshot persisted at `PK=RUN#{runId}, SK=SNAPSHOT` carries the per-tool examples that were active at run start.
  - Confirm the `db.writeSnapshot(runId, agentSnapshot)` call path forwards the new field unchanged (no marshalling step strips it); add a regression assertion in the unit test under task 12.2 that round-trips the snapshot through the marshaller.
  - _Requirements: 3.1, 3.2_

- [x] 3. Extend `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/shared/utils/config-diff.ts` with the `tool-examples-changed` change type
  - Add `"tool-examples-changed"` to the `ConfigChangeType` union and extend `ConfigChange` with optional `priorExamples?: string[]` and `newExamples?: string[]` fields populated only on `tool-examples-changed` records (other change types leave them undefined).
  - Inside the per-tool comparison loop, after the existing description/instruction comparison, add an examples comparison that emits a single `tool-examples-changed` record when the two `examples` arrays differ in length, in order, or in any element string, AND emits zero records when they are element-wise equal — including when both are empty.
  - Treat a missing `examples` field on either snapshot as `[]` for the comparison (backward compat per R3.3) so a pre-feature snapshot diffed against a post-feature snapshot does not falsely emit a `tool-examples-changed` record when the post-feature snapshot also has no examples for that tool.
  - Emit the `tool-examples-changed` record independently of `tool-modified` (R4.4): a tool whose only difference is its examples array MUST produce a `tool-examples-changed` record and no `tool-modified` record; a tool whose description AND examples both changed produces both records.
  - _Requirements: 4.1, 4.2, 4.4, 15.6_

- [x] 4. Add the new pure shared utility at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/shared/utils/recommendation-bucketing.ts`
  - Export `BucketedRecommendations<T>` and `bucketByTargetField<T>` exactly as specified in the design's Bucketing Helper Signature section, returning a four-key object `{ tool_description, tool_instruction, tool_examples, system_prompt }` of arrays.
  - Each input recommendation appears in exactly one output array (the one keyed by its `targetField`); the four arrays' concatenation contains the same multiset as the input; order within each bucket matches input order.
  - Throw on any recommendation whose `targetField` is not one of the four valid `ToolSurface` values — callers (the Analysis Lambda, the suite-recommend Lambda) are responsible for filtering invalid records before bucketing per R5.9 and R6.5.
  - Keep the function pure (no I/O, no clock, no globals) so Property 1 in task 13.1 can target it as a finite-state predicate.
  - _Requirements: 5.1, 7.1, 13.1, 15.1_

- [x] 5. Extract `groupFailuresByRootCause` and the `Recommendation` reuse from `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/handlers/analysis.ts` into `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/shared/utils/failure-grouping.ts`
  - Move the existing `groupFailuresByRootCause` and `deduplicateRecommendations` functions out of `analysis.ts` and into the new shared util so the `RecommendedChangesPanel`, the `FailureAnalysis.tsx` page, and the `CaseDetail.tsx` page can import the same canonical implementation per the design's "Bucketing Helper Signature ... three call sites with one tested implementation" rationale.
  - Update `analysis.ts` to re-export or import-and-re-use the shared functions so existing callers remain green; the next task (6) will rebuild the surrounding handler.
  - Replace the analysis-local `Recommendation` and related types with imports from `src/shared/types.ts` (added in task 1) so there is exactly one canonical `Recommendation` shape across the codebase.
  - Confirm the new util has zero React / no AWS-SDK dependencies (it is consumed by both backend and frontend) — pure TypeScript only.
  - _Requirements: 11.1, 13.1_

- [x] 6. Extend the Analysis Lambda at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/handlers/analysis.ts` for examples-aware prompts, persistence, force, and malformed-record drop
  - Extend `formatTools` to render an `Examples:` block immediately after the `Instruction:` line for each tool, formatted as a numbered list (one example per line) when present and the literal string `Examples: (none)` when the array is empty per R5.7 and R14.2.
  - Extend the prompt instructions block at the bottom of `buildAnalysisPrompt` with the three-paragraph clause from the design's "Per-Case Prompt Extension" section: enumerate the four valid `targetField` values, describe the three `tool_examples` operations (add → empty `currentText`, non-empty `suggestedText`; remove → non-empty `currentText`, empty `suggestedText`; replace → both non-empty), and require exact-string matching for remove/replace.
  - Add a `force?: boolean` field to `AnalysisRequest`.
  - Replace the response shape with the flat `caseAnalyses[]` form from the design (`PerCaseAnalysis` carrying `caseId`, `rootCauseCategory`, `explanation`, `traceAvailable`, `recommendations`, `generatedAt`, `modelId` — and the response itself carrying `caseAnalyses`, `generatedAt`, `modelId`, plus optional `partialFailures: string[]`); the legacy `individualAnalyses`/`groupedAnalyses` split is retired (the frontend re-groups for display via the shared `failure-grouping` util).
  - On entry, query `PK=RUN#{runId}, SK begins_with ANALYSIS#CASE#`; if the persisted record count equals the failed-case count for the run AND `force !== true`, return the persisted records without invoking Bedrock per R6.2 and R10.9.
  - On `force === true`, bypass the persisted-read shortcut, re-invoke Bedrock for every failed case, overwrite each `ANALYSIS#CASE#{caseId}` record, and update each `generatedAt` timestamp per R6.3.
  - After Bedrock returns, drop any recommendation whose `targetField` is not one of the four `ToolSurface` values (log the dropped record for diagnostics) per R5.9; drop any recommendation whose `targetName` is empty or where both `currentText` and `suggestedText` are empty per R13.3.
  - Persist each surviving per-case analysis to `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` with `generatedAt` (ISO 8601) and `modelId`. On DDB write failure, log the failure and still return the analysis to the caller (and surface the failed case IDs on the response's `partialFailures`) per R6.6.
  - When the snapshot read returns `Item` but `Item.tools[i].examples` is present and not a JSON array, abort the analysis and return HTTP 500 with `{ error: "snapshot_examples_malformed", toolName }` per R5.8.
  - Wrap Bedrock calls with the existing `src/shared/utils/backoff.ts` retry helper using `(baseMs: 1000, capMs: 10000, maxRetries: 2)` for `ThrottlingException`; on terminal throttle return HTTP 503 with `retryable: true` per R12.1, R12.2.
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 12.1, 12.2, 13.3, 14.1, 14.2, 14.3_

- [x] 7. Add the new per-suite recommendation Lambda at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/handlers/suite-recommend.ts`
  - Mirror the file layout, client caching, JSON helpers, and `_set*` test injectors of `comparison-summary.ts` so the new Lambda has the same operational posture as the existing Bedrock-callers in the codebase.
  - Export `SuiteRecommendRequest` (with optional `force?: boolean`), `SuiteRecommendResponse` (carrying `recommendations: PerSuiteRecommendation[]`, `generatedAt`, `modelId`), and the `handler` for `POST /runs/{runId}/recommend-suite`.
  - Read the persisted record at `PK=RUN#{runId}, SK=ANALYSIS#SUITE` first; if present and `force !== true`, return it unchanged so repeated reads return identical ordering per R8.8 and R9.3.
  - Load the failed `TestCaseResult[]` (`PK=RUN#{runId}, SK begins_with CASE#`), the `AgentSnapshot` (`PK=RUN#{runId}, SK=SNAPSHOT`), and any persisted per-case analyses (`PK=RUN#{runId}, SK begins_with ANALYSIS#CASE#`); a missing snapshot produces HTTP 404 with `{ error: "snapshot_missing" }` per R12.3, malformed `examples` produces HTTP 500 with `{ error: "snapshot_examples_malformed", toolName }` per R5.8.
  - Build the per-suite prompt verbatim from the design's "Per-Suite Prompt Template" section: system prompt instructing the model to consolidate and prioritize, user message containing Run Summary + Agent Configuration (reusing the same `formatTools` Examples-aware renderer from task 6) + Agent System Prompt + Per-Case Failures + Instructions block.
  - Call Bedrock Converse with `temperature: 0`, `topP: 1`, `maxTokens: 2048`, the same Sonnet 4.6 inference profile as `analysis.ts` and `comparison-summary.ts` (default `process.env.SUITE_RECOMMEND_MODEL_ID ?? process.env.ANALYSIS_MODEL_ID ?? "us.anthropic.claude-sonnet-4-6"`).
  - Parse the JSON response, drop any recommendation whose `targetField` is invalid (R5.9), whose `targetName` is empty (R13.3), whose `currentText`/`suggestedText` violate the no-op or operation-shape rules (R13.3), or whose `predictedImpact.liftedCaseIds` references a case ID that is not in the failed-case-IDs list for this run (R8.6); deduplicate `liftedCaseIds` within each surviving recommendation (R8.6).
  - Sort the surviving array using the comparator from the design's "Server-Side Ordering Enforcement" section: `(priority asc, predictedImpact.liftedCaseIds.length desc, lex(targetField + "|" + targetName) asc)`.
  - Renumber `priority` to a 1-based dense rank that respects the comparator so `recommendations[i].priority <= recommendations[j].priority` for all `i < j` per R9.1.
  - Persist the sorted, renumbered array to `PK=RUN#{runId}, SK=ANALYSIS#SUITE` with `generatedAt` and `modelId`; on DDB write failure log and still return the response (self-healing per R6.6 semantics).
  - Wrap Bedrock with the same retry posture as task 6 (`baseMs: 1000, capMs: 10000, maxRetries: 2` on `ThrottlingException`, terminal throttle → HTTP 503 with `retryable: true`) per R12.1 and R12.2.
  - When the model returns an empty array (no actionable recommendations), persist the empty array, return HTTP 200 with the empty array per R8.1 — same surface the panel's "No actionable recommendations were identified" empty state consumes.
  - _Requirements: 5.8, 5.9, 6.5, 8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7, 8.8, 9.1, 9.2, 9.3, 12.1, 12.2, 12.3, 12.4, 13.1, 13.2, 13.3_

- [x] 8. Wire the new Lambda into `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/lib/api-construct.ts`
  - Declare a public `suiteRecommendLambda: lambda.Function` field on `ApiConstruct` and instantiate it as a `NodejsFunction` from `src/backend/handlers/suite-recommend.ts` with `timeout: cdk.Duration.seconds(60)`, `memorySize: 512`, and the same `commonLambdaProps` (Node 20 ARM64, tracing, env) used by the analysis and comparison-summary Lambdas.
  - Grant the new Lambda the same Bedrock `InvokeModel` + `Converse` posture as `analysisLambda` against the three Anthropic inference-profile resource ARNs and the three foundation-model resource ARNs (us-east-1, us-east-2, us-west-2) — verbatim copy of the existing analysis Lambda's `addToRolePolicy` block.
  - Grant `props.table.grantReadWriteData(this.suiteRecommendLambda)` (the Lambda persists `PK=RUN#{runId}, SK=ANALYSIS#SUITE` so it needs write, unlike the analysis Lambda's read-only grant which task 8 should also upgrade — see next bullet).
  - Upgrade `props.table.grantReadData(this.analysisLambda)` to `grantReadWriteData` so the persistence-on-success step added in task 6 has IAM permission to write the per-case analysis records.
  - In `configureRoutes`, add a new `runById.addResource('recommend-suite')` resource and wire `addMethod('POST', new apigateway.LambdaIntegration(this.suiteRecommendLambda), authOptions)` so the route resolves at `POST /runs/{runId}/recommend-suite`.
  - Re-export the new field on the construct so the stack-level snapshot test in task 15 can assert its presence.
  - _Requirements: 8.1, 6.1, 6.2, 6.3_

- [x] 9. Build the new component `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/frontend/src/components/RecommendedChangesPanel.tsx`
  - Export `RecommendedChangesPanelProps` with `runId: string`, `suiteId?: string`, `runStatus: RunStatus`, `failedCount: number`, `errorCount: number` so the Run Dashboard wires it without prop drilling.
  - Implement the three explicit empty states from the design's render-decision sequence: (a) `runStatus === RUNNING` → placeholder "Recommendations will appear when the run completes" with no engine call (R10.8); (b) `failedCount === 0 && errorCount === 0` → green Alert "No recommended changes — all cases passed" with no engine call AND a "Re-analyze" action that surfaces the inline message "No analysis needed — all cases passed" without calling the engine (R10.2, R10.3); (c) otherwise mount-time POST without `force` to both `/runs/{runId}/analyze` and `/runs/{runId}/recommend-suite` (R10.9, R11.1, R11.2).
  - Render the per-suite recommendations at the top of the panel, the per-case recommendations grouped by root-cause category (using the shared `failure-grouping` util from task 5) and bucketed by Tool_Surface (using the `recommendation-bucketing` util from task 4) beneath, per R10.4.
  - Each per-suite card shows (a) a circled priority indicator displaying the recommendation's 1-based array index, (b) a Tool_Surface badge, (c) the diff view (current text in `#fdf0f0`/red border, suggested in `#f2fcf3`/green border — match the existing `DiffView` styling in `FailureAnalysis.tsx`), (d) the `predictedImpact.rationale` text, (e) `liftedCaseIds` rendered as `Button variant="inline-link"` items navigating to `/runs/{runId}/cases/{caseId}` per R10.6.
  - Render a "Re-analyze" action in the panel header that POSTs `{ force: true }` to both endpoints concurrently and refreshes local state on success per R11.3.
  - Render a "View full failure analysis" footer link to `/runs/{runId}/results` (the Results Viewer entry where Failure_Analysis_View lives) per R10.7.
  - Render the empty-state Alert "No actionable recommendations were identified for the failed cases in this run" with a "Re-analyze" action when both calls succeed but return zero recommendations per R10.5.
  - Render per-suite and per-case error states independently with a "Retry" button each per R12.2; render the inline notice "Per-case analysis failed for cases: {ids}" when the analysis response's `partialFailures` array is non-empty per R12.5.
  - Render a "Re-analyze to incorporate the now-captured examples" banner when any persisted analysis was generated against a snapshot with no `examples` per R12.6 (the response's `modelId`/`generatedAt` is the cue; the panel checks against the current snapshot via `effectiveSuiteId` lookup or via a flag set by the Lambdas).
  - The component reads only persisted records — it MUST NOT compute recommendations independently per R11.1 and R11.2.
  - _Requirements: 7.1, 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 10.7, 10.8, 10.9, 11.1, 11.2, 11.3, 12.2, 12.5, 12.6, 13.1, 13.2_

- [x] 10.1 Extend `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/frontend/src/pages/AgentBrowser.tsx` with the per-tool Examples block
  - Inside each tool `Container` in `AgentDetailPanel`, after the Instruction `Box` and before the Input Schema `Box`, add the Examples section structured per the design's "AgentBrowser.tsx per-tool examples block" snippet: a key-label header reading "Examples" with a `Badge` showing `tool.examples.length` (rendered even when zero per R2.4).
  - When `tool.examples.length === 0`, render a `<Box color="text-status-inactive">No examples configured</Box>` next to the count badge (R2.2).
  - When non-empty, render an ordered `<ol>` list with each `<li>` containing a `<pre>` styled with `whiteSpace: 'pre-wrap'`, `wordBreak: 'break-word'`, monospace family, light-gray background, and 6/8px padding so whitespace and newlines render verbatim (R2.3).
  - Do not introduce a separate fetch — the existing `GET /agents/{agentId}` response now carries `examples` on each tool (after task 2.1 ships).
  - _Requirements: 2.1, 2.2, 2.3, 2.4_

- [x] 10.2 Extend `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/frontend/src/pages/Comparison.tsx` to render `tool-examples-changed` rows
  - In the configuration-diff section, add a new row renderer for change records whose `changeType === "tool-examples-changed"` (the new type added in task 3).
  - Layout: a single row with the tool name in the header and a two-column body (Prior | New) showing each side's `examples` array as an ordered list with item-level highlighting: items present only in `new` get a green background (`#f2fcf3`), items present only in `prior` get a red background (`#fdf0f0`) and strike-through, items present in both but at different indices get a yellow "order changed" badge per R4.3.
  - Render empty-string examples as the literal text `<empty>` so deletions are visible.
  - The diff is computed client-side from the `priorExamples` and `newExamples` arrays carried on the change record; no extra API call.
  - Confirm the existing `tool-modified` row renderer is unaffected (R4.4 — a tool whose only difference is its examples MUST render only the `tool-examples-changed` row, not a `tool-modified` row).
  - _Requirements: 4.3, 4.4_

- [x] 10.3 Refactor `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/frontend/src/pages/FailureAnalysis.tsx` to read from persistence and add the Re-analyze action
  - Replace the auto-mount `runAnalysis()` call with a `fetchPersistedAnalysis()` that POSTs to `/runs/{runId}/analyze` without `force`; the Lambda's persisted-read shortcut (added in task 6) returns the record without re-invoking Bedrock per R11.1.
  - Replace the existing "Re-analyze" button (which currently re-posts the same request) with one that POSTs `{ force: true, suiteId? }` and updates local state on success per R11.3.
  - Switch local types and renderers from the legacy `individualAnalyses`/`groupedAnalyses` shape to the new flat `caseAnalyses[]` shape (the response shape after task 6 ships); group-by-root-cause runs client-side using the shared `failure-grouping` util from task 5 — no behaviour regression in the rendered UI.
  - Remove the local `Recommendation` and `FailureCaseAnalysis` interface declarations and import the canonical types from `src/shared/types.ts` (added in task 1).
  - Render the "Re-analyze to incorporate the now-captured examples" banner when the persisted record predates the examples-aware snapshot per R12.6; render the inline notice listing failed case IDs from `partialFailures` per R12.5.
  - The page remains the canonical full-detail view per R11.4 and is reachable from the Results Viewer; no route changes here.
  - _Requirements: 11.1, 11.3, 11.4, 12.5, 12.6, 13.1_

- [x] 10.4 Extend `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/frontend/src/pages/CaseDetail.tsx` with the per-case recommendations section
  - When `result.status === CaseStatus.FAILED`, fetch the persisted per-case analysis via POST `/runs/{runId}/analyze` without `force` (the Lambda returns the persisted record for this case if present); render a "Generate recommendations" button when the persisted record is missing for this case, which POSTs with `{ force: true, caseIds: [caseId] }` (or the simplest equivalent that triggers analysis for this case) per R7.2.
  - Render the recommendations beneath the existing Transcript and Execution Reasoning sections, grouped by Tool_Surface using the `recommendation-bucketing` util from task 4 per R7.1.
  - Skip the recommendations section entirely when `status` is `passed`, `error`, or `timed_out` per R7.3.
  - Add a "View full failure analysis ↗" link that navigates to `/runs/{runId}/results#case-{caseId}` so the Failure Analysis View remains the canonical full-detail view and the case detail page is a per-case projection of the same persisted record per R7.4.
  - The page MUST NOT compute recommendations independently — it reads only persisted records per R11.1.
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 11.1_

- [x] 11. Integrate `RecommendedChangesPanel` into `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/frontend/src/pages/RunDashboard.tsx`
  - Import the new `RecommendedChangesPanel` from `../components/RecommendedChangesPanel` and render it between the existing Progress section's `Container` and the Test Case Results `Container` so it sits above the results table per R10.1.
  - Pass `runId={runId}`, `suiteId={effectiveSuiteId ?? undefined}`, `runStatus={run?.status ?? RunStatus.RUNNING}`, `failedCount={progress?.failed ?? 0}`, `errorCount={progress?.errors ?? 0}` so the panel sees the same numbers the Progress section renders.
  - Render the panel only when a `runId` is set (i.e. not in the `/runs/new` "ready to start" sentinel state) so the panel does not flash a transient empty state before the run record loads.
  - Confirm the panel does not retrigger when polling refreshes the run state — its internal mount-time fetch should run once per mount, and the existing `progress` poll should not invalidate it.
  - _Requirements: 10.1_

- [x] 12.1 Add example-based unit tests for the Discovery Lambda's examples mapping at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/discovery.test.ts`
  - Test cases: tool with present array → preserved verbatim; tool with `null` → mapped to `[]`; tool with `undefined` → mapped to `[]`; tool with `examples: 42` (non-array) → mapped to `[]`; tool with `["", "  ", "line\nbreak", "\"quoted\""]` → preserved verbatim (no trim, no normalization).
  - Confirm the response from `getAgentDetail` always includes the `examples` field on every tool (never omitted) per R1.5.
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

- [x] 12.2 Add example-based unit tests for `snapshotAgent` examples capture at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/runs.test.ts`
  - Test cases: agent with N tools all carrying examples → snapshot's `tools[].examples` element-wise equals input; agent with no examples → snapshot's `tools[].examples` is `[]` for every tool; agent with malformed examples (non-array on the upstream payload) → snapshot's `tools[].examples` is `[]` (defensive degradation, not a 500 here — the 500 surfaces only on read at task 6).
  - Round-trip the snapshot through the DDB document marshaller and confirm the field survives.
  - _Requirements: 3.1, 3.2_

- [x] 12.3 Add example-based unit tests for the `tool-examples-changed` change type at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/config-diff.test.ts`
  - Test cases: identical examples → no record; added example → `tool-examples-changed` with prior/new arrays; removed example → `tool-examples-changed`; reordered same set → `tool-examples-changed`; missing-vs-empty (one snapshot has no examples field, the other has `[]`) → no record (backward compat per R3.3 and R4.2); description AND examples both changed → both `tool-modified` and `tool-examples-changed` records emitted; description changed but examples unchanged → only `tool-modified` (R4.4).
  - _Requirements: 3.3, 4.1, 4.2, 4.4_

- [x] 12.4 Add example-based unit tests for `recommendation-bucketing` at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/recommendation-bucketing.test.ts`
  - Test cases: empty input → all four buckets empty; one recommendation per surface → each bucket has exactly one record; multiple records on the same surface → bucket preserves input order; invalid `targetField` → throws.
  - _Requirements: 5.1, 13.1, 15.1_

- [x] 12.5 Add example-based unit tests for the extracted `failure-grouping` shared util at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/failure-grouping.test.ts`
  - Port the existing `groupFailuresByRootCause` and `deduplicateRecommendations` test cases from `tests/unit/analysis.test.ts` so coverage moves with the implementation.
  - Add a regression test that the util returns empty `individual` and `grouped` arrays for an empty input and tolerates a single-case category (renders as `individual`, not `grouped`).
  - _Requirements: 11.1_

- [x] 12.6 Add example-based unit tests for the Analysis Lambda's persistence, force, drop, and prompt extensions at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/analysis.test.ts`
  - Persisted-read shortcut: when DDB Query returns N persisted `ANALYSIS#CASE#*` records and there are N failed cases, Bedrock is NOT invoked and the response carries the persisted records with their original `generatedAt` (R6.2).
  - `force: true`: Bedrock IS invoked even when persisted records exist; persisted records are overwritten and `generatedAt` is updated (R6.3).
  - Pre-feature record: persisted record with no `tool_examples` recommendations is returned unchanged and is NOT silently regenerated (R6.4).
  - Persistence failure: simulated DDB write failure returns HTTP 200 with the analysis content and the failed case ID surfaces on `partialFailures` (R6.6).
  - Drop malformed: recommendation with invalid `targetField`, empty `targetName`, or both texts empty is dropped before persistence and logged (R5.9, R13.3).
  - Snapshot examples malformed: snapshot with `examples: 42` for a tool returns HTTP 500 with `{ error: "snapshot_examples_malformed", toolName }` (R5.8).
  - Prompt extension: `buildAnalysisPrompt` output contains the literal `Examples:` line for every tool, renders `Examples: (none)` for empty arrays, and contains the three-operations clause (R14.1, R14.2, R14.3).
  - Throttle posture: `ThrottlingException` is retried per the configured backoff (1s base, 10s cap, 2 retries); terminal throttle returns HTTP 503 with `retryable: true` (R12.1, R12.2).
  - _Requirements: 5.7, 5.8, 5.9, 6.2, 6.3, 6.4, 6.6, 12.1, 12.2, 13.3, 14.1, 14.2, 14.3_

- [x] 12.7 Add example-based unit tests for the new suite-recommend Lambda at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/suite-recommend.test.ts`
  - Persisted-read shortcut without `force` returns the persisted record unchanged, ordering preserved (R8.8, R9.3).
  - `force: true` re-invokes Bedrock and overwrites the persisted record with new `generatedAt` (R8.7).
  - Snapshot missing → HTTP 404 with `{ error: "snapshot_missing" }` (R12.3).
  - Snapshot examples malformed → HTTP 500 with `{ error: "snapshot_examples_malformed", toolName }` (R5.8).
  - Empty model output → HTTP 200 with empty `recommendations` array, persisted as such (R8.1).
  - Filter pass: model returns recommendations with (a) invalid `targetField`, (b) empty `targetName`, (c) `liftedCaseIds` referencing an unknown case ID, (d) duplicates within `liftedCaseIds` — assert the filtered output drops or deduplicates correctly (R5.9, R8.6, R13.3).
  - Sort and renumber: model returns recommendations in arbitrary priority order and arbitrary `liftedCaseIds.length` — assert the comparator from the design (priority asc, liftedCaseIds.length desc, lex tiebreaker) produces the expected order, and `priority` is renumbered to a 1-based dense rank that is monotonic with array index (R9.1, R9.2).
  - Prompt assertion: the constructed user message contains the four-Tool_Surface enum, the failed case IDs list, the Examples blocks for every tool (including `Examples: (none)` for empties), the explicit "consolidate, prioritize, predict impact" instructions (R8.2, R8.3).
  - Throttle posture identical to task 12.6 (R12.1, R12.2).
  - _Requirements: 5.8, 5.9, 8.1, 8.2, 8.3, 8.6, 8.7, 8.8, 9.1, 9.2, 9.3, 12.1, 12.2, 12.3, 13.3_

- [x] 13.1 Add Property 1 (Bucketing partitions) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/recommendation-bucketing.property.test.ts`
  - Generator: arrays of length 0..50 of recommendations with `targetField` drawn uniformly from the four `ToolSurface` values and arbitrary string fields.
  - Property: for any input array `xs`, the four output arrays' concatenation is a permutation of `xs` AND each input recommendation appears in exactly one output bucket — the one keyed by its `targetField` AND order within each bucket matches the input filter order.
  - Tag the test with the comment `Feature: actionable-recommendations, Property 1: Bucketing partitions` per the platform's tagging convention; minimum 100 fast-check iterations.
  - _Requirements: 5.1, 15.1_

- [x] 13.2 Add Property 2 (No-failure empty state) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/recommended-changes-panel-empty-state.property.test.ts`
  - Generator: random `RecommendedChangesPanelProps` objects with `failedCount === 0 && errorCount === 0` and arbitrary other fields (any `runStatus`, any `runId`, any `suiteId`).
  - Property: for any such props, the rendered output contains the empty-state text "No recommended changes — all cases passed" AND the `apiClient.post` mock is called zero times AND clicking the "Re-analyze" button still results in zero `apiClient.post` calls (the inline message "No analysis needed — all cases passed" is shown instead).
  - Use React Testing Library's `render` with a mocked `apiClient`; minimum 100 fast-check iterations.
  - _Requirements: 10.2, 10.3, 10.8, 15.2_

- [x] 13.3 Add Property 3 (Monotonic priority ordering) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/suite-recommend-priority.property.test.ts`
  - Generator: random `PerSuiteRecommendation[]` of length 0..30 with arbitrary `priority` integers in 1..100, arbitrary `liftedCaseIds` lengths, arbitrary `targetField`/`targetName` strings.
  - Property: feed the array through the Lambda's sort-and-renumber pipeline (export it as a pure helper from `suite-recommend.ts` for the test) — for the resulting array, for all `i < j`, `recommendations[i].priority <= recommendations[j].priority`.
  - Tag with `Feature: actionable-recommendations, Property 3: Monotonic priority ordering`; minimum 100 iterations.
  - _Requirements: 9.1, 15.3_

- [x] 13.4 Add Property 4 (Persisted-read determinism) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/suite-recommend-read-determinism.property.test.ts`
  - Run against DynamoDB Local (consistent with the platform's existing PBT convention for DDB-backed properties).
  - Generator: random `PerSuiteRecommendation[]` (and the accompanying `generatedAt`/`modelId`).
  - Property: write the record to `PK=RUN#{runId}, SK=ANALYSIS#SUITE`; read it back twice; assert the two reads are element-wise equal in length, in element order, and in every field of every element.
  - Minimum 50 iterations (DDB Local is the constraint on count).
  - _Requirements: 9.3, 15.4_

- [x] 13.5 Add Property 5 (Snapshot examples round-trip) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/snapshot-examples-roundtrip.property.test.ts`
  - Run against DynamoDB Local.
  - Generator: random `AgentSnapshot` with `tools[].examples` containing strings drawn from a Unicode-aware string generator that includes empty strings, strings with embedded whitespace, strings with embedded newlines, and strings with embedded quote characters (R1.4 verbatim preservation).
  - Property: write the snapshot to `PK=RUN#{runId}, SK=SNAPSHOT`; read it back; assert each tool's `examples` array is element-wise equal to the input — same length, same order, same string content.
  - Minimum 50 iterations.
  - _Requirements: 1.3, 1.4, 3.4, 15.5_

- [x] 13.6 Add Property 6 (`diffAgentConfigs` reflexivity over examples) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/config-diff-reflexivity.property.test.ts`
  - Generator: random `AgentSnapshot` values with non-trivial `tools[].examples` arrays (including empty arrays for some tools and non-empty for others).
  - Property: for any snapshot `s`, `diffAgentConfigs(s, s).hasChanges === false` AND `diffAgentConfigs(s, s).changes.length === 0`.
  - Tag with `Feature: actionable-recommendations, Property 6: diffAgentConfigs reflexivity over examples`; minimum 100 iterations.
  - _Requirements: 4.2, 15.6_

- [x] 14. Add integration tests against the deployed test stack at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/integration/critical-paths.test.ts`
  - Per-case end-to-end persisted-read shortcut: trigger a run with at least one failing case → wait for `COMPLETED` → POST `/runs/{runId}/analyze` (no `force`) → assert the response carries `caseAnalyses[]` and `partialFailures` is empty → POST again without `force` → assert the response is byte-for-byte identical (same `generatedAt`) and a Bedrock-call counter (CloudWatch metric or stack-test helper) shows zero new invocations between the two calls.
  - Per-case Re-analyze override: POST `/runs/{runId}/analyze` with `{ force: true }` → assert `generatedAt` is newer than the persisted value AND the Bedrock-call counter advances by one per failed case.
  - Per-suite end-to-end persisted-read shortcut: POST `/runs/{runId}/recommend-suite` (no `force`) → assert response carries `recommendations[]` (length ≥ 0) and is sorted by monotonic priority → POST again without `force` → assert byte-for-byte identical and Bedrock-call counter does not advance.
  - Per-suite Re-analyze override: POST with `{ force: true }` → assert `generatedAt` advances and Bedrock-call counter advances.
  - Snapshot examples flow: trigger a run against an agent with at least one tool carrying examples → assert `GET /runs/{runId}/snapshot` returns the examples → assert the per-case prompt (verifiable via a debug log if the Lambda exposes one, otherwise via a shadow handler) included an `Examples:` block for that tool.
  - _Requirements: 6.2, 6.3, 8.7, 8.8, 9.3, 10.9, 11.3_

- [x] 15. Verification — full build, full test suite, frontend build, CDK synth
  - Run `npx tsc --noEmit` from the repository root and confirm zero new TypeScript errors across `src/`, `lib/`, and `tests/`.
  - Run `npx vitest run` from the repository root and confirm all unit tests, all six property tests, and the integration tests pass; flag any test that newly skips or runs zero iterations.
  - Run the frontend production build (`npm run build` in `src/frontend/` or whatever the root build script invokes for the frontend asset bundle) and confirm zero new lint or type errors and that the bundle builds.
  - Run `npx cdk synth` and inspect the output for the new `suiteRecommendLambda` resource AND the new `/runs/{runId}/recommend-suite` API Gateway route AND the upgraded `analysisLambda` IAM grant (`grantReadWriteData` rather than `grantReadData`); compare against `cdk.out/ConnectAgentTestPlatformStack.template.json` to confirm no unrelated CloudFormation drift.
  - Update the existing infrastructure snapshot test under `tests/infrastructure/cdk-stack.test.ts` if needed so it includes the new Lambda, the new route, and the IAM upgrade — assertions, not just snapshot.
  - Confirm there is no leftover use of the legacy `individualAnalyses`/`groupedAnalyses` shape across the codebase (`grep -r "individualAnalyses" src/` should return zero results outside this tasks file's history).
  - _Requirements: All — final integration verification across R1–R15_

## Notes

- Every task is a leaf and references absolute file paths from the design's Reuse Map. Sub-bullets are details and notes only.
- Tasks sharing a numeric prefix (2.1/2.2, 10.1/10.2/10.3/10.4, 12.1–12.7, 13.1–13.6) touch independent files and can be assigned to different engineers in parallel.
- Property tests are single-leaf tasks per the user's authoring guidance so each property's pass/fail is independently visible in CI.
- Tasks 6 and 7 both depend on the failure-grouping extraction (task 5) and the bucketing util (task 4); the dependency graph below puts those utilities in an earlier wave than the handler updates that consume them.
- Task 15 is the final verification task per the workflow's completion guidance; it does not write new product code, only verifies the build artifact integrity end-to-end.
- All tasks reference the requirements they satisfy via the `_Requirements:` footer, including the granular sub-requirement numbers (e.g. 5.7, 5.8) rather than the parent requirement number alone.

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1"] },
    { "id": 1, "tasks": ["2.1", "2.2"] },
    { "id": 2, "tasks": ["3", "4", "5"] },
    { "id": 3, "tasks": ["6", "7"] },
    { "id": 4, "tasks": ["8"] },
    { "id": 5, "tasks": ["9"] },
    { "id": 6, "tasks": ["10.1", "10.2", "10.3", "10.4"] },
    { "id": 7, "tasks": ["11"] },
    { "id": 8, "tasks": ["12.1", "12.2", "12.3", "12.4", "12.5", "12.6", "12.7"] },
    { "id": 9, "tasks": ["13.1", "13.2", "13.3", "13.4", "13.5", "13.6"] },
    { "id": 10, "tasks": ["14"] },
    { "id": 11, "tasks": ["15"] }
  ]
}
```
