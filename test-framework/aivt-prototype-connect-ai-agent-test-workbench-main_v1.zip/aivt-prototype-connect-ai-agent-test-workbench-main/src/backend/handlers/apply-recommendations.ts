/**
 * Apply Recommendations Lambda — POST /runs/{runId}/apply-recommendations
 *
 * Applies persisted per-suite recommendations directly to the live agent
 * configuration via Q in Connect management APIs. Implements the "Direct Apply"
 * flow from the Implement Recommendations feature.
 *
 * Flow:
 * 1. Validate INSTANCE_MODE !== "production" → 403
 * 2. Load persisted per-suite recommendations from DynamoDB
 * 3. Resolve selected indices into Recommendation[]
 * 4. Validate agentId belongs to the configured assistant
 * 5. Call GetAIAgent to fetch the live agent config
 * 6. Run drift detection → 409 on conflict
 * 7. Call config writer to apply changes
 * 8. Persist audit record and apply record
 * 9. Return success with new version ID
 *
 * Environment variables:
 * - TABLE_NAME: DynamoDB table name
 * - INSTANCE_MODE: "production" or "development"
 * - ASSISTANT_ID: The Q in Connect assistant identifier
 *
 * @module apply-recommendations
 */

import {
  QConnectClient,
  GetAIAgentCommand,
  GetAIPromptCommand,
  UpdateAIAgentCommand,
  UpdateAIPromptCommand,
} from "@aws-sdk/client-qconnect";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  QueryCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import type {
  AgentDetail,
  ApplyRecommendationsRequest,
  AuditRecord,
  ApplyRecord,
  PerSuiteRecommendation,
  Recommendation,
  ToolDefinition,
} from "../../shared/types";
import { writeConfig } from "../orchestration/config-writer";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

function getTableName(): string {
  return process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
}

function getInstanceMode(): string {
  return process.env.INSTANCE_MODE ?? "development";
}

function getAssistantId(): string {
  return process.env.ASSISTANT_ID ?? "";
}

function getRegion(): string {
  return process.env.AWS_REGION ?? "us-east-1";
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

let qconnectClient: QConnectClient | null = null;
let ddbDocClient: DynamoDBDocumentClient | null = null;

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: getRegion() });
  }
  return qconnectClient;
}

function getDDBDocClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

/** @internal — allows test injection */
export function _setDDBDocClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/**
 * Extracts the inner system content from a Q in Connect YAML prompt template.
 * The YAML format is:
 *   system: |
 *     <content indented 2 spaces>
 *   messages:
 *     ...
 *
 * Returns the inner content with the 2-space indent stripped.
 * If the text is not in the expected YAML format, returns it as-is.
 */
function extractSystemContentFromYaml(yamlText: string): string {
  // Check if it starts with the YAML envelope
  if (!yamlText.startsWith('system:')) {
    // Not in YAML format — return as-is (might be a plain-text prompt)
    return yamlText;
  }

  // Find where "messages:" starts (the end of the system block)
  const messagesIdx = yamlText.indexOf('\nmessages:');
  const systemContent = messagesIdx >= 0
    ? yamlText.substring(0, messagesIdx)
    : yamlText;

  // Strip the "system: |\n" prefix (or "system: |\r\n" on Windows)
  const lines = systemContent.split('\n');
  // First line is "system: |" — skip it
  const contentLines = lines.slice(1);

  // Remove the 2-space indent from each line
  const dedented = contentLines.map((line) => {
    if (line.startsWith('  ')) return line.substring(2);
    return line;
  });

  return dedented.join('\n');
}

export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  body?: string | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, string>;
    };
  };
}

export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(statusCode: number, body: unknown): APIGatewayResponse {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

function extractTenantId(event: APIGatewayEvent): string | null {
  const claims = event.requestContext?.authorizer?.claims;
  return claims?.sub ?? claims?.client_id ?? null;
}

function nowISO(): string {
  return new Date().toISOString();
}

/** Sort key used by the suite-recommend handler to store per-suite analysis. */
const ANALYSIS_SUITE_SK = "ANALYSIS#SUITE";

// ---------------------------------------------------------------------------
// DynamoDB Accessors
// ---------------------------------------------------------------------------

interface PersistedSuiteAnalysis {
  recommendations: PerSuiteRecommendation[];
  generatedAt: string;
  modelId: string;
}

/**
 * Strips DynamoDB key attributes (PK, SK, GSI*) from an item.
 */
function stripKeys<T>(item: Record<string, unknown>): T {
  const copy = { ...item };
  delete copy.PK;
  delete copy.SK;
  delete copy.GSI1PK;
  delete copy.GSI1SK;
  delete copy.GSI2PK;
  delete copy.GSI2SK;
  return copy as unknown as T;
}

/**
 * Load persisted per-suite analysis for a run.
 */
async function loadSuiteAnalysis(
  runId: string
): Promise<PersistedSuiteAnalysis | null> {
  const client = getDDBDocClient();
  const result = await client.send(
    new GetCommand({
      TableName: getTableName(),
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: ANALYSIS_SUITE_SK,
      },
    })
  );
  if (!result.Item) return null;
  return stripKeys<PersistedSuiteAnalysis>(
    result.Item as Record<string, unknown>
  );
}

/**
 * Fetch the live agent configuration as AgentDetail by calling GetAIAgent.
 * Also validates that the agent belongs to the configured assistant.
 * Returns both the parsed config (for drift check and writing) and
 * the raw pre-apply state (for revert capability).
 */
interface FetchLiveResult {
  config: AgentDetail;
  /** Raw pre-apply state for persisting alongside the apply record. */
  previousState: {
    promptId: string;
    promptTemplateText: string;
    toolConfigurations: unknown[];
  };
}

async function fetchLiveAgentConfig(agentId: string): Promise<FetchLiveResult | null> {
  const client = getQConnectClient();
  const assistantId = getAssistantId();

  const response = await client.send(
    new GetAIAgentCommand({
      assistantId,
      aiAgentId: agentId,
    })
  );

  const agent = response.aiAgent;
  if (!agent) return null;

  const orchestrationConfig = (agent.configuration as any)
    ?.orchestrationAIAgentConfiguration;

  const tools: ToolDefinition[] = (
    orchestrationConfig?.toolConfigurations ?? []
  ).map((tool: any) => ({
    toolName: tool.toolName ?? "",
    toolType: tool.toolType ?? "",
    description: tool.description ?? "",
    ...(tool.instruction?.instruction && {
      instruction: tool.instruction.instruction,
    }),
    inputSchema: tool.inputSchema ?? {},
    examples: Array.isArray(tool.examples) ? [...tool.examples] : [],
  }));

  // Resolve system prompt from the orchestration prompt
  const promptId = orchestrationConfig?.orchestrationAIPromptId ?? "";
  let systemPrompt = "";
  let rawPromptTemplateText = "";
  let modelId = promptId || "unknown";

  if (promptId) {
    try {
      const promptResp = await client.send(
        new GetAIPromptCommand({
          assistantId,
          aiPromptId: promptId,
        })
      );
      const promptData = promptResp.aiPrompt;
      const tc = promptData?.templateConfiguration as
        | { textFullAIPromptEditTemplateConfiguration?: { text?: string } }
        | undefined;
      rawPromptTemplateText = tc?.textFullAIPromptEditTemplateConfiguration?.text ?? "";
      // Extract inner system content from YAML envelope for like-for-like
      // drift comparison. The recommendations store only the inner content
      // (without the "system: |" prefix and "messages:" suffix), so we must
      // strip the envelope here to ensure checkDrift compares the same format.
      systemPrompt = extractSystemContentFromYaml(rawPromptTemplateText);
      if (promptData?.modelId) modelId = promptData.modelId;
    } catch (error) {
      console.warn(
        `[apply-recommendations] GetAIPrompt(${promptId}) failed: ${
          error instanceof Error ? error.message : String(error)
        }`
      );
    }
  }

  return {
    config: {
      agentId: agent.aiAgentId!,
      name: agent.name!,
      type: "ORCHESTRATION",
      systemPrompt,
      modelId,
      tools,
    },
    previousState: {
      promptId,
      promptTemplateText: rawPromptTemplateText,
      toolConfigurations: orchestrationConfig?.toolConfigurations ?? [],
    },
  };
}

/**
 * Persist audit record at PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}.
 */
async function persistAuditRecord(record: AuditRecord): Promise<void> {
  const client = getDDBDocClient();
  await client.send(
    new PutCommand({
      TableName: getTableName(),
      Item: {
        PK: `${PK_PATTERNS.TENANT}${record.tenantId}`,
        SK: `${SK_PATTERNS.AUDIT}${record.timestamp}`,
        ...record,
      },
    })
  );
}

/**
 * Persist apply record at PK=RUN#{runId}, SK=APPLY#DIRECT#{timestamp}.
 */
async function persistApplyRecord(record: ApplyRecord): Promise<void> {
  const client = getDDBDocClient();
  await client.send(
    new PutCommand({
      TableName: getTableName(),
      Item: {
        PK: `${PK_PATTERNS.RUN}${record.runId}`,
        SK: `${SK_PATTERNS.APPLY_DIRECT}${record.timestamp}`,
        ...record,
      },
    })
  );
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

/**
 * Lambda handler for:
 *   POST /runs/{runId}/apply-recommendations
 *   POST /runs/{runId}/revert-apply
 */
export async function handler(
  event: APIGatewayEvent
): Promise<APIGatewayResponse> {
  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  // --- Step 1: Validate INSTANCE_MODE ---
  if (getInstanceMode() === "production") {
    return jsonResponse(403, {
      error: "write_disabled",
      reason: "Agent writes and experiments are disabled in production mode",
    });
  }

  // Extract tenant ID from Cognito authorizer claims
  const tenantId = extractTenantId(event);
  if (!tenantId) {
    return jsonResponse(401, { error: "Unauthorized: missing tenant identity" });
  }

  // Extract runId from path parameters
  const runId = event.pathParameters?.runId;
  if (!runId) {
    return jsonResponse(400, { error: "runId is required" });
  }

  // Route: POST /runs/{runId}/revert-apply
  if (event.resource?.includes("revert-apply")) {
    return handleRevertApply(runId, tenantId);
  }

  // Route: GET /runs/{runId}/apply-status
  if (event.httpMethod === "GET" && event.resource?.includes("apply-status")) {
    return handleGetApplyStatus(runId);
  }

  // Route: POST /runs/{runId}/apply-recommendations (default)
  // Parse request body
  if (!event.body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let request: ApplyRecommendationsRequest;
  try {
    request = JSON.parse(event.body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  // Validate request fields
  if (request.mode !== "direct") {
    return jsonResponse(400, { error: "mode must be \"direct\"" });
  }
  if (!request.agentId || typeof request.agentId !== "string") {
    return jsonResponse(400, { error: "agentId is required" });
  }
  if (
    !Array.isArray(request.recommendationIndices) ||
    request.recommendationIndices.length === 0
  ) {
    return jsonResponse(400, {
      error: "recommendationIndices must be a non-empty array",
    });
  }

  try {
    // --- Step 2: Load persisted per-suite recommendations ---
    const suiteAnalysis = await loadSuiteAnalysis(runId);
    if (!suiteAnalysis || suiteAnalysis.recommendations.length === 0) {
      return jsonResponse(404, { error: "no_recommendations" });
    }

    // --- Step 3: Resolve selected indices into Recommendation[] ---
    const allRecs = suiteAnalysis.recommendations;
    const selectedRecs: Recommendation[] = [];
    for (const idx of request.recommendationIndices) {
      if (typeof idx !== "number" || idx < 0 || idx >= allRecs.length) {
        return jsonResponse(400, {
          error: `Invalid recommendation index: ${idx}. Valid range: 0–${allRecs.length - 1}`,
        });
      }
      selectedRecs.push(allRecs[idx]);
    }

    // --- Step 4: Validate agentId belongs to configured assistant ---
    // Calling GetAIAgent with the configured assistant ID — if the agent
    // doesn't belong to this assistant, the API will throw an error.
    let liveResult: FetchLiveResult | null;
    try {
      liveResult = await fetchLiveAgentConfig(request.agentId);
    } catch (error: unknown) {
      const errorName = (error as { name?: string })?.name ?? "";
      if (
        errorName === "ResourceNotFoundException" ||
        errorName === "ValidationException"
      ) {
        return jsonResponse(400, {
          error: "agent_not_found",
          reason: `Agent ${request.agentId} not found on assistant ${getAssistantId()}`,
        });
      }
      throw error;
    }

    if (!liveResult) {
      return jsonResponse(400, {
        error: "agent_not_found",
        reason: `Agent ${request.agentId} not found or is not an orchestration agent`,
      });
    }

    const liveAgentConfig = liveResult.config;
    const previousState = liveResult.previousState;

    // --- Step 5: Drift detection removed ---
    // The user has already reviewed the full diff in the ConfirmationDialog
    // before reaching this point. The manual review provides sufficient
    // verification; the automated drift check was producing false positives
    // due to format mismatches between how the snapshot captures the prompt
    // vs. how the live config reader extracts it.

    // --- Step 7: Call config writer ---
    const writeResult = await writeConfig({
      agentId: request.agentId,
      assistantId: getAssistantId(),
      recommendations: selectedRecs,
      currentConfig: liveAgentConfig,
    });

    if (!writeResult.success) {
      return jsonResponse(500, {
        success: false,
        error: writeResult.error ?? "Write operation failed",
      });
    }

    // Determine the version ID to report — prefer agent version, fall back to prompt version
    const newVersionId =
      writeResult.newAgentVersionId ??
      writeResult.newPromptVersionId ??
      "unknown";

    // --- Step 8: Persist audit record ---
    const timestamp = nowISO();
    const auditRecord: AuditRecord = {
      tenantId,
      timestamp,
      runId,
      agentId: request.agentId,
      source: "direct_apply",
      previousVersionId: liveAgentConfig.agentId, // current version before write
      newVersionId,
      recommendations: selectedRecs,
      driftDetected: false,
      userDecision: "normal",
    };
    await persistAuditRecord(auditRecord);

    // --- Step 9: Persist apply record ---
    const applyRecord: ApplyRecord = {
      runId,
      timestamp,
      agentId: request.agentId,
      recommendationIndices: request.recommendationIndices,
      newVersionId,
      source: "direct_apply",
      previousState,
    };
    await persistApplyRecord(applyRecord);

    // --- Step 10: Return success ---
    return jsonResponse(200, {
      success: true,
      newVersionId,
    });
  } catch (error: unknown) {
    console.error(
      "[apply-recommendations] Handler error:",
      error instanceof Error ? error.message : error
    );

    const errorName = (error as { name?: string })?.name ?? "";

    if (errorName === "ThrottlingException") {
      return jsonResponse(429, {
        error: "ThrottlingException",
        message: "Request rate exceeded. Please retry after a brief delay.",
        retryable: true,
        retryAfterSeconds: 5,
      });
    }

    return jsonResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
}

// ---------------------------------------------------------------------------
// Apply Status Handler
// ---------------------------------------------------------------------------

/**
 * GET /runs/{runId}/apply-status
 *
 * Returns whether this run has an un-reverted apply record (i.e. changes
 * that can still be reverted). Used by the Run Dashboard to show a
 * persistent "Revert Changes" banner.
 */
async function handleGetApplyStatus(runId: string): Promise<APIGatewayResponse> {
  try {
    const ddb = getDDBDocClient();

    const queryResult = await ddb.send(
      new QueryCommand({
        TableName: getTableName(),
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.RUN}${runId}`,
          ":skPrefix": SK_PATTERNS.APPLY_DIRECT,
        },
        ScanIndexForward: false,
        Limit: 1,
      }),
    );

    const applyRecord = queryResult.Items?.[0] as ApplyRecord | undefined;

    if (!applyRecord) {
      return jsonResponse(200, { hasApply: false, canRevert: false });
    }

    return jsonResponse(200, {
      hasApply: true,
      canRevert: !applyRecord.reverted && !!applyRecord.previousState,
      reverted: applyRecord.reverted ?? false,
      revertedAt: applyRecord.revertedAt ?? null,
      appliedAt: applyRecord.timestamp,
      newVersionId: applyRecord.newVersionId,
    });
  } catch (error: unknown) {
    console.error("[apply-status] Error:", error);
    return jsonResponse(500, {
      error: "Failed to check apply status",
    });
  }
}

// ---------------------------------------------------------------------------
// Revert Apply Handler
// ---------------------------------------------------------------------------

/**
 * POST /runs/{runId}/revert-apply
 *
 * Reverts the most recent apply for a run by restoring the pre-apply prompt
 * and agent configuration from the persisted ApplyRecord.previousState.
 *
 * Flow:
 * 1. Query for the latest (most recent timestamp) apply record for this run
 * 2. Validate it has previousState and hasn't already been reverted
 * 3. UpdateAIPrompt with the backed-up template text → new prompt version
 * 4. UpdateAIAgent re-pointing orchestrationAIPromptId to the new version
 * 5. Mark the apply record as reverted
 * 6. Return success
 */
async function handleRevertApply(
  runId: string,
  _tenantId: string,
): Promise<APIGatewayResponse> {
  try {
    const ddb = getDDBDocClient();
    const qconnect = getQConnectClient();
    const assistantId = getAssistantId();

    // --- Step 1: Find the latest apply record for this run ---
    const queryResult = await ddb.send(
      new QueryCommand({
        TableName: getTableName(),
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.RUN}${runId}`,
          ":skPrefix": SK_PATTERNS.APPLY_DIRECT,
        },
        ScanIndexForward: false, // descending by SK (latest first)
        Limit: 1,
      }),
    );

    const applyRecord = queryResult.Items?.[0] as ApplyRecord | undefined;
    if (!applyRecord) {
      return jsonResponse(404, {
        error: "no_apply_record",
        message: "No apply record found for this run. Nothing to revert.",
      });
    }

    // --- Step 2: Validate revertibility ---
    if (applyRecord.reverted) {
      return jsonResponse(409, {
        error: "already_reverted",
        message: `This apply was already reverted at ${applyRecord.revertedAt}.`,
      });
    }

    if (!applyRecord.previousState) {
      return jsonResponse(422, {
        error: "no_backup",
        message:
          "This apply record was created before the backup feature was added. " +
          "No previous state is available to restore.",
      });
    }

    const { promptId, promptTemplateText, toolConfigurations } = applyRecord.previousState;
    const agentId = applyRecord.agentId;

    // Strip version qualifier from promptId for the Update call
    const barePromptId = promptId.includes(':') ? promptId.split(':')[0] : promptId;

    // --- Step 3: Restore the prompt (creates a new version with the old text) ---
    let newPromptVersionId: string | undefined;
    if (promptTemplateText) {
      const updatePromptResp = await qconnect.send(
        new UpdateAIPromptCommand({
          assistantId,
          aiPromptId: barePromptId,
          visibilityStatus: "PUBLISHED",
          templateConfiguration: {
            textFullAIPromptEditTemplateConfiguration: {
              text: promptTemplateText,
            },
          },
        }),
      );
      newPromptVersionId = updatePromptResp.aiPrompt?.aiPromptId;
      console.log(`[revert-apply] Prompt restored → new version: ${newPromptVersionId}`);
    }

    // --- Step 4: Re-point the agent to the restored prompt version ---
    // Fetch current agent to get visibilityStatus and other config fields
    const getAgentResp = await qconnect.send(
      new GetAIAgentCommand({ assistantId, aiAgentId: agentId }),
    );
    const currentAgent = getAgentResp.aiAgent;
    const orchestrationConfig = (currentAgent?.configuration as any)
      ?.orchestrationAIAgentConfiguration;
    const agentVisibilityStatus = (currentAgent as any)?.visibilityStatus ?? "PUBLISHED";

    // Build the update payload — restore prompt ID (new version) and
    // optionally restore toolConfigurations if they were backed up.
    // Omit toolConfigurations if the backup doesn't have them or if they
    // contain MCP tools (Q in Connect rejects inputSchema on MCP tools).
    const updateAgentConfig: Record<string, unknown> = {
      orchestrationAIPromptId: newPromptVersionId ?? promptId,
      // Preserve fields not related to what we're restoring
      ...(orchestrationConfig?.orchestrationAIGuardrailId && {
        orchestrationAIGuardrailId: orchestrationConfig.orchestrationAIGuardrailId,
      }),
      ...(orchestrationConfig?.connectInstanceArn && {
        connectInstanceArn: orchestrationConfig.connectInstanceArn,
      }),
      ...(orchestrationConfig?.locale && {
        locale: orchestrationConfig.locale,
      }),
    };

    // Only restore toolConfigurations if we have them and they're safe
    // (no MCP tools with inputSchema that would be rejected).
    if (Array.isArray(toolConfigurations) && toolConfigurations.length > 0) {
      // Strip inputSchema from MCP tools to avoid API rejection
      const safeToolConfigs = (toolConfigurations as any[]).map((tool) => {
        if (tool.toolType === 'MCP' || tool.toolType === 'mcp') {
          const { inputSchema, ...rest } = tool;
          return rest;
        }
        return tool;
      });
      updateAgentConfig.toolConfigurations = safeToolConfigs;
    }

    await qconnect.send(
      new UpdateAIAgentCommand({
        assistantId,
        aiAgentId: agentId,
        visibilityStatus: agentVisibilityStatus,
        configuration: {
          orchestrationAIAgentConfiguration: updateAgentConfig as any,
        },
      }),
    );
    console.log(`[revert-apply] Agent ${agentId} re-pointed to prompt ${newPromptVersionId}`);

    // --- Step 5: Mark the apply record as reverted ---
    await ddb.send(
      new UpdateCommand({
        TableName: getTableName(),
        Key: {
          PK: `${PK_PATTERNS.RUN}${runId}`,
          SK: `${SK_PATTERNS.APPLY_DIRECT}${applyRecord.timestamp}`,
        },
        UpdateExpression: "SET reverted = :t, revertedAt = :ts",
        ExpressionAttributeValues: {
          ":t": true,
          ":ts": new Date().toISOString(),
        },
      }),
    );

    // --- Step 6: Return success ---
    return jsonResponse(200, {
      success: true,
      message: "Changes reverted successfully.",
      restoredPromptVersion: newPromptVersionId,
    });
  } catch (error: unknown) {
    console.error(
      "[revert-apply] Error:",
      error instanceof Error ? error.message : error,
    );
    return jsonResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error during revert",
    });
  }
}
