/**
 * ImplementButton — entry-point component for the Implement Recommendations
 * flow. Renders an "Implement Recommendations" button that opens the
 * ModeSelector dialog when clicked.
 *
 * Visibility rules (Requirements 1.1, 1.2, 1.4, 19.2):
 *   - Hidden when instanceMode === "production"
 *   - Hidden when hasRecommendations === false
 *   - Hidden when runStatus === "running"
 *
 * Disabled state (Requirement 1.5):
 *   - While the run is still active the button is hidden outright (per R1.4
 *     the button is not rendered when no recommendations exist yet, and a
 *     running run hasn't produced final recommendations). If a future
 *     iteration renders the button before the run completes, it would be
 *     disabled with a tooltip "Available after the run completes".
 *
 * @module components/ImplementRecommendations/ImplementButton
 */

import { useState } from 'react';
import Button from '@cloudscape-design/components/button';
import Popover from '@cloudscape-design/components/popover';
import { RunStatus } from '../../../../shared/enums';
import { ModeSelector } from './ModeSelector';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface ImplementButtonProps {
  runId: string;
  suiteId: string;
  agentId: string;
  hasRecommendations: boolean;
  runStatus: RunStatus;
  instanceMode: 'production' | 'development';
  /** Callback when "Apply directly" is selected in the mode dialog. */
  onDirectApply?: () => void;
  /** Callback when "Advanced: Multi-variant experiment" is selected. */
  onExperiment?: () => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function ImplementButton({
  runId: _runId,
  suiteId: _suiteId,
  agentId: _agentId,
  hasRecommendations,
  runStatus,
  instanceMode,
  onDirectApply,
  onExperiment,
}: ImplementButtonProps): JSX.Element | null {
  const [modeSelectorVisible, setModeSelectorVisible] = useState(false);

  // These will be passed to confirmation/experiment flows in future tasks.
  void _runId;
  void _suiteId;
  void _agentId;

  // --- Visibility gates (R1.4, R19.2) ---
  // Hidden when production mode — write operations are disabled entirely.
  if (instanceMode === 'production') {
    return null;
  }

  // Hidden when no recommendations exist for this run.
  if (!hasRecommendations) {
    return null;
  }

  // Hidden when the run is still in progress — recommendations are not
  // finalized until the run completes.
  if (runStatus === RunStatus.RUNNING) {
    return null;
  }

  // --- Disabled state: run not yet terminal (R1.5) ---
  // In the current flow the button is hidden during running (early return
  // above), so this point is only reached for terminal statuses.
  // The disabled state is kept as a defensive fallback for any future
  // render path that might reach here with a non-terminal status.
  const isDisabled = false;

  // Wrap in popover for the tooltip when disabled.
  const button = (
    <Button
      variant="primary"
      disabled={isDisabled}
      onClick={() => setModeSelectorVisible(true)}
      ariaLabel="Implement recommendations"
    >
      Implement Recommendations
    </Button>
  );

  return (
    <>
      {isDisabled ? (
        <Popover
          dismissButton={false}
          position="top"
          size="small"
          triggerType="custom"
          content="Available after the run completes"
        >
          {button}
        </Popover>
      ) : (
        button
      )}

      <ModeSelector
        visible={modeSelectorVisible}
        onDismiss={() => setModeSelectorVisible(false)}
        onDirectApply={() => {
          setModeSelectorVisible(false);
          onDirectApply?.();
        }}
        onExperiment={() => {
          setModeSelectorVisible(false);
          onExperiment?.();
        }}
      />
    </>
  );
}
