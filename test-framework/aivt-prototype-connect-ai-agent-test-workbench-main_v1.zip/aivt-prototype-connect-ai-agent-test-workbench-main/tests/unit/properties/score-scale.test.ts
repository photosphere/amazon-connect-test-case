// Feature: bedrock-judge-evaluations, Property 3: Score-scale mapping is total and in-range
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import {
  GOAL_SUCCESS_SCALE,
  TOOL_SELECTION_SCALE,
  HELPFULNESS_SCALE,
  mapScoreLabel,
} from '../../../src/shared/utils/evaluation-scoring';

/**
 * Property test for the three Bedrock-judge `Score_Scale` tables.
 *
 * The Score_Scale tables (`GOAL_SUCCESS_SCALE`, `TOOL_SELECTION_SCALE`,
 * `HELPFULNESS_SCALE`) and the `mapScoreLabel(scale, label)` helper added
 * under task 2.2 form the categorical-label → `[0.0, 1.0]` boundary
 * between the Bedrock-judge response and the persisted scores.
 *
 * Property 3: Score-scale mapping is total and in-range
 *
 * **Validates: Requirements 4.1, 4.2, 4.4, 8.3**
 *
 * For every supported scale, this property covers four facets at once so
 * the contract holds across the full label space:
 *
 *   (a) **Total over in-scale labels**: every label that IS a key of the
 *       scale maps to a finite number in `[0.0, 1.0]`. Validates Reqs 4.1
 *       (the three tables exist with the stated values), 4.2 (every
 *       defined label maps to a finite decimal in the inclusive range),
 *       and 8.3 (every persisted score lies in `[0.0, 1.0]`).
 *   (b) **Refusal on out-of-scale labels**: every synthetic label that is
 *       NOT a key of the scale resolves to `undefined` — never a silent
 *       zero, never a default. Validates Req 4.4 (unmappable labels
 *       SHALL surface as `Evaluation_Error_State` `UNMAPPABLE_RESULT`,
 *       which means callers must be able to detect the unmapped case).
 *   (c) **Determinism**: calling `mapScoreLabel(scale, label)` twice with
 *       the same arguments returns the same value. Reinforces 4.2 by
 *       guaranteeing the mapping is a (pure) function.
 *   (d) **Well-formedness of the constants**: every directly-defined
 *       value in each scale table is itself a finite number in
 *       `[0.0, 1.0]`. Reinforces 4.1 / 4.2 by asserting on the
 *       constants directly rather than only through `mapScoreLabel`.
 *
 * The module under test is pure and has no AWS imports, so this test
 * exercises its real behaviour without any mocking.
 */

const ALL_SCALES: ReadonlyArray<readonly [string, Readonly<Record<string, number>>]> = [
  ['GOAL_SUCCESS_SCALE', GOAL_SUCCESS_SCALE],
  ['TOOL_SELECTION_SCALE', TOOL_SELECTION_SCALE],
  ['HELPFULNESS_SCALE', HELPFULNESS_SCALE],
];

describe('Property 3: Score-scale mapping is total and in-range', () => {
  for (const [scaleName, scale] of ALL_SCALES) {
    describe(scaleName, () => {
      const scaleKeys = Object.keys(scale);

      // -----------------------------------------------------------------
      // (d) Well-formedness check on the directly-defined constants.
      //
      // Asserted once per scale (not inside the property loop) so that a
      // hand-edited scale value that is e.g. NaN, -1, or 1.5 fails fast
      // with a clear message rather than only manifesting through
      // `mapScoreLabel`.
      // -----------------------------------------------------------------
      it('every directly-defined scale value is finite and within [0.0, 1.0]', () => {
        expect(scaleKeys.length).toBeGreaterThan(0);
        for (const key of scaleKeys) {
          const v = scale[key];
          expect(Number.isFinite(v)).toBe(true);
          expect(v).toBeGreaterThanOrEqual(0);
          expect(v).toBeLessThanOrEqual(1);
        }
      });

      // -----------------------------------------------------------------
      // (a) In-scale labels: total mapping into [0,1] (Req 4.1, 4.2, 8.3)
      // (c) Determinism: same input → same output (Req 4.2)
      //
      // We pick uniformly from the actual keys of the scale so every
      // defined label is exercised across `numRuns` iterations.
      // -----------------------------------------------------------------
      it('every in-scale label maps to a finite number in [0.0, 1.0] and is deterministic', () => {
        fc.assert(
          fc.property(fc.constantFrom(...scaleKeys), (label) => {
            const first = mapScoreLabel(scale, label);
            const second = mapScoreLabel(scale, label);

            // Determinism (c).
            expect(second).toBe(first);

            // Total + in-range (a).
            expect(first).toBeDefined();
            expect(typeof first).toBe('number');
            expect(Number.isFinite(first as number)).toBe(true);
            expect(first as number).toBeGreaterThanOrEqual(0);
            expect(first as number).toBeLessThanOrEqual(1);

            // Self-consistency: `mapScoreLabel` returns exactly the
            // value the constant defines for that key — no normalization
            // or transformation is applied.
            expect(first).toBe(scale[label]);
          }),
          { numRuns: 100 }
        );
      });

      // -----------------------------------------------------------------
      // (b) Out-of-scale labels: refusal — must return `undefined`
      //     (Req 4.4: no silent zero, no default).
      // (c) Determinism on the refusal path as well.
      //
      // Generator strategy: arbitrary string filtered to exclude any
      // string that is a key of the scale. We use `fc.string()` rather
      // than a constrained subset so the property exercises Unicode,
      // empty-string, whitespace, and inherited-property-name inputs
      // (e.g. `toString`, `constructor`) — all of which Req 4.4 demands
      // be unmappable rather than aliased to an in-scale entry.
      // -----------------------------------------------------------------
      it('every synthetic out-of-scale label returns undefined and is deterministic', () => {
        const scaleKeySet = new Set(scaleKeys);
        const outOfScaleLabelArb = fc
          .string()
          .filter((s) => !scaleKeySet.has(s));

        fc.assert(
          fc.property(outOfScaleLabelArb, (label) => {
            const first = mapScoreLabel(scale, label);
            const second = mapScoreLabel(scale, label);

            // Determinism (c) on the refusal path.
            expect(second).toBe(first);

            // Refusal (b): never a number — including not zero — when the
            // label is not a defined key of the scale.
            expect(first).toBeUndefined();
          }),
          { numRuns: 100 }
        );
      });
    });
  }
});
