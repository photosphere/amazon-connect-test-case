/**
 * CDK assertions for the OrchestrationConstruct's Bedrock_Judge wiring.
 *
 * Validates Requirements 6.1, 6.2, 6.6, 6.7, 6.8 — the configured
 * Judge_Model context value propagates onto the synthesised
 * `JudgeModelId` CFN output, no IAM policy in the synthesised stack
 * carries an AgentCore action or a `bedrock:*` wildcard, and synth
 * fails fast on an empty or unrecognized-prefix `judgeModelId`.
 *
 * The narrow `BedrockJudgeConverse` IAM grant that historically appeared
 * on the Evaluation Lambda role was retired in Task 20.2 of the
 * prompt-management spec (Req 19.2): the registry-derived Bedrock grant
 * produced by `computeBedrockGrants` is now the only Bedrock
 * `InvokeModel` / `Converse` statement on that role. Set-equality of
 * that statement against the registry's expected union is asserted by
 * `tests/cdk/bedrock-grants.test.ts` (Task 10.6).
 *
 * The `JUDGE_MODEL_ID` Lambda environment variable that historically
 * propagated the configured Judge_Model id to the Evaluation Lambda's
 * runtime was retired in Task 20.3 of the same spec (Req 1.4): the
 * Bedrock_Judge_Client now resolves the per-judge model id and
 * inference parameters through the Prompt_Registry's run-pinned
 * snapshot (`resolvePromptForRun`) rather than from an env var. The
 * synth-time validation in `resolveJudgeModelGrants` remains because
 * it still enforces R6.7 (empty / whitespace-only fails synth) and
 * R6.8 (unrecognized prefix fails synth) on the `judgeModelId` CDK
 * context value, and the `JudgeModelId` CFN output remains as a
 * deployment-review artifact. The tests below assert against that
 * output rather than the retired env var.
 */
import * as path from 'path';
import { describe, it, expect, vi } from 'vitest';
import * as cdk from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';

// Mirror cdk-stack.test.ts: stub NodejsFunction so esbuild bundling doesn't run
// during synth. Tests own the surface they exercise.
vi.mock('aws-cdk-lib/aws-lambda-nodejs', () => {
  const lambda = require('aws-cdk-lib/aws-lambda');

  class NodejsFunction extends lambda.Function {
    constructor(scope: any, id: string, props: any) {
      super(scope, id, {
        ...props,
        code: lambda.Code.fromInline('exports.handler = async () => {}'),
        handler: 'index.handler',
        runtime: props?.runtime ?? lambda.Runtime.NODEJS_20_X,
      });
    }
  }

  return { NodejsFunction };
});

import { ConnectAgentTestPlatformStack } from '../../lib/connect-agent-test-platform-stack';
import { resolveJudgeModelGrants } from '../../lib/orchestration-construct';

const MOCK_CONNECT_INSTANCE_ID = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890';
const FIXTURE_BUILD_DIR = path.resolve(__dirname, 'fixtures/frontend-dist');

const DEFAULT_JUDGE_MODEL_ID = 'us.anthropic.claude-sonnet-4-6';

interface SynthOptions {
  judgeModelId?: string | null;
}

/**
 * Synthesize the platform stack, optionally overriding the `judgeModelId` CDK
 * context key. Pass `null` to leave the context key absent (the construct then
 * falls back to its default).
 */
function synthStack(opts: SynthOptions = {}): cdk.Stack {
  const app = new cdk.App();
  if (opts.judgeModelId !== undefined && opts.judgeModelId !== null) {
    app.node.setContext('judgeModelId', opts.judgeModelId);
  }
  return new ConnectAgentTestPlatformStack(app, 'TestStack', {
    connectInstanceId: MOCK_CONNECT_INSTANCE_ID,
    callbackUrls: ['http://localhost:5173'],
    frontendBuildDir: FIXTURE_BUILD_DIR,
    env: { account: '123456789012', region: 'us-east-1' },
  });
}

function synthTemplate(opts: SynthOptions = {}): Template {
  return Template.fromStack(synthStack(opts));
}

/**
 * Find the `JudgeModelId` CFN output and return its resolved string
 * value. The output is emitted by `OrchestrationConstruct` and carries
 * the `judgeModelId` context value (or its default) the synth-time
 * validator returned. After Task 20.3 retired the runtime
 * `JUDGE_MODEL_ID` env var, this output is the on-template artifact
 * that operators read off to confirm what id propagated through synth.
 *
 * The synthesised logical id is `${ConstructPathPrefix}JudgeModelId${HashSuffix}`
 * (e.g. `OrchestrationJudgeModelIdAB12CD34`); we match by substring
 * because the construct's path prefix and CFN's hash suffix are
 * implementation details.
 */
function findJudgeModelIdOutput(template: Template): string {
  const outputs = template.findOutputs('*');
  const matches = Object.entries(outputs).filter(([logicalId]) =>
    logicalId.includes('JudgeModelId'),
  );
  expect(
    matches.length,
    `expected exactly one CFN output whose logical id contains "JudgeModelId", got ${matches.length}`,
  ).toBe(1);
  const [, output] = matches[0];
  const value = (output as any).Value;
  expect(typeof value).toBe('string');
  return value as string;
}

/**
 * Walk every IAM policy statement in the template and return the flattened set
 * of action strings. Used to assert universal absence of `bedrock-agentcore:*`
 * and `bedrock:*` wildcard actions on every role in the synthesised stack.
 */
function collectAllPolicyActions(template: Template): string[] {
  const policies = template.findResources('AWS::IAM::Policy');
  const out: string[] = [];
  for (const resource of Object.values(policies)) {
    const statements = (resource as any).Properties?.PolicyDocument?.Statement;
    if (!Array.isArray(statements)) continue;
    for (const statement of statements) {
      const actions = Array.isArray(statement.Action) ? statement.Action : [statement.Action];
      for (const action of actions) {
        if (typeof action === 'string') out.push(action);
      }
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// Default context: judgeModelId omitted → DEFAULT_JUDGE_MODEL_ID
// ---------------------------------------------------------------------------

describe('OrchestrationConstruct — Judge_Model context propagation (Reqs 6.1, 6.2)', () => {
  it('JudgeModelId CFN output defaults to us.anthropic.claude-sonnet-4-6 when context absent', () => {
    // Validates: Requirements 6.1, 6.2
    const template = synthTemplate();
    expect(findJudgeModelIdOutput(template)).toBe(DEFAULT_JUDGE_MODEL_ID);
  });

  it('JudgeModelId CFN output honors the judgeModelId context override', () => {
    // Validates: Requirements 6.1, 6.2
    const override = 'us.anthropic.claude-3-5-sonnet-20241022-v2:0';
    const template = synthTemplate({ judgeModelId: override });
    expect(findJudgeModelIdOutput(template)).toBe(override);
  });
});

// ---------------------------------------------------------------------------
// `eu.`-prefixed override — JudgeModelId CFN output propagation
// ---------------------------------------------------------------------------

describe('OrchestrationConstruct — eu. profile override (Reqs 6.1, 6.2)', () => {
  it('eu. profile also propagates onto the JudgeModelId CFN output unchanged', () => {
    // Validates: Requirements 6.1, 6.2
    const override = 'eu.anthropic.claude-sonnet-4-6';
    const template = synthTemplate({ judgeModelId: override });
    expect(findJudgeModelIdOutput(template)).toBe(override);
  });
});

// ---------------------------------------------------------------------------
// Wave 3 cleanup: legacy *_MODEL_ID env vars are gone (Req 1.4)
// ---------------------------------------------------------------------------

describe('OrchestrationConstruct — no legacy *_MODEL_ID env vars (Req 1.4 / Task 20.3)', () => {
  it('no Lambda Function in the synthesized stack carries any *_MODEL_ID environment variable', () => {
    // Validates: Requirement 1.4 (Wave 3 cleanup, Task 20.3 of the
    // prompt-management spec). Every per-callsite legacy env var
    // (`JUDGE_MODEL_ID`, `ANALYSIS_MODEL_ID`, `SUITE_RECOMMEND_MODEL_ID`,
    // `COMPARISON_SUMMARY_MODEL_ID`, `BEDROCK_MODEL_ID`,
    // `SIMULATOR_MODEL_ID`, `SCAFFOLD_MODEL_ID`) was retired in Wave 3
    // — the Prompt_Registry is now the runtime resolution path for
    // every Bedrock callsite. A regression that re-introduces any
    // `*_MODEL_ID` env var on any Lambda flips this assertion.
    const template = synthTemplate();
    const lambdas = template.findResources('AWS::Lambda::Function');
    const offenders: Array<{ logicalId: string; envKeys: string[] }> = [];
    for (const [logicalId, resource] of Object.entries(lambdas)) {
      const env = (resource as any).Properties?.Environment?.Variables;
      if (!env || typeof env !== 'object') continue;
      const offendingKeys = Object.keys(env).filter((k) =>
        /_MODEL_ID$/.test(k),
      );
      if (offendingKeys.length > 0) {
        offenders.push({ logicalId, envKeys: offendingKeys });
      }
    }
    expect(
      offenders,
      `Found Lambda(s) carrying a legacy *_MODEL_ID env var (Wave 3 should have removed all of them): ${JSON.stringify(offenders, null, 2)}`,
    ).toEqual([]);
  });
});

// ---------------------------------------------------------------------------
// Universal stack-wide invariant: no AgentCore actions, no `bedrock:*` wildcard
// ---------------------------------------------------------------------------

describe('OrchestrationConstruct — no AgentCore / bedrock:* wildcard anywhere (Req 6.6)', () => {
  it('no IAM policy in the synthesized stack carries a bedrock-agentcore:* action or a bedrock:* wildcard action', () => {
    // Validates: Requirement 6.6
    //
    // The narrow `BedrockJudgeConverse` IAM block that previously bounded
    // the Evaluation Lambda's grant was retired in Task 20.2 (Req 19.2);
    // the registry-derived `computeBedrockGrants` statement now stands in
    // for it. The set-equality of that statement against the registry's
    // expected union is asserted by `tests/cdk/bedrock-grants.test.ts`.
    // What this test still owns is the universal stack-wide invariant
    // that NO Lambda role anywhere in the synthesised template carries
    // either `bedrock-agentcore:*` or the literal `bedrock:*` wildcard.
    const template = synthTemplate();
    const actions = collectAllPolicyActions(template);

    for (const action of actions) {
      expect(action.startsWith('bedrock-agentcore:')).toBe(false);
    }
    // No `bedrock:*` wildcard. (Specific actions like `bedrock:InvokeModel`
    // or `bedrock:Converse` are fine; only the literal wildcard form is
    // forbidden.)
    expect(actions).not.toContain('bedrock:*');
  });
});

// ---------------------------------------------------------------------------
// Synth-time validation: empty / unrecognized prefix
// ---------------------------------------------------------------------------

describe('OrchestrationConstruct — synth-time validation of judgeModelId (Reqs 6.7, 6.8)', () => {
  it('an empty judgeModelId fails synth with a clear error', () => {
    // Validates: Requirement 6.7
    expect(() => synthStack({ judgeModelId: '' })).toThrow(
      /judgeModelId.*empty or whitespace-only/,
    );
  });

  it('a whitespace-only judgeModelId fails synth with a clear error', () => {
    // Validates: Requirement 6.7
    expect(() => synthStack({ judgeModelId: '   ' })).toThrow(
      /judgeModelId.*empty or whitespace-only/,
    );
  });

  it('an unrecognized inference-profile prefix fails synth and the error names supported prefixes', () => {
    // Validates: Requirement 6.8
    expect(() => synthStack({ judgeModelId: 'foobar.something-v1:0' })).toThrow(
      /Unrecognized judgeModelId.*foobar\.something-v1:0/,
    );
    // The error must name the supported inference-profile prefixes so
    // operators can self-correct without grepping the source.
    expect(() => synthStack({ judgeModelId: 'foobar.something-v1:0' })).toThrow(/us\./);
    expect(() => synthStack({ judgeModelId: 'foobar.something-v1:0' })).toThrow(/eu\./);
    expect(() => synthStack({ judgeModelId: 'foobar.something-v1:0' })).toThrow(/apac\./);
  });
});

// ---------------------------------------------------------------------------
// Spot-check: resolveJudgeModelGrants helper directly
// ---------------------------------------------------------------------------

describe('resolveJudgeModelGrants — helper-level spot check', () => {
  it('strips the inference-profile prefix to derive the underlying foundation-model id', () => {
    const { modelId, resourceArns } = resolveJudgeModelGrants(
      'us.anthropic.claude-sonnet-4-6',
      'us-east-1',
      '123456789012',
    );
    expect(modelId).toBe('us.anthropic.claude-sonnet-4-6');
    // Each region contributes one inference-profile ARN + one foundation-model ARN.
    expect(resourceArns).toHaveLength(6);
    expect(resourceArns).toContain(
      'arn:aws:bedrock:us-east-1:123456789012:inference-profile/us.anthropic.claude-sonnet-4-6',
    );
    expect(resourceArns).toContain(
      'arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-sonnet-4-6',
    );
  });

  it('a bare foundation-model id yields a single-region grant', () => {
    const { modelId, resourceArns } = resolveJudgeModelGrants(
      'anthropic.claude-3-5-sonnet-20241022-v2:0',
      'us-east-1',
      '123456789012',
    );
    expect(modelId).toBe('anthropic.claude-3-5-sonnet-20241022-v2:0');
    expect(resourceArns).toEqual([
      'arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-20241022-v2:0',
    ]);
  });
});
