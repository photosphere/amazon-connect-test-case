# Implementation Plan: Trace Reasoning and Latency

## Overview

This plan extends the Connect Agent Test Platform to surface reasoning, per-step latency, and inference metadata from the Q in Connect `ListSpans` API. The implementation progresses through the parsing layer, shared types, persistence guard, frontend presentation, analytics prompt plumbing, judge-prompt fix, and prompt-registry versioning — with property-based tests validating each correctness property from the design.

## Tasks

- [x] 1. Extend shared type interfaces
  - [x] 1.1 Add InferenceMetadata interface and extend ExecutionStep in `src/shared/types.ts`
    - Declare the `InferenceMetadata` interface with all 14 optional fields per the design
    - Add `durationMs?: number`, `reasoning?: string`, and `inferenceMetadata?: InferenceMetadata` to `ExecutionStep`
    - Ensure no existing fields are removed or renamed
    - _Requirements: 1.6, 2.4, 3.5_

- [x] 2. Extend the Span Parser with reasoning, duration, and metadata extraction
  - [x] 2.1 Extend `RawSpanValue` and `RawSpanAttributes` interfaces in `src/backend/orchestration/span-parser.ts`
    - Add `reasoning?: { value?: string }` to `RawSpanValue`
    - Add all 14 inference metadata source fields plus `systemInstructions` array to `RawSpanAttributes`
    - _Requirements: 1.5, 3.1_
  - [x] 2.2 Implement `extractReasoning` helper in `src/backend/orchestration/span-parser.ts`
    - Pure function that concatenates valid `reasoning.value` strings from `outputMessages` with `"\n"` separator
    - Skip invalid entries (null, empty, whitespace-only, non-string) without emitting separator
    - Return `undefined` when no valid entries exist (not empty string, not null)
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.7_
  - [x] 2.3 Implement `computeDurationMs` helper in `src/backend/orchestration/span-parser.ts`
    - Parse both timestamps with `Date.parse`, return `undefined` if either is NaN/missing
    - Return `Math.round(Math.max(0, end - start))` for valid timestamps
    - Emit single `console.warn` when difference is negative
    - _Requirements: 2.1, 2.2, 2.3, 2.7_
  - [x] 2.4 Implement `extractInferenceMetadata` helper in `src/backend/orchestration/span-parser.ts`
    - Type-check each of the 14 source fields against expected types
    - Build `systemInstructions` by filtering `attributes.systemInstructions[]` to valid `text.value` strings, joining with `"\n\n"`
    - Return `undefined` when zero fields pass type validation
    - _Requirements: 3.1, 3.2, 3.3, 3.6, 3.7_
  - [x] 2.5 Wire helpers into `parseSpansToTrace` in `src/backend/orchestration/span-parser.ts`
    - Call `extractReasoning` for inference steps, set `step.reasoning`
    - Call `computeDurationMs` for all real spans, set `step.durationMs`
    - Set `durationMs = undefined` on synthetic `inference_tool_use` and `synthetic_control_tool` steps
    - Call `extractInferenceMetadata` only for inference steps, set `step.inferenceMetadata`
    - Leave `inferenceMetadata = undefined` on non-inference steps
    - _Requirements: 1.1–1.7, 2.1–2.7, 3.1–3.7_
  - [x] 2.6 Write property tests for span-parser reasoning (Properties 1–4) in `tests/unit/properties/span-parser-reasoning.test.ts`
    - **Property 1: Reasoning extraction preserves verbatim content**
    - **Property 2: Multi-entry reasoning concatenation**
    - **Property 3: Invalid reasoning yields undefined**
    - **Property 4: Text and reasoning are independent**
    - **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.7**
  - [x] 2.7 Write property tests for span-parser duration (Properties 5–6) in `tests/unit/properties/span-parser-reasoning.test.ts`
    - **Property 5: durationMs is non-negative or undefined**
    - **Property 6: Synthetic steps have undefined durationMs**
    - **Validates: Requirements 2.1, 2.5, 2.6, 2.7**
  - [x] 2.8 Write property tests for span-parser metadata (Properties 7–9) in `tests/unit/properties/span-parser-reasoning.test.ts`
    - **Property 7: InferenceMetadata contains exactly the valid typed fields**
    - **Property 8: systemInstructions join preserves content**
    - **Property 9: inferenceMetadata absent on non-inference steps**
    - **Validates: Requirements 3.1, 3.2, 3.4, 3.6, 3.7**

- [x] 3. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Add persistence truncation guard
  - [x] 4.1 Add 350 KB truncation guard for `systemInstructions` in `src/backend/services/dynamodb.ts`
    - Before `writeExecutionTrace` serializes, check if any step's `inferenceMetadata.systemInstructions` exceeds 350 KB after JSON serialization
    - Truncate to 350 KB and append `"\n…[truncated]"` suffix
    - Emit `console.warn` with runId, caseId, and step index
    - If truncation itself throws, surface failure to caller (do not write)
    - _Requirements: 4.5, 4.6_
  - [x] 4.2 Write property test for persistence round-trip (Property 10) in `tests/unit/properties/trace-persistence-roundtrip.test.ts`
    - **Property 10: Persistence round-trip**
    - Verify write + read produces deep-equal `durationMs`, `reasoning`, `inferenceMetadata` on every step
    - **Validates: Requirements 4.3**

- [x] 5. Implement Timeline Transcript UI changes
  - [x] 5.1 Add `ReasoningRow`, `DurationLabel`, and `InferenceDetailsDisclosure` components in `src/frontend/src/components/Transcript/TimelineTranscript.tsx`
    - `ReasoningRow`: lavender background, left-border color distinct from agent-reply, label `Reasoning · <agentName>`, `pre-wrap` whitespace
    - `DurationLabel`: formats `durationMs` as `N ms` (< 1000) or `N.N s` (≥ 1000), returns null outside `[0, 86400000]`
    - `InferenceDetailsDisclosure`: Cloudscape `ExpandableSection` labeled `Inference details`, collapsed by default, key-value list per design
    - `SystemPromptDisclosure`: nested collapsed disclosure for `systemInstructions` with `pre-wrap`
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 7.1, 7.2, 7.3, 7.4, 7.5, 8.1, 8.2, 8.4_
  - [x] 5.2 Update `ReasoningStepRow` to render reasoning-first / agent-reply split and relabel inference to `Agent reply`
    - When `step.reasoning` is present: render `ReasoningRow` followed by agent-reply row (existing blue style)
    - Relabel inference row from `Inference` to `Agent reply`
    - Add duration label and TTFT label to the row header strip in format `step N · timestamp · duration · ttft`
    - Render `InferenceDetailsDisclosure` below inference steps with metadata
    - _Requirements: 5.1, 5.2, 5.5, 6.1, 6.2, 6.5, 7.1, 8.1, 8.2_
  - [x] 5.3 Write property test for duration formatting (Property 11) in `tests/unit/properties/duration-formatting.test.ts`
    - **Property 11: Duration label formatting**
    - For any integer `d` in `[0, 86400000]`: `d < 1000` → `"${d} ms"`, `d >= 1000` → `"${(d/1000).toFixed(1)} s"`
    - Function is total and never throws
    - **Validates: Requirements 6.1**

- [x] 6. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Plumb reasoning into failure analysis prompt
  - [x] 7.1 Add `## Reasoning trace` section to `buildAnalysisPrompt` in `src/backend/handlers/analysis.ts`
    - When at least one step carries non-empty `reasoning`, append a `## Reasoning trace` section to the user message
    - Format: `[step N · timestamp]\nreasoning text\n` per step, chronological order
    - When no step carries reasoning, produce byte-identical output to the prior renderer
    - Preserve reasoning verbatim (no truncation, no normalization)
    - _Requirements: 9.1, 9.2, 9.3, 9.4_
  - [x] 7.2 Bump `failure_analysis` prompt version in `src/backend/orchestration/prompt-registry/prompts/failure-analysis.ts`
    - Forward version bump (new `defaultText` reflecting the reasoning-trace section)
    - Persisted overrides against the prior version continue to resolve to prior text
    - Store resolved version on `ANALYSIS#CASE#{caseId}` records
    - _Requirements: 9.5, 9.6_
  - [x] 7.3 Write property tests for analysis prompt reasoning (Properties 12–13) in `tests/unit/properties/analysis-prompt-reasoning.test.ts`
    - **Property 12: Failure analysis prompt deterministic with reasoning**
    - **Property 13: Failure analysis prompt backward compatibility**
    - **Validates: Requirements 9.1, 9.2, 9.3, 9.4**

- [x] 8. Plumb reasoning into suite recommendation prompt
  - [x] 8.1 Add per-case reasoning trace to `buildUserMessage` in `src/backend/handlers/suite-recommend.ts`
    - Include each failed case's reasoning trace in the per-case section when at least one step carries reasoning
    - Same chronological format as the per-case path
    - When no case carries reasoning, produce byte-identical suite prompt to prior renderer
    - _Requirements: 10.1, 10.2_
  - [x] 8.2 Bump `suite_recommendation` prompt version in `src/backend/orchestration/prompt-registry/prompts/suite-recommendation.ts`
    - Forward version bump with same semantics as 7.2
    - Store resolved version on `ANALYSIS#SUITE` records
    - _Requirements: 10.3, 10.4_
  - [x] 8.3 Write property tests for suite prompt reasoning (Properties 14–15) in `tests/unit/properties/analysis-prompt-reasoning.test.ts`
    - **Property 14: Suite prompt includes per-case reasoning**
    - **Property 15: Suite prompt backward compatibility**
    - **Validates: Requirements 10.1, 10.2**

- [x] 9. Fix Helpfulness context to include same-turn tool calls
  - [x] 9.1 Modify `renderContextForAssistantTurn` in `src/shared/utils/judge-prompt-rendering.ts`
    - After the `Assistant:` line, include `Action:` / `Tool:` lines for every tool call on the same `ConversationTurn`
    - Preserve existing `renderToolCallLines` line shape byte-for-byte
    - Apply only to Helpfulness `{context}` — do NOT change GoalSuccessRate or ToolSelectionAccuracy contexts
    - Preserve the empty `{assistant_turn}` skip rule — tool-call-only turns are not promoted to standalone units
    - _Requirements: 14.1, 14.2, 14.3, 14.4, 14.8_
  - [x] 9.2 Conditionally bump `judge_helpfulness` prompt version if fixture re-render produces byte-different output
    - Re-render all fixtures under `tests/fixtures/spans/` plus `tmp/spans-mortgage-rate.json`
    - Bump only if at least one fixture produces a byte-different Helpfulness `{context}`
    - _Requirements: 14.5, 14.6_
  - [x] 9.3 Write property tests for helpfulness context (Properties 16–17) in `tests/unit/properties/helpfulness-context.test.ts`
    - **Property 16: Helpfulness context includes same-turn tool calls**
    - **Property 17: GoalSuccessRate and ToolSelectionAccuracy contexts unchanged**
    - **Validates: Requirements 14.1, 14.2, 14.3, 14.8**

- [x] 10. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 11. Implement lazy re-fetch for pre-feature traces
  - [x] 11.1 Add lazy re-fetch logic in `src/backend/handlers/results.ts`
    - On per-case detail page load, detect pre-feature TRACE (missing `durationMs`/`reasoning`/`inferenceMetadata`)
    - Check `LISTSPANS_RETENTION_DAYS` env var (default 7) against `(now - run.startTime)`
    - If within retention window and `sessionId` present: call ListSpans, re-parse with new Span_Parser
    - If re-parsed trace differs from stored: overwrite DDB (retry once on failure, render in-memory on second failure with inline notice)
    - If re-fetch returns 0 spans or errors: leave existing trace unchanged, log, no user-visible error
    - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 11.6, 11.7_

- [x] 12. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design using `fast-check`
- Unit tests validate specific examples and edge cases
- The design uses TypeScript throughout — all implementation tasks use TypeScript
- Prompt Registry version bumps are forward versions (not in-place edits) to preserve existing persisted overrides
- The three Bedrock pass/fail judges are deliberately NOT given reasoning content (Requirement 13)

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["2.1"] },
    { "id": 2, "tasks": ["2.2", "2.3", "2.4"] },
    { "id": 3, "tasks": ["2.5", "4.1"] },
    { "id": 4, "tasks": ["2.6", "2.7", "2.8", "4.2", "5.1"] },
    { "id": 5, "tasks": ["5.2", "5.3"] },
    { "id": 6, "tasks": ["7.1", "8.1", "9.1"] },
    { "id": 7, "tasks": ["7.2", "7.3", "8.2", "8.3", "9.2", "9.3"] },
    { "id": 8, "tasks": ["11.1"] }
  ]
}
```
