/**
 * Cases CRUD Lambda — handles test case routes with type-discriminator validation.
 *
 * Routes:
 * - POST   /suites/{suiteId}/cases          — Create test case
 * - GET    /suites/{suiteId}/cases           — List cases for suite
 * - GET    /suites/{suiteId}/cases/{caseId}  — Get single case
 * - PUT    /suites/{suiteId}/cases/{caseId}  — Update test case
 * - DELETE /suites/{suiteId}/cases/{caseId}  — Delete single case
 *
 * @module cases
 */

import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBService, createDynamoDBService } from "../services/dynamodb";
import type {
  TestCase,
  ToolSequenceTestCase,
  RagTestCase,
  ToolDefinition,
} from "../../shared/types";
import {
  CASE_DESCRIPTION_MAX,
  CASE_NAME_MAX,
  CUSTOMER_KNOWLEDGE_KEY_MAX,
  CUSTOMER_KNOWLEDGE_MAX_PAIRS,
  CUSTOMER_KNOWLEDGE_VALUE_MAX,
  INITIAL_UTTERANCE_MAX,
  PARAMETER_CHECKS_MAX,
  RAG_GROUND_TRUTH_MAX,
  RAG_QUESTION_MAX,
  SUCCESS_CRITERIA_MAX_STEPS,
  SUCCESS_CRITERIA_MIN_STEPS,
} from "../../shared/constants";
import { CommunicationStyle } from "../../shared/enums";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";

// ---------------------------------------------------------------------------
// Service setup
// ---------------------------------------------------------------------------

let dbService: DynamoDBService | null = null;

function getDBService(): DynamoDBService {
  if (!dbService) {
    const ddbClient = new DynamoDBClient({});
    const docClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
    dbService = createDynamoDBService(TABLE_NAME, docClient);
  }
  return dbService;
}

/** @internal — allows test injection */
export function _setDBService(service: DynamoDBService | null): void {
  dbService = service;
}

// ---------------------------------------------------------------------------
// Discovery service for content tag filter validation
// ---------------------------------------------------------------------------

/**
 * Fetches agent tool definitions from the Discovery API.
 * Returns null on any failure — content tag validation is best-effort.
 */
type AgentToolsFetcher = (agentId: string) => Promise<ToolDefinition[] | null>;

let agentToolsFetcher: AgentToolsFetcher | null = null;

/** @internal — allows test injection of the Discovery API access */
export function _setAgentToolsFetcher(fetcher: AgentToolsFetcher | null): void {
  agentToolsFetcher = fetcher;
}

async function fetchAgentTools(agentId: string): Promise<ToolDefinition[] | null> {
  if (agentToolsFetcher) {
    return agentToolsFetcher(agentId);
  }
  // Default implementation: use the discovery module
  try {
    const { getAgentDetail } = await import("./discovery");
    const detail = await getAgentDetail(agentId);
    return detail?.tools ?? null;
  } catch (error) {
    console.warn(
      "[cases] Failed to fetch agent tools for content tag validation:",
      error instanceof Error ? error.message : error,
    );
    return null;
  }
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  body?: string | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, string>;
    };
  };
}

export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

/** Validation warning (not a hard error) surfaced in the response. */
export interface ValidationWarning {
  type: "warning" | "info";
  key?: string;
  message: string;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(statusCode: number, body: unknown): APIGatewayResponse {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

function extractTenantId(event: APIGatewayEvent): string | null {
  const claims = event.requestContext?.authorizer?.claims;
  return claims?.sub ?? claims?.client_id ?? null;
}

function generateId(): string {
  const hex = "0123456789abcdef";
  let id = "";
  for (let i = 0; i < 24; i++) {
    id += hex[Math.floor(Math.random() * 16)];
  }
  return id;
}

// ---------------------------------------------------------------------------
// Type normalization and validation
// ---------------------------------------------------------------------------

/** Simulator-specific fields that are NOT allowed on RAG cases. */
const RAG_EXTRANEOUS_FIELDS = [
  "persona",
  "style",
  "customerKnowledge",
  "initialUtterance",
  "goalDescription",
  "primingMessage",
  "successCriteria",
] as const;

/**
 * Normalizes a raw record to a typed TestCase. Absent `type` is treated as
 * `"tool_sequence"` for backward compatibility (R1.2, R10.1).
 */
export function normalizeTestCase(raw: Record<string, unknown>): TestCase {
  const type = (raw.type as string) ?? "tool_sequence";
  if (type === "rag") {
    return { ...raw, type: "rag" } as unknown as RagTestCase;
  }
  return { ...raw, type: "tool_sequence" } as unknown as ToolSequenceTestCase;
}

/**
 * Validates session data: max 20 key-value pairs, keys non-empty.
 * Returns an error string or null if valid.
 */
function validateSessionData(
  sessionData: unknown,
): string | null {
  if (sessionData == null) return null;
  if (typeof sessionData !== "object" || Array.isArray(sessionData)) {
    return "sessionData must be an object";
  }
  const entries = Object.entries(sessionData as Record<string, unknown>);
  if (entries.length > CUSTOMER_KNOWLEDGE_MAX_PAIRS) {
    return `sessionData must have at most ${CUSTOMER_KNOWLEDGE_MAX_PAIRS} key-value pairs`;
  }
  for (const [key, value] of entries) {
    if (!key || key.trim() === "") {
      return "sessionData keys must be non-empty";
    }
    if (typeof value !== "string") {
      return `sessionData value for key "${key}" must be a string`;
    }
  }
  return null;
}

interface CaseValidationError {
  error: string;
  field?: string;
  details?: Array<{ field: string; message: string }>;
}

/**
 * Validates a RAG case input. Returns null if valid, or an error response body.
 */
function validateRagCase(input: Record<string, unknown>): CaseValidationError | null {
  // Check for extraneous simulator fields
  for (const field of RAG_EXTRANEOUS_FIELDS) {
    if (input[field] !== undefined) {
      return { error: "rag_case_extraneous_field", field };
    }
  }

  const errors: Array<{ field: string; message: string }> = [];

  // name: optional, max length
  if (input.name != null && typeof input.name === "string" && input.name.length > CASE_NAME_MAX) {
    errors.push({
      field: "name",
      message: `Name must be at most ${CASE_NAME_MAX} characters`,
    });
  }

  // description: required, non-empty, max length
  if (input.description == null || (typeof input.description === "string" && input.description.trim() === "")) {
    errors.push({ field: "description", message: "Description is required" });
  } else if (typeof input.description === "string" && input.description.length > CASE_DESCRIPTION_MAX) {
    errors.push({
      field: "description",
      message: `Description must be at most ${CASE_DESCRIPTION_MAX} characters`,
    });
  }

  // question: required, 1..1000 trimmed-non-empty
  if (input.question == null || typeof input.question !== "string" || input.question.trim() === "") {
    errors.push({ field: "question", message: "Question is required and must be non-empty" });
  } else if (input.question.length > RAG_QUESTION_MAX) {
    errors.push({
      field: "question",
      message: `Question must be at most ${RAG_QUESTION_MAX} characters`,
    });
  }

  // groundTruthAnswer: required, 1..4000 trimmed-non-empty
  if (
    input.groundTruthAnswer == null ||
    typeof input.groundTruthAnswer !== "string" ||
    input.groundTruthAnswer.trim() === ""
  ) {
    errors.push({
      field: "groundTruthAnswer",
      message: "Ground truth answer is required and must be non-empty",
    });
  } else if (input.groundTruthAnswer.length > RAG_GROUND_TRUTH_MAX) {
    errors.push({
      field: "groundTruthAnswer",
      message: `Ground truth answer must be at most ${RAG_GROUND_TRUTH_MAX} characters`,
    });
  }

  // sessionData: optional, max 20 pairs
  const sessionError = validateSessionData(input.sessionData);
  if (sessionError) {
    errors.push({ field: "sessionData", message: sessionError });
  }

  if (errors.length > 0) {
    return { error: "Validation failed", details: errors };
  }
  return null;
}

/**
 * Validates a tool-sequence case input using the existing validation logic.
 * Returns null if valid, or an error response body.
 */
function validateToolSequenceCase(input: Record<string, unknown>): CaseValidationError | null {
  const errors: Array<{ field: string; message: string }> = [];

  // name: optional, max length if provided
  if (input.name != null && typeof input.name === "string" && input.name.length > CASE_NAME_MAX) {
    errors.push({
      field: "name",
      message: `Name must be at most ${CASE_NAME_MAX} characters`,
    });
  }

  // description: required, non-empty, max length
  if (input.description == null || (typeof input.description === "string" && input.description.trim() === "")) {
    errors.push({ field: "description", message: "Description is required" });
  } else if (typeof input.description === "string" && input.description.length > CASE_DESCRIPTION_MAX) {
    errors.push({
      field: "description",
      message: `Description must be at most ${CASE_DESCRIPTION_MAX} characters`,
    });
  }

  // goalDescription: optional, max length
  if (input.goalDescription != null && typeof input.goalDescription === "string" && input.goalDescription.length > CASE_DESCRIPTION_MAX) {
    errors.push({
      field: "goalDescription",
      message: `Goal description must be at most ${CASE_DESCRIPTION_MAX} characters`,
    });
  }

  // initialUtterance: required, non-empty, max length
  const utterance = input.initialUtterance;
  if (utterance == null || (typeof utterance === "string" && utterance.trim() === "")) {
    errors.push({ field: "initialUtterance", message: "Initial utterance is required" });
  } else if (typeof utterance === "string" && utterance.length > INITIAL_UTTERANCE_MAX) {
    errors.push({
      field: "initialUtterance",
      message: `Initial utterance must be at most ${INITIAL_UTTERANCE_MAX} characters`,
    });
  }

  // customerKnowledge: optional, max pairs + key/value length
  if (input.customerKnowledge != null && typeof input.customerKnowledge === "object" && !Array.isArray(input.customerKnowledge)) {
    const entries = Object.entries(input.customerKnowledge as Record<string, unknown>);
    if (entries.length > CUSTOMER_KNOWLEDGE_MAX_PAIRS) {
      errors.push({
        field: "customerKnowledge",
        message: `Customer knowledge must have at most ${CUSTOMER_KNOWLEDGE_MAX_PAIRS} pairs`,
      });
    }
    for (const [key, value] of entries) {
      if (key.length > CUSTOMER_KNOWLEDGE_KEY_MAX) {
        errors.push({
          field: `customerKnowledge.${key}`,
          message: `Customer knowledge key must be at most ${CUSTOMER_KNOWLEDGE_KEY_MAX} characters`,
        });
      }
      if (typeof value === "string" && value.length > CUSTOMER_KNOWLEDGE_VALUE_MAX) {
        errors.push({
          field: `customerKnowledge.${key}`,
          message: `Customer knowledge value must be at most ${CUSTOMER_KNOWLEDGE_VALUE_MAX} characters`,
        });
      }
    }
  }

  // successCriteria: required, 1–30 steps
  const criteria = input.successCriteria as Array<{ toolName: string; required?: boolean; parameterChecks?: unknown[] }> | undefined;
  if (criteria == null || !Array.isArray(criteria) || criteria.length < SUCCESS_CRITERIA_MIN_STEPS) {
    errors.push({
      field: "successCriteria",
      message: `Success criteria must have at least ${SUCCESS_CRITERIA_MIN_STEPS} step`,
    });
  } else {
    if (criteria.length > SUCCESS_CRITERIA_MAX_STEPS) {
      errors.push({
        field: "successCriteria",
        message: `Success criteria must have at most ${SUCCESS_CRITERIA_MAX_STEPS} steps`,
      });
    }
    for (let i = 0; i < criteria.length; i++) {
      const step = criteria[i];
      if (!step.toolName || step.toolName.trim() === "") {
        errors.push({
          field: `successCriteria[${i}].toolName`,
          message: "Tool name is required",
        });
      }
      if (step.parameterChecks && Array.isArray(step.parameterChecks) && step.parameterChecks.length > PARAMETER_CHECKS_MAX) {
        errors.push({
          field: `successCriteria[${i}].parameterChecks`,
          message: `Parameter checks must have at most ${PARAMETER_CHECKS_MAX} entries`,
        });
      }
    }
  }

  // sessionData: optional, max 20 pairs
  const sessionError = validateSessionData(input.sessionData);
  if (sessionError) {
    errors.push({ field: "sessionData", message: sessionError });
  }

  if (errors.length > 0) {
    return { error: "Validation failed", details: errors };
  }
  return null;
}

// ---------------------------------------------------------------------------
// Content tag filter validation (R13)
// ---------------------------------------------------------------------------

/**
 * Extracts `{{$.Custom.*}}` placeholder keys from a tool's input schema by
 * recursively searching for string values matching the pattern.
 */
function extractPlaceholderKeys(obj: unknown): string[] {
  const keys: string[] = [];
  if (obj == null) return keys;

  if (typeof obj === "string") {
    const matches = obj.match(/\{\{\$\.Custom\.(\w+)\}\}/g);
    if (matches) {
      for (const m of matches) {
        const key = m.replace(/\{\{\$\.Custom\.|\}\}/g, "");
        if (key) keys.push(key);
      }
    }
    return keys;
  }

  if (Array.isArray(obj)) {
    for (const item of obj) {
      keys.push(...extractPlaceholderKeys(item));
    }
    return keys;
  }

  if (typeof obj === "object") {
    for (const value of Object.values(obj as Record<string, unknown>)) {
      keys.push(...extractPlaceholderKeys(value));
    }
  }

  return keys;
}

/**
 * Validates content tag filter alignment between session data keys and the
 * agent's Retrieve tool configuration. Returns warnings (not errors).
 *
 * Best-effort: if the Discovery API call fails, returns empty warnings.
 */
async function validateContentTagFilters(
  sessionData: Record<string, string> | undefined,
  agentId: string,
): Promise<ValidationWarning[]> {
  if (!sessionData || Object.keys(sessionData).length === 0) return [];

  const tools = await fetchAgentTools(agentId);
  if (!tools) return []; // Discovery failed — best-effort, proceed without warnings

  const warnings: ValidationWarning[] = [];

  // Find Retrieve tools and extract placeholder keys
  const retrieveTools = tools.filter(
    (t) => t.toolType === "RETRIEVE" || t.toolName.toLowerCase().includes("retrieve"),
  );

  const placeholderKeys: string[] = [];
  for (const tool of retrieveTools) {
    const keys = extractPlaceholderKeys(tool.inputSchema);
    placeholderKeys.push(...keys);
    // Also check instruction and description for placeholders
    if (tool.instruction) {
      placeholderKeys.push(...extractPlaceholderKeys(tool.instruction));
    }
  }

  // Deduplicate placeholder keys
  const uniquePlaceholderKeys = [...new Set(placeholderKeys)];

  if (uniquePlaceholderKeys.length === 0) {
    // R13.3: No dynamic filter configured
    warnings.push({
      type: "info",
      message:
        "This agent's Retrieve tool does not appear to have a dynamic content tag filter configured. " +
        "Session data keys will only take effect if the agent's Retrieve tool has " +
        "`retrievalConfiguration.filter.equals.value` set to a `{{$.Custom.*}}` placeholder. " +
        "Configure the filter key on the agent first.",
    });
  } else {
    // R13.2: Check if session data keys match placeholder keys
    for (const key of Object.keys(sessionData)) {
      if (!uniquePlaceholderKeys.includes(key)) {
        warnings.push({
          type: "warning",
          key,
          message: `Session data key "${key}" does not appear to be referenced by any Retrieve tool's content tag filter.`,
        });
      }
    }
  }

  return warnings;
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------

async function createCase(
  suiteId: string,
  tenantId: string,
  body: string | null,
): Promise<APIGatewayResponse> {
  if (!body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let input: Record<string, unknown>;
  try {
    input = JSON.parse(body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  // Determine case type: absent type → "tool_sequence"
  const type = (input.type as string) ?? "tool_sequence";

  if (type !== "rag" && type !== "tool_sequence") {
    return jsonResponse(400, { error: "Invalid type: must be 'tool_sequence' or 'rag'" });
  }

  // Validate by type
  if (type === "rag") {
    const validationError = validateRagCase(input);
    if (validationError) {
      return jsonResponse(400, validationError);
    }
  } else {
    const validationError = validateToolSequenceCase(input);
    if (validationError) {
      return jsonResponse(400, validationError);
    }
  }

  // Verify parent suite exists
  const db = getDBService();
  const suite = await db.getSuite(tenantId, suiteId);
  if (!suite) {
    return jsonResponse(404, { error: "Suite not found" });
  }

  const caseId = generateId();

  let testCase: TestCase;

  if (type === "rag") {
    testCase = {
      type: "rag",
      suiteId,
      caseId,
      name: (input.name as string) ?? "",
      description: ((input.description as string) ?? "").trim(),
      question: (input.question as string).trim(),
      groundTruthAnswer: (input.groundTruthAnswer as string).trim(),
      ...(input.sessionData ? { sessionData: input.sessionData as Record<string, string> } : {}),
    };
  } else {
    testCase = {
      type: "tool_sequence",
      suiteId,
      caseId,
      name: (input.name as string) ?? "",
      description: ((input.description as string) ?? "").trim(),
      ...(input.goalDescription && (input.goalDescription as string).trim() !== ""
        ? { goalDescription: (input.goalDescription as string).trim() }
        : {}),
      persona: (input.persona as string) ?? "",
      style: (input.style as CommunicationStyle) ?? CommunicationStyle.DIRECT,
      customerKnowledge: (input.customerKnowledge as Record<string, string>) ?? {},
      initialUtterance: (input.initialUtterance as string).trim(),
      successCriteria: (
        input.successCriteria as Array<{
          toolName: string;
          required?: boolean;
          parameterChecks?: { paramName: string; expectedValue: string }[];
        }>
      ).map((step) => ({
        toolName: step.toolName.trim(),
        required: step.required !== false,
        parameterChecks: step.parameterChecks,
      })),
      ...(input.sessionData ? { sessionData: input.sessionData as Record<string, string> } : {}),
      ...(input.primingMessage ? { primingMessage: input.primingMessage as string } : {}),
    };
  }

  await db.createCase(testCase);

  // Content tag filter validation (R13) — best-effort, RAG cases only
  let warnings: ValidationWarning[] = [];
  if (type === "rag" && input.sessionData) {
    warnings = await validateContentTagFilters(
      input.sessionData as Record<string, string>,
      suite.agentId,
    );
  }

  if (warnings.length > 0) {
    return jsonResponse(201, { ...testCase, warnings });
  }
  return jsonResponse(201, testCase);
}

async function getCase(
  suiteId: string,
  caseId: string,
): Promise<APIGatewayResponse> {
  const db = getDBService();
  const existing = await db.getCase(suiteId, caseId);
  if (!existing) {
    return jsonResponse(404, { error: "Test case not found" });
  }
  // Normalize type for backward compatibility
  const normalized = normalizeTestCase(existing as unknown as Record<string, unknown>);
  return jsonResponse(200, normalized);
}

async function listCases(suiteId: string): Promise<APIGatewayResponse> {
  const db = getDBService();
  const cases = await db.listCases(suiteId);
  // Normalize type on each case for backward compatibility
  const normalized = cases.map((c) =>
    normalizeTestCase(c as unknown as Record<string, unknown>),
  );
  return jsonResponse(200, { cases: normalized });
}

async function updateCase(
  suiteId: string,
  caseId: string,
  tenantId: string,
  body: string | null,
): Promise<APIGatewayResponse> {
  if (!body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let input: Record<string, unknown>;
  try {
    input = JSON.parse(body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  const db = getDBService();

  // Verify case exists
  const existing = await db.getCase(suiteId, caseId);
  if (!existing) {
    return jsonResponse(404, { error: "Test case not found" });
  }

  // Determine stored type (normalize legacy records without type)
  const storedType = (existing as unknown as Record<string, unknown>).type ?? "tool_sequence";

  // Type immutability: reject if the caller attempts to change type
  if (input.type !== undefined && input.type !== storedType) {
    return jsonResponse(400, {
      error: "Type is immutable after creation. Delete and recreate the case to change type.",
    });
  }

  const type = storedType as "tool_sequence" | "rag";

  // Validate by type
  if (type === "rag") {
    // On update, merge with existing values for optional fields
    const mergedForValidation: Record<string, unknown> = {
      name: input.name ?? existing.name,
      description: input.description ?? existing.description,
      question: input.question ?? (existing as RagTestCase).question,
      groundTruthAnswer: input.groundTruthAnswer ?? (existing as RagTestCase).groundTruthAnswer,
      sessionData: input.sessionData ?? (existing as RagTestCase).sessionData,
    };

    const validationError = validateRagCase(mergedForValidation);
    if (validationError) {
      return jsonResponse(400, validationError);
    }

    // Check for extraneous simulator fields on the UPDATE input itself
    for (const field of RAG_EXTRANEOUS_FIELDS) {
      if (input[field] !== undefined) {
        return jsonResponse(400, { error: "rag_case_extraneous_field", field });
      }
    }
  } else {
    // Tool-sequence update: merge with existing for validation
    const tsExisting = existing as ToolSequenceTestCase;
    const mergedForValidation: Record<string, unknown> = {
      name: input.name ?? tsExisting.name,
      description: input.description ?? tsExisting.description,
      goalDescription: input.goalDescription ?? tsExisting.goalDescription,
      initialUtterance: input.initialUtterance ?? tsExisting.initialUtterance,
      customerKnowledge: input.customerKnowledge ?? tsExisting.customerKnowledge,
      successCriteria: input.successCriteria ?? tsExisting.successCriteria,
      sessionData: input.sessionData ?? tsExisting.sessionData,
    };

    const validationError = validateToolSequenceCase(mergedForValidation);
    if (validationError) {
      return jsonResponse(400, validationError);
    }
  }

  let updatedCase: TestCase;

  if (type === "rag") {
    const ragExisting = existing as RagTestCase;
    updatedCase = {
      type: "rag",
      suiteId,
      caseId,
      name: (input.name as string) ?? ragExisting.name,
      description: ((input.description as string) ?? ragExisting.description).trim(),
      question: ((input.question as string) ?? ragExisting.question).trim(),
      groundTruthAnswer: ((input.groundTruthAnswer as string) ?? ragExisting.groundTruthAnswer).trim(),
      ...((input.sessionData ?? ragExisting.sessionData) && {
        sessionData: (input.sessionData as Record<string, string>) ?? ragExisting.sessionData,
      }),
    };
  } else {
    const tsExisting = existing as ToolSequenceTestCase;
    updatedCase = {
      type: "tool_sequence",
      suiteId,
      caseId,
      name: (input.name as string) ?? tsExisting.name,
      description: ((input.description as string) ?? tsExisting.description).trim(),
      // goalDescription: supports clearing via empty string
      ...((() => {
        if (input.goalDescription === undefined) {
          return tsExisting.goalDescription !== undefined
            ? { goalDescription: tsExisting.goalDescription }
            : {};
        }
        const trimmed = (input.goalDescription as string).trim();
        return trimmed !== "" ? { goalDescription: trimmed } : {};
      })()),
      persona: (input.persona as string) ?? tsExisting.persona,
      style: (input.style as CommunicationStyle) ?? tsExisting.style,
      customerKnowledge: (input.customerKnowledge as Record<string, string>) ?? tsExisting.customerKnowledge,
      initialUtterance: ((input.initialUtterance as string) ?? tsExisting.initialUtterance).trim(),
      successCriteria: input.successCriteria
        ? (
            input.successCriteria as Array<{
              toolName: string;
              required?: boolean;
              parameterChecks?: { paramName: string; expectedValue: string }[];
            }>
          ).map((step) => ({
            toolName: step.toolName.trim(),
            required: step.required !== false,
            parameterChecks: step.parameterChecks,
          }))
        : tsExisting.successCriteria,
      ...((input.sessionData ?? tsExisting.sessionData) && {
        sessionData: (input.sessionData as Record<string, string>) ?? tsExisting.sessionData,
      }),
      ...((input.primingMessage ?? tsExisting.primingMessage) && {
        primingMessage: (input.primingMessage as string) ?? tsExisting.primingMessage,
      }),
    } as ToolSequenceTestCase;
  }

  await db.updateCase(updatedCase);

  // Content tag filter validation (R13) — best-effort, RAG cases only
  let warnings: ValidationWarning[] = [];
  if (type === "rag" && (input.sessionData || (existing as RagTestCase).sessionData)) {
    // Fetch the suite to get agentId
    const suite = await db.getSuite(tenantId, suiteId);
    if (suite) {
      const sessionDataToValidate = (input.sessionData as Record<string, string>) ?? (existing as RagTestCase).sessionData;
      if (sessionDataToValidate) {
        warnings = await validateContentTagFilters(sessionDataToValidate, suite.agentId);
      }
    }
  }

  if (warnings.length > 0) {
    return jsonResponse(200, { ...updatedCase, warnings });
  }
  return jsonResponse(200, updatedCase);
}

async function deleteCase(
  suiteId: string,
  caseId: string,
): Promise<APIGatewayResponse> {
  const db = getDBService();

  // Verify case exists
  const existing = await db.getCase(suiteId, caseId);
  if (!existing) {
    return jsonResponse(404, { error: "Test case not found" });
  }

  await db.deleteCase(suiteId, caseId);

  return jsonResponse(200, { message: "Test case deleted" });
}

// ---------------------------------------------------------------------------
// Main handler / router
// ---------------------------------------------------------------------------

/**
 * Lambda handler for test case CRUD operations with type-discriminator validation.
 * Routes based on httpMethod and resource path pattern.
 */
export async function handler(event: APIGatewayEvent): Promise<APIGatewayResponse> {
  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  // Extract tenant ID from Cognito authorizer claims
  const tenantId = extractTenantId(event);
  if (!tenantId) {
    return jsonResponse(401, { error: "Unauthorized: missing tenant identity" });
  }

  const method = event.httpMethod;
  const resource = event.resource;
  const suiteId = event.pathParameters?.suiteId ?? null;
  const caseId = event.pathParameters?.caseId ?? null;

  try {
    // Route: POST /suites/{suiteId}/cases
    if (method === "POST" && resource === "/suites/{suiteId}/cases" && suiteId) {
      return await createCase(suiteId, tenantId, event.body ?? null);
    }

    // Route: GET /suites/{suiteId}/cases
    if (method === "GET" && resource === "/suites/{suiteId}/cases" && suiteId) {
      return await listCases(suiteId);
    }

    // Route: GET /suites/{suiteId}/cases/{caseId}
    if (method === "GET" && resource === "/suites/{suiteId}/cases/{caseId}" && suiteId && caseId) {
      return await getCase(suiteId, caseId);
    }

    // Route: PUT /suites/{suiteId}/cases/{caseId}
    if (method === "PUT" && resource === "/suites/{suiteId}/cases/{caseId}" && suiteId && caseId) {
      return await updateCase(suiteId, caseId, tenantId, event.body ?? null);
    }

    // Route: DELETE /suites/{suiteId}/cases/{caseId}
    if (method === "DELETE" && resource === "/suites/{suiteId}/cases/{caseId}" && suiteId && caseId) {
      return await deleteCase(suiteId, caseId);
    }

    return jsonResponse(404, { error: `Route not found: ${method} ${resource}` });
  } catch (error) {
    console.error("[cases] Handler error:", error instanceof Error ? error.message : error);

    // Handle DynamoDB condition check failures
    if (error instanceof Error && error.name === "ConditionalCheckFailedException") {
      return jsonResponse(409, { error: "Resource already exists or was modified" });
    }

    return jsonResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
}
