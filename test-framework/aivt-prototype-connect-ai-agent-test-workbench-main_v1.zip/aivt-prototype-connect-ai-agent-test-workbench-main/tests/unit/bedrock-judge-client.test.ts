/**
 * Unit tests for the Bedrock Judge Client wrapper (Task 4.1, migrated
 * for Wave-2 prompt-management — Task 17.6).
 *
 * Validates: Requirements 3.1, 3.3, 3.4, 3.5, 3.6, 6.3, 1.3, 10.1,
 * 10.3, 11.2, 11.3, 17.4.
 *
 * Runtime behaviour covered:
 * - Per-call timeout → typed `JudgeTimeoutError` carrying `timeoutMs`
 *   (Requirement 3.3). The Evaluation Lambda maps this to
 *   `Evaluation_Error_State` code `TIMEOUT` without substituting local
 *   scoring (Requirement 8.1) — verified here via `instanceof`.
 * - Response with no fenced JSON and no recoverable JSON object →
 *   typed `JudgeResponseParseError` (Requirement 3.4).
 * - Response with a fenced ```` ``` ```` block whose contents are not
 *   valid JSON → typed `JudgeResponseParseError` (Requirement 3.4).
 * - Parsed object missing the `reasoning` field, or whose `reasoning`
 *   field is non-string, or missing the `score` field, or whose `score`
 *   field is empty → typed `JudgeResponseParseError` (Requirement 3.4).
 * - Happy path: returns the raw `{ reasoning, score }` from the model
 *   verbatim — the `score` label is NOT interpreted, normalized, or
 *   remapped (Requirement 3.5). Score-Scale mapping happens downstream
 *   in `evaluation-scoring.ts`.
 * - `modelId` on the dispatched `ConverseCommand` is read from the
 *   registry-resolved prompt — not from `process.env.JUDGE_MODEL_ID`
 *   (Wave-2 migration; the legacy env-var fallback is gone).
 * - Inference config matches the resolved Anthropic Claude 4.x
 *   capability profile: `maxTokens` only, with `temperature`,
 *   `topP`, `topK`, and `stopSequences` absent (R17.4).
 * - `_setBedrockClient` test seam (mirroring the existing
 *   `_setBedrockClient` patterns elsewhere) lets tests inject a mock
 *   client without ever constructing a real `BedrockRuntimeClient`
 *   (Requirement 3.6).
 * - Static regression guard — the migrated source no longer carries a
 *   `process.env.*_MODEL_ID ?? "..."` fallback (R1.3 / R15.4 / Task
 *   17.6 acceptance criterion).
 */

import { readFileSync } from "node:fs";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ConverseCommand } from "@aws-sdk/client-bedrock-runtime";
import {
  judge,
  fillTemplate,
  extractJson,
  JudgeTimeoutError,
  JudgeResponseParseError,
  DEFAULT_JUDGE_TIMEOUT_MS,
  _setBedrockClient,
  _resetBedrockClient,
} from "../../src/backend/orchestration/bedrock-judge-client";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import { PROMPT_REGISTRY } from "../../src/backend/orchestration/prompt-registry";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------

/** A judge promptKey — `judge_goal_success_rate` is the canonical default. */
const JUDGE_PROMPT_KEY = "judge_goal_success_rate" as const;
const JUDGE_TEMPLATE = PROMPT_REGISTRY.judge_goal_success_rate.defaultText;

/** The registry-default modelId for the judge family (Anthropic Claude
 *  Sonnet 4.6 → cross-region inference profile). The build-invariants
 *  test in `tests/unit/prompt-registry.test.ts` ensures this stays in
 *  sync with `SUPPORTED_MODELS`. */
const EXPECTED_DEFAULT_MODEL_ID = "us.anthropic.claude-sonnet-4-6";

/** Vars satisfying the AgentCore template's declared placeholders. */
const SIMPLE_VARS = {
  available_tools: "(none)",
  context: "U: hi\nA: hello",
} as const;

/** Empty-string `runId` makes `resolvePromptForRun` fall back to the
 *  live registry — exactly what we want for a unit test that has
 *  injected the empty-overrides Prompts_Store below. */
const RUN_ID = "" as const;

/** Build a Bedrock Converse response carrying a single text content block. */
function makeConverseResponse(text: string): {
  output: { message: { content: Array<{ text: string }> } };
} {
  return { output: { message: { content: [{ text }] } } };
}

/** Build a duck-typed Bedrock client whose `send` returns the given
 *  Converse response. Mirrors the `_setBedrockClient` injection pattern
 *  in `tests/unit/customer-simulator.test.ts`. */
function makeMockBedrockClient(
  sendFn: (
    cmd: unknown,
    opts?: { abortSignal?: AbortSignal }
  ) => Promise<unknown>
): Parameters<typeof _setBedrockClient>[0] {
  return { send: sendFn } as unknown as Parameters<typeof _setBedrockClient>[0];
}

/**
 * Inject a stub Prompts_Store so `resolvePromptForRun(promptKey, "")`
 * goes through the live-fallback path and returns the registry's
 * bundled default for the supplied promptKey. Same pattern as
 * `tests/unit/customer-simulator.test.ts`.
 */
function setupPromptStoreWithDefaults(): void {
  _clearPromptRegistryCaches();
  const store = {
    getSnapshot: vi.fn().mockResolvedValue(null),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  } as unknown as DynamoDBService;
  _setPromptRegistryStore(store);
}

// ---------------------------------------------------------------------------
// Env / client lifecycle
// ---------------------------------------------------------------------------

const originalEnv = { ...process.env };

beforeEach(() => {
  process.env = { ...originalEnv };
  _resetBedrockClient();
  setupPromptStoreWithDefaults();
});

afterEach(() => {
  _setBedrockClient(null);
  _setPromptRegistryStore(null);
  _clearPromptRegistryCaches();
  process.env = { ...originalEnv };
});

// ---------------------------------------------------------------------------
// Pure helpers (used by the judge flow; verified directly so a regression
// in placeholder substitution or JSON extraction surfaces here rather than
// only via downstream parse failures).
// ---------------------------------------------------------------------------

describe("fillTemplate", () => {
  it("substitutes every occurrence of each {key} placeholder", () => {
    const out = fillTemplate(
      "before {a} middle {a} {b} end",
      { a: "X", b: "Y" }
    );
    expect(out).toBe("before X middle X Y end");
  });

  it("leaves placeholders whose keys are not in vars untouched", () => {
    // The AWS-published prompt templates embed JSON-Schema braces like
    // `{"properties": ...}` that the judge model must see literally.
    // Those braces are NOT keys in `vars`, so they pass through.
    const out = fillTemplate(
      'schema: {"properties": {"score": "..."}} ctx: {context}',
      { context: "C" }
    );
    expect(out).toBe(
      'schema: {"properties": {"score": "..."}} ctx: C'
    );
  });
});

describe("extractJson", () => {
  it("returns the trimmed inner content of a ```json fenced block", () => {
    const raw = '```json\n{"reasoning":"r","score":"Yes"}\n```';
    expect(extractJson(raw)).toBe('{"reasoning":"r","score":"Yes"}');
  });

  it("returns the trimmed inner content of a bare ``` fenced block", () => {
    const raw = '```\n{"reasoning":"r","score":"Yes"}\n```';
    expect(extractJson(raw)).toBe('{"reasoning":"r","score":"Yes"}');
  });

  it("falls back to the brace-bounded substring when no fence is present", () => {
    const raw = 'preamble {"reasoning":"r","score":"Yes"} trailing';
    expect(extractJson(raw)).toBe('{"reasoning":"r","score":"Yes"}');
  });

  it("returns the raw trimmed string when neither fence nor braces are present", () => {
    const raw = "  no json at all  ";
    expect(extractJson(raw)).toBe("no json at all");
  });
});

// ---------------------------------------------------------------------------
// Timeout behavior (Requirement 3.3, mapped by caller to Req 8.1 TIMEOUT)
// ---------------------------------------------------------------------------

describe("judge — timeout", () => {
  it("throws JudgeTimeoutError carrying timeoutMs when the SDK call exceeds the configured budget", async () => {
    // Mock `send` returns a promise that only rejects when the SDK abort
    // signal fires. The wrapper's `setTimeout` triggers the abort, the
    // mock rejects, and the wrapper's catch branch maps the timed-out
    // path to `JudgeTimeoutError`.
    const send = vi.fn().mockImplementation(
      (_cmd: unknown, opts?: { abortSignal?: AbortSignal }) =>
        new Promise<never>((_, reject) => {
          opts?.abortSignal?.addEventListener("abort", () => {
            const err = new Error("aborted");
            err.name = "AbortError";
            reject(err);
          });
        })
    );
    _setBedrockClient(makeMockBedrockClient(send));

    let caught: unknown;
    try {
      await judge({
        promptKey: JUDGE_PROMPT_KEY,
        vars: SIMPLE_VARS,
        runId: RUN_ID,
        timeoutMs: 25,
      });
    } catch (err) {
      caught = err;
    }

    expect(caught).toBeInstanceOf(JudgeTimeoutError);
    const err = caught as JudgeTimeoutError;
    // The Evaluation Lambda maps a TIMEOUT to the
    // `Evaluation_Error_State` (design §"Error Handling") via
    // `instanceof JudgeTimeoutError` plus these typed fields — no
    // string parsing of the message.
    expect(err.name).toBe("JudgeTimeoutError");
    expect(err.timeoutMs).toBe(25);
    expect(err.message).toContain("25");

    // Exactly one Converse call was attempted before the abort; the
    // wrapper does not retry (Requirement 3.5: the SDK's retry-with-
    // backoff is what surfaces persistent throttling, not this wrapper).
    expect(send).toHaveBeenCalledTimes(1);
  });

  it("exposes a 60_000ms default timeout that satisfies Requirement 3.3", () => {
    expect(DEFAULT_JUDGE_TIMEOUT_MS).toBe(60_000);
  });
});

// ---------------------------------------------------------------------------
// Response parsing failures (Requirement 3.4)
// ---------------------------------------------------------------------------

describe("judge — JudgeResponseParseError on malformed responses", () => {
  it("throws when the response has no fenced JSON and no JSON object substring", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(
        makeConverseResponse("I cannot evaluate this conversation.")
      );
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBeInstanceOf(JudgeResponseParseError);
  });

  it("throws when the response is empty/whitespace", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(makeConverseResponse("   \n  "));
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBeInstanceOf(JudgeResponseParseError);
  });

  it("throws when the fenced block contains malformed JSON", async () => {
    // Fence with non-JSON contents — `extractJson` returns the inner
    // text, `JSON.parse` rejects it, and the wrapper surfaces a typed
    // `JudgeResponseParseError`.
    const raw = "```json\n{ not valid json at all }\n```";
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    let caught: unknown;
    try {
      await judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID });
    } catch (err) {
      caught = err;
    }

    expect(caught).toBeInstanceOf(JudgeResponseParseError);
    const err = caught as JudgeResponseParseError;
    expect(err.name).toBe("JudgeResponseParseError");
    // The raw payload snippet is captured for diagnostic surfaces;
    // the caller forwards it into the `Evaluation_Error_State` reason.
    expect(err.responseSnippet).toContain("not valid json");
  });

  it("throws when the parsed JSON is a non-object (array, primitive)", async () => {
    const raw = '```json\n["Yes"]\n```';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBeInstanceOf(JudgeResponseParseError);
  });

  it("throws when the `reasoning` field is missing", async () => {
    const raw = '```json\n{"score":"Yes"}\n```';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBeInstanceOf(JudgeResponseParseError);
  });

  it("throws when the `reasoning` field is not a string", async () => {
    const raw = '```json\n{"reasoning":42,"score":"Yes"}\n```';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBeInstanceOf(JudgeResponseParseError);
  });

  it("throws when the `score` field is missing", async () => {
    const raw = '```json\n{"reasoning":"thoughts"}\n```';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBeInstanceOf(JudgeResponseParseError);
  });

  it("throws when the `score` field is an empty string", async () => {
    const raw = '```json\n{"reasoning":"thoughts","score":""}\n```';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBeInstanceOf(JudgeResponseParseError);
  });

  it("throws when the `score` field is not a string", async () => {
    const raw = '```json\n{"reasoning":"r","score":1}\n```';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBeInstanceOf(JudgeResponseParseError);
  });
});

// ---------------------------------------------------------------------------
// Happy path: raw passthrough of `{ reasoning, score }` (Requirement 3.5)
// ---------------------------------------------------------------------------

describe("judge — happy path", () => {
  it("returns the raw {reasoning, score} from a ```json fenced block unchanged", async () => {
    const reasoning =
      "The agent successfully called the right tool and resolved the issue.";
    const scoreLabel = "Above And Beyond";
    const raw = `\`\`\`json\n${JSON.stringify({
      reasoning,
      score: scoreLabel,
    })}\n\`\`\``;
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    const out = await judge({
      promptKey: JUDGE_PROMPT_KEY,
      vars: SIMPLE_VARS,
      runId: RUN_ID,
    });

    // The label is returned verbatim — no remapping to a number, no
    // case-folding, no normalization. Score_Scale mapping lives
    // downstream in `evaluation-scoring.ts` (Requirement 3.5).
    expect(out).toEqual({ reasoning, score: scoreLabel });
    expect(out.score).toBe("Above And Beyond");
    expect(typeof out.score).toBe("string");
  });

  it("returns the raw {reasoning, score} from a bare ``` fenced block", async () => {
    const raw = '```\n{"reasoning":"ok","score":"Yes"}\n```';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    const out = await judge({
      promptKey: JUDGE_PROMPT_KEY,
      vars: SIMPLE_VARS,
      runId: RUN_ID,
    });

    expect(out).toEqual({ reasoning: "ok", score: "Yes" });
  });

  it("returns the raw {reasoning, score} from an unfenced JSON object (brace-fallback path)", async () => {
    const raw = 'preamble {"reasoning":"r","score":"No"} tail';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    const out = await judge({
      promptKey: JUDGE_PROMPT_KEY,
      vars: SIMPLE_VARS,
      runId: RUN_ID,
    });

    expect(out).toEqual({ reasoning: "r", score: "No" });
  });

  it("does NOT interpret an out-of-rubric label — passes it through for the caller to flag as UNMAPPABLE_RESULT", async () => {
    // The wrapper has no knowledge of the rubric. A label that the
    // Score_Scale tables don't recognise (here: "Maybe") flows through
    // as-is so `evaluation-scoring.ts` can surface
    // `Evaluation_Error_State` code `UNMAPPABLE_RESULT` rather than
    // silently substituting a default (Requirement 3.5, 8.3).
    const raw = '```json\n{"reasoning":"r","score":"Maybe"}\n```';
    const send = vi.fn().mockResolvedValue(makeConverseResponse(raw));
    _setBedrockClient(makeMockBedrockClient(send));

    const out = await judge({
      promptKey: JUDGE_PROMPT_KEY,
      vars: SIMPLE_VARS,
      runId: RUN_ID,
    });

    expect(out.score).toBe("Maybe");
  });
});

// ---------------------------------------------------------------------------
// Registry-resolved modelId and inferenceConfig (R10.1, R11.2, R11.3, R17.4).
//
// The legacy `process.env.JUDGE_MODEL_ID ?? "..."` fallback was retired
// in Wave 2 — Task 17.6 of the prompt-management spec. The judge client
// now resolves its `(text, modelId, inferenceParameters)` triple via
// `resolvePromptForRun(promptKey, runId)` against the run's pinned
// snapshot (or the live override store when the snapshot lacks the
// promptKey). The Anthropic Claude 4.x capability profile forbids
// `temperature`, `topP`, `topK`, and `stopSequences`, so the
// `inferenceConfig` on the dispatched ConverseCommand carries
// `maxTokens` only.
// ---------------------------------------------------------------------------

describe("judge — registry resolves modelId and inferenceConfig (R10.1, R17.4)", () => {
  it("dispatches a ConverseCommand whose modelId comes from the registry default", async () => {
    let captured: ConverseCommand | undefined;
    const send = vi.fn().mockImplementation((cmd: ConverseCommand) => {
      captured = cmd;
      return Promise.resolve(
        makeConverseResponse('```json\n{"reasoning":"r","score":"Yes"}\n```')
      );
    });
    _setBedrockClient(makeMockBedrockClient(send));

    await judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID });

    expect(captured).toBeInstanceOf(ConverseCommand);
    expect(captured!.input.modelId).toBe(EXPECTED_DEFAULT_MODEL_ID);
  });

  it("emits an inferenceConfig whose key set matches the resolved Anthropic profile (maxTokens only)", async () => {
    let captured: ConverseCommand | undefined;
    const send = vi.fn().mockImplementation((cmd: ConverseCommand) => {
      captured = cmd;
      return Promise.resolve(
        makeConverseResponse('```json\n{"reasoning":"r","score":"Yes"}\n```')
      );
    });
    _setBedrockClient(makeMockBedrockClient(send));

    await judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID });

    const inferenceConfig = captured!.input.inferenceConfig ?? {};
    // R17.4: Anthropic Claude 4.x accepts `maxTokens` only. The other
    // four Converse keys (`temperature`, `topP`, `topK`,
    // `stopSequences`) are forbidden by the profile and silently
    // dropped by `buildInferenceConfig`.
    expect(Object.keys(inferenceConfig).sort()).toEqual(["maxTokens"]);
    expect(inferenceConfig.maxTokens).toBe(2048);
    expect(inferenceConfig.temperature).toBeUndefined();
    expect(inferenceConfig.topP).toBeUndefined();
    // No `additionalModelRequestFields` for Anthropic — only Nova carries `topK`.
    expect(captured!.input.additionalModelRequestFields).toBeUndefined();
  });

  it("renders the registry-resolved prompt as the Converse user message via fillTemplate", async () => {
    let captured: ConverseCommand | undefined;
    const send = vi.fn().mockImplementation((cmd: ConverseCommand) => {
      captured = cmd;
      return Promise.resolve(
        makeConverseResponse('```json\n{"reasoning":"r","score":"Yes"}\n```')
      );
    });
    _setBedrockClient(makeMockBedrockClient(send));

    const vars = {
      available_tools: "TOOLS_MARKER",
      context: "CONTEXT_MARKER",
    };
    await judge({ promptKey: JUDGE_PROMPT_KEY, vars, runId: RUN_ID });

    const messages = captured!.input.messages ?? [];
    expect(messages).toHaveLength(1);
    const text = (messages[0].content as Array<{ text: string }>)[0].text;
    // The registry-resolved prompt body was rendered against vars: the
    // placeholder names are gone, the var values are present.
    expect(text).toContain("TOOLS_MARKER");
    expect(text).toContain("CONTEXT_MARKER");
    expect(text).not.toContain("{available_tools}");
    expect(text).not.toContain("{context}");
    // And the byte-for-byte AgentCore template body was used (proving
    // the registry resolver, not a hardcoded SYSTEM_PROMPT literal,
    // supplied the body).
    expect(text).toContain(
      "You are an objective judge evaluating the quality of an AI assistant",
    );
    // Sanity: this substring belongs to the original AgentCore
    // template, not just the rendering function output.
    expect(JUDGE_TEMPLATE).toContain(
      "You are an objective judge evaluating the quality of an AI assistant",
    );
  });
});

// ---------------------------------------------------------------------------
// `_setBedrockClient` injection contract (Requirement 3.6)
// ---------------------------------------------------------------------------

describe("_setBedrockClient — test seam (no AWS invocation)", () => {
  it("routes every judge() call through the injected client", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(
        makeConverseResponse('```json\n{"reasoning":"r","score":"Yes"}\n```')
      );
    _setBedrockClient(makeMockBedrockClient(send));

    await judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID });
    await judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID });

    // Both calls hit the injected mock, never a real Bedrock client.
    expect(send).toHaveBeenCalledTimes(2);
  });

  it("forwards the `abortSignal` from the wrapper's AbortController to the injected send()", async () => {
    // The injected `send` sees an `AbortSignal` on its options arg even
    // on the happy path (because the wrapper unconditionally arms its
    // per-call timeout). A test that asserts the signal is plumbed
    // through guards against a regression where a future refactor drops
    // the abort wiring and silently leaks timed-out work.
    const seenSignals: Array<AbortSignal | undefined> = [];
    const send = vi
      .fn()
      .mockImplementation(
        (_cmd: unknown, opts?: { abortSignal?: AbortSignal }) => {
          seenSignals.push(opts?.abortSignal);
          return Promise.resolve(
            makeConverseResponse(
              '```json\n{"reasoning":"r","score":"Yes"}\n```'
            )
          );
        }
      );
    _setBedrockClient(makeMockBedrockClient(send));

    await judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID });

    expect(seenSignals).toHaveLength(1);
    expect(seenSignals[0]).toBeInstanceOf(AbortSignal);
    // The signal was not aborted on the happy path — only the timeout
    // path triggers an abort.
    expect(seenSignals[0]!.aborted).toBe(false);
  });

  it("propagates non-timeout SDK errors verbatim (caller maps them to JUDGE_ERROR)", async () => {
    // The wrapper distinguishes TIMEOUT from JUDGE_ERROR. Non-timeout
    // SDK errors (`ThrottlingException`, `ValidationException`,
    // `AccessDeniedException`, network errors, etc.) propagate
    // unchanged so the caller can keep using `instanceof
    // JudgeTimeoutError` / `instanceof JudgeResponseParseError` as the
    // discriminator and map everything else to
    // `Evaluation_Error_State` code `JUDGE_ERROR` (Requirement 8.2).
    const sdkErr = Object.assign(new Error("validation failed"), {
      name: "ValidationException",
    });
    const send = vi.fn().mockRejectedValue(sdkErr);
    _setBedrockClient(makeMockBedrockClient(send));

    await expect(
      judge({ promptKey: JUDGE_PROMPT_KEY, vars: SIMPLE_VARS, runId: RUN_ID })
    ).rejects.toBe(sdkErr);
  });
});

// ---------------------------------------------------------------------------
// Static regression guard (R1.3 / R15.4 — Task 17.6 acceptance criterion).
//
// The migrated source must NOT contain a `process.env.*_MODEL_ID ?? "..."`
// fallback. The static AST-based `prompts-registry-only-resolution`
// property test enforces the same rule across all callsites; this
// per-file regression guard is duplicated here so the failure surfaces
// next to the judge-client tests, where a developer iterating on this
// module is most likely to spot it.
// ---------------------------------------------------------------------------

describe("judge — registry-only resolution (no JUDGE_MODEL_ID fallback)", () => {
  it("the migrated module contains no `process.env.*_MODEL_ID ?? \"...\"` fallback", () => {
    const sourcePath = path.join(
      __dirname,
      "..",
      "..",
      "src",
      "backend",
      "orchestration",
      "bedrock-judge-client.ts",
    );
    const source = readFileSync(sourcePath, "utf8");
    const fallbackPattern =
      /process\.env\.[A-Z][A-Z0-9_]*_MODEL_ID\s*(?:\?\?|\|\|)\s*["'`]/;
    expect(source).not.toMatch(fallbackPattern);
  });

  it("the migrated module contains no inline `temperature: 0` literal in a Converse inferenceConfig", () => {
    const sourcePath = path.join(
      __dirname,
      "..",
      "..",
      "src",
      "backend",
      "orchestration",
      "bedrock-judge-client.ts",
    );
    const source = readFileSync(sourcePath, "utf8");
    // The legacy block was `inferenceConfig: { maxTokens: 1024,
    // temperature: 0 }`. After migration, `buildInferenceConfig`
    // shapes the `inferenceConfig` from the resolved prompt's
    // capability profile, and the Anthropic 4.x family forbids
    // `temperature` so it never appears on the wire. Strip line and
    // block comments before scanning so the regression guard ignores
    // descriptive doc strings that legitimately reference the legacy
    // values for migration history.
    const codeOnly = source
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/(^|[^:])\/\/[^\n]*/g, "$1");
    expect(codeOnly).not.toMatch(/temperature:\s*0\b/);
    expect(codeOnly).not.toMatch(/maxTokens:\s*1024\b/);
  });
});
