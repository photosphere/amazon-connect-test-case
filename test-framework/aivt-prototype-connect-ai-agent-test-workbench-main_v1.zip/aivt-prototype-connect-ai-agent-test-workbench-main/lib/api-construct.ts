import * as cdk from 'aws-cdk-lib';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { Construct } from 'constructs';

import { computeBedrockGrants } from './bedrock-grants';
import { PROMPT_REGISTRY } from '../src/backend/orchestration/prompt-registry';
import type {
  ModelKey,
  PromptKey,
} from '../src/backend/orchestration/prompt-registry';

export interface ApiConstructProps {
  /** Cognito User Pool for authorization. */
  userPool: cognito.IUserPool;
  /** DynamoDB table for data storage. */
  table: dynamodb.ITable;
  /** Connect instance ID (UUID). */
  connectInstanceId: string;
  /** Q in Connect assistant ID. */
  assistantId: string;
  /** Step Functions state machine ARN (for Run Trigger Lambda). */
  stateMachineArn?: string;
}

export class ApiConstruct extends Construct {
  public readonly api: apigateway.RestApi;
  public readonly authorizer: apigateway.IAuthorizer;
  public readonly discoveryLambda: lambda.Function;
  public readonly suiteCrudLambda: lambda.Function;
  public readonly casesLambda: lambda.Function;
  public readonly runTriggerLambda: lambda.Function;
  public readonly resultsLambda: lambda.Function;
  public readonly scaffoldLambda: lambda.Function;
  public readonly analysisLambda: lambda.Function;
  public readonly comparisonSummaryLambda: lambda.Function;
  public readonly suiteRecommendLambda: lambda.Function;
  public readonly promptsLambda: lambda.Function;

  constructor(scope: Construct, id: string, props: ApiConstructProps) {
    super(scope, id);

    const stack = cdk.Stack.of(this);

    // -----------------------------------------------------------------------
    // API Gateway REST API
    // -----------------------------------------------------------------------

    this.api = new apigateway.RestApi(this, 'TestPlatformApi', {
      restApiName: `${stack.stackName}-api`,
      description: 'Connect Agent Test Platform API',
      deployOptions: {
        stageName: 'prod',
        throttlingRateLimit: 100,
        throttlingBurstLimit: 200,
      },
      defaultCorsPreflightOptions: {
        allowOrigins: apigateway.Cors.ALL_ORIGINS,
        allowMethods: apigateway.Cors.ALL_METHODS,
        // `X-User-Email` is the display-hint header the web
        // client attaches on every authenticated request so the
        // backend can persist the editor's email alongside the
        // Cognito `sub` UUID on Prompts overrides (see
        // `extractDisplayEmail` in `src/backend/handlers/prompts.ts`).
        // Browsers preflight any request that carries a non-simple
        // header — without this entry every API call from the SPA
        // fails with `request header field x-user-email is not
        // allowed by Access-Control-Allow-Headers in preflight
        // response`.
        allowHeaders: [
          'Content-Type',
          'Authorization',
          'X-User-Email',
        ],
      },
    });

    // Add CORS headers to API Gateway's auto-generated 4xx and 5xx error
    // responses (e.g. authorizer rejections). Without these, a 401 from the
    // Cognito authorizer reaches the browser without the
    // `Access-Control-Allow-Origin` header and gets reported as a CORS error
    // — masking the real (auth) cause and forcing operators to inspect the
    // raw network response to diagnose. `defaultCorsPreflightOptions` only
    // covers OPTIONS preflight, not error responses on the actual request.
    const errorCorsHeaders: Record<string, string> = {
      'gatewayresponse.header.Access-Control-Allow-Origin': "'*'",
      // Mirror the preflight allow-list above (including
      // `X-User-Email`) so error responses from the authorizer or
      // a Lambda crash also satisfy the browser's CORS check. Without
      // this, an authorizer 401 on a request carrying
      // `X-User-Email` would surface as an opaque CORS error in
      // the SPA instead of the real 401.
      'gatewayresponse.header.Access-Control-Allow-Headers':
        "'Content-Type,Authorization,X-User-Email'",
      'gatewayresponse.header.Access-Control-Allow-Methods':
        "'OPTIONS,GET,PUT,POST,DELETE,PATCH,HEAD'",
    };
    new apigateway.GatewayResponse(this, 'Default4xxCors', {
      restApi: this.api,
      type: apigateway.ResponseType.DEFAULT_4XX,
      responseHeaders: errorCorsHeaders,
    });
    new apigateway.GatewayResponse(this, 'Default5xxCors', {
      restApi: this.api,
      type: apigateway.ResponseType.DEFAULT_5XX,
      responseHeaders: errorCorsHeaders,
    });

    // -----------------------------------------------------------------------
    // Cognito Authorizer — validates both user-pool and client-credentials tokens
    // -----------------------------------------------------------------------

    const authorizer = new apigateway.CognitoUserPoolsAuthorizer(this, 'CognitoAuthorizer', {
      cognitoUserPools: [props.userPool],
      identitySource: 'method.request.header.Authorization',
    });
    this.authorizer = authorizer;

    const authorizationOptions: apigateway.MethodOptions = {
      authorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
      authorizationScopes: ['test-platform/run'],
    };

    // -----------------------------------------------------------------------
    // Shared environment variables for all Lambdas
    // -----------------------------------------------------------------------

    const sharedEnv: Record<string, string> = {
      CONNECT_INSTANCE_ID: props.connectInstanceId,
      ASSISTANT_ID: props.assistantId,
      TABLE_NAME: props.table.tableName,
    };

    // -----------------------------------------------------------------------
    // Bedrock grant summary — populated as each Bedrock-calling Lambda is
    // wired below via `computeBedrockGrants`. Surfaced on the
    // `BedrockGrantSummary` CFN output (R19.6) so a deployment review can
    // read off which models each Lambda is permitted to invoke without
    // parsing the synthesised IAM JSON. Keyed by the Lambda construct's
    // logical id (the second argument to `new NodejsFunction(this, ...)`)
    // so the output's keys match what shows up in the CFN template.
    //
    // Post-Wave-3 posture (Task 20.1): the helper-derived
    // `iam.PolicyStatement` from `computeBedrockGrants` is now the
    // ONLY Bedrock grant on each Lambda role. The Wave 0 dual-grant
    // safety overlap (registry-derived statement attached alongside a
    // legacy inline `bedrock:*` block, kept while Waves 0–2 burned in)
    // has been removed — the registry has been the production
    // resolution path long enough that a regression in
    // `allowedModels[]` is caught by the CDK assertion test in
    // `tests/cdk/bedrock-grants.test.ts` rather than a dual grant.
    const bedrockGrantSummary: Record<string, readonly ModelKey[]> = {};

    // Common Lambda configuration
    const commonLambdaProps = {
      runtime: lambda.Runtime.NODEJS_24_X,
      architecture: lambda.Architecture.ARM_64,
      tracing: lambda.Tracing.ACTIVE,
      environment: sharedEnv,
      bundling: {
        // Include @aws-sdk/client-qconnect in the bundle rather than using the
        // Lambda runtime's built-in version, which lacks the newer
        // orchestrationAIAgentConfiguration schema support.
        externalModules: [
          '@aws-sdk/client-dynamodb',
          '@aws-sdk/lib-dynamodb',
          '@aws-sdk/client-sfn',
          '@aws-sdk/client-bedrock-runtime',
          // Deliberately NOT excluding @aws-sdk/client-qconnect
        ],
      },
    };

    // -----------------------------------------------------------------------
    // Lambda: Discovery (GET /agents, GET /agents/{agentId})
    // -----------------------------------------------------------------------

    this.discoveryLambda = new NodejsFunction(this, 'DiscoveryLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/discovery.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-discovery`,
      description: 'Lists and retrieves AI agent configurations from Q in Connect',
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
    });

    // IAM: wisdom + qconnect ListAIAgents, GetAIAgent, GetAIPrompt
    // ListAIAgents resolves to the assistant ARN; GetAIAgent resolves to ai-agent ARN;
    // GetAIPrompt resolves the orchestration prompt id surfaced on the agent
    // configuration into the actual YAML prompt body shown in the GUI.
    this.discoveryLambda.addToRolePolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'wisdom:ListAIAgents',
        'wisdom:GetAIAgent',
        'wisdom:GetAIPrompt',
        'qconnect:ListAIAgents',
        'qconnect:GetAIAgent',
        'qconnect:GetAIPrompt',
      ],
      resources: [
        `arn:aws:wisdom:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:wisdom:${stack.region}:${stack.account}:ai-agent/*`,
        `arn:aws:wisdom:${stack.region}:${stack.account}:ai-prompt/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:ai-agent/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:ai-prompt/*`,
      ],
    }));

    // -----------------------------------------------------------------------
    // Lambda: Suite CRUD (/suites/*)
    // -----------------------------------------------------------------------

    this.suiteCrudLambda = new NodejsFunction(this, 'SuiteCrudLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/suites.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-suite-crud`,
      description: 'CRUD operations for test suites and test cases',
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
    });

    // IAM: DynamoDB read/write
    props.table.grantReadWriteData(this.suiteCrudLambda);

    // IAM: Q in Connect ListAIAgents — GET /suites enriches each suite with
    // the resolved agent display name (agent-grouped-suites feature). The
    // handler calls `listAgents()` and resolves agentId -> name; without
    // this grant the call throws AccessDenied, the handler falls back to an
    // empty map, and the UI renders raw agentIds instead of agent names.
    // ListAIAgents authorizes against BOTH the assistant ARN and the
    // per-agent `ai-agent/{assistantId}/*` ARN, so both must be listed
    // (matching the DiscoveryLambda grant) — granting only `assistant/*`
    // still yields AccessDenied on the `ai-agent/*` resource.
    this.suiteCrudLambda.addToRolePolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'wisdom:ListAIAgents',
        'qconnect:ListAIAgents',
      ],
      resources: [
        `arn:aws:wisdom:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:wisdom:${stack.region}:${stack.account}:ai-agent/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:ai-agent/*`,
      ],
    }));

    // -----------------------------------------------------------------------
    // Lambda: Cases CRUD (/suites/{suiteId}/cases/*)
    // -----------------------------------------------------------------------

    this.casesLambda = new NodejsFunction(this, 'CasesLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/cases.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-cases`,
      description: 'CRUD operations for test cases with type-discriminator validation',
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
    });

    // IAM: DynamoDB read/write for persisting cases
    props.table.grantReadWriteData(this.casesLambda);

    // IAM: Discovery API read access for content tag filter validation (R13)
    this.casesLambda.addToRolePolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'wisdom:ListAIAgents',
        'wisdom:GetAIAgent',
        'qconnect:ListAIAgents',
        'qconnect:GetAIAgent',
      ],
      resources: [
        `arn:aws:wisdom:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:wisdom:${stack.region}:${stack.account}:ai-agent/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:ai-agent/*`,
      ],
    }));

    // -----------------------------------------------------------------------
    // Lambda: Run Trigger (POST /runs, POST /runs/{runId}/abort)
    // -----------------------------------------------------------------------

    this.runTriggerLambda = new NodejsFunction(this, 'RunTriggerLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/runs.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-run-trigger`,
      description: 'Triggers test runs and handles abort requests',
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
      environment: {
        ...sharedEnv,
        STATE_MACHINE_ARN: props.stateMachineArn ?? '',
      },
    });

    // IAM: DynamoDB read/write + Step Functions start/stop
    props.table.grantReadWriteData(this.runTriggerLambda);
    this.runTriggerLambda.addToRolePolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'states:StartExecution',
        'states:StopExecution',
      ],
      resources: [props.stateMachineArn ?? `arn:aws:states:${stack.region}:${stack.account}:stateMachine:*`],
    }));

    // Also needs Q in Connect for agent snapshot. GetAIPrompt resolves the
    // orchestration prompt id into the YAML body persisted on the snapshot
    // (so failure-analysis and the case-detail page see the actual prompt
    // text, not the bare prompt id).
    this.runTriggerLambda.addToRolePolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'wisdom:GetAIAgent',
        'wisdom:GetAIPrompt',
        'qconnect:GetAIAgent',
        'qconnect:GetAIPrompt',
      ],
      resources: [
        `arn:aws:wisdom:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:wisdom:${stack.region}:${stack.account}:ai-agent/*`,
        `arn:aws:wisdom:${stack.region}:${stack.account}:ai-prompt/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:ai-agent/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:ai-prompt/*`,
      ],
    }));

    // -----------------------------------------------------------------------
    // Lambda: Results (GET /runs/*, GET /suites/{suiteId}/runs)
    // -----------------------------------------------------------------------

    this.resultsLambda = new NodejsFunction(this, 'ResultsLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/results.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-results`,
      description: 'Retrieves test run results and run history',
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
    });

    // IAM: DynamoDB read only
    props.table.grantReadData(this.resultsLambda);

    // -----------------------------------------------------------------------
    // Lambda: Scaffold (POST /suites/{suiteId}/cases/scaffold)
    // -----------------------------------------------------------------------

    this.scaffoldLambda = new NodejsFunction(this, 'ScaffoldLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/scaffold.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-scaffold`,
      description: 'AI-powered test case scaffolding using Bedrock',
      timeout: cdk.Duration.seconds(60),
      memorySize: 512,
    });

    // IAM: Bedrock InvokeModel + Converse, DynamoDB read, Q in Connect GetAIAgent.
    // The Bedrock grant is produced by `computeBedrockGrants` from the
    // Prompt_Registry — see the registry-derived block immediately below.
    // The Scaffold handler invokes the Prompt_Resolver against
    // `suite_scaffold` and `case_scaffold` (both share this Lambda —
    // there's no second NodejsFunction for the case-level path), so
    // the grant is the union of `allowedModels[]` for both keys.
    {
      const grant = computeBedrockGrants({
        promptKeys: ['suite_scaffold', 'case_scaffold'],
        stack,
      });
      this.scaffoldLambda.addToRolePolicy(grant.statement);
      bedrockGrantSummary.ScaffoldLambda = grant.modelKeys;
    }
    props.table.grantReadData(this.scaffoldLambda);
    this.scaffoldLambda.addToRolePolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'wisdom:GetAIAgent',
        'qconnect:GetAIAgent',
      ],
      resources: [
        `arn:aws:wisdom:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:wisdom:${stack.region}:${stack.account}:ai-agent/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:assistant/*`,
        `arn:aws:qconnect:${stack.region}:${stack.account}:ai-agent/*`,
      ],
    }));

    // -----------------------------------------------------------------------
    // Lambda: Analysis (POST /runs/{runId}/analyze)
    // -----------------------------------------------------------------------

    this.analysisLambda = new NodejsFunction(this, 'AnalysisLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/analysis.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-analysis`,
      description: 'AI-powered failure root cause analysis using Bedrock',
      timeout: cdk.Duration.seconds(120),
      memorySize: 512,
    });

    // IAM: Bedrock InvokeModel + Converse, DynamoDB read/write.
    // Read for snapshot/cases/persisted analyses; write for the
    // persistence-on-success step that stores per-case analyses at
    // PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId} (R6.1). The Bedrock
    // grant is produced by `computeBedrockGrants` from the
    // Prompt_Registry — see the registry-derived block immediately
    // below. The Analysis handler invokes `failure_analysis`.
    {
      const grant = computeBedrockGrants({
        promptKeys: ['failure_analysis'],
        stack,
      });
      this.analysisLambda.addToRolePolicy(grant.statement);
      bedrockGrantSummary.AnalysisLambda = grant.modelKeys;
    }
    props.table.grantReadWriteData(this.analysisLambda);

    // -----------------------------------------------------------------------
    // Lambda: Comparison Summary (POST /comparisons/summarize)
    // -----------------------------------------------------------------------

    this.comparisonSummaryLambda = new NodejsFunction(this, 'ComparisonSummaryLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/comparison-summary.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-comparison-summary`,
      description: 'Bedrock-generated summary of differences between two test runs',
      // Bedrock Converse on a 4.6 Sonnet profile is fast (~3-5s) but allow
      // headroom for cold starts + DDB reads. Stays well under API Gateway's
      // 30s integration limit.
      timeout: cdk.Duration.seconds(25),
      memorySize: 512,
    });

    // IAM: same Bedrock + DDB read posture as the Analysis Lambda — they
    // both call Converse on the Anthropic inference profile and read the
    // run/case/snapshot DDB partitions. The Bedrock grant is produced by
    // `computeBedrockGrants` from the Prompt_Registry — see the
    // registry-derived block immediately below. The Comparison Summary
    // handler invokes `comparison_summary`.
    {
      const grant = computeBedrockGrants({
        promptKeys: ['comparison_summary'],
        stack,
      });
      this.comparisonSummaryLambda.addToRolePolicy(grant.statement);
      bedrockGrantSummary.ComparisonSummaryLambda = grant.modelKeys;
    }
    props.table.grantReadData(this.comparisonSummaryLambda);

    // -----------------------------------------------------------------------
    // Lambda: Suite Recommend (POST /runs/{runId}/recommend-suite)
    // -----------------------------------------------------------------------

    this.suiteRecommendLambda = new NodejsFunction(this, 'SuiteRecommendLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/suite-recommend.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-suite-recommend`,
      description: 'Bedrock-generated per-suite consolidated recommendations for a run',
      timeout: cdk.Duration.seconds(120),
      memorySize: 512,
    });

    // IAM: same Bedrock posture as the Analysis Lambda — Converse against
    // the Anthropic inference profile in us-east-1 / us-east-2 / us-west-2,
    // plus the foundation-model ARNs the inference profile fronts. The
    // Bedrock grant is produced by `computeBedrockGrants` from the
    // Prompt_Registry — see the registry-derived block immediately
    // below. The Suite Recommend handler invokes `suite_recommendation`.
    {
      const grant = computeBedrockGrants({
        promptKeys: ['suite_recommendation'],
        stack,
      });
      this.suiteRecommendLambda.addToRolePolicy(grant.statement);
      bedrockGrantSummary.SuiteRecommendLambda = grant.modelKeys;
    }
    // DDB read/write — Lambda persists the consolidated result at
    // PK=RUN#{runId}, SK=ANALYSIS#SUITE (R8.7).
    props.table.grantReadWriteData(this.suiteRecommendLambda);

    // -----------------------------------------------------------------------
    // Lambda: Prompts (/prompts/*)
    //
    // API surface for the Prompt Management feature: list / get / update /
    // reset prompts and view their override history (R8.1, R8.2). Same
    // `commonLambdaProps` posture as the audit Lambda (Node 20 ARM64,
    // tracing on, shared env). Memory bumped to 512 MiB because the
    // dry-render validation stage (R4.10) constructs a Bedrock
    // `ConverseCommand` for any model in the prompt's `allowedModels[]`
    // and the SDK is heavier to load than the lib-dynamodb client.
    //
    // Bundling note: `commonLambdaProps.bundling.externalModules` already
    // excludes `@aws-sdk/client-bedrock-runtime` from the bundle (the
    // Lambda runtime ships a compatible version), so the dry-render
    // validator's `ConverseCommand` constructor resolves at runtime
    // without inflating the deployment package. The validator never
    // calls `client.send`, so the runtime SDK is sufficient.
    // -----------------------------------------------------------------------

    this.promptsLambda = new NodejsFunction(this, 'PromptsLambda', {
      ...commonLambdaProps,
      entry: 'src/backend/handlers/prompts.ts',
      handler: 'handler',
      functionName: `${stack.stackName}-prompts`,
      description:
        'Prompts API: list/get/update/reset prompts and view history (Prompt Management feature)',
      timeout: cdk.Duration.seconds(30),
      memorySize: 512,
    });

    // DDB read/write — override and history rows live at
    // PK=PROMPT#{promptKey}, SK=OVERRIDE / HISTORY#{paddedVersion}, and
    // the audit best-effort write goes to PK=TENANT#{tenantId},
    // SK=AUDIT#{ts}. The handler also scans the table for the
    // `GET /prompts/active-runs` endpoint (R16.5).
    props.table.grantReadWriteData(this.promptsLambda);

    // Wave 0 dual grant (R19.2): registry-derived statement covering
    // the union of every prompt's `allowedModels[]`. The dry-render
    // validator builds a `ConverseCommand` for any model the user can
    // pick on the Prompts page, so the grant has to span every model
    // in the catalog. Sourced from `ALL_PROMPT_KEYS` (the closed
    // `PromptKey` union) to avoid drift if a new prompt is added to
    // the registry — `computeBedrockGrants` walks the registry and
    // unions every model.
    {
      const ALL_PROMPT_KEYS = Object.keys(PROMPT_REGISTRY) as PromptKey[];
      const grant = computeBedrockGrants({
        promptKeys: ALL_PROMPT_KEYS,
        stack,
      });
      this.promptsLambda.addToRolePolicy(grant.statement);
      bedrockGrantSummary.PromptsLambda = grant.modelKeys;
    }

    // -----------------------------------------------------------------------
    // API Gateway Routes
    // -----------------------------------------------------------------------

    this.configureRoutes(authorizationOptions);

    // -----------------------------------------------------------------------
    // Outputs
    // -----------------------------------------------------------------------

    new cdk.CfnOutput(this, 'ApiUrl', {
      value: this.api.url,
      description: 'API Gateway endpoint URL',
    });

    // R19.6: surface the helper-derived Bedrock grant summary on the CFN
    // template as a single JSON map keyed by Lambda logical id with the
    // alphabetically-sorted `modelKeys[]` each Lambda is permitted to
    // invoke. Lets a deployment review answer "which models can this
    // Lambda call?" without parsing the IAM policy JSON, and gives the
    // Task 10.6 assertion test a stable on-template artifact to compare
    // against the registry's expected union.
    new cdk.CfnOutput(this, 'BedrockGrantSummary', {
      value: JSON.stringify(bedrockGrantSummary),
      description:
        'Map of Bedrock-calling Lambda logical id -> readonly ModelKey[] derived from computeBedrockGrants (R19.6).',
    });
  }

  /**
   * Configure all API Gateway routes with their Lambda integrations.
   */
  private configureRoutes(authOptions: apigateway.MethodOptions): void {
    // --- /agents ---
    const agents = this.api.root.addResource('agents');
    const discoveryIntegration = new apigateway.LambdaIntegration(this.discoveryLambda);
    agents.addMethod('GET', discoveryIntegration, authOptions);

    // --- /agents/{agentId} ---
    const agentById = agents.addResource('{agentId}');
    agentById.addMethod('GET', discoveryIntegration, authOptions);

    // --- /suites ---
    const suites = this.api.root.addResource('suites');
    const suiteCrudIntegration = new apigateway.LambdaIntegration(this.suiteCrudLambda);
    suites.addMethod('POST', suiteCrudIntegration, authOptions);
    suites.addMethod('GET', suiteCrudIntegration, authOptions);

    // --- /suites/{suiteId} ---
    const suiteById = suites.addResource('{suiteId}');
    suiteById.addMethod('GET', suiteCrudIntegration, authOptions);
    suiteById.addMethod('PUT', suiteCrudIntegration, authOptions);
    suiteById.addMethod('DELETE', suiteCrudIntegration, authOptions);

    // --- /suites/{suiteId}/cases ---
    const cases = suiteById.addResource('cases');
    const casesIntegration = new apigateway.LambdaIntegration(this.casesLambda);
    cases.addMethod('POST', casesIntegration, authOptions);
    cases.addMethod('GET', casesIntegration, authOptions);

    // --- /suites/{suiteId}/cases/{caseId} ---
    const caseById = cases.addResource('{caseId}');
    caseById.addMethod('GET', casesIntegration, authOptions);
    caseById.addMethod('PUT', casesIntegration, authOptions);
    caseById.addMethod('DELETE', casesIntegration, authOptions);

    // --- /suites/{suiteId}/cases/scaffold ---
    const scaffold = cases.addResource('scaffold');
    const scaffoldIntegration = new apigateway.LambdaIntegration(this.scaffoldLambda);
    scaffold.addMethod('POST', scaffoldIntegration, authOptions);

    // --- /suites/{suiteId}/runs ---
    const suiteRuns = suiteById.addResource('runs');
    const resultsIntegration = new apigateway.LambdaIntegration(this.resultsLambda);
    suiteRuns.addMethod('GET', resultsIntegration, authOptions);

    // --- /runs ---
    const runs = this.api.root.addResource('runs');
    const runTriggerIntegration = new apigateway.LambdaIntegration(this.runTriggerLambda);
    runs.addMethod('POST', runTriggerIntegration, authOptions);

    // --- /runs/{runId} ---
    const runById = runs.addResource('{runId}');
    runById.addMethod('GET', resultsIntegration, authOptions);

    // --- /runs/{runId}/abort ---
    const abort = runById.addResource('abort');
    abort.addMethod('POST', runTriggerIntegration, authOptions);

    // --- /runs/{runId}/cases/{caseId} ---
    const runCases = runById.addResource('cases');
    const runCaseById = runCases.addResource('{caseId}');
    runCaseById.addMethod('GET', resultsIntegration, authOptions);

    // --- /runs/{runId}/snapshot ---
    // Surfaces the AgentSnapshot persisted by PrepareRun at
    // PK=RUN#{runId}, SK=SNAPSHOT. Used by the Compare Runs page to
    // diff agent configurations across two runs (tools added/removed,
    // model id changed, system prompt changes). Read-only; same auth
    // posture as the rest of the Results Lambda routes.
    const runSnapshot = runById.addResource('snapshot');
    runSnapshot.addMethod('GET', resultsIntegration, authOptions);

    // --- /runs/{runId}/analyze ---
    const analyze = runById.addResource('analyze');
    const analysisIntegration = new apigateway.LambdaIntegration(this.analysisLambda);
    analyze.addMethod('POST', analysisIntegration, authOptions);

    // --- /runs/{runId}/recommend-suite ---
    // Sibling to /analyze: produces the consolidated, prioritized per-suite
    // recommendation set rendered by the Recommended Changes Panel on the
    // Run Dashboard. Persisted at PK=RUN#{runId}, SK=ANALYSIS#SUITE so
    // repeat reads bypass Bedrock; pass `{ force: true }` to regenerate.
    const recommendSuite = runById.addResource('recommend-suite');
    const suiteRecommendIntegration = new apigateway.LambdaIntegration(
      this.suiteRecommendLambda,
    );
    recommendSuite.addMethod('POST', suiteRecommendIntegration, authOptions);

    // --- /comparisons/summarize ---
    // Single-resource POST endpoint that takes `{ runIdA, runIdB, suiteId? }`
    // in the body. Mounted under a dedicated `/comparisons` namespace
    // (rather than under `/runs/...`) because the operation isn't scoped
    // to either run individually — both ids are payload, not path.
    const comparisons = this.api.root.addResource('comparisons');
    const comparisonsSummarize = comparisons.addResource('summarize');
    const comparisonSummaryIntegration = new apigateway.LambdaIntegration(
      this.comparisonSummaryLambda,
    );
    comparisonsSummarize.addMethod('POST', comparisonSummaryIntegration, authOptions);

    // --- /prompts/* (Prompt Management feature) ---
    //
    // Routes mirror the dispatcher in `src/backend/handlers/prompts.ts`,
    // which keys off `event.resource` (the path template, not the
    // resolved path) — so the resource templates registered here
    // (`/prompts`, `/prompts/{promptKey}`, `/prompts/{promptKey}/reset`,
    // `/prompts/{promptKey}/history`, `/prompts/active-runs`) must
    // match the strings the dispatcher compares against verbatim.
    //
    // R8.1: every method carries the shared `authOptions`
    // (`authorizationType: COGNITO`, the User Pool authorizer, and
    // `authorizationScopes: ['test-platform/run']`). Dropping the scope
    // would flip the authorizer back to ID-token mode and 401 the
    // frontend, so all six methods reuse `authOptions` as-is.
    //
    // Resource ordering note: `active-runs` and `{promptKey}` are
    // sibling children of `/prompts`. API Gateway routes static
    // segments before path parameters, so a request to
    // `/prompts/active-runs` always matches the static resource even
    // though the path-parameter sibling exists. The order of
    // `addResource` calls below doesn't affect routing — it just
    // reflects how the dispatcher reads.
    const prompts = this.api.root.addResource('prompts');
    const promptsIntegration = new apigateway.LambdaIntegration(this.promptsLambda);
    prompts.addMethod('GET', promptsIntegration, authOptions);

    // --- /prompts/active-runs ---
    // Static segment registered before the `{promptKey}` sibling so it
    // sits visually with the parent listing. Returns the list of
    // currently in-flight runs that have already snapshotted a
    // resolved prompt set (R16.5) — used by the Prompts page to warn
    // before applying an override.
    const promptsActiveRuns = prompts.addResource('active-runs');
    promptsActiveRuns.addMethod('GET', promptsIntegration, authOptions);

    // --- /prompts/{promptKey} ---
    const promptByKey = prompts.addResource('{promptKey}');
    promptByKey.addMethod('GET', promptsIntegration, authOptions);
    promptByKey.addMethod('PUT', promptsIntegration, authOptions);

    // --- /prompts/{promptKey}/reset ---
    const promptReset = promptByKey.addResource('reset');
    promptReset.addMethod('POST', promptsIntegration, authOptions);

    // --- /prompts/{promptKey}/history ---
    const promptHistory = promptByKey.addResource('history');
    promptHistory.addMethod('GET', promptsIntegration, authOptions);
  }
}
