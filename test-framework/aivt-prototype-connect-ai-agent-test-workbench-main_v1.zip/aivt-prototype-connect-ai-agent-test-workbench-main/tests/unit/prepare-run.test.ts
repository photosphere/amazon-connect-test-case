/**
 * Unit tests for the PrepareRun handler's output contract.
 *
 * The state machine's HasSurvivingRagCases Choice node depends on
 * `$.hasRagCases` being present on PrepareRun's output. A regression here
 * crashes the entire state machine with `States.Runtime` and leaves runs
 * stuck in `running`. These tests pin the contract.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";

// Mock the DynamoDBService so PrepareRun's I/O calls succeed without AWS.
// `listPromptOverrides` is consulted at run start to pin the registry's
// effective prompts onto the AgentSnapshot (R11.1); returning an empty
// Map means every run-pinned promptKey resolves to its bundled default.
vi.mock("../../src/backend/services/dynamodb", () => ({
  DynamoDBService: vi.fn().mockImplementation(() => ({
    createRun: vi.fn().mockResolvedValue(undefined),
    writeSnapshot: vi.fn().mockResolvedValue(undefined),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  })),
}));

import {
  handler,
  type PrepareRunInput,
} from "../../src/backend/orchestration/handlers/prepare-run";

const baseAgentSnapshot = {
  agentId: "agent-1",
  name: "asst-test",
  systemPrompt: "you are a helpful agent",
  modelId: "model-1",
  tools: [],
};

function makeInput(
  overrides: Partial<PrepareRunInput> = {},
): PrepareRunInput {
  return {
    suiteId: "suite-1",
    tenantId: "tenant-1",
    runId: "run-test-123",
    startTime: "2026-06-09T14:00:00.000Z",
    concurrency: 9,
    agentSnapshot: baseAgentSnapshot,
    testCases: [],
    ...overrides,
  };
}

describe("PrepareRun handler — hasRagCases contract", () => {
  const ORIGINAL_ENV = process.env.ASSISTANT_ID;

  beforeEach(() => {
    process.env.ASSISTANT_ID = "asst-test";
  });

  afterEach(() => {
    if (ORIGINAL_ENV === undefined) {
      delete process.env.ASSISTANT_ID;
    } else {
      process.env.ASSISTANT_ID = ORIGINAL_ENV;
    }
  });

  it("sets hasRagCases=false when the suite has no test cases", async () => {
    const out = await handler(makeInput({ testCases: [] }));
    expect(out.hasRagCases).toBe(false);
  });

  it("sets hasRagCases=false when every case is type 'tool_sequence'", async () => {
    const out = await handler(
      makeInput({
        testCases: [
          { caseId: "c1", type: "tool_sequence" },
          { caseId: "c2", type: "tool_sequence" },
        ],
      }),
    );
    expect(out.hasRagCases).toBe(false);
  });

  it("sets hasRagCases=false when type is missing (legacy pre-feature records)", async () => {
    // Per the read-side contract on TestCase, missing `type` is treated as
    // tool_sequence. PrepareRun must follow the same convention.
    const out = await handler(
      makeInput({
        testCases: [{ caseId: "c1" }, { caseId: "c2" }],
      }),
    );
    expect(out.hasRagCases).toBe(false);
  });

  it("sets hasRagCases=true when at least one case is type 'rag'", async () => {
    const out = await handler(
      makeInput({
        testCases: [
          { caseId: "c1", type: "tool_sequence" },
          { caseId: "c2", type: "rag" },
          { caseId: "c3", type: "tool_sequence" },
        ],
      }),
    );
    expect(out.hasRagCases).toBe(true);
  });

  it("sets hasRagCases=true when every case is type 'rag'", async () => {
    const out = await handler(
      makeInput({
        testCases: [
          { caseId: "c1", type: "rag" },
          { caseId: "c2", type: "rag" },
        ],
      }),
    );
    expect(out.hasRagCases).toBe(true);
  });

  it("preserves all other output fields verbatim", async () => {
    const input = makeInput({
      testCases: [{ caseId: "c1", type: "tool_sequence" }],
    });
    const out = await handler(input);
    expect(out.runId).toBe(input.runId);
    expect(out.suiteId).toBe(input.suiteId);
    expect(out.startTime).toBe(input.startTime);
    expect(out.agentId).toBe(baseAgentSnapshot.agentId);
    expect(out.assistantId).toBe("asst-test");
    expect(out.testCases).toEqual(input.testCases);
  });
});
