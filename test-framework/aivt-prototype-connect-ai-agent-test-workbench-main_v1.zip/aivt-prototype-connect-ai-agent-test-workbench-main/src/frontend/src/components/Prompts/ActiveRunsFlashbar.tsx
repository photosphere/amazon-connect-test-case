/**
 * Post-save informational notice surfaced when the user saves (or
 * resets) a prompt while at least one test run is in progress.
 *
 * Implements task 13.8 of the prompt-management feature plan and the
 * following requirement:
 *
 *   - R14.6 — WHEN the user saves a prompt edit AND `getActiveRuns().count > 0`
 *     at submit time, THE Prompts_Page SHALL render a non-blocking
 *     notification (Cloudscape `Flashbar`) reading "Saved. The change
 *     will not affect runs already in progress; it will apply to the
 *     next run started." so that the user is not surprised by
 *     Run_Snapshot pinning.
 *
 * The message text is pinned VERBATIM to the requirement's wording so
 * that an audit trail can verify it; do not paraphrase.
 *
 * Ownership split with the parent ({@link PromptDetailPage}):
 *
 *   - The parent decides WHEN the notice should be visible by polling
 *     `getActiveRuns()` immediately before each save/reset and toggling
 *     the `visible` prop after a successful response when the
 *     submit-time count was non-zero.
 *
 *   - The component itself simply renders (or returns `null`) based on
 *     `visible` and forwards the dismiss event so the parent can hide
 *     the Flashbar.
 *
 * The component returns `null` rather than an empty Flashbar when
 * `visible` is false so it occupies no layout space and screen readers
 * do not encounter a stale alert region.
 *
 * @module frontend/components/Prompts/ActiveRunsFlashbar
 */

import Flashbar, {
  type FlashbarProps,
} from '@cloudscape-design/components/flashbar';

export interface ActiveRunsFlashbarProps {
  /** Whether the notice is currently shown. */
  visible: boolean;
  /** Fires when the user dismisses the Flashbar. */
  onDismiss: () => void;
}

export function ActiveRunsFlashbar({
  visible,
  onDismiss,
}: ActiveRunsFlashbarProps): JSX.Element | null {
  if (!visible) return null;
  const items: FlashbarProps.MessageDefinition[] = [
    {
      type: 'info',
      dismissible: true,
      onDismiss: onDismiss,
      content:
        'Saved. The change will not affect runs already in progress; it will apply to the next run started.',
      id: 'prompt-active-runs',
    },
  ];
  return <Flashbar items={items} />;
}
