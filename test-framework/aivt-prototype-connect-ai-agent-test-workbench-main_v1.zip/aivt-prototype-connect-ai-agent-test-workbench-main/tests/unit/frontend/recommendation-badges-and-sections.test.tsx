// @vitest-environment jsdom
/**
 * Unit tests for the test-case-validity-analysis frontend components:
 *
 * - RecommendationBadge: blue "Fix test" badge for test_case, orange "Fix agent" for agent targets
 * - RecommendedChangesPanel: section grouping with distinct headers and background tints
 * - FailureAnalysis DiffView: testCaseField sub-label, deep-link generation
 * - Backward compatibility: pre-feature records without testCaseField render with orange badge
 *
 * Validates: Requirements 7.1, 7.2, 7.3, 7.4, 7.5, 8.1, 8.2
 */

import React from 'react';
import { describe, it, expect, vi, beforeAll, afterEach } from 'vitest';
import { render, screen, cleanup, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

import type { Recommendation, PerSuiteRecommendation, RecommendationTarget } from '../../../src/shared/types';
import { RunStatus } from '../../../src/shared/enums';

// ---------------------------------------------------------------------------
// Mock the apiClient — required by RecommendedChangesPanel and FailureAnalysis
// (they call the API on mount).
// ---------------------------------------------------------------------------

const { apiGetMock, apiPostMock } = vi.hoisted(() => ({
  apiGetMock: vi.fn(),
  apiPostMock: vi.fn(),
}));

vi.mock('../../../src/frontend/src/api', () => {
  class MockApiClientError extends Error {
    public readonly status: number;
    public readonly retryable: boolean;
    constructor(status: number, message: string, retryable: boolean) {
      super(message);
      this.name = 'ApiClientError';
      this.status = status;
      this.retryable = retryable;
    }
  }
  class MockRuntimeConfigUnavailableError extends Error {
    constructor(message = 'Runtime configuration unavailable.') {
      super(message);
      this.name = 'RuntimeConfigUnavailableError';
    }
  }
  return {
    apiClient: {
      get: apiGetMock,
      post: apiPostMock,
      put: vi.fn(),
      delete: vi.fn(),
    },
    ApiClientError: MockApiClientError,
    RuntimeConfigUnavailableError: MockRuntimeConfigUnavailableError,
    loadConfig: vi.fn(),
    getConfig: vi.fn(() => ({ instanceMode: 'development' })),
    getConfigStatus: vi.fn(),
    subscribeToNotifications: vi.fn(() => () => {}),
    notifyError: vi.fn(),
  };
});

// ---------------------------------------------------------------------------
// Mock react-router-dom (same approach as other frontend tests)
// ---------------------------------------------------------------------------

const { mockNavigate } = vi.hoisted(() => ({
  mockNavigate: vi.fn(),
}));

vi.mock('react-router-dom', () => ({
  useParams: () => ({ runId: 'run-123' }),
  useSearchParams: () => [new URLSearchParams('suiteId=suite-abc'), vi.fn()],
  useNavigate: () => mockNavigate,
}));

// ---------------------------------------------------------------------------
// Import components AFTER mocks are registered
// ---------------------------------------------------------------------------

import {
  RecommendationBadge,
  RecommendedChangesPanel,
} from '../../../src/frontend/src/components/RecommendedChangesPanel';
import { FailureAnalysis } from '../../../src/frontend/src/pages/FailureAnalysis';

// ---------------------------------------------------------------------------
// jsdom polyfills for Cloudscape
// ---------------------------------------------------------------------------

beforeAll(() => {
  const g = globalThis as unknown as {
    ResizeObserver?: unknown;
    IntersectionObserver?: unknown;
  };
  if (typeof g.ResizeObserver === 'undefined') {
    g.ResizeObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
    };
  }
  if (typeof g.IntersectionObserver === 'undefined') {
    g.IntersectionObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
      takeRecords(): unknown[] { return []; }
      readonly root = null;
      readonly rootMargin = '';
      readonly thresholds: ReadonlyArray<number> = [];
    };
  }
  if (typeof window.matchMedia !== 'function') {
    window.matchMedia = (query: string) =>
      ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => {},
        removeListener: () => {},
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => false,
      }) as unknown as MediaQueryList;
  }
  if (!window.getComputedStyle) {
    window.getComputedStyle = () => ({} as CSSStyleDeclaration);
  }
});

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeRec(overrides: Partial<Recommendation> & { targetField: RecommendationTarget }): Recommendation {
  return {
    targetName: 'some-tool',
    currentText: 'old text',
    suggestedText: 'new text',
    rationale: 'because reasons',
    ...overrides,
  };
}

function makeSuiteRec(
  overrides: Partial<PerSuiteRecommendation> & { targetField: RecommendationTarget },
): PerSuiteRecommendation {
  return {
    targetName: 'some-tool',
    currentText: 'old text',
    suggestedText: 'new text',
    rationale: 'because reasons',
    priority: 1,
    predictedImpact: { liftedCaseIds: ['case-1'], rationale: 'should fix it' },
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// RecommendationBadge tests (R7.1, R7.2)
// ---------------------------------------------------------------------------

describe('RecommendationBadge', () => {
  it('renders a blue badge with text "Fix test" when targetField is "test_case" (R7.1)', () => {
    render(<RecommendationBadge targetField="test_case" />);
    expect(screen.getByText('Fix test')).toBeInTheDocument();
  });

  it('renders an orange "Fix agent" badge for tool_description (R7.2)', () => {
    render(<RecommendationBadge targetField="tool_description" />);
    expect(screen.getByText('Fix agent')).toBeInTheDocument();
  });

  it('renders an orange "Fix agent" badge for tool_instruction (R7.2)', () => {
    render(<RecommendationBadge targetField="tool_instruction" />);
    expect(screen.getByText('Fix agent')).toBeInTheDocument();
  });

  it('renders an orange "Fix agent" badge for tool_examples (R7.2)', () => {
    render(<RecommendationBadge targetField="tool_examples" />);
    expect(screen.getByText('Fix agent')).toBeInTheDocument();
  });

  it('renders an orange "Fix agent" badge for system_prompt (R7.2)', () => {
    render(<RecommendationBadge targetField="system_prompt" />);
    expect(screen.getByText('Fix agent')).toBeInTheDocument();
  });

  it('renders an orange "Fix agent" badge for unknown/legacy targetField values (backward compat R8.2)', () => {
    render(<RecommendationBadge targetField="some_unknown_field" />);
    expect(screen.getByText('Fix agent')).toBeInTheDocument();
  });
});

// ---------------------------------------------------------------------------
// RecommendedChangesPanel: Section grouping (R7.3, R7.4)
// ---------------------------------------------------------------------------

describe('RecommendedChangesPanel — section grouping', () => {
  it('renders both "Agent recommendations" and "Test case recommendations" headers when both types exist (R7.3)', async () => {
    // Mock the suite endpoint to return both agent and test_case recommendations
    apiPostMock.mockImplementation((url: string) => {
      if (url.includes('/recommend-suite')) {
        return Promise.resolve({
          recommendations: [
            makeSuiteRec({ targetField: 'tool_description', targetName: 'lookupAccount', priority: 1 }),
            makeSuiteRec({ targetField: 'test_case', targetName: 'case-1', testCaseField: 'successCriteria', priority: 2 }),
          ],
          generatedAt: '2024-01-01T00:00:00Z',
          modelId: 'anthropic.claude-3-5-sonnet',
        });
      }
      if (url.includes('/analyze')) {
        return Promise.resolve({
          caseAnalyses: [],
          generatedAt: '2024-01-01T00:00:00Z',
          modelId: 'anthropic.claude-3-5-sonnet',
        });
      }
      return Promise.resolve({});
    });
    apiGetMock.mockResolvedValue({
      snapshot: { tools: [{ name: 'lookupAccount', examples: ['ex1'] }] },
    });

    render(
      <RecommendedChangesPanel
        runId="run-123"
        suiteId="suite-abc"
        runStatus={RunStatus.COMPLETED}
        failedCount={3}
        errorCount={0}
      />,
    );

    // Wait for async data loading
    await waitFor(() => {
      expect(screen.getByText('Agent recommendations')).toBeInTheDocument();
    });
    expect(screen.getByText('Test case recommendations')).toBeInTheDocument();
  });

  it('renders only agent section without "Test case recommendations" header when only agent recs exist (R7.4)', async () => {
    apiPostMock.mockImplementation((url: string) => {
      if (url.includes('/recommend-suite')) {
        return Promise.resolve({
          recommendations: [
            makeSuiteRec({ targetField: 'tool_description', targetName: 'lookupAccount', priority: 1 }),
            makeSuiteRec({ targetField: 'system_prompt', targetName: 'system_prompt', priority: 2 }),
          ],
          generatedAt: '2024-01-01T00:00:00Z',
          modelId: 'anthropic.claude-3-5-sonnet',
        });
      }
      if (url.includes('/analyze')) {
        return Promise.resolve({
          caseAnalyses: [],
          generatedAt: '2024-01-01T00:00:00Z',
          modelId: 'anthropic.claude-3-5-sonnet',
        });
      }
      return Promise.resolve({});
    });
    apiGetMock.mockResolvedValue({
      snapshot: { tools: [{ name: 'lookupAccount', examples: ['ex1'] }] },
    });

    render(
      <RecommendedChangesPanel
        runId="run-123"
        suiteId="suite-abc"
        runStatus={RunStatus.COMPLETED}
        failedCount={2}
        errorCount={0}
      />,
    );

    // Wait for data
    await waitFor(() => {
      expect(screen.getByText('Top recommended changes')).toBeInTheDocument();
    });

    // When only one type, headers for both sections are NOT shown (R7.4)
    expect(screen.queryByText('Agent recommendations')).not.toBeInTheDocument();
    expect(screen.queryByText('Test case recommendations')).not.toBeInTheDocument();
  });

  it('renders only test case section without "Agent recommendations" header when only test_case recs exist (R7.4)', async () => {
    apiPostMock.mockImplementation((url: string) => {
      if (url.includes('/recommend-suite')) {
        return Promise.resolve({
          recommendations: [
            makeSuiteRec({ targetField: 'test_case', targetName: 'case-1', testCaseField: 'persona', priority: 1 }),
            makeSuiteRec({ targetField: 'test_case', targetName: 'case-2', testCaseField: 'initialUtterance', priority: 2 }),
          ],
          generatedAt: '2024-01-01T00:00:00Z',
          modelId: 'anthropic.claude-3-5-sonnet',
        });
      }
      if (url.includes('/analyze')) {
        return Promise.resolve({
          caseAnalyses: [],
          generatedAt: '2024-01-01T00:00:00Z',
          modelId: 'anthropic.claude-3-5-sonnet',
        });
      }
      return Promise.resolve({});
    });
    apiGetMock.mockResolvedValue({
      snapshot: { tools: [{ name: 'lookupAccount', examples: ['ex1'] }] },
    });

    render(
      <RecommendedChangesPanel
        runId="run-123"
        suiteId="suite-abc"
        runStatus={RunStatus.COMPLETED}
        failedCount={2}
        errorCount={0}
      />,
    );

    await waitFor(() => {
      expect(screen.getByText('Top recommended changes')).toBeInTheDocument();
    });

    // When only one type, no section headers (R7.4)
    expect(screen.queryByText('Agent recommendations')).not.toBeInTheDocument();
    expect(screen.queryByText('Test case recommendations')).not.toBeInTheDocument();
  });
});

// ---------------------------------------------------------------------------
// FailureAnalysis: testCaseField sub-label and deep-link (R7.5, R7.6)
// ---------------------------------------------------------------------------

describe('FailureAnalysis — test_case recommendations', () => {
  it('renders "Fix test" badge with testCaseField sub-label for test_case recs (R7.5)', async () => {
    apiPostMock.mockImplementation((url: string) => {
      if (url.includes('/analyze')) {
        return Promise.resolve({
          caseAnalyses: [
            {
              caseId: 'case-tc-1',
              rootCauseCategory: 'test_case_defect',
              explanation: 'The agent correctly refused payment without confirmation.',
              traceAvailable: true,
              recommendations: [
                makeRec({
                  targetField: 'test_case',
                  targetName: 'case-tc-1',
                  testCaseField: 'successCriteria',
                  currentText: '1. processPayment (required: true)',
                  suggestedText: '1. confirmPayment (required: true)\n2. processPayment (required: true)',
                  rationale: 'Agent requires confirmation before payment.',
                }),
              ],
              generatedAt: '2024-01-01T00:00:00Z',
              modelId: 'anthropic.claude-3-5-sonnet',
            },
          ],
          generatedAt: '2024-01-01T00:00:00Z',
          modelId: 'anthropic.claude-3-5-sonnet',
        });
      }
      return Promise.resolve({});
    });
    apiGetMock.mockResolvedValue({
      snapshot: { tools: [{ name: 'processPayment', examples: ['ex'] }] },
    });

    render(
      <FailureAnalysis
        runId="run-123"
        suiteId="suite-abc"
        agentId="agent-1"
        runStatus={RunStatus.COMPLETED}
      />,
    );

    // Wait for the case to render
    await waitFor(() => {
      expect(screen.getByText('Fix test')).toBeInTheDocument();
    });

    // The testCaseField sub-label should be rendered (R7.5)
    expect(screen.getByText(/· successCriteria/)).toBeInTheDocument();
  });

  it('renders "Edit test case" deep-link with correct URL containing suiteId and caseId (R7.6)', async () => {
    apiPostMock.mockImplementation((url: string) => {
      if (url.includes('/analyze')) {
        return Promise.resolve({
          caseAnalyses: [
            {
              caseId: 'case-deep-link',
              rootCauseCategory: 'test_case_defect',
              explanation: 'Persona contradicts expected behavior.',
              traceAvailable: true,
              recommendations: [
                makeRec({
                  targetField: 'test_case',
                  targetName: 'case-deep-link',
                  testCaseField: 'persona',
                  currentText: 'Angry customer who refuses to provide info',
                  suggestedText: 'Cooperative customer willing to authenticate',
                }),
              ],
              generatedAt: '2024-01-01T00:00:00Z',
              modelId: 'anthropic.claude-3-5-sonnet',
            },
          ],
          generatedAt: '2024-01-01T00:00:00Z',
          modelId: 'anthropic.claude-3-5-sonnet',
        });
      }
      return Promise.resolve({});
    });
    apiGetMock.mockResolvedValue({
      snapshot: { tools: [] },
    });

    render(
      <FailureAnalysis
        runId="run-123"
        suiteId="suite-abc"
        agentId="agent-1"
        runStatus={RunStatus.COMPLETED}
      />,
    );

    // Wait for the deep link to appear
    await waitFor(() => {
      expect(screen.getByText('Edit test case')).toBeInTheDocument();
    });

    // Verify the link href contains the expected URL structure
    const link = screen.getByText('Edit test case').closest('a');
    expect(link).toBeInTheDocument();
    // The href should contain the suiteId and caseId with field query parameter
    expect(link!.getAttribute('href')).toContain('/suites/suite-abc');
    expect(link!.getAttribute('href')).toContain('editCase=case-deep-link');
    expect(link!.getAttribute('href')).toContain('field=persona');
  });
});

// ---------------------------------------------------------------------------
// Backward compatibility: pre-feature records without testCaseField (R8.1, R8.2)
// ---------------------------------------------------------------------------

describe('Backward compatibility — pre-feature records', () => {
  it('recommendation without testCaseField renders with orange "Fix agent" badge (R8.2)', () => {
    // Simulates a pre-feature rec that has no testCaseField property
    const legacyRec: Recommendation = {
      targetField: 'tool_description',
      targetName: 'transferCall',
      currentText: 'Transfers the call',
      suggestedText: 'Transfers the call to another agent',
      rationale: 'More descriptive',
      // testCaseField intentionally absent — simulates pre-feature record
    };

    // RecommendationBadge uses only targetField to determine badge color
    render(<RecommendationBadge targetField={legacyRec.targetField} />);
    expect(screen.getByText('Fix agent')).toBeInTheDocument();
  });

  it('pre-feature FailureAnalysis records without testCaseField render with orange badge (R8.1, R8.2)', async () => {
    // Simulate a pre-feature analysis response — all recs are agent-targeted, no testCaseField
    apiPostMock.mockImplementation((url: string) => {
      if (url.includes('/analyze')) {
        return Promise.resolve({
          caseAnalyses: [
            {
              caseId: 'legacy-case-1',
              rootCauseCategory: 'incomplete_tool_description',
              explanation: 'Tool description is missing key details.',
              traceAvailable: false,
              recommendations: [
                {
                  targetField: 'tool_description',
                  targetName: 'lookupAccount',
                  currentText: 'Looks up account',
                  suggestedText: 'Looks up account by phone number or email',
                  rationale: 'Need more specificity',
                  // No testCaseField — this is a pre-feature record
                },
              ],
              generatedAt: '2023-06-01T00:00:00Z',
              modelId: 'anthropic.claude-3-sonnet',
            },
          ],
          generatedAt: '2023-06-01T00:00:00Z',
          modelId: 'anthropic.claude-3-sonnet',
        });
      }
      return Promise.resolve({});
    });
    apiGetMock.mockResolvedValue({
      snapshot: { tools: [] },
    });

    render(
      <FailureAnalysis
        runId="run-legacy"
        suiteId="suite-old"
        agentId="agent-1"
        runStatus={RunStatus.COMPLETED}
      />,
    );

    // Wait for the per-case analysis to render
    await waitFor(() => {
      expect(screen.getByText('legacy-case-1')).toBeInTheDocument();
    });

    // The pre-feature record should NOT show "Fix test" anywhere
    expect(screen.queryByText('Fix test')).not.toBeInTheDocument();
    // There should be no deep-link to test case editor
    expect(screen.queryByText('Edit test case')).not.toBeInTheDocument();
  });
});
