/**
 * Public surface of the Prompt_Registry module.
 *
 * Every consumer outside the `prompt-registry/` directory imports from this
 * file rather than from the internal modules: keeping the public surface
 * narrow lets us refactor the directory layout (split a definition file,
 * add a new capability profile, rewire the resolver internals) without
 * touching call sites.
 *
 * The exports fall into four groups:
 *
 *   - **Registry data and resolution.** {@link PROMPT_REGISTRY} is the
 *     thirteen-entry in-code map of every {@link PromptDefinition} the
 *     platform recognises (R1.1); {@link resolvePrompt} is the pure
 *     resolver every Bedrock_Callsite uses to compute the effective
 *     `(text, modelKey, modelId, inferenceParameters, version,
 *     capabilityProfile)` tuple (R10.1, R10.5).
 *
 *   - **Model catalog and capability profiles.** {@link SUPPORTED_MODELS}
 *     is the six-entry frozen catalog of Bedrock models the Prompts page
 *     exposes (R17.1); {@link CAPABILITY_PROFILES} is the per-family
 *     declaration of which Converse `inferenceConfig` keys each model
 *     accepts (R17.2); {@link buildInferenceConfig} is the wire-shape
 *     helper every callsite uses to place accepted keys into the exact
 *     argument shape `ConverseCommand` expects (R17.4).
 *
 *   - **Run-pinned prompt keys.** {@link RUN_PROMPT_KEYS} is the closed
 *     list of `promptKey` values that the run-start snapshotter pins on
 *     `AgentSnapshot.prompts[]` for in-flight runs to read from (R11.1).
 *     The three interactive-only prompts (`suite_scaffold`,
 *     `case_scaffold`, `comparison_summary`) are excluded because they
 *     never execute inside a Step Functions run — they back the
 *     interactive scaffold and comparison-summary endpoints which always
 *     resolve through the live override store via `resolvePromptLive`.
 *
 *   - **Type re-exports.** Every shared prompt-management type is
 *     re-exported here so a consumer can import everything from a single
 *     module instead of reaching into `../../shared/types` for the data
 *     shapes and into `./types` for the registry-internal additions.
 *
 * Production callers SHALL go through {@link resolvePrompt} (or its
 * cached runtime wrapper in `runtime.ts`, when that module lands) so the
 * three behaviour invariants documented in `resolver.ts` are always
 * enforced. Direct reads of {@link PROMPT_REGISTRY} are intentionally
 * permitted for code that needs the bundled defaults (the validation
 * pipeline's placeholder schema check, the `computeBedrockGrants` CDK
 * helper that walks `allowedModels[]`, and the registry invariant tests).
 *
 * @module backend/orchestration/prompt-registry
 */

import type { PromptKey } from "./types";

// ---------------------------------------------------------------------------
// Registry data and resolution
// ---------------------------------------------------------------------------

export { PROMPT_REGISTRY, resolvePrompt } from "./resolver";

// ---------------------------------------------------------------------------
// Model catalog and capability profiles
// ---------------------------------------------------------------------------

export { SUPPORTED_MODELS } from "./supported-models";
export { CAPABILITY_PROFILES, buildInferenceConfig } from "./capability-profiles";
export type { BuiltInferenceConfig } from "./capability-profiles";

// ---------------------------------------------------------------------------
// Run-pinned prompt keys
// ---------------------------------------------------------------------------

/**
 * The closed list of `promptKey` values any test run can consume — every
 * registered prompt except the three interactive-only ones
 * (`suite_scaffold`, `case_scaffold`, `comparison_summary`). The
 * PrepareRun Lambda iterates this list when it builds the
 * `AgentSnapshot.prompts` map at run start (R11.1) so in-flight runs read
 * their prompts from the snapshot rather than from the live Prompts_Store
 * (R11.2 / R16.1).
 *
 * Excluded keys back interactive HTTP endpoints (`POST /scaffold`,
 * `POST /comparison-summary`) which always resolve through the live
 * override store via the `resolvePromptLive` runtime helper, so pinning
 * them on a run snapshot would be wasted work.
 *
 * Frozen with `as const` so the inferred element type narrows to the
 * literal `PromptKey` subset rather than the full union — adding or
 * removing a prompt later starts as a TypeScript error at any consumer
 * that relied on the previous membership.
 */
export const RUN_PROMPT_KEYS: readonly PromptKey[] = [
  "failure_analysis",
  "suite_recommendation",
  "tournament_summary",
  "variant_generation",
  "customer_simulator",
  "judge_goal_success_rate",
  "judge_helpfulness",
  "judge_tool_selection",
  "judge_opportunistic_faithfulness",
  "rag_evaluation_job",
] as const;

// ---------------------------------------------------------------------------
// Type re-exports — single import surface for every consumer
// ---------------------------------------------------------------------------

export {
  UnknownPromptKeyError,
} from "./types";

export type {
  InferenceParameterSchema,
  ModelCapabilityProfile,
  ModelKey,
  Placeholder,
  PromptDefinition,
  PromptKey,
  PromptOverride,
  PromptRegistry,
  ResolvedPrompt,
  ResolvedPromptSnapshot,
  SupportedModel,
} from "./types";
