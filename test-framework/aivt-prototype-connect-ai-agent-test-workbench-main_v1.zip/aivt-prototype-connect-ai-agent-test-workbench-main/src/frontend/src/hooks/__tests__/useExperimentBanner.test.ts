// @vitest-environment jsdom
// Feature: implement-recommendations-frontend, Property 9: Banner retains last-known status on transient failures
/**
 * Property-based test AND unit tests for the useExperimentBanner hook.
 *
 * Property 9: For any last-known experiment status and for any sequence of
 * FEWER than 3 consecutive poll failures, the banner's displayed status SHALL
 * remain equal to the last successfully fetched status and `pollError` SHALL
 * remain false.
 *
 * Unit tests validate: Requirements 5.1–5.6
 *
 * **Validates: Requirements 5.6**
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderHook, act, cleanup } from '@testing-library/react';
import * as fc from 'fast-check';
import type { ExperimentRecord, ExperimentStatus } from '../../../../shared/types';

vi.mock('../../api/recommendations', () => ({
  listExperiments: vi.fn(),
  getExperiment: vi.fn(),
}));

import { listExperiments, getExperiment } from '../../api/recommendations';
import { useExperimentBanner } from '../useExperimentBanner';

const mockListExperiments = listExperiments as ReturnType<typeof vi.fn>;
const mockGetExperiment = getExperiment as ReturnType<typeof vi.fn>;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Non-terminal statuses — the hook actively polls while in these states. */
const NON_TERMINAL_STATUSES: ExperimentStatus[] = [
  'generating_variants',
  'creating_agents',
  'running',
  'cleanup_in_progress',
];

/** Build a minimal ExperimentRecord with the given status. */
function makeExperimentRecord(status: ExperimentStatus): ExperimentRecord {
  return {
    experimentId: 'exp-001',
    runId: 'run-001',
    agentId: 'agent-001',
    status,
    variantConfigs: [],
    temporaryAgentIds: { A: 'a1', B: 'b1', C: 'c1' },
    variantRunIds: { A: 'r1', B: 'r2', C: 'r3' },
    baselineRunId: 'baseline-001',
    sfnExecutionArn: 'arn:aws:states:us-east-1:123:execution:exp',
    cleanupStatus: 'pending',
    createdAt: '2024-01-01T00:00:00Z',
  };
}

// ---------------------------------------------------------------------------
// fast-check arbitraries
// ---------------------------------------------------------------------------

/** Arbitrary for a non-terminal experiment status. */
const nonTerminalStatusArb = fc.constantFrom(...NON_TERMINAL_STATUSES);

/**
 * Arbitrary for the number of consecutive failures: 0, 1, or 2.
 * Property 9 states "fewer than 3 consecutive failures".
 */
const failureCountArb = fc.integer({ min: 0, max: 2 });

// ---------------------------------------------------------------------------
// Property Test
// ---------------------------------------------------------------------------

describe('useExperimentBanner — Property 9: Banner retains last-known status on transient failures', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it('pollError remains false and displayed status equals last successful fetch for <3 consecutive failures', async () => {
    await fc.assert(
      fc.asyncProperty(
        nonTerminalStatusArb,
        failureCountArb,
        async (lastKnownStatus: ExperimentStatus, consecutiveFailures: number) => {
          // Clean up any prior renders and reset timers between iterations
          cleanup();
          vi.clearAllTimers();
          mockListExperiments.mockReset();
          mockGetExperiment.mockReset();

          const record = makeExperimentRecord(lastKnownStatus);

          // Initial listExperiments returns the experiment in the given status
          mockListExperiments.mockResolvedValue({ experiments: [record] });

          // Render the hook
          const { result, unmount } = renderHook(() => useExperimentBanner('run-001'));

          // Flush the initial async fetch (listExperiments resolves)
          await act(async () => {
            await vi.advanceTimersByTimeAsync(0);
          });

          // Verify initial state is correct after first fetch
          expect(result.current.experiment?.status).toBe(lastKnownStatus);
          expect(result.current.pollError).toBe(false);
          expect(result.current.hasExperiment).toBe(true);

          // Now simulate `consecutiveFailures` poll failures (each fewer than 3)
          for (let i = 0; i < consecutiveFailures; i++) {
            mockGetExperiment.mockRejectedValueOnce(new Error('Network error'));

            // Advance the 10-second poll interval
            await act(async () => {
              await vi.advanceTimersByTimeAsync(10_000);
            });
          }

          // After fewer than 3 consecutive failures:
          // - pollError MUST remain false
          // - displayed status MUST equal the last successfully fetched status
          expect(result.current.pollError).toBe(false);
          expect(result.current.experiment?.status).toBe(lastKnownStatus);
          expect(result.current.hasExperiment).toBe(true);

          // Unmount to stop any intervals before next iteration
          unmount();
        },
      ),
      { numRuns: 100 },
    );
  });
});


// ---------------------------------------------------------------------------
// Unit Tests — Validates Requirements 5.1–5.6
// ---------------------------------------------------------------------------

describe('useExperimentBanner — Unit Tests', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  // -------------------------------------------------------------------------
  // Req 5.1: Initial fetch — no experiment → hasExperiment: false
  // -------------------------------------------------------------------------

  describe('initial fetch', () => {
    it('returns hasExperiment: false when no experiments exist for the run', async () => {
      mockListExperiments.mockResolvedValue({ experiments: [] });

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.hasExperiment).toBe(false);
      expect(result.current.experiment).toBeNull();
      expect(result.current.pollError).toBe(false);
      expect(result.current.isTerminal).toBe(false);
    });

    it('returns hasExperiment: false when runId is null', () => {
      const { result } = renderHook(() => useExperimentBanner(null));

      expect(result.current.hasExperiment).toBe(false);
      expect(result.current.experiment).toBeNull();
    });

    it('returns hasExperiment: true when an active experiment is found', async () => {
      const record = makeExperimentRecord('running');
      mockListExperiments.mockResolvedValue({ experiments: [record] });

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.hasExperiment).toBe(true);
      expect(result.current.experiment?.status).toBe('running');
      expect(result.current.isTerminal).toBe(false);
    });
  });

  // -------------------------------------------------------------------------
  // Req 5.3: Polling — active experiment → polls every 10s → updates on change
  // -------------------------------------------------------------------------

  describe('polling behavior', () => {
    it('polls every 10 seconds for non-terminal experiments', async () => {
      const initialRecord = makeExperimentRecord('generating_variants');
      const updatedRecord = makeExperimentRecord('running');

      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });
      mockGetExperiment.mockResolvedValue(updatedRecord);

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      // Resolve initial listExperiments
      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.experiment?.status).toBe('generating_variants');

      // Advance 10 seconds — first poll fires
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.experiment?.status).toBe('running');
      expect(mockGetExperiment).toHaveBeenCalledTimes(1);
    });

    it('does not start polling if initial experiment is in a terminal status', async () => {
      const record = makeExperimentRecord('completed');
      mockListExperiments.mockResolvedValue({ experiments: [record] });

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      expect(result.current.hasExperiment).toBe(true);
      expect(result.current.isTerminal).toBe(true);

      // Advance time — should not poll
      await act(async () => {
        await vi.advanceTimersByTimeAsync(30_000);
      });

      expect(mockGetExperiment).not.toHaveBeenCalled();
    });
  });

  // -------------------------------------------------------------------------
  // Req 5.4/5.5: Terminal detection — completed/failed → stops polling
  // -------------------------------------------------------------------------

  describe('terminal status detection', () => {
    it('stops polling when experiment transitions to completed', async () => {
      const initialRecord = makeExperimentRecord('running');
      const completedRecord = makeExperimentRecord('completed');

      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });
      mockGetExperiment.mockResolvedValue(completedRecord);

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      // First poll returns completed
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.experiment?.status).toBe('completed');
      expect(result.current.isTerminal).toBe(true);

      // Advance more time — no additional polls
      mockGetExperiment.mockClear();
      await act(async () => {
        await vi.advanceTimersByTimeAsync(30_000);
      });

      expect(mockGetExperiment).not.toHaveBeenCalled();
    });

    it('stops polling when experiment transitions to failed', async () => {
      const initialRecord = makeExperimentRecord('running');
      const failedRecord = makeExperimentRecord('failed');

      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });
      mockGetExperiment.mockResolvedValue(failedRecord);

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      // First poll returns failed
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.experiment?.status).toBe('failed');
      expect(result.current.isTerminal).toBe(true);

      // No further polling
      mockGetExperiment.mockClear();
      await act(async () => {
        await vi.advanceTimersByTimeAsync(30_000);
      });

      expect(mockGetExperiment).not.toHaveBeenCalled();
    });

    it('stops polling when experiment transitions to cleaned_up', async () => {
      const initialRecord = makeExperimentRecord('cleanup_in_progress');
      const cleanedUpRecord = makeExperimentRecord('cleaned_up');

      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });
      mockGetExperiment.mockResolvedValue(cleanedUpRecord);

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.experiment?.status).toBe('cleaned_up');
      expect(result.current.isTerminal).toBe(true);

      mockGetExperiment.mockClear();
      await act(async () => {
        await vi.advanceTimersByTimeAsync(30_000);
      });

      expect(mockGetExperiment).not.toHaveBeenCalled();
    });
  });

  // -------------------------------------------------------------------------
  // Req 5.6: 3-failure threshold — three consecutive errors → pollError: true
  // -------------------------------------------------------------------------

  describe('3-failure threshold', () => {
    it('sets pollError to true after 3 consecutive poll failures', async () => {
      const initialRecord = makeExperimentRecord('running');
      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });
      mockGetExperiment.mockRejectedValue(new Error('Network error'));

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      // 1st failure
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      expect(result.current.pollError).toBe(false);

      // 2nd failure
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      expect(result.current.pollError).toBe(false);

      // 3rd failure — threshold reached
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      expect(result.current.pollError).toBe(true);

      // Last known experiment is still retained
      expect(result.current.experiment?.status).toBe('running');
      expect(result.current.hasExperiment).toBe(true);
    });

    it('retains last-known status during consecutive failures', async () => {
      const initialRecord = makeExperimentRecord('creating_agents');
      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });
      mockGetExperiment.mockRejectedValue(new Error('Server error'));

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      // Two failures — status should still be the initial value
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.experiment?.status).toBe('creating_agents');
      expect(result.current.pollError).toBe(false);
    });
  });

  // -------------------------------------------------------------------------
  // Req 5.6: Recovery — success after failures → pollError: false
  // -------------------------------------------------------------------------

  describe('recovery after failures', () => {
    it('clears pollError when a successful poll follows 3+ failures', async () => {
      const initialRecord = makeExperimentRecord('running');
      const recoveredRecord = makeExperimentRecord('running');
      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      // Simulate 3 consecutive failures to trigger pollError
      mockGetExperiment.mockRejectedValue(new Error('Network error'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.pollError).toBe(true);

      // Now a successful poll occurs — should recover
      mockGetExperiment.mockResolvedValue(recoveredRecord);

      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.pollError).toBe(false);
      expect(result.current.experiment?.status).toBe('running');
    });

    it('resets failure counter on success even after 1-2 failures', async () => {
      const initialRecord = makeExperimentRecord('running');
      const updatedRecord = makeExperimentRecord('running');
      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });

      const { result } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      // 2 failures followed by a success
      mockGetExperiment.mockRejectedValueOnce(new Error('err'));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      mockGetExperiment.mockRejectedValueOnce(new Error('err'));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      mockGetExperiment.mockResolvedValueOnce(updatedRecord);
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.pollError).toBe(false);

      // Now need 3 MORE failures to trigger pollError (counter was reset)
      mockGetExperiment.mockRejectedValueOnce(new Error('err'));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      mockGetExperiment.mockRejectedValueOnce(new Error('err'));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.pollError).toBe(false);

      mockGetExperiment.mockRejectedValueOnce(new Error('err'));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });

      expect(result.current.pollError).toBe(true);
    });
  });

  // -------------------------------------------------------------------------
  // Cleanup on unmount
  // -------------------------------------------------------------------------

  describe('cleanup', () => {
    it('stops polling on unmount', async () => {
      const initialRecord = makeExperimentRecord('running');
      mockListExperiments.mockResolvedValue({ experiments: [initialRecord] });
      mockGetExperiment.mockResolvedValue(makeExperimentRecord('running'));

      const { unmount } = renderHook(() => useExperimentBanner('run-123'));

      await act(async () => {
        await vi.advanceTimersByTimeAsync(0);
      });

      unmount();

      // Advance time — should not call getExperiment after unmount
      mockGetExperiment.mockClear();
      await act(async () => {
        await vi.advanceTimersByTimeAsync(30_000);
      });

      expect(mockGetExperiment).not.toHaveBeenCalled();
    });
  });
});
