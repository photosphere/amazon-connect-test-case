import { describe, it, expect } from "vitest";
import { bucketByTargetField } from "../../src/shared/utils/recommendation-bucketing";
import type { Recommendation, ToolSurface } from "../../src/shared/types";

function makeRec(overrides: Partial<Recommendation> = {}): Recommendation {
  return {
    targetField: "tool_description",
    targetName: "lookupTool",
    currentText: "old text",
    suggestedText: "new text",
    rationale: "because",
    ...overrides,
  };
}

describe("bucketByTargetField", () => {
  it("returns four empty buckets for empty input", () => {
    const result = bucketByTargetField([]);

    expect(result).toEqual({
      tool_description: [],
      tool_instruction: [],
      tool_examples: [],
      system_prompt: [],
    });
    // All four keys must be present even when empty so consumers can index
    // without optional-chaining.
    expect(Object.keys(result).sort()).toEqual([
      "system_prompt",
      "tool_description",
      "tool_examples",
      "tool_instruction",
    ]);
  });

  it("places exactly one record per bucket when given one recommendation per surface", () => {
    const recs: Recommendation[] = [
      makeRec({ targetField: "tool_description", targetName: "toolA" }),
      makeRec({ targetField: "tool_instruction", targetName: "toolB" }),
      makeRec({
        targetField: "tool_examples",
        targetName: "toolC",
        currentText: "",
        suggestedText: "an example",
      }),
      makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
      }),
    ];

    const result = bucketByTargetField(recs);

    expect(result.tool_description).toHaveLength(1);
    expect(result.tool_instruction).toHaveLength(1);
    expect(result.tool_examples).toHaveLength(1);
    expect(result.system_prompt).toHaveLength(1);

    expect(result.tool_description[0].targetName).toBe("toolA");
    expect(result.tool_instruction[0].targetName).toBe("toolB");
    expect(result.tool_examples[0].targetName).toBe("toolC");
    expect(result.system_prompt[0].targetName).toBe("system_prompt");
  });

  it("preserves input order within a bucket when multiple records share the same surface", () => {
    const recs: Recommendation[] = [
      makeRec({ targetField: "tool_examples", targetName: "tool1", suggestedText: "first" }),
      makeRec({ targetField: "tool_description", targetName: "tool2" }),
      makeRec({ targetField: "tool_examples", targetName: "tool3", suggestedText: "second" }),
      makeRec({ targetField: "tool_examples", targetName: "tool4", suggestedText: "third" }),
      makeRec({ targetField: "tool_description", targetName: "tool5" }),
    ];

    const result = bucketByTargetField(recs);

    expect(result.tool_examples.map((r) => r.suggestedText)).toEqual([
      "first",
      "second",
      "third",
    ]);
    expect(result.tool_description.map((r) => r.targetName)).toEqual([
      "tool2",
      "tool5",
    ]);
    expect(result.tool_instruction).toEqual([]);
    expect(result.system_prompt).toEqual([]);
  });

  it("preserves input multiset across all four buckets (no records added or dropped)", () => {
    const recs: Recommendation[] = [
      makeRec({ targetField: "tool_description", targetName: "a" }),
      makeRec({ targetField: "tool_instruction", targetName: "b" }),
      makeRec({ targetField: "tool_examples", targetName: "c" }),
      makeRec({ targetField: "system_prompt", targetName: "system_prompt" }),
      makeRec({ targetField: "tool_description", targetName: "d" }),
    ];

    const result = bucketByTargetField(recs);

    const concat = [
      ...result.tool_description,
      ...result.tool_instruction,
      ...result.tool_examples,
      ...result.system_prompt,
    ];
    expect(concat).toHaveLength(recs.length);
    // Every input record appears in some bucket.
    for (const rec of recs) {
      expect(concat).toContain(rec);
    }
  });

  it("throws when a recommendation has an invalid targetField", () => {
    const recs = [
      makeRec({ targetField: "tool_description", targetName: "ok" }),
      makeRec({
        // Cast intentionally — exercising the runtime guard for upstream
        // contract violations (R5.9).
        targetField: "not_a_real_surface" as unknown as ToolSurface,
        targetName: "bad",
      }),
    ];

    expect(() => bucketByTargetField(recs)).toThrow(/invalid targetField/);
    expect(() => bucketByTargetField(recs)).toThrow(/index 1/);
  });

  it("throws on the first invalid targetField even when later records would also be invalid", () => {
    const recs = [
      makeRec({
        targetField: "" as unknown as ToolSurface,
        targetName: "first-bad",
      }),
      makeRec({
        targetField: "another_bad" as unknown as ToolSurface,
        targetName: "second-bad",
      }),
    ];

    expect(() => bucketByTargetField(recs)).toThrow(/index 0/);
  });
});
