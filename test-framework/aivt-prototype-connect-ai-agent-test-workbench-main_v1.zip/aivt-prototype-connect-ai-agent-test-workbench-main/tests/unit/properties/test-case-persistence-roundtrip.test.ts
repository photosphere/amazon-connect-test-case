// Feature: test-case-validity-analysis, Property 5: Per-case analysis persistence round-trip
import { describe, it, expect } from "vitest";
import fc from "fast-check";

/**
 * **Validates: Requirements 10.1, 10.2, 10.3**
 *
 * Property 5: Per-case analysis persistence round-trip
 *
 * For any valid PerCaseAnalysis record whose recommendations array contains
 * test_case entries with valid testCaseField values, writing the record to
 * DynamoDB and reading it back produces a record whose test_case
 * recommendations carry identical targetField, targetName, testCaseField,
 * currentText, suggestedText, and rationale values.
 *
 * Since we can't actually write to DynamoDB in a unit test, we simulate the
 * round-trip by JSON.stringify → JSON.parse (which is what DynamoDB's document
 * client does with the marshaller). The key invariant: the fields survive
 * serialization/deserialization without loss.
 */

// ---------------------------------------------------------------------------
// Types (mirroring src/shared/types.ts)
// ---------------------------------------------------------------------------

type RecommendationTarget =
  | "tool_description"
  | "tool_instruction"
  | "tool_examples"
  | "system_prompt"
  | "test_case";

type TestCaseTargetField =
  | "successCriteria"
  | "initialUtterance"
  | "persona"
  | "customerKnowledge"
  | "goalDescription";

interface Recommendation {
  targetField: RecommendationTarget;
  targetName: string;
  currentText: string;
  suggestedText: string;
  rationale: string;
  testCaseField?: TestCaseTargetField;
}

interface PerCaseAnalysis {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;
  recommendations: Recommendation[];
  generatedAt: string;
  modelId: string;
  failureAnalysisPromptVersion?: number;
  testCaseDefect?: boolean;
}

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

const VALID_TEST_CASE_FIELDS: TestCaseTargetField[] = [
  "successCriteria",
  "initialUtterance",
  "persona",
  "customerKnowledge",
  "goalDescription",
];

const VALID_AGENT_TARGET_FIELDS: RecommendationTarget[] = [
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
];

/** Non-empty string that may contain unicode, whitespace, special chars. */
const nonEmptyStringArb = fc
  .string({ minLength: 1, maxLength: 200 })
  .filter((s) => s.trim().length > 0);

/** Arbitrary for a test_case recommendation with valid testCaseField. */
const testCaseRecommendationArb: fc.Arbitrary<Recommendation> = fc.record({
  targetField: fc.constant("test_case" as const),
  targetName: nonEmptyStringArb, // caseId
  currentText: nonEmptyStringArb,
  suggestedText: nonEmptyStringArb,
  rationale: nonEmptyStringArb,
  testCaseField: fc.constantFrom(...VALID_TEST_CASE_FIELDS),
});

/** Arbitrary for an agent-targeted recommendation (no testCaseField). */
const agentRecommendationArb: fc.Arbitrary<Recommendation> = fc.record({
  targetField: fc.constantFrom(...VALID_AGENT_TARGET_FIELDS),
  targetName: nonEmptyStringArb,
  currentText: nonEmptyStringArb,
  suggestedText: nonEmptyStringArb,
  rationale: nonEmptyStringArb,
});

/**
 * Arbitrary for a PerCaseAnalysis record that includes at least one
 * test_case recommendation. The rootCauseCategory is "test_case_defect"
 * since that's the only valid root cause for test_case recommendations.
 */
const perCaseAnalysisWithTestCaseRecsArb: fc.Arbitrary<PerCaseAnalysis> = fc
  .tuple(
    // At least one test_case recommendation
    fc.array(testCaseRecommendationArb, { minLength: 1, maxLength: 3 }),
    // Zero or more agent recommendations
    fc.array(agentRecommendationArb, { minLength: 0, maxLength: 3 }),
    // Other fields
    nonEmptyStringArb, // caseId
    nonEmptyStringArb, // explanation
    fc.boolean(), // traceAvailable
    fc.date({ min: new Date("2024-01-01"), max: new Date("2026-01-01") }).map((d) =>
      d.toISOString()
    ), // generatedAt
    nonEmptyStringArb, // modelId
    fc.option(fc.nat({ max: 100 }), { nil: undefined }), // failureAnalysisPromptVersion
  )
  .map(
    ([
      testCaseRecs,
      agentRecs,
      caseId,
      explanation,
      traceAvailable,
      generatedAt,
      modelId,
      failureAnalysisPromptVersion,
    ]) => {
      const result: PerCaseAnalysis = {
        caseId,
        rootCauseCategory: "test_case_defect",
        explanation,
        traceAvailable,
        recommendations: [...testCaseRecs, ...agentRecs],
        generatedAt,
        modelId,
        testCaseDefect: true,
      };
      if (failureAnalysisPromptVersion !== undefined) {
        result.failureAnalysisPromptVersion = failureAnalysisPromptVersion;
      }
      return result;
    }
  );

// ---------------------------------------------------------------------------
// Simulated DynamoDB round-trip
// ---------------------------------------------------------------------------

/**
 * Simulates the DynamoDB document client's marshalling behavior:
 * JSON.stringify strips undefined values, JSON.parse reconstitutes the object.
 * This is exactly what the DynamoDBDocumentClient does when writing/reading.
 */
function dynamoRoundTrip<T>(value: T): T {
  return JSON.parse(JSON.stringify(value));
}

// ---------------------------------------------------------------------------
// Property test
// ---------------------------------------------------------------------------

describe("Feature: test-case-validity-analysis, Property 5: Per-case analysis persistence round-trip", () => {
  it("write-then-read preserves targetField, targetName, testCaseField, currentText, suggestedText, rationale on test_case recommendations", () => {
    fc.assert(
      fc.property(perCaseAnalysisWithTestCaseRecsArb, (analysis) => {
        // Simulate persistence: write (stringify) then read (parse)
        const persisted = dynamoRoundTrip(analysis);

        // Verify the test_case recommendations survived the round-trip
        const originalTestCaseRecs = analysis.recommendations.filter(
          (r) => r.targetField === "test_case"
        );
        const persistedTestCaseRecs = persisted.recommendations.filter(
          (r: Recommendation) => r.targetField === "test_case"
        );

        // Same count of test_case recommendations
        expect(persistedTestCaseRecs.length).toBe(originalTestCaseRecs.length);

        // Each test_case recommendation preserves its critical fields
        for (let i = 0; i < originalTestCaseRecs.length; i++) {
          const original = originalTestCaseRecs[i];
          const roundTripped = persistedTestCaseRecs[i];

          expect(roundTripped.targetField).toBe(original.targetField);
          expect(roundTripped.targetName).toBe(original.targetName);
          expect(roundTripped.testCaseField).toBe(original.testCaseField);
          expect(roundTripped.currentText).toBe(original.currentText);
          expect(roundTripped.suggestedText).toBe(original.suggestedText);
          expect(roundTripped.rationale).toBe(original.rationale);
        }
      }),
      { numRuns: 200 }
    );
  });

  it("testCaseField is preserved as one of the five valid TestCaseTargetField values after round-trip", () => {
    fc.assert(
      fc.property(perCaseAnalysisWithTestCaseRecsArb, (analysis) => {
        const persisted = dynamoRoundTrip(analysis);

        const persistedTestCaseRecs = persisted.recommendations.filter(
          (r: Recommendation) => r.targetField === "test_case"
        );

        for (const rec of persistedTestCaseRecs) {
          expect(VALID_TEST_CASE_FIELDS).toContain(rec.testCaseField);
        }
      }),
      { numRuns: 200 }
    );
  });

  it("agent-targeted recommendations without testCaseField remain unchanged after round-trip", () => {
    fc.assert(
      fc.property(perCaseAnalysisWithTestCaseRecsArb, (analysis) => {
        const persisted = dynamoRoundTrip(analysis);

        const originalAgentRecs = analysis.recommendations.filter(
          (r) => r.targetField !== "test_case"
        );
        const persistedAgentRecs = persisted.recommendations.filter(
          (r: Recommendation) => r.targetField !== "test_case"
        );

        expect(persistedAgentRecs.length).toBe(originalAgentRecs.length);

        for (let i = 0; i < originalAgentRecs.length; i++) {
          const original = originalAgentRecs[i];
          const roundTripped = persistedAgentRecs[i];

          expect(roundTripped.targetField).toBe(original.targetField);
          expect(roundTripped.targetName).toBe(original.targetName);
          expect(roundTripped.currentText).toBe(original.currentText);
          expect(roundTripped.suggestedText).toBe(original.suggestedText);
          expect(roundTripped.rationale).toBe(original.rationale);
          // testCaseField should not be present on agent recs
          expect(roundTripped.testCaseField).toBeUndefined();
        }
      }),
      { numRuns: 200 }
    );
  });

  it("the testCaseDefect boolean flag survives round-trip", () => {
    fc.assert(
      fc.property(perCaseAnalysisWithTestCaseRecsArb, (analysis) => {
        const persisted = dynamoRoundTrip(analysis);
        expect(persisted.testCaseDefect).toBe(analysis.testCaseDefect);
      }),
      { numRuns: 100 }
    );
  });
});
