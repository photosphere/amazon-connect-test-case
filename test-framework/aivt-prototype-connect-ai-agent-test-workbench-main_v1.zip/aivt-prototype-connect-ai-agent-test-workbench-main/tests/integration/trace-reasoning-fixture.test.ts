/**
 * Golden-path integration test — exercises the real `tmp/spans-mortgage-rate.json`
 * fixture through the full trace-reasoning-and-latency feature pipeline.
 *
 * This test verifies:
 *   1. Reasoning extraction (verbatim preservation)
 *   2. durationMs computation (non-negative integers from timestamps)
 *   3. InferenceMetadata population (typed fields from span attributes)
 *   4. Analysis prompt rendering (reasoning trace section)
 *   5. Helpfulness context rendering (reasoning excluded, tool calls included)
 *
 * The fixture is the authoritative ground truth — all expected values derive
 * from parsing it with the production span-parser.
 */

import { describe, it, expect } from "vitest";
import * as fs from "node:fs";
import * as path from "node:path";

import {
  parseSpansToTrace,
  type RawSpan,
} from "@backend/orchestration/span-parser";
import { buildAnalysisPrompt } from "@backend/handlers/analysis";
import {
  renderJudgePromptContext,
  type CustomerTurnWithTimestamp,
} from "@shared/utils/judge-prompt-rendering";
import type { ExecutionTrace, TranscriptTurn, AgentSnapshot } from "@shared/types";

// ---------------------------------------------------------------------------
// Fixture loading
// ---------------------------------------------------------------------------

const fixtureRaw = JSON.parse(
  fs.readFileSync(
    path.resolve(__dirname, "../../tmp/spans-mortgage-rate.json"),
    "utf-8",
  ),
) as RawSpan[];

const SESSION_ID = "b324a670-d71b-4c4e-a77f-4fb53d071890";

// Parse the fixture once for all tests
const trace: ExecutionTrace = parseSpansToTrace(SESSION_ID, fixtureRaw);

// ---------------------------------------------------------------------------
// Test: Reasoning extraction
// ---------------------------------------------------------------------------

describe("Reasoning extraction from mortgage-rate fixture", () => {
  const inferenceSteps = trace.steps.filter((s) => s.type === "inference");

  it("has exactly 7 inference spans", () => {
    expect(inferenceSteps.length).toBe(7);
  });

  it("first inference step reasoning starts with expected text", () => {
    const first = inferenceSteps[0];
    expect(first.reasoning).toBeDefined();
    expect(first.reasoning!.startsWith("The customer is asking for their mortgage rate.")).toBe(
      true,
    );
  });

  it("each inference step with reasoning in the raw data has it captured verbatim", () => {
    // All 7 inference spans in this fixture carry reasoning
    for (const step of inferenceSteps) {
      expect(step.reasoning).toBeDefined();
      expect(typeof step.reasoning).toBe("string");
      expect(step.reasoning!.trim().length).toBeGreaterThan(0);
    }
  });

  it("non-inference steps (invoke_agent, execute_tool) have reasoning === undefined", () => {
    const nonInference = trace.steps.filter((s) => s.type !== "inference");
    for (const step of nonInference) {
      expect(step.reasoning).toBeUndefined();
    }
  });
});

// ---------------------------------------------------------------------------
// Test: durationMs computation
// ---------------------------------------------------------------------------

describe("durationMs computation from mortgage-rate fixture", () => {
  it("every real-span step (non-synthetic) has durationMs defined as non-negative integer", () => {
    const realSteps = trace.steps.filter(
      (s) => s.spanName !== "inference_tool_use" && s.spanName !== "synthetic_control_tool",
    );
    for (const step of realSteps) {
      expect(step.durationMs).toBeDefined();
      expect(step.durationMs).toBeGreaterThanOrEqual(0);
      expect(Number.isInteger(step.durationMs)).toBe(true);
    }
  });

  it("first inference span: durationMs is 1957", () => {
    const firstInference = trace.steps.find((s) => s.type === "inference");
    expect(firstInference).toBeDefined();
    // start=2026-06-11T04:23:08.741Z, end=2026-06-11T04:23:10.698Z → 1957ms
    expect(firstInference!.durationMs).toBe(1957);
  });

  it("synthetic inference_tool_use steps have durationMs === undefined", () => {
    const syntheticSteps = trace.steps.filter(
      (s) => s.spanName === "inference_tool_use",
    );
    for (const step of syntheticSteps) {
      expect(step.durationMs).toBeUndefined();
    }
  });
});

// ---------------------------------------------------------------------------
// Test: inferenceMetadata
// ---------------------------------------------------------------------------

describe("inferenceMetadata from mortgage-rate fixture", () => {
  const firstInference = trace.steps.find((s) => s.type === "inference")!;

  it("first inference step has inferenceMetadata defined", () => {
    expect(firstInference.inferenceMetadata).toBeDefined();
  });

  it("requestModel matches expected value", () => {
    expect(firstInference.inferenceMetadata!.requestModel).toBe(
      "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    );
  });

  it("usageInputTokens === 5240", () => {
    expect(firstInference.inferenceMetadata!.usageInputTokens).toBe(5240);
  });

  it("usageOutputTokens === 131", () => {
    expect(firstInference.inferenceMetadata!.usageOutputTokens).toBe(131);
  });

  it("usageTotalTokens === 5371", () => {
    expect(firstInference.inferenceMetadata!.usageTotalTokens).toBe(5371);
  });

  it("requestMaxTokens === 2048", () => {
    expect(firstInference.inferenceMetadata!.requestMaxTokens).toBe(2048);
  });

  it("temperature === 0", () => {
    expect(firstInference.inferenceMetadata!.temperature).toBe(0);
  });

  it("timeToFirstTokenMs === 725", () => {
    expect(firstInference.inferenceMetadata!.timeToFirstTokenMs).toBe(725);
  });

  it('responseFinishReasons is ["end_turn"]', () => {
    expect(firstInference.inferenceMetadata!.responseFinishReasons).toEqual(["end_turn"]);
  });

  it("promptId matches expected value", () => {
    expect(firstInference.inferenceMetadata!.promptId).toBe(
      "197e301f-3217-48a8-8359-43bf16519f7b",
    );
  });

  it("promptName === 'AnyBank'", () => {
    expect(firstInference.inferenceMetadata!.promptName).toBe("AnyBank");
  });

  it("promptVersion === 2", () => {
    expect(firstInference.inferenceMetadata!.promptVersion).toBe(2);
  });

  it("aiAgentVersion === 14", () => {
    expect(firstInference.inferenceMetadata!.aiAgentVersion).toBe(14);
  });

  it("systemInstructions is defined and starts with expected text", () => {
    expect(firstInference.inferenceMetadata!.systemInstructions).toBeDefined();
    expect(
      firstInference.inferenceMetadata!.systemInstructions!.startsWith(
        "You are an AI customer service agent",
      ),
    ).toBe(true);
  });

  it("non-inference steps have inferenceMetadata === undefined", () => {
    const nonInference = trace.steps.filter(
      (s) => s.type === "tool" || s.type === "agent",
    );
    for (const step of nonInference) {
      expect(step.inferenceMetadata).toBeUndefined();
    }
  });
});

// ---------------------------------------------------------------------------
// Test: Analysis prompt rendering
// ---------------------------------------------------------------------------

describe("Analysis prompt rendering with reasoning trace", () => {
  const prompt = buildAnalysisPrompt({
    caseId: "test-mortgage-rate",
    testCaseDefinition: null,
    transcript: [],
    reasoningTrace: trace,
    expectedTools: ["verifyIdentity", "getAccounts", "getLoanDetails"],
    actualTools: trace.toolSequence,
    agentTools: [],
    systemPrompt: "",
  });

  it("output contains '## Reasoning trace'", () => {
    expect(prompt).toContain("## Reasoning trace");
  });

  it("reasoning entries appear in chronological step order", () => {
    const reasoningSection = prompt.split("## Reasoning trace")[1];
    expect(reasoningSection).toBeDefined();

    // Extract [step N ...] markers
    const stepMarkers = [...reasoningSection.matchAll(/\[step (\d+)/g)].map(
      (m) => parseInt(m[1], 10),
    );
    // They should be strictly increasing
    for (let i = 1; i < stepMarkers.length; i++) {
      expect(stepMarkers[i]).toBeGreaterThan(stepMarkers[i - 1]);
    }
  });

  it("first reasoning entry text is preserved verbatim", () => {
    const firstInference = trace.steps.find((s) => s.type === "inference")!;
    expect(prompt).toContain(firstInference.reasoning!);
  });
});

// ---------------------------------------------------------------------------
// Test: Helpfulness context rendering (reasoning excluded)
// ---------------------------------------------------------------------------

describe("Helpfulness context rendering — reasoning excluded", () => {
  // Build minimal transcript from inference spans' input messages (customer turns)
  const customerTurns: CustomerTurnWithTimestamp[] = [
    {
      text: "Hey can you pull up my mortgage and tell me what my rate it",
      timestampMs: Date.parse("2026-06-11T04:23:08.548Z"),
    },
    {
      text: "It's 407-462-9069.",
      timestampMs: Date.parse("2026-06-11T04:23:11.925Z"),
    },
    {
      text: "1234.",
      timestampMs: Date.parse("2026-06-11T04:23:15.004Z"),
    },
  ];

  const transcript: TranscriptTurn[] = customerTurns.map((ct, i) => ({
    turnNumber: i,
    role: "customer" as const,
    text: ct.text,
    timestamp: new Date(ct.timestampMs).toISOString(),
    elapsedMs: 0,
  }));

  const snapshot: AgentSnapshot = {
    tools: [],
    systemPrompt: "",
    modelId: "",
    capturedAt: new Date(0).toISOString(),
  };

  const rendered = renderJudgePromptContext({
    trace,
    transcript,
    snapshot,
    expectedToolNames: [],
  });

  it("at least one assistant turn context includes Action: lines for same-turn tool calls", () => {
    const hasAction = rendered.assistantTurns.some(
      (at) => at.context.includes("Action:"),
    );
    expect(hasAction).toBe(true);
  });

  it("assistant turn contexts do NOT include reasoning text", () => {
    const inferenceSteps = trace.steps.filter((s) => s.type === "inference");
    for (const at of rendered.assistantTurns) {
      for (const step of inferenceSteps) {
        if (step.reasoning) {
          // Reasoning text should NOT appear in the context
          expect(at.context).not.toContain(step.reasoning);
        }
      }
    }
  });

  it("full session context does NOT include reasoning text", () => {
    const inferenceSteps = trace.steps.filter((s) => s.type === "inference");
    for (const step of inferenceSteps) {
      if (step.reasoning) {
        expect(rendered.context).not.toContain(step.reasoning);
      }
    }
  });
});
