/**
 * Pure reducer for the Test Suites page's per-agent expand/collapse state.
 *
 * The Suites page tracks which agent sections are expanded in a
 * `Record<agentName, boolean>`. On every fetch (initial load, refresh,
 * create, delete) the page reconciles that map against the agents present
 * in the freshly fetched suites: newly discovered agents default to
 * expanded (`true`), while any agent the user has already interacted with
 * keeps its current state. This is what makes a user's collapse choice
 * survive a refresh (Requirement 5.3) and what makes every section start
 * expanded on first load (Requirement 5.2).
 *
 * Extracting the merge into a pure function keeps the load-bearing logic
 * out of the component's `useEffect` so it can be unit- and property-tested
 * directly against the real code path the component runs.
 *
 * @module expandedAgents
 */

import { groupSuitesByAgent } from './groupSuites';
import type { EnrichedTestSuite } from '../../../shared/types';

/** Per-agent expand/collapse state keyed by `agentName`. */
export type ExpandedAgentsState = Record<string, boolean>;

/**
 * Reconcile the previous expand/collapse state with the agents present in
 * the supplied suites.
 *
 * Every distinct `agentName` derived from `suites` that is not already a
 * key of `prev` is added as expanded (`true`). Agents already present in
 * `prev` keep their existing value verbatim — including `false`, so a
 * user's collapse choice is preserved across re-fetches. Existing keys are
 * never removed, so an agent that temporarily disappears from a fetch (and
 * later returns) retains the user's choice.
 *
 * The function is pure: it returns a new object and never mutates `prev`.
 *
 * @param prev - The current expand/collapse map (the component's state).
 * @param suites - The freshly fetched enriched suites.
 * @returns The reconciled expand/collapse map.
 */
export function mergeExpandedAgents(
  prev: ExpandedAgentsState,
  suites: EnrichedTestSuite[],
): ExpandedAgentsState {
  const next: ExpandedAgentsState = { ...prev };
  for (const group of groupSuitesByAgent(suites)) {
    if (!(group.agentName in next)) {
      next[group.agentName] = true;
    }
  }
  return next;
}
