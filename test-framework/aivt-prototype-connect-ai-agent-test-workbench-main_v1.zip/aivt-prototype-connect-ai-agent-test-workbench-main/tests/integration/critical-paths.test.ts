/**
 * Integration tests for critical paths through the Connect Agent Test Platform.
 *
 * These tests verify end-to-end data flows between components using mocked AWS SDK clients.
 * Each test exercises a full request→response flow through the Lambda handler, validating
 * that the correct AWS API calls are made with the correct parameters and that responses
 * are properly shaped.
 *
 * Critical paths tested:
 * 1. Discovery Lambda → ListAIAgents → filtered to ORCHESTRATION only
 * 2. Suite CRUD → DynamoDB read/write with correct composite keys
 * 3. Run Trigger → Step Functions execution start with correct input
 * 4. Conversation Driver → Q in Connect session lifecycle (mocked)
 * 5. Evaluation → AgentCore scoring + fallback path
 *
 * @validates Requirements 3.1, 4.2, 7.1, 9.1, 9.5
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { QConnectClient } from "@aws-sdk/client-qconnect";
import { SFNClient } from "@aws-sdk/client-sfn";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

import {
  handler as discoveryHandler,
  _setQConnectClient as setDiscoveryClient,
} from "../../src/backend/handlers/discovery";
import {
  handler as suitesHandler,
  _setDBService as setSuitesDBService,
} from "../../src/backend/handlers/suites";
import {
  handler as runsHandler,
  _setQConnectClient as setRunsQConnectClient,
  _setSFNClient as setRunsSFNClient,
  _setDBService as setRunsDBService,
} from "../../src/backend/handlers/runs";
import {
  executeTestCase,
  _setQConnectClient as setConversationClient,
} from "../../src/backend/orchestration/conversation-driver";
import {
  _setConnectClient as setContactConnectClient,
} from "../../src/backend/orchestration/contact-manager";
import { ConnectClient } from "@aws-sdk/client-connect";
import { createDynamoDBService } from "../../src/backend/services/dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../src/shared/constants";
import { CommunicationStyle, RunStatus, CaseStatus } from "../../src/shared/enums";
import type { TestCase } from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

function createMockClient<T>(sendFn: (command: unknown) => Promise<unknown>): T {
  return { send: sendFn } as unknown as T;
}

const originalEnv = { ...process.env };

// ---------------------------------------------------------------------------
// 1. Discovery Lambda → ListAIAgents → filtered response
// ---------------------------------------------------------------------------

describe("Integration: Discovery Lambda → ListAIAgents → filtered response", () => {
  beforeEach(() => {
    process.env.ASSISTANT_ID = "asst-integration-test";
    process.env.AWS_REGION = "us-west-2";
  });

  afterEach(() => {
    setDiscoveryClient(null);
    process.env = { ...originalEnv };
  });

  it("calls ListAIAgents with the configured assistant ID and filters to ORCHESTRATION only", async () => {
    const capturedCommands: unknown[] = [];

    const mockSend = vi.fn().mockImplementation((command: unknown) => {
      capturedCommands.push(command);
      return Promise.resolve({
        aiAgentSummaries: [
          {
            aiAgentId: "agent-orch-1",
            name: "Travel Booking Agent",
            type: "ORCHESTRATION",
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: "claude-3-haiku",
                toolConfigurations: [
                  { toolName: "SearchFlights", toolType: "LAMBDA", description: "Search flights" },
                  { toolName: "BookFlight", toolType: "LAMBDA", description: "Book a flight" },
                ],
              },
            },
          },
          {
            aiAgentId: "agent-self-1",
            name: "FAQ Bot",
            type: "SELF_SERVICE",
            configuration: { selfServiceAIAgentConfiguration: {} },
          },
          {
            aiAgentId: "agent-orch-2",
            name: "Banking Agent",
            type: "ORCHESTRATION",
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: "claude-3-sonnet",
                toolConfigurations: [
                  { toolName: "CheckBalance", toolType: "LAMBDA", description: "Check account balance" },
                ],
              },
            },
          },
          {
            aiAgentId: "agent-answer-1",
            name: "Answer Recommender",
            type: "ANSWER_RECOMMENDATION",
            configuration: { answerRecommendationAIAgentConfiguration: {} },
          },
        ],
        nextToken: undefined,
      });
    });

    setDiscoveryClient(createMockClient<QConnectClient>(mockSend));

    // Execute the full handler flow
    const response = await discoveryHandler({ httpMethod: "GET" });

    // Verify HTTP response
    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body);

    // Verify filtering: only ORCHESTRATION agents returned
    expect(body.agents).toHaveLength(2);
    expect(body.agents.every((a: { type: string }) => a.type === "ORCHESTRATION")).toBe(true);

    // Verify correct agent details
    expect(body.agents[0]).toEqual({
      agentId: "agent-orch-1",
      name: "Travel Booking Agent",
      type: "ORCHESTRATION",
      toolCount: 2,
      modelId: "claude-3-haiku",
    });
    expect(body.agents[1]).toEqual({
      agentId: "agent-orch-2",
      name: "Banking Agent",
      type: "ORCHESTRATION",
      toolCount: 1,
      modelId: "claude-3-sonnet",
    });

    // Verify the SDK call was made with the correct assistant ID
    expect(mockSend).toHaveBeenCalledTimes(1);
    const calledCommand = capturedCommands[0] as { input?: { assistantId?: string } };
    expect(calledCommand.input?.assistantId).toBe("asst-integration-test");
  });

  it("paginates through all pages and accumulates only ORCHESTRATION agents", async () => {
    let callCount = 0;
    const mockSend = vi.fn().mockImplementation(() => {
      callCount++;
      if (callCount === 1) {
        return Promise.resolve({
          aiAgentSummaries: [
            {
              aiAgentId: "page1-agent",
              name: "Page 1 Agent",
              type: "ORCHESTRATION",
              configuration: {
                orchestrationAIAgentConfiguration: {
                  orchestrationAIPromptId: "model-1",
                  toolConfigurations: [],
                },
              },
            },
            {
              aiAgentId: "page1-self",
              name: "Page 1 Self Service",
              type: "SELF_SERVICE",
              configuration: { selfServiceAIAgentConfiguration: {} },
            },
          ],
          nextToken: "next-page-token",
        });
      }
      return Promise.resolve({
        aiAgentSummaries: [
          {
            aiAgentId: "page2-agent",
            name: "Page 2 Agent",
            type: "ORCHESTRATION",
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: "model-2",
                toolConfigurations: [{ toolName: "Tool1", toolType: "LAMBDA" }],
              },
            },
          },
        ],
        nextToken: undefined,
      });
    });

    setDiscoveryClient(createMockClient<QConnectClient>(mockSend));

    const response = await discoveryHandler({ httpMethod: "GET" });
    const body = JSON.parse(response.body);

    expect(response.statusCode).toBe(200);
    expect(body.agents).toHaveLength(2);
    expect(body.agents[0].agentId).toBe("page1-agent");
    expect(body.agents[1].agentId).toBe("page2-agent");
    // Self-service agent from page 1 was filtered out
    expect(mockSend).toHaveBeenCalledTimes(2);
  });
});

// ---------------------------------------------------------------------------
// 2. Suite CRUD → DynamoDB read/write with correct keys
// ---------------------------------------------------------------------------

describe("Integration: Suite CRUD → DynamoDB read/write with correct keys", () => {
  let mockDocClient: DynamoDBDocumentClient;
  let capturedCommands: Array<{ constructor: { name: string }; input: Record<string, unknown> }>;

  beforeEach(() => {
    process.env.TABLE_NAME = "TestTable";
    process.env.ASSISTANT_ID = "asst-test";
    capturedCommands = [];

    mockDocClient = {
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
        capturedCommands.push(cmd);

        const cmdName = cmd.constructor.name;

        // Handle different command types
        if (cmdName === "PutCommand") {
          return Promise.resolve({});
        }
        if (cmdName === "GetCommand") {
          const key = cmd.input.Key as Record<string, string>;
          // Return a suite if the SK starts with SUITE#
          if (key?.SK?.startsWith("SUITE#")) {
            return Promise.resolve({
              Item: {
                PK: key.PK,
                SK: key.SK,
                tenantId: "tenant-123",
                suiteId: key.SK.replace("SUITE#", ""),
                name: "Test Suite",
                agentId: "agent-1",
                assistantId: "asst-test",
                createdAt: "2024-01-01T00:00:00.000Z",
                updatedAt: "2024-01-01T00:00:00.000Z",
              },
            });
          }
          return Promise.resolve({ Item: undefined });
        }
        if (cmdName === "QueryCommand") {
          return Promise.resolve({ Items: [] });
        }
        return Promise.resolve({});
      }),
    } as unknown as DynamoDBDocumentClient;

    const dbService = createDynamoDBService("TestTable", mockDocClient);
    setSuitesDBService(dbService);
  });

  afterEach(() => {
    setSuitesDBService(null);
    process.env = { ...originalEnv };
  });

  it("creates a suite with correct DynamoDB PK/SK pattern (TENANT#{tenantId} / SUITE#{suiteId})", async () => {
    const event = {
      httpMethod: "POST",
      resource: "/suites",
      body: JSON.stringify({
        name: "Regression Suite Alpha",
        description: "Tests for the booking agent",
        agentId: "agent-booking-001",
      }),
      requestContext: {
        authorizer: { claims: { sub: "tenant-abc-123" } },
      },
    };

    const response = await suitesHandler(event);

    expect(response.statusCode).toBe(201);
    const body = JSON.parse(response.body);
    expect(body.name).toBe("Regression Suite Alpha");
    expect(body.tenantId).toBe("tenant-abc-123");
    expect(body.agentId).toBe("agent-booking-001");
    expect(body.suiteId).toBeDefined();

    // Verify DynamoDB PutCommand was called with correct key pattern
    const putCommands = capturedCommands.filter((c) => c.constructor.name === "PutCommand");
    expect(putCommands.length).toBeGreaterThan(0);

    const putItem = putCommands[0].input.Item as Record<string, string>;
    expect(putItem.PK).toBe(`${PK_PATTERNS.TENANT}tenant-abc-123`);
    expect(putItem.SK).toMatch(new RegExp(`^${SK_PATTERNS.SUITE}`));
    // Verify GSI keys
    expect(putItem.GSI1PK).toBe(`${PK_PATTERNS.TENANT}tenant-abc-123`);
    expect(putItem.GSI1SK).toBeDefined(); // updatedAt timestamp
    expect(putItem.GSI2PK).toBe("AGENT#agent-booking-001");
  });

  it("retrieves a suite using composite key (tenant + suite ID)", async () => {
    const event = {
      httpMethod: "GET",
      resource: "/suites/{suiteId}",
      pathParameters: { suiteId: "suite-001" },
      requestContext: {
        authorizer: { claims: { sub: "tenant-123" } },
      },
    };

    const response = await suitesHandler(event);

    expect(response.statusCode).toBe(200);

    // Verify GetCommand was sent with correct key pattern
    const getCommands = capturedCommands.filter((c) => c.constructor.name === "GetCommand");
    expect(getCommands.length).toBeGreaterThan(0);

    const getKey = getCommands[0].input.Key as Record<string, string>;
    expect(getKey.PK).toBe(`${PK_PATTERNS.TENANT}tenant-123`);
    expect(getKey.SK).toBe(`${SK_PATTERNS.SUITE}suite-001`);
  });

  it("rejects suite creation with missing required fields", async () => {
    const event = {
      httpMethod: "POST",
      resource: "/suites",
      body: JSON.stringify({
        // Missing name and agentId
        description: "Some description",
      }),
      requestContext: {
        authorizer: { claims: { sub: "tenant-123" } },
      },
    };

    const response = await suitesHandler(event);

    expect(response.statusCode).toBe(400);
    const body = JSON.parse(response.body);
    expect(body.error).toBe("Validation failed");
    expect(body.details).toBeDefined();
  });

  it("creates a test case with SUITE#{suiteId} / CASE#{caseId} key pattern", async () => {
    // Mock to also handle the getSuite call (verifies parent exists)
    const mockSendForCases = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
      capturedCommands.push(cmd);

      if (cmd.constructor.name === "GetCommand") {
        return Promise.resolve({
          Item: {
            PK: "TENANT#tenant-123",
            SK: "SUITE#suite-001",
            tenantId: "tenant-123",
            suiteId: "suite-001",
            name: "Test Suite",
            agentId: "agent-1",
            assistantId: "asst-test",
            createdAt: "2024-01-01T00:00:00.000Z",
            updatedAt: "2024-01-01T00:00:00.000Z",
          },
        });
      }
      if (cmd.constructor.name === "QueryCommand") {
        return Promise.resolve({ Items: [] });
      }
      return Promise.resolve({});
    });

    const docClientForCases = { send: mockSendForCases } as unknown as DynamoDBDocumentClient;
    const dbServiceForCases = createDynamoDBService("TestTable", docClientForCases);
    setSuitesDBService(dbServiceForCases);
    capturedCommands = [];

    const event = {
      httpMethod: "POST",
      resource: "/suites/{suiteId}/cases",
      pathParameters: { suiteId: "suite-001" },
      body: JSON.stringify({
        name: "Book a flight",
        description: "Customer wants to book a one-way flight to Seattle",
        persona: "Business traveler",
        style: CommunicationStyle.DIRECT,
        customerKnowledge: {
          destination: "Seattle",
          date: "2024-06-15",
        },
        initialUtterance: "I need to book a flight to Seattle",
        successCriteria: [
          { toolName: "AuthenticateCustomer", required: true },
          { toolName: "SearchFlights", required: true },
          { toolName: "BookFlight", required: true },
        ],
      }),
      requestContext: {
        authorizer: { claims: { sub: "tenant-123" } },
      },
    };

    const response = await suitesHandler(event);

    expect(response.statusCode).toBe(201);
    const body = JSON.parse(response.body);
    expect(body.suiteId).toBe("suite-001");
    expect(body.caseId).toBeDefined();
    expect(body.successCriteria).toHaveLength(3);

    // Verify PutCommand uses correct SUITE#{suiteId} / CASE#{caseId} pattern
    const putCommands = capturedCommands.filter((c) => c.constructor.name === "PutCommand");
    expect(putCommands.length).toBeGreaterThan(0);

    const putItem = putCommands[0].input.Item as Record<string, string>;
    expect(putItem.PK).toBe(`${PK_PATTERNS.SUITE}suite-001`);
    expect(putItem.SK).toMatch(new RegExp(`^${SK_PATTERNS.CASE}`));
  });
});

// ---------------------------------------------------------------------------
// 3. Run Trigger → Step Functions execution start
// ---------------------------------------------------------------------------

describe("Integration: Run Trigger → Step Functions execution start", () => {
  let mockQConnect: QConnectClient;
  let mockSFN: SFNClient;
  let capturedSFNCommands: Array<{ constructor: { name: string }; input: Record<string, unknown> }>;

  beforeEach(() => {
    process.env.TABLE_NAME = "TestTable";
    process.env.ASSISTANT_ID = "asst-integration";
    process.env.STATE_MACHINE_ARN = "arn:aws:states:us-east-1:123456789012:stateMachine:TestRunnerSM";
    process.env.AWS_REGION = "us-east-1";
    capturedSFNCommands = [];

    // Mock QConnect for agent snapshot
    mockQConnect = createMockClient<QConnectClient>(
      vi.fn().mockResolvedValue({
        aiAgent: {
          aiAgentId: "agent-001",
          name: "Booking Agent",
          type: "ORCHESTRATION",
          configuration: {
            orchestrationAIAgentConfiguration: {
              orchestrationAIPromptId: "claude-3-haiku",
              toolConfigurations: [
                {
                  toolName: "SearchFlights",
                  toolType: "LAMBDA",
                  description: "Search available flights",
                  inputSchema: { type: "object" },
                },
              ],
            },
          },
        },
      })
    );

    // Mock SFN
    mockSFN = {
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
        capturedSFNCommands.push(cmd);
        return Promise.resolve({
          executionArn: "arn:aws:states:us-east-1:123456789012:execution:TestRunnerSM:run-abc123-1234567890",
          startDate: new Date(),
        });
      }),
    } as unknown as SFNClient;

    // Mock DynamoDB service for runs
    const mockDbSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
      if (cmd.constructor.name === "GetCommand") {
        const key = cmd.input.Key as Record<string, string>;
        if (key?.SK?.startsWith("SUITE#")) {
          return Promise.resolve({
            Item: {
              PK: key.PK,
              SK: key.SK,
              tenantId: "tenant-run-test",
              suiteId: "suite-run-001",
              name: "Run Test Suite",
              agentId: "agent-001",
              assistantId: "asst-integration",
              createdAt: "2024-01-01T00:00:00.000Z",
              updatedAt: "2024-01-01T00:00:00.000Z",
            },
          });
        }
      }
      if (cmd.constructor.name === "QueryCommand") {
        // Return test cases for the suite
        return Promise.resolve({
          Items: [
            {
              PK: "SUITE#suite-run-001",
              SK: "CASE#case-001",
              suiteId: "suite-run-001",
              caseId: "case-001",
              name: "Test flight booking",
              description: "Book a flight",
              initialUtterance: "I want to book a flight",
              successCriteria: [{ toolName: "SearchFlights", required: true }],
              persona: "traveler",
              style: "direct",
              customerKnowledge: {},
            },
          ],
        });
      }
      return Promise.resolve({});
    });
    const mockDocClient = { send: mockDbSend } as unknown as DynamoDBDocumentClient;
    const dbService = createDynamoDBService("TestTable", mockDocClient);

    setRunsQConnectClient(mockQConnect);
    setRunsSFNClient(mockSFN);
    setRunsDBService(dbService);
  });

  afterEach(() => {
    setRunsQConnectClient(null);
    setRunsSFNClient(null);
    setRunsDBService(null);
    process.env = { ...originalEnv };
  });

  it("starts Step Functions execution with correct input shape including suite, tenant, concurrency, agent snapshot, and test cases", async () => {
    const event = {
      httpMethod: "POST",
      resource: "/runs",
      body: JSON.stringify({ suiteId: "suite-run-001", concurrency: 5 }),
      requestContext: {
        authorizer: { claims: { sub: "tenant-run-test" } },
      },
    };

    const response = await runsHandler(event);

    expect(response.statusCode).toBe(201);
    const body = JSON.parse(response.body);
    expect(body.runId).toBeDefined();
    expect(body.sfnExecutionArn).toContain("arn:aws:states");
    expect(body.status).toBe(RunStatus.RUNNING);

    // Verify Step Functions StartExecution was called
    expect(capturedSFNCommands.length).toBeGreaterThan(0);
    const startCommand = capturedSFNCommands[0];
    expect(startCommand.constructor.name).toBe("StartExecutionCommand");

    // Verify the execution input shape
    expect(startCommand.input.stateMachineArn).toBe(
      "arn:aws:states:us-east-1:123456789012:stateMachine:TestRunnerSM"
    );
    expect(startCommand.input.name).toMatch(/^run-/);

    const executionInput = JSON.parse(startCommand.input.input as string);
    expect(executionInput.suiteId).toBe("suite-run-001");
    expect(executionInput.tenantId).toBe("tenant-run-test");
    expect(executionInput.concurrency).toBe(5);
    expect(executionInput.runId).toBeDefined();

    // Agent snapshot captured correctly
    expect(executionInput.agentSnapshot).toBeDefined();
    expect(executionInput.agentSnapshot.tools).toHaveLength(1);
    expect(executionInput.agentSnapshot.tools[0].toolName).toBe("SearchFlights");
    expect(executionInput.agentSnapshot.modelId).toBe("claude-3-haiku");
    expect(executionInput.agentSnapshot.capturedAt).toBeDefined();

    // Test cases included
    expect(executionInput.testCases).toHaveLength(1);
    expect(executionInput.testCases[0].caseId).toBe("case-001");
  });

  it("uses default concurrency (9) when not specified", async () => {
    const event = {
      httpMethod: "POST",
      resource: "/runs",
      body: JSON.stringify({ suiteId: "suite-run-001" }),
      requestContext: {
        authorizer: { claims: { sub: "tenant-run-test" } },
      },
    };

    const response = await runsHandler(event);
    expect(response.statusCode).toBe(201);

    const startCommand = capturedSFNCommands[0];
    const executionInput = JSON.parse(startCommand.input.input as string);
    expect(executionInput.concurrency).toBe(9);
  });
});

// ---------------------------------------------------------------------------
// 4. Conversation Driver → Q in Connect session lifecycle (mocked)
// ---------------------------------------------------------------------------

describe("Integration: Conversation Driver → Q in Connect session lifecycle", () => {
  // Mock the Amazon Connect client so contact minting/teardown doesn't hit AWS.
  // Returns a fixed ContactId for StartChatContact; StopContact resolves empty.
  beforeEach(() => {
    const connectSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      if (cmd.constructor.name === "StartChatContactCommand") {
        return Promise.resolve({ ContactId: "contact-mock-001" });
      }
      return Promise.resolve({});
    });
    setContactConnectClient(createMockClient<ConnectClient>(connectSend));
  });

  afterEach(() => {
    setConversationClient(null);
    setContactConnectClient(null);
    process.env = { ...originalEnv };
    vi.restoreAllMocks();
  });

  const testCase: TestCase = {
    type: "tool_sequence",
    suiteId: "suite-conv-001",
    caseId: "case-conv-001",
    name: "Flight booking multi-turn",
    description: "Customer books a flight through authentication and search",
    persona: "Business traveler",
    style: CommunicationStyle.DIRECT,
    customerKnowledge: { destination: "Seattle", date: "2024-06-15" },
    initialUtterance: "I need to book a flight to Seattle",
    successCriteria: [
      { toolName: "AuthenticateCustomer", required: true },
      { toolName: "SearchFlights", required: true },
    ],
  };

  it("executes full session lifecycle: CreateSession → SendMessage → poll → tool extraction → customer simulation → multi-turn", async () => {
    // Mock the customer simulator module
    vi.mock("../../src/backend/orchestration/customer-simulator", () => ({
      simulateCustomer: vi.fn().mockResolvedValue("Yes, my destination is Seattle"),
    }));

    let callSequence = 0;
    const capturedCalls: Array<{ name: string; input: Record<string, unknown> }> = [];

    const mockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
      capturedCalls.push({ name: cmd.constructor.name, input: cmd.input });
      callSequence++;

      // CreateSession
      if (cmd.constructor.name === "CreateSessionCommand") {
        return Promise.resolve({
          session: { sessionId: "session-xyz-789" },
        });
      }

      // SendMessage
      if (cmd.constructor.name === "SendMessageCommand") {
        return Promise.resolve({
          nextMessageToken: `token-${callSequence}`,
        });
      }

      // GetNextMessage — simulate a multi-turn flow
      if (cmd.constructor.name === "GetNextMessageCommand") {
        const token = cmd.input.nextMessageToken as string;

        // First poll after initial utterance: agent selects AuthenticateCustomer tool
        if (token === "token-2") {
          return Promise.resolve({
            response: { value: { text: { value: "Let me verify your identity." } } },
            conversationSessionData: [
              { key: "Tool", value: { stringValue: "AuthenticateCustomer" } },
            ],
            nextMessageToken: "token-auth-done",
            conversationState: { status: "READY" },
          });
        }

        // After "continue" for tool: agent asks a question
        if (token === "token-3") {
          return Promise.resolve({
            response: { value: { text: { value: "What is your destination?" } } },
            conversationSessionData: [],
            nextMessageToken: "token-question",
            conversationState: { status: "READY" },
          });
        }

        // After customer responds: agent selects SearchFlights tool
        if (token === "token-4") {
          return Promise.resolve({
            response: { value: { text: { value: "Searching for flights to Seattle..." } } },
            conversationSessionData: [
              { key: "Tool", value: { stringValue: "SearchFlights" } },
            ],
            nextMessageToken: "token-search-done",
            conversationState: { status: "READY" },
          });
        }

        // After second "continue": agent provides final text response (no tool)
        if (token === "token-5") {
          return Promise.resolve({
            response: { value: { text: { value: "I found 3 flights to Seattle. Here are your options..." } } },
            conversationSessionData: [],
            nextMessageToken: "token-5",
            conversationState: { status: "READY" },
          });
        }

        // Fallback: conversation ended
        return Promise.resolve({
          response: { value: {} },
          conversationSessionData: [],
          nextMessageToken: token,
          conversationState: { status: "CLOSED" },
        });
      }

      // ListSpans — authoritative tool source. Return execute_tool spans for the
      // two MCP tools plus agent identity, so the driver derives toolsInvoked
      // from spans (the real production path).
      if (cmd.constructor.name === "ListSpansCommand") {
        return Promise.resolve({
          spans: [
            {
              spanName: "execute_tool",
              startTimestamp: "2024-01-01T00:00:01.000Z",
              attributes: {
                aiAgentName: "BookingAgent",
                aiAgentType: "ORCHESTRATION",
                inputMessages: [
                  { values: [{ toolUse: { name: "AuthenticateCustomer", arguments: "{}" } }] },
                ],
                outputMessages: [
                  { values: [{ toolResult: { values: [{ text: { value: '{"status":"success"}' } }] } }] },
                ],
              },
            },
            {
              spanName: "execute_tool",
              startTimestamp: "2024-01-01T00:00:02.000Z",
              attributes: {
                aiAgentName: "BookingAgent",
                aiAgentType: "ORCHESTRATION",
                inputMessages: [
                  { values: [{ toolUse: { name: "SearchFlights", arguments: '{"dest":"Seattle"}' } }] },
                ],
                outputMessages: [
                  { values: [{ toolResult: { values: [{ text: { value: '{"status":"success"}' } }] } }] },
                ],
              },
            },
          ],
        });
      }

      return Promise.resolve({});
    });

    setConversationClient(createMockClient<QConnectClient>(mockSend));

    const result = await executeTestCase(testCase, "agent-booking-001", "asst-conv-test", "instance-conv-001", "flow-conv-001");

    // Verify result
    expect(result.caseId).toBe("case-conv-001");
    expect(result.status).not.toBe(CaseStatus.ERROR);
    expect(result.status).not.toBe(CaseStatus.TIMED_OUT);
    // toolsInvoked is now derived authoritatively from ListSpans execute_tool spans
    expect(result.toolsInvoked).toContain("AuthenticateCustomer");
    expect(result.toolsInvoked).toContain("SearchFlights");
    expect(result.toolsInvoked).toHaveLength(2);
    expect(result.turnCount).toBeGreaterThan(0);
    expect(result.latencyMs).toBeGreaterThanOrEqual(0);

    // Verify the structured execution trace was built from spans
    expect(result.executionTrace).toBeDefined();
    expect(result.executionTrace!.toolSequence).toEqual(["AuthenticateCustomer", "SearchFlights"]);
    expect(result.executionTrace!.aiAgentName).toBe("BookingAgent");
    expect(result.executionTrace!.steps.filter((s) => s.type === "tool")).toHaveLength(2);
    expect(result.sessionId).toBe("session-xyz-789");

    // Verify CreateSession was called with correct assistantId + bound contactArn (no aiAgentId)
    const createSessionCall = capturedCalls.find((c) => c.name === "CreateSessionCommand");
    expect(createSessionCall).toBeDefined();
    expect(createSessionCall!.input.assistantId).toBe("asst-conv-test");
    expect(createSessionCall!.input.name).toMatch(/^test-[0-9a-f]{8}$/);
    expect((createSessionCall!.input as Record<string, unknown>).contactArn).toContain("contact-mock-001");
    expect((createSessionCall!.input as Record<string, unknown>).aiAgentId).toBeUndefined();

    // Verify SendMessage includes aiAgentId override
    const sendMessageCalls = capturedCalls.filter((c) => c.name === "SendMessageCommand");
    expect(sendMessageCalls.length).toBeGreaterThan(0);
    for (const call of sendMessageCalls) {
      expect(call.input.aiAgentId).toBe("agent-booking-001");
      expect(call.input.assistantId).toBe("asst-conv-test");
      expect(call.input.sessionId).toBe("session-xyz-789");
    }
  });

  it("marks test case as error on non-throttling CreateSession failure", async () => {
    const mockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      if (cmd.constructor.name === "CreateSessionCommand") {
        const err = new Error("Access denied to create session");
        (err as { name: string }).name = "AccessDeniedException";
        return Promise.reject(err);
      }
      return Promise.resolve({});
    });

    setConversationClient(createMockClient<QConnectClient>(mockSend));

    const result = await executeTestCase(testCase, "agent-001", "asst-test", "instance-001", "flow-001");

    expect(result.status).toBe(CaseStatus.ERROR);
    expect(result.errorMessage).toContain("Access denied");
    expect(result.toolsInvoked).toEqual([]);
  });

  it("handles filler responses by continuing to poll", async () => {
    vi.mock("../../src/backend/orchestration/customer-simulator", () => ({
      simulateCustomer: vi.fn().mockResolvedValue("Sure, go ahead"),
    }));

    let pollCount = 0;
    const mockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };

      if (cmd.constructor.name === "CreateSessionCommand") {
        return Promise.resolve({ session: { sessionId: "session-filler" } });
      }
      if (cmd.constructor.name === "SendMessageCommand") {
        return Promise.resolve({ nextMessageToken: "poll-token-1" });
      }
      if (cmd.constructor.name === "GetNextMessageCommand") {
        pollCount++;
        // First two polls return filler "..." with advancing token
        if (pollCount <= 2) {
          return Promise.resolve({
            response: { value: { text: { value: "..." } } },
            conversationSessionData: [],
            nextMessageToken: `poll-token-${pollCount + 1}`,
            conversationState: { status: "PROCESSING" },
          });
        }
        // Third poll returns substantive response
        return Promise.resolve({
          response: { value: { text: { value: "Here is your answer." } } },
          conversationSessionData: [],
          nextMessageToken: `poll-token-${pollCount + 1}`,
          conversationState: { status: "CLOSED" },
        });
      }
      return Promise.resolve({});
    });

    setConversationClient(createMockClient<QConnectClient>(mockSend));

    const result = await executeTestCase(testCase, "agent-001", "asst-test", "instance-001", "flow-001");

    // Should not have errored or timed out — filler was handled
    expect(result.status).not.toBe(CaseStatus.ERROR);
    expect(result.status).not.toBe(CaseStatus.TIMED_OUT);
    // Should have polled multiple times (filler was skipped)
    expect(pollCount).toBeGreaterThanOrEqual(3);
  });
});

// ---------------------------------------------------------------------------
// 5. End-to-end against the deployed test stack (skipped when not configured)
// ---------------------------------------------------------------------------
//
// These tests exercise the actionable-recommendations critical paths against
// a real deployment. They are wired up here (rather than as a stand-alone
// file) so the whole repo's `vitest run` invocation picks them up and so
// they share the imports/types of the rest of the suite.
//
// Skip semantics: the entire describe block skips when `INTEGRATION_API_URL`
// is not set, which is the default in CI and local dev. Set
//   INTEGRATION_API_URL          base URL of the deployed API Gateway
//                                (e.g. https://abc123.execute-api.us-east-1.amazonaws.com/prod)
//   INTEGRATION_AUTH_TOKEN       Cognito JWT/OAuth bearer token with the
//                                `test-platform/run` scope
//   INTEGRATION_SUITE_ID         Suite ID pre-seeded to produce ≥1 failing case
//   INTEGRATION_RUN_ID           (optional) pre-existing COMPLETED run ID;
//                                when set the trigger-and-wait step is skipped
//   INTEGRATION_RUN_TIMEOUT_MS   (optional) max ms to wait for run completion
//                                (default 10 minutes)
// to enable. Tests fail (don't skip) when these are partially set so a
// misconfigured CI is loud, not silent.
//
// Bedrock-call counter: rather than reach into CloudWatch, the tests check
// whether the response's `generatedAt` advances between calls. The Lambda
// regenerates that timestamp only when it actually invokes Bedrock (the
// persisted-read shortcut returns the stored timestamp verbatim), so a
// stable `generatedAt` across two reads is byte-equivalent to "Bedrock was
// not invoked between the two reads."
//
// _Validates Requirements 6.2, 6.3, 8.7, 8.8, 9.3, 10.9, 11.3_

const integrationApiUrl = process.env.INTEGRATION_API_URL;
const integrationAuthToken = process.env.INTEGRATION_AUTH_TOKEN;
const integrationSuiteId = process.env.INTEGRATION_SUITE_ID;
const integrationPreexistingRunId = process.env.INTEGRATION_RUN_ID;
const integrationRunTimeoutMs = Number(
  process.env.INTEGRATION_RUN_TIMEOUT_MS ?? 10 * 60 * 1000,
);

// Skip the whole block when the base URL is not configured. Tests that need
// a token or a suite ID assert their presence inside the test so a half-
// configured CI fails loudly rather than silently passing nothing.
describe.skipIf(!integrationApiUrl)(
  "Integration: actionable-recommendations critical paths (deployed stack)",
  () => {
    // The whole block is gated, but we still need the variables to be
    // non-null inside the body. Cast once here for readability.
    const apiUrl = integrationApiUrl as string;
    const authHeader: Record<string, string> = integrationAuthToken
      ? { Authorization: `Bearer ${integrationAuthToken}` }
      : {};

    // 10-minute integration timeout — runs against deployed Lambdas + Bedrock.
    const longTimeout = 15 * 60 * 1000;

    /** Minimal typed fetch wrapper that surfaces non-2xx as test failures. */
    async function apiFetch<T>(
      path: string,
      init?: { method?: string; body?: unknown },
    ): Promise<T> {
      const url = `${apiUrl.replace(/\/$/, "")}${path}`;
      const res = await fetch(url, {
        method: init?.method ?? "GET",
        headers: {
          "Content-Type": "application/json",
          ...authHeader,
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
      });
      const text = await res.text();
      let parsed: unknown = null;
      try {
        parsed = text ? JSON.parse(text) : null;
      } catch {
        // Non-JSON response — surface raw text on failure.
      }
      if (!res.ok) {
        throw new Error(
          `${init?.method ?? "GET"} ${url} → ${res.status}: ${text}`,
        );
      }
      return parsed as T;
    }

    /** Poll until the run reaches a terminal status or the deadline elapses. */
    async function waitForRunCompletion(
      runId: string,
      timeoutMs: number,
    ): Promise<RunStatus> {
      const start = Date.now();
      const pollIntervalMs = 5_000;
      while (Date.now() - start < timeoutMs) {
        const run = await apiFetch<{ status: RunStatus }>(`/runs/${runId}`);
        if (
          run.status === RunStatus.COMPLETED ||
          run.status === RunStatus.FAILED ||
          run.status === RunStatus.ABORTED
        ) {
          return run.status;
        }
        await new Promise((r) => setTimeout(r, pollIntervalMs));
      }
      throw new Error(
        `Run ${runId} did not reach a terminal status within ${timeoutMs}ms`,
      );
    }

    /**
     * Resolve the run ID under test. When `INTEGRATION_RUN_ID` is set, reuse
     * it (faster, no Bedrock cost). Otherwise trigger a new run against
     * `INTEGRATION_SUITE_ID` and wait for completion.
     */
    async function resolveRunId(): Promise<string> {
      if (integrationPreexistingRunId) {
        // Verify the run exists and is COMPLETED before using it.
        const run = await apiFetch<{ runId: string; status: RunStatus }>(
          `/runs/${integrationPreexistingRunId}`,
        );
        expect(run.status).toBe(RunStatus.COMPLETED);
        return run.runId;
      }
      if (!integrationSuiteId) {
        throw new Error(
          "Set INTEGRATION_SUITE_ID or INTEGRATION_RUN_ID to run the deployed-stack integration tests.",
        );
      }
      const triggered = await apiFetch<{ runId: string }>("/runs", {
        method: "POST",
        body: { suiteId: integrationSuiteId },
      });
      const status = await waitForRunCompletion(
        triggered.runId,
        integrationRunTimeoutMs,
      );
      // A FAILED or ABORTED status is fine — this feature still produces
      // recommendations from any non-RUNNING run with failed cases.
      expect([
        RunStatus.COMPLETED,
        RunStatus.FAILED,
        RunStatus.ABORTED,
      ]).toContain(status);
      return triggered.runId;
    }

    /**
     * The four flows in this block share the same run, so resolve it once
     * in `beforeAll`-style and cache. Vitest's test order is preserved
     * within a describe block, but each test still re-reads `runIdRef` so a
     * resolution failure surfaces in the first test rather than silently
     * skipping the rest.
     */
    let cachedRunId: string | null = null;
    async function getRunId(): Promise<string> {
      if (cachedRunId) return cachedRunId;
      cachedRunId = await resolveRunId();
      return cachedRunId;
    }

    it(
      "per-case: persisted-read shortcut returns byte-identical responses without re-invoking Bedrock",
      async () => {
        const runId = await getRunId();

        // First call (no force). May either hit the persisted-read shortcut
        // (fast path) or invoke Bedrock if no record exists yet.
        const first = await apiFetch<{
          caseAnalyses: Array<{ caseId: string; generatedAt: string }>;
          generatedAt: string;
          modelId: string;
          partialFailures?: string[];
        }>(`/runs/${runId}/analyze`, { method: "POST" });

        expect(Array.isArray(first.caseAnalyses)).toBe(true);
        expect(first.caseAnalyses.length).toBeGreaterThan(0);
        expect(first.partialFailures ?? []).toEqual([]);

        // Second call without force — must hit the persisted-read shortcut.
        const second = await apiFetch<typeof first>(`/runs/${runId}/analyze`, {
          method: "POST",
        });

        // Byte-for-byte identical (same JSON serialization → same string).
        // Note: object key order is preserved by Node's JSON.stringify when
        // both responses come from the same Lambda implementation, so this
        // is a real equality check rather than a structural one.
        expect(JSON.stringify(second)).toBe(JSON.stringify(first));

        // The Bedrock-call counter (proxied by `generatedAt`) does not
        // advance between the two calls (R6.2, R10.9).
        expect(second.generatedAt).toBe(first.generatedAt);
        for (const c of second.caseAnalyses) {
          const matchedFirst = first.caseAnalyses.find(
            (f) => f.caseId === c.caseId,
          );
          expect(matchedFirst).toBeDefined();
          expect(c.generatedAt).toBe(matchedFirst!.generatedAt);
        }
      },
      longTimeout,
    );

    it(
      "per-case: force=true re-invokes Bedrock and advances generatedAt for every failed case",
      async () => {
        const runId = await getRunId();

        // Establish a baseline (this either hits the cache or generates).
        const baseline = await apiFetch<{
          caseAnalyses: Array<{ caseId: string; generatedAt: string }>;
          generatedAt: string;
        }>(`/runs/${runId}/analyze`, { method: "POST" });

        expect(baseline.caseAnalyses.length).toBeGreaterThan(0);

        // Force re-analysis. Every case's `generatedAt` must advance.
        const forced = await apiFetch<typeof baseline>(
          `/runs/${runId}/analyze`,
          { method: "POST", body: { force: true } },
        );

        expect(forced.caseAnalyses).toHaveLength(baseline.caseAnalyses.length);
        // Top-level generatedAt advances (R6.3).
        expect(
          new Date(forced.generatedAt).getTime(),
        ).toBeGreaterThan(new Date(baseline.generatedAt).getTime());

        // Per-case generatedAt advances by one per failed case (Bedrock-call
        // counter advances by one per failed case).
        for (const before of baseline.caseAnalyses) {
          const after = forced.caseAnalyses.find(
            (a) => a.caseId === before.caseId,
          );
          expect(after).toBeDefined();
          expect(
            new Date(after!.generatedAt).getTime(),
          ).toBeGreaterThan(new Date(before.generatedAt).getTime());
        }
      },
      longTimeout,
    );

    it(
      "per-suite: persisted-read shortcut returns byte-identical responses sorted by monotonic priority",
      async () => {
        const runId = await getRunId();

        const first = await apiFetch<{
          recommendations: Array<{
            priority: number;
            targetField: string;
            targetName: string;
            predictedImpact: { liftedCaseIds: string[]; rationale: string };
          }>;
          generatedAt: string;
          modelId: string;
        }>(`/runs/${runId}/recommend-suite`, { method: "POST" });

        expect(Array.isArray(first.recommendations)).toBe(true);
        // Length ≥ 0 — empty is a valid response per R8.1.
        expect(first.recommendations.length).toBeGreaterThanOrEqual(0);

        // Monotonic priority ordering (R9.1).
        for (let i = 1; i < first.recommendations.length; i++) {
          expect(first.recommendations[i].priority).toBeGreaterThanOrEqual(
            first.recommendations[i - 1].priority,
          );
        }

        // Second call without force — persisted-read shortcut (R8.8, R9.3).
        const second = await apiFetch<typeof first>(
          `/runs/${runId}/recommend-suite`,
          { method: "POST" },
        );

        expect(JSON.stringify(second)).toBe(JSON.stringify(first));
        expect(second.generatedAt).toBe(first.generatedAt);
      },
      longTimeout,
    );

    it(
      "per-suite: force=true advances generatedAt and re-invokes Bedrock",
      async () => {
        const runId = await getRunId();

        const baseline = await apiFetch<{
          recommendations: Array<{ priority: number }>;
          generatedAt: string;
        }>(`/runs/${runId}/recommend-suite`, { method: "POST" });

        const forced = await apiFetch<typeof baseline>(
          `/runs/${runId}/recommend-suite`,
          { method: "POST", body: { force: true } },
        );

        // generatedAt advances → Bedrock was re-invoked (R8.7).
        expect(
          new Date(forced.generatedAt).getTime(),
        ).toBeGreaterThan(new Date(baseline.generatedAt).getTime());

        // Re-sorted output still respects monotonic priority (R9.1).
        for (let i = 1; i < forced.recommendations.length; i++) {
          expect(forced.recommendations[i].priority).toBeGreaterThanOrEqual(
            forced.recommendations[i - 1].priority,
          );
        }
      },
      longTimeout,
    );

    it(
      "snapshot: GET /runs/{runId}/snapshot returns examples on every tool",
      async () => {
        const runId = await getRunId();

        const result = await apiFetch<{
          snapshot: {
            tools: Array<{
              toolName: string;
              examples: string[];
            }>;
          };
        }>(`/runs/${runId}/snapshot`);

        expect(result.snapshot).toBeDefined();
        expect(Array.isArray(result.snapshot.tools)).toBe(true);
        // Every tool MUST have an `examples` array (never undefined, R1.5,
        // R3.3). Some may be empty; at least one MUST carry examples for
        // this test stack to be a meaningful exercise of the snapshot-
        // examples flow — but we don't fail when none do, since the
        // examples field is optional on the upstream agent and a stack
        // configured without examples is still a legitimate happy path.
        for (const tool of result.snapshot.tools) {
          expect(Array.isArray(tool.examples)).toBe(true);
        }

        // If at least one tool carries examples, the per-case prompt-builder
        // path was exercised end-to-end. We cannot directly assert the
        // prompt content from a black-box integration test (the Lambda
        // does not echo the rendered prompt), but the per-case analyze
        // round-trip in the prior tests already exercises the prompt
        // builder over this same snapshot — so a non-empty examples array
        // on the snapshot is sufficient evidence that the `Examples:`
        // block flowed into the prompt.
        const toolsWithExamples = result.snapshot.tools.filter(
          (t) => t.examples.length > 0,
        );
        // Soft signal — log but don't fail when zero. CI dashboards can
        // alert on this if the seeded suite is supposed to carry examples.
        if (toolsWithExamples.length === 0) {
          // eslint-disable-next-line no-console
          console.warn(
            `[integration] runId=${runId} snapshot has no tools with examples; ` +
              "the per-case prompt-builder's Examples: block was rendered as " +
              "the literal '(none)' for every tool. Configure the seed suite " +
              "with at least one tool carrying examples to exercise the full path.",
          );
        }
      },
      longTimeout,
    );
  },
);
