/**
 * Typed Prompts API client.
 *
 * Thin, resource-specific wrapper around {@link apiClient} that:
 *
 *   1. Pins the response shapes to the contracts declared in the
 *      prompt-management design (`ListPromptsResponse`, `GetPromptResponse`,
 *      `UpdatePromptResponse`, `ResetPromptResponse`, `GetHistoryResponse`,
 *      `ActiveRunsResponse`).
 *
 *   2. Maps the platform's `{ error, code, details? }` 4xx error body to
 *      a typed {@link PromptApiError} carrying the structured `code` from
 *      the design's error table — `PROMPT_NOT_FOUND`,
 *      `PROMPT_TEXT_TOO_LARGE`, `PLACEHOLDERS_MISSING`,
 *      `PLACEHOLDER_COUNT_EXCEEDED`, `UNKNOWN_PLACEHOLDER`,
 *      `MODEL_NOT_ALLOWED`, `MODEL_FORBIDS_KEY`,
 *      `INFERENCE_PARAMETER_OUT_OF_BOUNDS`, `DRY_RENDER_FAILED`,
 *      `RESET_CONFIRMATION_REQUIRED`, `VERSION_CONFLICT`. Frontend code
 *      can `switch (err.code)` for inline UX rendering.
 *
 *   3. Sends `{ confirm: true }` automatically on `resetPrompt` so callers
 *      cannot accidentally trip the `RESET_CONFIRMATION_REQUIRED` guard.
 *
 * The base {@link ApiClientError} already carries `code` and `details`
 * lifted from the response body; this module narrows that to the typed
 * `PromptErrorCode` union and rebrands as `PromptApiError` so callers can
 * `instanceof PromptApiError` without false positives from unrelated
 * resource errors.
 *
 * @module frontend/api/prompts
 */

import { apiClient, ApiClientError } from './client';
import type {
  ModelKey,
  Placeholder,
  PromptKey,
  InferenceParameterSchema,
} from '../../../shared/types';

// ---------------------------------------------------------------------------
// Error codes (per design.md > Error Handling > API-level errors table)
// ---------------------------------------------------------------------------

/**
 * Closed union of structured error codes the Prompts API emits in the
 * `code` field of a 4xx response body. The design pins these to a
 * specific HTTP status; the frontend matches on the `code` first
 * (UX is keyed by code, not status).
 */
export type PromptErrorCode =
  | 'PROMPT_NOT_FOUND'
  | 'PROMPT_TEXT_TOO_LARGE'
  | 'PLACEHOLDERS_MISSING'
  | 'PLACEHOLDER_COUNT_EXCEEDED'
  | 'UNKNOWN_PLACEHOLDER'
  | 'MODEL_NOT_ALLOWED'
  | 'MODEL_FORBIDS_KEY'
  | 'INFERENCE_PARAMETER_OUT_OF_BOUNDS'
  | 'DRY_RENDER_FAILED'
  | 'RESET_CONFIRMATION_REQUIRED'
  | 'VERSION_CONFLICT';

/**
 * Typed error thrown by every wrapper in this module when the Prompts
 * API returns a 4xx (or 409) response with a recognised structured
 * `code`. Carries the `httpStatus` for callers that still want to
 * branch on status, and the `details` object verbatim from the
 * backend so UX components can render code-specific affordances
 * (e.g. `PROMPT_TEXT_TOO_LARGE` → `details.observedBytes`,
 * `details.limitBytes`).
 *
 * Untyped 4xx responses (malformed JSON parse errors, missing
 * `confirm`, etc.) are NOT wrapped — they remain {@link ApiClientError}
 * so callers can distinguish "the backend rejected my payload with a
 * documented code" from "my client constructed an invalid request".
 */
export class PromptApiError extends Error {
  public readonly code: PromptErrorCode;
  public readonly details?: Record<string, unknown>;
  public readonly httpStatus: number;

  constructor(args: {
    message: string;
    code: PromptErrorCode;
    httpStatus: number;
    details?: Record<string, unknown>;
  }) {
    super(args.message);
    this.name = 'PromptApiError';
    this.code = args.code;
    this.httpStatus = args.httpStatus;
    if (args.details !== undefined) {
      this.details = args.details;
    }
  }
}

/**
 * Type guard for the closed `PromptErrorCode` union. The base API
 * client passes through `code` as a generic string (it is shared
 * across resources); we narrow to the prompts-specific union here so
 * `PromptApiError` can never carry an unrelated-resource code.
 */
function isPromptErrorCode(code: string): code is PromptErrorCode {
  switch (code as PromptErrorCode) {
    case 'PROMPT_NOT_FOUND':
    case 'PROMPT_TEXT_TOO_LARGE':
    case 'PLACEHOLDERS_MISSING':
    case 'PLACEHOLDER_COUNT_EXCEEDED':
    case 'UNKNOWN_PLACEHOLDER':
    case 'MODEL_NOT_ALLOWED':
    case 'MODEL_FORBIDS_KEY':
    case 'INFERENCE_PARAMETER_OUT_OF_BOUNDS'  :
    case 'DRY_RENDER_FAILED':
    case 'RESET_CONFIRMATION_REQUIRED':
    case 'VERSION_CONFLICT':
      return true;
    default:
      return false;
  }
}

/**
 * If `err` is an {@link ApiClientError} carrying a recognised prompts
 * `code`, rethrow as {@link PromptApiError}. Otherwise rethrow the
 * original error untouched — 401/redirect-to-login paths and 5xx
 * notifications must keep the existing `ApiClientError` semantics.
 */
function rethrowAsPromptError(err: unknown): never {
  if (err instanceof ApiClientError && err.code && isPromptErrorCode(err.code)) {
    throw new PromptApiError({
      message: err.message,
      code: err.code,
      httpStatus: err.status,
      details: err.details,
    });
  }
  throw err;
}

/**
 * Run `fn`; convert any structured prompts error to {@link PromptApiError}.
 */
async function withPromptErrorMapping<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    rethrowAsPromptError(err);
  }
}

// ---------------------------------------------------------------------------
// Response shapes (mirrors design.md > Components and Interfaces > API)
// ---------------------------------------------------------------------------

/** One row of the `GET /prompts` list response. */
export interface PromptListItem {
  promptKey: PromptKey;
  name: string;
  category: string;
  description: string;
  defaultModelKey: ModelKey;
  currentModelKey: ModelKey;
  defaultModelDisplayName: string;
  currentModelDisplayName: string;
  /** ISO 8601 UTC; null when the prompt has never been overridden. */
  lastModifiedAt: string | null;
  /** Cognito subject of the last editor; null when never overridden. */
  lastModifiedBy: string | null;
  /**
   * Optional human-readable email of the last editor — populated by
   * the backend from the request's `X-User-Email` header at
   * write time. The Prompts table prefers this over
   * {@link lastModifiedBy} for display. Absent for rows persisted
   * before the field existed and for callers (e.g. M2M clients) that
   * did not supply the header.
   */
  lastModifiedByEmail?: string;
  /** Override version. `0` when no override has ever been written. */
  version: number;
  isOverridden: boolean;
}

export interface ListPromptsResponse {
  prompts: PromptListItem[];
}

/** One entry in the `allowedModels[]` array of a `GetPromptResponse`. */
export interface AllowedModelEntry {
  modelKey: ModelKey;
  displayName: string;
  inferenceProfileId: string;
  vendor: 'anthropic' | 'amazon';
  capabilityProfileKey: string;
  capabilityProfile: {
    acceptsTopLevel: string[];
    acceptsAdditional: string[];
    forbids: string[];
    numericRanges: Record<string, { min: number; max: number }>;
  };
}

/** Full prompt detail returned by `GET /prompts/{promptKey}`. */
export interface GetPromptResponse {
  promptKey: PromptKey;
  name: string;
  description: string;
  category: string;
  /** Bundled-in registry default text. */
  defaultText: string;
  /** `override.text ?? defaultText` — what the platform actually sends. */
  effectiveText: string;
  defaultModelKey: ModelKey;
  currentModelKey: ModelKey;
  inferenceParameters: Record<string, unknown>;
  inferenceParameterSchema: Record<string, InferenceParameterSchema>;
  placeholders: Placeholder[];
  allowedModels: AllowedModelEntry[];
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;
  /** See {@link PromptListItem.lastModifiedByEmail}. */
  lastModifiedByEmail?: string;
  version: number;
  isOverridden: boolean;
}

/** Body accepted by `PUT /prompts/{promptKey}`. Sparse — supply only what changes. */
export interface UpdatePromptRequest {
  text?: string;
  modelKey?: ModelKey;
  inferenceParameters?: Record<string, unknown>;
}

/** 200 response from `PUT /prompts/{promptKey}`. */
export interface UpdatePromptResponse {
  promptKey: PromptKey;
  version: number;
  lastModifiedAt: string;
  lastModifiedBy: string;
}

/** 200 response from `POST /prompts/{promptKey}/reset`. */
export interface ResetPromptResponse {
  promptKey: PromptKey;
  /** Always `0` — reset clears the override. */
  version: 0;
  resetAt: string;
}

/** One row of the `GET /prompts/{promptKey}/history` response. */
export interface HistoryEntry {
  version: number;
  text: string;
  modelKey: ModelKey;
  inferenceParameters: Record<string, unknown>;
  modifiedAt: string;
  modifiedBy: string;
  /**
   * Optional human-readable email of whoever made this historical
   * edit. Forwarded by the backend from the prior override row's
   * `lastModifiedByEmail`. Absent on snapshots whose prior override
   * predates the field. The history panel prefers this over
   * {@link modifiedBy} for the "Modified by" cell.
   */
  modifiedByEmail?: string;
  changeKind: 'edit' | 'reset';
}

export interface GetHistoryResponse {
  history: HistoryEntry[];
}

/** 200 response from `GET /prompts/active-runs`. */
export interface ActiveRunsResponse {
  /** Number of runs whose status is `running` OR `pending` (R16.5). */
  count: number;
}

// ---------------------------------------------------------------------------
// API surface
// ---------------------------------------------------------------------------

/**
 * `GET /prompts` — list every prompt in the registry layered with the
 * live override snapshot. Sorted by `category` then `name` ascending
 * (R2.2). Response intentionally omits `defaultText`/`overrideText`
 * bodies (R2.4); use {@link getPrompt} to fetch the full detail.
 */
export function listPrompts(): Promise<ListPromptsResponse> {
  return withPromptErrorMapping(() =>
    apiClient.get<ListPromptsResponse>('/prompts'),
  );
}

/**
 * `GET /prompts/{promptKey}` — read one prompt's full detail, including
 * `defaultText`, `effectiveText`, `placeholders[]`, `allowedModels[]`,
 * and the resolved model's capability profile.
 */
export function getPrompt(promptKey: PromptKey): Promise<GetPromptResponse> {
  return withPromptErrorMapping(() =>
    apiClient.get<GetPromptResponse>(`/prompts/${encodeURIComponent(promptKey)}`),
  );
}

/**
 * `PUT /prompts/{promptKey}` — persist a prompt override. Body is
 * sparse: any subset of `text`, `modelKey`, `inferenceParameters` may
 * be supplied. The backend runs the validation pipeline in strict
 * order; the first failing stage surfaces as a {@link PromptApiError}
 * with the corresponding {@link PromptErrorCode}.
 */
export function updatePrompt(
  promptKey: PromptKey,
  body: UpdatePromptRequest,
): Promise<UpdatePromptResponse> {
  return withPromptErrorMapping(() =>
    apiClient.put<UpdatePromptResponse>(
      `/prompts/${encodeURIComponent(promptKey)}`,
      body,
    ),
  );
}

/**
 * `POST /prompts/{promptKey}/reset` — revert a prompt to its bundled
 * default. The wrapper sends `{ confirm: true }` automatically so the
 * caller cannot accidentally trip the `RESET_CONFIRMATION_REQUIRED`
 * guard from R6.6 — confirmation is the UI's responsibility, not the
 * client's.
 *
 * Idempotent for the "no override exists" case (R6.4); a double-reset
 * leaves the prompt in the same state as a single one.
 */
export function resetPrompt(
  promptKey: PromptKey,
): Promise<ResetPromptResponse> {
  return withPromptErrorMapping(() =>
    apiClient.post<ResetPromptResponse>(
      `/prompts/${encodeURIComponent(promptKey)}/reset`,
      { confirm: true },
    ),
  );
}

/**
 * `GET /prompts/{promptKey}/history` — return the prompt's persisted
 * change history sorted by `version` descending, capped at the
 * platform's history retention bound (10 entries per R7.2). Each entry
 * carries the *effective* (default-merged) text, model, and inference
 * parameters at that version so the UI can render the historical
 * state directly.
 */
export function getHistory(
  promptKey: PromptKey,
): Promise<GetHistoryResponse> {
  return withPromptErrorMapping(() =>
    apiClient.get<GetHistoryResponse>(
      `/prompts/${encodeURIComponent(promptKey)}/history`,
    ),
  );
}

/**
 * `GET /prompts/active-runs` — return the count of test runs whose
 * `status` is `running` OR `pending` (R16.5). Polled by the Prompts
 * detail page once on mount and once before submitting an edit/reset
 * so the UI can surface the "edit will not affect this run" message.
 */
export function getActiveRuns(): Promise<ActiveRunsResponse> {
  return withPromptErrorMapping(() =>
    apiClient.get<ActiveRunsResponse>('/prompts/active-runs'),
  );
}
