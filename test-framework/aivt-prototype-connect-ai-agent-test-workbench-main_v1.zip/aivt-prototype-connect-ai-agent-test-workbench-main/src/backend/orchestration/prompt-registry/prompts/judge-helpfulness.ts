/**
 * `judge_helpfulness` — prompt for the `Builtin.Helpfulness` judge,
 * based on the AWS-published AgentCore template with a rendering-context
 * annotation added to inform the judge that `{context}` now includes
 * same-turn tool calls (Action: / Tool: lines) that fired alongside the
 * assistant reply being scored. This is a forward version bump from the
 * prior verbatim template — persisted overrides against the prior version
 * continue to resolve to their saved text.
 *
 * Placeholders are the AgentCore-defined tokens substituted by
 * `bedrock-judge-client.ts`'s `fillTemplate`:
 *
 *   - `{context}` — prior conversation turns plus same-turn tool actions
 *   - `{assistant_turn}` — the target assistant turn being evaluated
 *
 * @module backend/orchestration/prompt-registry/prompts/judge-helpfulness
 */

import { HELPFULNESS_TEMPLATE } from "../../judge-prompt-templates";
import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

export const judgeHelpfulnessPrompt: PromptDefinition = {
  promptKey: "judge_helpfulness",
  name: "Judge — Helpfulness",
  description:
    "AWS-published Builtin.Helpfulness judge prompt with rendering-context annotation. Rates a single assistant turn on the seven-level ordinal helpfulness scale (Not Helpful At All … Above And Beyond). The {context} placeholder now includes same-turn tool calls so the judge sees actions that accompanied the assistant reply.",
  category: "evaluation",
  defaultText: HELPFULNESS_TEMPLATE,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [
    {
      name: "context",
      description:
        "Prior conversation turns leading up to the assistant turn being scored, including same-turn tool actions (Action:/Tool: lines) that accompanied the reply.",
      maxOccurrences: 1,
    },
    {
      name: "assistant_turn",
      description:
        "The target assistant turn whose helpfulness is being scored.",
      maxOccurrences: 1,
    },
  ],
  literalBraceRegions: [
    {
      start: '{"properties": {"reasoning": ',
      end: '"required": ["reasoning", "score"]}',
    },
  ],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 2_048 },
  },
  defaultInferenceValues: {
    maxTokens: 2_048,
  },
};
