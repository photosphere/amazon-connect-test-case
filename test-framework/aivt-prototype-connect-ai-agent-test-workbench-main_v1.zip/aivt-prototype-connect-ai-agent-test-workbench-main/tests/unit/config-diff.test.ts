import { describe, it, expect } from "vitest";
import { diffAgentConfigs } from "../../src/shared/utils/config-diff";
import { AgentSnapshot, ToolDefinition } from "../../src/shared/types";

function makeTool(overrides: Partial<ToolDefinition> = {}): ToolDefinition {
  return {
    toolName: "defaultTool",
    toolType: "CUSTOM",
    description: "A default tool",
    inputSchema: {},
    examples: [],
    ...overrides,
  };
}

function makeSnapshot(overrides: Partial<AgentSnapshot> = {}): AgentSnapshot {
  return {
    tools: [],
    systemPrompt: "You are a helpful agent.",
    modelId: "anthropic.claude-3-haiku",
    capturedAt: "2024-01-01T00:00:00Z",
    ...overrides,
  };
}

/**
 * Builds a tool fixture WITHOUT an `examples` field, simulating a snapshot
 * persisted before the field shipped. Cast through `unknown` because the
 * type now requires `examples` at construction sites — the omission is the
 * point of the fixture (R3.3, R4.2 backward-compat coverage).
 */
function makeLegacyToolWithoutExamples(
  overrides: Partial<Omit<ToolDefinition, "examples">> = {}
): ToolDefinition {
  const base = {
    toolName: "defaultTool",
    toolType: "CUSTOM",
    description: "A default tool",
    inputSchema: {},
    ...overrides,
  };
  return base as unknown as ToolDefinition;
}

describe("diffAgentConfigs", () => {
  it("returns no changes for identical snapshots", () => {
    const snapshot = makeSnapshot({
      tools: [makeTool({ toolName: "lookup" })],
    });

    const result = diffAgentConfigs(snapshot, snapshot);
    expect(result.hasChanges).toBe(false);
    expect(result.changes).toHaveLength(0);
  });

  it("detects tool added in second snapshot", () => {
    const snapshotA = makeSnapshot({ tools: [] });
    const snapshotB = makeSnapshot({
      tools: [makeTool({ toolName: "newTool", description: "A new tool" })],
    });

    const result = diffAgentConfigs(snapshotA, snapshotB);
    expect(result.hasChanges).toBe(true);
    expect(result.changes).toHaveLength(1);
    expect(result.changes[0].changeType).toBe("tool-added");
    expect(result.changes[0].toolName).toBe("newTool");
  });

  it("detects tool removed from first snapshot", () => {
    const snapshotA = makeSnapshot({
      tools: [makeTool({ toolName: "oldTool" })],
    });
    const snapshotB = makeSnapshot({ tools: [] });

    const result = diffAgentConfigs(snapshotA, snapshotB);
    expect(result.hasChanges).toBe(true);
    expect(result.changes).toHaveLength(1);
    expect(result.changes[0].changeType).toBe("tool-removed");
    expect(result.changes[0].toolName).toBe("oldTool");
  });

  it("detects tool with modified description", () => {
    const snapshotA = makeSnapshot({
      tools: [makeTool({ toolName: "tool1", description: "Original desc" })],
    });
    const snapshotB = makeSnapshot({
      tools: [makeTool({ toolName: "tool1", description: "Updated desc" })],
    });

    const result = diffAgentConfigs(snapshotA, snapshotB);
    expect(result.hasChanges).toBe(true);
    expect(result.changes).toHaveLength(1);
    expect(result.changes[0].changeType).toBe("tool-modified");
    expect(result.changes[0].toolName).toBe("tool1");
    expect(result.changes[0].detail).toContain("description");
  });

  it("detects tool with modified instruction", () => {
    const snapshotA = makeSnapshot({
      tools: [
        makeTool({ toolName: "tool1", instruction: "Do this" }),
      ],
    });
    const snapshotB = makeSnapshot({
      tools: [
        makeTool({ toolName: "tool1", instruction: "Do that instead" }),
      ],
    });

    const result = diffAgentConfigs(snapshotA, snapshotB);
    expect(result.hasChanges).toBe(true);
    expect(result.changes[0].changeType).toBe("tool-modified");
    expect(result.changes[0].detail).toContain("instruction");
  });

  it("detects system prompt change", () => {
    const snapshotA = makeSnapshot({ systemPrompt: "You are helpful." });
    const snapshotB = makeSnapshot({ systemPrompt: "You are very helpful." });

    const result = diffAgentConfigs(snapshotA, snapshotB);
    expect(result.hasChanges).toBe(true);
    const promptChange = result.changes.find(
      (c) => c.changeType === "system-prompt-changed"
    );
    expect(promptChange).toBeDefined();
  });

  it("detects model ID change", () => {
    const snapshotA = makeSnapshot({ modelId: "anthropic.claude-3-haiku" });
    const snapshotB = makeSnapshot({ modelId: "anthropic.claude-3-sonnet" });

    const result = diffAgentConfigs(snapshotA, snapshotB);
    expect(result.hasChanges).toBe(true);
    const modelChange = result.changes.find(
      (c) => c.changeType === "model-changed"
    );
    expect(modelChange).toBeDefined();
    expect(modelChange!.detail).toContain("claude-3-haiku");
    expect(modelChange!.detail).toContain("claude-3-sonnet");
  });

  it("detects multiple changes simultaneously", () => {
    const snapshotA = makeSnapshot({
      tools: [makeTool({ toolName: "keep" }), makeTool({ toolName: "remove" })],
      systemPrompt: "Original",
      modelId: "model-a",
    });
    const snapshotB = makeSnapshot({
      tools: [makeTool({ toolName: "keep" }), makeTool({ toolName: "added" })],
      systemPrompt: "Changed",
      modelId: "model-b",
    });

    const result = diffAgentConfigs(snapshotA, snapshotB);
    expect(result.hasChanges).toBe(true);
    // tool-added, tool-removed, system-prompt-changed, model-changed
    expect(result.changes.length).toBe(4);
  });

  it("does not flag tools as modified when only inputSchema differs", () => {
    const snapshotA = makeSnapshot({
      tools: [
        makeTool({ toolName: "tool1", inputSchema: { type: "object" } }),
      ],
    });
    const snapshotB = makeSnapshot({
      tools: [
        makeTool({
          toolName: "tool1",
          inputSchema: { type: "object", properties: { foo: {} } },
        }),
      ],
    });

    const result = diffAgentConfigs(snapshotA, snapshotB);
    // Per spec: only description and instruction changes are flagged
    expect(result.hasChanges).toBe(false);
  });

  // ---------------------------------------------------------------------
  // tool-examples-changed coverage (R3.3, R4.1, R4.2, R4.4)
  // ---------------------------------------------------------------------

  describe("tool-examples-changed change type", () => {
    it("emits no record when both tools have identical examples", () => {
      const examples = ["What is the order status?", "Where is my package?"];
      const snapshotA = makeSnapshot({
        tools: [makeTool({ toolName: "lookup", examples: [...examples] })],
      });
      const snapshotB = makeSnapshot({
        tools: [makeTool({ toolName: "lookup", examples: [...examples] })],
      });

      const result = diffAgentConfigs(snapshotA, snapshotB);
      expect(result.hasChanges).toBe(false);
      expect(
        result.changes.find((c) => c.changeType === "tool-examples-changed")
      ).toBeUndefined();
    });

    it("emits a tool-examples-changed record when an example is added", () => {
      const snapshotA = makeSnapshot({
        tools: [
          makeTool({ toolName: "lookup", examples: ["Where is my order?"] }),
        ],
      });
      const snapshotB = makeSnapshot({
        tools: [
          makeTool({
            toolName: "lookup",
            examples: ["Where is my order?", "What is the ETA?"],
          }),
        ],
      });

      const result = diffAgentConfigs(snapshotA, snapshotB);
      expect(result.hasChanges).toBe(true);
      const change = result.changes.find(
        (c) => c.changeType === "tool-examples-changed"
      );
      expect(change).toBeDefined();
      expect(change!.toolName).toBe("lookup");
      expect(change!.priorExamples).toEqual(["Where is my order?"]);
      expect(change!.newExamples).toEqual([
        "Where is my order?",
        "What is the ETA?",
      ]);
      // No tool-modified record when only examples changed.
      expect(
        result.changes.find((c) => c.changeType === "tool-modified")
      ).toBeUndefined();
    });

    it("emits a tool-examples-changed record when an example is removed", () => {
      const snapshotA = makeSnapshot({
        tools: [
          makeTool({
            toolName: "lookup",
            examples: ["Where is my order?", "What is the ETA?"],
          }),
        ],
      });
      const snapshotB = makeSnapshot({
        tools: [
          makeTool({ toolName: "lookup", examples: ["Where is my order?"] }),
        ],
      });

      const result = diffAgentConfigs(snapshotA, snapshotB);
      expect(result.hasChanges).toBe(true);
      const change = result.changes.find(
        (c) => c.changeType === "tool-examples-changed"
      );
      expect(change).toBeDefined();
      expect(change!.toolName).toBe("lookup");
      expect(change!.priorExamples).toEqual([
        "Where is my order?",
        "What is the ETA?",
      ]);
      expect(change!.newExamples).toEqual(["Where is my order?"]);
    });

    it("emits a tool-examples-changed record when the same set is reordered", () => {
      const snapshotA = makeSnapshot({
        tools: [
          makeTool({
            toolName: "lookup",
            examples: ["a", "b", "c"],
          }),
        ],
      });
      const snapshotB = makeSnapshot({
        tools: [
          makeTool({
            toolName: "lookup",
            examples: ["c", "b", "a"],
          }),
        ],
      });

      const result = diffAgentConfigs(snapshotA, snapshotB);
      expect(result.hasChanges).toBe(true);
      const change = result.changes.find(
        (c) => c.changeType === "tool-examples-changed"
      );
      expect(change).toBeDefined();
      expect(change!.priorExamples).toEqual(["a", "b", "c"]);
      expect(change!.newExamples).toEqual(["c", "b", "a"]);
    });

    it("emits no record when one snapshot is missing the examples field and the other is []", () => {
      // Backward-compat per R3.3 and R4.2: a pre-feature snapshot (no
      // `examples` key) diffed against a post-feature snapshot whose tool
      // has `examples: []` MUST collapse both sides to [] and emit nothing.
      const snapshotA = makeSnapshot({
        tools: [makeLegacyToolWithoutExamples({ toolName: "lookup" })],
      });
      const snapshotB = makeSnapshot({
        tools: [makeTool({ toolName: "lookup", examples: [] })],
      });

      const resultForward = diffAgentConfigs(snapshotA, snapshotB);
      expect(resultForward.hasChanges).toBe(false);
      expect(
        resultForward.changes.find(
          (c) => c.changeType === "tool-examples-changed"
        )
      ).toBeUndefined();

      // Reverse direction must also produce no record.
      const resultReverse = diffAgentConfigs(snapshotB, snapshotA);
      expect(resultReverse.hasChanges).toBe(false);
      expect(
        resultReverse.changes.find(
          (c) => c.changeType === "tool-examples-changed"
        )
      ).toBeUndefined();
    });

    it("emits both tool-modified and tool-examples-changed when description and examples both change", () => {
      const snapshotA = makeSnapshot({
        tools: [
          makeTool({
            toolName: "lookup",
            description: "Original description",
            examples: ["one"],
          }),
        ],
      });
      const snapshotB = makeSnapshot({
        tools: [
          makeTool({
            toolName: "lookup",
            description: "Updated description",
            examples: ["one", "two"],
          }),
        ],
      });

      const result = diffAgentConfigs(snapshotA, snapshotB);
      expect(result.hasChanges).toBe(true);

      const modified = result.changes.find(
        (c) => c.changeType === "tool-modified"
      );
      expect(modified).toBeDefined();
      expect(modified!.toolName).toBe("lookup");
      expect(modified!.detail).toContain("description");

      const examplesChanged = result.changes.find(
        (c) => c.changeType === "tool-examples-changed"
      );
      expect(examplesChanged).toBeDefined();
      expect(examplesChanged!.toolName).toBe("lookup");
      expect(examplesChanged!.priorExamples).toEqual(["one"]);
      expect(examplesChanged!.newExamples).toEqual(["one", "two"]);
    });

    it("emits only tool-modified when description changes but examples are unchanged", () => {
      // R4.4: a tool whose description changed but whose examples array is
      // element-wise equal MUST produce a tool-modified record and no
      // tool-examples-changed record.
      const examples = ["sample one", "sample two"];
      const snapshotA = makeSnapshot({
        tools: [
          makeTool({
            toolName: "lookup",
            description: "Original description",
            examples: [...examples],
          }),
        ],
      });
      const snapshotB = makeSnapshot({
        tools: [
          makeTool({
            toolName: "lookup",
            description: "Updated description",
            examples: [...examples],
          }),
        ],
      });

      const result = diffAgentConfigs(snapshotA, snapshotB);
      expect(result.hasChanges).toBe(true);
      expect(result.changes).toHaveLength(1);
      expect(result.changes[0].changeType).toBe("tool-modified");
      expect(
        result.changes.find((c) => c.changeType === "tool-examples-changed")
      ).toBeUndefined();
    });
  });
});
