import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import Container from '@cloudscape-design/components/container';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import Alert from '@cloudscape-design/components/alert';
import StatusIndicator from '@cloudscape-design/components/status-indicator';
import Table, { type TableProps } from '@cloudscape-design/components/table';
import Spinner from '@cloudscape-design/components/spinner';
import Pagination from '@cloudscape-design/components/pagination';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import Tabs from '@cloudscape-design/components/tabs';
import Select, { type SelectProps } from '@cloudscape-design/components/select';
import Badge from '@cloudscape-design/components/badge';
import { apiClient, ApiClientError } from '../api';
import type { TestRun, TestCaseResult, TestSuite, AgentSnapshot } from '../../../shared/types';
import { RunStatus, CaseStatus } from '../../../shared/enums';
import { compareRuns, type ComparisonEntry } from '../../../shared/utils/run-comparison';
import { ComparisonSummary } from './ComparisonSummary';
import {
  compareScores,
  METRIC_KEYS,
  type CaseScoreComparison,
  type DeltaClass,
  type MetricDelta,
  type MetricKey,
  type ScoreComparisonResult,
} from '../../../shared/utils/score-comparison';
import { diffAgentConfigs, type ConfigChange } from '../../../shared/utils/config-diff';
import { formatDurationMs } from '../../../shared/utils/time-formatting';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface ListSuitesResponse {
  suites: TestSuite[];
}

interface ListRunsResponse {
  runs: TestRun[];
  nextToken?: string;
}

interface RunDetailResponse {
  run: TestRun;
  progress: {
    totalCases: number;
    completed: number;
    passed: number;
    failed: number;
    errors: number;
    accuracy: number;
  };
  results: TestCaseResult[];
}

interface RunSnapshotResponse {
  snapshot: AgentSnapshot;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const PAGE_SIZE = 50;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function runStatusIndicator(status: RunStatus) {
  switch (status) {
    case RunStatus.RUNNING:
      return <StatusIndicator type="in-progress">Running</StatusIndicator>;
    case RunStatus.COMPLETED:
      return <StatusIndicator type="success">Completed</StatusIndicator>;
    case RunStatus.FAILED:
      return <StatusIndicator type="error">Failed</StatusIndicator>;
    case RunStatus.ABORTED:
      return <StatusIndicator type="stopped">Aborted</StatusIndicator>;
    default:
      return <StatusIndicator type="info">{status}</StatusIndicator>;
  }
}

function caseStatusBadge(status: CaseStatus | undefined) {
  if (!status) return <Badge color="grey">—</Badge>;
  switch (status) {
    case CaseStatus.PASSED:
      return <Badge color="green">Passed</Badge>;
    case CaseStatus.FAILED:
      return <Badge color="red">Failed</Badge>;
    case CaseStatus.ERROR:
      return <Badge color="grey">Error</Badge>;
    case CaseStatus.TIMED_OUT:
      return <Badge color="grey">Timed Out</Badge>;
    default:
      return <Badge color="grey">{status}</Badge>;
  }
}

function statusChangeIndicator(entry: ComparisonEntry) {
  switch (entry.category) {
    case 'status-changed':
      return (
        <SpaceBetween direction="horizontal" size="xxs">
          {caseStatusBadge(entry.previousStatus)}
          <Box variant="small">→</Box>
          {caseStatusBadge(entry.currentStatus)}
        </SpaceBetween>
      );
    case 'added':
      return <StatusIndicator type="info">Added</StatusIndicator>;
    case 'removed':
      return <StatusIndicator type="warning">Removed</StatusIndicator>;
    case 'unchanged':
      return <StatusIndicator type="success">Unchanged</StatusIndicator>;
    default:
      return <Box>—</Box>;
  }
}

function configChangeTypeIndicator(change: ConfigChange) {
  switch (change.changeType) {
    case 'tool-added':
      return <StatusIndicator type="info">Added</StatusIndicator>;
    case 'tool-removed':
      return <StatusIndicator type="error">Removed</StatusIndicator>;
    case 'tool-modified':
      return <StatusIndicator type="warning">Modified</StatusIndicator>;
    case 'tool-examples-changed':
      // tool-examples-changed records are rendered out-of-table as side-by-side
      // cards below; they should never appear in the configChanges Table after
      // the filter applied in the config-diff tab. This branch exists only as a
      // defensive fallback so an unexpected leak still renders something useful.
      return <StatusIndicator type="warning">Examples changed</StatusIndicator>;
    case 'system-prompt-changed':
      return <StatusIndicator type="warning">Changed</StatusIndicator>;
    case 'model-changed':
      return <StatusIndicator type="warning">Changed</StatusIndicator>;
    default:
      return <StatusIndicator type="info">—</StatusIndicator>;
  }
}

// ---------------------------------------------------------------------------
// tool-examples-changed renderer (R4.3)
// ---------------------------------------------------------------------------

/**
 * Classification of a single example string within the prior/new diff.
 *
 * - `added`: present on the `new` side only. Renders with a green background
 *   (`#f2fcf3`) so additions are visually distinct.
 * - `removed`: present on the `prior` side only. Renders with a red background
 *   (`#fdf0f0`) and strike-through so deletions are visible even when the
 *   value collides with an unrelated kept item.
 * - `reordered`: present on both sides but at different indices. Renders with
 *   a yellow "order changed" badge per R4.3.
 * - `same`: present at the same index on both sides. No highlight.
 */
type ExampleItemClass = 'added' | 'removed' | 'reordered' | 'same';

/**
 * Classify `value` at `index` on `side` against the opposite array.
 *
 * Uses string membership (`includes`) for the present-in-both test and
 * `indexOf` for the same-position test. With duplicate strings within a
 * single array this gives a stable, easy-to-reason-about classification:
 * the first occurrence anchors the same-position decision and later
 * occurrences are flagged as reordered or removed. A perfect Myers-style
 * diff is overkill for the typical 3–10 item examples list this row
 * renders.
 */
function classifyExampleItem(
  value: string,
  index: number,
  side: 'prior' | 'new',
  priorArr: string[],
  newArr: string[],
): ExampleItemClass {
  const other = side === 'prior' ? newArr : priorArr;
  if (!other.includes(value)) {
    return side === 'prior' ? 'removed' : 'added';
  }
  return other.indexOf(value) === index ? 'same' : 'reordered';
}

/**
 * Render an example value with the literal placeholder `<empty>` when the
 * string is empty so empty-string deletions stay visible per the task spec.
 */
function renderExampleValue(value: string) {
  if (value === '') {
    return (
      <span
        style={{
          color: '#5f6b7a',
          fontStyle: 'italic',
        }}
      >
        &lt;empty&gt;
      </span>
    );
  }
  return (
    <pre
      style={{
        margin: 0,
        whiteSpace: 'pre-wrap',
        wordBreak: 'break-word',
        fontFamily: 'monospace',
        fontSize: '12px',
      }}
    >
      {value}
    </pre>
  );
}

/**
 * Render one side (Prior or New) of the examples diff as an ordered list with
 * per-item highlighting. Pure presentation; the upstream
 * `tool-examples-changed` change record carries the two arrays verbatim from
 * `config-diff.ts` so no further fetches happen here.
 */
function ExamplesDiffColumn({
  side,
  values,
  priorArr,
  newArr,
}: {
  side: 'prior' | 'new';
  values: string[];
  priorArr: string[];
  newArr: string[];
}) {
  if (values.length === 0) {
    return (
      <Box color="text-status-inactive">
        <span style={{ fontStyle: 'italic' }}>(no examples)</span>
      </Box>
    );
  }
  return (
    <ol style={{ margin: 0, paddingLeft: '1.25rem' }}>
      {values.map((v, i) => {
        const cls = classifyExampleItem(v, i, side, priorArr, newArr);
        const background =
          cls === 'added' ? '#f2fcf3' : cls === 'removed' ? '#fdf0f0' : 'transparent';
        const textDecoration = cls === 'removed' ? 'line-through' : 'none';
        return (
          <li
            key={`${side}-${i}-${v}`}
            style={{
              background,
              padding: '4px 6px',
              marginBottom: '2px',
              borderRadius: '3px',
              textDecoration,
            }}
          >
            <SpaceBetween direction="vertical" size="xxs">
              {renderExampleValue(v)}
              {cls === 'reordered' && (
                <Badge color="severity-medium">Order changed</Badge>
              )}
            </SpaceBetween>
          </li>
        );
      })}
    </ol>
  );
}

/**
 * Render a single `tool-examples-changed` change record as a Container with
 * the tool name in the header and a two-column body (Prior | New).
 *
 * Per-item highlighting matches R4.3:
 * - items present only in `new` get a green background
 * - items present only in `prior` get a red background and strike-through
 * - items present in both at different indices get a yellow "order changed"
 *   badge
 *
 * Empty-string examples render as the literal text `<empty>` so deletions of
 * empty strings stay visible. The diff is computed client-side from the
 * `priorExamples` and `newExamples` arrays carried on the change record; no
 * additional API call is needed.
 */
function ToolExamplesDiffRow({ change }: { change: ConfigChange }) {
  const priorArr = change.priorExamples ?? [];
  const newArr = change.newExamples ?? [];
  return (
    <Container
      header={
        <Header
          variant="h3"
          description={`Examples changed (${priorArr.length} → ${newArr.length})`}
        >
          Tool: {change.toolName ?? '(unknown)'}
        </Header>
      }
    >
      <ColumnLayout columns={2}>
        <div>
          <Box variant="awsui-key-label">Prior ({priorArr.length} examples)</Box>
          <ExamplesDiffColumn
            side="prior"
            values={priorArr}
            priorArr={priorArr}
            newArr={newArr}
          />
        </div>
        <div>
          <Box variant="awsui-key-label">New ({newArr.length} examples)</Box>
          <ExamplesDiffColumn
            side="new"
            values={newArr}
            priorArr={priorArr}
            newArr={newArr}
          />
        </div>
      </ColumnLayout>
    </Container>
  );
}

const METRIC_LABELS: Record<MetricKey, string> = {
  goalSuccessScore: 'Goal Success',
  helpfulnessScore: 'Helpfulness',
  toolAccuracyScore: 'Tool Accuracy',
};

function classificationLabel(classification: DeltaClass): string {
  switch (classification) {
    case 'improved':
      return 'Improved';
    case 'regressed':
      return 'Regressed';
    case 'unchanged':
      return 'Unchanged';
    case 'not-comparable':
      return 'Not comparable';
  }
}

function formatDelta(delta: number): string {
  // Show signed delta with three decimals so unchanged ≠ improved/regressed visually.
  const sign = delta > 0 ? '+' : delta < 0 ? '' : '±';
  return `${sign}${delta.toFixed(3)}`;
}

/**
 * Render a single metric delta cell with a color/icon-distinguished status
 * indicator. `not-comparable` is shown explicitly with a dash and label
 * (Req 15.2, 15.3).
 */
function metricDeltaCell(metricDelta: MetricDelta) {
  switch (metricDelta.classification) {
    case 'improved':
      return (
        <StatusIndicator type="success">
          {classificationLabel(metricDelta.classification)}
          {typeof metricDelta.delta === 'number' ? ` (${formatDelta(metricDelta.delta)})` : ''}
        </StatusIndicator>
      );
    case 'regressed':
      return (
        <StatusIndicator type="error">
          {classificationLabel(metricDelta.classification)}
          {typeof metricDelta.delta === 'number' ? ` (${formatDelta(metricDelta.delta)})` : ''}
        </StatusIndicator>
      );
    case 'unchanged':
      return (
        <StatusIndicator type="info">
          {classificationLabel(metricDelta.classification)}
          {typeof metricDelta.delta === 'number' ? ` (${formatDelta(metricDelta.delta)})` : ''}
        </StatusIndicator>
      );
    case 'not-comparable':
      return (
        <SpaceBetween direction="horizontal" size="xxs">
          <Box variant="small">—</Box>
          <StatusIndicator type="pending">Not comparable</StatusIndicator>
        </SpaceBetween>
      );
  }
}

function formatAccuracy(run: TestRun): string {
  if (run.totalCases === 0) return '0.0%';
  return `${((run.passed / run.totalCases) * 100).toFixed(1)}%`;
}

function formatAverageLatency(results: TestCaseResult[]): string {
  if (results.length === 0) return '—';
  const avg = results.reduce((sum, r) => sum + r.latencyMs, 0) / results.length;
  return formatDurationMs(avg);
}

// ---------------------------------------------------------------------------
// Main Component
// ---------------------------------------------------------------------------

export function Comparison() {
  const [searchParams, setSearchParams] = useSearchParams();
  const suiteIdFromUrl = searchParams.get('suiteId');
  // Accept `?runIds=A,B` so SuiteDetail can deep-link directly into the
  // comparison view with both runs prefilled. Falls back to the
  // selectable-list UX when the param is absent (the page still works
  // standalone, e.g. for the legacy /compare entry point).
  const runIdsFromUrl = (() => {
    const raw = searchParams.get('runIds');
    if (!raw) return [] as string[];
    return raw
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
  })();

  // Suite selection state
  const [suites, setSuites] = useState<TestSuite[]>([]);
  const [suitesLoading, setSuitesLoading] = useState(true);
  const [selectedSuiteOption, setSelectedSuiteOption] = useState<SelectProps.Option | null>(
    suiteIdFromUrl ? { value: suiteIdFromUrl, label: suiteIdFromUrl } : null
  );

  // Run history state
  const [runs, setRuns] = useState<TestRun[]>([]);
  const [runsLoading, setRunsLoading] = useState(false);
  const [runsError, setRunsError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // Comparison state
  const [selectedRuns, setSelectedRuns] = useState<TestRun[]>([]);
  const [comparing, setComparing] = useState(false);
  const [comparisonEntries, setComparisonEntries] = useState<ComparisonEntry[] | null>(null);
  const [scoreComparison, setScoreComparison] = useState<ScoreComparisonResult | null>(null);
  const [configChanges, setConfigChanges] = useState<ConfigChange[] | null>(null);
  const [comparisonError, setComparisonError] = useState<string | null>(null);

  // Run detail data for comparison (results + snapshots)
  const [runAResults, setRunAResults] = useState<TestCaseResult[]>([]);
  const [runBResults, setRunBResults] = useState<TestCaseResult[]>([]);

  // ---------------------------------------------------------------------------
  // Fetch suites
  // ---------------------------------------------------------------------------

  const fetchSuites = useCallback(async () => {
    setSuitesLoading(true);
    try {
      const response = await apiClient.get<ListSuitesResponse>('/suites');
      setSuites(response.suites);
      // Update selected suite option label if we have a suiteId from URL
      if (suiteIdFromUrl) {
        const matchedSuite = response.suites.find((s) => s.suiteId === suiteIdFromUrl);
        if (matchedSuite) {
          setSelectedSuiteOption({ value: matchedSuite.suiteId, label: matchedSuite.name });
        }
      }
    } catch (err) {
      // Silently handle — suites list is non-critical
      console.error('Failed to fetch suites:', err);
    } finally {
      setSuitesLoading(false);
    }
  }, [suiteIdFromUrl]);

  useEffect(() => {
    fetchSuites();
  }, [fetchSuites]);

  // ---------------------------------------------------------------------------
  // Fetch run history for selected suite
  // ---------------------------------------------------------------------------

  const fetchRuns = useCallback(async (suiteId: string, page: number) => {
    setRunsLoading(true);
    setRunsError(null);
    try {
      const response = await apiClient.get<ListRunsResponse>(
        `/suites/${suiteId}/runs?limit=${PAGE_SIZE}&page=${page}`
      );
      setRuns(response.runs);
      // Estimate total pages based on whether there's a next token
      if (response.nextToken) {
        setTotalPages(Math.max(totalPages, page + 1));
      } else {
        setTotalPages(page);
      }
    } catch (err) {
      if (err instanceof ApiClientError) {
        setRunsError(err.message);
      } else {
        setRunsError('Failed to load run history.');
      }
      setRuns([]);
    } finally {
      setRunsLoading(false);
    }
  }, [totalPages]);

  // Fetch runs when suite changes
  useEffect(() => {
    const suiteId = selectedSuiteOption?.value;
    if (suiteId) {
      setSelectedRuns([]);
      setComparisonEntries(null);
      setScoreComparison(null);
      setConfigChanges(null);
      setCurrentPage(1);
      fetchRuns(suiteId, 1);
    } else {
      setRuns([]);
    }
  }, [selectedSuiteOption?.value, fetchRuns]);

  // Deep-link auto-compare: when the URL carries `?runIds=A,B` and the
  // runs list arrives, prefill the selection and immediately trigger the
  // comparison. Tracked by a ref so a subsequent edit to the selection
  // doesn't re-trigger it. Honors the contract that exactly two runs
  // must be present in the list — if either is missing (paginated past,
  // wrong suite, deleted) the page falls back to manual selection mode
  // and surfaces an inline note.
  const autoCompareDoneRef = useRef(false);
  const [autoCompareWarning, setAutoCompareWarning] = useState<string | null>(
    null,
  );
  useEffect(() => {
    if (autoCompareDoneRef.current) return;
    if (runIdsFromUrl.length !== 2) return;
    if (runs.length === 0) return;
    const [aId, bId] = runIdsFromUrl;
    const a = runs.find((r) => r.runId === aId);
    const b = runs.find((r) => r.runId === bId);
    if (!a || !b) {
      // Don't try across pages — surface an actionable warning so the
      // user can pick manually.
      setAutoCompareWarning(
        `Could not find ${[!a && aId, !b && bId].filter(Boolean).join(' and ')} ` +
          'in the current run history page. Pick the runs manually.',
      );
      autoCompareDoneRef.current = true;
      return;
    }
    autoCompareDoneRef.current = true;
    setSelectedRuns([a, b]);
    // Defer to the next tick so React has a chance to commit the selection
    // before handleCompare reads it.
    setTimeout(() => {
      void handleCompare(a, b);
    }, 0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runs.length]);

  // ---------------------------------------------------------------------------
  // Handle suite selection
  // ---------------------------------------------------------------------------

  const handleSuiteChange = (option: SelectProps.Option | null) => {
    setSelectedSuiteOption(option);
    if (option?.value) {
      setSearchParams({ suiteId: option.value });
    } else {
      setSearchParams({});
    }
  };

  // ---------------------------------------------------------------------------
  // Handle pagination
  // ---------------------------------------------------------------------------

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    const suiteId = selectedSuiteOption?.value;
    if (suiteId) {
      fetchRuns(suiteId, page);
    }
  };

  // ---------------------------------------------------------------------------
  // Handle run selection for comparison
  // ---------------------------------------------------------------------------

  const handleRunSelectionChange: TableProps['onSelectionChange'] = (event) => {
    const items = event.detail.selectedItems as TestRun[];
    if (items.length <= 2) {
      setSelectedRuns(items);
    }
  };

  // ---------------------------------------------------------------------------
  // Perform comparison
  // ---------------------------------------------------------------------------

  /**
   * Run the comparison. Optionally accepts an explicit (runA, runB) pair
   * so the deep-link auto-compare path can fire without waiting for
   * `setSelectedRuns(...)` to commit. When called with no arguments
   * (the manual "Compare selected runs" button), reads from the
   * `selectedRuns` state and validates the count.
   */
  const handleCompare = async (
    explicitA?: TestRun,
    explicitB?: TestRun,
  ) => {
    const pair = explicitA && explicitB ? [explicitA, explicitB] : selectedRuns;
    if (pair.length !== 2) return;

    setComparing(true);
    setComparisonError(null);
    setComparisonEntries(null);
    setScoreComparison(null);
    setConfigChanges(null);

    // Sort runs by start time so earlier run = A, later run = B
    const sorted = [...pair].sort(
      (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
    );
    const runA = sorted[0];
    const runB = sorted[1];

    try {
      // Fetch results and snapshots for both runs in parallel
      const [detailA, detailB, snapshotA, snapshotB] = await Promise.all([
        apiClient.get<RunDetailResponse>(`/runs/${runA.runId}`),
        apiClient.get<RunDetailResponse>(`/runs/${runB.runId}`),
        apiClient.get<RunSnapshotResponse>(`/runs/${runA.runId}/snapshot`).catch(() => null),
        apiClient.get<RunSnapshotResponse>(`/runs/${runB.runId}/snapshot`).catch(() => null),
      ]);

      // Compare results
      const comparison = compareRuns(detailA.results, detailB.results);
      setComparisonEntries(comparison.entries);
      setRunAResults(detailA.results);
      setRunBResults(detailB.results);

      // Compare per-metric evaluation scores (Reqs 15.1, 15.2, 15.3, 15.4)
      const scores = compareScores(detailA.results, detailB.results);
      setScoreComparison(scores);

      // Compare configurations if snapshots available
      if (snapshotA?.snapshot && snapshotB?.snapshot) {
        const diff = diffAgentConfigs(snapshotA.snapshot, snapshotB.snapshot);
        setConfigChanges(diff.changes);
      } else {
        setConfigChanges([]);
      }
    } catch (err) {
      if (err instanceof ApiClientError) {
        setComparisonError(err.message);
      } else {
        setComparisonError('Failed to load comparison data.');
      }
    } finally {
      setComparing(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Run history table columns
  // ---------------------------------------------------------------------------

  const runColumnDefinitions: TableProps.ColumnDefinition<TestRun>[] = [
    {
      id: 'startTime',
      header: 'Run Time',
      cell: (item) => new Date(item.startTime).toLocaleString(),
      sortingField: 'startTime',
    },
    {
      id: 'status',
      header: 'Status',
      cell: (item) => runStatusIndicator(item.status),
    },
    {
      id: 'accuracy',
      header: 'Accuracy',
      cell: (item) => formatAccuracy(item),
    },
    {
      id: 'passRate',
      header: 'Pass Rate',
      cell: (item) =>
        item.totalCases > 0
          ? `${item.passed}/${item.totalCases}`
          : '—',
    },
    {
      id: 'totalCases',
      header: 'Total Cases',
      cell: (item) => item.totalCases,
    },
    {
      id: 'runId',
      header: 'Run ID',
      cell: (item) => (
        <Box variant="code" fontSize="body-s">
          {item.runId.slice(0, 12)}...
        </Box>
      ),
    },
  ];

  // ---------------------------------------------------------------------------
  // Comparison table columns
  // ---------------------------------------------------------------------------

  const comparisonColumnDefinitions: TableProps.ColumnDefinition<ComparisonEntry>[] = [
    {
      id: 'caseId',
      header: 'Test Case',
      cell: (item) => (
        <Box variant="code" fontSize="body-s">
          {item.caseId}
        </Box>
      ),
    },
    {
      id: 'category',
      header: 'Change',
      cell: (item) => statusChangeIndicator(item),
    },
    {
      id: 'previousStatus',
      header: 'Run A Status',
      cell: (item) => caseStatusBadge(item.previousStatus),
    },
    {
      id: 'currentStatus',
      header: 'Run B Status',
      cell: (item) => caseStatusBadge(item.currentStatus),
    },
  ];

  // ---------------------------------------------------------------------------
  // Score-delta table columns (per Reqs 15.2, 15.3)
  // ---------------------------------------------------------------------------

  const scoreDeltaColumnDefinitions: TableProps.ColumnDefinition<CaseScoreComparison>[] = [
    {
      id: 'caseId',
      header: 'Test Case',
      cell: (item) => (
        <Box variant="code" fontSize="body-s">
          {item.caseId}
        </Box>
      ),
    },
    ...METRIC_KEYS.map<TableProps.ColumnDefinition<CaseScoreComparison>>((metric) => ({
      id: metric,
      header: METRIC_LABELS[metric],
      cell: (item) => metricDeltaCell(item.metrics[metric]),
    })),
  ];

  // ---------------------------------------------------------------------------
  // Config diff table columns
  // ---------------------------------------------------------------------------

  const configDiffColumnDefinitions: TableProps.ColumnDefinition<ConfigChange>[] = [
    {
      id: 'changeType',
      header: 'Change Type',
      cell: (item) => configChangeTypeIndicator(item),
    },
    {
      id: 'component',
      header: 'Component',
      cell: (item) => {
        if (item.toolName) return `Tool: ${item.toolName}`;
        if (item.changeType === 'system-prompt-changed') return 'System Prompt';
        if (item.changeType === 'model-changed') return 'Model';
        return '—';
      },
    },
    {
      id: 'detail',
      header: 'Detail',
      cell: (item) => item.detail,
    },
  ];

  // ---------------------------------------------------------------------------
  // Suite options for Select
  // ---------------------------------------------------------------------------

  const suiteOptions: SelectProps.Options = suites.map((s) => ({
    value: s.suiteId,
    label: s.name,
    description: s.description || undefined,
  }));

  // ---------------------------------------------------------------------------
  // Comparison summary
  // ---------------------------------------------------------------------------

  const comparisonSummary = comparisonEntries
    ? {
        unchanged: comparisonEntries.filter((e) => e.category === 'unchanged').length,
        statusChanged: comparisonEntries.filter((e) => e.category === 'status-changed').length,
        added: comparisonEntries.filter((e) => e.category === 'added').length,
        removed: comparisonEntries.filter((e) => e.category === 'removed').length,
      }
    : null;

  // Sort comparison entries: status-changed first, then added, removed, unchanged
  const sortedComparisonEntries = comparisonEntries
    ? [...comparisonEntries].sort((a, b) => {
        const priority: Record<string, number> = {
          'status-changed': 0,
          added: 1,
          removed: 2,
          unchanged: 3,
        };
        return (priority[a.category] ?? 99) - (priority[b.category] ?? 99);
      })
    : [];

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  return (
    <ContentLayout
      header={
        <Header variant="h1" description="Compare test runs to detect regressions">
          Historical Comparison
        </Header>
      }
    >
      <SpaceBetween size="l">
        {/* Suite Selector */}
        <Container header={<Header variant="h2">Select Test Suite</Header>}>
          <Select
            selectedOption={selectedSuiteOption}
            onChange={({ detail }) => handleSuiteChange(detail.selectedOption)}
            options={suiteOptions}
            placeholder="Choose a test suite"
            loadingText="Loading suites..."
            statusType={suitesLoading ? 'loading' : 'finished'}
            filteringType="auto"
            empty="No suites available"
          />
        </Container>

        {/* Run History */}
        {selectedSuiteOption?.value && (
          <Container
            header={
              <Header
                variant="h2"
                description="Select two runs to compare"
                actions={
                  <Button
                    variant="primary"
                    disabled={selectedRuns.length !== 2}
                    onClick={() => {
                      void handleCompare();
                    }}
                    loading={comparing}
                  >
                    Compare selected runs
                  </Button>
                }
              >
                Run History
              </Header>
            }
          >
            <SpaceBetween size="m">
              {runsError && (
                <Alert type="error" dismissible onDismiss={() => setRunsError(null)}>
                  {runsError}
                </Alert>
              )}

              <Table
                columnDefinitions={runColumnDefinitions}
                items={runs}
                loading={runsLoading}
                loadingText="Loading run history..."
                selectionType="multi"
                selectedItems={selectedRuns}
                onSelectionChange={handleRunSelectionChange}
                isItemDisabled={(item) =>
                  selectedRuns.length >= 2 && !selectedRuns.some((r) => r.runId === item.runId)
                }
                trackBy="runId"
                variant="embedded"
                empty={
                  <Box textAlign="center" padding="l">
                    <SpaceBetween size="m">
                      <b>No runs found</b>
                      <Box variant="p" color="inherit">
                        No test runs have been recorded for this suite yet.
                      </Box>
                    </SpaceBetween>
                  </Box>
                }
              />

              <Pagination
                currentPageIndex={currentPage}
                pagesCount={totalPages}
                onChange={({ detail }) => handlePageChange(detail.currentPageIndex)}
              />
            </SpaceBetween>
          </Container>
        )}

        {/* Comparison Results */}
        {autoCompareWarning && (
          <Alert
            type="warning"
            dismissible
            onDismiss={() => setAutoCompareWarning(null)}
          >
            {autoCompareWarning}
          </Alert>
        )}
        {comparisonError && (
          <Alert type="error" dismissible onDismiss={() => setComparisonError(null)}>
            {comparisonError}
          </Alert>
        )}

        {comparing && (
          <Box textAlign="center" padding="l">
            <Spinner size="large" /> Loading comparison...
          </Box>
        )}

        {/*
          AI-generated summary panel — fires the moment the comparison
          data is ready. Rendered ABOVE the diff tables because it's the
          most-glanceable view of the comparison; the tables behind it
          are still the source of truth.

          Mounted with a `triggerKey` so two clicks on the same pair of
          runs reuse the same React state (the component re-fetches only
          when the key actually changes — see the useEffect dep on
          `triggerKey` in ComparisonSummary).
        */}
        {comparisonEntries && !comparing && selectedRuns.length === 2 && (() => {
          const sorted = [...selectedRuns].sort(
            (a, b) =>
              new Date(a.startTime).getTime() - new Date(b.startTime).getTime(),
          );
          const earlier = sorted[0];
          const later = sorted[1];
          return (
            <ComparisonSummary
              runIdA={earlier.runId}
              runIdB={later.runId}
              suiteId={selectedSuiteOption?.value}
              triggerKey={`${earlier.runId}|${later.runId}`}
            />
          );
        })()}

        {comparisonEntries && !comparing && (
          <Container
            header={
              <Header
                variant="h2"
                description={`Comparing run from ${new Date(selectedRuns[0]?.startTime || '').toLocaleString()} vs ${new Date(selectedRuns[1]?.startTime || '').toLocaleString()}`}
              >
                Comparison Results
              </Header>
            }
          >
            <SpaceBetween size="l">
              {/* Summary */}
              {comparisonSummary && (
                <ColumnLayout columns={4} variant="text-grid">
                  <div>
                    <Box variant="awsui-key-label">Unchanged</Box>
                    <Box variant="p" fontSize="heading-l" color="text-status-success">
                      {comparisonSummary.unchanged}
                    </Box>
                  </div>
                  <div>
                    <Box variant="awsui-key-label">Status Changed</Box>
                    <Box variant="p" fontSize="heading-l" color="text-status-error">
                      {comparisonSummary.statusChanged}
                    </Box>
                  </div>
                  <div>
                    <Box variant="awsui-key-label">Added</Box>
                    <Box variant="p" fontSize="heading-l" color="text-status-info">
                      {comparisonSummary.added}
                    </Box>
                  </div>
                  <div>
                    <Box variant="awsui-key-label">Removed</Box>
                    <Box variant="p" fontSize="heading-l" color="text-status-warning">
                      {comparisonSummary.removed}
                    </Box>
                  </div>
                </ColumnLayout>
              )}

              {/* Tabs for comparison detail and config diff */}
              <Tabs
                tabs={[
                  {
                    id: 'status-changes',
                    label: `Status Changes (${sortedComparisonEntries.length})`,
                    content: (
                      <Table
                        columnDefinitions={comparisonColumnDefinitions}
                        items={sortedComparisonEntries}
                        trackBy="caseId"
                        variant="embedded"
                        empty={
                          <Box textAlign="center" padding="l">
                            No test case differences found between the runs.
                          </Box>
                        }
                      />
                    ),
                  },
                  {
                    id: 'config-diff',
                    label: `Configuration Diff (${configChanges?.length ?? 0})`,
                    content: (
                      <SpaceBetween size="m">
                        {configChanges && configChanges.length === 0 && (
                          <Alert type="info" statusIconAriaLabel="Info">
                            No configuration changes detected between the two runs.
                          </Alert>
                        )}
                        {configChanges && configChanges.length > 0 && (() => {
                          // Split out `tool-examples-changed` records so they
                          // render as side-by-side cards below the table per
                          // R4.3. The remaining records — including
                          // `tool-modified` — feed the existing table renderer
                          // unchanged so R4.4 holds (a tool whose only
                          // difference is its examples produces only the
                          // `tool-examples-changed` record from config-diff.ts
                          // and thus only the cards row here, never a
                          // `tool-modified` row).
                          const tableChanges = configChanges.filter(
                            (c) => c.changeType !== 'tool-examples-changed',
                          );
                          const examplesChanges = configChanges.filter(
                            (c) => c.changeType === 'tool-examples-changed',
                          );
                          return (
                            <SpaceBetween size="m">
                              {tableChanges.length > 0 && (
                                <Table
                                  columnDefinitions={configDiffColumnDefinitions}
                                  items={tableChanges}
                                  trackBy={(item) =>
                                    `${item.changeType}-${item.toolName || 'config'}`
                                  }
                                  variant="embedded"
                                  empty={
                                    <Box textAlign="center" padding="l">
                                      No configuration changes found.
                                    </Box>
                                  }
                                />
                              )}
                              {examplesChanges.length > 0 && (
                                <SpaceBetween size="m">
                                  <Header variant="h3">
                                    Tool Examples Changed ({examplesChanges.length})
                                  </Header>
                                  {examplesChanges.map((change) => (
                                    <ToolExamplesDiffRow
                                      key={`examples-${change.toolName ?? 'unknown'}`}
                                      change={change}
                                    />
                                  ))}
                                </SpaceBetween>
                              )}
                            </SpaceBetween>
                          );
                        })()}
                        {configChanges === null && (
                          <Alert type="warning" statusIconAriaLabel="Warning">
                            Configuration snapshots are not available for one or both runs.
                          </Alert>
                        )}
                      </SpaceBetween>
                    ),
                  },
                  {
                    id: 'score-deltas',
                    label: `Score Deltas (${scoreComparison?.entries.length ?? 0})`,
                    content: (
                      <SpaceBetween size="l">
                        {/* Per-metric suite-level summary (Req 15.4) */}
                        {scoreComparison && (
                          <ColumnLayout columns={3} variant="text-grid">
                            {METRIC_KEYS.map((metric) => {
                              const counts = scoreComparison.summary.perMetric[metric];
                              return (
                                <div key={metric}>
                                  <Box variant="awsui-key-label">{METRIC_LABELS[metric]}</Box>
                                  <SpaceBetween size="xxs">
                                    <StatusIndicator type="success">
                                      Improved: {counts.improved}
                                    </StatusIndicator>
                                    <StatusIndicator type="error">
                                      Regressed: {counts.regressed}
                                    </StatusIndicator>
                                    <StatusIndicator type="info">
                                      Unchanged: {counts.unchanged}
                                    </StatusIndicator>
                                    <StatusIndicator type="pending">
                                      Not comparable: {counts.notComparable}
                                    </StatusIndicator>
                                  </SpaceBetween>
                                </div>
                              );
                            })}
                          </ColumnLayout>
                        )}

                        {/* Per-case per-metric deltas (Reqs 15.2, 15.3) */}
                        {scoreComparison && scoreComparison.entries.length > 0 && (
                          <Table
                            columnDefinitions={scoreDeltaColumnDefinitions}
                            items={scoreComparison.entries}
                            trackBy="caseId"
                            variant="embedded"
                          />
                        )}
                        {scoreComparison && scoreComparison.entries.length === 0 && (
                          <Alert type="info" statusIconAriaLabel="Info">
                            No test cases are present in both runs, so per-metric deltas cannot be computed.
                          </Alert>
                        )}
                      </SpaceBetween>
                    ),
                  },
                  {
                    id: 'side-by-side',
                    label: 'Side-by-Side Metrics',
                    content: (
                      <SideBySideView
                        runA={selectedRuns.sort(
                          (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
                        )[0]}
                        runB={selectedRuns.sort(
                          (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
                        )[1]}
                        resultsA={runAResults}
                        resultsB={runBResults}
                      />
                    ),
                  },
                ]}
              />
            </SpaceBetween>
          </Container>
        )}
      </SpaceBetween>
    </ContentLayout>
  );
}

// ---------------------------------------------------------------------------
// Side-by-Side Metrics Sub-Component
// ---------------------------------------------------------------------------

function SideBySideView({
  runA,
  runB,
  resultsA,
  resultsB,
}: {
  runA: TestRun | undefined;
  runB: TestRun | undefined;
  resultsA: TestCaseResult[];
  resultsB: TestCaseResult[];
}) {
  if (!runA || !runB) {
    return <Box padding="l">Select two runs to view side-by-side metrics.</Box>;
  }

  return (
    <ColumnLayout columns={2} variant="text-grid">
      {/* Run A */}
      <Container
        header={
          <Header variant="h3">
            Run A — {new Date(runA.startTime).toLocaleDateString()}
          </Header>
        }
      >
        <SpaceBetween size="s">
          <div>
            <Box variant="awsui-key-label">Status</Box>
            <div>{runStatusIndicator(runA.status)}</div>
          </div>
          <div>
            <Box variant="awsui-key-label">Accuracy</Box>
            <Box>{formatAccuracy(runA)}</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Pass Rate</Box>
            <Box>{runA.passed}/{runA.totalCases} passed</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Failed</Box>
            <Box color="text-status-error">{runA.failed}</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Errors</Box>
            <Box color="text-status-warning">{runA.errors}</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Avg Duration</Box>
            <Box>{formatAverageLatency(resultsA)}</Box>
          </div>
        </SpaceBetween>
      </Container>

      {/* Run B */}
      <Container
        header={
          <Header variant="h3">
            Run B — {new Date(runB.startTime).toLocaleDateString()}
          </Header>
        }
      >
        <SpaceBetween size="s">
          <div>
            <Box variant="awsui-key-label">Status</Box>
            <div>{runStatusIndicator(runB.status)}</div>
          </div>
          <div>
            <Box variant="awsui-key-label">Accuracy</Box>
            <Box>{formatAccuracy(runB)}</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Pass Rate</Box>
            <Box>{runB.passed}/{runB.totalCases} passed</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Failed</Box>
            <Box color="text-status-error">{runB.failed}</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Errors</Box>
            <Box color="text-status-warning">{runB.errors}</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Avg Duration</Box>
            <Box>{formatAverageLatency(resultsB)}</Box>
          </div>
        </SpaceBetween>
      </Container>
    </ColumnLayout>
  );
}
