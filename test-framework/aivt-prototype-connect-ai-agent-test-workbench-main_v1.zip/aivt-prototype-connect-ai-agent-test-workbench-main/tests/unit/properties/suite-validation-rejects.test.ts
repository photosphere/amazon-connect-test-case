// Feature: connect-agent-test-platform, Property 18: Suite validation rejects invalid input

import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';
import { validateTestSuite } from '@shared/validation';
import { TestSuite } from '@shared/types';

/**
 * **Validates: Requirements 4.3**
 *
 * Property 18: Suite validation rejects invalid input
 * Generate test suite inputs with missing/empty names and null/empty agentIds.
 * Verify validation returns errors identifying missing fields and never creates a record.
 */
describe('Property 18: Suite validation rejects invalid input', () => {
  const validAgentId = fc.string({ minLength: 1, maxLength: 36 }).filter(s => s.trim().length > 0);
  const validName = fc.string({ minLength: 1, maxLength: 128 }).filter(s => s.trim().length > 0);
  const whitespaceOnly = fc.stringOf(fc.constantFrom(' ', '\t', '\n'), { minLength: 1 });

  it('missing name always produces name error', () => {
    fc.assert(
      fc.property(validAgentId, (agentId) => {
        const input: Partial<TestSuite> = { agentId };
        const result = validateTestSuite(input);

        expect(result.valid).toBe(false);
        expect(result.errors.some(e => e.field === 'name')).toBe(true);
      }),
      { numRuns: 100 }
    );
  });

  it('empty/whitespace-only name always produces name error', () => {
    fc.assert(
      fc.property(whitespaceOnly, validAgentId, (name, agentId) => {
        const input: Partial<TestSuite> = { name, agentId };
        const result = validateTestSuite(input);

        expect(result.valid).toBe(false);
        expect(result.errors.some(e => e.field === 'name')).toBe(true);
      }),
      { numRuns: 100 }
    );
  });

  it('missing agentId always produces agentId error', () => {
    fc.assert(
      fc.property(validName, (name) => {
        const input: Partial<TestSuite> = { name };
        const result = validateTestSuite(input);

        expect(result.valid).toBe(false);
        expect(result.errors.some(e => e.field === 'agentId')).toBe(true);
      }),
      { numRuns: 100 }
    );
  });

  it('empty/whitespace-only agentId always produces agentId error', () => {
    fc.assert(
      fc.property(validName, whitespaceOnly, (name, agentId) => {
        const input: Partial<TestSuite> = { name, agentId };
        const result = validateTestSuite(input);

        expect(result.valid).toBe(false);
        expect(result.errors.some(e => e.field === 'agentId')).toBe(true);
      }),
      { numRuns: 100 }
    );
  });

  it('both missing name and agentId produces both errors', () => {
    fc.assert(
      fc.property(fc.record({}), () => {
        const input: Partial<TestSuite> = {};
        const result = validateTestSuite(input);

        expect(result.valid).toBe(false);
        expect(result.errors.some(e => e.field === 'name')).toBe(true);
        expect(result.errors.some(e => e.field === 'agentId')).toBe(true);
      }),
      { numRuns: 100 }
    );
  });

  it('any input with valid name and agentId (within bounds) passes regardless of other content', () => {
    const optionalDescription = fc.option(
      fc.string({ minLength: 0, maxLength: 500 }),
      { nil: undefined }
    );

    fc.assert(
      fc.property(validName, validAgentId, optionalDescription, (name, agentId, description) => {
        const input: Partial<TestSuite> = { name, agentId };
        if (description !== undefined) {
          input.description = description;
        }
        const result = validateTestSuite(input);

        expect(result.valid).toBe(true);
        expect(result.errors).toHaveLength(0);
      }),
      { numRuns: 100 }
    );
  });
});
