#!/usr/bin/env bash
# Triggers a test run against a suite by directly invoking the run-trigger
# Lambda (bypassing Cognito), then polls the run SUMMARY record until the run
# reaches a terminal status and prints a per-case summary.
#
# Usage: bash scripts/run-suite.sh [suiteId]
set -euo pipefail

SUITE_ID="${1:-266a970aa07d450a1fc7eb85}"
TENANT_ID="14b8e4d8-8041-70d3-9ba8-274c8b66c7e1"
REGION="us-east-1"
TABLE="ConnectAgentTestPlatformStack-StorageTestPlatformTableB1757843-1BFX60BQIDZF7"
RUN_FN="ConnectAgentTestPlatformStack-run-trigger"

EVENT=$(python3 -c "
import json
print(json.dumps({
  'httpMethod':'POST','resource':'/runs','pathParameters':None,
  'body':json.dumps({'suiteId':'$SUITE_ID'}),
  'requestContext':{'authorizer':{'claims':{'sub':'$TENANT_ID'}}}
}))
")

echo "Triggering run for suite $SUITE_ID ..."
aws lambda invoke --function-name "$RUN_FN" --region "$REGION" \
  --cli-binary-format raw-in-base64-out --payload "$EVENT" /tmp/run-resp.json \
  --query 'StatusCode' --output text >/dev/null

RUN_ID=$(python3 -c "import json;print(json.loads(json.load(open('/tmp/run-resp.json'))['body']).get('runId',''))")
if [ -z "$RUN_ID" ]; then echo "Failed to start run:"; cat /tmp/run-resp.json; exit 1; fi
echo "Run started: $RUN_ID"
echo "Polling SUMMARY status..."

for i in $(seq 1 80); do
  sleep 15
  aws dynamodb query --table-name "$TABLE" --region "$REGION" \
    --key-condition-expression "PK = :pk" \
    --expression-attribute-values "{\":pk\":{\"S\":\"RUN#$RUN_ID\"}}" \
    --output json 2>/dev/null > /tmp/run-cases.json
  STATUS=$(python3 -c "
import json
d=json.load(open('/tmp/run-cases.json'))
for it in d.get('Items',[]):
    if it.get('SK',{}).get('S','')=='SUMMARY':
        print(list(it.get('status',{'S':'?'}).values())[0]); break
else: print('?')
")
  CASES=$(python3 -c "
import json
d=json.load(open('/tmp/run-cases.json'))
cs=[list(it['status'].values())[0] for it in d.get('Items',[]) if it.get('SK',{}).get('S','').startswith('CASE#') and 'status' in it]
print(cs)
")
  echo "  poll $i: run status=$STATUS cases=$CASES"
  if [ "$STATUS" = "completed" ] || [ "$STATUS" = "failed" ] || [ "$STATUS" = "aborted" ]; then
    echo "Run terminal: $STATUS"
    break
  fi
done

echo ""
echo "=== Results for run $RUN_ID ==="
python3 -c "
import json
d=json.load(open('/tmp/run-cases.json'))
cases=[{k:list(v.values())[0] for k,v in it.items()} for it in d.get('Items',[]) if it.get('SK',{}).get('S','').startswith('CASE#')]
for c in sorted(cases, key=lambda x:x.get('caseId','')):
    print(f\"  {c.get('caseId','')[:12]}  status={c.get('status'):<10} turns={str(c.get('turnCount','?')):<4} tools={c.get('toolsInvoked')}\")
print(f\"  TOTAL: {len(cases)} cases | passed={sum(1 for c in cases if c.get('status')=='passed')} failed={sum(1 for c in cases if c.get('status')=='failed')} error={sum(1 for c in cases if c.get('status')=='error')} timed_out={sum(1 for c in cases if c.get('status')=='timed_out')}\")
"
echo "RUN_ID=$RUN_ID"
