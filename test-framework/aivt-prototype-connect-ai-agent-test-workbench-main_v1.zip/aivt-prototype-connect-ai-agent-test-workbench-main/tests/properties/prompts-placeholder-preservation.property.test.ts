/**
 * Property 3: Placeholder preservation.
 *
 * For any persisted Prompt — default state, post-edit, or post-reset —
 * the set of declared `placeholder.name` values is a subset of the set
 * of `{name}` tokens in the resolver's persisted `effectiveText`.
 * Equivalently: every required placeholder appears at least once in the
 * text the resolver returns, no matter what override sequence preceded
 * the resolution.
 *
 * The persisted-Prompt model used here is the one the design's "Edit
 * path" / "Run-start capture" / "Callsite invocation" sub-sections
 * commit to: an in-memory `Prompts_Store` keyed by `promptKey`, mutated
 * by two operation kinds (PUT a sparse override, RESET the override
 * away), then read by the pure {@link resolvePrompt} function. Task 5.1
 * had not landed when this test was authored, so the DDB layer is
 * mocked in-memory rather than going through `Prompts_Store` CRUD —
 * the property holds at the resolver boundary, which is the boundary
 * that matters: every Bedrock_Callsite reads the resolver's output, so
 * pinning the invariant there pins it for every callsite regardless of
 * which persistence implementation lives behind the override map.
 *
 * The resolver gives us the property "for free" in three of the four
 * states the design enumerates:
 *
 *   - **Default state.** The bundled `defaultText` contains every
 *     declared placeholder per the registry build invariants pinned by
 *     Task 2.7's `prompt-registry.test.ts`. The resolver returns
 *     `defaultText` when no override is in effect, so the property
 *     holds trivially.
 *
 *   - **Valid override (post-edit).** {@link validTextArb} only emits
 *     text bodies in which every declared placeholder appears at least
 *     once and no unknown `{name}` token is introduced. The resolver
 *     returns `override.text` for these inputs, so the property holds
 *     by construction of the generator.
 *
 *   - **Post-reset.** A reset deletes the override row; the resolver
 *     reverts to `defaultText`, the same situation as the default
 *     state.
 *
 *   - **Stale override fallback.** The resolver's stale-placeholder
 *     fallback (Invariant 2 in `resolver.ts`) replaces a sparse
 *     override missing one or more placeholders with the bundled
 *     `defaultText` for that single call. We do not generate stale
 *     overrides explicitly (the validation pipeline rejects them at
 *     the Prompts_API boundary, so they cannot persist in production),
 *     but the property still holds in this branch by the same default
 *     argument.
 *
 * Random sequences of PUT and RESET operations exercise the cross-
 * product of those branches across every registered `promptKey`. The
 * property is asserted **after every operation in the sequence** — not
 * just the final state — so a sequence that briefly violated the
 * invariant in the middle would still surface as a failure.
 *
 * Generators are the shared `promptKeyArb` and `validTextArb` from
 * `tests/properties/generators.ts`; no new arbitraries land here so the
 * valid-input distribution stays consistent across the four property
 * tests in the wave.
 *
 * **Validates: Requirements 12.2, 15.3**
 */

import fc from "fast-check";
import { describe, expect, it } from "vitest";

import {
  PROMPT_REGISTRY,
  resolvePrompt,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";
import type {
  PromptDefinition,
  PromptKey,
  PromptOverride,
} from "../../src/backend/orchestration/prompt-registry";

import {
  promptKeyArb,
  validInferenceParametersArb,
  validTextArb,
} from "./generators";

// ---------------------------------------------------------------------------
// In-memory mock of the Prompts_Store override map.
//
// The real Prompts_Store (DDB) is one row per `promptKey` at
// `PK=PROMPT#{promptKey}, SK=OVERRIDE`. The resolver reads it as a
// `ReadonlyMap<PromptKey, PromptOverride>`. We model the same shape
// here as a plain `Map`: PUT writes a sparse override; RESET deletes
// the row. Both are pure value mutations — no transaction semantics,
// no history, no audit. The property under test does not depend on
// any of those concerns, so leaving them out keeps the test fast and
// the failure modes obvious.
// ---------------------------------------------------------------------------

type Operation =
  | {
      kind: "put";
      promptKey: PromptKey;
      text: string;
      modelKey: PromptOverride["modelKey"];
      inferenceParameters: Readonly<Record<string, unknown>>;
    }
  | { kind: "reset"; promptKey: PromptKey };

/**
 * Apply one operation to the override map in-place and return the same
 * map. Returning the map (rather than `void`) lets the caller chain
 * `.reduce(...)` over an operation sequence without an explicit `let`.
 *
 * Each PUT increments a monotonic version counter — the resolver does
 * not care about the value, but mirroring the `Prompts_Store` semantics
 * keeps the test honest about how a real edit would look on the wire.
 */
function applyOperation(
  store: Map<PromptKey, PromptOverride>,
  op: Operation,
): Map<PromptKey, PromptOverride> {
  if (op.kind === "reset") {
    store.delete(op.promptKey);
    return store;
  }
  const prior = store.get(op.promptKey);
  store.set(op.promptKey, {
    promptKey: op.promptKey,
    text: op.text,
    modelKey: op.modelKey,
    inferenceParameters: op.inferenceParameters,
    version: (prior?.version ?? 0) + 1,
    lastModifiedAt: "1970-01-01T00:00:00.000Z",
    lastModifiedBy: "property-test",
  });
  return store;
}

// ---------------------------------------------------------------------------
// Property assertion helper.
//
// Pulled out so the same check is used for the bundled-defaults case,
// the single-edit case, and the random-sequence case below. Failure
// messages name the offending `promptKey` and missing placeholder so a
// counter-example reported by fast-check is immediately actionable.
// ---------------------------------------------------------------------------

function expectAllPlaceholdersPresent(
  promptKey: PromptKey,
  prompt: PromptDefinition,
  store: ReadonlyMap<PromptKey, PromptOverride>,
): void {
  const resolved = resolvePrompt(promptKey, store);
  for (const placeholder of prompt.placeholders) {
    const token = `{${placeholder.name}}`;
    expect(
      resolved.text.includes(token),
      `[${promptKey}] resolved effectiveText is missing declared placeholder ${token}`,
    ).toBe(true);
  }
}

// ---------------------------------------------------------------------------
// `Operation` arbitrary, scoped to one prompt at a time so PUT bodies
// can be generated against that prompt's placeholder schema. Building
// the per-prompt arbitraries up front (rather than chaining
// `promptKeyArb` into a per-key body draw) keeps the operation sequence
// arbitrary deterministic and lets fast-check shrink minimal sequences
// when a counter-example is found.
// ---------------------------------------------------------------------------

function operationArbForPrompt(
  promptKey: PromptKey,
  prompt: PromptDefinition,
): fc.Arbitrary<Operation> {
  // PUT body: valid text, model from `allowedModels[]`, inference
  // parameters valid for that model. The validation pipeline would
  // accept exactly this body at the Prompts_API boundary; we mirror
  // that contract so the in-memory store only ever holds overrides
  // the real system would also accept.
  const putArb: fc.Arbitrary<Operation> = fc
    .constantFrom(...prompt.allowedModels)
    .chain((modelKey) => {
      const model = SUPPORTED_MODELS[modelKey];
      return fc.tuple(
        validTextArb(prompt),
        validInferenceParametersArb(prompt, model),
      ).map(([text, inferenceParameters]) => ({
        kind: "put" as const,
        promptKey,
        text,
        modelKey,
        inferenceParameters,
      }));
    });

  const resetArb: fc.Arbitrary<Operation> = fc.constant({
    kind: "reset" as const,
    promptKey,
  });

  // 4:1 PUT-to-RESET weighting: most operations are edits (the
  // common case in production), but RESETs appear often enough that
  // sequences of length ≥ 5 reliably exercise both branches plus
  // the back-and-forth transitions between them.
  return fc.oneof(
    { weight: 4, arbitrary: putArb },
    { weight: 1, arbitrary: resetArb },
  );
}

// ---------------------------------------------------------------------------
// 1. Default state (no overrides) — sanity check the resolver against
//    the bundled defaults for every registered promptKey. The build
//    invariant from Task 2.7 already pins `defaultText` to contain
//    every placeholder; this case asserts the resolver propagates
//    that property to its caller.
// ---------------------------------------------------------------------------

describe("Property 3 — Placeholder preservation (default state)", () => {
  const promptKeys = Object.keys(PROMPT_REGISTRY) as PromptKey[];

  it.each(promptKeys)(
    "[%s] resolver returns defaultText with every declared placeholder when no override is set",
    (promptKey) => {
      const empty: ReadonlyMap<PromptKey, PromptOverride> = new Map();
      expectAllPlaceholdersPresent(
        promptKey,
        PROMPT_REGISTRY[promptKey],
        empty,
      );
    },
  );
});

// ---------------------------------------------------------------------------
// 2. Single-edit state — for every (promptKey, validText) pair, one
//    PUT followed by a resolve must return text with every declared
//    placeholder. This is the property reduced to its smallest non-
//    trivial sequence; any failure here would point at validTextArb
//    or at the resolver's default-fallback path before sequence
//    interactions could obscure the cause.
// ---------------------------------------------------------------------------

describe("Property 3 — Placeholder preservation (single edit)", () => {
  it("a single valid PUT preserves every declared placeholder for every promptKey", () => {
    fc.assert(
      fc
        .property(promptKeyArb, (promptKey) => {
          const prompt = PROMPT_REGISTRY[promptKey];
          // `chain` so the per-prompt body arbitraries see the prompt
          // we just drew. `fc.assert` does not support nested `chain`
          // off the outer property directly, hence the explicit nested
          // `fc.assert` here. (Pulling the outer arbitrary into the
          // chain keeps the shrinking machinery whole.)
          fc.assert(
            fc.property(
              fc
                .constantFrom(...prompt.allowedModels)
                .chain((modelKey) => {
                  const model = SUPPORTED_MODELS[modelKey];
                  return fc.tuple(
                    validTextArb(prompt),
                    validInferenceParametersArb(prompt, model),
                  ).map(([text, inferenceParameters]) => ({
                    text,
                    modelKey,
                    inferenceParameters,
                  }));
                }),
              ({ text, modelKey, inferenceParameters }) => {
                const store = new Map<PromptKey, PromptOverride>();
                applyOperation(store, {
                  kind: "put",
                  promptKey,
                  text,
                  modelKey,
                  inferenceParameters,
                });
                expectAllPlaceholdersPresent(promptKey, prompt, store);
              },
            ),
            { numRuns: 25 },
          );
        }),
      // Outer numRuns ≥ 8 prompts × 25 inner runs/prompt = ≥ 200 cases.
      // R15.6 requires ≥ 100 iterations; the per-prompt nested run keeps
      // every promptKey's placeholder schema exercised.
      { numRuns: 8 },
    );
  });
});

// ---------------------------------------------------------------------------
// 3. Random PUT/RESET sequences — the headline case. After every
//    operation in the sequence (not just the final state) the
//    resolver's output must satisfy the placeholder invariant.
//    Sequence length is bounded to 20 ops per iteration, matching
//    the Property 2 (reset idempotence) bound documented in the
//    design's Testing Strategy section.
// ---------------------------------------------------------------------------

describe("Property 3 — Placeholder preservation (random PUT/RESET sequences)", () => {
  it("every state along an arbitrary edit/reset sequence preserves every declared placeholder", () => {
    fc.assert(
      fc.property(
        promptKeyArb.chain((promptKey) => {
          const prompt = PROMPT_REGISTRY[promptKey];
          return fc
            .array(operationArbForPrompt(promptKey, prompt), {
              minLength: 1,
              maxLength: 20,
            })
            .map((ops) => ({ promptKey, prompt, ops }));
        }),
        ({ promptKey, prompt, ops }) => {
          const store = new Map<PromptKey, PromptOverride>();
          // Assert the property after every step, not just at the end.
          // A counter-example that only manifests in the middle of a
          // sequence is still a failure — the design's "any persisted
          // Prompt" precondition admits every intermediate state.
          for (const op of ops) {
            applyOperation(store, op);
            expectAllPlaceholdersPresent(promptKey, prompt, store);
          }
        },
      ),
      // R15.6: ≥ 100 iterations. 150 leaves headroom for fast-check's
      // shrinker without bloating CI runtime — each iteration runs ≤ 20
      // resolver calls, all of which are pure in-memory operations.
      { numRuns: 150 },
    );
  });
});
