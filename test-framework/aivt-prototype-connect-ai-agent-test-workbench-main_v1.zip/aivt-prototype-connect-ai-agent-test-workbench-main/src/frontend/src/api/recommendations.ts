/**
 * Typed Recommendations API client.
 *
 * Thin, resource-specific wrapper around {@link apiClient} that pins response
 * shapes to the contracts declared in the implement-recommendations design:
 *
 *   - `fetchRecommendations` — per-suite recommendations for a completed run
 *   - `applyRecommendations` — apply selected recommendations to the agent
 *   - `createExperiment` — start a multi-variant experiment
 *   - `getExperiment` — poll experiment status
 *   - `applyVariant` — promote a variant's changes to the real agent
 *   - `listExperiments` — list experiments for a run
 *
 * Unlike the Prompts wrapper, the recommendations layer does not need
 * error-code narrowing — the orchestrator hook handles 409 (conflict) at
 * the HTTP-status level and surfaces all other errors through the Flashbar.
 *
 * @module frontend/api/recommendations
 */

import { apiClient } from './client';
import type {
  ApplyRecommendationsResponse,
  ExperimentCreateResponse,
  ExperimentRecord,
  PerSuiteRecommendation,
} from '../../../shared/types';

// ---------------------------------------------------------------------------
// Response shapes
// ---------------------------------------------------------------------------

/** Response from POST /runs/{runId}/recommend-suite */
export interface FetchRecommendationsResponse {
  recommendations: PerSuiteRecommendation[];
  generatedAt: string;
  modelId: string;
}

/** Response from GET /runs/{runId}/experiments */
export interface ListExperimentsResponse {
  experiments: ExperimentRecord[];
}

// ---------------------------------------------------------------------------
// API surface
// ---------------------------------------------------------------------------

/**
 * `POST /runs/{runId}/recommend-suite` — fetch per-suite
 * recommendations for a completed run. Without `force: true` in the
 * body the Lambda returns persisted records (no Bedrock call).
 */
export function fetchRecommendations(
  runId: string,
  suiteId: string,
): Promise<FetchRecommendationsResponse> {
  return apiClient.post<FetchRecommendationsResponse>(
    `/runs/${runId}/recommend-suite`,
    { suiteId },
  );
}

/**
 * `POST /runs/{runId}/apply-recommendations` — apply selected
 * recommendations directly to the agent. Optionally pass `force: true`
 * to override drift conflicts.
 */
export function applyRecommendations(
  runId: string,
  agentId: string,
  recommendationIndices: number[],
  force?: boolean,
): Promise<ApplyRecommendationsResponse> {
  return apiClient.post<ApplyRecommendationsResponse>(
    `/runs/${runId}/apply-recommendations`,
    { mode: 'direct', agentId, recommendationIndices, ...(force && { force: true }) },
  );
}

/**
 * `POST /runs/{runId}/experiments` — create a multi-variant experiment
 * for the given agent.
 */
export function createExperiment(
  runId: string,
  agentId: string,
): Promise<ExperimentCreateResponse> {
  return apiClient.post<ExperimentCreateResponse>(
    `/runs/${runId}/experiments`,
    { mode: 'multi_variant', agentId },
  );
}

/**
 * `GET /runs/{runId}/experiments/{experimentId}` — get experiment
 * status and details.
 */
export function getExperiment(
  runId: string,
  experimentId: string,
): Promise<ExperimentRecord> {
  return apiClient.get<ExperimentRecord>(
    `/runs/${runId}/experiments/${experimentId}`,
  );
}

/**
 * `POST /runs/{runId}/experiments/{experimentId}/apply` — apply a
 * variant's changes to the real agent.
 */
export function applyVariant(
  runId: string,
  experimentId: string,
  variant: 'A' | 'B' | 'C',
): Promise<ApplyRecommendationsResponse> {
  return apiClient.post<ApplyRecommendationsResponse>(
    `/runs/${runId}/experiments/${experimentId}/apply`,
    { variant },
  );
}

/**
 * `GET /runs/{runId}/experiments` — list all experiments for a run.
 */
export function listExperiments(
  runId: string,
): Promise<ListExperimentsResponse> {
  return apiClient.get<ListExperimentsResponse>(
    `/runs/${runId}/experiments`,
  );
}

/**
 * `POST /runs/{runId}/revert-apply` — revert the most recent apply for a run,
 * restoring the agent's previous prompt and tool configuration.
 */
export function revertApply(
  runId: string,
): Promise<{ success: boolean; message: string; restoredPromptVersion?: string }> {
  return apiClient.post<{ success: boolean; message: string; restoredPromptVersion?: string }>(
    `/runs/${runId}/revert-apply`,
    {},
  );
}

/**
 * `GET /runs/{runId}/apply-status` — check if a run has an un-reverted apply
 * that can be rolled back.
 */
export function getApplyStatus(
  runId: string,
): Promise<{
  hasApply: boolean;
  canRevert: boolean;
  reverted?: boolean;
  revertedAt?: string | null;
  appliedAt?: string;
  newVersionId?: string;
}> {
  return apiClient.get(`/runs/${runId}/apply-status`);
}
