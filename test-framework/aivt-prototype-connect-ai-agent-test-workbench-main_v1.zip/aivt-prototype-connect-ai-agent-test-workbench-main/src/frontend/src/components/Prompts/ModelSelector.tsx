/**
 * Capability-aware model selector for the per-prompt detail page.
 *
 * Implements task 13.5 of the prompt-management feature plan and the
 * following requirements:
 *
 *   - R5.2 — the dropdown is constrained to the prompt's `allowedModels[]`
 *     returned by the API, so the user can never pick a model the
 *     registry hasn't approved for that prompt.
 *
 *   - R5.5 — when the user switches to a model whose Model_Capability_Profile
 *     accepts a strict superset of the prior profile (anthropic_claude_4x →
 *     amazon_nova for example), the additional keys are NOT auto-populated;
 *     they merely become editable in the {@link InferenceParameterForm}.
 *     This keeps the override surface honest: a user opts in to the new
 *     keys by entering values explicitly. Conversely, when the new profile
 *     forbids keys the user had set under the prior profile (Nova → Claude
 *     4.x for example, where temperature/topP/topK/stopSequences are
 *     rejected), those keys are stripped from the draft inference
 *     parameters and reported back to the caller via the `removedKeys`
 *     callback argument.
 *
 *   - R14.2 — the model dropdown shows only the `allowedModels[]` returned
 *     by the API, and downstream form fields are filtered by the resolved
 *     model's capability profile (the {@link InferenceParameterForm} owns
 *     that filtering; the selector's job is only to inform it which model
 *     is now selected and which keys, if any, were dropped from the draft).
 *
 * Cloudscape `Alert` rendering is intentionally NOT done inside this
 * component — the parent ({@link PromptDetailPage}) owns the lifecycle
 * of the "removed keys" notice because:
 *
 *   1. The notice is dismissible (a fresh state the parent already
 *      manages alongside the save-error alert and active-runs flashbar).
 *
 *   2. The notice must persist across re-renders of the selector itself
 *      (e.g., when the user edits other form fields) until the user
 *      either saves, reverts, or dismisses it.
 *
 *   3. A second model switch in the same session must merge the new
 *      removed-keys with the old, which is parent state — the selector
 *      is stateless on this dimension by design.
 *
 * The selector therefore returns the removed keys via the `onChange`
 * callback's second argument and trusts the parent to surface them.
 *
 * @module frontend/components/Prompts/ModelSelector
 */

import Select, { type SelectProps } from '@cloudscape-design/components/select';
import type { AllowedModelEntry, ModelKey } from '../../api';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface ModelSelectorProps {
  /**
   * The full `allowedModels[]` array from the prompt detail response.
   * Each entry carries its capability profile inline so the selector
   * can compute which keys a prospective switch would drop without
   * needing a second API call.
   */
  allowedModels: AllowedModelEntry[];

  /**
   * The currently-selected `modelKey`. The Cloudscape `Select`'s
   * `selectedOption` is derived by matching this against
   * `allowedModels[].modelKey`. When the value isn't found in the
   * allowed list (defensive — shouldn't happen in practice because
   * the API always returns a `currentModelKey` that is in
   * `allowedModels[]`), the selector renders no selection so the
   * user is forced to pick one explicitly rather than seeing a
   * stale label.
   */
  selectedModelKey: ModelKey;

  /**
   * Called when the user picks a different model. The second argument
   * is the list of `inferenceParameters` keys that the new model's
   * capability profile would forbid — the parent is expected to drop
   * them from the draft inference parameters and surface a Cloudscape
   * `Alert` listing them so the user knows what changed (R5.5).
   *
   * If the user re-selects the already-selected model (or the new
   * model accepts every key the prior profile did), `removedKeys` is
   * an empty array and the parent SHOULD NOT raise the alert.
   */
  onChange: (modelKey: ModelKey, removedKeys: string[]) => void;

  /**
   * The current draft inference parameters. The selector reads only
   * the key set; values are irrelevant for the forbidden-key
   * computation. Passing the live draft (rather than the persisted
   * dict) ensures keys the user has just typed in are also stripped
   * if the new model forbids them — otherwise a stale draft would
   * survive a model switch and trip the dry-render check on save.
   */
  currentInferenceParameters: Record<string, unknown>;

  /**
   * Disable the dropdown while a save or reset is in flight so the
   * user can't change the model under the API call's feet.
   */
  disabled?: boolean;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Compute the set of keys present in `currentInferenceParameters`
 * that the prospective model's capability profile would forbid —
 * i.e. keys that are NOT in the union of `acceptsTopLevel` and
 * `acceptsAdditional`. The model's explicit `forbids[]` list is a
 * subset of "everything not accepted", so we match against the
 * accepts-union directly: any current key the new profile doesn't
 * accept must be dropped, whether the profile listed it explicitly
 * or simply doesn't recognise it.
 *
 * Returns an empty array when no current key is at risk.
 */
function computeRemovedKeys(
  newModel: AllowedModelEntry,
  currentInferenceParameters: Record<string, unknown>,
): string[] {
  const accepted = new Set<string>([
    ...newModel.capabilityProfile.acceptsTopLevel,
    ...newModel.capabilityProfile.acceptsAdditional,
  ]);
  return Object.keys(currentInferenceParameters).filter(
    (key) => !accepted.has(key),
  );
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * Cloudscape `Select` over a prompt's allowed models, with capability-
 * aware change semantics. See the module docstring for the contract.
 */
export function ModelSelector({
  allowedModels,
  selectedModelKey,
  onChange,
  currentInferenceParameters,
  disabled,
}: ModelSelectorProps): JSX.Element {
  // Map each allowed model to a Cloudscape `Select` option. The
  // `description` field surfaces the inference-profile id so a user
  // who knows the canonical Bedrock prefix can confirm the dropdown
  // resolves to the model they expect.
  const options: SelectProps.Option[] = allowedModels.map((model) => ({
    label: model.displayName,
    value: model.modelKey,
    description: model.inferenceProfileId,
  }));

  const selected =
    options.find((option) => option.value === selectedModelKey) ?? null;

  const handleChange = (raw: string | undefined) => {
    if (!raw) return;
    const next = raw as ModelKey;

    // No-op: the user re-picked the already-selected model. We still
    // forward the change so the parent's onChange contract is uniform
    // (idempotent), but with an empty `removedKeys` so the parent's
    // alert state is left untouched.
    if (next === selectedModelKey) {
      onChange(next, []);
      return;
    }

    // Defensive: the dropdown only renders entries from `allowedModels`,
    // so a missing entry here would mean a corrupted option list. We
    // forward the change with an empty removed-keys list rather than
    // throwing, so the user isn't blocked, and let the backend's
    // MODEL_NOT_ALLOWED check be the authoritative guard at save time.
    const newModel = allowedModels.find((m) => m.modelKey === next);
    if (!newModel) {
      onChange(next, []);
      return;
    }

    const removedKeys = computeRemovedKeys(newModel, currentInferenceParameters);
    onChange(next, removedKeys);
  };

  return (
    <Select
      selectedOption={selected}
      onChange={({ detail }) =>
        handleChange(detail.selectedOption.value as string | undefined)
      }
      options={options}
      disabled={disabled}
      placeholder="Select a model"
    />
  );
}

export default ModelSelector;
