/**
 * Run comparison utility for identifying status changes between test runs.
 *
 * @module run-comparison
 */

import { CaseStatus } from "../enums";
import { TestCaseResult } from "../types";

/** Classification of a test case when comparing two runs. */
export type ComparisonCategory =
  | "unchanged"
  | "status-changed"
  | "added"
  | "removed";

/** A single entry in the run comparison result. */
export interface ComparisonEntry {
  caseId: string;
  category: ComparisonCategory;
  /** Status in the first run (undefined if added). */
  previousStatus?: CaseStatus;
  /** Status in the second run (undefined if removed). */
  currentStatus?: CaseStatus;
}

/** Aggregate result of comparing two runs. */
export interface RunComparisonResult {
  entries: ComparisonEntry[];
  summary: {
    unchanged: number;
    statusChanged: number;
    added: number;
    removed: number;
  };
}

/**
 * Compares two test run result sets and classifies each case.
 *
 * Matching is performed by `caseId`. Cases are classified as:
 * - "unchanged": present in both runs with the same status
 * - "status-changed": present in both runs with a different status
 * - "added": present in runB but not runA
 * - "removed": present in runA but not runB
 *
 * @param runA - Results from the first (earlier) run
 * @param runB - Results from the second (later) run
 * @returns Classification of all cases across both runs
 */
export function compareRuns(
  runA: TestCaseResult[],
  runB: TestCaseResult[]
): RunComparisonResult {
  const mapA = new Map<string, TestCaseResult>();
  const mapB = new Map<string, TestCaseResult>();

  for (const result of runA) {
    mapA.set(result.caseId, result);
  }
  for (const result of runB) {
    mapB.set(result.caseId, result);
  }

  const entries: ComparisonEntry[] = [];
  const allCaseIds = new Set<string>([...mapA.keys(), ...mapB.keys()]);

  for (const caseId of allCaseIds) {
    const inA = mapA.get(caseId);
    const inB = mapB.get(caseId);

    if (inA && inB) {
      if (inA.status === inB.status) {
        entries.push({
          caseId,
          category: "unchanged",
          previousStatus: inA.status,
          currentStatus: inB.status,
        });
      } else {
        entries.push({
          caseId,
          category: "status-changed",
          previousStatus: inA.status,
          currentStatus: inB.status,
        });
      }
    } else if (inB && !inA) {
      entries.push({
        caseId,
        category: "added",
        currentStatus: inB.status,
      });
    } else if (inA && !inB) {
      entries.push({
        caseId,
        category: "removed",
        previousStatus: inA.status,
      });
    }
  }

  const summary = {
    unchanged: entries.filter((e) => e.category === "unchanged").length,
    statusChanged: entries.filter((e) => e.category === "status-changed").length,
    added: entries.filter((e) => e.category === "added").length,
    removed: entries.filter((e) => e.category === "removed").length,
  };

  return { entries, summary };
}
