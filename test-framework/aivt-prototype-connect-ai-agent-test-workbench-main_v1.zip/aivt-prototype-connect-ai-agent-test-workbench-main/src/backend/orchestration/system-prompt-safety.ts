/**
 * System Prompt Safety Validation Module
 *
 * Validates that a variant's modified system prompt preserves structural
 * integrity per Requirements 20.1–20.6:
 *
 * 1. Dynamic parameters ({{$.Custom.*}}, {{agent.*}}, {{session.*}}) remain
 *    in their original positions at the end of the prompt.
 * 2. Thinking/messaging blocks (<thinking>, <messaging> or equivalent
 *    structural delimiters) are byte-for-byte unchanged.
 * 3. No new examples introduced into the system prompt body.
 *
 * Falls back to treating the entire prompt as editable (minus dynamic
 * params at end) when no structural markers are detected.
 *
 * @module system-prompt-safety
 */

// ---------------------------------------------------------------------------
// Public Types
// ---------------------------------------------------------------------------

export interface SystemPromptSafetyResult {
  valid: boolean;
  violations: string[];
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/**
 * Regex matching dynamic parameters: {{$.Custom.Foo}}, {{agent.bar}}, {{session.baz}}
 * These placeholders are injected by the Q in Connect runtime and must remain
 * at the end of the prompt to preserve prompt cache efficiency (R20.1).
 */
const DYNAMIC_PARAM_REGEX =
  /\{\{\$\.Custom\.\w+\}\}|\{\{agent\.\w+\}\}|\{\{session\.\w+\}\}/g;

/**
 * Structural delimiters that delineate thinking and messaging blocks.
 * The Q in Connect self-service orchestration prompts use XML-style tags.
 */
const BLOCK_DELIMITERS: ReadonlyArray<{ open: string; close: string }> = [
  { open: "<thinking>", close: "</thinking>" },
  { open: "<messaging>", close: "</messaging>" },
];

/**
 * Patterns that indicate example-like content in a system prompt.
 * Used for heuristic detection of newly introduced examples (R20.3).
 */
const EXAMPLE_PATTERNS: RegExp[] = [
  // Dialogue patterns: "Customer:" / "Agent:" pairs
  /^Customer:/m,
  /^Agent:/m,
  // Q/A patterns
  /^Q:/m,
  /^A:/m,
  // Explicit example markers
  /^Example\s*\d*\s*:/mi,
  // XML-like example blocks
  /<example>/i,
];

// ---------------------------------------------------------------------------
// Internal Helpers
// ---------------------------------------------------------------------------

/**
 * Extracts all dynamic parameter occurrences with their positions.
 */
function extractDynamicParams(
  prompt: string
): Array<{ match: string; index: number }> {
  const results: Array<{ match: string; index: number }> = [];
  let m: RegExpExecArray | null;
  const regex = new RegExp(DYNAMIC_PARAM_REGEX.source, "g");
  while ((m = regex.exec(prompt)) !== null) {
    results.push({ match: m[0], index: m.index });
  }
  return results;
}

/**
 * Determines the start index of the "trailing dynamic parameters section."
 * This is the position after which only dynamic parameters (and whitespace/
 * newlines between them) appear. Returns prompt.length if no dynamic params
 * exist at the end.
 */
function findTrailingParamsStart(prompt: string): number {
  const params = extractDynamicParams(prompt);
  if (params.length === 0) {
    return prompt.length;
  }

  // Walk backward from the end of the prompt to find the first character
  // that is not part of a dynamic parameter or whitespace between them.
  // The "trailing section" starts at the earliest dynamic parameter that
  // is part of a contiguous block extending to the end of the prompt.
  let trailingStart = prompt.length;

  for (let i = params.length - 1; i >= 0; i--) {
    const param = params[i];
    const paramEnd = param.index + param.match.length;

    // Check that everything from paramEnd to trailingStart is only whitespace
    // or other dynamic parameters (which we've already accounted for).
    const between = prompt.substring(paramEnd, trailingStart);
    if (between.trim().length > 0) {
      // There's non-whitespace content between this param and the trailing
      // section, so this param is not part of the trailing block.
      break;
    }

    trailingStart = param.index;
  }

  // Also check that everything from trailingStart to end of prompt is only
  // dynamic params and whitespace
  const trailingContent = prompt.substring(trailingStart);
  const withoutParams = trailingContent.replace(DYNAMIC_PARAM_REGEX, "");
  if (withoutParams.trim().length > 0) {
    // Trailing section contains non-param, non-whitespace content.
    // This means no clean trailing section exists.
    return prompt.length;
  }

  return trailingStart;
}

/**
 * Extracts structural blocks (thinking/messaging) from a prompt.
 * Returns the blocks with their content and positions.
 */
function extractBlocks(
  prompt: string
): Array<{ open: string; close: string; content: string; start: number; end: number }> {
  const blocks: Array<{
    open: string;
    close: string;
    content: string;
    start: number;
    end: number;
  }> = [];

  for (const delimiter of BLOCK_DELIMITERS) {
    let searchStart = 0;
    while (true) {
      const openIdx = prompt.indexOf(delimiter.open, searchStart);
      if (openIdx === -1) break;

      const closeIdx = prompt.indexOf(
        delimiter.close,
        openIdx + delimiter.open.length
      );
      if (closeIdx === -1) break;

      const blockEnd = closeIdx + delimiter.close.length;
      blocks.push({
        open: delimiter.open,
        close: delimiter.close,
        content: prompt.substring(openIdx, blockEnd),
        start: openIdx,
        end: blockEnd,
      });

      searchStart = blockEnd;
    }
  }

  return blocks;
}

/**
 * Checks if a text segment contains example-like patterns.
 */
function containsExamplePatterns(text: string): boolean {
  return EXAMPLE_PATTERNS.some((pattern) => pattern.test(text));
}

/**
 * Extracts the editable body content from a prompt by removing structural
 * blocks and trailing dynamic parameters.
 */
function extractEditableBody(prompt: string): string {
  const blocks = extractBlocks(prompt);
  const trailingStart = findTrailingParamsStart(prompt);

  // Remove blocks and trailing section to get the editable body
  let body = prompt.substring(0, trailingStart);

  // Remove blocks from body (process in reverse order to preserve indices)
  const sortedBlocks = [...blocks]
    .filter((b) => b.start < trailingStart)
    .sort((a, b) => b.start - a.start);

  for (const block of sortedBlocks) {
    body =
      body.substring(0, block.start) +
      body.substring(Math.min(block.end, trailingStart));
  }

  return body;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Validates that a variant's modified system prompt preserves structural
 * integrity per Requirements 20.1-20.6:
 *
 * 1. Dynamic parameters ({{$.Custom.*}}, {{agent.*}}, {{session.*}}) remain
 *    in their original positions at the end of the prompt.
 * 2. Thinking/messaging blocks (<thinking>, <messaging> or equivalent
 *    structural delimiters) are byte-for-byte unchanged.
 * 3. No new examples introduced into the system prompt body.
 *
 * Falls back to treating the entire prompt as editable (minus dynamic
 * params at end) when no structural markers are detected.
 */
export function validateSystemPromptSafety(
  originalPrompt: string,
  modifiedPrompt: string
): SystemPromptSafetyResult {
  const violations: string[] = [];

  // -------------------------------------------------------------------------
  // Rule 1: Dynamic parameters must remain at end of prompt (R20.1)
  // -------------------------------------------------------------------------
  const originalParams = extractDynamicParams(originalPrompt);
  const modifiedParams = extractDynamicParams(modifiedPrompt);

  // All original parameters must still be present
  const originalParamValues = originalParams.map((p) => p.match);
  const modifiedParamValues = modifiedParams.map((p) => p.match);

  for (const param of originalParamValues) {
    if (!modifiedParamValues.includes(param)) {
      violations.push(
        `Dynamic parameter "${param}" was removed from the prompt.`
      );
    }
  }

  // Check that all dynamic parameters in the modified prompt are at the end
  if (modifiedParams.length > 0) {
    const modifiedTrailingStart = findTrailingParamsStart(modifiedPrompt);
    const originalTrailingStart = findTrailingParamsStart(originalPrompt);

    // If trailing start equals prompt length, no params are in a trailing position
    if (modifiedTrailingStart === modifiedPrompt.length) {
      // All params exist but none are at the trailing position — report each one
      for (const param of modifiedParams) {
        violations.push(
          `Dynamic parameter "${param.match}" at position ${param.index} ` +
            `is not in the trailing section. ` +
            `Dynamic parameters must remain at the end of the prompt to preserve prompt cache efficiency.`
        );
      }
    } else {
      // Verify all dynamic params are within the trailing section
      for (const param of modifiedParams) {
        if (param.index < modifiedTrailingStart) {
          violations.push(
            `Dynamic parameter "${param.match}" at position ${param.index} ` +
              `is not in the trailing section (which starts at position ${modifiedTrailingStart}). ` +
              `Dynamic parameters must remain at the end of the prompt.`
          );
        }
      }

      // Additional safety check: if the original prompt had a body section
      // (non-whitespace content before its trailing params), then the modified
      // prompt must not have params placed before that body content. This catches
      // the case where body is very short/whitespace-only and params get moved
      // to the very beginning — findTrailingParamsStart might report 0 even
      // though the params were relocated to the front.
      if (
        modifiedTrailingStart === 0 &&
        originalTrailingStart > 0 &&
        originalTrailingStart < originalPrompt.length
      ) {
        // The original had params clearly at the end (body existed before them),
        // but now findTrailingParamsStart says the whole modified prompt is trailing.
        // Check if the modified prompt has params before any remaining body content.
        // If body content from original still exists somewhere after the params,
        // the params were moved to the front.
        const originalBody = originalPrompt
          .substring(0, originalTrailingStart);
        // If the original body had content (even just whitespace that's preserved),
        // and params are now at position 0, they were moved forward.
        if (originalBody.length > 0) {
          for (const param of modifiedParams) {
            if (param.index === 0 || modifiedPrompt.substring(0, param.index).trim().length === 0) {
              violations.push(
                `Dynamic parameter "${param.match}" was moved from the trailing section ` +
                  `to the beginning of the prompt. ` +
                  `Dynamic parameters must remain at the end of the prompt.`
              );
            }
          }
        }
      }
    }
  }

  // -------------------------------------------------------------------------
  // Rule 2: Thinking/messaging blocks must be byte-for-byte unchanged (R20.2)
  // -------------------------------------------------------------------------
  const originalBlocks = extractBlocks(originalPrompt);
  const hasStructuralMarkers = originalBlocks.length > 0;

  if (hasStructuralMarkers) {
    const modifiedBlocks = extractBlocks(modifiedPrompt);

    // Each original block must have a corresponding byte-for-byte match
    for (const origBlock of originalBlocks) {
      const matchingBlock = modifiedBlocks.find(
        (mb) => mb.open === origBlock.open && mb.close === origBlock.close
      );

      if (!matchingBlock) {
        violations.push(
          `Structural block ${origBlock.open}...${origBlock.close} was removed from the prompt. ` +
            `Thinking/messaging blocks are immutable and must not be modified or removed.`
        );
      } else if (matchingBlock.content !== origBlock.content) {
        violations.push(
          `Structural block ${origBlock.open}...${origBlock.close} was modified. ` +
            `Thinking/messaging blocks must remain byte-for-byte unchanged.`
        );
      }
    }
  }

  // -------------------------------------------------------------------------
  // Rule 3: No new examples introduced into system prompt body (R20.3)
  // -------------------------------------------------------------------------
  if (hasStructuralMarkers) {
    // With structural markers: compare the editable body portions
    const originalBody = extractEditableBody(originalPrompt);
    const modifiedBody = extractEditableBody(modifiedPrompt);

    // Find content that is new in the modified body
    // Heuristic: check if the modified body introduces example patterns that
    // were not present in the original body
    const originalHasExamples = containsExamplePatterns(originalBody);
    const modifiedHasExamples = containsExamplePatterns(modifiedBody);

    if (!originalHasExamples && modifiedHasExamples) {
      violations.push(
        "New example content was introduced into the system prompt body. " +
          "New examples must be directed to tool_examples on the appropriate tool instead."
      );
    }
  } else {
    // Fallback: no structural markers detected (R20.6)
    // Treat entire prompt as editable minus trailing dynamic params.
    // Only enforce Rule 1 (already done above) and Rule 3.
    const originalTrailingStart = findTrailingParamsStart(originalPrompt);
    const modifiedTrailingStart = findTrailingParamsStart(modifiedPrompt);

    const originalBody = originalPrompt.substring(0, originalTrailingStart);
    const modifiedBody = modifiedPrompt.substring(0, modifiedTrailingStart);

    const originalHasExamples = containsExamplePatterns(originalBody);
    const modifiedHasExamples = containsExamplePatterns(modifiedBody);

    if (!originalHasExamples && modifiedHasExamples) {
      violations.push(
        "New example content was introduced into the system prompt body. " +
          "New examples must be directed to tool_examples on the appropriate tool instead."
      );
    }
  }

  return {
    valid: violations.length === 0,
    violations,
  };
}
