/**
 * Confirmation modal shown when the user clicks "Revert to default" on
 * the per-prompt detail page.
 *
 * Implements task 13.8 of the prompt-management feature plan and the
 * following requirement:
 *
 *   - R14.4 — when the user clicks "Revert to default", the page SHALL
 *     prompt for confirmation, then issue `POST /prompts/{promptKey}/reset`
 *     and on success SHALL refetch the prompt detail.
 *
 * Ownership split with the parent ({@link PromptDetailPage}):
 *
 *   - The modal is presentation-only. It surfaces a Cloudscape `Modal`
 *     with a header, body copy, and a Cancel/Revert button pair. It
 *     does NOT call the API itself.
 *
 *   - On Revert, the modal raises `onConfirm()`; the parent owns the
 *     `resetPrompt(promptKey)` call so it can also do post-reset
 *     bookkeeping (refetch the detail, surface the R14.6 active-runs
 *     notice when applicable). The `prompts` API client already sends
 *     `{ confirm: true }` automatically per its contract, so the parent
 *     simply calls `resetPrompt(promptKey)` without further arguments.
 *
 *   - On Cancel (or backdrop dismiss), the modal raises `onCancel()`;
 *     the parent decides whether to close the modal — typically by
 *     toggling its `visible` prop to `false`.
 *
 *   - The `loading` prop drives the primary button's spinner and
 *     disables the Cancel button so the user cannot double-trigger or
 *     close the modal mid-request.
 *
 * @module frontend/components/Prompts/RevertConfirmModal
 */

import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import Modal from '@cloudscape-design/components/modal';
import SpaceBetween from '@cloudscape-design/components/space-between';

export interface RevertConfirmModalProps {
  /** Whether the modal is currently visible. */
  visible: boolean;
  /** Display name of the prompt being reverted, used in the body copy. */
  promptName: string;
  /** True while the parent's `resetPrompt(...)` call is in flight. */
  loading: boolean;
  /** Fires when the user clicks the primary "Revert" button. */
  onConfirm: () => void;
  /** Fires when the user clicks Cancel or dismisses the modal. */
  onCancel: () => void;
}

export function RevertConfirmModal({
  visible,
  promptName,
  loading,
  onConfirm,
  onCancel,
}: RevertConfirmModalProps): JSX.Element {
  return (
    <Modal
      visible={visible}
      onDismiss={onCancel}
      header="Revert to bundled default"
      footer={
        <Box float="right">
          <SpaceBetween direction="horizontal" size="xs">
            <Button variant="link" onClick={onCancel} disabled={loading}>
              Cancel
            </Button>
            <Button variant="primary" onClick={onConfirm} loading={loading}>
              Revert
            </Button>
          </SpaceBetween>
        </Box>
      }
    >
      <SpaceBetween size="s">
        <Box>
          Revert <strong>{promptName}</strong> to the text and model that the
          platform shipped with? This discards the current override and the
          next Bedrock invocation will use the bundled default.
        </Box>
        <Box variant="small" color="text-body-secondary">
          Runs already in progress are not affected — they continue with the
          prompts pinned at their start.
        </Box>
      </SpaceBetween>
    </Modal>
  );
}
