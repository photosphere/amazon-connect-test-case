# bedrock-judge-evaluations

Replaces the AgentCore Evaluate integration in `platform-hosting-and-evaluations` Workstream 2 with a Bedrock Converse + AWS-published prompt-template approach.

## Status

- **Phase**: design (high-level)
- **Validation**: end-to-end probe `scripts/bedrock-judge-probe.ts` produced sensible scores against both checked-in `Span_Fixtures` (multi-tool-success, failure-escalation) using Claude 3.5 Sonnet. The production default (`us.anthropic.claude-sonnet-4-6`) tracks the platform's standard reasoning model; the probe is intentionally left on the validated id.
- **Source of truth for prompts**: <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html>

## Why this exists

`design.md` opens with the validated facts. Short version:

- Q in Connect (`qconnect:ListSpans`) is not AgentCore Runtime; AgentCore Evaluate's `sessionSpans` requires the post-CloudWatch-ingestion log format produced by AgentCore Runtime + ADOT, which we cannot synthesize. 9 live probes against the AgentCore Evaluate API confirmed every hand-crafted variant fails with `LogEventMissingException`.
- AWS publishes the exact prompt templates the built-in evaluators use. Calling Bedrock Converse with those templates produces the same scoring without the ingestion pipeline. Two checked-in fixtures validated end-to-end.

## Files

- `.config.kiro` — feature spec config (design-first, high-level design)
- `design.md` — high-level design, components, data flow, error handling, correctness properties, testing strategy, migration plan
- `requirements.md` — to be derived from the design (not yet written)
- `tasks.md` — to be derived from requirements + design (not yet written)

## Key decisions

- **Reuses unchanged**: `evaluation-scoring.ts`, `evaluation-result.ts`, `score-comparison.ts`, `types.ts`, all run/results/comparison frontend code.
- **Replaces**: `trace-to-otel.ts` → `judge-prompt-rendering.ts`; `agentcore-client.ts` → `bedrock-judge-client.ts`; the Evaluation Lambda's composition.
- **Default judge model**: `us.anthropic.claude-sonnet-4-6` (matches `analysis.ts` and `scaffold.ts`), configurable via the `judgeModelId` CDK context key. IAM grant is scoped to exactly the configured profile ARN plus its underlying foundation-model ARN in every region the inference profile may route to (no `us.anthropic.*` wildcards).
- **Migration**: keeps `platform-hosting-and-evaluations` Workstream 1 (Tasks 1–9, hosting/bootstrap); supersedes Workstream 2 (Tasks 10–21).
