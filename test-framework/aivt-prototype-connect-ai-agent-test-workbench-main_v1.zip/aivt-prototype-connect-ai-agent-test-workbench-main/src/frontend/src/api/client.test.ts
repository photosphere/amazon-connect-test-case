/**
 * Unit tests for the API client covering:
 * - 401 redirect to Cognito login
 * - 5xx flash message notification dispatch
 * - Network timeout retry with backoff
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

// Mock the auth module
vi.mock('../auth', () => ({
  getAccessToken: vi.fn(),
  getStoredUserEmail: vi.fn(),
  redirectToLogin: vi.fn(),
}));

// Mock the config module: return a valid runtime config so requests resolve a base URL.
// Tests that exercise the runtime-config error path live in tests/unit/frontend/.
vi.mock('./config', () => ({
  getConfig: vi.fn(() => ({
    apiEndpoint: 'https://example.test/prod',
    cognitoUserPoolId: 'us-east-1_TEST',
    cognitoClientId: 'test-client-id',
    cognitoDomain: 'test.auth.us-east-1.amazoncognito.com',
    region: 'us-east-1',
    instanceMode: 'development',
  })),
}));

// Mock the notifications module
vi.mock('./notifications', () => ({
  notifyError: vi.fn(),
}));

import { apiClient, ApiClientError } from './client';
import { getAccessToken, redirectToLogin } from '../auth';
import { notifyError } from './notifications';

// Helpers
const mockFetch = vi.fn();
global.fetch = mockFetch;

// Access the mocked functions
const mockGetAccessToken = getAccessToken as ReturnType<typeof vi.fn>;
const mockRedirectToLogin = redirectToLogin as ReturnType<typeof vi.fn>;
const mockNotifyError = notifyError as ReturnType<typeof vi.fn>;

describe('API Client', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockGetAccessToken.mockResolvedValue('test-token-123');
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('Authentication', () => {
    it('includes Bearer token in request headers', async () => {
      mockFetch.mockResolvedValue({
        ok: true,
        status: 200,
        json: () => Promise.resolve({ data: 'test' }),
      });

      await apiClient.get('/agents');

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining('/agents'),
        expect.objectContaining({
          headers: expect.objectContaining({
            Authorization: 'Bearer test-token-123',
          }),
        })
      );
    });

    it('redirects to login when no token is available', async () => {
      mockGetAccessToken.mockResolvedValue(null);

      await expect(apiClient.get('/agents')).rejects.toThrow(ApiClientError);
      expect(mockRedirectToLogin).toHaveBeenCalled();
    });
  });

  describe('401 Handling', () => {
    it('redirects to Cognito login on 401 response', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 401,
        statusText: 'Unauthorized',
      });

      await expect(apiClient.get('/agents')).rejects.toThrow(ApiClientError);
      expect(mockRedirectToLogin).toHaveBeenCalled();
    });

    it('throws ApiClientError with status 401', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 401,
        statusText: 'Unauthorized',
      });

      try {
        await apiClient.get('/agents');
      } catch (err) {
        expect(err).toBeInstanceOf(ApiClientError);
        expect((err as ApiClientError).status).toBe(401);
        expect((err as ApiClientError).retryable).toBe(false);
      }
    });
  });

  describe('5xx Error Handling', () => {
    it('dispatches a notification on 5xx errors', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: () => Promise.resolve({ message: 'Server error occurred' }),
      });

      await expect(apiClient.get('/runs/123')).rejects.toThrow(ApiClientError);
      expect(mockNotifyError).toHaveBeenCalledWith('Server error occurred', true);
    });

    it('marks 5xx errors as retryable', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 503,
        statusText: 'Service Unavailable',
        json: () => Promise.resolve({ message: 'Service unavailable' }),
      });

      try {
        await apiClient.post('/runs', { suiteId: 'test' });
      } catch (err) {
        expect(err).toBeInstanceOf(ApiClientError);
        expect((err as ApiClientError).status).toBe(503);
        expect((err as ApiClientError).retryable).toBe(true);
      }
    });

    it('does not dispatch notification for 4xx errors (non-401)', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: () => Promise.resolve({ message: 'Not found' }),
      });

      await expect(apiClient.get('/agents/nonexistent')).rejects.toThrow(ApiClientError);
      expect(mockNotifyError).not.toHaveBeenCalled();
    });
  });

  describe('Network Timeout Retry', () => {
    it('retries on network timeout (AbortError)', async () => {
      const abortError = new DOMException('signal is aborted', 'AbortError');

      // First two calls timeout, third succeeds
      mockFetch
        .mockRejectedValueOnce(abortError)
        .mockRejectedValueOnce(abortError)
        .mockResolvedValue({
          ok: true,
          status: 200,
          json: () => Promise.resolve({ agents: [] }),
        });

      const result = await apiClient.get<{ agents: unknown[] }>('/agents');
      expect(result.agents).toEqual([]);
      expect(mockFetch).toHaveBeenCalledTimes(3);
    });

    it('dispatches retry notification on network timeout', async () => {
      const abortError = new DOMException('signal is aborted', 'AbortError');

      mockFetch
        .mockRejectedValueOnce(abortError)
        .mockResolvedValue({
          ok: true,
          status: 200,
          json: () => Promise.resolve({ data: 'ok' }),
        });

      await apiClient.get('/agents');
      expect(mockNotifyError).toHaveBeenCalledWith(
        expect.stringContaining('Network timeout'),
        true
      );
    });

    it('throws after max retries exhausted', async () => {
      const abortError = new DOMException('signal is aborted', 'AbortError');

      mockFetch
        .mockRejectedValueOnce(abortError)
        .mockRejectedValueOnce(abortError)
        .mockRejectedValueOnce(abortError);

      await expect(apiClient.get('/agents')).rejects.toThrow(ApiClientError);
      // Initial + 2 retries = 3 calls
      expect(mockFetch).toHaveBeenCalledTimes(3);
    });

    it('retries on TypeError (network failure)', async () => {
      mockFetch
        .mockRejectedValueOnce(new TypeError('Failed to fetch'))
        .mockResolvedValue({
          ok: true,
          status: 200,
          json: () => Promise.resolve({ data: 'recovered' }),
        });

      const result = await apiClient.get<{ data: string }>('/agents');
      expect(result.data).toBe('recovered');
      expect(mockFetch).toHaveBeenCalledTimes(2);
    });
  });

  describe('Successful Requests', () => {
    it('handles 204 No Content', async () => {
      mockFetch.mockResolvedValue({
        ok: true,
        status: 204,
      });

      const result = await apiClient.delete('/suites/123');
      expect(result).toBeUndefined();
    });

    it('parses JSON response', async () => {
      mockFetch.mockResolvedValue({
        ok: true,
        status: 200,
        json: () => Promise.resolve({ agents: [{ agentId: '1', name: 'Test' }] }),
      });

      const result = await apiClient.get<{ agents: unknown[] }>('/agents');
      expect(result.agents).toHaveLength(1);
    });
  });
});
