// Feature: prompt-management, fast-check generators for the
// property-based correctness invariants from the design's Testing
// Strategy section (R15.6).
//
// Three arbitraries live here. The four property tests in the wave
// (placeholder preservation, capability-profile compliance, override
// round-trip, reset idempotence) all draw from this module so the
// valid-input distribution is shared and any tightening of "what counts
// as a valid edit" lands in one place rather than five.
//
//   - `promptKeyArb` — picks one of the thirteen registered `PromptKey`
//     values uniformly at random. Sourced from `Object.keys(PROMPT_REGISTRY)`
//     so it cannot drift from the registry: a removed prompt key narrows
//     the set automatically and a new one widens it.
//
//   - `validTextArb(prompt)` — generates a `text` body that satisfies
//     every stage of the Prompts API validation pipeline:
//       (a) each declared `{name}` placeholder appears at least once;
//       (b) no placeholder exceeds its `maxOccurrences` cap when one is
//           declared;
//       (c) no `{...}` token is introduced for a name the registry does
//           not declare (achieved by drawing fillers from a brace-free
//           alphabet — every `{name}` substring in the output is a
//           placeholder token we inserted intentionally);
//       (d) total UTF-8 byte length stays under the prompt's per-key
//           `maxTextBytes` cap (`64 KiB` when absent).
//     The generator deliberately keeps generated text short (≤~512
//     chars) so tests stay fast; correctness is what we want to pin,
//     not size-cap edge cases (those are exercised by unit tests in
//     `tests/unit/prompts-validation.test.ts`).
//
//   - `validInferenceParametersArb(prompt, model)` — generates an
//     `inferenceParameters` body valid for the `(prompt, model)` pair.
//     The output's key set is a subset of the resolved model's
//     `capabilityProfile.acceptsTopLevel ∪ acceptsAdditional` and
//     disjoint from `capabilityProfile.forbids`; numeric values lie
//     inside the intersection of the prompt's per-key schema range and
//     the profile's per-key range, plus the model's `maxOutputTokens`
//     ceiling for `maxTokens` specifically (per the design's "effective
//     bound" note). Keys not in the prompt's schema are never emitted —
//     the prompt's schema is the authoritative list of which knobs the
//     prompt advertises.
//
// All three generators are pure: they consult only the registry and the
// supported-models / capability-profiles catalogs imported via the
// public `prompt-registry/index.ts` surface. No DDB, no HTTP, no
// platform mocks — every property test layers its own mocks on top.
//
// **Validates: Requirement 15.6**

import fc from 'fast-check';

import {
  CAPABILITY_PROFILES,
  PROMPT_REGISTRY,
} from '../../src/backend/orchestration/prompt-registry';
import type {
  InferenceParameterSchema,
  PromptDefinition,
  PromptKey,
  SupportedModel,
} from '../../src/backend/orchestration/prompt-registry';

// ---------------------------------------------------------------------------
// Internal alphabet for filler text — every printable ASCII character
// EXCEPT `{` and `}`. Guarantees that the only `{name}` tokens in the
// generated text are the ones we inject deliberately, which is what the
// "Unknown placeholder detection" validation stage (R12.4) requires.
// ---------------------------------------------------------------------------

const SAFE_FILLER_CHARS: readonly string[] =
  'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,;:!?-_\n'.split(
    '',
  );

const SAFE_FILLER_CHAR_ARB = fc.constantFrom(...SAFE_FILLER_CHARS);

/**
 * Filler-text arbitrary that draws from {@link SAFE_FILLER_CHARS}, so
 * the result is guaranteed to contain no `{` or `}` characters. Used
 * for the inter-placeholder fragments of {@link validTextArb} and as
 * the entire body for prompts that declare zero placeholders.
 */
function fillerArb(
  minLength: number,
  maxLength: number,
): fc.Arbitrary<string> {
  return fc.stringOf(SAFE_FILLER_CHAR_ARB, { minLength, maxLength });
}

// ---------------------------------------------------------------------------
// Bounds helpers
// ---------------------------------------------------------------------------

/**
 * Intersect the prompt's per-key schema range with the profile's
 * per-key range and (for `maxTokens` specifically) the per-model
 * `maxOutputTokens` ceiling. The dry-render validator enforces this
 * intersection at edit time, so the generator must respect it for
 * generated values to satisfy the validation pipeline.
 *
 * Returns `null` when the schema is a `stringArray` (a non-numeric
 * shape that has no min/max bounds in the same sense).
 */
function effectiveNumericBounds(
  key: string,
  schema: InferenceParameterSchema,
  profileNumericRanges: Readonly<Record<string, { min: number; max: number }>>,
  model: SupportedModel,
): { min: number; max: number } | null {
  if (schema.kind === 'stringArray') {
    return null;
  }
  const profileRange = profileNumericRanges[key] ?? {
    min: schema.min,
    max: schema.max,
  };
  let min = Math.max(schema.min, profileRange.min);
  let max = Math.min(schema.max, profileRange.max);
  if (key === 'maxTokens') {
    max = Math.min(max, model.maxOutputTokens);
  }
  // If the intersection is empty (would indicate a malformed schema vs
  // catalog), collapse to a singleton so fc.integer/double do not throw.
  // The registry invariant tests catch this case directly; here we just
  // want a defensible fallback.
  if (min > max) {
    return { min: max, max: max };
  }
  return { min, max };
}

/**
 * Build a value-arbitrary for a single inference-parameter key, keyed
 * by the per-prompt schema's `kind`. Numeric bounds are the
 * intersection computed by {@link effectiveNumericBounds}; the
 * `stringArray` shape draws short non-empty strings so the tests stay
 * fast.
 */
function valueArbForSchema(
  key: string,
  schema: InferenceParameterSchema,
  profileNumericRanges: Readonly<Record<string, { min: number; max: number }>>,
  model: SupportedModel,
): fc.Arbitrary<unknown> {
  if (schema.kind === 'stringArray') {
    return fc.array(
      fc.stringOf(SAFE_FILLER_CHAR_ARB, { minLength: 1, maxLength: 16 }),
      { minLength: 0, maxLength: schema.maxLength },
    );
  }
  const bounds = effectiveNumericBounds(
    key,
    schema,
    profileNumericRanges,
    model,
  );
  // bounds is non-null here because schema.kind !== 'stringArray'.
  // Cast through `as` is safe given the kind discriminator.
  const { min, max } = bounds as { min: number; max: number };
  if (schema.kind === 'integer') {
    return fc.integer({ min: Math.ceil(min), max: Math.floor(max) });
  }
  // schema.kind === 'number'
  return fc.double({ min, max, noNaN: true, noDefaultInfinity: true });
}

// ---------------------------------------------------------------------------
// Public arbitraries
// ---------------------------------------------------------------------------

/**
 * Picks one of the thirteen registered `PromptKey` values uniformly at
 * random. Sourced from `Object.keys(PROMPT_REGISTRY)` so the generator
 * cannot drift from the registry — adding or removing a prompt key
 * automatically widens or narrows the generator's output set.
 */
export const promptKeyArb: fc.Arbitrary<PromptKey> = fc.constantFrom(
  ...(Object.keys(PROMPT_REGISTRY) as PromptKey[]),
);

/**
 * Generate a `text` body valid for `prompt` per the validation pipeline:
 * every declared placeholder appears at least once (and at most its
 * `maxOccurrences` cap when one is declared), no unknown `{...}` tokens
 * are introduced, and the total UTF-8 byte length stays under the
 * prompt's `maxTextBytes` cap. For prompts that declare zero
 * placeholders (`suite_scaffold`, `case_scaffold`, `failure_analysis`,
 * `suite_recommendation`, `comparison_summary`, `tournament_summary`,
 * `variant_generation`, `rag_evaluation_job`) the result is a non-empty
 * brace-free filler string.
 *
 * Strategy: build the placeholder token list (each declared placeholder
 * repeated 1..min(maxOccurrences, 3) times), then interleave a
 * brace-free filler segment between every pair plus a prefix and
 * suffix. The brace-free alphabet is the load-bearing piece — it
 * guarantees that the only `{name}` substrings in the output are the
 * tokens we injected intentionally, so the "Unknown placeholder
 * detection" validation stage trivially passes.
 *
 * The per-occurrence cap of 3 is a deliberate test-speed choice: it is
 * always ≥ 1 so the placeholder-presence stage passes, and always ≤ the
 * declared `maxOccurrences` when one is set, so the
 * `PLACEHOLDER_COUNT_EXCEEDED` stage cannot fail. The validation
 * pipeline's specific behaviour at the cap boundary is exercised by
 * unit tests, not by these property tests.
 */
export function validTextArb(
  prompt: PromptDefinition,
): fc.Arbitrary<string> {
  const sizeCap = prompt.maxTextBytes ?? 64 * 1024;

  // Empty-placeholders case: just generate a non-empty filler. Any
  // brace-free string is automatically a valid prompt text since there
  // is no placeholder set to satisfy and no unknown-placeholder regex
  // can match.
  if (prompt.placeholders.length === 0) {
    return fillerArb(1, 200).map((text) => {
      // Belt-and-braces: clamp to the size cap.
      return Buffer.byteLength(text, 'utf8') > sizeCap
        ? text.slice(0, Math.min(text.length, 200))
        : text;
    });
  }

  // Per-placeholder occurrence count, bounded by the declared
  // maxOccurrences (when present) and by 3 (a test-speed cap that keeps
  // generated bodies under ~512 chars even for prompts with several
  // placeholders).
  const TEST_OCCURRENCE_CEILING = 3;
  const occurrenceArbs = prompt.placeholders.map((p) => {
    const upper = Math.min(
      p.maxOccurrences ?? TEST_OCCURRENCE_CEILING,
      TEST_OCCURRENCE_CEILING,
    );
    // upper is always ≥ 1 because every declared maxOccurrences
    // currently in the registry is ≥ 1; defensive `max(1, upper)` here
    // protects future changes.
    const safeUpper = Math.max(1, upper);
    return fc.integer({ min: 1, max: safeUpper }).map((count) => ({
      name: p.name,
      count,
    }));
  });

  return fc.tuple(...occurrenceArbs).chain((counts) => {
    // Build the ordered list of placeholder tokens to insert. Order
    // does not affect validation (placeholders may appear in any
    // sequence), so we keep the registry's declaration order for
    // readability.
    const tokens: string[] = [];
    for (const { name, count } of counts) {
      for (let i = 0; i < count; i++) {
        tokens.push(`{${name}}`);
      }
    }
    // One filler segment per gap (before each token + after the last).
    return fc
      .array(fillerArb(0, 24), {
        minLength: tokens.length + 1,
        maxLength: tokens.length + 1,
      })
      .map((fillers) => {
        const parts: string[] = [];
        for (let i = 0; i < tokens.length; i++) {
          parts.push(fillers[i]);
          parts.push(tokens[i]);
        }
        parts.push(fillers[tokens.length]);
        const text = parts.join('');
        // The declared placeholder tokens guarantee `text.length > 0`
        // because at least one token of length ≥ 3 (`{x}`) is present,
        // so we never need to pad. The size cap can theoretically be
        // exceeded when the registry declares a prompt with many
        // placeholders all set to large maxOccurrences, but with the
        // ceiling above (3 occurrences × ~30 chars per placeholder ×
        // ~10 placeholders ≪ 64 KiB) it cannot in practice. Defensive
        // truncation falls back to the bundled default rather than
        // returning an invalid body.
        if (Buffer.byteLength(text, 'utf8') > sizeCap) {
          return prompt.defaultText;
        }
        return text;
      });
  });
}

/**
 * Generate an `inferenceParameters` body valid for the `(prompt,
 * model)` pair. The output's key set is a subset of the resolved
 * model's `capabilityProfile.acceptsTopLevel ∪ acceptsAdditional` and
 * disjoint from `capabilityProfile.forbids`; numeric values lie inside
 * the intersection of the prompt's per-key schema and the profile's
 * per-key range (with the model's `maxOutputTokens` cap layered on for
 * `maxTokens` specifically).
 *
 * Keys present in the prompt's schema but not accepted by the resolved
 * model's profile (for example `temperature` for any
 * `anthropic_claude_4x` or `anthropic_claude_4x_lax` model — both
 * profiles only accept `maxTokens` top-level) are filtered out —
 * emitting them would trip the `MODEL_FORBIDS_KEY` validation stage.
 * The filtered subset is the candidate set the generator picks from;
 * `fc.subarray` then draws an arbitrary subset of those candidates
 * (the validation pipeline accepts a sparse `inferenceParameters`
 * body and merges missing keys with the bundled defaults at resolve
 * time).
 *
 * If the candidate set is empty (e.g. the `rag_evaluation_job` prompt
 * which declares zero `inferenceParameters`, or an Anthropic model
 * resolved against a prompt whose schema only declares Nova-family
 * keys), the generator emits the empty object — which is itself valid:
 * the resolver falls back to the prompt's `defaultInferenceValues`.
 */
export function validInferenceParametersArb(
  prompt: PromptDefinition,
  model: SupportedModel,
): fc.Arbitrary<Record<string, unknown>> {
  const profile = CAPABILITY_PROFILES[model.capabilityProfileKey];
  const acceptedKeys = new Set<string>([
    ...profile.acceptsTopLevel,
    ...profile.acceptsAdditional,
  ]);
  const forbiddenKeys = new Set<string>(profile.forbids);

  // Candidate keys: declared in the prompt's schema AND accepted by
  // the resolved model's profile AND not in the forbid list. The third
  // check is redundant in practice (the registry guarantees that
  // accepted ∩ forbidden = ∅) but kept for defensive symmetry with the
  // capability-profile compliance property.
  const candidateKeys = Object.keys(prompt.inferenceParameters).filter(
    (key) => acceptedKeys.has(key) && !forbiddenKeys.has(key),
  );

  if (candidateKeys.length === 0) {
    return fc.constant({});
  }

  // Per-key value arbitrary, computed once so the chain below does not
  // re-derive bounds on every draw.
  const valueArbs: Record<string, fc.Arbitrary<unknown>> = {};
  for (const key of candidateKeys) {
    valueArbs[key] = valueArbForSchema(
      key,
      prompt.inferenceParameters[key],
      profile.numericRanges,
      model,
    );
  }

  // Pick an arbitrary subset of candidate keys, then materialise each
  // chosen key with its value arbitrary. The empty subset is allowed —
  // an empty `inferenceParameters` body is valid input.
  return fc.subarray(candidateKeys).chain((chosen) => {
    if (chosen.length === 0) {
      return fc.constant({});
    }
    const recordShape: Record<string, fc.Arbitrary<unknown>> = {};
    for (const key of chosen) {
      recordShape[key] = valueArbs[key];
    }
    return fc.record(recordShape);
  });
}
