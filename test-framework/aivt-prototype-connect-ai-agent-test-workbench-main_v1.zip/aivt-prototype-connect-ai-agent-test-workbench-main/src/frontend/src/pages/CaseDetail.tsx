/**
 * CaseDetail — per-case drill-down at `/runs/:runId/cases/:caseId`.
 *
 * Aggregates everything a tester needs to debug a single test case run:
 *
 *   - Overview: status, scores, tools invoked, latency, errors.
 *   - Transcript: chronological turn-by-turn record of the conversation.
 *   - Evaluation reasoning: the per-evaluator-unit detail captured by the
 *     Bedrock judge — one row per Converse call (1 GoalSuccessRate, N
 *     Helpfulness, M ToolSelectionAccuracy), with the rubric label,
 *     mapped score, and the judge's verbatim reasoning text.
 *
 * Backed by the existing GET /runs/{runId}/cases/{caseId} endpoint, which
 * returns the persisted `TestCaseResult` plus the recorded transcript.
 *
 * The page is suite-aware: navigates back to the run dashboard with the
 * `?suiteId=` query string preserved so the dashboard's by-id GET can
 * resolve an in-progress run record from the suite partition (see
 * `getRunByRunId` in `src/backend/handlers/results.ts`).
 */
import { useCallback, useEffect, useState } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import Container from '@cloudscape-design/components/container';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import Alert from '@cloudscape-design/components/alert';
import StatusIndicator from '@cloudscape-design/components/status-indicator';
import Spinner from '@cloudscape-design/components/spinner';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import Tabs from '@cloudscape-design/components/tabs';
import Badge from '@cloudscape-design/components/badge';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import Link from '@cloudscape-design/components/link';
import Table from '@cloudscape-design/components/table';
import { apiClient, ApiClientError } from '../api';
import type {
  TestCaseResult,
  TestCase,
  TestSuite,
  RagThresholds,
  TranscriptTurn,
  EvaluationCallDetail,
  ExecutionTrace,
  Recommendation,
  ToolSurface,
} from '../../../shared/types';
import { TimelineTranscript } from '../components/Transcript/TimelineTranscript';
import { DEFAULT_RAG_THRESHOLDS } from '../../../shared/types';
import { CaseStatus } from '../../../shared/enums';
import { formatDurationMs } from '../../../shared/utils/time-formatting';
import { bucketByTargetField } from '../../../shared/utils/recommendation-bucketing';

interface CaseDetailResponse {
  result: TestCaseResult;
  transcript: TranscriptTurn[];
  executionTrace?: ExecutionTrace;
}

/** Cloudscape badge for case status, reused from the run dashboard convention. */
function caseStatusIndicator(status: CaseStatus) {
  switch (status) {
    case CaseStatus.PASSED:
      return <StatusIndicator type="success">Passed</StatusIndicator>;
    case CaseStatus.FAILED:
      return <StatusIndicator type="error">Failed</StatusIndicator>;
    case CaseStatus.ERROR:
      return <StatusIndicator type="warning">Error</StatusIndicator>;
    case CaseStatus.TIMED_OUT:
      return <StatusIndicator type="warning">Timed out</StatusIndicator>;
    default:
      return <StatusIndicator type="info">{status}</StatusIndicator>;
  }
}

/** Format a `[0,1]` score for display. Returns `—` for missing values. */
function formatScore(value: number | undefined): string {
  if (value == null) return '—';
  return `${(value * 100).toFixed(1)}%`;
}

/** Short label for an evaluator family. */
function evaluatorLabel(evaluator: EvaluationCallDetail['evaluator']): string {
  switch (evaluator) {
    case 'Builtin.GoalSuccessRate':
      return 'Goal Success';
    case 'Builtin.Helpfulness':
      return 'Helpfulness';
    case 'Builtin.ToolSelectionAccuracy':
      return 'Tool Selection';
  }
}

/**
 * Group per-call detail by evaluator family, preserving call-order within
 * each family. The Lambda emits details in dispatch order (which is also
 * trace-chronological for Helpfulness and ToolSelectionAccuracy), so we
 * preserve that order rather than re-sorting by `index` — the natural
 * scan order is already what the user expects.
 */
function groupDetails(
  details: EvaluationCallDetail[],
): Record<EvaluationCallDetail['evaluator'], EvaluationCallDetail[]> {
  const out: Record<
    EvaluationCallDetail['evaluator'],
    EvaluationCallDetail[]
  > = {
    'Builtin.GoalSuccessRate': [],
    'Builtin.Helpfulness': [],
    'Builtin.ToolSelectionAccuracy': [],
  };
  for (const d of details) out[d.evaluator].push(d);
  return out;
}

// ---------------------------------------------------------------------------
// Per-case recommendations — wire types
// ---------------------------------------------------------------------------

/**
 * Per-case analysis as persisted under
 * `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` and returned in the
 * `caseAnalyses[]` array of {@link AnalyzeResponseWire}. Mirrors
 * `PerCaseAnalysis` in `src/backend/handlers/analysis.ts`.
 */
interface PerCaseAnalysisWire {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;
  recommendations: Recommendation[];
  generatedAt: string;
  modelId: string;
}

/**
 * Response body for `POST /runs/{runId}/analyze`. The Lambda's
 * persisted-read shortcut returns existing per-case records without
 * invoking Bedrock when `force` is not set (R6.2 / R11.1).
 */
interface AnalyzeResponseWire {
  caseAnalyses: PerCaseAnalysisWire[];
  generatedAt: string;
  modelId: string;
  /** Case IDs whose Bedrock analysis succeeded but DDB persistence failed (R6.6). */
  partialFailures?: string[];
}

// ---------------------------------------------------------------------------
// Per-case recommendations — display helpers
// ---------------------------------------------------------------------------

/** Human-readable label for a {@link ToolSurface} value. Mirrors the
 * label used by `RecommendedChangesPanel.tsx` and `FailureAnalysis.tsx`
 * so headers read the same way across all three surfaces. */
function targetFieldLabel(field: ToolSurface | string): string {
  switch (field) {
    case 'tool_description':
      return 'Tool Description';
    case 'tool_instruction':
      return 'Tool Instruction';
    case 'tool_examples':
      return 'Tool Examples';
    case 'system_prompt':
      return 'System Prompt';
    default:
      return String(field);
  }
}

/** Human-readable label for a snake_case root-cause category. */
function formatRootCauseCategory(category: string): string {
  return category
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

/**
 * Two-row diff with current text on a red-bordered light-red background
 * and suggested text on a green-bordered light-green background.
 * Styling matches the existing `DiffView` in `FailureAnalysis.tsx` and
 * `RecommendedChangesPanel.tsx` byte-for-byte (`#fdf0f0` / `#d91515`
 * for current, `#f2fcf3` / `#037f0c` for suggested) so the three
 * surfaces look like the same component to a user pivoting between
 * them.
 */
function RecommendationDiffView({
  recommendation,
}: {
  recommendation: Recommendation;
}): JSX.Element {
  return (
    <SpaceBetween size="xs">
      <Box variant="small">
        <strong>{targetFieldLabel(recommendation.targetField)}</strong>
        {recommendation.targetName !== 'system_prompt' && (
          <span style={{ marginLeft: '8px', color: '#5f6b7a' }}>
            ({recommendation.targetName})
          </span>
        )}
      </Box>
      <div
        style={{
          backgroundColor: '#fdf0f0',
          border: '1px solid #d91515',
          borderRadius: '4px',
          padding: '8px 12px',
          fontFamily: 'monospace',
          fontSize: '13px',
          whiteSpace: 'pre-wrap',
          wordBreak: 'break-word',
        }}
      >
        <Box variant="small" color="text-status-error">
          <strong>− Current</strong>
        </Box>
        {recommendation.currentText || (
          <Box variant="small" color="text-status-inactive">
            (empty)
          </Box>
        )}
      </div>
      <div
        style={{
          backgroundColor: '#f2fcf3',
          border: '1px solid #037f0c',
          borderRadius: '4px',
          padding: '8px 12px',
          fontFamily: 'monospace',
          fontSize: '13px',
          whiteSpace: 'pre-wrap',
          wordBreak: 'break-word',
        }}
      >
        <Box variant="small" color="text-status-success">
          <strong>+ Suggested</strong>
        </Box>
        {recommendation.suggestedText || (
          <Box variant="small" color="text-status-inactive">
            (empty)
          </Box>
        )}
      </div>
      {recommendation.rationale && (
        <Box variant="small" color="text-body-secondary">
          <em>Rationale: {recommendation.rationale}</em>
        </Box>
      )}
    </SpaceBetween>
  );
}

/**
 * Render the recommendations for a single case grouped by
 * {@link ToolSurface}. The bucketing helper is the shared pure util
 * from `src/shared/utils/recommendation-bucketing.ts` (task 4) — the
 * same util used by the Run Dashboard's Recommended_Changes_Panel and
 * the Failure Analysis View, so the per-case detail surface is a
 * structural projection of the persisted record (R7.1).
 */
function ToolSurfaceBuckets({
  recommendations,
}: {
  recommendations: Recommendation[];
}): JSX.Element {
  let buckets;
  try {
    buckets = bucketByTargetField(recommendations);
  } catch (err) {
    return (
      <Alert
        type="warning"
        statusIconAriaLabel="Warning"
        header="Malformed recommendations"
      >
        {err instanceof Error ? err.message : 'Unknown bucketing error.'}
      </Alert>
    );
  }
  // Render order matches the Recommended_Changes_Panel: system prompt
  // first (highest leverage / coarsest surface), then per-tool surfaces.
  const surfaces: ToolSurface[] = [
    'system_prompt',
    'tool_description',
    'tool_instruction',
    'tool_examples',
  ];
  const nonEmpty = surfaces.filter((s) => buckets[s].length > 0);
  if (nonEmpty.length === 0) {
    return (
      <Box variant="small" color="text-status-inactive">
        No specific recommendations generated for this failure.
      </Box>
    );
  }
  return (
    <SpaceBetween size="m">
      {nonEmpty.map((surface) => (
        <ExpandableSection
          key={surface}
          variant="footer"
          defaultExpanded
          headerText={`${targetFieldLabel(surface)} (${buckets[surface].length})`}
        >
          <SpaceBetween size="m">
            {buckets[surface].map((rec, idx) => (
              <RecommendationDiffView
                key={`${surface}-${idx}`}
                recommendation={rec}
              />
            ))}
          </SpaceBetween>
        </ExpandableSection>
      ))}
    </SpaceBetween>
  );
}

export function CaseDetail() {
  const { runId, caseId } = useParams<{ runId: string; caseId: string }>();
  const [searchParams] = useSearchParams();
  const suiteIdParam = searchParams.get('suiteId');
  const navigate = useNavigate();

  const [result, setResult] = useState<TestCaseResult | null>(null);
  const [transcript, setTranscript] = useState<TranscriptTurn[]>([]);
  const [executionTrace, setExecutionTrace] = useState<ExecutionTrace | null>(
    null,
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // ---------------------------------------------------------------------
  // Per-case recommendations state (R7.1, R7.2, R11.1)
  // ---------------------------------------------------------------------
  //
  // The page reads only persisted records — it never computes
  // recommendations independently (R11.1). The mount-time POST to
  // `/runs/{runId}/analyze` without `force` hits the Lambda's
  // persisted-read shortcut and returns the persisted record for this
  // case if it exists; otherwise the user can click "Generate
  // recommendations" which posts with `force: true` and triggers a
  // fresh analysis (R7.2).

  const [analysis, setAnalysis] = useState<PerCaseAnalysisWire | null>(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  /** True after the initial mount-time fetch completes (success or 200
   * with no record for this case). Used to decide between the
   * "Generate recommendations" CTA and the "no record yet" placeholder. */
  const [analysisFetched, setAnalysisFetched] = useState(false);
  /** Case IDs reported by the Lambda whose Bedrock analysis succeeded
   * but persistence failed (R6.6 / R12.5). Surfaced inline beneath the
   * recommendations when the current case is in the list. */
  const [partialFailures, setPartialFailures] = useState<string[]>([]);

  // ---------------------------------------------------------------------
  // RAG case data (R7.1–R7.8, R12.5, R12.9)
  // ---------------------------------------------------------------------
  // For RAG cases: fetch the test case definition (question, groundTruthAnswer)
  // and suite thresholds so the detail page can render the RAG render surface.

  const [testCase, setTestCase] = useState<TestCase | null>(null);
  const [ragThresholds, setRagThresholds] = useState<RagThresholds>(DEFAULT_RAG_THRESHOLDS);

  useEffect(() => {
    if (!runId || !caseId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    apiClient
      .get<CaseDetailResponse>(`/runs/${runId}/cases/${caseId}`)
      .then((response) => {
        if (cancelled) return;
        setResult(response.result);
        setTranscript(response.transcript ?? []);
        setExecutionTrace(response.executionTrace ?? null);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(
          err instanceof ApiClientError
            ? err.message
            : 'Failed to load case detail.',
        );
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [runId, caseId]);

  // Fetch test case definition and suite thresholds when we detect a RAG case.
  // Triggered once we have result data and it's a RAG case (or has ragMetrics).
  useEffect(() => {
    if (!result || !suiteIdParam || !caseId) return;
    const isRag = result.caseType === 'rag';
    const hasRagMetrics = !!result.ragMetrics;
    if (!isRag && !hasRagMetrics) return;

    let cancelled = false;

    // Fetch the test case definition (for question/groundTruthAnswer)
    if (isRag) {
      apiClient
        .get<TestCase>(`/suites/${suiteIdParam}/cases/${caseId}`)
        .then((tc) => {
          if (!cancelled) setTestCase(tc);
        })
        .catch(() => {
          // Non-critical — the page still renders metrics from TestCaseResult
        });
    }

    // Fetch suite for ragThresholds
    apiClient
      .get<TestSuite>(`/suites/${suiteIdParam}`)
      .then((suite) => {
        if (!cancelled) {
          setRagThresholds(suite.ragThresholds ?? DEFAULT_RAG_THRESHOLDS);
        }
      })
      .catch(() => {
        // Non-critical — fall back to default thresholds
      });

    return () => {
      cancelled = true;
    };
  }, [result, suiteIdParam, caseId]);

  /**
   * Fetch the per-case analysis. `force=false` hits the Lambda's
   * persisted-read shortcut and returns the persisted record without
   * invoking Bedrock (R6.2 / R11.1). `force=true` re-invokes Bedrock
   * for every failed case in the run (the endpoint does not currently
   * support a per-case filter, so the simplest equivalent is to force
   * full regeneration and pluck this case's entry from `caseAnalyses`).
   */
  const fetchAnalysis = useCallback(
    async (force: boolean): Promise<void> => {
      if (!runId || !caseId) return;
      setAnalysisLoading(true);
      setAnalysisError(null);
      try {
        const body: Record<string, unknown> = {};
        if (suiteIdParam) body.suiteId = suiteIdParam;
        if (force) body.force = true;
        const response = await apiClient.post<AnalyzeResponseWire>(
          `/runs/${runId}/analyze`,
          body,
        );
        const match =
          response.caseAnalyses.find((c) => c.caseId === caseId) ?? null;
        setAnalysis(match);
        setPartialFailures(response.partialFailures ?? []);
        setAnalysisFetched(true);
      } catch (err) {
        if (err instanceof ApiClientError) {
          setAnalysisError(err.message);
        } else {
          setAnalysisError('Failed to load recommendations.');
        }
      } finally {
        setAnalysisLoading(false);
      }
    },
    [runId, caseId, suiteIdParam],
  );

  // Mount-time fetch. Only run when the case is FAILED — for `passed`,
  // `error`, and `timed_out` the section is skipped entirely (R7.3) so
  // there's no point hitting the engine.
  useEffect(() => {
    if (!result || result.status !== CaseStatus.FAILED) return;
    void fetchAnalysis(false);
    // Run once per (runId, caseId, status=FAILED) tuple; fetchAnalysis
    // is stable via useCallback for these inputs.
  }, [result, fetchAnalysis]);

  // Build the link back to the run dashboard with the suiteId hint
  // preserved (the dashboard's `GET /runs/{runId}` needs it to resolve
  // an in-progress run record).
  const backToRunHref = suiteIdParam
    ? `/runs/${runId}?suiteId=${encodeURIComponent(suiteIdParam)}`
    : `/runs/${runId}`;

  if (loading) {
    return (
      <ContentLayout
        header={
          <Header variant="h1" description="Loading test case detail...">
            Test Case
          </Header>
        }
      >
        <Box textAlign="center" padding="l">
          <Spinner size="large" />
        </Box>
      </ContentLayout>
    );
  }

  if (error || !result) {
    return (
      <ContentLayout
        header={
          <Header
            variant="h1"
            actions={
              <Button variant="link" onClick={() => navigate(backToRunHref)}>
                Back to run
              </Button>
            }
          >
            Test Case
          </Header>
        }
      >
        <Alert type="error" header="Failed to load case detail">
          {error ?? 'Test case not found.'}
        </Alert>
      </ContentLayout>
    );
  }

  // ---------------------------------------------------------------------------
  // Overview tab — status, scores, tools, latency
  // ---------------------------------------------------------------------------

  // Determine if this is a RAG case
  const isRagCase = result.caseType === 'rag';

  // Determine if Faithfulness hard gate triggered (R6.4, R7.7)
  const faithfulnessHardGateTriggered =
    isRagCase &&
    result.status === CaseStatus.FAILED &&
    result.ragMetrics?.faithfulness != null &&
    result.ragMetrics.faithfulness < ragThresholds.faithfulness;

  // Agent's terminal response from transcript (last agent turn)
  const agentResponse = transcript.find((t) => t.role === 'agent')?.text ?? '—';

  // RAG evaluation error user-facing copy (R8.7)
  const ragErrorCopy: Record<string, string> = {
    RAG_JOB_FAILED: 'RAG evaluation failed. Re-run the suite or contact support.',
    RAG_JOB_TIMEOUT: 'RAG evaluation timed out after 30 minutes. Re-run the suite.',
    MALFORMED_RESULT: 'Bedrock returned an unparseable result for this case.',
    MISSING_EVALUATOR: 'Bedrock did not return a result for this case.',
  };

  // RAG render surface (R7.1–R7.8)
  const ragOverview = isRagCase ? (
    <SpaceBetween size="l">
      {/* Evaluation error alert with RAG-specific copy (R8.7) */}
      {result.evaluationError && (
        <Alert
          type="warning"
          header={`Evaluation: ${result.evaluationError.code}`}
        >
          {ragErrorCopy[result.evaluationError.code] ?? result.evaluationError.reason}
        </Alert>
      )}

      {/* Failed Faithfulness gate badge (R6.4, R7.7) */}
      {faithfulnessHardGateTriggered && (
        <Alert type="error" statusIconAriaLabel="Error">
          <Badge color="red">Failed Faithfulness gate</Badge>
          {' '}— The agent's response was not sufficiently grounded in the retrieved passages.
        </Alert>
      )}

      {/* Question section (R7.2) */}
      <Container header={<Header variant="h2">Question</Header>}>
        <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontFamily: 'inherit' }}>
          {testCase?.type === 'rag' ? testCase.question : '—'}
        </pre>
      </Container>

      {/* Agent's Answer section (R7.3) */}
      <Container header={<Header variant="h2">Agent&apos;s Answer</Header>}>
        <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontFamily: 'inherit' }}>
          {agentResponse}
        </pre>
      </Container>

      {/* Ground Truth section (R7.4) */}
      <Container header={<Header variant="h2">Ground Truth</Header>}>
        <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontFamily: 'inherit' }}>
          {testCase?.type === 'rag' ? testCase.groundTruthAnswer : '—'}
        </pre>
      </Container>

      {/* Metrics section (R7.5, R6.7) */}
      <Container header={<Header variant="h2">Metrics</Header>}>
        <Table
          variant="embedded"
          columnDefinitions={[
            { id: 'metric', header: 'Metric', cell: (item) => item.metric },
            { id: 'score', header: 'Score', cell: (item) => item.score },
            { id: 'threshold', header: 'Threshold', cell: (item) => item.threshold },
            {
              id: 'passFail',
              header: 'Pass/Fail',
              cell: (item) => (
                <StatusIndicator type={item.passed ? 'success' : 'error'}>
                  {item.passed ? 'Pass' : 'Fail'}
                </StatusIndicator>
              ),
            },
          ]}
          items={[
            {
              metric: 'Faithfulness',
              score: result.ragMetrics?.faithfulness != null ? result.ragMetrics.faithfulness.toFixed(3) : '—',
              threshold: ragThresholds.faithfulness.toFixed(3),
              passed: result.ragMetrics?.faithfulness != null && result.ragMetrics.faithfulness >= ragThresholds.faithfulness,
            },
            {
              metric: 'Correctness',
              score: result.ragMetrics?.correctness != null ? result.ragMetrics.correctness.toFixed(3) : '—',
              threshold: ragThresholds.correctness.toFixed(3),
              passed: result.ragMetrics?.correctness != null && result.ragMetrics.correctness >= ragThresholds.correctness,
            },
            {
              metric: 'Completeness',
              score: result.ragMetrics?.completeness != null ? result.ragMetrics.completeness.toFixed(3) : '—',
              threshold: ragThresholds.completeness.toFixed(3),
              passed: result.ragMetrics?.completeness != null && result.ragMetrics.completeness >= ragThresholds.completeness,
            },
            {
              metric: 'Helpfulness',
              score: result.ragMetrics?.helpfulness != null ? result.ragMetrics.helpfulness.toFixed(3) : '—',
              threshold: ragThresholds.helpfulness.toFixed(3),
              passed: result.ragMetrics?.helpfulness != null && result.ragMetrics.helpfulness >= ragThresholds.helpfulness,
            },
          ]}
        />
      </Container>

      {/* Retrieved Chunks panel (R7.6) */}
      <ExpandableSection
        variant="container"
        headerText={`Retrieved Chunks${result.retrievedChunks ? ` (${result.retrievedChunks.length})` : ''}`}
        defaultExpanded={false}
      >
        {(!result.retrievedChunks || result.retrievedChunks.length === 0) ? (
          <Box variant="p" color="text-status-inactive">
            No chunks were retrieved for this question.
          </Box>
        ) : (
          <SpaceBetween size="m">
            {result.retrievedChunks.map((chunk, idx) => (
              <div
                key={idx}
                style={{
                  background: '#f9f9f9',
                  border: '1px solid #e0e0e0',
                  borderRadius: 4,
                  padding: '12px',
                }}
              >
                <SpaceBetween size="xs">
                  {chunk.title && (
                    <Box variant="awsui-key-label">Title: {chunk.title}</Box>
                  )}
                  <pre
                    style={{
                      margin: 0,
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-word',
                      fontFamily: 'monospace',
                      fontSize: '13px',
                      background: '#ffffff',
                      border: '1px solid #eaeaea',
                      borderRadius: 4,
                      padding: '8px',
                    }}
                  >
                    {chunk.text}
                  </pre>
                  <SpaceBetween direction="horizontal" size="m">
                    {chunk.knowledgeBaseId && (
                      <Box variant="small" color="text-status-inactive">
                        KB: {chunk.knowledgeBaseId}
                      </Box>
                    )}
                    {chunk.contentId && (
                      <Box variant="small" color="text-status-inactive">
                        Content: {chunk.contentId}
                      </Box>
                    )}
                  </SpaceBetween>
                </SpaceBetween>
              </div>
            ))}
          </SpaceBetween>
        )}
      </ExpandableSection>

      {/* Status and duration overview */}
      <Container header={<Header variant="h2">Overview</Header>}>
        <ColumnLayout columns={2} variant="text-grid">
          <div>
            <Box variant="awsui-key-label">Status</Box>
            <div>{caseStatusIndicator(result.status)}</div>
          </div>
          <div>
            <Box variant="awsui-key-label">Duration</Box>
            <Box variant="p">{formatDurationMs(result.latencyMs)}</Box>
          </div>
          {result.sessionId && (
            <div>
              <Box variant="awsui-key-label">Session ID</Box>
              <Box variant="code" fontSize="body-s">
                {result.sessionId}
              </Box>
            </div>
          )}
        </ColumnLayout>
        {result.errorMessage && (
          <Box padding={{ top: 's' }}>
            <Alert type="error" header="Execution error">
              {result.errorMessage}
            </Alert>
          </Box>
        )}
      </Container>
    </SpaceBetween>
  ) : null;

  // Tool-sequence overview (existing)
  const overview = (
    <Container header={<Header variant="h2">Overview</Header>}>
      <ColumnLayout columns={2} variant="text-grid">
        <div>
          <Box variant="awsui-key-label">Status</Box>
          <div>{caseStatusIndicator(result.status)}</div>
        </div>
        <div>
          <Box variant="awsui-key-label">Duration</Box>
          <Box variant="p">{formatDurationMs(result.latencyMs)}</Box>
        </div>
        <div>
          <Box variant="awsui-key-label">Turns</Box>
          <Box variant="p">{result.turnCount}</Box>
        </div>
        <div>
          <Box variant="awsui-key-label">Tools Invoked</Box>
          <Box variant="p">{result.toolsInvoked.join(' → ') || '—'}</Box>
        </div>
        <div>
          <Box variant="awsui-key-label">Goal Success</Box>
          <Box variant="p">{formatScore(result.goalSuccessScore)}</Box>
        </div>
        <div>
          <Box variant="awsui-key-label">Helpfulness</Box>
          <Box variant="p">{formatScore(result.helpfulnessScore)}</Box>
        </div>
        <div>
          <Box variant="awsui-key-label">Tool Accuracy</Box>
          <Box variant="p">{formatScore(result.toolAccuracyScore)}</Box>
        </div>
        {result.sessionId && (
          <div>
            <Box variant="awsui-key-label">Session ID</Box>
            <Box variant="code" fontSize="body-s">
              {result.sessionId}
            </Box>
          </div>
        )}
      </ColumnLayout>
      {result.evaluationError && (
        <Box padding={{ top: 's' }}>
          <Alert
            type={
              result.evaluationError.code === 'INSUFFICIENT_TRACE'
                ? 'info'
                : 'warning'
            }
            header={`Evaluation: ${result.evaluationError.code}`}
          >
            {ragErrorCopy[result.evaluationError.code] ?? result.evaluationError.reason}
          </Alert>
        </Box>
      )}
      {result.errorMessage && (
        <Box padding={{ top: 's' }}>
          <Alert type="error" header="Execution error">
            {result.errorMessage}
          </Alert>
        </Box>
      )}
    </Container>
  );

  // ---------------------------------------------------------------------------
  // Transcript tab — delegated to the shared {@link TimelineTranscript}
  // component so this page and the Run Dashboard's expandable transcript
  // (`ResultsViewer.tsx`) render the same chronological customer ↔ agent
  // timeline (interleaved with reasoning steps and tool calls). Every
  // rendering invariant — dedup of agent transcript turns when a trace
  // is present, noise-span filtering, synthetic control-tool
  // parenthetical, args / result formatting — lives inside the shared
  // component. The page only owns the surrounding container chrome and
  // the trace-aware description copy.
  // ---------------------------------------------------------------------------

  const transcriptTab =
    transcript.length === 0 && !executionTrace ? (
      <Container header={<Header variant="h2">Transcript</Header>}>
        <TimelineTranscript transcript={transcript} executionTrace={executionTrace} />
      </Container>
    ) : (
      <Container
        header={
          <Header
            variant="h2"
            description={
              executionTrace
                ? `Customer ↔ agent exchange interleaved with the agent's reasoning and tool calls from ListSpans${executionTrace.aiAgentName ? ` (${executionTrace.aiAgentName})` : ''}.`
                : 'Customer ↔ agent message exchange. ListSpans data was not captured for this case, so the agent\'s per-step reasoning is unavailable.'
            }
          >
            Transcript
          </Header>
        }
      >
        <TimelineTranscript transcript={transcript} executionTrace={executionTrace} />
      </Container>
    );

  // ---------------------------------------------------------------------------
  // Evaluation reasoning tab — per-evaluator-unit detail
  // ---------------------------------------------------------------------------

  const reasoningTab = (() => {
    const details = result.evaluationDetails ?? [];
    if (details.length === 0) {
      return (
        <Container header={<Header variant="h2">Evaluation reasoning</Header>}>
          <Alert type="info" header="Reasoning not captured">
            This test case was scored before the per-evaluator drill-down
            was enabled, or the run was short-circuited (insufficient
            trace, missing snapshot) and no judge calls were made. Re-run
            the suite to capture per-evaluator reasoning.
          </Alert>
        </Container>
      );
    }
    const grouped = groupDetails(details);
    return (
      <SpaceBetween size="l">
        {(
          [
            'Builtin.GoalSuccessRate',
            'Builtin.Helpfulness',
            'Builtin.ToolSelectionAccuracy',
          ] as const
        ).map((evaluator) => {
          const entries = grouped[evaluator];
          if (entries.length === 0) return null;
          return (
            <Container
              key={evaluator}
              header={
                <Header
                  variant="h2"
                  description={`${entries.length} evaluator call${entries.length === 1 ? '' : 's'} · template: ${evaluator}`}
                >
                  {evaluatorLabel(evaluator)}
                </Header>
              }
            >
              <SpaceBetween size="m">
                {entries.map((detail) => {
                  const ok = detail.error == null;
                  return (
                    <div
                      key={`${detail.evaluator}-${detail.index}`}
                      style={{
                        borderLeft: `4px solid ${ok ? '#037f0c' : '#d91515'}`,
                        padding: '8px 12px',
                        background: '#fafafa',
                        borderRadius: 4,
                      }}
                    >
                      <SpaceBetween size="xs">
                        <SpaceBetween direction="horizontal" size="s">
                          <Badge color={ok ? 'green' : 'red'}>
                            {ok
                              ? `${detail.label ?? '—'} (${formatScore(detail.mappedValue)})`
                              : `Error: ${detail.error?.kind}`}
                          </Badge>
                          <Box variant="small" color="text-status-inactive">
                            {`Unit #${detail.index}`}
                          </Box>
                        </SpaceBetween>
                        {detail.reasoning && (
                          <Box variant="p">
                            <Box variant="awsui-key-label">Reasoning</Box>
                            {detail.reasoning}
                          </Box>
                        )}
                        {detail.error && !detail.reasoning && (
                          <Box variant="p" color="text-status-error">
                            {detail.error.message}
                          </Box>
                        )}
                      </SpaceBetween>
                    </div>
                  );
                })}
              </SpaceBetween>
            </Container>
          );
        })}
      </SpaceBetween>
    );
  })();

  // ---------------------------------------------------------------------------
  // Opportunistic Groundedness row for tool_sequence cases (R12.5, R12.9)
  // Shown beneath evaluation reasoning when a tool_sequence case has
  // ragMetrics.faithfulness (from opportunistic inline Converse check).
  // ---------------------------------------------------------------------------

  const groundednessRow = !isRagCase && result.ragMetrics?.faithfulness != null ? (
    <Container
      header={
        <Header
          variant="h2"
          description="Informational — this score does not affect the case's pass/fail status."
        >
          Groundedness
        </Header>
      }
    >
      <Table
        variant="embedded"
        columnDefinitions={[
          { id: 'metric', header: 'Metric', cell: (item) => item.metric },
          { id: 'score', header: 'Score', cell: (item) => item.score },
          { id: 'threshold', header: 'Threshold', cell: (item) => item.threshold },
          {
            id: 'passFail',
            header: 'Pass/Fail',
            cell: (item) => (
              <StatusIndicator type={item.passed ? 'success' : 'error'}>
                {item.passed ? 'Pass' : 'Fail'}
              </StatusIndicator>
            ),
          },
        ]}
        items={[
          {
            metric: 'Faithfulness',
            score: result.ragMetrics!.faithfulness!.toFixed(3),
            threshold: ragThresholds.faithfulness.toFixed(3),
            passed: result.ragMetrics!.faithfulness! >= ragThresholds.faithfulness,
          },
        ]}
      />
    </Container>
  ) : null;

  // ---------------------------------------------------------------------------
  // Recommendations section — only when status is FAILED (R7.1, R7.3)
  //
  // Reads only the persisted record (R11.1). The mount-time fetch posts
  // to /runs/{runId}/analyze without `force` so the Lambda's
  // persisted-read shortcut returns the cached record (or empty
  // `caseAnalyses` if no analysis has run yet for the run). When no
  // record exists for THIS case, surface a "Generate recommendations"
  // CTA that posts with `force: true` to trigger fresh analysis (R7.2).
  //
  // The endpoint does not currently accept a per-case filter, so the
  // simplest equivalent is to force regeneration for the entire run and
  // pluck this case's entry from the response. The cost of regenerating
  // unrelated cases is bounded by the number of failed cases in the
  // run, which is the same cost the Run Dashboard's
  // Recommended_Changes_Panel pays on its own Re-analyze.
  //
  // The section is skipped entirely for `passed`, `error`, and
  // `timed_out` statuses (R7.3) — those cases never have a persisted
  // analysis record.
  // ---------------------------------------------------------------------------

  const showRecommendations = result.status === CaseStatus.FAILED;

  /** Deep link to the Failure Analysis View with the case anchor
   * pre-selected so it remains the canonical full-detail surface
   * (R7.4). The Failure_Analysis_View renders inside ResultsViewer at
   * `/runs/{runId}/results`; the `case-{caseId}` hash lets that page
   * scroll to (or otherwise highlight) the relevant case if/when it
   * implements anchor navigation. */
  const fullAnalysisHref = `/runs/${runId}/results#case-${caseId}`;

  const partialFailureForThisCase =
    !!caseId && partialFailures.includes(caseId);

  const recommendationsSection = showRecommendations ? (
    <Container
      header={
        <Header
          variant="h2"
          description={
            analysis
              ? `Root cause: ${formatRootCauseCategory(analysis.rootCauseCategory)} · Generated ${new Date(analysis.generatedAt).toLocaleString()}`
              : 'AI-generated recommendations grouped by Tool_Surface (system prompt, tool description, tool instruction, tool examples).'
          }
          actions={
            // R7.2 — When no persisted record exists for this case yet,
            // a "Generate recommendations" CTA posts with `force: true`
            // to trigger fresh analysis. When a record already exists,
            // the same surface offers a "Re-analyze" affordance.
            analysisFetched && !analysisLoading ? (
              <Button
                variant={analysis ? 'normal' : 'primary'}
                iconName="refresh"
                onClick={() => void fetchAnalysis(true)}
              >
                {analysis ? 'Re-analyze' : 'Generate recommendations'}
              </Button>
            ) : undefined
          }
        >
          Recommendations
        </Header>
      }
    >
      <SpaceBetween size="m">
        {analysisLoading && (
          <Box textAlign="center" padding="l">
            <SpaceBetween size="s" alignItems="center">
              <Spinner size="large" />
              <Box variant="p">Loading recommendations…</Box>
            </SpaceBetween>
          </Box>
        )}

        {analysisError && !analysisLoading && (
          <Alert
            type="error"
            statusIconAriaLabel="Error"
            header="Failed to load recommendations"
            action={
              <Button onClick={() => void fetchAnalysis(false)}>Retry</Button>
            }
          >
            {analysisError}
          </Alert>
        )}

        {/* R12.5 — surface persistence partial failure for this case. */}
        {partialFailureForThisCase && (
          <Alert type="warning" statusIconAriaLabel="Warning">
            Per-case analysis succeeded but failed to persist for this case.
            The recommendations below were generated successfully but may not
            be available on the next page load.
          </Alert>
        )}

        {/* No persisted record for this case yet — surface a CTA. */}
        {!analysisLoading && !analysisError && analysisFetched && !analysis && (
          <Alert
            type="info"
            statusIconAriaLabel="Info"
            header="No recommendations yet"
            action={
              <Button
                variant="primary"
                onClick={() => void fetchAnalysis(true)}
              >
                Generate recommendations
              </Button>
            }
          >
            No persisted analysis exists for this case yet. Generating
            recommendations will analyze every failed case in this run with
            Bedrock and persist the result.
          </Alert>
        )}

        {analysis && !analysisLoading && (
          <SpaceBetween size="m">
            {/* Reasoning trace unavailability notice — mirrors
             * FailureAnalysis.tsx so the per-case projection reads the
             * same as the canonical full-detail view. */}
            {!analysis.traceAvailable && (
              <Alert type="info" statusIconAriaLabel="Info">
                Reasoning trace evidence was unavailable for this test case.
                Analysis is based on the conversation transcript and tool
                sequences only.
              </Alert>
            )}

            <div>
              <Box variant="awsui-key-label">Root Cause</Box>
              <SpaceBetween direction="horizontal" size="xs">
                <Badge color="blue">
                  {formatRootCauseCategory(analysis.rootCauseCategory)}
                </Badge>
              </SpaceBetween>
            </div>

            <div>
              <Box variant="awsui-key-label">Explanation</Box>
              <Box variant="p">{analysis.explanation}</Box>
            </div>

            <ToolSurfaceBuckets recommendations={analysis.recommendations} />
          </SpaceBetween>
        )}

        {/* R7.4 — deep link to the canonical Failure_Analysis_View. */}
        <Box textAlign="right">
          <Link href={fullAnalysisHref} external={false}>
            View full failure analysis ↗
          </Link>
        </Box>
      </SpaceBetween>
    </Container>
  ) : null;

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description={
            <SpaceBetween direction="horizontal" size="xs">
              <span>Run:</span>
              <Button
                variant="inline-link"
                onClick={() => navigate(backToRunHref)}
              >
                {runId}
              </Button>
              <Box variant="small" color="text-status-inactive">
                · Case: {caseId}
              </Box>
            </SpaceBetween>
          }
          actions={
            <Button variant="link" onClick={() => navigate(backToRunHref)}>
              Back to run
            </Button>
          }
        >
          Test Case Detail
        </Header>
      }
    >
      <Tabs
        tabs={[
          { id: 'overview', label: 'Overview', content: isRagCase ? ragOverview : overview },
          ...(!isRagCase ? [
            { id: 'transcript', label: 'Transcript', content: transcriptTab },
            {
              id: 'reasoning',
              label: 'Evaluation reasoning',
              content: (
                <SpaceBetween size="l">
                  {reasoningTab}
                  {groundednessRow}
                </SpaceBetween>
              ),
            },
          ] : []),
        ]}
      />
      {/* Recommendations section — rendered beneath the tabs, only when
       * the case is FAILED and is a tool_sequence case (R7.1, R7.3).
       * Sits below the Transcript and Evaluation Reasoning content per
       * the design's per-case projection of the canonical
       * Failure_Analysis_View. */}
      {!isRagCase && recommendationsSection && (
        <Box padding={{ top: 'l' }}>{recommendationsSection}</Box>
      )}
    </ContentLayout>
  );
}

