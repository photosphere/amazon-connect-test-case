/**
 * `failure_analysis` — system prompt for the Bedrock Converse call inside
 * `POST /runs/{runId}/analyze` (per-case failure root-cause analysis).
 * The user message (transcript, reasoning trace, tool surfaces, system
 * prompt, response-schema instructions) is built by
 * `buildAnalysisPrompt`; the registered prompt is the literal `system`
 * block lifted byte-for-byte from `src/backend/handlers/analysis.ts`'s
 * `analyzeFailure` call.
 *
 * Version history:
 *   v1 — original system prompt (no reasoning awareness).
 *   v2 — updated to document the `## Reasoning trace` section the user
 *         message now includes when inference steps carry reasoning
 *         (trace-reasoning-and-latency, R9.5).
 *   v3 — updated to reference the `## Test Case Definition` section,
 *         `test_case_defect` root cause category, Sound Decision Signal
 *         detection, and `test_case` recommendation target with
 *         `testCaseField` (test-case-validity-analysis, R2.2, R5.1,
 *         R9.1, R9.4).
 *
 * @module backend/orchestration/prompt-registry/prompts/failure-analysis
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

/**
 * v1 — original `defaultText`. Retained for rollback documentation.
 */
export const PRIOR_DEFAULT_TEXT_V1 =
  "You are an expert at diagnosing AI agent failures. Analyze the provided test case data and produce structured root cause analysis with actionable recommendations. Always respond with valid JSON matching the requested schema.";

/**
 * v2 — prior `defaultText` reflecting the reasoning-trace section added
 * to the user message by `buildAnalysisPrompt` (trace-reasoning-and-latency
 * feature, Requirement 9.5). The user message now includes a
 * `## Reasoning trace` section when inference steps carry reasoning,
 * providing the agent's chain-of-thought alongside the transcript and tool
 * sequences. Retained for rollback capability.
 */
export const PRIOR_DEFAULT_TEXT =
  "You are an expert at diagnosing AI agent failures. Analyze the provided test case data and produce structured root cause analysis with actionable recommendations. The user message may include a ## Reasoning trace section containing the agent's chain-of-thought reasoning for inference steps — use this to determine whether the agent misunderstood the goal, picked the wrong tool, hallucinated a constraint, or was misled by the system prompt. Always respond with valid JSON matching the requested schema.";

/**
 * v3 — active `defaultText` for test-case-validity-analysis feature.
 *
 * Additions over v2:
 *   - References the `## Test Case Definition` section now included in the
 *     user message (name, persona, initial utterance, success criteria,
 *     customer knowledge, goal description).
 *   - Introduces `test_case_defect` as a valid root cause category for when
 *     the agent's reasoning trace shows it made a correct decision but the
 *     test case expected otherwise.
 *   - Instructs Sound Decision Signal detection: compare the reasoning trace
 *     against the test case's success criteria looking for evidence the agent
 *     deliberately refused an expected tool based on instructions, safety
 *     guardrails, missing prerequisites, or ambiguity.
 *   - Introduces `test_case` as a valid recommendation target with a required
 *     `testCaseField` sub-property identifying which test case field to edit.
 *   - Constrains at most one `test_case` recommendation per failed case.
 */
const DEFAULT_TEXT =
  "You are an expert at diagnosing AI agent failures. Analyze the provided test case data and produce structured root cause analysis with actionable recommendations. " +
  "The user message includes a ## Test Case Definition section containing the test case's name, persona, initial utterance, success criteria, customer knowledge, and goal description — use this to evaluate whether the test case's expectations are reasonable given the agent's configuration. " +
  "The user message may also include a ## Reasoning trace section containing the agent's chain-of-thought reasoning for inference steps — use this to determine whether the agent misunderstood the goal, picked the wrong tool, hallucinated a constraint, or was misled by the system prompt. " +
  "When performing Sound Decision Signal detection, compare the agent's reasoning trace against the test case's success criteria. If the trace shows the agent deliberately chose not to invoke an expected tool because (a) its instructions prohibit the action, (b) safety or compliance guardrails apply, (c) prerequisite information was missing from the persona or session, or (d) ambiguity required clarification before acting — and that decision conflicts with a required tool in the success criteria — classify the root cause as test_case_defect rather than blaming the agent. " +
  "The valid root cause categories include test_case_defect for cases where the agent was correct but the test expectations are unreasonable, contradictory, or impossible. Prefer test_case_defect over other when the reasoning trace provides clear evidence; default to an agent-deficiency category when uncertain. " +
  "When recommending changes, the valid targetField values include test_case for recommending edits to the test case itself. A test_case recommendation must include a testCaseField property (one of: successCriteria, initialUtterance, persona, customerKnowledge, goalDescription) and is only valid when the root cause is test_case_defect. Produce at most one test_case recommendation per case. " +
  "Always respond with valid JSON matching the requested schema.";

export const failureAnalysisPrompt: PromptDefinition = {
  promptKey: "failure_analysis",
  name: "Failure Analysis — Per-Case Root Cause",
  description:
    "System prompt for the Converse call that diagnoses why a single failed test case failed and emits structured per-case recommendations.",
  category: "analysis",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 4_096 },
  },
  defaultInferenceValues: {
    maxTokens: 4_096,
  },
};
