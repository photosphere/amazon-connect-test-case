/**
 * Runtime Prompt resolution helpers — the only entry points
 * Bedrock_Callsites use to fetch their effective prompt at invocation
 * time. The pure {@link resolvePrompt} resolver in `resolver.ts` is the
 * underlying primitive; this module wraps it with the I/O the callsites
 * actually need: a per-warm DynamoDB read of the run-pinned
 * {@link AgentSnapshot}, a per-warm read (with a short TTL) of the live
 * Prompts_Store, and the structured fail-closed error
 * {@link PromptResolutionError} that callsites surface when neither path
 * can resolve.
 *
 * Two functions are exposed:
 *
 *   - {@link resolvePromptForRun} — used inside a Step Functions
 *     execution. Reads the run's `AgentSnapshot.prompts` map first
 *     (R11.2). Falls back to the live registry when the snapshot lacks
 *     a `prompts` field (a snapshot persisted before this feature
 *     shipped — R11.4 / R16.2) or when the run-start capture didn't pin
 *     the requested `promptKey` (e.g. a new prompt added in a redeploy
 *     between the run starting and the callsite executing). Throws
 *     {@link PromptResolutionError} when both the snapshot path and the
 *     live fallback fail (R16.3).
 *
 *   - {@link resolvePromptLive} — used outside any run scope (the four
 *     interactive endpoints `POST /scaffold` × 2, `POST /comparison-summary`,
 *     `POST /suite-recommend`, `POST /failure-analysis`, and the Prompts
 *     handler's dry-render check). Reads the live override store via
 *     {@link DynamoDBService.listPromptOverrides} and runs the pure
 *     resolver. Throws {@link PromptResolutionError} when the store read
 *     fails.
 *
 * Caching posture:
 *
 *   - The snapshot read is cached per Lambda warm keyed by `runId`. A
 *     snapshot is immutable for the lifetime of a run, so caching it
 *     once is correct; the worst case is a Lambda warm that outlives a
 *     run, which is harmless because the next run starts a new `runId`.
 *   - The live-override read is cached for ≤30 seconds to avoid
 *     hammering DynamoDB during a Map iteration over hundreds of cases
 *     in a single Lambda warm. The TTL is short enough that a freshly
 *     persisted edit propagates to the next run within one cache-cycle
 *     and far longer than the duration of any single run iteration.
 *
 * Both caches fail closed on read errors: when the underlying DynamoDB
 * read throws, this module never substitutes a previously cached value
 * to keep the call going. It surfaces a {@link PromptResolutionError}
 * so the callsite can abort the Bedrock invocation and the run records
 * the case as `error` rather than silently emitting an empty or stale
 * prompt to the model (R16.3 fail-closed).
 *
 * Test injection: {@link _setPromptStore} swaps the underlying
 * {@link DynamoDBService} for an in-memory double; {@link _clearCaches}
 * resets the per-warm caches between test cases. Both are intentionally
 * `@internal` — production callers SHALL go through
 * {@link resolvePromptForRun} or {@link resolvePromptLive}.
 *
 * @module backend/orchestration/prompt-registry/runtime
 */

import type { AgentSnapshot, ResolvedPromptSnapshot } from "../../../shared/types";
import { dynamoDBService, DynamoDBService } from "../../services/dynamodb";
import {
  CAPABILITY_PROFILES,
  resolvePrompt,
  UnknownPromptKeyError,
  type PromptKey,
  type PromptOverride,
  type ResolvedPrompt,
} from "./index";

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/**
 * Thrown when neither the run-pinned snapshot path nor the live
 * Prompts_Store fallback can resolve the requested `promptKey`. Distinct
 * from {@link UnknownPromptKeyError} (which is a programming error
 * indicating the registry doesn't recognise the key at all) so callsites
 * can pattern-match on the type and surface the failure to their caller
 * with the right severity (R16.3 fail-closed).
 *
 * The error preserves the offending `promptKey` and (when known) the
 * `runId` of the run whose snapshot read failed, so log records can
 * name them without the caller having to capture them from local
 * scope. The originating cause (a DynamoDB error, a JSON parse error, a
 * stale-placeholder fallback that itself threw) is attached via the
 * standard `cause` slot.
 */
export class PromptResolutionError extends Error {
  /** Make the error nominally distinct from plain `Error` instances. */
  public readonly name = "PromptResolutionError";

  /** The `promptKey` value that could not be resolved. */
  public readonly promptKey: string;

  /**
   * The `runId` whose snapshot read failed, when the failure originated
   * from {@link resolvePromptForRun}. Absent for failures originating in
   * {@link resolvePromptLive} where there is no surrounding run scope.
   */
  public readonly runId?: string;

  public constructor(
    promptKey: string,
    message: string,
    options: { runId?: string; cause?: unknown } = {},
  ) {
    super(message);
    this.promptKey = promptKey;
    if (options.runId !== undefined) {
      this.runId = options.runId;
    }
    if (options.cause !== undefined) {
      // ES2022 `Error.cause` is supported by the Node 20 runtime the
      // platform's Lambdas execute under; assigning it through a typed
      // index keeps this compatible with older lib targets that don't
      // declare the `cause` field on `Error`.
      (this as Error & { cause?: unknown }).cause = options.cause;
    }
    Object.setPrototypeOf(this, PromptResolutionError.prototype);
  }
}

// ---------------------------------------------------------------------------
// Module-level state (per-Lambda-warm caches + test-injected store)
// ---------------------------------------------------------------------------

/** Per-warm TTL for the live override cache. Short enough that a fresh
 *  edit propagates to the next run quickly, long enough that a Map
 *  iteration over hundreds of cases inside a single run does not hammer
 *  DynamoDB on every callsite invocation. */
const LIVE_OVERRIDE_TTL_MS = 30_000;

/**
 * Snapshot cache keyed by `runId`. A snapshot is immutable for the
 * lifetime of a run, so caching the result of a single
 * {@link DynamoDBService.getSnapshot} read is always correct. We cache
 * `null` results too (the snapshot does not exist) so a missing
 * snapshot does not trigger repeated DDB reads inside one warm — the
 * fallback to {@link resolvePromptLive} short-circuits without re-reading.
 */
let snapshotCache: Map<string, AgentSnapshot | null> = new Map();

/**
 * Live-override cache. `null` when no read has happened yet on this
 * warm; a `{ overrides, expiresAt }` record after a successful read.
 * The `expiresAt` field is an absolute `Date.now()` epoch millisecond
 * value so the freshness check is a single integer comparison.
 */
let liveOverrideCache:
  | { overrides: ReadonlyMap<PromptKey, PromptOverride>; expiresAt: number }
  | null = null;

/**
 * Test-injected {@link DynamoDBService}. `null` in production where the
 * module-singleton {@link dynamoDBService} is used. Tests pass an
 * in-memory double via {@link _setPromptStore} so unit tests can
 * exercise both the snapshot-first and the live-fallback paths without
 * a DynamoDB Local container.
 */
let injectedStore: DynamoDBService | null = null;

/**
 * Resolve the {@link DynamoDBService} the runtime helpers delegate
 * their reads to. Tests can swap the store via {@link _setPromptStore};
 * production always reaches the module-singleton.
 */
function getStore(): DynamoDBService {
  return injectedStore ?? dynamoDBService;
}

// ---------------------------------------------------------------------------
// Run-scoped resolver — `resolvePromptForRun`
// ---------------------------------------------------------------------------

/**
 * Resolve `promptKey` for a Bedrock_Callsite executing inside the
 * scope of a run. The resolution algorithm:
 *
 *   1. Read the run's {@link AgentSnapshot} (per-warm cached by
 *      `runId`). If the snapshot carries a `prompts.{promptKey}` entry,
 *      shape it as a {@link ResolvedPrompt} and return — the run is
 *      pinned to that triple per R11.2.
 *   2. Otherwise fall back to {@link resolvePromptLive}. This covers
 *      three cases: snapshot reads that throw (DDB unreachable
 *      mid-run), pre-feature snapshots that have no `prompts` field
 *      (R11.4 / R16.2), and post-feature snapshots that pinned a
 *      narrower set of `promptKey` values than the callsite is asking
 *      for (e.g. a new prompt added in a redeploy between run start
 *      and callsite execution).
 *   3. If the live fallback also fails, throw
 *      {@link PromptResolutionError} carrying both the originating
 *      cause and the `runId` so the case errors out cleanly (R16.3).
 *
 * {@link UnknownPromptKeyError} thrown by the underlying resolver is
 * re-thrown unchanged: that error indicates the registry doesn't
 * recognise the `promptKey` at all, which is a programming error
 * orthogonal to the fail-closed semantics.
 *
 * @param promptKey — the registered prompt to resolve.
 * @param runId     — the run whose snapshot to consult.
 * @returns the resolved prompt ready to feed to `buildInferenceConfig`
 *          and the Bedrock Converse call.
 * @throws {PromptResolutionError} when both the snapshot path and the
 *          live fallback fail.
 * @throws {UnknownPromptKeyError} when `promptKey` is not registered.
 */
export async function resolvePromptForRun(
  promptKey: PromptKey,
  runId: string,
): Promise<ResolvedPrompt> {
  let snapshot: AgentSnapshot | null = null;
  let snapshotError: unknown = null;

  if (snapshotCache.has(runId)) {
    snapshot = snapshotCache.get(runId) ?? null;
  } else {
    try {
      snapshot = await getStore().getSnapshot(runId);
      // Cache the read regardless of whether the snapshot exists so a
      // missing-snapshot result doesn't cost a DDB read on every
      // callsite invocation in this warm.
      snapshotCache.set(runId, snapshot);
    } catch (err) {
      // Don't cache the error — the next call within this warm should
      // get a chance to retry the snapshot read in case the failure was
      // transient. The live fallback below covers this invocation.
      snapshotError = err;
      console.warn(
        `[prompt-registry/runtime] Snapshot read failed for runId="${runId}"; falling back to live registry`,
        err,
      );
    }
  }

  // Snapshot-first: if the snapshot pinned this promptKey, return it
  // shaped as a ResolvedPrompt without consulting the live store.
  const pinned: ResolvedPromptSnapshot | undefined =
    snapshot?.prompts?.[promptKey];
  if (pinned !== undefined) {
    return {
      promptKey,
      text: pinned.text,
      modelKey: pinned.modelKey,
      modelId: pinned.modelId,
      inferenceParameters: pinned.inferenceParameters,
      version: pinned.version,
      capabilityProfile: CAPABILITY_PROFILES[pinned.capabilityProfileKey],
    };
  }

  // Emit a structured info log naming the reason we fell through to the
  // live registry — pre-feature snapshot, missing key, or missing
  // snapshot. Snapshot-read errors already logged a warning above.
  if (snapshotError === null) {
    if (snapshot === null) {
      console.info(
        `[prompt-registry/runtime] No snapshot found for runId="${runId}"; falling back to live registry for promptKey="${promptKey}"`,
      );
    } else if (snapshot.prompts === undefined) {
      console.info(
        `[prompt-registry/runtime] Snapshot for runId="${runId}" predates the prompt-management feature (no prompts field); falling back to live registry for promptKey="${promptKey}"`,
      );
    } else {
      console.info(
        `[prompt-registry/runtime] Snapshot for runId="${runId}" has prompts map but no entry for promptKey="${promptKey}"; falling back to live registry`,
      );
    }
  }

  try {
    return await resolvePromptLive(promptKey);
  } catch (liveErr) {
    // UnknownPromptKeyError is a programming error orthogonal to the
    // fail-closed contract — re-throw it unchanged so callsites can
    // surface the right severity.
    if (liveErr instanceof UnknownPromptKeyError) {
      throw liveErr;
    }
    // Both paths failed — fail closed per R16.3. Prefer the live error
    // as the cause because it represents the most recent attempt; the
    // snapshot error (if any) is informational at this point.
    throw new PromptResolutionError(
      promptKey,
      `Failed to resolve promptKey="${promptKey}" for runId="${runId}" via both the run snapshot and the live override store`,
      { runId, cause: liveErr },
    );
  }
}

// ---------------------------------------------------------------------------
// Live resolver — `resolvePromptLive`
// ---------------------------------------------------------------------------

/**
 * Resolve `promptKey` against the live Prompts_Store. Used by every
 * Bedrock_Callsite that executes outside a run scope (the four
 * interactive endpoints) and by the fallback path in
 * {@link resolvePromptForRun}.
 *
 * Reads {@link DynamoDBService.listPromptOverrides} on first invocation
 * per warm, then caches the result for {@link LIVE_OVERRIDE_TTL_MS}
 * milliseconds so a Map iteration over many promptKeys in one warm
 * does not hit DynamoDB once per key. The cached map is never returned
 * after expiry — when the cached entry is stale, this function fetches
 * a fresh map and replaces the cache.
 *
 * Fail-closed (R16.3): if the underlying read throws, the cache is
 * reset and {@link PromptResolutionError} is raised. The function
 * never substitutes a previously cached value to keep the call going.
 *
 * {@link UnknownPromptKeyError} from the pure resolver propagates
 * unchanged.
 *
 * @param promptKey — the registered prompt to resolve.
 * @returns the resolved prompt ready to feed to `buildInferenceConfig`
 *          and the Bedrock Converse call.
 * @throws {PromptResolutionError} when the override-store read fails.
 * @throws {UnknownPromptKeyError} when `promptKey` is not registered.
 */
export async function resolvePromptLive(
  promptKey: PromptKey,
): Promise<ResolvedPrompt> {
  const now = Date.now();
  let overrides: ReadonlyMap<PromptKey, PromptOverride>;

  if (liveOverrideCache !== null && liveOverrideCache.expiresAt > now) {
    overrides = liveOverrideCache.overrides;
  } else {
    try {
      overrides = await getStore().listPromptOverrides();
    } catch (err) {
      // Fail closed: drop any prior cached value rather than serving a
      // stale read after a failure. The next caller within this warm
      // will retry the read; if DynamoDB is durably unreachable, every
      // caller gets a PromptResolutionError, which is the correct
      // signal under R16.3.
      liveOverrideCache = null;
      throw new PromptResolutionError(
        promptKey,
        `Failed to read live prompt-override store while resolving promptKey="${promptKey}"`,
        { cause: err },
      );
    }
    liveOverrideCache = {
      overrides,
      expiresAt: now + LIVE_OVERRIDE_TTL_MS,
    };
  }

  // resolvePrompt may throw UnknownPromptKeyError; that propagates
  // naturally to the caller. Stale-placeholder fallback inside the
  // resolver is silent here — it logs a warning and returns the
  // bundled default with version=0, exactly as a fresh registry read
  // would.
  return resolvePrompt(promptKey, overrides);
}

// ---------------------------------------------------------------------------
// Test-only helpers
// ---------------------------------------------------------------------------

/**
 * Replace the {@link DynamoDBService} the runtime helpers delegate
 * their reads to. Pass `null` to revert to the production singleton.
 *
 * @internal — production callers SHALL go through
 *   {@link resolvePromptForRun} / {@link resolvePromptLive}.
 */
export function _setPromptStore(store: DynamoDBService | null): void {
  injectedStore = store;
}

/**
 * Reset the per-warm caches. Called between test cases so a stale
 * snapshot or override cache from one test does not bleed into the
 * next.
 *
 * @internal
 */
export function _clearCaches(): void {
  snapshotCache = new Map();
  liveOverrideCache = null;
}
