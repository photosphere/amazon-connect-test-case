/**
 * Unit tests for the Suite CRUD Lambda handler.
 *
 * Tests route handling, validation, and response structure using a mocked
 * DynamoDB service layer.
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import { handler, _setDBService, type APIGatewayEvent } from "../../src/backend/handlers/suites";
import { DynamoDBService } from "../../src/backend/services/dynamodb";
import type { TestSuite, TestCase, AgentSummary } from "../../src/shared/types";
import { CommunicationStyle } from "../../src/shared/enums";
import { listAgents } from "../../src/backend/handlers/discovery";

// ---------------------------------------------------------------------------
// Mock discovery module — listSuites calls listAgents() to enrich suites with
// resolved agent names. We control its behavior per-test.
// ---------------------------------------------------------------------------

vi.mock("../../src/backend/handlers/discovery", () => ({
  listAgents: vi.fn(),
}));

const mockListAgents = vi.mocked(listAgents);

function makeAgent(overrides: Partial<AgentSummary> = {}): AgentSummary {
  return {
    agentId: "agent-xyz",
    name: "Customer Support Agent",
    type: "ORCHESTRATION",
    toolCount: 3,
    modelId: "anthropic.claude-3-sonnet",
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Mock DynamoDB service
// ---------------------------------------------------------------------------

function createMockDBService(): {
  service: DynamoDBService;
  mocks: Record<string, ReturnType<typeof vi.fn>>;
} {
  const mocks = {
    createSuite: vi.fn().mockResolvedValue(undefined),
    getSuite: vi.fn().mockResolvedValue(null),
    updateSuite: vi.fn().mockResolvedValue(undefined),
    deleteSuite: vi.fn().mockResolvedValue(undefined),
    listSuites: vi.fn().mockResolvedValue([]),
    createCase: vi.fn().mockResolvedValue(undefined),
    getCase: vi.fn().mockResolvedValue(null),
    updateCase: vi.fn().mockResolvedValue(undefined),
    deleteCase: vi.fn().mockResolvedValue(undefined),
    listCases: vi.fn().mockResolvedValue([]),
  };

  return { service: mocks as unknown as DynamoDBService, mocks };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const TENANT_ID = "tenant-abc-123";

function makeEvent(overrides: Partial<APIGatewayEvent>): APIGatewayEvent {
  return {
    httpMethod: "GET",
    resource: "/suites",
    pathParameters: null,
    body: null,
    requestContext: {
      authorizer: {
        claims: { sub: TENANT_ID },
      },
    },
    ...overrides,
  };
}

function makeSuite(overrides: Partial<TestSuite> = {}): TestSuite {
  return {
    tenantId: TENANT_ID,
    suiteId: "suite-001",
    name: "My Test Suite",
    description: "A test suite description",
    agentId: "agent-xyz",
    assistantId: "assistant-abc",
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
    ...overrides,
  };
}

function makeTestCase(overrides: Partial<TestCase> = {}): TestCase {
  return {
    type: "tool_sequence",
    suiteId: "suite-001",
    caseId: "case-001",
    name: "Test Case 1",
    description: "A test case description",
    persona: "Friendly customer",
    style: CommunicationStyle.DIRECT,
    customerKnowledge: { accountId: "12345" },
    initialUtterance: "I need help with my account",
    successCriteria: [{ toolName: "AuthenticateUser", required: true }],
    ...overrides,
  } as TestCase;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("Suite CRUD Lambda", () => {
  let mockDB: ReturnType<typeof createMockDBService>;

  beforeEach(() => {
    mockDB = createMockDBService();
    _setDBService(mockDB.service);
    mockListAgents.mockReset();
    mockListAgents.mockResolvedValue([]);
  });

  describe("Authentication", () => {
    it("returns 401 when no tenant ID in claims", async () => {
      const event = makeEvent({
        requestContext: { authorizer: { claims: {} } },
      });
      const result = await handler(event);
      expect(result.statusCode).toBe(401);
      expect(JSON.parse(result.body).error).toContain("Unauthorized");
    });

    it("returns 401 when authorizer is missing", async () => {
      const event = makeEvent({
        requestContext: {},
      });
      const result = await handler(event);
      expect(result.statusCode).toBe(401);
    });
  });

  describe("OPTIONS (CORS preflight)", () => {
    it("returns 200 for OPTIONS requests", async () => {
      const event = makeEvent({ httpMethod: "OPTIONS" });
      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      expect(result.headers["Access-Control-Allow-Origin"]).toBe("*");
    });
  });

  describe("POST /suites — Create Suite", () => {
    it("creates a suite with valid input", async () => {
      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites",
        body: JSON.stringify({ name: "New Suite", agentId: "agent-123" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(201);

      const body = JSON.parse(result.body);
      expect(body.name).toBe("New Suite");
      expect(body.agentId).toBe("agent-123");
      expect(body.tenantId).toBe(TENANT_ID);
      expect(body.suiteId).toBeDefined();
      expect(body.createdAt).toBeDefined();
      expect(body.updatedAt).toBeDefined();
      expect(mockDB.mocks.createSuite).toHaveBeenCalledOnce();
    });

    it("returns 400 when name is missing", async () => {
      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites",
        body: JSON.stringify({ agentId: "agent-123" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.error).toBe("Validation failed");
      expect(body.details).toBeDefined();
      expect(body.details.some((e: { field: string }) => e.field === "name")).toBe(true);
    });

    it("returns 400 when agentId is missing", async () => {
      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites",
        body: JSON.stringify({ name: "Suite" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.details.some((e: { field: string }) => e.field === "agentId")).toBe(true);
    });

    it("returns 400 for invalid JSON body", async () => {
      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites",
        body: "not json",
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
      expect(JSON.parse(result.body).error).toContain("Invalid JSON");
    });

    it("returns 400 when body is empty", async () => {
      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites",
        body: null,
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
    });

    it("returns 400 when name exceeds 128 characters", async () => {
      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites",
        body: JSON.stringify({ name: "x".repeat(129), agentId: "agent-123" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
    });
  });

  describe("GET /suites — List Suites", () => {
    it("returns empty array when no suites", async () => {
      const event = makeEvent({ httpMethod: "GET", resource: "/suites" });

      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      expect(JSON.parse(result.body)).toEqual({ suites: [] });
      expect(mockDB.mocks.listSuites).toHaveBeenCalledWith(TENANT_ID);
    });

    it("returns list of suites", async () => {
      const suites = [makeSuite({ suiteId: "s1" }), makeSuite({ suiteId: "s2" })];
      mockDB.mocks.listSuites.mockResolvedValue(suites);

      const event = makeEvent({ httpMethod: "GET", resource: "/suites" });
      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      expect(JSON.parse(result.body).suites).toHaveLength(2);
    });

    it("calls listAgents and enriches each suite with the resolved agentName", async () => {
      mockDB.mocks.listSuites.mockResolvedValue([
        makeSuite({ suiteId: "s1", agentId: "agent-xyz" }),
        makeSuite({ suiteId: "s2", agentId: "agent-other" }),
      ]);
      mockListAgents.mockResolvedValue([
        makeAgent({ agentId: "agent-xyz", name: "Customer Support Agent" }),
        makeAgent({ agentId: "agent-other", name: "Billing Agent" }),
      ]);

      const event = makeEvent({ httpMethod: "GET", resource: "/suites" });
      const result = await handler(event);

      expect(result.statusCode).toBe(200);
      expect(mockListAgents).toHaveBeenCalledOnce();

      const { suites } = JSON.parse(result.body);
      expect(suites).toHaveLength(2);
      expect(suites[0].agentName).toBe("Customer Support Agent");
      expect(suites[1].agentName).toBe("Billing Agent");
      // The original agentId is preserved alongside the resolved name.
      expect(suites[0].agentId).toBe("agent-xyz");
      expect(suites[1].agentId).toBe("agent-other");
    });

    it("falls back to agentId for suites whose agent is not in the listing", async () => {
      mockDB.mocks.listSuites.mockResolvedValue([
        makeSuite({ suiteId: "s1", agentId: "agent-xyz" }),
        makeSuite({ suiteId: "s2", agentId: "agent-deleted" }),
      ]);
      mockListAgents.mockResolvedValue([
        makeAgent({ agentId: "agent-xyz", name: "Customer Support Agent" }),
      ]);

      const event = makeEvent({ httpMethod: "GET", resource: "/suites" });
      const result = await handler(event);

      expect(result.statusCode).toBe(200);
      const { suites } = JSON.parse(result.body);
      expect(suites[0].agentName).toBe("Customer Support Agent");
      // Unresolvable agentId falls back to the literal agentId value.
      expect(suites[1].agentName).toBe("agent-deleted");
    });

    it("renders the page with agentName=agentId fallback when listAgents throws", async () => {
      const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
      mockDB.mocks.listSuites.mockResolvedValue([
        makeSuite({ suiteId: "s1", agentId: "agent-xyz" }),
        makeSuite({ suiteId: "s2", agentId: "agent-abc" }),
      ]);
      mockListAgents.mockRejectedValue(new Error("Q in Connect unavailable"));

      const event = makeEvent({ httpMethod: "GET", resource: "/suites" });
      const result = await handler(event);

      // The page still renders (200) despite the agent service being down.
      expect(result.statusCode).toBe(200);
      const { suites } = JSON.parse(result.body);
      expect(suites).toHaveLength(2);
      // Every suite falls back to its agentId as the agentName.
      expect(suites[0].agentName).toBe("agent-xyz");
      expect(suites[1].agentName).toBe("agent-abc");
      expect(warnSpy).toHaveBeenCalled();

      warnSpy.mockRestore();
    });
  });

  describe("GET /suites/{suiteId} — Get Suite", () => {
    it("returns suite with case count", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());
      mockDB.mocks.listCases.mockResolvedValue([makeTestCase(), makeTestCase({ caseId: "case-002" })]);

      const event = makeEvent({
        httpMethod: "GET",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "suite-001" },
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      const body = JSON.parse(result.body);
      expect(body.name).toBe("My Test Suite");
      expect(body.caseCount).toBe(2);
    });

    it("returns 404 when suite not found", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(null);

      const event = makeEvent({
        httpMethod: "GET",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "nonexistent" },
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(404);
    });
  });

  describe("PUT /suites/{suiteId} — Update Suite", () => {
    it("updates suite name and description", async () => {
      const existing = makeSuite();
      mockDB.mocks.getSuite
        .mockResolvedValueOnce(existing) // existence check
        .mockResolvedValueOnce({ ...existing, name: "Updated", updatedAt: "2024-02-01T00:00:00.000Z" }); // return updated

      const event = makeEvent({
        httpMethod: "PUT",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "suite-001" },
        body: JSON.stringify({ name: "Updated", description: "New desc" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      expect(mockDB.mocks.updateSuite).toHaveBeenCalledOnce();
    });

    it("returns 404 when suite does not exist", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(null);

      const event = makeEvent({
        httpMethod: "PUT",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "nonexistent" },
        body: JSON.stringify({ name: "Updated" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(404);
    });

    it("returns 400 for validation errors on update", async () => {
      const event = makeEvent({
        httpMethod: "PUT",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "suite-001" },
        body: JSON.stringify({ name: "" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
    });
  });

  describe("DELETE /suites/{suiteId} — Delete Suite", () => {
    it("deletes suite with valid confirmation token", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      const event = makeEvent({
        httpMethod: "DELETE",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "suite-001" },
        body: JSON.stringify({ confirmationToken: "suite-001" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      expect(mockDB.mocks.deleteSuite).toHaveBeenCalledWith(TENANT_ID, "suite-001");
    });

    it("returns 400 when confirmation token is missing", async () => {
      const event = makeEvent({
        httpMethod: "DELETE",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "suite-001" },
        body: JSON.stringify({}),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
      expect(JSON.parse(result.body).error).toContain("confirmation token");
    });

    it("returns 400 when confirmation token does not match suiteId", async () => {
      const event = makeEvent({
        httpMethod: "DELETE",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "suite-001" },
        body: JSON.stringify({ confirmationToken: "wrong-token" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
    });

    it("returns 404 when suite does not exist", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(null);

      const event = makeEvent({
        httpMethod: "DELETE",
        resource: "/suites/{suiteId}",
        pathParameters: { suiteId: "suite-001" },
        body: JSON.stringify({ confirmationToken: "suite-001" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(404);
    });
  });

  describe("POST /suites/{suiteId}/cases — Create Case", () => {
    it("creates a test case with valid input", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: "suite-001" },
        body: JSON.stringify({
          name: "Test Case",
          description: "A valid test case",
          persona: "Impatient customer",
          style: "direct",
          customerKnowledge: { orderId: "ORD-123" },
          initialUtterance: "Where is my order?",
          successCriteria: [
            { toolName: "LookupOrder", required: true },
            { toolName: "GetShipmentStatus", required: true },
          ],
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(201);
      const body = JSON.parse(result.body);
      expect(body.suiteId).toBe("suite-001");
      expect(body.caseId).toBeDefined();
      expect(body.successCriteria).toHaveLength(2);
      expect(mockDB.mocks.createCase).toHaveBeenCalledOnce();
    });

    it("returns 400 when description is missing", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: "suite-001" },
        body: JSON.stringify({
          initialUtterance: "Hello",
          successCriteria: [{ toolName: "SomeTool", required: true }],
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.details.some((e: { field: string }) => e.field === "description")).toBe(true);
    });

    it("returns 404 when parent suite does not exist", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(null);

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: "nonexistent" },
        body: JSON.stringify({
          description: "Test case",
          initialUtterance: "Hello",
          successCriteria: [{ toolName: "Tool", required: true }],
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(404);
    });
  });

  describe("GET /suites/{suiteId}/cases — List Cases", () => {
    it("returns list of cases for a suite", async () => {
      const cases = [makeTestCase(), makeTestCase({ caseId: "case-002" })];
      mockDB.mocks.listCases.mockResolvedValue(cases);

      const event = makeEvent({
        httpMethod: "GET",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: "suite-001" },
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      expect(JSON.parse(result.body).cases).toHaveLength(2);
    });
  });

  describe("PUT /suites/{suiteId}/cases/{caseId} — Update Case", () => {
    it("updates an existing test case", async () => {
      mockDB.mocks.getCase.mockResolvedValue(makeTestCase());

      const event = makeEvent({
        httpMethod: "PUT",
        resource: "/suites/{suiteId}/cases/{caseId}",
        pathParameters: { suiteId: "suite-001", caseId: "case-001" },
        body: JSON.stringify({
          description: "Updated description",
          initialUtterance: "Updated utterance",
          successCriteria: [{ toolName: "NewTool", required: true }],
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      const body = JSON.parse(result.body);
      expect(body.description).toBe("Updated description");
      expect(mockDB.mocks.updateCase).toHaveBeenCalledOnce();
    });

    it("returns 404 when case does not exist", async () => {
      mockDB.mocks.getCase.mockResolvedValue(null);

      const event = makeEvent({
        httpMethod: "PUT",
        resource: "/suites/{suiteId}/cases/{caseId}",
        pathParameters: { suiteId: "suite-001", caseId: "nonexistent" },
        body: JSON.stringify({
          description: "Updated",
          initialUtterance: "Hi",
          successCriteria: [{ toolName: "Tool", required: true }],
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(404);
    });
  });

  describe("DELETE /suites/{suiteId}/cases/{caseId} — Delete Case", () => {
    it("deletes an existing test case", async () => {
      mockDB.mocks.getCase.mockResolvedValue(makeTestCase());

      const event = makeEvent({
        httpMethod: "DELETE",
        resource: "/suites/{suiteId}/cases/{caseId}",
        pathParameters: { suiteId: "suite-001", caseId: "case-001" },
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(200);
      expect(mockDB.mocks.deleteCase).toHaveBeenCalledWith("suite-001", "case-001");
    });

    it("returns 404 when case does not exist", async () => {
      mockDB.mocks.getCase.mockResolvedValue(null);

      const event = makeEvent({
        httpMethod: "DELETE",
        resource: "/suites/{suiteId}/cases/{caseId}",
        pathParameters: { suiteId: "suite-001", caseId: "nonexistent" },
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(404);
    });
  });

  describe("Route not found", () => {
    it("returns 404 for unknown routes", async () => {
      const event = makeEvent({
        httpMethod: "PATCH",
        resource: "/unknown",
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(404);
      expect(JSON.parse(result.body).error).toContain("Route not found");
    });
  });

  describe("Error handling", () => {
    it("returns 409 for ConditionalCheckFailedException", async () => {
      const error = new Error("Condition not met");
      error.name = "ConditionalCheckFailedException";
      mockDB.mocks.createSuite.mockRejectedValue(error);

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites",
        body: JSON.stringify({ name: "Suite", agentId: "agent-1" }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(409);
    });

    it("returns 500 for unexpected errors", async () => {
      mockDB.mocks.listSuites.mockRejectedValue(new Error("DynamoDB down"));

      const event = makeEvent({ httpMethod: "GET", resource: "/suites" });
      const result = await handler(event);
      expect(result.statusCode).toBe(500);
    });
  });
});
