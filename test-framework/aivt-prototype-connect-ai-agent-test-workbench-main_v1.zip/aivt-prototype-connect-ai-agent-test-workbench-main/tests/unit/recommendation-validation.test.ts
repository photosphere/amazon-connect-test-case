import { describe, it, expect } from "vitest";
import {
  validateRecommendation,
  validateRecommendations,
} from "@backend/orchestration/validation";
import { Recommendation, ToolSurface } from "@shared/types";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function validRecommendation(overrides?: Partial<Recommendation>): Recommendation {
  return {
    targetField: "tool_instruction",
    targetName: "verifyIdentity",
    currentText: "Use only after greeting.",
    suggestedText: "Use only after greeting the customer warmly.",
    rationale: "More specific instruction improves accuracy.",
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// validateRecommendation — targetField
// ---------------------------------------------------------------------------

describe("validateRecommendation", () => {
  describe("targetField validation", () => {
    const validSurfaces: ToolSurface[] = [
      "tool_description",
      "tool_instruction",
      "tool_examples",
      "system_prompt",
    ];

    it.each(validSurfaces)(
      "accepts valid targetField: %s",
      (surface) => {
        const rec = validRecommendation({ targetField: surface });
        const result = validateRecommendation(rec);
        expect(result.valid).toBe(true);
        expect(result.errors).toHaveLength(0);
      }
    );

    it("rejects invalid targetField", () => {
      const rec = validRecommendation({
        targetField: "invalid_surface" as ToolSurface,
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain("Invalid targetField");
    });

    it("rejects empty string targetField", () => {
      const rec = validRecommendation({
        targetField: "" as ToolSurface,
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain("Invalid targetField");
    });
  });

  // ---------------------------------------------------------------------------
  // targetName validation
  // ---------------------------------------------------------------------------

  describe("targetName validation", () => {
    it("accepts non-empty targetName", () => {
      const rec = validRecommendation({ targetName: "bookFlight" });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(true);
    });

    it("rejects empty targetName", () => {
      const rec = validRecommendation({ targetName: "" });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain("targetName");
    });

    it("rejects whitespace-only targetName", () => {
      const rec = validRecommendation({ targetName: "   " });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain("targetName");
    });
  });

  // ---------------------------------------------------------------------------
  // currentText / suggestedText validation (no-op rejection)
  // ---------------------------------------------------------------------------

  describe("currentText/suggestedText validation", () => {
    it("accepts when only currentText is non-empty (remove operation)", () => {
      const rec = validRecommendation({
        targetField: "tool_examples",
        currentText: "Example: book a flight to Seattle",
        suggestedText: "",
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(true);
    });

    it("accepts when only suggestedText is non-empty (add operation)", () => {
      const rec = validRecommendation({
        targetField: "tool_examples",
        currentText: "",
        suggestedText: "Example: book a hotel in NYC",
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(true);
    });

    it("accepts when both are non-empty (replace operation)", () => {
      const rec = validRecommendation({
        currentText: "Old text",
        suggestedText: "New text",
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(true);
    });

    it("rejects when both are empty (no-op)", () => {
      const rec = validRecommendation({
        currentText: "",
        suggestedText: "",
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(false);
      expect(result.errors[0]).toContain("At least one of currentText or suggestedText");
    });
  });

  // ---------------------------------------------------------------------------
  // Multiple errors
  // ---------------------------------------------------------------------------

  describe("multiple errors", () => {
    it("collects all errors at once", () => {
      const rec: Recommendation = {
        targetField: "bogus" as ToolSurface,
        targetName: "",
        currentText: "",
        suggestedText: "",
        rationale: "",
      };
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(false);
      expect(result.errors.length).toBe(3);
    });
  });

  // ---------------------------------------------------------------------------
  // tool_examples operation semantics
  // ---------------------------------------------------------------------------

  describe("tool_examples operations", () => {
    it("validates add: empty currentText, non-empty suggestedText", () => {
      const rec = validRecommendation({
        targetField: "tool_examples",
        targetName: "searchFlights",
        currentText: "",
        suggestedText: "Customer: I need to fly to LA next Friday",
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(true);
    });

    it("validates remove: non-empty currentText, empty suggestedText", () => {
      const rec = validRecommendation({
        targetField: "tool_examples",
        targetName: "searchFlights",
        currentText: "Customer: I need to fly to LA next Friday",
        suggestedText: "",
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(true);
    });

    it("validates replace: both non-empty", () => {
      const rec = validRecommendation({
        targetField: "tool_examples",
        targetName: "searchFlights",
        currentText: "Old example",
        suggestedText: "New example",
      });
      const result = validateRecommendation(rec);
      expect(result.valid).toBe(true);
    });
  });
});

// ---------------------------------------------------------------------------
// validateRecommendations (batch)
// ---------------------------------------------------------------------------

describe("validateRecommendations", () => {
  it("returns valid for empty array", () => {
    const result = validateRecommendations([]);
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it("returns valid for array of valid recommendations", () => {
    const recs = [
      validRecommendation(),
      validRecommendation({ targetField: "system_prompt", targetName: "system_prompt" }),
    ];
    const result = validateRecommendations(recs);
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it("returns invalid and prefixes error with index", () => {
    const recs = [
      validRecommendation(),
      validRecommendation({ targetName: "" }), // invalid at index 1
    ];
    const result = validateRecommendations(recs);
    expect(result.valid).toBe(false);
    expect(result.errors[0]).toContain("Recommendation[1]");
  });

  it("collects errors from multiple invalid recommendations", () => {
    const recs = [
      validRecommendation({ targetField: "bad" as ToolSurface }), // index 0
      validRecommendation({ targetName: "  " }), // index 1
    ];
    const result = validateRecommendations(recs);
    expect(result.valid).toBe(false);
    expect(result.errors.length).toBe(2);
    expect(result.errors[0]).toContain("Recommendation[0]");
    expect(result.errors[1]).toContain("Recommendation[1]");
  });
});
