#!/usr/bin/env python3
"""Configure the AI Agent with a specific tool tier for the scaling test.

Usage:
    .venv/bin/python scratch/scaling_test/configure_agent.py --tier {10|20|30|40|50}

This script:
1. Loads tools.json and slices the first N tools for the requested tier
2. Saves the original AI Agent configuration to .original_agent_config.json (only on first run)
3. Updates the AI Agent's toolConfigurations with the tier's tools

The system prompt is NOT modified — the service auto-injects the tool list via
{{$.toolConfigurationList}}. Only the toolConfigurations array on the AI Agent
needs to change between tiers.
"""

import argparse
import json
import sys
from pathlib import Path

import boto3

# --- Constants ---
REGION = "us-east-1"
INSTANCE_ID = "46837cc7-8562-4b3f-92b2-1bae0ede624b"
ASSISTANT_ID = "5664eea5-381d-468e-bfba-302b69ae6dec"
AI_AGENT_ID = "8c02abb3-ba52-42cc-be7d-d01a8634d4ae"
# System default orchestration prompt — properly handles {{$.toolConfigurationList}}
SYSTEM_PROMPT_ID = "871ebb63-3ebc-43a3-b65e-197a34c80fa8"

VALID_TIERS = [10, 20, 30, 40, 50]

SCRIPT_DIR = Path(__file__).resolve().parent
TOOLS_FILE = SCRIPT_DIR / "tools.json"
ORIGINAL_CONFIG_FILE = SCRIPT_DIR / ".original_agent_config.json"


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Configure AI Agent with a specific tool tier for scaling test"
    )
    parser.add_argument(
        "--tier",
        type=int,
        choices=VALID_TIERS,
        required=True,
        help="Number of tools to configure (10, 20, 30, 40, or 50)",
    )
    return parser.parse_args()


def load_tools(tier: int) -> list[dict]:
    """Load tools.json and return the first N tools for the given tier."""
    with open(TOOLS_FILE, "r") as f:
        all_tools = json.load(f)

    if len(all_tools) < tier:
        print(f"ERROR: tools.json contains {len(all_tools)} tools, but tier {tier} requires {tier}")
        sys.exit(1)

    return all_tools[:tier]


def save_original_config(qconnect_client) -> dict:
    """Fetch and save the current AI Agent configuration before making changes.

    Only saves on the first run — if .original_agent_config.json already exists,
    it's left intact so we always restore to the true pre-test state.
    """
    if ORIGINAL_CONFIG_FILE.exists():
        print(f"Original config already saved at {ORIGINAL_CONFIG_FILE} (not overwriting)")
        with open(ORIGINAL_CONFIG_FILE, "r") as f:
            return json.load(f)

    print("Fetching current AI Agent configuration...")
    try:
        response = qconnect_client.get_ai_agent(
            assistantId=ASSISTANT_ID,
            aiAgentId=AI_AGENT_ID,
        )
    except Exception as e:
        print(f"ERROR: Failed to get AI Agent configuration: {e}")
        if hasattr(e, "response"):
            print(f"API Response: {json.dumps(e.response, indent=2, default=str)}")
        sys.exit(1)

    # Save the full response (minus ResponseMetadata) for restoration
    config_to_save = {k: v for k, v in response.items() if k != "ResponseMetadata"}

    with open(ORIGINAL_CONFIG_FILE, "w") as f:
        json.dump(config_to_save, f, indent=2, default=str)

    print(f"Original config saved to {ORIGINAL_CONFIG_FILE}")
    return config_to_save


def build_tool_configurations(tools: list[dict]) -> list[dict]:
    """Build the toolConfigurations payload for update_ai_agent.

    The tools.json format already matches the API shape for ORCHESTRATION agents:
    toolName, toolType, description, instruction, inputSchema, userInteractionConfiguration.
    We pass them through directly.
    """
    return tools


def get_current_prompt_id(qconnect_client) -> str:
    """Get the current orchestration prompt ID from the AI Agent.

    We need to preserve this when updating — only the toolConfigurations change.
    """
    try:
        response = qconnect_client.get_ai_agent(
            assistantId=ASSISTANT_ID,
            aiAgentId=AI_AGENT_ID,
        )
    except Exception as e:
        print(f"ERROR: Failed to get AI Agent: {e}")
        if hasattr(e, "response"):
            print(f"API Response: {json.dumps(e.response, indent=2, default=str)}")
        sys.exit(1)

    ai_agent = response.get("aiAgent", response)
    config = ai_agent.get("configuration", {})

    # The agent may be type ORCHESTRATION (config directly has orchestrationAIAgentConfiguration)
    # or type SELF_SERVICE (nested under selfServiceAIAgentConfiguration)
    orch_config = config.get("orchestrationAIAgentConfiguration", {})
    if not orch_config:
        ss_config = config.get("selfServiceAIAgentConfiguration", {})
        orch_config = ss_config.get("orchestrationAIAgentConfiguration", {})

    prompt_id = orch_config.get("orchestrationAIPromptId", "")

    if not prompt_id:
        print("ERROR: Could not find orchestrationAIPromptId on the AI Agent.")
        print("The agent may not have an orchestration prompt configured.")
        print(f"Agent config keys: {list(config.keys())}")
        sys.exit(1)

    return prompt_id


def update_ai_agent(qconnect_client, prompt_id: str, tool_configs: list[dict]) -> None:
    """Update the AI Agent with new tool configurations.

    Preserves the existing prompt — only toolConfigurations changes.
    Uses the same config shape the agent already has (orchestrationAIAgentConfiguration).
    """
    print(f"Updating AI Agent with {len(tool_configs)} tools (keeping prompt {prompt_id})...")

    try:
        qconnect_client.update_ai_agent(
            assistantId=ASSISTANT_ID,
            aiAgentId=AI_AGENT_ID,
            configuration={
                "orchestrationAIAgentConfiguration": {
                    "orchestrationAIPromptId": prompt_id,
                    "toolConfigurations": tool_configs,
                    "locale": "en_US",
                },
            },
            visibilityStatus="PUBLISHED",
        )
    except Exception as e:
        print(f"ERROR: Failed to update AI Agent: {e}")
        if hasattr(e, "response"):
            print(f"API Response: {json.dumps(e.response, indent=2, default=str)}")
        sys.exit(1)

    print("AI Agent updated successfully.")
    print(f"  Prompt: {prompt_id} (unchanged)")
    print(f"  Tools: {len(tool_configs)}")


def main():
    """Main entry point."""
    args = parse_args()
    tier = args.tier

    print(f"=== Configuring AI Agent for Tier {tier} ===")
    print(f"Region: {REGION}")
    print(f"Assistant: {ASSISTANT_ID}")
    print(f"AI Agent: {AI_AGENT_ID}")
    print()

    # Create boto3 client
    qconnect_client = boto3.client("qconnect", region_name=REGION)

    # Step 1: Load tools for this tier
    tools = load_tools(tier)
    print(f"Loaded {len(tools)} tools for tier {tier}")
    print(f"  Tools: {', '.join(t['toolName'] for t in tools[:5])}{'...' if len(tools) > 5 else ''}")
    print()

    # Step 2: Save original config (only on first run)
    save_original_config(qconnect_client)
    print()

    # Step 3: Get the current prompt ID (we preserve it)
    prompt_id = get_current_prompt_id(qconnect_client)
    print(f"Current prompt: {prompt_id}")
    print()

    # Step 4: Build tool configurations and update agent
    tool_configs = build_tool_configurations(tools)
    update_ai_agent(qconnect_client, prompt_id, tool_configs)
    print()

    print(f"=== Configuration complete for Tier {tier} ===")
    print(f"The AI Agent now has {tier} tools. Prompt unchanged.")
    print(f"Original config saved to: {ORIGINAL_CONFIG_FILE}")
    print(f"Run cleanup_agent.py to restore the original configuration.")


if __name__ == "__main__":
    main()
