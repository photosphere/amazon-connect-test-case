/**
 * RAG Evaluate Lambda — Stage 2 handler invoked by Step Functions after
 * Stage 1 (ExecuteCases) completes for runs containing RAG cases.
 *
 * Workflow:
 * 1. Filter to RAG cases with captured responses (not error).
 * 2. Serialize each case via serializeRagCaseToJsonl, assemble via assembleJsonlFile.
 * 3. Upload to s3://{RAG_Job_Bucket}/{runId}/input.jsonl.
 * 4. Call bedrock:CreateEvaluationJob with BYOI dataset.
 * 5. Poll bedrock:GetEvaluationJob every 30s, hard cap 30 min.
 * 6. On COMPLETED — read per-prompt output from S3, join by index, write ragMetrics to DDB.
 * 7. On FAILED/STOPPED/timeout — write error codes to each case.
 * 8. Apply computeRagCaseStatus thresholds, set case.status.
 * 9. Persist RAGJOB record for observability.
 *
 * Resolves the `rag_evaluation_job` prompt for the executing run via
 * {@link resolvePromptForRun} (R10.1, R10.2, R11.2 — the run's pinned
 * snapshot is the source of truth, falling back to the live registry
 * for pre-feature runs). The resolved `prompt.modelId` is wired into
 * `evaluatorModelConfig.bedrockEvaluatorModels[0].modelIdentifier` on
 * the `CreateEvaluationJob` request per R10.2. Unlike the Wave-1 / 2
 * Converse migrations, the resolved `prompt.text` is intentionally
 * unused — the Bedrock RAG evaluation job invokes AWS-managed
 * evaluator templates server-side rather than a user-supplied system
 * prompt; the registry entry exists purely to surface `modelKey` on
 * the Prompts page (model-only entry per the design).
 *
 * Migrated from a hardcoded inline `JUDGE_MODEL_ID` env-var fallback
 * to the registry (Wave 2 — Task 17.7 of the prompt-management spec).
 * The legacy `JUDGE_MODEL_ID` env var is still set in
 * `lib/orchestration-construct.ts` as a Wave-2 safety net and is
 * removed in Wave 3.
 *
 * Validates: Requirements 1.3, 4.2, 4.4, 4.5, 4.7, 5.9, 5.10, 6.3, 6.4,
 * 8.1, 8.2, 8.3, 8.4, 8.5, 9.1, 9.2, 10.1, 10.2, 11.2.
 *
 * @module rag-evaluate
 */

import { S3Client, PutObjectCommand, GetObjectCommand, ListObjectsV2Command } from "@aws-sdk/client-s3";
import {
  BedrockClient,
  CreateEvaluationJobCommand,
  GetEvaluationJobCommand,
  StopEvaluationJobCommand,
} from "@aws-sdk/client-bedrock";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, UpdateCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import { serializeRagCaseToJsonl, assembleJsonlFile } from "./jsonl-serializer";
import { computeRagCaseStatus } from "./rag-decision";
import { resolvePromptForRun } from "./prompt-registry/runtime";
import { RAG_JOB_POLL_INTERVAL_MS, RAG_JOB_TIMEOUT_MS, PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import type { RagMetrics, RagThresholds, RetrievedChunk, EvaluationErrorCode } from "../../shared/types";
import { DEFAULT_RAG_THRESHOLDS } from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";
const RAG_JOB_BUCKET = process.env.RAG_JOB_BUCKET ?? "";
const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";

/** Metric set used for retrieve-and-generate evaluation. */
const RAG_METRIC_SET = [
  "Builtin.Faithfulness",
  "Builtin.Correctness",
  "Builtin.Completeness",
  "Builtin.Helpfulness",
] as const;

// ---------------------------------------------------------------------------
// Clients (lazy singletons; injectable for tests)
// ---------------------------------------------------------------------------

let s3Client: S3Client | null = null;
let bedrockClient: BedrockClient | null = null;
let docClient: DynamoDBDocumentClient | null = null;

function getS3Client(): S3Client {
  if (!s3Client) {
    s3Client = new S3Client({ region: REGION });
  }
  return s3Client;
}

function getBedrockClient(): BedrockClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockClient({ region: REGION });
  }
  return bedrockClient;
}

function getDocClient(): DynamoDBDocumentClient {
  if (!docClient) {
    const ddbClient = new DynamoDBClient({ region: REGION });
    docClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return docClient;
}

/**
 * Test-only injectors for dependency replacement.
 * @internal
 */
export function _setS3Client(client: S3Client | null): void {
  s3Client = client as S3Client | null;
}
export function _setBedrockClient(client: BedrockClient | null): void {
  bedrockClient = client as BedrockClient | null;
}
export function _setDocClient(client: DynamoDBDocumentClient | null): void {
  docClient = client as DynamoDBDocumentClient | null;
}

// ---------------------------------------------------------------------------
// Input / Output interfaces
// ---------------------------------------------------------------------------

/** A single RAG case as passed from the state machine after Stage 1. */
export interface RagCaseData {
  caseId: string;
  question: string;
  groundTruthAnswer: string;
  /** The agent's terminal response captured in Stage 1. Undefined if error. */
  agentResponse?: string;
  /** Retrieved chunks from ListSpans. */
  retrievedChunks?: RetrievedChunk[];
  /** Case status from Stage 1 — "error" means it should be excluded. */
  status?: string;
}

/** Input event from the Step Functions state machine. */
export interface RagEvaluateInput {
  runId: string;
  suiteId: string;
  /**
   * Explicitly constructed RAG case data. Present in backward-compat
   * scenarios or tests. When absent (the normal runtime path), ragCases
   * are constructed from `testCases` + DDB case-result reads.
   */
  ragCases?: RagCaseData[];
  agentSnapshot?: {
    modelId: string;
  };
  ragThresholds?: RagThresholds;
  /**
   * The original test case definitions passed through from PrepareRun.
   * Available on the state machine state because the Map step uses
   * `resultPath: "$.caseResults"` which preserves all other fields.
   */
  testCases?: Array<Record<string, unknown>>;
  /**
   * Per-case results from the Map step (WriteCaseResult output array).
   * Used to identify which cases completed vs errored.
   */
  caseResults?: Array<Record<string, unknown>>;
  /** Whether the suite has RAG cases — set by PrepareRun. */
  hasRagCases?: boolean;
  /** Agent ID from PrepareRun output. */
  agentId?: string;
  /** Assistant ID from PrepareRun output. */
  assistantId?: string;
}

/** Output returned to the Step Functions state machine. */
export interface RagEvaluateOutput {
  runId: string;
  evaluatedCount: number;
  errorCount: number;
  jobArn?: string;
  status: "COMPLETED" | "FAILED" | "TIMEOUT" | "SKIPPED";
}

// ---------------------------------------------------------------------------
// Utility: sleep
// ---------------------------------------------------------------------------

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ---------------------------------------------------------------------------
// Evaluator model ID mapping
// ---------------------------------------------------------------------------

/**
 * Maps an inference profile ID or model key to a foundation model ID
 * supported by Bedrock's CreateEvaluationJob evaluator model list.
 * The evaluation API rejects inference profile IDs (e.g.
 * "us.anthropic.claude-sonnet-4-6") — it requires the bare foundation
 * model ID from the supported evaluator list.
 *
 * Fallback: if the input doesn't match a known mapping, use Claude
 * Sonnet 4.0 as a safe default (it's in the supported list).
 */
function mapToEvaluatorModelId(modelId: string): string {
  // Bedrock CreateEvaluationJob requires either a foundation model ID or
  // a cross-region inference profile ID. In accounts where on-demand access
  // to foundation models isn't enabled (only inference profiles), the bare
  // model ID is rejected. Use the US cross-region inference profile for
  // reliability — the docs confirm these are supported for evaluation jobs.
  const EVALUATOR_MODEL_MAP: Record<string, string> = {
    // Platform inference profile IDs -> US cross-region inference profiles
    "us.anthropic.claude-sonnet-4-6": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "us.anthropic.claude-sonnet-4-5-20250514-v1:0": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "us.anthropic.claude-3-5-sonnet-20241022-v2:0": "us.anthropic.claude-3-5-haiku-20241022-v1:0",
    "us.anthropic.claude-haiku-4-5": "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    "us.anthropic.claude-haiku-4-5-20251001-v1:0": "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    "us.anthropic.claude-opus-4-8": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "us.amazon.nova-pro-v1:0": "us.amazon.nova-pro-v1:0",
    "us.amazon.nova-lite-v1:0": "us.amazon.nova-pro-v1:0",
    // Foundation model IDs -> US cross-region inference profiles
    "anthropic.claude-sonnet-4-20250514-v1:0": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "anthropic.claude-3-5-sonnet-20241022-v2:0": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "anthropic.claude-haiku-4-5-20251001-v1:0": "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    "amazon.nova-pro-v1:0": "us.amazon.nova-pro-v1:0",
  };

  const mapped = EVALUATOR_MODEL_MAP[modelId];
  if (mapped) return mapped;

  // If already a US inference profile, pass through
  if (modelId.startsWith("us.")) return modelId;

  // Default fallback to Claude Sonnet 4.0 US inference profile
  console.warn(
    `[rag-evaluate] Unknown evaluator model ID "${modelId}", falling back to us.anthropic.claude-sonnet-4-20250514-v1:0`,
  );
  return "us.anthropic.claude-sonnet-4-20250514-v1:0";
}

// ---------------------------------------------------------------------------
// Step 1: Filter surviving cases
// ---------------------------------------------------------------------------

function filterSurvivingCases(ragCases: RagCaseData[]): RagCaseData[] {
  return ragCases.filter(
    (c) => c.status !== "error" && c.agentResponse !== undefined && c.agentResponse !== null,
  );
}

// ---------------------------------------------------------------------------
// Step 3: Upload JSONL to S3
// ---------------------------------------------------------------------------

async function uploadJsonlToS3(runId: string, body: string): Promise<string> {
  const key = `${runId}/input.jsonl`;
  const s3Uri = `s3://${RAG_JOB_BUCKET}/${key}`;

  await getS3Client().send(
    new PutObjectCommand({
      Bucket: RAG_JOB_BUCKET,
      Key: key,
      Body: body,
      ContentType: "application/jsonl",
    }),
  );

  return s3Uri;
}

// ---------------------------------------------------------------------------
// Step 4: Create evaluation job
// ---------------------------------------------------------------------------

async function createEvaluationJob(
  runId: string,
  inputS3Uri: string,
  caseCount: number,
  judgeModelId: string,
): Promise<string> {
  const jobName = `rag-eval-${runId}-${Date.now()}`;
  const outputPath = `s3://${RAG_JOB_BUCKET}/${runId}/output/`;

  const response = await getBedrockClient().send(
    new CreateEvaluationJobCommand({
      jobName,
      roleArn: process.env.BEDROCK_EVAL_ROLE_ARN,
      applicationType: "RagEvaluation",
      evaluationConfig: {
        automated: {
          datasetMetricConfigs: [
            {
              // taskType is required by the API schema but documented as
              // "ignored for knowledge base evaluation jobs". Use
              // "Generation" which is the closest semantic match for
              // retrieve-and-generate; "Custom" is rejected by the API
              // validation layer despite the docs claiming it's ignored.
              taskType: "Generation",
              metricNames: [...RAG_METRIC_SET],
              dataset: {
                name: `input-${runId}`,
                datasetLocation: {
                  s3Uri: inputS3Uri,
                },
              },
            },
          ],
          evaluatorModelConfig: {
            bedrockEvaluatorModels: [
              { modelIdentifier: judgeModelId },
            ],
          },
        },
      },
      inferenceConfig: {
        ragConfigs: [
          {
            precomputedRagSourceConfig: {
              retrieveAndGenerateSourceConfig: {
                ragSourceIdentifier: "connect-orchestration-retrieve",
              },
            },
          },
        ],
      },
      outputDataConfig: {
        s3Uri: outputPath,
      },
    }),
  );

  const jobArn = response.jobArn ?? "";

  console.info("[rag-evaluate] CreateEvaluationJob", {
    jobArn,
    inputS3Uri,
    judgeModel: judgeModelId,
    metricSet: RAG_METRIC_SET,
    caseCount,
  });

  return jobArn;
}

// ---------------------------------------------------------------------------
// Step 5: Poll for job completion
// ---------------------------------------------------------------------------

type JobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | "Deleting";

async function pollForCompletion(jobArn: string): Promise<{ status: JobStatus; outputPath?: string }> {
  const startTime = Date.now();

  while (true) {
    const elapsed = Date.now() - startTime;
    if (elapsed >= RAG_JOB_TIMEOUT_MS) {
      // Hard cap reached — attempt to stop the job
      console.error("[rag-evaluate] Poll timeout reached after", elapsed, "ms. Stopping job.");
      try {
        await getBedrockClient().send(
          new StopEvaluationJobCommand({ jobIdentifier: jobArn }),
        );
      } catch (stopErr) {
        console.error("[rag-evaluate] StopEvaluationJob failed (best-effort):", stopErr instanceof Error ? stopErr.message : stopErr);
      }
      return { status: "Stopping" };
    }

    await sleep(RAG_JOB_POLL_INTERVAL_MS);

    try {
      const response = await getBedrockClient().send(
        new GetEvaluationJobCommand({ jobIdentifier: jobArn }),
      );

      const status = (response.status ?? "InProgress") as JobStatus;
      console.info("[rag-evaluate] GetEvaluationJob poll", { jobArn, status });

      if (status === "Completed") {
        // Extract the output data location from the response
        const outputPath = response.outputDataConfig?.s3Uri;
        return { status, outputPath };
      }

      if (status === "Failed" || status === "Stopped" || status === "Stopping" || status === "Deleting") {
        console.error("[rag-evaluate] Job reached terminal non-success status:", status);
        return { status };
      }
      // InProgress — continue polling
    } catch (pollErr) {
      console.error("[rag-evaluate] GetEvaluationJob poll error:", pollErr instanceof Error ? pollErr.message : pollErr);
      // Continue polling on transient errors
    }
  }
}

// ---------------------------------------------------------------------------
// Step 6: Read per-prompt output from S3
// ---------------------------------------------------------------------------

interface PerPromptResult {
  lineIndex: number;
  metrics: {
    faithfulness?: number;
    correctness?: number;
    completeness?: number;
    helpfulness?: number;
  };
}

async function readPerPromptResults(_outputPath: string, runId: string): Promise<PerPromptResult[]> {
  // List objects under the output prefix to find the per-prompt result file
  const outputPrefix = `${runId}/output/`;

  const listResponse = await getS3Client().send(
    new ListObjectsV2Command({
      Bucket: RAG_JOB_BUCKET,
      Prefix: outputPrefix,
    }),
  );

  const objects = listResponse.Contents ?? [];
  // Look for the per-prompt results file (typically named with "per_prompt" or similar)
  const perPromptObject = objects.find(
    (obj) => obj.Key && (obj.Key.includes("per_prompt") || obj.Key.includes("per-prompt") || obj.Key.endsWith(".jsonl")),
  );

  if (!perPromptObject?.Key) {
    console.error("[rag-evaluate] No per-prompt output file found under", outputPrefix);
    return [];
  }

  const getResponse = await getS3Client().send(
    new GetObjectCommand({
      Bucket: RAG_JOB_BUCKET,
      Key: perPromptObject.Key,
    }),
  );

  const bodyStr = await getResponse.Body?.transformToString("utf-8");
  if (!bodyStr) {
    console.error("[rag-evaluate] Empty per-prompt output file:", perPromptObject.Key);
    return [];
  }

  const results: PerPromptResult[] = [];
  const lines = bodyStr.trim().split("\n");

  for (let i = 0; i < lines.length; i++) {
    try {
      const parsed = JSON.parse(lines[i]);
      const metrics: PerPromptResult["metrics"] = {};

      // Bedrock RAG evaluation output format (as of 2025):
      // Each line is: { conversationTurns: [{ inputRecord, output, results }] }
      // where results[] is an array of metric objects:
      //   { metricName: "Builtin.Faithfulness", result: 0.95, evaluatorDetails: [...] }
      const turns = parsed.conversationTurns;
      if (Array.isArray(turns) && turns.length > 0) {
        const turnResults = turns[0].results;
        if (Array.isArray(turnResults)) {
          for (const mr of turnResults) {
            const name = (mr.metricName ?? "").toLowerCase();
            const score = mr.result !== undefined ? Number(mr.result) : undefined;
            if (name.includes("faithfulness") && score !== undefined) metrics.faithfulness = score;
            if (name.includes("correctness") && score !== undefined) metrics.correctness = score;
            if (name.includes("completeness") && score !== undefined) metrics.completeness = score;
            if (name.includes("helpfulness") && score !== undefined) metrics.helpfulness = score;
          }
        }
      }

      // Fallback: try legacy flat format (scores/metrics/evaluationResults at top level)
      if (metrics.faithfulness === undefined && metrics.correctness === undefined) {
        const scoreSource = parsed.scores ?? parsed.metrics ?? parsed.evaluationResults;
        if (scoreSource && typeof scoreSource === "object") {
          if (scoreSource.faithfulness !== undefined) metrics.faithfulness = Number(scoreSource.faithfulness);
          if (scoreSource.correctness !== undefined) metrics.correctness = Number(scoreSource.correctness);
          if (scoreSource.completeness !== undefined) metrics.completeness = Number(scoreSource.completeness);
          if (scoreSource.helpfulness !== undefined) metrics.helpfulness = Number(scoreSource.helpfulness);
          if (scoreSource.Faithfulness !== undefined) metrics.faithfulness = Number(scoreSource.Faithfulness);
          if (scoreSource.Correctness !== undefined) metrics.correctness = Number(scoreSource.Correctness);
          if (scoreSource.Completeness !== undefined) metrics.completeness = Number(scoreSource.Completeness);
          if (scoreSource.Helpfulness !== undefined) metrics.helpfulness = Number(scoreSource.Helpfulness);
        }
      }

      // Line index: use position in file (corresponds to JSONL line order)
      const lineIndex = parsed.promptIndex ?? parsed.index ?? i;
      results.push({ lineIndex, metrics });
    } catch (parseErr) {
      console.error("[rag-evaluate] Failed to parse per-prompt result line", i, ":", parseErr instanceof Error ? parseErr.message : parseErr);
      // Individual line failure — still process others (R8.4)
      results.push({ lineIndex: i, metrics: {} });
    }
  }

  return results;
}

// ---------------------------------------------------------------------------
// Step 6/7: Write metrics or errors to DDB
// ---------------------------------------------------------------------------

async function writeRagMetrics(
  runId: string,
  caseId: string,
  ragMetrics: RagMetrics,
  status: "passed" | "failed",
): Promise<void> {
  const client = getDocClient();
  await client.send(
    new UpdateCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `CASE#${caseId}`,
      },
      UpdateExpression: "SET ragMetrics = :rm, #s = :st, caseType = :ct",
      ExpressionAttributeNames: { "#s": "status" },
      ExpressionAttributeValues: {
        ":rm": ragMetrics,
        ":st": status,
        ":ct": "rag",
      },
    }),
  );
}

async function writeErrorToCase(
  runId: string,
  caseId: string,
  code: EvaluationErrorCode,
  reason: string,
): Promise<void> {
  const client = getDocClient();
  await client.send(
    new UpdateCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `CASE#${caseId}`,
      },
      UpdateExpression: "SET evaluationError = :ee, #s = :st, caseType = :ct",
      ExpressionAttributeNames: { "#s": "status" },
      ExpressionAttributeValues: {
        ":ee": { code, reason },
        ":st": "error",
        ":ct": "rag",
      },
    }),
  );
}

// ---------------------------------------------------------------------------
// Step 9: Persist RAGJOB record
// ---------------------------------------------------------------------------

interface RagJobRecord {
  runId: string;
  jobArn: string;
  judgeModelId: string;
  inputS3Uri: string;
  outputS3Uri?: string;
  submittedCaseCount: number;
  indexMap: Record<number, string>;
  status: "IN_PROGRESS" | "COMPLETED" | "FAILED" | "STOPPED" | "TIMEOUT";
  startedAt: string;
  completedAt?: string;
}

async function persistRagJobRecord(record: RagJobRecord): Promise<void> {
  const client = getDocClient();
  await client.send(
    new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        PK: `${PK_PATTERNS.RUN}${record.runId}`,
        SK: "RAGJOB",
        ...record,
      },
    }),
  );
}

// ---------------------------------------------------------------------------
// Resilient RAG case loading (DDB fallback)
// ---------------------------------------------------------------------------

/**
 * Loads RAG case data for evaluation. Prefers `event.ragCases` if present
 * (backward compat / tests), otherwise constructs from `event.testCases`
 * + DDB case-result reads.
 *
 * This is the key fix for the Stage 2 pipeline crash: the state machine
 * passes the full execution state to RAG_Evaluate (because it uses
 * `resultPath` not `outputPath`), so `event.testCases` contains the
 * original test case definitions (with question/groundTruthAnswer) and
 * the DDB case-result records (written by WriteCaseResult) contain the
 * persisted agentResponse and retrievedChunks.
 */
async function loadRagCases(event: RagEvaluateInput): Promise<RagCaseData[]> {
  // Path 1: Explicit ragCases on the event (backward compat / tests)
  if (Array.isArray(event.ragCases) && event.ragCases.length > 0) {
    return event.ragCases;
  }

  // Path 2: Construct from testCases + DDB
  const { runId, testCases } = event;
  if (!testCases || !runId) {
    console.error("[rag-evaluate] Neither ragCases nor testCases available on event", {
      hasRagCases: !!event.ragCases,
      hasTestCases: !!event.testCases,
      runId: event.runId,
    });
    return [];
  }

  // Filter to RAG test cases only
  const ragTestCases = testCases.filter(
    (tc) => (tc as { type?: string }).type === "rag",
  );
  if (ragTestCases.length === 0) {
    console.info("[rag-evaluate] No RAG test cases found in testCases array.");
    return [];
  }

  // Read each case's persisted result from DDB to get agentResponse + retrievedChunks
  const client = getDocClient();
  const cases: RagCaseData[] = [];

  for (const tc of ragTestCases) {
    const caseId = (tc as { caseId?: string }).caseId;
    if (!caseId) {
      console.warn("[rag-evaluate] Test case missing caseId, skipping:", tc);
      continue;
    }

    try {
      const result = await client.send(
        new GetCommand({
          TableName: TABLE_NAME,
          Key: {
            PK: `${PK_PATTERNS.RUN}${runId}`,
            SK: `${SK_PATTERNS.CASE}${caseId}`,
          },
        }),
      );
      const item = result.Item;

      cases.push({
        caseId,
        question: (tc as { question?: string }).question ?? "",
        groundTruthAnswer: (tc as { groundTruthAnswer?: string }).groundTruthAnswer ?? "",
        agentResponse: item?.agentResponse as string | undefined,
        retrievedChunks: item?.retrievedChunks as RetrievedChunk[] | undefined,
        status: (item?.status as string) ?? "error",
      });
    } catch (err) {
      console.warn(
        `[rag-evaluate] Failed to read case result for ${caseId}:`,
        err instanceof Error ? err.message : err,
      );
      cases.push({
        caseId,
        question: (tc as { question?: string }).question ?? "",
        groundTruthAnswer: (tc as { groundTruthAnswer?: string }).groundTruthAnswer ?? "",
        status: "error",
      });
    }
  }

  console.info("[rag-evaluate] Loaded RAG cases from DDB", {
    total: ragTestCases.length,
    loaded: cases.length,
    withResponse: cases.filter((c) => c.agentResponse !== undefined).length,
  });

  return cases;
}

/**
 * Resolves the agent model ID for JSONL serialization. Prefers
 * `event.agentSnapshot.modelId`, falls back to reading the persisted
 * SNAPSHOT record from DDB.
 */
async function resolveModelId(event: RagEvaluateInput): Promise<string> {
  if (event.agentSnapshot?.modelId) {
    return event.agentSnapshot.modelId;
  }

  // Read from the SNAPSHOT record persisted by PrepareRun / the runs API
  const client = getDocClient();
  try {
    const result = await client.send(
      new GetCommand({
        TableName: TABLE_NAME,
        Key: {
          PK: `${PK_PATTERNS.RUN}${event.runId}`,
          SK: SK_PATTERNS.SNAPSHOT,
        },
      }),
    );
    const modelId = (result.Item?.modelId as string) ?? "unknown";
    console.info("[rag-evaluate] Resolved modelId from SNAPSHOT record:", modelId);
    return modelId;
  } catch (err) {
    console.warn(
      "[rag-evaluate] Failed to read SNAPSHOT for modelId, using 'unknown':",
      err instanceof Error ? err.message : err,
    );
    return "unknown";
  }
}

/**
 * Resolves RAG thresholds. Prefers `event.ragThresholds` if explicitly
 * passed, otherwise uses the platform default thresholds.
 */
function resolveRagThresholds(event: RagEvaluateInput): RagThresholds {
  if (event.ragThresholds) {
    return event.ragThresholds;
  }
  return DEFAULT_RAG_THRESHOLDS;
}

// ---------------------------------------------------------------------------
// Lambda handler
// ---------------------------------------------------------------------------

/**
 * Stage 2 handler for RAG evaluation. Invoked by Step Functions after
 * Stage 1 completes for runs containing RAG cases.
 */
export async function handler(event: RagEvaluateInput): Promise<RagEvaluateOutput> {
  const { runId } = event;
  const startedAt = new Date().toISOString();

  // Robustly load ragCases — from event.ragCases if present, otherwise from testCases + DDB
  const ragCases = await loadRagCases(event);
  const ragThresholds = resolveRagThresholds(event);

  // Step 1: Filter to RAG cases with captured responses
  const survivingCases = filterSurvivingCases(ragCases);

  if (survivingCases.length === 0) {
    console.info("[rag-evaluate] Zero surviving RAG cases — skipping CreateEvaluationJob.", { runId });
    return { runId, evaluatedCount: 0, errorCount: 0, status: "SKIPPED" };
  }

  // R10.1 / R10.2 / R11.2: resolve the `rag_evaluation_job` prompt
  // once for this run via the run-pinned snapshot (falling back to the
  // live registry for pre-feature runs). We consume only `prompt.modelId`
  // — the Bedrock RAG evaluation job does NOT take a Converse system
  // prompt, so `prompt.text` is intentionally unused. A
  // `PromptResolutionError` from `resolvePromptForRun` (R16.3)
  // propagates unchanged so the run records cleanly rather than emitting
  // a job with a stale model id.
  const prompt = await resolvePromptForRun("rag_evaluation_job", runId);
  // CreateEvaluationJob requires a foundation model ID from the supported
  // evaluator model list, NOT an inference profile ID. The prompt registry
  // resolves to an inference profile (e.g. "us.anthropic.claude-sonnet-4-6")
  // which works for Converse calls but is rejected by the evaluation API.
  // Map to the corresponding supported evaluator model ID.
  const judgeModelId = mapToEvaluatorModelId(prompt.modelId);

  // Resolve the agent's model ID for the JSONL modelIdentifier field
  const agentModelId = await resolveModelId(event);

  // Step 2: Serialize each case to JSONL
  const serializedCases = survivingCases.map((c) => ({
    caseId: c.caseId,
    line: serializeRagCaseToJsonl({
      question: c.question,
      groundTruthAnswer: c.groundTruthAnswer,
      agentResponse: c.agentResponse!,
      retrievedChunks: c.retrievedChunks ?? [],
      knowledgeBaseId: undefined,
      modelIdentifier: agentModelId,
    }),
  }));

  const { body, indexMap } = assembleJsonlFile(serializedCases);

  // Step 3: Upload to S3
  const inputS3Uri = await uploadJsonlToS3(runId, body);
  console.info("[rag-evaluate] Uploaded JSONL to S3", { inputS3Uri, caseCount: survivingCases.length });

  // Step 4: Create evaluation job
  let jobArn: string;
  try {
    jobArn = await createEvaluationJob(runId, inputS3Uri, survivingCases.length, judgeModelId);
  } catch (createErr) {
    console.error("[rag-evaluate] CreateEvaluationJob failed:", createErr instanceof Error ? createErr.message : createErr);
    // Write RAG_JOB_FAILED to all surviving cases (R8.2)
    const reason = createErr instanceof Error ? createErr.message : "CreateEvaluationJob returned an error";
    for (const c of survivingCases) {
      await writeErrorToCase(runId, c.caseId, "RAG_JOB_FAILED", reason);
    }
    await persistRagJobRecord({
      runId,
      jobArn: "",
      judgeModelId,
      inputS3Uri,
      submittedCaseCount: survivingCases.length,
      indexMap,
      status: "FAILED",
      startedAt,
      completedAt: new Date().toISOString(),
    });
    return { runId, evaluatedCount: 0, errorCount: survivingCases.length, status: "FAILED" };
  }

  // Step 5: Poll for job completion
  const pollResult = await pollForCompletion(jobArn);

  let evaluatedCount = 0;
  let errorCount = 0;
  let finalStatus: RagEvaluateOutput["status"];

  if (pollResult.status === "Completed") {
    // Step 6: Read per-prompt output, join by index, write metrics
    finalStatus = "COMPLETED";
    try {
      const perPromptResults = await readPerPromptResults(pollResult.outputPath ?? "", runId);
      const resultsByIndex = new Map<number, PerPromptResult>();
      for (const r of perPromptResults) {
        resultsByIndex.set(r.lineIndex, r);
      }

      for (const [lineIdx, caseId] of Object.entries(indexMap)) {
        const idx = Number(lineIdx);
        const perPrompt = resultsByIndex.get(idx);

        if (!perPrompt) {
          // R8.5: No result for this case
          console.error("[rag-evaluate] No per-prompt result for lineIndex", idx, "caseId", caseId);
          await writeErrorToCase(
            runId,
            caseId,
            "MISSING_EVALUATOR",
            "Bedrock did not return a result for this prompt",
          );
          errorCount++;
          continue;
        }

        const metrics = perPrompt.metrics;

        // Check if we have all four metrics as valid numbers
        if (
          metrics.faithfulness === undefined ||
          metrics.correctness === undefined ||
          metrics.completeness === undefined ||
          metrics.helpfulness === undefined ||
          isNaN(metrics.faithfulness) ||
          isNaN(metrics.correctness) ||
          isNaN(metrics.completeness) ||
          isNaN(metrics.helpfulness)
        ) {
          // R8.4: Malformed result for this individual case
          console.error("[rag-evaluate] Malformed metrics for lineIndex", idx, "caseId", caseId);
          await writeErrorToCase(
            runId,
            caseId,
            "MALFORMED_RESULT",
            "Bedrock returned incomplete or non-numeric metric scores for this prompt",
          );
          errorCount++;
          continue;
        }

        // Step 8: Apply thresholds via computeRagCaseStatus
        const ragMetrics: RagMetrics = {
          faithfulness: metrics.faithfulness,
          correctness: metrics.correctness,
          completeness: metrics.completeness,
          helpfulness: metrics.helpfulness,
        };

        const caseStatus = computeRagCaseStatus(ragMetrics, ragThresholds);
        await writeRagMetrics(runId, caseId, ragMetrics, caseStatus);
        evaluatedCount++;
      }
    } catch (readErr) {
      console.error("[rag-evaluate] Failed to read/process per-prompt output:", readErr instanceof Error ? readErr.message : readErr);
      // Write MALFORMED_RESULT to any cases not yet processed
      for (const c of survivingCases) {
        // Best-effort: write error to all remaining cases
        try {
          await writeErrorToCase(
            runId,
            c.caseId,
            "MALFORMED_RESULT",
            "Failed to read or parse Bedrock evaluation output",
          );
          errorCount++;
        } catch {
          // Swallow DDB write errors on the error path
        }
      }
      finalStatus = "FAILED";
    }
  } else if (pollResult.status === "Stopping" || pollResult.status === "Stopped") {
    // Step 7: Timeout — write RAG_JOB_TIMEOUT to all cases
    finalStatus = "TIMEOUT";
    for (const c of survivingCases) {
      await writeErrorToCase(
        runId,
        c.caseId,
        "RAG_JOB_TIMEOUT",
        "Bedrock evaluation job did not complete within 30 minutes",
      );
      errorCount++;
    }
  } else {
    // Step 7: Failed/Stopped — write RAG_JOB_FAILED to all cases
    finalStatus = "FAILED";
    for (const c of survivingCases) {
      await writeErrorToCase(
        runId,
        c.caseId,
        "RAG_JOB_FAILED",
        `Bedrock evaluation job ended with status: ${pollResult.status}`,
      );
      errorCount++;
    }
  }

  // Step 9: Persist RAGJOB record
  await persistRagJobRecord({
    runId,
    jobArn,
    judgeModelId,
    inputS3Uri,
    outputS3Uri: `s3://${RAG_JOB_BUCKET}/${runId}/output/`,
    submittedCaseCount: survivingCases.length,
    indexMap,
    status: finalStatus === "COMPLETED" ? "COMPLETED" : finalStatus === "TIMEOUT" ? "TIMEOUT" : "FAILED",
    startedAt,
    completedAt: new Date().toISOString(),
  });

  return { runId, evaluatedCount, errorCount, jobArn, status: finalStatus };
}
