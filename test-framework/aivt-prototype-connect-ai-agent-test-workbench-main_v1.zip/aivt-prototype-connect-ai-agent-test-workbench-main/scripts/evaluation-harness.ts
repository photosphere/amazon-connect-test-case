#!/usr/bin/env node
/**
 * Local Evaluation Harness — runs the Bedrock-judge integration from a
 * developer machine without a CDK deploy.
 *
 * Run via: `npx tsx scripts/evaluation-harness.ts <input>` or
 *          `JUDGE_MODEL_ID=us.anthropic.claude-sonnet-4-6 npx tsx scripts/evaluation-harness.ts <input>`
 *
 * The harness is the local twin of the deployed Evaluation Lambda. It
 * deliberately reuses the **same** render → judge → aggregate → assemble
 * code path the Lambda runs by importing
 * {@link evaluateCaseSession} from
 * `src/backend/orchestration/evaluation.ts` (task 5.1) so a developer
 * iterating on prompt rendering, score-scale mapping, or judge behavior
 * locally sees the same behavior the deployed pipeline would produce
 * (Requirement 9.4 / 9.6).
 *
 * Inputs (Requirement 9.5):
 * - Exactly one positional argument:
 *     - **File mode**: a path that exists on disk. The file is parsed as
 *       JSON and may be either:
 *         * a checked-in `Span_Fixture` (`{ sessionId, rawSpans, ... }`),
 *           which is run through `parseSpansToTrace` to build the
 *           `ExecutionTrace`; or
 *         * a saved trace/transcript file (`{ trace, transcript?, ... }`)
 *           used directly.
 *     - **Session mode**: a Q in Connect session id (anything that looks
 *       like a UUID and is not a path that exists on disk). The harness
 *       calls `qconnect:ListSpans` for that id and runs
 *       `parseSpansToTrace` on the result.
 *
 * Both modes feed the resulting bundle into {@link evaluateCaseSession},
 * which renders the four Judge_Prompt_Context surfaces, fans out the
 * `1 + N + M` Bedrock `Converse` calls concurrently, maps labels through
 * the Score_Scale tables, and aggregates the results into the three
 * persisted score fields (or an `evaluationError`). The harness then
 * prints the three scores plus per-evaluator label + reasoning
 * (Requirement 9.2 / 9.3).
 *
 * Failure behavior (Requirements 9.6, 9.7, 9.8, 9.9, 10.4, 10.5). Each
 * branch emits a stderr line tagged with one of the documented operation
 * names so an operator can match on it directly:
 *
 *   - Missing / invalid CLI input → `[argument]` + usage banner, exit 2,
 *     no AWS calls (Req 9.6).
 *   - Unparseable / wrong-shape file → `[load-file]`, exit 1, no
 *     submission (Req 9.7).
 *   - Unresolvable session id, empty `ListSpans`, or `ListSpans`
 *     access-denied / error → `[qconnect:ListSpans]`, exit 1, no
 *     submission (Reqs 9.8, 10.5).
 *   - Missing / unresolvable AWS credentials → `[credentials]`, exit 1,
 *     no AWS call attempted (Req 10.4).
 *   - Bedrock judge timeout / parse failure / access-denied / SDK error
 *     surface as `caseEvaluation.evaluationError` returned by
 *     {@link evaluateCaseSession}, which the harness reports as
 *     `[bedrock:Converse]` and exits non-zero — **never** a local-scoring
 *     fallback (Reqs 9.9, 10.5).
 *
 * Credentials (Requirement 10):
 * - Uses the AWS SDK's default credential chain (environment, named
 *   profile, SSO, web identity, EC2/ECS metadata) via
 *   `@aws-sdk/credential-provider-node`. No long-lived AWS credentials
 *   are embedded in source (Req 10.3).
 * - The harness only calls `bedrock:Converse` (via the judge client) and
 *   `qconnect:ListSpans` (in session mode) on its normal path
 *   (Req 10.1). It never falls back to local scoring (Req 10.5 / Req 8.5
 *   / Req 8.8).
 *
 * @module evaluation-harness
 */

import { existsSync, readFileSync } from "node:fs";
import { resolve as resolvePath } from "node:path";

import {
  ListSpansCommand,
  QConnectClient,
} from "@aws-sdk/client-qconnect";
import { defaultProvider } from "@aws-sdk/credential-provider-node";

import {
  evaluateCaseSession,
  type EvaluateCaseSessionOutput,
  type JudgeCallDetail,
} from "../src/backend/orchestration/evaluation";
import {
  renderJudgePromptContext,
} from "../src/shared/utils/judge-prompt-rendering";
import {
  judge as bedrockJudge,
} from "../src/backend/orchestration/bedrock-judge-client";
import {
  parseSpansToTrace,
  type RawSpan,
} from "../src/backend/orchestration/span-parser";
import type { CaseEvaluation } from "../src/shared/utils/evaluation-result";
import type {
  AgentSnapshot,
  ExecutionTrace,
  ToolDefinition,
  TranscriptTurn,
} from "../src/shared/types";

// The judge module / prompt-rendering module imports are referenced in
// the same-module-as-Lambda assertion in `tests/unit/evaluation-harness.test.ts`
// (Requirement 9.4). They are deliberately kept at the top of the file
// so a static-source grep of the imports reflects the harness's true
// dependency on the same modules the Lambda uses.
void renderJudgePromptContext;
void bedrockJudge;

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Default region when no override is supplied. */
const DEFAULT_REGION = "us-east-1";

/** Page size for `ListSpans`; mirrors `conversation-driver.ts`. */
const LIST_SPANS_PAGE_SIZE = 100;

/**
 * Loose UUID-ish matcher for Q in Connect session ids. Sessions are
 * UUIDv4 strings; accepting any string of `[0-9a-f-]` characters of
 * length ≥ 8 that starts with a hex digit keeps the test surface
 * forgiving while still rejecting unrelated tokens like file paths.
 */
const SESSION_ID_PATTERN = /^[0-9a-fA-F][0-9a-fA-F-]{7,}$/;

// Documented operation names — used both in stderr output and in unit
// test assertions. Centralised so the two never drift.
const OP_ARGUMENT = "argument";
const OP_LOAD_FILE = "load-file";
const OP_LIST_SPANS = "qconnect:ListSpans";
const OP_CREDENTIALS = "credentials";
const OP_CONVERSE = "bedrock:Converse";

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/**
 * Internal error type used to flag a specific failure path that should
 * print a clear message naming the failing operation and exit non-zero
 * **without** any AWS call or local fallback. The runner catches every
 * thrown `HarnessError` and converts it into the matching exit code +
 * stderr line.
 */
class HarnessError extends Error {
  /** Operation tag printed alongside the message (e.g. `"load-file"`). */
  readonly operation: string;
  /** Exit code the runner should emit (default 1, 2 for arg errors). */
  readonly exitCode: number;
  constructor(operation: string, message: string, exitCode = 1) {
    super(message);
    this.name = "HarnessError";
    this.operation = operation;
    this.exitCode = exitCode;
  }
}

// ---------------------------------------------------------------------------
// CLI argument parsing
// ---------------------------------------------------------------------------

interface CliArgs {
  /** The single positional argument: file path or session id. */
  input?: string;
  /** Optional `--assistant-id` for session mode (else `ASSISTANT_ID` env). */
  assistantId?: string;
  /** Optional `--region` (else `AWS_REGION` / default). */
  region?: string;
  /** Optional per-evaluator timeout override in milliseconds. */
  timeoutMs?: number;
  /** Optional per-case wall-clock budget override in milliseconds. */
  budgetMs?: number;
  /** `--help` / `-h`. */
  help?: boolean;
}

/**
 * Parses CLI arguments into a {@link CliArgs}. Throws {@link HarnessError}
 * (operation = `argument`, exitCode = 2) on unknown flags or invalid
 * values; the runner converts the throw into an `[argument]` stderr
 * line followed by the usage banner.
 */
function parseArgs(argv: string[]): CliArgs {
  const args: CliArgs = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = argv[i + 1];
    const take = (assign: (v: string) => void): void => {
      if (next === undefined) {
        throw new HarnessError(
          OP_ARGUMENT,
          `Missing value for argument ${a}`,
          2,
        );
      }
      assign(next);
      i++;
    };
    if (a === "-h" || a === "--help") {
      args.help = true;
      continue;
    }
    if (a === "--assistant-id") {
      take((v) => (args.assistantId = v));
      continue;
    }
    if (a === "--region") {
      take((v) => (args.region = v));
      continue;
    }
    if (a === "--timeout-ms") {
      take((v) => {
        const n = Number(v);
        if (!Number.isFinite(n) || n <= 0) {
          throw new HarnessError(
            OP_ARGUMENT,
            `--timeout-ms must be a positive number, got "${v}"`,
            2,
          );
        }
        args.timeoutMs = n;
      });
      continue;
    }
    if (a === "--budget-ms") {
      take((v) => {
        const n = Number(v);
        if (!Number.isFinite(n) || n <= 0) {
          throw new HarnessError(
            OP_ARGUMENT,
            `--budget-ms must be a positive number, got "${v}"`,
            2,
          );
        }
        args.budgetMs = n;
      });
      continue;
    }
    // `--key=value` form support for symmetry with smoke-check.
    if (a.startsWith("--") && a.includes("=")) {
      const eq = a.indexOf("=");
      const key = a.slice(2, eq);
      const value = a.slice(eq + 1);
      if (key === "assistant-id") {
        args.assistantId = value;
        continue;
      }
      if (key === "region") {
        args.region = value;
        continue;
      }
      if (key === "timeout-ms") {
        const n = Number(value);
        if (!Number.isFinite(n) || n <= 0) {
          throw new HarnessError(
            OP_ARGUMENT,
            `--timeout-ms must be a positive number, got "${value}"`,
            2,
          );
        }
        args.timeoutMs = n;
        continue;
      }
      if (key === "budget-ms") {
        const n = Number(value);
        if (!Number.isFinite(n) || n <= 0) {
          throw new HarnessError(
            OP_ARGUMENT,
            `--budget-ms must be a positive number, got "${value}"`,
            2,
          );
        }
        args.budgetMs = n;
        continue;
      }
      throw new HarnessError(OP_ARGUMENT, `Unknown argument: --${key}`, 2);
    }
    if (a.startsWith("--")) {
      throw new HarnessError(OP_ARGUMENT, `Unknown argument: ${a}`, 2);
    }
    if (args.input !== undefined) {
      throw new HarnessError(
        OP_ARGUMENT,
        `Unexpected extra positional argument: "${a}"`,
        2,
      );
    }
    args.input = a;
  }
  return args;
}

/** Lines of the usage banner, written to stderr on argument errors. */
function usageLines(): string[] {
  return [
    "Usage: npx tsx scripts/evaluation-harness.ts <input> [options]",
    "",
    "Arguments:",
    "  <input>                  Either a file path (transcript/trace JSON or",
    "                            Span_Fixture) OR a Q in Connect session id.",
    "                            Exactly one input is required.",
    "",
    "Options:",
    "  --assistant-id <id>      Q in Connect assistant id used in session mode",
    "                            (env: ASSISTANT_ID).",
    `  --region <region>        AWS region (env: AWS_REGION; default: ${DEFAULT_REGION}).`,
    "  --timeout-ms <ms>        Per-judge-call timeout override (default: 60000).",
    "  --budget-ms <ms>         Per-case wall-clock budget override (default: 90000).",
    "  -h, --help               Print this help message.",
    "",
    "Environment:",
    "  JUDGE_MODEL_ID           Bedrock model id to use as the judge",
    "                            (default in deploy: us.anthropic.claude-sonnet-4-6).",
    "",
    "Behavior:",
    "  File mode    - if <input> exists on disk, the harness reads it as JSON",
    "                  (Span_Fixture or trace/transcript).",
    "  Session mode - otherwise <input> is treated as a Q in Connect session id",
    "                  and the harness calls qconnect:ListSpans.",
    "",
    "  Both modes feed the SAME render->judge->aggregate->assemble path used",
    "  by the deployed Evaluation Lambda. The harness uses the AWS SDK's",
    "  default credential chain and never falls back to local scoring.",
  ];
}

// ---------------------------------------------------------------------------
// Argument resolution (file vs session vs unresolvable)
// ---------------------------------------------------------------------------

type InputMode =
  | { kind: "file"; path: string }
  | { kind: "session"; sessionId: string };

/**
 * Decides whether the supplied positional argument is a file path or a
 * Q in Connect session id. File-existence wins over the UUID pattern
 * check: a UUID-shaped argument that happens to point at a real file on
 * disk resolves to file mode so a developer can save a fixture under
 * its session id.
 *
 * Throws {@link HarnessError} (operation = `argument`, exitCode = 2)
 * when the argument is neither a readable file nor a plausible session
 * id (Req 9.6).
 */
function resolveInputMode(input: string): InputMode {
  const trimmed = input.trim();
  if (trimmed.length === 0) {
    throw new HarnessError(
      OP_ARGUMENT,
      "input argument is empty — provide a file path or a session id.",
      2,
    );
  }
  // 1. File-exists check wins. Try the literal value first (so an
  //    in-memory test filesystem keyed by exact path resolves
  //    correctly), then the absolute path against `cwd`.
  if (existsSync(trimmed)) {
    return { kind: "file", path: trimmed };
  }
  const absolute = resolvePath(process.cwd(), trimmed);
  if (absolute !== trimmed && existsSync(absolute)) {
    return { kind: "file", path: absolute };
  }
  // 2. Otherwise look for a UUID-ish session id.
  if (SESSION_ID_PATTERN.test(trimmed)) {
    return { kind: "session", sessionId: trimmed };
  }
  // 3. Neither — surface an unambiguous error before any AWS call.
  throw new HarnessError(
    OP_ARGUMENT,
    `input "${input}" is neither a readable file nor a recognizable Q in Connect session id.`,
    2,
  );
}

// ---------------------------------------------------------------------------
// File mode: load transcript or Span_Fixture
// ---------------------------------------------------------------------------

interface LoadedSession {
  /** Session id to attach to the captured trace. */
  sessionId: string;
  /** Authoritative ExecutionTrace (parsed from rawSpans or supplied directly). */
  trace: ExecutionTrace;
  /** Conversation transcript (may be empty for Span_Fixtures or session mode). */
  transcript: TranscriptTurn[];
  /** Tools the agent had access to when the trace was captured. */
  availableTools: ToolDefinition[];
  /** Ordered tool names from the case's success criteria. */
  expectedToolNames: string[];
}

/**
 * Reads `path` from disk and returns either a `Span_Fixture`-shaped
 * record (parsed via `parseSpansToTrace`) or a saved trace/transcript
 * record. Throws {@link HarnessError} (operation = `load-file`) on any
 * read / parse / shape failure so the runner emits a `[load-file]`
 * stderr line and exits non-zero with no submission (Req 9.7).
 */
function loadFromFile(path: string): LoadedSession {
  let raw: string;
  try {
    raw = readFileSync(path, "utf-8");
  } catch (err) {
    throw new HarnessError(
      OP_LOAD_FILE,
      `could not read file "${path}": ${
        err instanceof Error ? err.message : String(err)
      }`,
    );
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new HarnessError(
      OP_LOAD_FILE,
      `file "${path}" is not valid JSON: ${
        err instanceof Error ? err.message : String(err)
      }`,
    );
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new HarnessError(
      OP_LOAD_FILE,
      `file "${path}" must contain a JSON object at the top level.`,
    );
  }
  const obj = parsed as Record<string, unknown>;

  // -------------------------------------------------------------------------
  // Span_Fixture path: { sessionId, rawSpans, ... }
  // -------------------------------------------------------------------------
  if (Array.isArray(obj.rawSpans)) {
    const sessionId =
      typeof obj.sessionId === "string" && obj.sessionId.length > 0
        ? obj.sessionId
        : undefined;
    if (!sessionId) {
      throw new HarnessError(
        OP_LOAD_FILE,
        `Span_Fixture "${path}" is missing a non-empty "sessionId" string.`,
      );
    }
    let trace: ExecutionTrace;
    try {
      trace = parseSpansToTrace(sessionId, obj.rawSpans as RawSpan[]);
    } catch (err) {
      throw new HarnessError(
        OP_LOAD_FILE,
        `failed to parse spans in "${path}": ${
          err instanceof Error ? err.message : String(err)
        }`,
      );
    }
    if (trace.steps.length === 0) {
      throw new HarnessError(
        OP_LOAD_FILE,
        `Span_Fixture "${path}" produced an empty execution trace (no inference or execute_tool spans).`,
      );
    }
    const availableTools = readToolDefinitionsField(
      obj.availableTools,
      path,
      "availableTools",
    );
    const expectedToolNames = readStringArrayField(
      obj.expectedToolNames ?? obj.expectedToolSequence,
      path,
      "expectedToolNames",
    );
    const transcript = readTranscriptField(obj.transcript, path);
    return {
      sessionId,
      trace,
      transcript,
      availableTools,
      expectedToolNames,
    };
  }

  // -------------------------------------------------------------------------
  // Trace/transcript path: { trace, transcript?, availableTools?, ... }
  // -------------------------------------------------------------------------
  if (obj.trace && typeof obj.trace === "object") {
    const traceObj = obj.trace as Record<string, unknown>;
    if (
      typeof traceObj.sessionId !== "string" ||
      traceObj.sessionId.length === 0 ||
      !Array.isArray(traceObj.steps)
    ) {
      throw new HarnessError(
        OP_LOAD_FILE,
        `file "${path}" has a "trace" field that is not a valid ExecutionTrace (missing sessionId or steps).`,
      );
    }
    const trace = obj.trace as unknown as ExecutionTrace;
    const sessionId =
      typeof obj.sessionId === "string" && obj.sessionId.length > 0
        ? obj.sessionId
        : trace.sessionId;
    const transcript = readTranscriptField(obj.transcript, path);
    const availableTools = readToolDefinitionsField(
      obj.availableTools,
      path,
      "availableTools",
    );
    const expectedToolNames = readStringArrayField(
      obj.expectedToolNames ?? obj.expectedToolSequence,
      path,
      "expectedToolNames",
    );
    return {
      sessionId,
      trace,
      transcript,
      availableTools,
      expectedToolNames,
    };
  }

  throw new HarnessError(
    OP_LOAD_FILE,
    `file "${path}" is not a recognized Span_Fixture or trace/transcript file (expected "rawSpans" or "trace" at the top level).`,
  );
}

/** Reads `transcript` defensively. `undefined` → []; malformed → throws. */
function readTranscriptField(value: unknown, path: string): TranscriptTurn[] {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value)) {
    throw new HarnessError(
      OP_LOAD_FILE,
      `file "${path}" has a "transcript" field that is not an array.`,
    );
  }
  for (const t of value) {
    if (
      !t ||
      typeof t !== "object" ||
      typeof (t as Record<string, unknown>).turnNumber !== "number" ||
      typeof (t as Record<string, unknown>).text !== "string"
    ) {
      throw new HarnessError(
        OP_LOAD_FILE,
        `file "${path}" contains a "transcript" entry missing turnNumber or text.`,
      );
    }
  }
  return value as TranscriptTurn[];
}

/** Reads `availableTools` / similar arrays of `ToolDefinition`. */
function readToolDefinitionsField(
  value: unknown,
  path: string,
  fieldName: string,
): ToolDefinition[] {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value)) {
    throw new HarnessError(
      OP_LOAD_FILE,
      `file "${path}" has a "${fieldName}" field that is not an array.`,
    );
  }
  for (const t of value) {
    if (
      !t ||
      typeof t !== "object" ||
      typeof (t as Record<string, unknown>).toolName !== "string"
    ) {
      throw new HarnessError(
        OP_LOAD_FILE,
        `file "${path}" contains a "${fieldName}" entry missing toolName.`,
      );
    }
  }
  return value as ToolDefinition[];
}

/** Reads a `string[]` field; defaults to `[]`. */
function readStringArrayField(
  value: unknown,
  path: string,
  fieldName: string,
): string[] {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value) || !value.every((s) => typeof s === "string")) {
    throw new HarnessError(
      OP_LOAD_FILE,
      `file "${path}" has a "${fieldName}" field that is not an array of strings.`,
    );
  }
  return value as string[];
}

// ---------------------------------------------------------------------------
// Session mode: ListSpans + parseSpansToTrace
// ---------------------------------------------------------------------------

/**
 * Calls `qconnect:ListSpans` for `sessionId` (paginating until exhaustion),
 * parses the result into an `ExecutionTrace`, and returns it shaped as a
 * {@link LoadedSession}.
 *
 * Failure mapping (Reqs 9.8, 10.5). All throws use operation
 * `qconnect:ListSpans` so the runner emits a `[qconnect:ListSpans]`
 * stderr line and the unit tests can match on it directly:
 *
 * - SDK throws `AccessDeniedException` / `UnauthorizedException` →
 *   "access denied" message. No submission.
 * - SDK throws `ResourceNotFoundException` → "could not resolve session"
 *   message. No submission.
 * - Empty span list → "no spans" message. No submission.
 * - Spans returned but none parsed into a step → "empty execution
 *   trace" message. No submission.
 *
 * The `assistantId` is required: if missing, throws an
 * {@link HarnessError} with operation `argument` so the harness fails
 * fast with usage guidance instead of issuing a malformed AWS call.
 *
 * Note: this function does not load an `AgentSnapshot`. The platform
 * persists the snapshot under `PK=RUN#{runId}, SK=SNAPSHOT` which only
 * exists for completed Test_Runs and is keyed off the run id, not the
 * session id. In session mode the harness synthesises an empty
 * snapshot from the session's available tools (none in raw spans), so
 * the available-tools list is empty in session-mode evaluations. To
 * exercise the full available-tools rendering the developer should
 * save a Span_Fixture or trace/transcript file with `availableTools`
 * populated and use file mode.
 */
async function loadFromSession(
  sessionId: string,
  args: CliArgs,
): Promise<LoadedSession> {
  const assistantId =
    args.assistantId ??
    process.env.ASSISTANT_ID ??
    process.env.QCONNECT_ASSISTANT_ID;
  if (!assistantId || assistantId.trim().length === 0) {
    throw new HarnessError(
      OP_ARGUMENT,
      "session mode requires an assistant id. Pass --assistant-id <id> or set the ASSISTANT_ID environment variable.",
      2,
    );
  }

  const region =
    args.region ??
    process.env.AWS_REGION ??
    process.env.AWS_DEFAULT_REGION ??
    DEFAULT_REGION;
  const client = new QConnectClient({ region });

  const rawSpans: RawSpan[] = [];
  let nextToken: string | undefined;
  try {
    do {
      const resp = await client.send(
        new ListSpansCommand({
          assistantId,
          sessionId,
          nextToken,
          maxResults: LIST_SPANS_PAGE_SIZE,
        }),
      );
      for (const s of resp.spans ?? []) {
        rawSpans.push(s as RawSpan);
      }
      nextToken = resp.nextToken;
    } while (nextToken);
  } catch (err) {
    const name = (err as { name?: string }).name ?? "";
    if (
      name === "AccessDeniedException" ||
      name === "UnauthorizedException"
    ) {
      throw new HarnessError(
        OP_LIST_SPANS,
        `access denied calling ${OP_LIST_SPANS} for session "${sessionId}": ${
          err instanceof Error ? err.message : String(err)
        }. The harness does not fall back to local scoring.`,
      );
    }
    if (name === "ResourceNotFoundException") {
      throw new HarnessError(
        OP_LIST_SPANS,
        `${OP_LIST_SPANS} could not resolve session "${sessionId}" (ResourceNotFoundException). No spans available; nothing was submitted to the Bedrock judge.`,
      );
    }
    throw new HarnessError(
      OP_LIST_SPANS,
      `${OP_LIST_SPANS} failed for session "${sessionId}": ${
        err instanceof Error ? err.message : String(err)
      }`,
    );
  }

  if (rawSpans.length === 0) {
    throw new HarnessError(
      OP_LIST_SPANS,
      `${OP_LIST_SPANS} returned no spans for session "${sessionId}". Execution_Trace could not be retrieved; nothing was submitted to the Bedrock judge.`,
    );
  }

  const trace = parseSpansToTrace(sessionId, rawSpans);
  if (trace.steps.length === 0) {
    throw new HarnessError(
      OP_LIST_SPANS,
      `${OP_LIST_SPANS} returned spans for session "${sessionId}" but none parsed into an inference or execute_tool step. Execution_Trace is empty; nothing was submitted to the Bedrock judge.`,
    );
  }
  // In session mode the harness has no test case (no success criteria)
  // and no agent snapshot. The same render → judge path still runs;
  // the tool-selection evaluator simply sees an empty available-tools
  // list and the case carries an empty `expectedToolNames`.
  return {
    sessionId,
    trace,
    transcript: [],
    availableTools: [],
    expectedToolNames: [],
  };
}

// ---------------------------------------------------------------------------
// Credential pre-flight check (Req 10.4)
// ---------------------------------------------------------------------------

/**
 * Resolves AWS credentials via the SDK's default provider chain and
 * throws a {@link HarnessError} (operation = `credentials`) when none
 * are available. Requirement 10.4 mandates that **no** AWS API call is
 * attempted when credentials are missing, so this function is invoked
 * before either the file-mode Bedrock submission or the session-mode
 * `ListSpans` call.
 */
async function ensureCredentialsAvailable(): Promise<void> {
  try {
    const provider = defaultProvider();
    const credentials = await provider();
    if (
      !credentials ||
      typeof credentials.accessKeyId !== "string" ||
      credentials.accessKeyId.length === 0
    ) {
      throw new HarnessError(
        OP_CREDENTIALS,
        "AWS credentials are missing: the default credential chain returned an empty access key.",
      );
    }
  } catch (err) {
    if (err instanceof HarnessError) throw err;
    throw new HarnessError(
      OP_CREDENTIALS,
      `AWS credentials are missing or unresolvable: ${
        err instanceof Error ? err.message : String(err)
      }. Configure AWS credentials (env vars, AWS_PROFILE, or SSO) and retry.`,
    );
  }
}

// ---------------------------------------------------------------------------
// Output formatting
// ---------------------------------------------------------------------------

/**
 * Prints the three scores plus per-evaluator label + reasoning
 * (Requirement 9.2 / 9.3). Score values are formatted to four decimal
 * places; missing scores are rendered as `(unset)` so it is unambiguous
 * when an `evaluationError` left them off. The harness prints the value
 * `0.0000` as a real score (Req 9.2 / 9.3 — "including a value of
 * exactly 0.0 when produced").
 */
function printScores(
  caseEvaluation: CaseEvaluation,
  rawJudgeResults: JudgeCallDetail[],
): void {
  const fmt = (n: number | undefined): string =>
    n === undefined ? "(unset)" : n.toFixed(4);
  console.log("");
  console.log("Scores (range 0.0–1.0):");
  console.log(`  goalSuccessScore:  ${fmt(caseEvaluation.goalSuccessScore)}`);
  console.log(`  helpfulnessScore:  ${fmt(caseEvaluation.helpfulnessScore)}`);
  console.log(`  toolAccuracyScore: ${fmt(caseEvaluation.toolAccuracyScore)}`);
  console.log("");
  console.log("Per-evaluator detail:");
  if (rawJudgeResults.length === 0) {
    console.log("  (no judge calls were issued)");
    return;
  }
  // Group by evaluator id so readers can scan one block per family.
  const byEvaluator = new Map<string, JudgeCallDetail[]>();
  for (const r of rawJudgeResults) {
    let list = byEvaluator.get(r.evaluatorId);
    if (!list) {
      list = [];
      byEvaluator.set(r.evaluatorId, list);
    }
    list.push(r);
  }
  for (const [evaluatorId, calls] of byEvaluator) {
    console.log(`  ${evaluatorId}:`);
    for (const call of calls) {
      const mapped =
        typeof call.mappedValue === "number"
          ? call.mappedValue.toFixed(4)
          : "(none)";
      const labelStr = call.label ? ` label="${call.label}"` : "";
      const errStr = call.error ? ` error=${call.error.kind}` : "";
      console.log(
        `    [${call.index}] mappedValue=${mapped}${labelStr}${errStr}`,
      );
      if (call.reasoning) {
        console.log(`        reasoning: ${truncate(call.reasoning, 240)}`);
      }
      if (call.error?.message) {
        console.log(
          `        errorMessage: ${truncate(call.error.message, 240)}`,
        );
      }
    }
  }
}

function truncate(s: string, max: number): string {
  if (s.length <= max) return s;
  return `${s.slice(0, max - 1)}…`;
}

// ---------------------------------------------------------------------------
// evaluationError → HarnessError mapping (no local-scoring fallback)
// ---------------------------------------------------------------------------

/**
 * Maps a `caseEvaluation.evaluationError` (produced by the shared
 * {@link evaluateCaseSession} pipeline) into a {@link HarnessError} with
 * a stable operation tag. The runner converts it into the matching
 * `[…]` stderr line and exit code.
 *
 * Operation choice:
 * - `INSUFFICIENT_TRACE` is the only error code that can arise BEFORE
 *   any Bedrock call (the prompt renderer rejected the trace), so it
 *   is tagged `qconnect:ListSpans` (the upstream operation that
 *   produced the unusable spans) when in session mode and `load-file`
 *   when in file mode.
 * - All other codes (`TIMEOUT`, `JUDGE_ERROR`, `UNMAPPABLE_RESULT`,
 *   `MISSING_EVALUATOR`) name `bedrock:Converse` so the operator sees a
 *   single, consistent operation tag for any judge failure (Reqs 9.9,
 *   10.5).
 */
function evaluationErrorToHarnessError(
  evaluationError: NonNullable<CaseEvaluation["evaluationError"]>,
  insufficientTraceOp: typeof OP_LIST_SPANS | typeof OP_LOAD_FILE,
): HarnessError {
  const { code, reason } = evaluationError;
  switch (code) {
    case "INSUFFICIENT_TRACE":
      return new HarnessError(
        insufficientTraceOp,
        `insufficient trace data; no submission was made to the Bedrock judge. ${reason}`,
      );
    case "TIMEOUT":
      return new HarnessError(
        OP_CONVERSE,
        `${OP_CONVERSE} timed out: ${reason}`,
      );
    case "JUDGE_ERROR":
      return new HarnessError(
        OP_CONVERSE,
        `${OP_CONVERSE} failed: ${reason}`,
      );
    case "UNMAPPABLE_RESULT":
      return new HarnessError(
        OP_CONVERSE,
        `${OP_CONVERSE} returned an unmappable result: ${reason}`,
      );
    case "MISSING_EVALUATOR":
      return new HarnessError(
        OP_CONVERSE,
        `${OP_CONVERSE} did not return a usable result for one or more evaluators: ${reason}`,
      );
    default:
      // Fallback for any EvaluationErrorCode the harness does not yet
      // map explicitly (e.g. the RAG_* and MALFORMED_RESULT codes that
      // arrive from the shared evaluation pipeline). Tagging
      // `bedrock:Converse` keeps the operator-facing operation tag
      // consistent with the other judge-pipeline failures and silences
      // the missing-return check should the union grow further.
      return new HarnessError(
        OP_CONVERSE,
        `${OP_CONVERSE} failed with code ${code}: ${reason}`,
      );
  }
}

// ---------------------------------------------------------------------------
// AgentSnapshot synthesis
// ---------------------------------------------------------------------------

/**
 * Builds an `AgentSnapshot` shape from the loaded session's
 * `availableTools`. The `evaluateCaseSession` pipeline only reads
 * `snapshot.tools` from the snapshot, so the other fields are filled
 * with placeholder strings — they never reach the Bedrock prompt.
 */
function makeSnapshot(availableTools: ToolDefinition[]): AgentSnapshot {
  return {
    tools: availableTools,
    systemPrompt: "",
    modelId: "",
    capturedAt: new Date(0).toISOString(),
  };
}

// ---------------------------------------------------------------------------
// Main runner — returns an exit code (0 on success, non-zero on failure)
// ---------------------------------------------------------------------------

/**
 * Runs the harness end-to-end for a single CLI invocation and returns
 * the exit code (0 on success, 1 or 2 on failure). The function does
 * **not** call `process.exit` itself so unit tests can drive it directly
 * and assert on the returned code.
 *
 * Order of operations (each step gates the next; failures short-circuit
 * the rest):
 *   1. Parse CLI args (no AWS calls).
 *   2. Resolve the input mode by file-exists check then id pattern (no
 *      AWS calls).
 *   3. Pre-flight credential check (Req 10.4) — fails before any AWS
 *      operation when credentials are missing.
 *   4. In file mode, load the session from disk; in session mode,
 *      fetch spans via `qconnect:ListSpans` and parse them.
 *   5. Run the shared {@link evaluateCaseSession} pipeline (render →
 *      judge → aggregate → assemble — Req 9.4).
 *   6. Print scores + per-evaluator detail or surface the error reason
 *      naming the operation.
 *
 * Failure handling: any {@link HarnessError} thrown by a helper is
 * caught and converted into a stderr line tagged with the operation
 * name + the matching exit code. An `evaluationError` returned by the
 * pipeline is converted via {@link evaluationErrorToHarnessError}.
 *
 * @param argv - Positional CLI arguments (after `node script.ts`)
 * @returns Exit code (0, 1, or 2)
 */
export async function runHarness(argv: string[]): Promise<number> {
  // -------------------------------------------------------------------------
  // 1. Parse CLI args.
  // -------------------------------------------------------------------------
  let cliArgs: CliArgs;
  try {
    cliArgs = parseArgs(argv);
  } catch (err) {
    return reportThrownError(err, /*emitUsage*/ true);
  }
  if (cliArgs.help) {
    for (const line of usageLines()) {
      console.log(line);
    }
    return 0;
  }
  if (cliArgs.input === undefined) {
    process.stderr.write(
      "[argument] missing required input argument (file path or session id).\n\n",
    );
    for (const line of usageLines()) {
      process.stderr.write(`${line}\n`);
    }
    return 2;
  }

  // -------------------------------------------------------------------------
  // 2. Resolve the input mode (no AWS calls). Errors here precede the
  //    credential check so a typo in the input never burns a credential
  //    lookup.
  // -------------------------------------------------------------------------
  let mode: InputMode;
  try {
    mode = resolveInputMode(cliArgs.input);
  } catch (err) {
    return reportThrownError(err, /*emitUsage*/ true);
  }

  // -------------------------------------------------------------------------
  // 3. Pre-flight credential check (Req 10.4) — done BEFORE any AWS
  //    operation in either mode.
  // -------------------------------------------------------------------------
  try {
    await ensureCredentialsAvailable();
  } catch (err) {
    return reportThrownError(err, /*emitUsage*/ false);
  }

  // -------------------------------------------------------------------------
  // 4. Load the session.
  // -------------------------------------------------------------------------
  let loaded: LoadedSession;
  try {
    if (mode.kind === "file") {
      loaded = loadFromFile(mode.path);
    } else {
      loaded = await loadFromSession(mode.sessionId, cliArgs);
    }
  } catch (err) {
    return reportThrownError(err, /*emitUsage*/ false);
  }

  console.log(
    `Loaded session "${loaded.sessionId}" (${loaded.trace.steps.length} step(s), ${loaded.trace.toolSequence.length} tool call(s)).`,
  );

  // -------------------------------------------------------------------------
  // 5. Run the SAME render→judge→aggregate→assemble pipeline the
  //    deployed Evaluation Lambda runs (Req 9.4). Every Bedrock judge
  //    failure mode is converted into a `caseEvaluation.evaluationError`
  //    by `evaluateCaseSession`; the harness surfaces those as a
  //    non-zero exit naming the operation. No local-scoring fallback
  //    (Reqs 8.5, 8.8, 10.5).
  // -------------------------------------------------------------------------
  let result: EvaluateCaseSessionOutput;
  try {
    result = await evaluateCaseSession({
      trace: loaded.trace,
      transcript: loaded.transcript,
      snapshot: makeSnapshot(loaded.availableTools),
      expectedToolNames: loaded.expectedToolNames,
      ...(cliArgs.timeoutMs !== undefined
        ? { timeoutMs: cliArgs.timeoutMs }
        : {}),
      ...(cliArgs.budgetMs !== undefined
        ? { budgetMs: cliArgs.budgetMs }
        : {}),
    });
  } catch (err) {
    // `evaluateCaseSession` does not normally throw — it converts
    // every failure into a `caseEvaluation.evaluationError` — but treat
    // any unexpected throw as a Bedrock-side failure for safety, with
    // no local fallback.
    return reportThrownError(
      new HarnessError(
        OP_CONVERSE,
        `unexpected failure in evaluateCaseSession: ${
          err instanceof Error ? err.message : String(err)
        }`,
      ),
      /*emitUsage*/ false,
    );
  }

  // -------------------------------------------------------------------------
  // 6. Surface results.
  // -------------------------------------------------------------------------
  if (result.caseEvaluation.evaluationError) {
    if (result.rawJudgeResults.length > 0) {
      printScores(result.caseEvaluation, result.rawJudgeResults);
    }
    const harnessErr = evaluationErrorToHarnessError(
      result.caseEvaluation.evaluationError,
      mode.kind === "session" ? OP_LIST_SPANS : OP_LOAD_FILE,
    );
    return reportThrownError(harnessErr, /*emitUsage*/ false);
  }

  printScores(result.caseEvaluation, result.rawJudgeResults);
  console.log("");
  console.log("Evaluation complete.");
  return 0;
}

/**
 * Writes a `[<op>] <message>` line to stderr and returns the exit code.
 * When `emitUsage` is true (argument errors), the usage banner follows.
 */
function reportThrownError(err: unknown, emitUsage: boolean): number {
  if (err instanceof HarnessError) {
    process.stderr.write(`[${err.operation}] ${err.message}\n`);
    if (emitUsage) {
      process.stderr.write("\n");
      for (const line of usageLines()) {
        process.stderr.write(`${line}\n`);
      }
    }
    return err.exitCode;
  }
  if (err instanceof Error) {
    process.stderr.write(`[unknown] ${err.message}\n`);
    return 1;
  }
  process.stderr.write(`[unknown] ${String(err)}\n`);
  return 1;
}

// ---------------------------------------------------------------------------
// CLI entry point
// ---------------------------------------------------------------------------

const invokedDirectly =
  typeof require !== "undefined" && require.main === module;
if (invokedDirectly) {
  runHarness(process.argv.slice(2))
    .then((code) => process.exit(code))
    .catch((err) => {
      process.stderr.write(
        `[unexpected] ${
          err instanceof Error ? err.stack ?? err.message : String(err)
        }\n`,
      );
      process.exit(1);
    });
}
