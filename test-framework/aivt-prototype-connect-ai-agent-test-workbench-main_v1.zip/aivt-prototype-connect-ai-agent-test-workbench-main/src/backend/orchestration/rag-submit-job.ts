/**
 * SubmitRagJob Lambda — Step Functions sub-workflow step 1.
 *
 * Extracted from the monolithic rag-evaluate.ts to avoid Lambda timeout.
 * This handler:
 * 1. Loads RAG cases from DDB (or event.ragCases).
 * 2. Filters to surviving cases (non-error with captured response).
 * 3. Resolves model IDs and thresholds.
 * 4. Serializes to JSONL and uploads to S3.
 * 5. Calls CreateEvaluationJob.
 * 6. Persists initial RAGJOB record with status IN_PROGRESS.
 * 7. Returns structured data for the SFN poll loop.
 *
 * @module rag-submit-job
 */

import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import {
  BedrockClient,
  CreateEvaluationJobCommand,
} from "@aws-sdk/client-bedrock";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, GetCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { serializeRagCaseToJsonl, assembleJsonlFile } from "./jsonl-serializer";
import { resolvePromptForRun } from "./prompt-registry/runtime";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import type { RagThresholds, RetrievedChunk, EvaluationErrorCode } from "../../shared/types";
import { DEFAULT_RAG_THRESHOLDS } from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";
const RAG_JOB_BUCKET = process.env.RAG_JOB_BUCKET ?? "";
const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";

/** Metric set used for retrieve-and-generate evaluation. */
const RAG_METRIC_SET = [
  "Builtin.Faithfulness",
  "Builtin.Correctness",
  "Builtin.Completeness",
  "Builtin.Helpfulness",
] as const;

// ---------------------------------------------------------------------------
// Clients (lazy singletons; injectable for tests)
// ---------------------------------------------------------------------------

let s3Client: S3Client | null = null;
let bedrockClient: BedrockClient | null = null;
let docClient: DynamoDBDocumentClient | null = null;

function getS3Client(): S3Client {
  if (!s3Client) s3Client = new S3Client({ region: REGION });
  return s3Client;
}

function getBedrockClient(): BedrockClient {
  if (!bedrockClient) bedrockClient = new BedrockClient({ region: REGION });
  return bedrockClient;
}

function getDocClient(): DynamoDBDocumentClient {
  if (!docClient) {
    const ddbClient = new DynamoDBClient({ region: REGION });
    docClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return docClient;
}

/** @internal Test-only injectors. */
export function _setS3Client(client: S3Client | null): void { s3Client = client as S3Client | null; }
export function _setBedrockClient(client: BedrockClient | null): void { bedrockClient = client as BedrockClient | null; }
export function _setDocClient(client: DynamoDBDocumentClient | null): void { docClient = client as DynamoDBDocumentClient | null; }

// ---------------------------------------------------------------------------
// Input / Output interfaces
// ---------------------------------------------------------------------------

/** A single RAG case as passed from the state machine after Stage 1. */
export interface RagCaseData {
  caseId: string;
  question: string;
  groundTruthAnswer: string;
  agentResponse?: string;
  retrievedChunks?: RetrievedChunk[];
  status?: string;
}

/** Input event — same shape as the old RagEvaluateInput (full SFN state). */
export interface SubmitRagJobInput {
  runId: string;
  suiteId: string;
  ragCases?: RagCaseData[];
  agentSnapshot?: { modelId: string };
  ragThresholds?: RagThresholds;
  testCases?: Array<Record<string, unknown>>;
  caseResults?: Array<Record<string, unknown>>;
  hasRagCases?: boolean;
  agentId?: string;
  assistantId?: string;
}

/** Output returned to Step Functions — flows through the poll loop. */
export interface SubmitRagJobOutput {
  runId: string;
  suiteId: string;
  jobArn: string;
  indexMap: Record<number, string>;
  ragThresholds: RagThresholds;
  startedAt: string;
  judgeModelId: string;
  inputS3Uri: string;
  submittedCaseCount: number;
  /** "SUBMITTED" on success, "SKIPPED" when zero survivors or create failed. */
  status: "SUBMITTED" | "SKIPPED";
}

// ---------------------------------------------------------------------------
// Evaluator model ID mapping (copied from rag-evaluate.ts)
// ---------------------------------------------------------------------------

/**
 * Maps an inference profile ID or model key to a foundation model ID
 * supported by Bedrock's CreateEvaluationJob evaluator model list.
 */
export function mapToEvaluatorModelId(modelId: string): string {
  const EVALUATOR_MODEL_MAP: Record<string, string> = {
    "us.anthropic.claude-sonnet-4-6": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "us.anthropic.claude-sonnet-4-5-20250514-v1:0": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "us.anthropic.claude-3-5-sonnet-20241022-v2:0": "us.anthropic.claude-3-5-haiku-20241022-v1:0",
    "us.anthropic.claude-haiku-4-5": "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    "us.anthropic.claude-haiku-4-5-20251001-v1:0": "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    "us.anthropic.claude-opus-4-8": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "us.amazon.nova-pro-v1:0": "us.amazon.nova-pro-v1:0",
    "us.amazon.nova-lite-v1:0": "us.amazon.nova-pro-v1:0",
    "anthropic.claude-sonnet-4-20250514-v1:0": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "anthropic.claude-3-5-sonnet-20241022-v2:0": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "anthropic.claude-haiku-4-5-20251001-v1:0": "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    "amazon.nova-pro-v1:0": "us.amazon.nova-pro-v1:0",
  };

  const mapped = EVALUATOR_MODEL_MAP[modelId];
  if (mapped) return mapped;
  if (modelId.startsWith("us.")) return modelId;

  console.warn(
    `[rag-submit-job] Unknown evaluator model ID "${modelId}", falling back to us.anthropic.claude-sonnet-4-20250514-v1:0`,
  );
  return "us.anthropic.claude-sonnet-4-20250514-v1:0";
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function filterSurvivingCases(ragCases: RagCaseData[]): RagCaseData[] {
  return ragCases.filter(
    (c) => c.status !== "error" && c.agentResponse !== undefined && c.agentResponse !== null,
  );
}

async function loadRagCases(event: SubmitRagJobInput): Promise<RagCaseData[]> {
  if (Array.isArray(event.ragCases) && event.ragCases.length > 0) {
    return event.ragCases;
  }

  const { runId, testCases } = event;
  if (!testCases || !runId) {
    console.error("[rag-submit-job] Neither ragCases nor testCases available on event");
    return [];
  }

  const ragTestCases = testCases.filter(
    (tc) => (tc as { type?: string }).type === "rag",
  );
  if (ragTestCases.length === 0) return [];

  const client = getDocClient();
  const cases: RagCaseData[] = [];

  for (const tc of ragTestCases) {
    const caseId = (tc as { caseId?: string }).caseId;
    if (!caseId) continue;

    try {
      const result = await client.send(
        new GetCommand({
          TableName: TABLE_NAME,
          Key: {
            PK: `${PK_PATTERNS.RUN}${runId}`,
            SK: `${SK_PATTERNS.CASE}${caseId}`,
          },
        }),
      );
      const item = result.Item;
      cases.push({
        caseId,
        question: (tc as { question?: string }).question ?? "",
        groundTruthAnswer: (tc as { groundTruthAnswer?: string }).groundTruthAnswer ?? "",
        agentResponse: item?.agentResponse as string | undefined,
        retrievedChunks: item?.retrievedChunks as RetrievedChunk[] | undefined,
        status: (item?.status as string) ?? "error",
      });
    } catch (err) {
      console.warn(`[rag-submit-job] Failed to read case result for ${caseId}`);
      cases.push({
        caseId,
        question: (tc as { question?: string }).question ?? "",
        groundTruthAnswer: (tc as { groundTruthAnswer?: string }).groundTruthAnswer ?? "",
        status: "error",
      });
    }
  }

  return cases;
}

async function resolveModelId(event: SubmitRagJobInput): Promise<string> {
  if (event.agentSnapshot?.modelId) return event.agentSnapshot.modelId;

  const client = getDocClient();
  try {
    const result = await client.send(
      new GetCommand({
        TableName: TABLE_NAME,
        Key: {
          PK: `${PK_PATTERNS.RUN}${event.runId}`,
          SK: SK_PATTERNS.SNAPSHOT,
        },
      }),
    );
    return (result.Item?.modelId as string) ?? "unknown";
  } catch {
    return "unknown";
  }
}

function resolveRagThresholds(event: SubmitRagJobInput): RagThresholds {
  return event.ragThresholds ?? DEFAULT_RAG_THRESHOLDS;
}

async function uploadJsonlToS3(runId: string, body: string): Promise<string> {
  const key = `${runId}/input.jsonl`;
  const s3Uri = `s3://${RAG_JOB_BUCKET}/${key}`;

  await getS3Client().send(
    new PutObjectCommand({
      Bucket: RAG_JOB_BUCKET,
      Key: key,
      Body: body,
      ContentType: "application/jsonl",
    }),
  );

  return s3Uri;
}

async function writeErrorToCase(
  runId: string,
  caseId: string,
  code: EvaluationErrorCode,
  reason: string,
): Promise<void> {
  const client = getDocClient();
  await client.send(
    new UpdateCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `CASE#${caseId}`,
      },
      UpdateExpression: "SET evaluationError = :ee, #s = :st, caseType = :ct",
      ExpressionAttributeNames: { "#s": "status" },
      ExpressionAttributeValues: {
        ":ee": { code, reason },
        ":st": "error",
        ":ct": "rag",
      },
    }),
  );
}

async function persistRagJobRecord(record: {
  runId: string;
  jobArn: string;
  judgeModelId: string;
  inputS3Uri: string;
  submittedCaseCount: number;
  indexMap: Record<number, string>;
  status: string;
  startedAt: string;
  completedAt?: string;
}): Promise<void> {
  const client = getDocClient();
  await client.send(
    new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        PK: `${PK_PATTERNS.RUN}${record.runId}`,
        SK: "RAGJOB",
        ...record,
      },
    }),
  );
}

// ---------------------------------------------------------------------------
// Lambda handler
// ---------------------------------------------------------------------------

export async function handler(event: SubmitRagJobInput): Promise<SubmitRagJobOutput> {
  const { runId, suiteId } = event;
  const startedAt = new Date().toISOString();

  const ragCases = await loadRagCases(event);
  const ragThresholds = resolveRagThresholds(event);
  const survivingCases = filterSurvivingCases(ragCases);

  if (survivingCases.length === 0) {
    console.info("[rag-submit-job] Zero surviving RAG cases — skipping.", { runId });
    return {
      runId,
      suiteId,
      jobArn: "",
      indexMap: {},
      ragThresholds,
      startedAt,
      judgeModelId: "",
      inputS3Uri: "",
      submittedCaseCount: 0,
      status: "SKIPPED",
    };
  }

  // Resolve evaluator model from prompt registry
  const prompt = await resolvePromptForRun("rag_evaluation_job", runId);
  const judgeModelId = mapToEvaluatorModelId(prompt.modelId);

  // Resolve agent model for JSONL
  const agentModelId = await resolveModelId(event);

  // Serialize to JSONL
  const serializedCases = survivingCases.map((c) => ({
    caseId: c.caseId,
    line: serializeRagCaseToJsonl({
      question: c.question,
      groundTruthAnswer: c.groundTruthAnswer,
      agentResponse: c.agentResponse!,
      retrievedChunks: c.retrievedChunks ?? [],
      knowledgeBaseId: undefined,
      modelIdentifier: agentModelId,
    }),
  }));

  const { body, indexMap } = assembleJsonlFile(serializedCases);

  // Upload to S3
  const inputS3Uri = await uploadJsonlToS3(runId, body);
  console.info("[rag-submit-job] Uploaded JSONL", { inputS3Uri, caseCount: survivingCases.length });

  // Create evaluation job
  let jobArn: string;
  try {
    const jobName = `rag-eval-${runId}-${Date.now()}`;
    const outputPath = `s3://${RAG_JOB_BUCKET}/${runId}/output/`;

    const response = await getBedrockClient().send(
      new CreateEvaluationJobCommand({
        jobName,
        roleArn: process.env.BEDROCK_EVAL_ROLE_ARN,
        applicationType: "RagEvaluation",
        evaluationConfig: {
          automated: {
            datasetMetricConfigs: [
              {
                taskType: "Generation",
                metricNames: [...RAG_METRIC_SET],
                dataset: {
                  name: `input-${runId}`,
                  datasetLocation: { s3Uri: inputS3Uri },
                },
              },
            ],
            evaluatorModelConfig: {
              bedrockEvaluatorModels: [
                { modelIdentifier: judgeModelId },
              ],
            },
          },
        },
        inferenceConfig: {
          ragConfigs: [
            {
              precomputedRagSourceConfig: {
                retrieveAndGenerateSourceConfig: {
                  ragSourceIdentifier: "connect-orchestration-retrieve",
                },
              },
            },
          ],
        },
        outputDataConfig: { s3Uri: outputPath },
      }),
    );

    jobArn = response.jobArn ?? "";
    console.info("[rag-submit-job] CreateEvaluationJob", { jobArn, judgeModel: judgeModelId });
  } catch (createErr) {
    console.error("[rag-submit-job] CreateEvaluationJob failed:", createErr instanceof Error ? createErr.message : createErr);
    const reason = createErr instanceof Error ? createErr.message : "CreateEvaluationJob returned an error";
    for (const c of survivingCases) {
      await writeErrorToCase(runId, c.caseId, "RAG_JOB_FAILED", reason);
    }
    await persistRagJobRecord({
      runId,
      jobArn: "",
      judgeModelId,
      inputS3Uri,
      submittedCaseCount: survivingCases.length,
      indexMap,
      status: "FAILED",
      startedAt,
      completedAt: new Date().toISOString(),
    });
    // Return a terminal state so the Choice routes to ReadRagResults error path
    return {
      runId,
      suiteId,
      jobArn: "",
      indexMap,
      ragThresholds,
      startedAt,
      judgeModelId,
      inputS3Uri,
      submittedCaseCount: survivingCases.length,
      status: "SKIPPED", // Error already handled — skip the poll loop
    };
  }

  // Persist initial RAGJOB record
  await persistRagJobRecord({
    runId,
    jobArn,
    judgeModelId,
    inputS3Uri,
    submittedCaseCount: survivingCases.length,
    indexMap,
    status: "IN_PROGRESS",
    startedAt,
  });

  return {
    runId,
    suiteId,
    jobArn,
    indexMap,
    ragThresholds,
    startedAt,
    judgeModelId,
    inputS3Uri,
    submittedCaseCount: survivingCases.length,
    status: "SUBMITTED",
  };
}
