/**
 * useActiveRuns — tracks runs the current browser tab has launched and polls
 * their status until they finish, surfacing a small in-memory list the app
 * shell can use to render a persistent "running" banner.
 *
 * Why localStorage (not a backend list-active-runs endpoint):
 *   - The platform is a single-user developer tool today; "what runs did I
 *     just start?" is the relevant question, not "what runs are active
 *     account-wide?". A localStorage-tracked list keeps the UX promise
 *     ("I clicked Run, I want to see its status from any page in this tab")
 *     without adding a new API surface, IAM, or DDB query.
 *   - Each tracked id is fetched via the existing GET /runs/{runId}, so the
 *     polling cost is bounded by the number of runs the user has launched
 *     in this tab.
 *
 * Lifecycle:
 *   - `trackRun(runId, suiteId, suiteName?)` — call after POST /runs returns
 *     201; persists `{ runId, suiteId, suiteName, startedAt }` in
 *     localStorage and starts polling.
 *   - The hook polls every {@link POLL_INTERVAL_MS} ms while at least one
 *     tracked run is non-terminal; calls GET /runs/{runId} for each tracked
 *     id.
 *   - When a tracked run reaches a terminal status (COMPLETED, FAILED,
 *     ABORTED), it is removed from the tracked set on the next tick.
 *   - 404 from GET /runs/{runId} (the user manually purged or the record
 *     hasn't propagated yet) is tolerated: the entry remains tracked until
 *     {@link STALE_AFTER_MS} of consecutive 404s, then it is pruned.
 *
 * The hook is read-only from a component's perspective — it surfaces an
 * array of "active run" view-models plus a `trackRun` action.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { apiClient, ApiClientError } from "../api";
import { RunStatus } from "../../../shared/enums";
import type { TestRun } from "../../../shared/types";

/** Poll interval for in-flight runs. Three seconds matches RunDashboard. */
const POLL_INTERVAL_MS = 3_000;

/** Treat a tracked run as orphaned after this many consecutive 404s. */
const STALE_AFTER_MS = 30_000;

/** localStorage key holding the tab-local active-run set. */
const STORAGE_KEY = "active-runs-v1";

/** Persisted shape for one tracked run. */
interface PersistedRun {
  runId: string;
  suiteId: string;
  suiteName?: string;
  /** ISO timestamp the user clicked Run. */
  startedAt: string;
  /** Last observed status (cached so the banner is non-blank between polls). */
  lastStatus?: RunStatus;
  /** Last observed progress (cached so the banner can show "3/8" between polls). */
  lastTotal?: number;
  lastCompleted?: number;
}

/** View-model the banner renders. */
export interface ActiveRunView {
  runId: string;
  suiteId: string;
  suiteName?: string;
  status: RunStatus;
  /** 0-based — completed cases (passed + failed + errors). */
  completed?: number;
  total?: number;
}

/**
 * One polling outcome per tracked run. We carry the runId on both arms so
 * the consumer can attribute the result back without losing it through a
 * Promise.allSettled rejection.
 */
type PollOutcome =
  | {
      runId: string;
      kind: "ok";
      run: TestRun;
      completed: number;
      total: number;
    }
  | { runId: string; kind: "missing" }
  | { runId: string; kind: "error"; status: number };

function loadFromStorage(): PersistedRun[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (r): r is PersistedRun =>
        typeof r === "object" &&
        r != null &&
        typeof r.runId === "string" &&
        typeof r.suiteId === "string" &&
        typeof r.startedAt === "string",
    );
  } catch {
    return [];
  }
}

function saveToStorage(runs: PersistedRun[]): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(runs));
  } catch {
    // Quota exceeded or storage disabled. Silently no-op; the banner
    // becomes session-scoped instead of persistent.
  }
}

function isTerminal(status?: RunStatus): boolean {
  return (
    status === RunStatus.COMPLETED ||
    status === RunStatus.FAILED ||
    status === RunStatus.ABORTED
  );
}

function toView(run: PersistedRun): ActiveRunView {
  return {
    runId: run.runId,
    suiteId: run.suiteId,
    suiteName: run.suiteName,
    status: run.lastStatus ?? RunStatus.RUNNING,
    completed: run.lastCompleted,
    total: run.lastTotal,
  };
}

/**
 * Track active runs for the current browser tab. The hook polls each
 * tracked run's status and prunes terminal/orphaned entries on its own; a
 * caller only needs to call `trackRun` once per launched run, plus
 * optionally `dismissRun` to manually clear an entry from the banner.
 */
export function useActiveRuns(): {
  runs: ActiveRunView[];
  trackRun: (runId: string, suiteId: string, suiteName?: string) => void;
  dismissRun: (runId: string) => void;
  dismissAll: () => void;
} {
  const [persisted, setPersisted] = useState<PersistedRun[]>(loadFromStorage);
  // Per-runId 404 streak — the timestamp of the first observed miss. Kept
  // in a ref so transient misses don't churn React state.
  const missesRef = useRef<Map<string, number>>(new Map());

  const trackRun = useCallback(
    (runId: string, suiteId: string, suiteName?: string) => {
      setPersisted((prev) => {
        if (prev.some((r) => r.runId === runId)) return prev;
        const next: PersistedRun[] = [
          ...prev,
          { runId, suiteId, suiteName, startedAt: new Date().toISOString() },
        ];
        saveToStorage(next);
        return next;
      });
    },
    [],
  );

  /**
   * Manually remove a run from the tab-local active set. Used by the
   * Flashbar banner's per-item dismiss control: a user who started a run
   * but no longer wants to see it in the banner (e.g. they've opened the
   * dashboard or aborted) can clear it without waiting for the polling
   * cycle to observe a terminal status. This is a UI-only operation and
   * does not abort the underlying run.
   */
  const dismissRun = useCallback((runId: string) => {
    missesRef.current.delete(runId);
    setPersisted((prev) => {
      if (!prev.some((r) => r.runId === runId)) return prev;
      const next = prev.filter((r) => r.runId !== runId);
      saveToStorage(next);
      return next;
    });
  }, []);

  /** Clear every tracked run. Wired to a "Dismiss all" button on the banner. */
  const dismissAll = useCallback(() => {
    missesRef.current.clear();
    setPersisted(() => {
      saveToStorage([]);
      return [];
    });
  }, []);

  useEffect(() => {
    let cancelled = false;
    const tick = async () => {
      const ids = persisted.map((r) => r.runId);
      if (ids.length === 0) return;

      const outcomes: PollOutcome[] = await Promise.all(
        ids.map(async (runId): Promise<PollOutcome> => {
          try {
            // The active-runs hook always has the suiteId stored alongside
            // the runId (it's persisted at trackRun time), so pass it to
            // the by-id GET as a hint. An in-progress run is stored at
            // PK=SUITE#{suiteId}, SK=RUN#{startTime} and is invisible to
            // the by-id endpoint without this hint.
            const tracked = persisted.find((p) => p.runId === runId);
            const url = tracked
              ? `/runs/${runId}?suiteId=${encodeURIComponent(tracked.suiteId)}`
              : `/runs/${runId}`;
            const response = await apiClient.get<{
              run: TestRun;
              progress?: { completed: number; total: number };
            }>(url);
            const completed =
              response.progress?.completed ??
              response.run.passed + response.run.failed + response.run.errors;
            const total = response.progress?.total ?? response.run.totalCases;
            return { runId, kind: "ok", run: response.run, completed, total };
          } catch (err) {
            if (err instanceof ApiClientError && err.status === 404) {
              return { runId, kind: "missing" };
            }
            const status =
              err instanceof ApiClientError ? err.status : 0;
            return { runId, kind: "error", status };
          }
        }),
      );
      if (cancelled) return;

      setPersisted((prev) => {
        const byId = new Map(prev.map((r) => [r.runId, { ...r }]));
        const now = Date.now();
        for (const o of outcomes) {
          const entry = byId.get(o.runId);
          if (!entry) continue;
          if (o.kind === "ok") {
            entry.lastStatus = o.run.status;
            entry.lastTotal = o.total;
            entry.lastCompleted = o.completed;
            missesRef.current.delete(o.runId);
          } else if (o.kind === "missing") {
            const first = missesRef.current.get(o.runId) ?? now;
            missesRef.current.set(o.runId, first);
          }
          // 5xx / network: ignore — leave the cached lastStatus alone.
        }

        const next: PersistedRun[] = [];
        for (const r of byId.values()) {
          if (isTerminal(r.lastStatus)) continue;
          const firstMiss = missesRef.current.get(r.runId);
          if (firstMiss !== undefined && now - firstMiss > STALE_AFTER_MS) {
            missesRef.current.delete(r.runId);
            continue;
          }
          next.push(r);
        }
        // Avoid an unnecessary state update — and the resulting effect
        // re-run — when nothing changed.
        if (
          next.length === prev.length &&
          next.every(
            (r, i) =>
              prev[i].runId === r.runId &&
              prev[i].lastStatus === r.lastStatus &&
              prev[i].lastCompleted === r.lastCompleted &&
              prev[i].lastTotal === r.lastTotal,
          )
        ) {
          return prev;
        }
        saveToStorage(next);
        return next;
      });
    };

    if (persisted.length === 0) return;
    void tick();
    const id = setInterval(() => {
      void tick();
    }, POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
    // We deliberately depend on length, not the array, so the timer
    // doesn't restart on every status mutation. Adds (via trackRun) flow
    // through the length change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [persisted.length]);

  return { runs: persisted.map(toView), trackRun, dismissRun, dismissAll };
}
