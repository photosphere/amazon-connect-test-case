/**
 * Backward-compatibility tests for the test-case-validity-analysis feature.
 *
 * Validates Requirements 8.1, 8.2, 8.3, 8.4:
 *   - Persisted records without `testCaseField` on recommendations are treated
 *     as agent-targeted by `partitionByTargetType`.
 *   - Persisted records without `testCaseDefect` are treated as `false`.
 *   - Existing `ANALYSIS#CASE#` and `ANALYSIS#SUITE` records render unchanged
 *     through the partitioning and bucketing utilities.
 */
import { describe, it, expect } from "vitest";

import {
  partitionByTargetType,
  bucketByTargetField,
} from "@shared/utils/recommendation-bucketing";
import type {
  Recommendation,
  RecommendationTarget,
} from "@shared/types";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Simulates a pre-feature PerCaseAnalysis record as read from DynamoDB.
 * These records have no `testCaseDefect` field and their recommendations
 * carry no `testCaseField` property.
 */
interface LegacyPerCaseAnalysis {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;
  recommendations: Recommendation[];
  generatedAt: string;
  modelId: string;
  // Note: `testCaseDefect` intentionally absent — simulates pre-feature record.
  // Note: `failureAnalysisPromptVersion` may also be absent on very old records.
}

function makeLegacyRecommendation(
  overrides: Partial<Recommendation> = {},
): Recommendation {
  return {
    targetField: "tool_description",
    targetName: "lookupTool",
    currentText: "old description",
    suggestedText: "new description",
    rationale: "Tool description was unclear",
    ...overrides,
  };
}

function makeLegacyPerCaseAnalysis(
  overrides: Partial<LegacyPerCaseAnalysis> = {},
): LegacyPerCaseAnalysis {
  return {
    caseId: "case-legacy-001",
    rootCauseCategory: "system_prompt_gap",
    explanation: "The system prompt lacks instructions for handling X.",
    traceAvailable: false,
    recommendations: [makeLegacyRecommendation()],
    generatedAt: "2024-03-15T10:00:00.000Z",
    modelId: "anthropic.claude-3-5-sonnet-20241022-v2:0",
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("Backward compatibility: test-case-validity-analysis", () => {
  describe("partitionByTargetType with pre-feature records", () => {
    it("treats recommendations without testCaseField as agent-targeted", () => {
      // Simulate pre-feature recommendations — all four ToolSurface values,
      // none have testCaseField.
      const recs: Recommendation[] = [
        makeLegacyRecommendation({ targetField: "tool_description", targetName: "toolA" }),
        makeLegacyRecommendation({ targetField: "tool_instruction", targetName: "toolB" }),
        makeLegacyRecommendation({ targetField: "tool_examples", targetName: "toolC" }),
        makeLegacyRecommendation({ targetField: "system_prompt", targetName: "system_prompt" }),
      ];

      const { agent, testCase } = partitionByTargetType(recs);

      // All recs go to agent group; none to testCase.
      expect(agent).toHaveLength(4);
      expect(testCase).toHaveLength(0);

      // Verify none of the agent recs have testCaseField.
      for (const rec of agent) {
        expect(rec.testCaseField).toBeUndefined();
      }
    });

    it("produces correct output for a mix of old agent recs and new test_case recs", () => {
      // Simulate a record that could exist after re-analysis: mix of old-style
      // agent recs (no testCaseField) and new test_case recs.
      const recs: Recommendation[] = [
        makeLegacyRecommendation({ targetField: "tool_description", targetName: "toolA" }),
        {
          targetField: "test_case" as RecommendationTarget,
          targetName: "case-001",
          currentText: "old criteria",
          suggestedText: "new criteria",
          rationale: "Test expectations too strict",
          testCaseField: "successCriteria",
        },
        makeLegacyRecommendation({ targetField: "system_prompt", targetName: "system_prompt" }),
      ];

      const { agent, testCase } = partitionByTargetType(recs);

      expect(agent).toHaveLength(2);
      expect(testCase).toHaveLength(1);

      // Agent recs preserve order.
      expect(agent[0].targetName).toBe("toolA");
      expect(agent[1].targetName).toBe("system_prompt");

      // Test case rec is correctly partitioned.
      expect(testCase[0].targetField).toBe("test_case");
      expect(testCase[0].testCaseField).toBe("successCriteria");
    });

    it("handles empty recommendations array (pre-feature record with no recs)", () => {
      const { agent, testCase } = partitionByTargetType([]);
      expect(agent).toEqual([]);
      expect(testCase).toEqual([]);
    });
  });

  describe("testCaseDefect field absence", () => {
    it("legacy records without testCaseDefect are treated as non-defect (falsy)", () => {
      const legacy = makeLegacyPerCaseAnalysis();

      // The field is absent — accessing it yields undefined, which is falsy.
      // This simulates how consuming code should check:
      //   if (analysis.testCaseDefect) { ... }  — would be false
      const asAny = legacy as unknown as Record<string, unknown>;
      expect(asAny.testCaseDefect).toBeUndefined();
      expect(Boolean(asAny.testCaseDefect)).toBe(false);
    });

    it("legacy rootCauseCategory values are not 'test_case_defect'", () => {
      // Pre-feature valid categories; none is test_case_defect.
      const categories = [
        "overlapping_tool_descriptions",
        "missing_disambiguation",
        "incorrect_tool_prioritization",
        "incomplete_tool_description",
        "system_prompt_gap",
        "missing_tool_instruction",
        "parameter_mismatch",
        "other",
      ];

      for (const cat of categories) {
        const legacy = makeLegacyPerCaseAnalysis({ rootCauseCategory: cat });
        // Suite-recommend uses `analysis.rootCauseCategory === "test_case_defect"`
        // to partition — all legacy categories evaluate to false.
        expect(legacy.rootCauseCategory === "test_case_defect").toBe(false);
      }
    });

    it("suite partition treats legacy analyses as agent-deficiency", () => {
      // Simulate what suite-recommend.ts does at line ~549:
      // if (analysis?.rootCauseCategory === "test_case_defect") → defect group
      // else → agent deficiency group
      const perCaseAnalyses = new Map<string, LegacyPerCaseAnalysis>([
        ["case-1", makeLegacyPerCaseAnalysis({ caseId: "case-1", rootCauseCategory: "system_prompt_gap" })],
        ["case-2", makeLegacyPerCaseAnalysis({ caseId: "case-2", rootCauseCategory: "other" })],
        ["case-3", makeLegacyPerCaseAnalysis({ caseId: "case-3", rootCauseCategory: "parameter_mismatch" })],
      ]);

      const testCaseDefectIds: string[] = [];
      const agentDeficiencyIds: string[] = [];
      for (const [caseId, analysis] of perCaseAnalyses) {
        if (analysis.rootCauseCategory === "test_case_defect") {
          testCaseDefectIds.push(caseId);
        } else {
          agentDeficiencyIds.push(caseId);
        }
      }

      expect(testCaseDefectIds).toHaveLength(0);
      expect(agentDeficiencyIds).toHaveLength(3);
      expect(agentDeficiencyIds).toContain("case-1");
      expect(agentDeficiencyIds).toContain("case-2");
      expect(agentDeficiencyIds).toContain("case-3");
    });
  });

  describe("existing records render unchanged through bucketing", () => {
    it("bucketByTargetField works for pre-feature recommendations (no test_case)", () => {
      const recs: Recommendation[] = [
        makeLegacyRecommendation({ targetField: "tool_description", targetName: "toolA" }),
        makeLegacyRecommendation({ targetField: "tool_instruction", targetName: "toolB" }),
        makeLegacyRecommendation({ targetField: "system_prompt", targetName: "system_prompt" }),
      ];

      // bucketByTargetField should not throw for pre-feature records.
      const buckets = bucketByTargetField(recs);

      expect(buckets.tool_description).toHaveLength(1);
      expect(buckets.tool_instruction).toHaveLength(1);
      expect(buckets.tool_examples).toHaveLength(0);
      expect(buckets.system_prompt).toHaveLength(1);

      // Verify records are unchanged.
      expect(buckets.tool_description[0]).toBe(recs[0]);
      expect(buckets.tool_instruction[0]).toBe(recs[1]);
      expect(buckets.system_prompt[0]).toBe(recs[2]);
    });

    it("pre-feature recs must be filtered before bucketByTargetField if mixed with test_case", () => {
      // bucketByTargetField throws on unknown targetField (including "test_case").
      // Callers must use partitionByTargetType first to separate test_case recs.
      const mixedRecs: Recommendation[] = [
        makeLegacyRecommendation({ targetField: "tool_description" }),
        {
          targetField: "test_case" as RecommendationTarget,
          targetName: "case-001",
          currentText: "old",
          suggestedText: "new",
          rationale: "fix test",
          testCaseField: "successCriteria",
        },
      ];

      // Partition first...
      const { agent, testCase } = partitionByTargetType(mixedRecs);

      // ...then bucket only the agent recs (safe).
      const buckets = bucketByTargetField(agent as Recommendation[]);
      expect(buckets.tool_description).toHaveLength(1);

      // test_case recs handled separately.
      expect(testCase).toHaveLength(1);
      expect(testCase[0].targetField).toBe("test_case");
    });

    it("ANALYSIS#SUITE persisted record with only agent recs partitions unchanged", () => {
      // Simulate reading a per-suite persisted record written before this feature.
      const persistedSuiteRecs: Recommendation[] = [
        makeLegacyRecommendation({ targetField: "tool_description", targetName: "RouteTool" }),
        makeLegacyRecommendation({ targetField: "tool_instruction", targetName: "PaymentTool" }),
        makeLegacyRecommendation({ targetField: "system_prompt", targetName: "system_prompt" }),
      ];

      const { agent, testCase } = partitionByTargetType(persistedSuiteRecs);

      // All recs are agent-targeted.
      expect(agent).toHaveLength(3);
      expect(testCase).toHaveLength(0);

      // Records are reference-identical (no transformation applied).
      expect(agent[0]).toBe(persistedSuiteRecs[0]);
      expect(agent[1]).toBe(persistedSuiteRecs[1]);
      expect(agent[2]).toBe(persistedSuiteRecs[2]);
    });
  });
});
