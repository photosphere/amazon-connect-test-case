// Test whether UpdateSessionData (ANI injection) between CreateSession and the
// first SendMessage is what flips routing from ORCHESTRATION to SELF_SERVICE.
import {
  QConnectClient,
  CreateSessionCommand,
  SendMessageCommand,
  GetNextMessageCommand,
  ListSpansCommand,
  UpdateSessionDataCommand,
} from "@aws-sdk/client-qconnect";

const REGION = "us-east-1";
const ASSISTANT_ID = "5664eea5-381d-468e-bfba-302b69ae6dec";
const ANYBANK = "d54d3dee-b9ec-415a-9a4b-b4769426f365";
const UTTERANCE = "Hey can you pull up my mortgage and tell me what my current interest is?";

const client = new QConnectClient({ region: REGION });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function pollOnce(sessionId, token) {
  let cur = token;
  for (let i = 0; i < 8; i++) {
    const r = await client.send(
      new GetNextMessageCommand({ assistantId: ASSISTANT_ID, sessionId, nextMessageToken: cur })
    );
    const status = r.conversationState?.status;
    cur = r.nextMessageToken ?? cur;
    if (status === "READY" || status === "CLOSED") break;
    await sleep(400);
  }
}

async function spanInfo(sessionId) {
  const types = new Set();
  let nextToken, text = "";
  do {
    const resp = await client.send(
      new ListSpansCommand({ assistantId: ASSISTANT_ID, sessionId, nextToken, maxResults: 100 })
    );
    for (const s of resp.spans ?? []) {
      const a = s.attributes ?? {};
      if (a.aiAgentType) types.add(`${a.aiAgentType}:${a.aiAgentName}`);
      for (const o of a.outputMessages ?? []) {
        for (const v of o.values ?? []) if (v.text?.value) text = v.text.value;
      }
    }
    nextToken = resp.nextToken;
  } while (nextToken);
  return { types: [...types], text };
}

async function probe(label, { injectData, sendData }) {
  const name = `probe2-${Math.random().toString(16).slice(2, 10)}`;
  try {
    const cs = await client.send(
      new CreateSessionCommand({ assistantId: ASSISTANT_ID, name })
    );
    const sessionId = cs.session?.sessionId;

    if (injectData) {
      await client.send(
        new UpdateSessionDataCommand({
          assistantId: ASSISTANT_ID,
          sessionId,
          data: [{ key: "ANI", value: { stringValue: "4074629069" } }],
        })
      );
    }

    const sm = await client.send(
      new SendMessageCommand({
        assistantId: ASSISTANT_ID,
        sessionId,
        type: "TEXT",
        message: { value: { text: { value: UTTERANCE } } },
        aiAgentId: ANYBANK,
      })
    );
    await pollOnce(sessionId, sm.nextMessageToken);
    await sleep(1500);
    const info = await spanInfo(sessionId);
    console.log(`\n### ${label}`);
    console.log(`session=${sessionId}`);
    console.log(`agentTypes=${JSON.stringify(info.types)}`);
    console.log(`agentText="${info.text.slice(0, 120)}"`);
  } catch (e) {
    console.log(`\n### ${label}\nERROR: ${e.name}: ${e.message}`);
  }
}

// Baseline: no session data injection (should be ORCHESTRATION)
await probe("1: NO UpdateSessionData", { injectData: false });

// With ANI injection via UpdateSessionData (mirrors the real run)
await probe("2: WITH UpdateSessionData(ANI) before first SendMessage", { injectData: true });

console.log("\nDONE");
