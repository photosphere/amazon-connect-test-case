/**
 * Unit tests for the Prompts Lambda handler in
 * `src/backend/handlers/prompts.ts`.
 *
 * The handler dispatches API Gateway proxy events by `(httpMethod, resource)`
 * and delegates Prompts_Store CRUD to a `DynamoDBService` instance. This file
 * mocks the store via the handler's `_setPromptStore` test injection point and
 * mocks the raw DynamoDB document client (used for the best-effort audit write
 * and the `active-runs` scan) via `_setDDBClient`.
 *
 * The invariants under test follow the task description directly:
 *
 *   - `GET /prompts` returns all thirteen entries sorted by category then by
 *     name (case-insensitive), with the prompt body fields (`defaultText` /
 *     `overrideText`) absent (R2.4).
 *   - `GET /prompts/{promptKey}` returns `defaultText` byte-for-byte and
 *     `effectiveText = override.text ?? defaultText` (R3.1, R3.3).
 *   - `PUT /prompts/{promptKey}` increments the persisted `version` by exactly
 *     one and snapshots the prior override into history via the store's
 *     `putPromptOverride(_, priorVersion, priorOverride, "edit")` call (R4.2,
 *     R4.3).
 *   - `POST /prompts/{promptKey}/reset` returns 400 `RESET_CONFIRMATION_REQUIRED`
 *     when `confirm` is missing or not strictly `true` (R6.6); the no-override
 *     reset is idempotent (R6.4).
 *   - `GET /prompts/{promptKey}/history` returns history sorted by `version`
 *     descending with at most ten entries (R7.2, R7.3).
 *   - An audit-write failure does NOT affect the 200 response on edits or
 *     resets (R9.3 — best-effort audit posture).
 *
 * _Validates: Requirements 2.1-2.5, 3.1-3.4, 4.1-4.4, 6.1-6.6, 7.1-7.4, 9.1-9.4_
 */

import {
  afterEach,
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from "vitest";
import type { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

import {
  _setDDBClient,
  _setPromptStore,
  handler,
  type APIGatewayEvent,
} from "../../src/backend/handlers/prompts";
import {
  PROMPT_REGISTRY,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";
import type {
  PromptHistoryEntry,
  PromptKey,
  PromptOverride,
} from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Constants & fixtures
// ---------------------------------------------------------------------------

const TEST_USER = "user-test-1";

/**
 * Build a minimal API Gateway proxy event with the authorizer claims wired so
 * `extractAuth` returns a valid principal. Each test that varies the route or
 * body spreads its own overrides on top.
 */
function makeEvent(overrides: Partial<APIGatewayEvent> = {}): APIGatewayEvent {
  return {
    httpMethod: "GET",
    resource: "/prompts",
    pathParameters: null,
    body: null,
    requestContext: {
      authorizer: {
        claims: { sub: TEST_USER },
      },
    },
    ...overrides,
  };
}

/**
 * Build a `DynamoDBService`-shaped stub whose Prompts_Store methods are
 * `vi.fn()` instances. Tests inject this via `_setPromptStore` and reach into
 * the returned object to set per-test return values, then assert call shapes
 * via the mock metadata.
 *
 * The service exposes other methods (suites, runs, results, audit) but the
 * Prompts handler only consults the six listed below, so the stub stays
 * narrow. A `Proxy` would work but `as unknown as DynamoDBService` keeps the
 * call sites' types honest at the cost of a single cast.
 */
type MockPromptStore = {
  getPromptOverride: ReturnType<typeof vi.fn>;
  listPromptOverrides: ReturnType<typeof vi.fn>;
  putPromptOverride: ReturnType<typeof vi.fn>;
  deletePromptOverride: ReturnType<typeof vi.fn>;
  listPromptHistory: ReturnType<typeof vi.fn>;
  evictOldestHistoryEntry: ReturnType<typeof vi.fn>;
  /**
   * Reads the highest persisted HISTORY-row version for a prompt.
   * Default-resolves to 0 so the steady-state PUT path (no history,
   * no override) lands at v=1 as before. Tests covering the
   * post-reset-edit path override this to non-zero values to
   * exercise the v=N+1 collision-avoidance branch in the handler.
   */
  getLatestHistoryVersion: ReturnType<typeof vi.fn>;
};

function makeMockStore(): MockPromptStore {
  return {
    getPromptOverride: vi.fn(),
    listPromptOverrides: vi.fn(),
    putPromptOverride: vi.fn(),
    deletePromptOverride: vi.fn(),
    listPromptHistory: vi.fn(),
    evictOldestHistoryEntry: vi.fn().mockResolvedValue(undefined),
    getLatestHistoryVersion: vi.fn().mockResolvedValue(0),
  };
}

/**
 * Wire a `MockPromptStore` into the handler. Returns the same reference so
 * the test can capture call args after the handler runs.
 */
function injectStore(store: MockPromptStore): MockPromptStore {
  _setPromptStore(store as unknown as DynamoDBService);
  return store;
}

/**
 * Build a `DynamoDBDocumentClient`-shaped mock. The handler issues `PutCommand`
 * for audit writes and `ScanCommand` for the `active-runs` count, both via
 * `client.send`. Tests provide a `send` implementation that either succeeds
 * (default: empty result), or throws (for the audit-failure cases).
 */
function makeMockDocClient(opts: {
  /** Optional per-command handler overrides. Falls back to a 200-shaped reply. */
  onSend?: (cmd: { constructor: { name: string }; input: unknown }) => unknown;
}): DynamoDBDocumentClient {
  const defaultHandler = (cmd: { constructor: { name: string } }) => {
    // ScanCommand for active-runs returns an empty page; PutCommand for audit
    // returns an empty {} per the SDK contract. Either way, the handler does
    // not depend on the response shape beyond it being non-throwing.
    if (cmd.constructor.name === "ScanCommand") {
      return { Items: [], LastEvaluatedKey: undefined };
    }
    return {};
  };
  const send = vi.fn(async (cmd: { constructor: { name: string }; input: unknown }) => {
    if (opts.onSend) return opts.onSend(cmd);
    return defaultHandler(cmd);
  });
  return { send } as unknown as DynamoDBDocumentClient;
}

/**
 * Build a canonical override row for `failure_analysis`. Tests that need a
 * different prompt or different fields spread their own overrides on top of
 * this base — keeping the per-test setup short.
 */
function makeOverride(args: Partial<PromptOverride> = {}): PromptOverride {
  return {
    promptKey: "failure_analysis",
    text: "Override text. Failures: {failure_summary}",
    modelKey: "claude_haiku_4_5",
    inferenceParameters: { maxTokens: 2048 },
    version: 3,
    lastModifiedAt: "2024-06-01T12:00:00.000Z",
    lastModifiedBy: "user-prior",
    ...args,
  };
}

// ---------------------------------------------------------------------------
// Test scaffolding
// ---------------------------------------------------------------------------

describe("Prompts handler", () => {
  let store: MockPromptStore;

  beforeEach(() => {
    store = injectStore(makeMockStore());
    _setDDBClient(makeMockDocClient({}));
  });

  afterEach(() => {
    _setPromptStore(null);
    _setDDBClient(null);
    vi.clearAllMocks();
  });

  // -------------------------------------------------------------------------
  // GET /prompts
  // -------------------------------------------------------------------------

  describe("GET /prompts", () => {
    it("returns all thirteen registry entries sorted by category then by name with body fields absent (R2.1, R2.2, R2.4)", async () => {
      // No overrides — every prompt resolves to its bundled default.
      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>(),
      );

      const response = await handler(
        makeEvent({ httpMethod: "GET", resource: "/prompts" }),
      );

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        prompts: Array<{
          promptKey: PromptKey;
          name: string;
          category: string;
          currentModelKey: string;
          isOverridden: boolean;
          version: number;
          // The keys we explicitly assert are NOT present:
          defaultText?: string;
          overrideText?: string;
          effectiveText?: string;
          text?: string;
        }>;
      };

      // The registry is the contractual catalog (R1.1) — exactly thirteen
      // entries land in the response, one per declared promptKey.
      expect(body.prompts).toHaveLength(13);
      expect(Object.keys(PROMPT_REGISTRY)).toHaveLength(13);
      const returnedKeys = body.prompts.map((p) => p.promptKey).sort();
      const expectedKeys = (Object.keys(PROMPT_REGISTRY) as PromptKey[]).sort();
      expect(returnedKeys).toEqual(expectedKeys);

      // R2.4 — body fields are NOT in the list response. We assert this
      // defensively for every returned row so a future regression that
      // accidentally serialises the full text into the list reply fails
      // here rather than blowing up the wire payload size in production.
      for (const entry of body.prompts) {
        expect(entry).not.toHaveProperty("defaultText");
        expect(entry).not.toHaveProperty("overrideText");
        expect(entry).not.toHaveProperty("effectiveText");
        expect(entry).not.toHaveProperty("text");
      }

      // R2.2 — entries sorted by category, then by name; both case-insensitive.
      // We compute the expected ordering by sorting the input keys via the
      // same comparator the handler uses, so a registry edit that adds a
      // category between deploys keeps this test green.
      const entries = (Object.keys(PROMPT_REGISTRY) as PromptKey[]).map(
        (key) => ({
          promptKey: key,
          name: PROMPT_REGISTRY[key].name,
          category: PROMPT_REGISTRY[key].category,
        }),
      );
      entries.sort((a, b) => {
        const c = a.category.localeCompare(b.category, undefined, {
          sensitivity: "base",
        });
        if (c !== 0) return c;
        return a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
      });
      expect(body.prompts.map((p) => p.promptKey)).toEqual(
        entries.map((e) => e.promptKey),
      );

      // Pristine state: no overrides → every row reports `isOverridden=false`
      // and `version=0` (R3.4 cross-check via the list endpoint).
      for (const entry of body.prompts) {
        expect(entry.isOverridden).toBe(false);
        expect(entry.version).toBe(0);
      }
    });

    it("reflects an existing override on the matching row (R2.1)", async () => {
      const override = makeOverride({ promptKey: "failure_analysis", version: 7 });
      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>([["failure_analysis", override]]),
      );

      const response = await handler(
        makeEvent({ httpMethod: "GET", resource: "/prompts" }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        prompts: Array<{
          promptKey: PromptKey;
          isOverridden: boolean;
          version: number;
          currentModelKey: string;
          lastModifiedAt: string | null;
          lastModifiedBy: string | null;
        }>;
      };

      const failureRow = body.prompts.find(
        (p) => p.promptKey === "failure_analysis",
      );
      expect(failureRow).toBeDefined();
      expect(failureRow!.isOverridden).toBe(true);
      expect(failureRow!.version).toBe(7);
      expect(failureRow!.currentModelKey).toBe("claude_haiku_4_5");
      expect(failureRow!.lastModifiedBy).toBe("user-prior");

      // Other rows remain pristine.
      const otherRow = body.prompts.find(
        (p) => p.promptKey !== "failure_analysis",
      );
      expect(otherRow!.isOverridden).toBe(false);
    });
  });

  // -------------------------------------------------------------------------
  // GET /prompts/{promptKey}
  // -------------------------------------------------------------------------

  describe("GET /prompts/{promptKey}", () => {
    it("returns defaultText byte-for-byte and effectiveText = override.text ?? defaultText (R3.1, R3.3, R3.4)", async () => {
      // No override — `effectiveText` falls back to the bundled default.
      store.getPromptOverride.mockResolvedValue(null);

      const response = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        promptKey: PromptKey;
        defaultText: string;
        effectiveText: string;
        isOverridden: boolean;
        version: number;
        lastModifiedBy: string | null;
      };

      // R3.3 — defaultText returned byte-for-byte from the registry. We use
      // strict equality to make this explicit; any normalisation (whitespace,
      // line endings) would surface as a string-length or hash mismatch.
      expect(body.defaultText).toBe(PROMPT_REGISTRY.failure_analysis.defaultText);
      // R3.1 — `effectiveText = override.text ?? defaultText`; with no
      // override, the two are identical.
      expect(body.effectiveText).toBe(body.defaultText);
      // R3.4 — pristine state surfaces `isOverridden=false`, `version=0`,
      // and `lastModifiedBy=null`.
      expect(body.isOverridden).toBe(false);
      expect(body.version).toBe(0);
      expect(body.lastModifiedBy).toBeNull();
    });

    it("returns effectiveText = override.text when an override exists (R3.1)", async () => {
      const override = makeOverride({
        promptKey: "failure_analysis",
        text: "OVERRIDE BODY {failure_summary}",
        version: 4,
      });
      store.getPromptOverride.mockResolvedValue(override);

      const response = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        defaultText: string;
        effectiveText: string;
        isOverridden: boolean;
        version: number;
      };

      // The override text wins on `effectiveText`; the bundled default is
      // still returned verbatim on `defaultText` so the UI can render the
      // side-by-side viewer per R14.1.
      expect(body.effectiveText).toBe("OVERRIDE BODY {failure_summary}");
      expect(body.defaultText).toBe(PROMPT_REGISTRY.failure_analysis.defaultText);
      expect(body.isOverridden).toBe(true);
      expect(body.version).toBe(4);
    });

    it("returns 404 PROMPT_NOT_FOUND for an unknown promptKey (R3.2)", async () => {
      const response = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "not_a_real_prompt" },
        }),
      );
      expect(response.statusCode).toBe(404);
      const body = JSON.parse(response.body) as { code: string };
      expect(body.code).toBe("PROMPT_NOT_FOUND");
      // R3.2 — no DDB read happens when the key is unknown.
      expect(store.getPromptOverride).not.toHaveBeenCalled();
    });
  });

  // -------------------------------------------------------------------------
  // PUT /prompts/{promptKey}
  // -------------------------------------------------------------------------

  describe("PUT /prompts/{promptKey}", () => {
    it("increments version by exactly one and snapshots the prior to history (R4.2, R4.3)", async () => {
      const prior = makeOverride({
        promptKey: "failure_analysis",
        version: 5,
      });
      store.getPromptOverride.mockResolvedValue(prior);
      store.putPromptOverride.mockResolvedValue(undefined);

      // `failure_analysis` has zero declared placeholders, so any plain
      // text body passes the placeholder-presence stage. Using a
      // placeholder-free prompt here keeps the test resilient to future
      // placeholder-schema changes on prompts the handler dispatch covers.
      const newText = "Diagnose this failure carefully and produce JSON.";

      const response = await handler(
        makeEvent({
          httpMethod: "PUT",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ text: newText }),
        }),
      );

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        promptKey: PromptKey;
        version: number;
        lastModifiedBy: string;
      };

      // R4.2 — version increments by exactly one (5 → 6). The handler
      // reads `priorVersion` from the existing override and passes
      // `priorVersion + 1` into the persist call.
      expect(body.version).toBe(6);
      expect(body.lastModifiedBy).toBe(TEST_USER);

      // R4.3 — `putPromptOverride` is called with `(newOverride,
      // priorVersion, priorOverride, "edit")`. The store layer inspects
      // the prior override and snapshots it as a HISTORY row before
      // writing the new OVERRIDE; we assert the call shape here so a
      // future regression that drops the prior-override argument (and
      // therefore stops snapshotting history) fails the test.
      expect(store.putPromptOverride).toHaveBeenCalledTimes(1);
      const [persisted, observedPriorVersion, observedPriorOverride, changeKind] =
        store.putPromptOverride.mock.calls[0];

      expect(persisted.version).toBe(6);
      expect(persisted.text).toBe(newText);
      expect(persisted.lastModifiedBy).toBe(TEST_USER);
      expect(typeof persisted.lastModifiedAt).toBe("string");

      expect(observedPriorVersion).toBe(5);
      expect(observedPriorOverride).toEqual(prior);
      expect(changeKind).toBe("edit");
    });

    it("first-time edit lands at version 1 with priorVersion=0 (R4.2)", async () => {
      // No prior override — first edit on a pristine prompt.
      store.getPromptOverride.mockResolvedValue(null);
      store.putPromptOverride.mockResolvedValue(undefined);

      // `failure_analysis` declares no placeholders, so any plain text
      // satisfies the validation pipeline.
      const newText = "Tune this failure-analysis prompt.";

      const response = await handler(
        makeEvent({
          httpMethod: "PUT",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ text: newText }),
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as { version: number };
      // No prior override means `priorVersion=0`, so the new version
      // is `0 + 1 = 1` per R4.2's "increment by exactly one" rule.
      expect(body.version).toBe(1);

      const [persisted, priorVersion, priorOverride] =
        store.putPromptOverride.mock.calls[0];
      expect(persisted.version).toBe(1);
      expect(priorVersion).toBe(0);
      expect(priorOverride).toBeNull();
    });

    it("edit when no history exists keeps the original behaviour (priorOverride=null, latestHistoryVersion=0 ⇒ v=1)", async () => {
      // Sanity check that pinning the new `getLatestHistoryVersion`
      // call to its default zero return value preserves the v=1
      // first-edit semantics. A regression that flipped the max()
      // logic into an off-by-one would surface here as v=2.
      store.getPromptOverride.mockResolvedValue(null);
      store.getLatestHistoryVersion.mockResolvedValue(0);
      store.putPromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makeEvent({
          httpMethod: "PUT",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ text: "First edit." }),
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as { version: number };
      expect(body.version).toBe(1);
      const [persisted] = store.putPromptOverride.mock.calls[0];
      expect(persisted.version).toBe(1);
    });

    it("post-reset edit lands at v=N+1, NOT v=1 (collision avoidance with the reset event row)", async () => {
      // Bug-fix scenario: an edit (v=1) followed by a reset persisted
      // history rows at v=1 (prior-edit snapshot) and v=2 (reset
      // event), then deleted the OVERRIDE row. The next edit MUST
      // land at v=3 to avoid colliding with either history row. The
      // handler reads both `getPromptOverride` (returns null
      // post-reset) and `getLatestHistoryVersion` (returns 2 here)
      // in parallel and uses the max + 1.
      store.getPromptOverride.mockResolvedValue(null);
      store.getLatestHistoryVersion.mockResolvedValue(2);
      store.putPromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makeEvent({
          httpMethod: "PUT",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ text: "Post-reset edit." }),
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as { version: number };
      // R4.2's "monotonic across edits and resets" interpretation:
      // the next version is one above the highest counter we've
      // ever observed for this prompt, so v=2 (history) → v=3.
      expect(body.version).toBe(3);

      const [persisted, priorVersion, priorOverride] =
        store.putPromptOverride.mock.calls[0];
      expect(persisted.version).toBe(3);
      // `priorVersion` (used for the conditional check on the
      // OVERRIDE Put) remains 0 — there is no OVERRIDE row, so the
      // condition resolves to `attribute_not_exists(version)`. The
      // history-row counter is decoupled from the conditional check.
      expect(priorVersion).toBe(0);
      expect(priorOverride).toBeNull();
    });

    it("steady-state edit uses max(priorVersion, latestHistoryVersion) so a stale latestHistoryVersion never regresses the counter", async () => {
      // Defensive shape: when an OVERRIDE row exists at v=5 and the
      // history happens to report a smaller max (e.g. between
      // writes), the handler must still increment from the OVERRIDE
      // row, not from the smaller history value. `Math.max(5, 3) +
      // 1 = 6`, not `3 + 1 = 4`.
      const prior = makeOverride({
        promptKey: "failure_analysis",
        version: 5,
      });
      store.getPromptOverride.mockResolvedValue(prior);
      store.getLatestHistoryVersion.mockResolvedValue(3);
      store.putPromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makeEvent({
          httpMethod: "PUT",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ text: "Steady-state edit." }),
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as { version: number };
      expect(body.version).toBe(6);
    });
  });

  // -------------------------------------------------------------------------
  // POST /prompts/{promptKey}/reset
  // -------------------------------------------------------------------------

  describe("POST /prompts/{promptKey}/reset", () => {
    it("returns 400 RESET_CONFIRMATION_REQUIRED when body is missing (R6.6)", async () => {
      const response = await handler(
        makeEvent({
          httpMethod: "POST",
          resource: "/prompts/{promptKey}/reset",
          pathParameters: { promptKey: "failure_analysis" },
          body: null,
        }),
      );
      expect(response.statusCode).toBe(400);
      const body = JSON.parse(response.body) as { code: string };
      expect(body.code).toBe("RESET_CONFIRMATION_REQUIRED");
      // R6.6 — no persisted record is touched on a confirmation failure.
      expect(store.deletePromptOverride).not.toHaveBeenCalled();
    });

    it("returns 400 RESET_CONFIRMATION_REQUIRED when confirm is omitted from the body (R6.6)", async () => {
      const response = await handler(
        makeEvent({
          httpMethod: "POST",
          resource: "/prompts/{promptKey}/reset",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ note: "I want to revert" }),
        }),
      );
      expect(response.statusCode).toBe(400);
      const body = JSON.parse(response.body) as { code: string };
      expect(body.code).toBe("RESET_CONFIRMATION_REQUIRED");
      expect(store.deletePromptOverride).not.toHaveBeenCalled();
    });

    it("returns 400 RESET_CONFIRMATION_REQUIRED when confirm is not strictly true (R6.6)", async () => {
      // R6.6 calls out "not equal to `true`" specifically — strings,
      // numbers, and the literal `false` all SHALL fail. We probe each.
      const candidates: Array<unknown> = ["true", 1, true /* sentinel */, false, null, 0];
      for (const value of candidates) {
        if (value === true) continue; // strict-true — covered by happy path
        const response = await handler(
          makeEvent({
            httpMethod: "POST",
            resource: "/prompts/{promptKey}/reset",
            pathParameters: { promptKey: "failure_analysis" },
            body: JSON.stringify({ confirm: value }),
          }),
        );
        expect(response.statusCode).toBe(400);
        const body = JSON.parse(response.body) as { code: string };
        expect(body.code).toBe("RESET_CONFIRMATION_REQUIRED");
      }
      expect(store.deletePromptOverride).not.toHaveBeenCalled();
    });

    it("is idempotent for the no-override case (R6.4)", async () => {
      // No prior override exists — the reset is a no-op at the store level
      // (`deletePromptOverride` returns without writing anything) and the
      // handler returns 200 with `version: 0` per R6.3.
      store.getPromptOverride.mockResolvedValue(null);
      store.deletePromptOverride.mockResolvedValue(undefined);

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/prompts/{promptKey}/reset",
        pathParameters: { promptKey: "failure_analysis" },
        body: JSON.stringify({ confirm: true }),
      });

      const first = await handler(event);
      const second = await handler(event);

      expect(first.statusCode).toBe(200);
      expect(second.statusCode).toBe(200);
      const firstBody = JSON.parse(first.body) as {
        promptKey: PromptKey;
        version: 0;
        resetAt: string;
      };
      const secondBody = JSON.parse(second.body) as {
        promptKey: PromptKey;
        version: 0;
        resetAt: string;
      };

      // R6.4 — applying the reset twice in succession leaves the prompt in
      // the same state. The shape is identical except for the timestamp.
      expect(firstBody.promptKey).toBe("failure_analysis");
      expect(firstBody.version).toBe(0);
      expect(secondBody.promptKey).toBe("failure_analysis");
      expect(secondBody.version).toBe(0);

      // The store delegate was called both times with `priorOverride=null`,
      // which the store layer treats as a no-op (no transactional write).
      // The third argument carries the resetter's identity per the
      // post-bugfix signature; the store layer ignores it on the
      // null-prior branch but the handler still computes it.
      expect(store.deletePromptOverride).toHaveBeenCalledTimes(2);
      for (const call of store.deletePromptOverride.mock.calls) {
        const [calledKey, priorOverride, resetEvent] = call;
        expect(calledKey).toBe("failure_analysis");
        expect(priorOverride).toBeNull();
        expect(resetEvent).toEqual(
          expect.objectContaining({
            modifiedBy: TEST_USER,
            modifiedAt: expect.any(String),
          }),
        );
      }
    });

    it("edit then reset passes the resetter's identity and a fresh timestamp into deletePromptOverride", async () => {
      // Bug-fix invariant: a reset is now its own versioned event with
      // its own actor/timestamp, so the handler MUST forward the
      // authenticated principal's id and a freshly-generated ISO
      // timestamp into the store's reset-event row. Earlier
      // implementations elided this argument entirely; the regression
      // it caused was a reset row attributed to whoever made the
      // prior edit, not to whoever pressed "reset".
      const prior = makeOverride({
        promptKey: "failure_analysis",
        version: 1,
        text: "Edit 1",
        lastModifiedAt: "2024-06-09T12:00:00.000Z",
        lastModifiedBy: "user-prior",
      });
      store.getPromptOverride.mockResolvedValue(prior);
      store.deletePromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makeEvent({
          httpMethod: "POST",
          resource: "/prompts/{promptKey}/reset",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ confirm: true }),
          headers: { "X-User-Email": "resetter@example.com" },
        }),
      );

      expect(response.statusCode).toBe(200);
      expect(store.deletePromptOverride).toHaveBeenCalledTimes(1);
      const [calledKey, priorOverride, resetEvent] =
        store.deletePromptOverride.mock.calls[0];
      expect(calledKey).toBe("failure_analysis");
      expect(priorOverride).toEqual(prior);
      // The resetter's identity flows through `auth.userId`; the
      // display email is forwarded onto `modifiedByEmail`. The
      // timestamp is generated by `nowISO()` at handler-call time
      // and is distinct from the prior override's `lastModifiedAt`.
      expect(resetEvent.modifiedBy).toBe(TEST_USER);
      expect(resetEvent.modifiedByEmail).toBe("resetter@example.com");
      expect(typeof resetEvent.modifiedAt).toBe("string");
      expect(resetEvent.modifiedAt).not.toBe(prior.lastModifiedAt);
    });

    it("triggers history eviction after a successful non-trivial reset (cap can overflow by 2)", async () => {
      // The reset transaction now adds two HISTORY rows in one go
      // (prior-edit snapshot + reset event), so the post-reset count
      // can exceed PROMPT_HISTORY_MAX_ENTRIES by 2 in a single user
      // action. The handler MUST call `evictOldestHistoryEntry` after
      // a successful reset to drain any surplus — same posture as
      // the edit path.
      const prior = makeOverride({ promptKey: "failure_analysis", version: 9 });
      store.getPromptOverride.mockResolvedValue(prior);
      store.deletePromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makeEvent({
          httpMethod: "POST",
          resource: "/prompts/{promptKey}/reset",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ confirm: true }),
        }),
      );

      expect(response.statusCode).toBe(200);
      expect(store.evictOldestHistoryEntry).toHaveBeenCalledTimes(1);
      expect(store.evictOldestHistoryEntry.mock.calls[0][0]).toBe(
        "failure_analysis",
      );
    });

    it("does NOT trigger history eviction on the no-op reset (no rows were added)", async () => {
      // Idempotent reset path: no prior override exists, so the
      // store-level call is a no-op (no DDB write at all). Since no
      // history rows were added, the eviction is unnecessary — and
      // skipping it avoids one DDB Query per "reset against an
      // already-default prompt" call.
      store.getPromptOverride.mockResolvedValue(null);
      store.deletePromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makeEvent({
          httpMethod: "POST",
          resource: "/prompts/{promptKey}/reset",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ confirm: true }),
        }),
      );

      expect(response.statusCode).toBe(200);
      expect(store.evictOldestHistoryEntry).not.toHaveBeenCalled();
    });
  });

  // -------------------------------------------------------------------------
  // GET /prompts/{promptKey}/history
  // -------------------------------------------------------------------------

  describe("GET /prompts/{promptKey}/history", () => {
    it("returns history sorted by version descending with at most ten entries (R7.2, R7.3)", async () => {
      // Build twelve entries, returned by the store newest-first (the store
      // already issues `Query` with `ScanIndexForward: false`). The handler
      // SHALL trim to the documented cap (`PROMPT_HISTORY_MAX_ENTRIES = 10`)
      // and SHALL preserve the descending order.
      const definition = PROMPT_REGISTRY.failure_analysis;
      const entries: PromptHistoryEntry[] = [];
      for (let v = 12; v >= 1; v--) {
        entries.push({
          promptKey: "failure_analysis",
          version: v,
          text: `Version ${v} text`,
          modelKey: definition.defaultModelKey,
          inferenceParameters: { maxTokens: 1024 },
          modifiedAt: `2024-06-${String(v).padStart(2, "0")}T00:00:00.000Z`,
          modifiedBy: `user-${v}`,
          changeKind: "edit",
        });
      }
      store.listPromptHistory.mockResolvedValue(entries);

      const response = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}/history",
          pathParameters: { promptKey: "failure_analysis" },
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        history: Array<{ version: number; modifiedBy: string }>;
      };

      // R7.2 — at most ten entries returned even when the store hands us
      // more (e.g. between writes before `evictOldestHistoryEntry` runs).
      expect(body.history).toHaveLength(10);
      // R7.3 — `version` descending; the first entry is the most recent.
      const versions = body.history.map((e) => e.version);
      const sortedDesc = [...versions].sort((a, b) => b - a);
      expect(versions).toEqual(sortedDesc);
      expect(versions[0]).toBe(12);
      // The trimmed-out entries are the oldest (versions 1 and 2).
      expect(versions).not.toContain(1);
      expect(versions).not.toContain(2);
    });

    it("returns an empty history list when the prompt has never been overridden (R7.4)", async () => {
      // No OVERRIDE row, no HISTORY rows — the prompt is running its
      // bundled default. The handler MUST NOT synthesize a row in
      // this state.
      store.getPromptOverride.mockResolvedValue(null);
      store.listPromptHistory.mockResolvedValue([]);

      const response = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}/history",
          pathParameters: { promptKey: "failure_analysis" },
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as { history: unknown[] };
      expect(body.history).toEqual([]);
    });

    it("synthesizes a top-of-list row from the current OVERRIDE row so N edits show as N rows (versions N…1)", async () => {
      // First-edit shape: there's an OVERRIDE row at version 1 but no
      // persisted HISTORY rows yet (the first edit replaced the
      // bundled default, which is implicit and never snapshots).
      // The handler MUST surface a synthetic top-of-list entry sourced
      // from the OVERRIDE row so the user sees a row labelled
      // "Version 1" immediately after their first save — not an
      // empty table that fills in only on the second save.
      const override = makeOverride({
        promptKey: "failure_analysis",
        version: 1,
        text: "Edit 1",
        modelKey: "claude_haiku_4_5",
        inferenceParameters: { maxTokens: 2048 },
        lastModifiedAt: "2024-06-09T12:00:00.000Z",
        lastModifiedBy: "user-edit-1",
        lastModifiedByEmail: "alice@example.com",
      });
      store.getPromptOverride.mockResolvedValue(override);
      store.listPromptHistory.mockResolvedValue([]);

      const firstEditResponse = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}/history",
          pathParameters: { promptKey: "failure_analysis" },
        }),
      );
      expect(firstEditResponse.statusCode).toBe(200);
      const firstEditBody = JSON.parse(firstEditResponse.body) as {
        history: Array<{
          version: number;
          text: string;
          modelKey: string;
          modifiedAt: string;
          modifiedBy: string;
          modifiedByEmail?: string;
          changeKind: string;
        }>;
      };
      expect(firstEditBody.history).toHaveLength(1);
      const [firstEntry] = firstEditBody.history;
      expect(firstEntry.version).toBe(1);
      expect(firstEntry.text).toBe("Edit 1");
      expect(firstEntry.modelKey).toBe("claude_haiku_4_5");
      expect(firstEntry.modifiedBy).toBe("user-edit-1");
      expect(firstEntry.modifiedByEmail).toBe("alice@example.com");
      // The synthetic entry must be tagged "edit" — a reset clears
      // the OVERRIDE row, so by construction the override only
      // exists when the most recent action that *kept* an override
      // was an edit.
      expect(firstEntry.changeKind).toBe("edit");

      // Second-edit shape: the OVERRIDE row is now at version 2; the
      // first edit has been snapshotted into HISTORY. The handler
      // MUST surface both — synthetic v2 on top, persisted v1 below.
      const secondOverride = makeOverride({
        promptKey: "failure_analysis",
        version: 2,
        text: "Edit 2",
        lastModifiedAt: "2024-06-09T13:00:00.000Z",
        lastModifiedBy: "user-edit-2",
      });
      store.getPromptOverride.mockResolvedValue(secondOverride);
      store.listPromptHistory.mockResolvedValue([
        {
          promptKey: "failure_analysis",
          version: 1,
          text: "Edit 1",
          modelKey: "claude_haiku_4_5",
          inferenceParameters: { maxTokens: 2048 },
          modifiedAt: "2024-06-09T12:00:00.000Z",
          modifiedBy: "user-edit-1",
          modifiedByEmail: "alice@example.com",
          changeKind: "edit",
        },
      ]);

      const secondEditResponse = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}/history",
          pathParameters: { promptKey: "failure_analysis" },
        }),
      );
      expect(secondEditResponse.statusCode).toBe(200);
      const secondEditBody = JSON.parse(secondEditResponse.body) as {
        history: Array<{ version: number; text: string }>;
      };
      expect(secondEditBody.history).toHaveLength(2);
      expect(secondEditBody.history.map((e) => e.version)).toEqual([2, 1]);
      expect(secondEditBody.history[0].text).toBe("Edit 2");
      expect(secondEditBody.history[1].text).toBe("Edit 1");
    });

    it("trims the combined synthetic+persisted list to the documented ten-entry cap (R7.2)", async () => {
      // OVERRIDE row at version 11 plus 11 persisted HISTORY rows
      // (versions 10 down to 1 — that's the steady state after edits
      // 1…11 have landed). The combined list is 12 entries; the cap
      // must trim to 10 newest, dropping versions 2 and 1.
      const override = makeOverride({
        promptKey: "failure_analysis",
        version: 11,
        text: "Edit 11",
        lastModifiedAt: "2024-06-11T00:00:00.000Z",
        lastModifiedBy: "user-edit-11",
      });
      store.getPromptOverride.mockResolvedValue(override);
      const persisted: PromptHistoryEntry[] = [];
      for (let v = 10; v >= 1; v--) {
        persisted.push({
          promptKey: "failure_analysis",
          version: v,
          text: `Edit ${v}`,
          modelKey: "claude_sonnet_4_6",
          inferenceParameters: { maxTokens: 4096 },
          modifiedAt: `2024-06-${String(v).padStart(2, "0")}T00:00:00.000Z`,
          modifiedBy: `user-${v}`,
          changeKind: "edit",
        });
      }
      store.listPromptHistory.mockResolvedValue(persisted);

      const response = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}/history",
          pathParameters: { promptKey: "failure_analysis" },
        }),
      );
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        history: Array<{ version: number }>;
      };
      expect(body.history).toHaveLength(10);
      // Newest first: the synthetic v11 leads, then v10…v2; v1 was
      // trimmed by the cap.
      const versions = body.history.map((e) => e.version);
      expect(versions[0]).toBe(11);
      expect(versions).not.toContain(1);
    });
  });

  // -------------------------------------------------------------------------
  // Audit best-effort posture (R9.3)
  // -------------------------------------------------------------------------

  describe("audit write failures do not affect the 200 response (R9.3)", () => {
    it("PUT returns 200 even when the audit PutCommand throws", async () => {
      const prior = makeOverride({
        promptKey: "failure_analysis",
        version: 2,
      });
      store.getPromptOverride.mockResolvedValue(prior);
      store.putPromptOverride.mockResolvedValue(undefined);

      // The handler issues PutCommand for audit records via the raw
      // `DynamoDBDocumentClient`. We make the client throw on PutCommand
      // (so the audit write fails) while leaving ScanCommand intact for
      // any incidental traffic. The handler's try/catch wrapper swallows
      // the audit error per R9.3 — the 200 stands and the override
      // remains in effect.
      const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});
      _setDDBClient(
        makeMockDocClient({
          onSend: (cmd) => {
            if (cmd.constructor.name === "PutCommand") {
              throw new Error("Simulated audit write failure");
            }
            return { Items: [] };
          },
        }),
      );

      // `failure_analysis` declares no placeholders, so a plain text body
      // passes the validation pipeline cleanly — leaving the audit-write
      // failure as the only error path the test is exercising.
      const newText = "Diagnose this failure carefully and produce JSON.";
      const response = await handler(
        makeEvent({
          httpMethod: "PUT",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ text: newText }),
        }),
      );

      // R9.3 — best-effort audit. The override write succeeded, so the
      // handler returns 200 even though the audit `PutCommand` threw. The
      // store-level call still happened exactly once.
      expect(response.statusCode).toBe(200);
      expect(store.putPromptOverride).toHaveBeenCalledTimes(1);
      // The audit failure is logged at error level (the handler uses
      // `console.error`). We don't assert the exact message — only that
      // the failure was surfaced to the operator's logs.
      expect(consoleError).toHaveBeenCalled();
      consoleError.mockRestore();
    });

    it("POST /reset returns 200 even when the audit PutCommand throws", async () => {
      // A prior override exists so the reset is the non-trivial path
      // (transactional history snapshot + override delete). The audit
      // record we attempt to write afterwards is best-effort.
      const prior = makeOverride({
        promptKey: "failure_analysis",
        version: 4,
      });
      store.getPromptOverride.mockResolvedValue(prior);
      store.deletePromptOverride.mockResolvedValue(undefined);

      const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});
      _setDDBClient(
        makeMockDocClient({
          onSend: (cmd) => {
            if (cmd.constructor.name === "PutCommand") {
              throw new Error("Simulated audit write failure");
            }
            return { Items: [] };
          },
        }),
      );

      const response = await handler(
        makeEvent({
          httpMethod: "POST",
          resource: "/prompts/{promptKey}/reset",
          pathParameters: { promptKey: "failure_analysis" },
          body: JSON.stringify({ confirm: true }),
        }),
      );

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        promptKey: PromptKey;
        version: 0;
      };
      expect(body.promptKey).toBe("failure_analysis");
      expect(body.version).toBe(0);
      expect(store.deletePromptOverride).toHaveBeenCalledTimes(1);
      expect(consoleError).toHaveBeenCalled();
      consoleError.mockRestore();
    });
  });

  // -------------------------------------------------------------------------
  // Sanity check: one of the SUPPORTED_MODELS the registry can resolve to
  // exists and is consistent with the list endpoint's display-name lookup.
  // This guards against a registry/model-catalog mismatch that would
  // surface as a runtime crash inside `handleListPrompts`.
  // -------------------------------------------------------------------------

  describe("registry/model catalog consistency", () => {
    it("every registry entry's defaultModelKey resolves in SUPPORTED_MODELS", () => {
      for (const promptKey of Object.keys(PROMPT_REGISTRY) as PromptKey[]) {
        const definition = PROMPT_REGISTRY[promptKey];
        expect(SUPPORTED_MODELS[definition.defaultModelKey]).toBeDefined();
        expect(SUPPORTED_MODELS[definition.defaultModelKey].displayName).toBeTypeOf(
          "string",
        );
      }
    });
  });

  // -------------------------------------------------------------------------
  // GET /prompts/active-runs
  //
  // The endpoint counts run records whose `status ∈ {running, pending}` AND
  // whose `startTime` falls inside a recency window. Without the recency
  // cutoff, runs that were aborted abnormally (Lambda crash, Step Functions
  // abort, etc.) and never reconciled to a terminal status accumulate as
  // permanent zombies and inflate the count — surfacing on the Prompts
  // detail page as a misleading "N runs in progress" warning.
  // -------------------------------------------------------------------------

  describe("GET /prompts/active-runs", () => {
    it("issues a Scan whose FilterExpression includes the startTime recency cutoff", async () => {
      let capturedFilter: string | undefined;
      let capturedValues: Record<string, unknown> | undefined;
      _setDDBClient(
        makeMockDocClient({
          onSend: (cmd) => {
            if (cmd.constructor.name === "ScanCommand") {
              const input = cmd.input as {
                FilterExpression?: string;
                ExpressionAttributeValues?: Record<string, unknown>;
              };
              capturedFilter = input.FilterExpression;
              capturedValues = input.ExpressionAttributeValues;
              return { Items: [], LastEvaluatedKey: undefined };
            }
            return {};
          },
        }),
      );

      const response = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/active-runs",
        }),
      );

      expect(response.statusCode).toBe(200);
      expect(JSON.parse(response.body)).toEqual({ count: 0 });

      // The filter expression must reference startTime + the cutoff
      // attribute value. We assert the structural shape rather than
      // an exact substring so the implementation can re-spell the
      // expression without breaking the test.
      expect(capturedFilter).toBeDefined();
      expect(capturedFilter).toContain("startTime");
      expect(capturedValues).toBeDefined();
      expect(capturedValues).toHaveProperty(":cutoff");
      expect(capturedValues!).toMatchObject({
        ":suitePrefix": "SUITE#",
        ":runPrefix": "RUN#",
        ":running": "running",
        ":pending": "pending",
      });
      // Cutoff is an ISO-8601 instant in the past, computed at request
      // time. We accept any value within the last 24 hours so this
      // test is not flaky on slow CI; the production cutoff is 2 hours.
      const cutoff = capturedValues![":cutoff"] as string;
      expect(typeof cutoff).toBe("string");
      const cutoffMs = Date.parse(cutoff);
      expect(Number.isFinite(cutoffMs)).toBe(true);
      const ageMs = Date.now() - cutoffMs;
      expect(ageMs).toBeGreaterThan(0);
      expect(ageMs).toBeLessThan(24 * 60 * 60 * 1000);
    });

    it("returns the count of items the (recency-filtered) Scan returns, paginating defensively", async () => {
      let scanCalls = 0;
      _setDDBClient(
        makeMockDocClient({
          onSend: (cmd) => {
            if (cmd.constructor.name === "ScanCommand") {
              scanCalls++;
              // Two pages of 3 items each (DDB pagination contract):
              // page 1 returns LastEvaluatedKey, page 2 doesn't, the
              // handler sums them.
              if (scanCalls === 1) {
                return {
                  Items: [{ PK: "SUITE#a" }, { PK: "SUITE#b" }, { PK: "SUITE#c" }],
                  LastEvaluatedKey: { PK: "SUITE#c", SK: "RUN#x" },
                };
              }
              return {
                Items: [{ PK: "SUITE#d" }, { PK: "SUITE#e" }],
                LastEvaluatedKey: undefined,
              };
            }
            return {};
          },
        }),
      );

      const response = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/active-runs",
        }),
      );

      expect(response.statusCode).toBe(200);
      expect(JSON.parse(response.body)).toEqual({ count: 5 });
      expect(scanCalls).toBe(2);
    });
  });

  // -------------------------------------------------------------------------
  // X-User-Email display-hint header
  //
  // The web client propagates the signed-in user's email from the ID
  // token so the Prompts page can show "alice@example.com" instead of
  // a Cognito `sub` UUID. The header is a display hint, never used for
  // auth — these tests pin the validation + persistence contract.
  // -------------------------------------------------------------------------

  describe("X-User-Email display-hint header", () => {
    /**
     * Build a PUT event that sends a single-field text edit on
     * `failure_analysis` with the given headers map. Mirrors the
     * existing PUT test fixtures so the headers are the only variable.
     */
    function makePutEventWithHeaders(
      headers: Record<string, string | undefined>,
    ): APIGatewayEvent {
      return makeEvent({
        httpMethod: "PUT",
        resource: "/prompts/{promptKey}",
        pathParameters: { promptKey: "failure_analysis" },
        body: JSON.stringify({ text: "Updated text. No placeholders required." }),
        headers,
      });
    }

    it("persists lastModifiedByEmail on the override row when the header is a valid email", async () => {
      store.getPromptOverride.mockResolvedValue(null);
      store.putPromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makePutEventWithHeaders({
          "X-User-Email": "alice@example.com",
        }),
      );

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        lastModifiedByEmail?: string;
      };
      // Echoed in the response so the page can refresh without a
      // round-trip.
      expect(body.lastModifiedByEmail).toBe("alice@example.com");

      // Persisted on the override row passed to the store. The
      // authoritative `lastModifiedBy` UUID is preserved alongside
      // it.
      const [persisted] = store.putPromptOverride.mock.calls[0] as [
        { lastModifiedBy: string; lastModifiedByEmail?: string },
      ];
      expect(persisted.lastModifiedBy).toBe(TEST_USER);
      expect(persisted.lastModifiedByEmail).toBe("alice@example.com");
    });

    it("looks up the header case-insensitively (API Gateway preserves client casing)", async () => {
      store.getPromptOverride.mockResolvedValue(null);
      store.putPromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makePutEventWithHeaders({
          "x-user-email": "bob@example.com",
        }),
      );

      expect(response.statusCode).toBe(200);
      expect(JSON.parse(response.body).lastModifiedByEmail).toBe(
        "bob@example.com",
      );
    });

    it("ignores a malformed email value and persists no display hint", async () => {
      store.getPromptOverride.mockResolvedValue(null);
      store.putPromptOverride.mockResolvedValue(undefined);

      const response = await handler(
        makePutEventWithHeaders({
          "X-User-Email": "not-an-email",
        }),
      );

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as {
        lastModifiedByEmail?: string;
      };
      expect(body.lastModifiedByEmail).toBeUndefined();

      const [persisted] = store.putPromptOverride.mock.calls[0] as [
        { lastModifiedByEmail?: string },
      ];
      expect(persisted.lastModifiedByEmail).toBeUndefined();
    });

    it("ignores an oversized email (DDB attribute size guard)", async () => {
      store.getPromptOverride.mockResolvedValue(null);
      store.putPromptOverride.mockResolvedValue(undefined);

      // 250 chars of local-part + "@example.com" → 262 chars total,
      // above the 254 cap.
      const oversize = `${"a".repeat(250)}@example.com`;
      const response = await handler(
        makePutEventWithHeaders({
          "X-User-Email": oversize,
        }),
      );

      expect(response.statusCode).toBe(200);
      const [persisted] = store.putPromptOverride.mock.calls[0] as [
        { lastModifiedByEmail?: string },
      ];
      expect(persisted.lastModifiedByEmail).toBeUndefined();
    });

    it("omits the field entirely when the header is absent", async () => {
      store.getPromptOverride.mockResolvedValue(null);
      store.putPromptOverride.mockResolvedValue(undefined);

      const response = await handler(makePutEventWithHeaders({}));

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as Record<string, unknown>;
      expect(body).not.toHaveProperty("lastModifiedByEmail");

      const [persisted] = store.putPromptOverride.mock.calls[0] as [
        Record<string, unknown>,
      ];
      expect(persisted).not.toHaveProperty("lastModifiedByEmail");
    });

    it("surfaces the persisted email in GET /prompts and GET /prompts/{key}", async () => {
      // Build an override that already carries a lastModifiedByEmail —
      // the read paths surface it on both the list and detail
      // responses.
      const override = makeOverride({
        promptKey: "failure_analysis",
        lastModifiedByEmail: "carol@example.com",
      });
      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>([
          ["failure_analysis", override],
        ]),
      );
      store.getPromptOverride.mockResolvedValue(override);

      const listResponse = await handler(
        makeEvent({ httpMethod: "GET", resource: "/prompts" }),
      );
      expect(listResponse.statusCode).toBe(200);
      const listBody = JSON.parse(listResponse.body) as {
        prompts: Array<{ promptKey: PromptKey; lastModifiedByEmail?: string }>;
      };
      const failureRow = listBody.prompts.find(
        (p) => p.promptKey === "failure_analysis",
      )!;
      expect(failureRow.lastModifiedByEmail).toBe("carol@example.com");

      const detailResponse = await handler(
        makeEvent({
          httpMethod: "GET",
          resource: "/prompts/{promptKey}",
          pathParameters: { promptKey: "failure_analysis" },
        }),
      );
      expect(detailResponse.statusCode).toBe(200);
      const detailBody = JSON.parse(detailResponse.body) as {
        lastModifiedByEmail?: string;
      };
      expect(detailBody.lastModifiedByEmail).toBe("carol@example.com");
    });
  });
});
