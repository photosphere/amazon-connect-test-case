// Feature: connect-agent-test-platform, Property 16: Failure grouping consolidation
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import {
  groupFailuresByRootCause,
  type FailureCaseAnalysis,
  type Recommendation,
} from "@backend/handlers/analysis";

/**
 * **Validates: Requirements 12.6**
 *
 * Property 16: Failure grouping consolidation
 * For any set of failed test cases with assigned root cause categories, if 2 or more
 * cases share the same root cause category string, they SHALL be consolidated into a
 * single group. Cases with unique categories SHALL remain as individual entries.
 */

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Generates a random root cause category string. */
const categoryArb = fc
  .string({ minLength: 1, maxLength: 40 })
  .filter((s) => s.trim().length > 0);

/** Generates a random recommendation. */
const recommendationArb: fc.Arbitrary<Recommendation> = fc.record({
  targetField: fc.constantFrom("tool_description", "tool_instruction", "system_prompt"),
  targetName: fc.string({ minLength: 1, maxLength: 30 }).filter((s) => s.trim().length > 0),
  currentText: fc.string({ minLength: 1, maxLength: 100 }),
  suggestedText: fc.string({ minLength: 1, maxLength: 100 }),
  rationale: fc.string({ minLength: 1, maxLength: 100 }),
});

/** Generates a FailureCaseAnalysis with specified caseId and category. */
function failureCaseAnalysisArb(
  caseId: string,
  rootCauseCategory: string
): fc.Arbitrary<FailureCaseAnalysis> {
  return fc.record({
    caseId: fc.constant(caseId),
    rootCauseCategory: fc.constant(rootCauseCategory),
    explanation: fc.string({ minLength: 1, maxLength: 200 }),
    traceAvailable: fc.boolean(),
    recommendations: fc.array(recommendationArb, { minLength: 1, maxLength: 5 }),
  });
}

/**
 * Generates a set of failure analyses with 1–10 unique categories and 3–20 failures,
 * each randomly assigned one of the categories.
 */
const failureSetArb = fc
  .integer({ min: 1, max: 10 })
  .chain((numCategories) =>
    fc
      .uniqueArray(categoryArb, { minLength: numCategories, maxLength: numCategories })
      .chain((categories) =>
        fc
          .integer({ min: 3, max: 20 })
          .chain((numFailures) =>
            fc
              .tuple(
                fc.uniqueArray(
                  fc.string({ minLength: 1, maxLength: 20 }).filter((s) => s.trim().length > 0),
                  { minLength: numFailures, maxLength: numFailures }
                ),
                fc.array(fc.integer({ min: 0, max: numCategories - 1 }), {
                  minLength: numFailures,
                  maxLength: numFailures,
                })
              )
              .chain(([caseIds, categoryIndices]) => {
                const analyses = caseIds.map((caseId, i) => {
                  const category = categories[categoryIndices[i]];
                  return failureCaseAnalysisArb(caseId, category);
                });
                return fc.tuple(...analyses);
              })
          )
      )
  );

// ---------------------------------------------------------------------------
// Property tests
// ---------------------------------------------------------------------------

describe("Property 16: Failure grouping consolidation", () => {
  it("each group's category is unique in the output", () => {
    fc.assert(
      fc.property(failureSetArb, (analyses) => {
        const { grouped } = groupFailuresByRootCause(analyses);

        const groupCategories = grouped.map((g) => g.rootCauseCategory);
        const uniqueCategories = new Set(groupCategories);
        expect(groupCategories.length).toBe(uniqueCategories.size);
      }),
      { numRuns: 100 }
    );
  });

  it("all input failures appear in exactly one group or individual entry", () => {
    fc.assert(
      fc.property(failureSetArb, (analyses) => {
        const { individual, grouped } = groupFailuresByRootCause(analyses);

        // Collect all caseIds from both individual and grouped
        const individualCaseIds = individual.map((a) => a.caseId);
        const groupedCaseIds = grouped.flatMap((g) => g.caseIds);
        const allOutputCaseIds = [...individualCaseIds, ...groupedCaseIds];

        // Every input caseId appears in the output exactly once
        const inputCaseIds = analyses.map((a) => a.caseId);
        expect(allOutputCaseIds.sort()).toEqual(inputCaseIds.sort());

        // No duplicates in output
        const outputSet = new Set(allOutputCaseIds);
        expect(outputSet.size).toBe(allOutputCaseIds.length);
      }),
      { numRuns: 100 }
    );
  });

  it("groups with 2+ cases have all cases sharing the same category", () => {
    fc.assert(
      fc.property(failureSetArb, (analyses) => {
        const { grouped } = groupFailuresByRootCause(analyses);

        // Build a map from caseId to category from input
        const caseToCategory = new Map(
          analyses.map((a) => [a.caseId, a.rootCauseCategory])
        );

        for (const group of grouped) {
          expect(group.caseIds.length).toBeGreaterThanOrEqual(2);
          for (const caseId of group.caseIds) {
            expect(caseToCategory.get(caseId)).toBe(group.rootCauseCategory);
          }
        }
      }),
      { numRuns: 100 }
    );
  });

  it("the number of groups equals the number of categories with 2+ failures", () => {
    fc.assert(
      fc.property(failureSetArb, (analyses) => {
        const { individual, grouped } = groupFailuresByRootCause(analyses);

        // Count how many categories have 2+ failures in the input
        const categoryCounts = new Map<string, number>();
        for (const analysis of analyses) {
          categoryCounts.set(
            analysis.rootCauseCategory,
            (categoryCounts.get(analysis.rootCauseCategory) || 0) + 1
          );
        }

        const expectedGroupCount = [...categoryCounts.values()].filter((c) => c >= 2).length;
        const expectedIndividualCount = [...categoryCounts.values()].filter((c) => c === 1).length;

        expect(grouped.length).toBe(expectedGroupCount);
        expect(individual.length).toBe(expectedIndividualCount);
      }),
      { numRuns: 100 }
    );
  });

  it("total output covers the same number of unique categories as input", () => {
    fc.assert(
      fc.property(failureSetArb, (analyses) => {
        const { individual, grouped } = groupFailuresByRootCause(analyses);

        // Unique categories from output
        const outputCategories = new Set([
          ...individual.map((a) => a.rootCauseCategory),
          ...grouped.map((g) => g.rootCauseCategory),
        ]);

        // Unique categories from input
        const inputCategories = new Set(analyses.map((a) => a.rootCauseCategory));

        expect(outputCategories.size).toBe(inputCategories.size);
        for (const cat of inputCategories) {
          expect(outputCategories.has(cat)).toBe(true);
        }
      }),
      { numRuns: 100 }
    );
  });
});
