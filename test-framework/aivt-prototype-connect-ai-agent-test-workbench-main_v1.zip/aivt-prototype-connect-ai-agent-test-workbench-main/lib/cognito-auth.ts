import * as cdk from 'aws-cdk-lib';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';

export interface CognitoAuthProps {
  /**
   * The Connect instance ID (UUID) used to scope IAM permissions.
   */
  connectInstanceId: string;

  /**
   * Callback URLs for the hosted UI (e.g., CloudFront distribution URL).
   * Provided via CDK context parameter.
   */
  callbackUrls: string[];

  /**
   * Logout URLs for the hosted UI.
   */
  logoutUrls?: string[];
}

export class CognitoAuth extends Construct {
  public readonly userPool: cognito.UserPool;
  public readonly userPoolClient: cognito.UserPoolClient;
  public readonly identityPool: cognito.CfnIdentityPool;
  public readonly authenticatedRole: iam.Role;
  public readonly machineClient: cognito.UserPoolClient;
  public readonly machineClientSecretArn: string;
  public readonly tokenEndpointUrl: string;
  /** The hosted-UI domain construct. */
  public readonly userPoolDomain: cognito.UserPoolDomain;
  /**
   * The fully-qualified hosted-UI domain (e.g.
   * `my-stack-123456789012.auth.us-east-1.amazoncognito.com`), without scheme
   * or path. Used as the `cognitoDomain` field of the frontend Runtime_Config.
   */
  public readonly cognitoDomain: string;

  constructor(scope: Construct, id: string, props: CognitoAuthProps) {
    super(scope, id);

    const stack = cdk.Stack.of(this);

    // --- Cognito User Pool ---
    this.userPool = new cognito.UserPool(this, 'UserPool', {
      userPoolName: `${stack.stackName}-user-pool`,
      selfSignUpEnabled: false,
      signInAliases: { email: true },
      autoVerify: { email: true },
      passwordPolicy: {
        minLength: 8,
        requireUppercase: true,
        requireLowercase: true,
        requireDigits: true,
        requireSymbols: true,
      },
      accountRecovery: cognito.AccountRecovery.EMAIL_ONLY,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    // --- Cognito Hosted UI Domain ---
    const domain = this.userPool.addDomain('HostedUIDomain', {
      cognitoDomain: {
        domainPrefix: `${stack.stackName.toLowerCase()}-${cdk.Aws.ACCOUNT_ID}`,
      },
    });
    this.userPoolDomain = domain;
    // Fully-qualified hosted-UI domain (no scheme/path) for Runtime_Config.
    this.cognitoDomain = `${domain.domainName}.auth.${stack.region}.amazoncognito.com`;

    // --- Resource Server (test-platform/run scope) ---
    const resourceServer = this.userPool.addResourceServer('TestPlatformResourceServer', {
      identifier: 'test-platform',
      scopes: [
        {
          scopeName: 'run',
          scopeDescription: 'Execute test runs and retrieve results',
        },
      ],
    });

    // --- Interactive App Client (hosted UI) ---
    this.userPoolClient = this.userPool.addClient('WebAppClient', {
      userPoolClientName: `${stack.stackName}-web-client`,
      generateSecret: false,
      authFlows: {
        userSrp: true,
      },
      oAuth: {
        flows: {
          authorizationCodeGrant: true,
        },
        scopes: [
          cognito.OAuthScope.OPENID,
          cognito.OAuthScope.EMAIL,
          cognito.OAuthScope.PROFILE,
          cognito.OAuthScope.custom('test-platform/run'),
        ],
        callbackUrls: props.callbackUrls,
        logoutUrls: props.logoutUrls ?? props.callbackUrls,
      },
      preventUserExistenceErrors: true,
    });

    // Ensure web client is created after the resource server (needs the custom scope)
    this.userPoolClient.node.addDependency(resourceServer);

    // --- Machine-to-Machine App Client (client_credentials) ---
    this.machineClient = this.userPool.addClient('MachineClient', {
      userPoolClientName: `${stack.stackName}-machine-client`,
      generateSecret: true,
      oAuth: {
        flows: {
          clientCredentials: true,
        },
        scopes: [
          cognito.OAuthScope.custom('test-platform/run'),
        ],
      },
      preventUserExistenceErrors: true,
    });

    // Ensure machine client is created after the resource server
    this.machineClient.node.addDependency(resourceServer);

    // --- Store machine client secret in Secrets Manager ---
    const machineClientSecret = new secretsmanager.Secret(this, 'MachineClientSecret', {
      secretName: `${stack.stackName}/machine-client-secret`,
      description: 'Cognito machine client secret for CI/CD access to Connect Agent Test Platform',
      secretStringValue: this.machineClient.userPoolClientSecret,
    });
    this.machineClientSecretArn = machineClientSecret.secretArn;

    // --- Cognito Identity Pool ---
    this.identityPool = new cognito.CfnIdentityPool(this, 'IdentityPool', {
      identityPoolName: `${stack.stackName}_identity_pool`,
      allowUnauthenticatedIdentities: false,
      cognitoIdentityProviders: [
        {
          clientId: this.userPoolClient.userPoolClientId,
          providerName: this.userPool.userPoolProviderName,
        },
      ],
    });

    // --- IAM Role for Authenticated Users ---
    this.authenticatedRole = new iam.Role(this, 'AuthenticatedRole', {
      roleName: `${stack.stackName}-cognito-authenticated`,
      assumedBy: new iam.FederatedPrincipal(
        'cognito-identity.amazonaws.com',
        {
          StringEquals: {
            'cognito-identity.amazonaws.com:aud': this.identityPool.ref,
          },
          'ForAnyValue:StringLike': {
            'cognito-identity.amazonaws.com:amr': 'authenticated',
          },
        },
        'sts:AssumeRoleWithWebIdentity',
      ),
    });

    // Q in Connect session APIs scoped to the instance
    this.authenticatedRole.addToPolicy(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        actions: [
          'wisdom:CreateSession',
          'wisdom:SendMessage',
          'wisdom:GetNextMessage',
          'qconnect:CreateSession',
          'qconnect:SendMessage',
          'qconnect:GetNextMessage',
        ],
        resources: [
          `arn:aws:wisdom:${stack.region}:${stack.account}:assistant/*`,
          `arn:aws:wisdom:${stack.region}:${stack.account}:session/*`,
          `arn:aws:qconnect:${stack.region}:${stack.account}:assistant/*`,
          `arn:aws:qconnect:${stack.region}:${stack.account}:session/*`,
        ],
      }),
    );

    // Bedrock Converse API
    this.authenticatedRole.addToPolicy(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        actions: [
          'bedrock:InvokeModel',
          'bedrock:Converse',
        ],
        resources: [
          `arn:aws:bedrock:${stack.region}::foundation-model/*`,
        ],
      }),
    );

    // --- Attach role to Identity Pool ---
    new cognito.CfnIdentityPoolRoleAttachment(this, 'IdentityPoolRoleAttachment', {
      identityPoolId: this.identityPool.ref,
      roles: {
        authenticated: this.authenticatedRole.roleArn,
      },
    });

    // --- Token Endpoint URL ---
    this.tokenEndpointUrl = `https://${domain.domainName}.auth.${stack.region}.amazoncognito.com/oauth2/token`;

    // --- CDK Outputs ---
    new cdk.CfnOutput(this, 'UserPoolId', {
      value: this.userPool.userPoolId,
      description: 'Cognito User Pool ID',
    });

    new cdk.CfnOutput(this, 'UserPoolClientId', {
      value: this.userPoolClient.userPoolClientId,
      description: 'Cognito User Pool Web Client ID',
    });

    new cdk.CfnOutput(this, 'IdentityPoolId', {
      value: this.identityPool.ref,
      description: 'Cognito Identity Pool ID',
    });

    new cdk.CfnOutput(this, 'MachineClientId', {
      value: this.machineClient.userPoolClientId,
      description: 'Machine-to-machine App Client ID for CI/CD integration',
    });

    new cdk.CfnOutput(this, 'TokenEndpoint', {
      value: this.tokenEndpointUrl,
      description: 'Cognito token endpoint URL for client_credentials grant',
    });

    new cdk.CfnOutput(this, 'MachineClientSecretArn', {
      value: this.machineClientSecretArn,
      description: 'ARN of the Secrets Manager secret containing the machine client secret',
    });
  }
}
