#!/usr/bin/env python3
"""Execute the scaling test against the AI Agent for a given tool tier.

Usage:
    .venv/bin/python scratch/scaling_test/run_test.py --tier {10|20|30|40|50} [--concurrency 5]

This script:
1. Loads utterances.json and filters to utterances for tools in the active tier
2. For each utterance: CreateSession → SendMessage → poll GetNextMessage
3. Extracts tool name from conversationSessionData.Tool or records None/timeout
4. Writes per-utterance results to scratch/scaling_test/results/<timestamp>_tier<N>.json
5. Prints a summary table to stdout

Utterances run in parallel (default concurrency=5) since each uses an independent session.
"""

import argparse
import json
import random
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock

import boto3
from botocore.exceptions import ClientError

from customer_simulator import CustomerSimulator

# --- Constants ---
REGION = "us-east-1"
INSTANCE_ID = "46837cc7-8562-4b3f-92b2-1bae0ede624b"
ASSISTANT_ID = "5664eea5-381d-468e-bfba-302b69ae6dec"
AI_AGENT_ID = "8c02abb3-ba52-42cc-be7d-d01a8634d4ae"

VALID_TIERS = [10, 20, 30, 40, 50]
POLL_TIMEOUT_S = 60
POLL_INTERVAL_S = 0.3

# Exponential backoff for 429 throttling
THROTTLE_INITIAL_DELAY_S = 2.0
THROTTLE_MAX_DELAY_S = 30.0
THROTTLE_MAX_RETRIES = 3

SCRIPT_DIR = Path(__file__).resolve().parent
TOOLS_FILE = SCRIPT_DIR / "tools.json"
UTTERANCES_FILE = SCRIPT_DIR / "utterances.json"
RESULTS_DIR = SCRIPT_DIR / "results"


# --- Data Models ---


@dataclass
class TestResult:
    """Per-utterance test result record."""

    utterance_id: str
    utterance_text: str
    expected_tool: str
    actual_tool: str | None
    passed: bool
    style: str
    response_time_ms: int
    session_id: str


# --- Utility Functions ---


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Run scaling test utterances against the AI Agent"
    )
    parser.add_argument(
        "--tier",
        type=int,
        choices=VALID_TIERS,
        required=True,
        help="Tool tier to test (10, 20, 30, 40, or 50)",
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=9,
        help="Max concurrent sessions (default: 9, stays under 10 TPS limit).",
    )
    return parser.parse_args()


def load_tools() -> list[dict]:
    """Load tool definitions from tools.json."""
    return json.loads(TOOLS_FILE.read_text())


def load_utterances() -> list[dict]:
    """Load test utterances from utterances.json."""
    return json.loads(UTTERANCES_FILE.read_text())


def filter_utterances_for_tier(
    utterances: list[dict], tools: list[dict], tier: int
) -> list[dict]:
    """Filter utterances to only those targeting tools in the active tier."""
    tier_tool_names = {t["toolName"] for t in tools[:tier]}
    return [u for u in utterances if u["expected_tool"] in tier_tool_names]


def extract_tool_name(response: dict) -> str | None:
    """Extract tool name from a GetNextMessage response.

    The tool name appears in conversationSessionData under the key "Tool".
    Returns the tool name string, or None if no tool was selected.
    """
    session_data = response.get("conversationSessionData", [])
    for item in session_data:
        if item.get("key") == "Tool":
            value = item.get("value", {})
            tool_name = value.get("stringValue", "")
            if tool_name:
                return tool_name
    return None


def compute_accuracy(results: list[TestResult]) -> float:
    """Compute accuracy percentage from a list of TestResults.

    Returns (count_passed / total) * 100, or 0.0 if no results.
    """
    if not results:
        return 0.0
    passed_count = sum(1 for r in results if r.passed)
    return (passed_count / len(results)) * 100.0


def exponential_backoff_with_jitter(attempt: int) -> float:
    """Calculate delay for exponential backoff with jitter.

    Args:
        attempt: Zero-based retry attempt number.

    Returns:
        Delay in seconds to wait before retrying.
    """
    base_delay = THROTTLE_INITIAL_DELAY_S * (2**attempt)
    capped_delay = min(base_delay, THROTTLE_MAX_DELAY_S)
    # Add jitter: random value between 0 and capped_delay
    jitter = random.uniform(0, capped_delay)
    return jitter


def call_with_throttle_retry(func, **kwargs):
    """Call a boto3 API function with exponential backoff on 429 throttling.

    Args:
        func: The boto3 client method to call.
        **kwargs: Arguments to pass to the method.

    Returns:
        The API response.

    Raises:
        ClientError: If throttling persists after max retries, or for
            non-throttling errors.
    """
    for attempt in range(THROTTLE_MAX_RETRIES + 1):
        try:
            return func(**kwargs)
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            status_code = e.response.get("ResponseMetadata", {}).get(
                "HTTPStatusCode", 0
            )

            is_throttle = (
                status_code == 429
                or error_code == "ThrottlingException"
                or error_code == "TooManyRequestsException"
            )

            if is_throttle and attempt < THROTTLE_MAX_RETRIES:
                delay = exponential_backoff_with_jitter(attempt)
                print(
                    f"  [throttled] Retry {attempt + 1}/{THROTTLE_MAX_RETRIES} "
                    f"after {delay:.1f}s..."
                )
                time.sleep(delay)
                continue

            raise


# --- Core Test Logic ---


def create_session(client) -> str | None:
    """Create a fresh Q in Connect session for a single utterance.

    Returns the session ID, or None on failure.
    We don't pass aiAgentConfiguration on session creation — the agent
    is specified per-message via the aiAgentId param on SendMessage.
    """
    import uuid

    session_name = f"scaling-test-{uuid.uuid4().hex[:8]}"
    try:
        resp = call_with_throttle_retry(
            client.create_session,
            assistantId=ASSISTANT_ID,
            name=session_name,
        )
        return resp["session"]["sessionId"]
    except ClientError as e:
        print(f"  [error] CreateSession failed: {e}")
        return None


def send_message(client, session_id: str, text: str) -> str | None:
    """Send a text message to the AI Agent.

    Uses aiAgentId to override the default session agent and hit our
    orchestration agent directly.

    Returns the nextMessageToken, or None on failure.
    """
    try:
        resp = call_with_throttle_retry(
            client.send_message,
            assistantId=ASSISTANT_ID,
            sessionId=session_id,
            type="TEXT",
            message={"value": {"text": {"value": text}}},
            aiAgentId=AI_AGENT_ID,
        )
        return resp.get("nextMessageToken")
    except ClientError as e:
        print(f"  [error] SendMessage failed: {e}")
        return None


def poll_for_response(
    client, session_id: str, next_message_token: str
) -> tuple[str | None, bool, str | None]:
    """Poll GetNextMessage until tool selection or agent finishes speaking.

    Response flow:
    1. PROCESSING + real text = agent is mid-response (streaming TTS chunks)
    2. READY + tool in sessionData = tool selected, done
    3. READY + "..." + no token change = agent finished speaking, waiting for customer

    We accumulate text from PROCESSING chunks. When we hit READY with "...",
    the accumulated text is the agent's full response (likely a clarifying question).

    Returns:
        Tuple of (tool_name_or_None, timed_out, agent_text_or_None).
    """
    token = next_message_token
    start = time.monotonic()
    accumulated_text = ""

    while (time.monotonic() - start) < POLL_TIMEOUT_S:
        try:
            resp = call_with_throttle_retry(
                client.get_next_message,
                assistantId=ASSISTANT_ID,
                sessionId=session_id,
                nextMessageToken=token,
            )
        except ClientError as e:
            print(f"  [error] GetNextMessage failed: {e}")
            return None, False, None

        new_token = resp.get("nextMessageToken", token)
        conversation_state = resp.get("conversationState", {})
        status = conversation_state.get("status", "")

        # Extract text from this chunk
        response_obj = resp.get("response", {})
        chunk_text = ""
        if isinstance(response_obj, dict):
            value = response_obj.get("value", {})
            if isinstance(value, dict):
                text_obj = value.get("text", {})
                if isinstance(text_obj, dict):
                    chunk_text = text_obj.get("value", "")

        # Check for tool selection
        tool_name = extract_tool_name(resp)
        if tool_name:
            return tool_name, False, accumulated_text or chunk_text

        if status == "PROCESSING":
            # Agent is mid-response — accumulate text, keep polling
            if chunk_text and chunk_text.strip() not in ("", "...", "......", "…"):
                accumulated_text += chunk_text
            token = new_token
            time.sleep(POLL_INTERVAL_S)
            continue

        if status == "CLOSED":
            return None, False, accumulated_text or chunk_text

        if status == "READY":
            # Check if token stopped changing — agent is done, waiting for customer
            if new_token == token:
                # Agent finished. Return accumulated text as the "question"
                final_text = accumulated_text.strip() if accumulated_text.strip() else chunk_text
                return None, False, final_text if final_text.strip() not in ("", "...", "......") else None
            else:
                # Token advanced — more messages coming
                if chunk_text and chunk_text.strip() not in ("", "...", "......", "…"):
                    accumulated_text += chunk_text
                token = new_token
                time.sleep(POLL_INTERVAL_S)
                continue

        # Unknown status — keep polling
        token = new_token
        time.sleep(POLL_INTERVAL_S)

    # Timed out
    return None, True, accumulated_text or None


def run_single_utterance(
    client, utterance: dict, simulator: CustomerSimulator, max_turns: int = 10
) -> TestResult:
    """Execute a single test utterance and return the result.

    Creates a fresh session, sends the message, polls for response.
    If the agent responds with a clarifying question (text, no tool),
    uses the Bedrock-powered customer simulator to generate a natural
    follow-up response based on the scenario context. A tool selection
    on any turn within max_turns counts as the result.

    Args:
        client: boto3 qconnect client.
        utterance: The utterance record from utterances.json (includes customer_context).
        simulator: CustomerSimulator instance for generating follow-up responses.
        max_turns: Maximum number of message turns (default 3).
    """
    utterance_id = utterance["utterance_id"]
    text = utterance["text"]
    expected_tool = utterance["expected_tool"]
    style = utterance["style"]

    start_time = time.monotonic()

    # Step 1: Create session
    session_id = create_session(client)
    if session_id is None:
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        return TestResult(
            utterance_id=utterance_id,
            utterance_text=text,
            expected_tool=expected_tool,
            actual_tool=None,
            passed=False,
            style=style,
            response_time_ms=elapsed_ms,
            session_id="",
        )

    # Step 2: Send initial message
    next_token = send_message(client, session_id, text)
    if next_token is None:
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        return TestResult(
            utterance_id=utterance_id,
            utterance_text=text,
            expected_tool=expected_tool,
            actual_tool=None,
            passed=False,
            style=style,
            response_time_ms=elapsed_ms,
            session_id=session_id,
        )

    # Step 3: Poll — multi-turn loop with Bedrock-simulated customer
    actual_tool = None
    timed_out = False
    # Track conversation for the simulator's context
    conversation_history: list[dict] = [
        {"role": "user", "content": [{"text": text}]}
    ]

    for turn in range(max_turns):
        actual_tool, timed_out, agent_text = poll_for_response(client, session_id, next_token)

        # If we got a tool selection (or timeout), we're done
        if actual_tool is not None or timed_out:
            break

        # Agent responded with text (clarifying question) but no tool.
        # If we have follow-up turns remaining, use the simulator.
        if turn < max_turns - 1 and agent_text:
            # Add agent's response to conversation history
            conversation_history.append(
                {"role": "assistant", "content": [{"text": agent_text}]}
            )

            # Generate a customer response via Bedrock
            customer_response = simulator.generate_response(
                agent_message=agent_text,
                utterance=utterance,
                conversation_history=conversation_history,
            )
            print(f"    [turn {turn + 2}] Agent: \"{agent_text[:80]}...\"")
            print(f"    [turn {turn + 2}] Customer (simulated): \"{customer_response}\"")

            # Add customer response to history
            conversation_history.append(
                {"role": "user", "content": [{"text": customer_response}]}
            )

            # Send the simulated customer response to the AI Agent
            next_token = send_message(client, session_id, customer_response)
            if next_token is None:
                break
        else:
            # No agent text or no turns remaining — done
            break

    elapsed_ms = int((time.monotonic() - start_time) * 1000)

    if timed_out:
        actual_tool_display = "timeout"
    else:
        actual_tool_display = actual_tool

    passed = actual_tool == expected_tool

    return TestResult(
        utterance_id=utterance_id,
        utterance_text=text,
        expected_tool=expected_tool,
        actual_tool=actual_tool_display,
        passed=passed,
        style=style,
        response_time_ms=elapsed_ms,
        session_id=session_id,
    )


# --- Results I/O ---


def write_results(results: list[TestResult], tier: int) -> Path:
    """Write results to a timestamped JSON file.

    Returns the path to the written file.
    """
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H%M%S")
    filename = f"{timestamp}_tier{tier}.json"
    output_path = RESULTS_DIR / filename

    passed_count = sum(1 for r in results if r.passed)
    accuracy = compute_accuracy(results)

    output = {
        "tier": tier,
        "timestamp": timestamp,
        "total_utterances": len(results),
        "correct": passed_count,
        "accuracy_pct": round(accuracy, 2),
        "results": [asdict(r) for r in results],
    }

    output_path.write_text(json.dumps(output, indent=2))
    return output_path


def print_summary_table(tier: int, results: list[TestResult]) -> None:
    """Print a summary table to stdout."""
    total = len(results)
    correct = sum(1 for r in results if r.passed)
    accuracy = compute_accuracy(results)

    print()
    print("┌──────┬───────────┬─────────┬──────────┐")
    print("│ Tier │ Utterances│ Correct │ Accuracy │")
    print("├──────┼───────────┼─────────┼──────────┤")
    print(f"│ {tier:4d} │ {total:9d}│ {correct:7d} │ {accuracy:6.1f}%  │")
    print("└──────┴───────────┴─────────┴──────────┘")
    print()


# --- Main ---


def main() -> None:
    """Run the scaling test for a given tier with parallel execution."""
    args = parse_args()
    tier = args.tier
    concurrency = args.concurrency

    print(f"=== Scaling Test: Tier {tier} ===")
    print(f"  Concurrency: {concurrency} parallel sessions")
    print(f"  Poll timeout: {POLL_TIMEOUT_S}s")
    print()

    # Load data
    tools = load_tools()
    utterances = load_utterances()

    # Filter utterances for this tier
    tier_utterances = filter_utterances_for_tier(utterances, tools, tier)
    print(f"  Loaded {len(tier_utterances)} utterances for tier {tier}")
    print()

    if not tier_utterances:
        print("[error] No utterances found for this tier. Exiting.")
        sys.exit(1)

    # Create customer simulator (thread-safe — each call is independent)
    simulator = CustomerSimulator(region=REGION)
    print(f"  Customer simulator: Bedrock ({simulator.model_id})")
    print()

    # Thread-safe progress tracking
    print_lock = Lock()
    completed_count = [0]
    total = len(tier_utterances)

    def run_one(idx_utterance: tuple[int, dict]) -> TestResult:
        """Run a single utterance in a worker thread."""
        idx, utterance = idx_utterance
        # Each thread gets its own boto3 client (thread-safe)
        client = boto3.client("qconnect", region_name=REGION)

        result = run_single_utterance(client, utterance, simulator)

        with print_lock:
            completed_count[0] += 1
            status = "✓" if result.passed else "✗"
            print(
                f"  [{completed_count[0]}/{total}] "
                f"{status} {utterance['utterance_id']}: "
                f"expected={result.expected_tool}, "
                f"actual={result.actual_tool}, "
                f"time={result.response_time_ms}ms"
            )

        return result

    # Execute in parallel
    start_time = time.monotonic()
    results: list[TestResult] = []

    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = {
            executor.submit(run_one, (i, utt)): i
            for i, utt in enumerate(tier_utterances)
        }
        for future in as_completed(futures):
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                idx = futures[future]
                print(f"  [error] Utterance {idx} raised exception: {e}")

    elapsed = time.monotonic() - start_time
    print(f"\n  Total time: {elapsed:.1f}s ({elapsed/total:.1f}s avg per utterance)")

    # Sort results back into original order by utterance_id
    results.sort(key=lambda r: r.utterance_id)

    # Write results
    output_path = write_results(results, tier)
    print(f"  Results written to: {output_path}")

    # Print summary
    print_summary_table(tier, results)


if __name__ == "__main__":
    main()
