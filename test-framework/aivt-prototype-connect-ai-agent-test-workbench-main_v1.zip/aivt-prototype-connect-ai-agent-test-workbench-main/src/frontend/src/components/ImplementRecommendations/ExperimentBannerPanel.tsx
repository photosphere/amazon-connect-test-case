/**
 * ExperimentBannerPanel — a presentational banner displayed on the Run
 * Dashboard when an experiment exists for the current run. Shows status
 * and navigation links based on the experiment lifecycle.
 *
 * Key requirements addressed:
 *   - R5.1: Active experiments show status + link to ExperimentProgress
 *   - R5.2: Completed experiments show "View Experiment Results" link
 *   - R5.4: Banner updates content when terminal status reached
 *   - R5.5: Failed experiments show error indicator + "View Details" link
 *   - R5.6: Poll errors display inline "Status updates unavailable" alert
 *
 * @module components/ImplementRecommendations/ExperimentBannerPanel
 */

import Alert from '@cloudscape-design/components/alert';
import Box from '@cloudscape-design/components/box';
import Link from '@cloudscape-design/components/link';
import SpaceBetween from '@cloudscape-design/components/space-between';
import StatusIndicator from '@cloudscape-design/components/status-indicator';

import type { ExperimentRecord, ExperimentStatus } from '../../../../shared/types';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const ACTIVE_STATUSES: ExperimentStatus[] = [
  'generating_variants',
  'creating_agents',
  'running',
  'cleanup_in_progress',
];

const STATUS_LABELS: Record<ExperimentStatus, string> = {
  generating_variants: 'Generating experiment variants',
  creating_agents: 'Creating temporary test agents',
  running: 'Experiment running',
  cleanup_in_progress: 'Cleaning up temporary agents',
  completed: 'Experiment completed',
  cleaned_up: 'Experiment completed',
  failed: 'Experiment failed',
};

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface ExperimentBannerPanelProps {
  /** The experiment record to display status for. */
  experiment: ExperimentRecord;
  /** The run ID (used for building navigation links). */
  runId: string;
  /** Whether polling has failed 3+ times consecutively. */
  pollError?: boolean;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * Renders an informational banner summarizing the experiment status with
 * appropriate indicators and navigation links. Fully prop-driven — the
 * parent hook manages polling and state.
 */
export function ExperimentBannerPanel({
  experiment,
  runId,
  pollError,
}: ExperimentBannerPanelProps): JSX.Element {
  const { status, experimentId } = experiment;
  const experimentPath = `/runs/${runId}/experiments/${experimentId}`;

  return (
    <SpaceBetween size="xs">
      {pollError && (
        <Alert type="warning" statusIconAriaLabel="Warning">
          Status updates unavailable
        </Alert>
      )}
      {renderBannerContent(status, experimentPath)}
    </SpaceBetween>
  );
}

// ---------------------------------------------------------------------------
// Internal render helpers
// ---------------------------------------------------------------------------

function renderBannerContent(
  status: ExperimentStatus,
  experimentPath: string,
): JSX.Element {
  if (ACTIVE_STATUSES.includes(status)) {
    return (
      <Box>
        <SpaceBetween size="xs" direction="horizontal" alignItems="center">
          <StatusIndicator type="in-progress">
            {STATUS_LABELS[status]}
          </StatusIndicator>
          <Link href={experimentPath}>View progress</Link>
        </SpaceBetween>
      </Box>
    );
  }

  if (status === 'completed' || status === 'cleaned_up') {
    return (
      <Box>
        <SpaceBetween size="xs" direction="horizontal" alignItems="center">
          <StatusIndicator type="success">
            {STATUS_LABELS[status]}
          </StatusIndicator>
          <Link href={experimentPath}>View Experiment Results</Link>
        </SpaceBetween>
      </Box>
    );
  }

  if (status === 'failed') {
    return (
      <Box>
        <SpaceBetween size="xs" direction="horizontal" alignItems="center">
          <StatusIndicator type="error">
            {STATUS_LABELS[status]}
          </StatusIndicator>
          <Link href={experimentPath}>View Details</Link>
        </SpaceBetween>
      </Box>
    );
  }

  // Defensive: handle unexpected status values
  return (
    <Box>
      <StatusIndicator type="info">Unknown experiment status</StatusIndicator>
    </Box>
  );
}
