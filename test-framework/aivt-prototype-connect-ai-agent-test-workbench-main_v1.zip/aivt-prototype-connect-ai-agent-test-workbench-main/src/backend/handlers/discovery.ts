/**
 * Discovery Lambda — GET /agents, GET /agents/{agentId}
 *
 * Lists AI agents (filtered to ORCHESTRATION type only) and retrieves agent
 * detail including tool configurations and system prompt.
 *
 * Environment variables:
 * - CONNECT_INSTANCE_ID: The Connect instance identifier
 * - ASSISTANT_ID: The Q in Connect assistant identifier
 *
 * @module discovery
 */

import {
  QConnectClient,
  ListAIAgentsCommand,
  GetAIAgentCommand,
  GetAIPromptCommand,
  type AIAgentSummary as QConnectAgentSummary,
} from "@aws-sdk/client-qconnect";
import type { AgentSummary, AgentDetail, ToolDefinition } from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

function getRegion(): string {
  return process.env.AWS_REGION ?? "us-east-1";
}

function getAssistantId(): string {
  return process.env.ASSISTANT_ID ?? "";
}

// ---------------------------------------------------------------------------
// Client
// ---------------------------------------------------------------------------

let qconnectClient: QConnectClient | null = null;

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: getRegion() });
  }
  return qconnectClient;
}

/** @internal — allows test injection */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

// ---------------------------------------------------------------------------
// Response helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
};

function successResponse(statusCode: number, body: unknown) {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

function errorResponse(
  statusCode: number,
  error: string,
  message: string,
  retryable = false
) {
  return {
    statusCode,
    body: JSON.stringify({
      error,
      message,
      retryable,
      ...(retryable && { retryAfterSeconds: statusCode === 429 ? 5 : 2 }),
    }),
    headers: CORS_HEADERS,
  };
}

// ---------------------------------------------------------------------------
// List agents
// ---------------------------------------------------------------------------

/**
 * Fetches all AI agents from the configured assistant, paginating through
 * all results, and filters to ORCHESTRATION type only.
 */
export async function listAgents(): Promise<AgentSummary[]> {
  const client = getQConnectClient();
  const assistantId = getAssistantId();
  const agents: AgentSummary[] = [];
  let nextToken: string | undefined;

  do {
    const command = new ListAIAgentsCommand({
      assistantId,
      ...(nextToken && { nextToken }),
      maxResults: 100,
    });

    const response = await client.send(command);
    const summaries = response.aiAgentSummaries ?? [];

    for (const agent of summaries) {
      if (agent.type === "ORCHESTRATION") {
        agents.push(mapToAgentSummary(agent));
      }
    }

    nextToken = response.nextToken;
  } while (nextToken);

  return agents;
}

/**
 * Maps a Q in Connect AIAgentSummary to our AgentSummary interface.
 */
function mapToAgentSummary(agent: QConnectAgentSummary): AgentSummary {
  const toolCount = getToolCountFromSummary(agent);
  return {
    agentId: agent.aiAgentId!,
    name: agent.name!,
    type: "ORCHESTRATION",
    toolCount,
    modelId: extractModelIdFromSummary(agent),
  };
}

/**
 * Extracts the tool count from an orchestration agent summary's configuration.
 */
function getToolCountFromSummary(agent: QConnectAgentSummary): number {
  const orchestrationConfig = (agent.configuration as any)?.orchestrationAIAgentConfiguration;
  if (!orchestrationConfig?.toolConfigurations) return 0;
  return orchestrationConfig.toolConfigurations.length;
}

/**
 * Extracts model ID from the agent summary.
 */
function extractModelIdFromSummary(agent: QConnectAgentSummary): string {
  const orchestrationConfig = (agent.configuration as any)?.orchestrationAIAgentConfiguration;
  return orchestrationConfig?.orchestrationAIPromptId ?? "unknown";
}

// ---------------------------------------------------------------------------
// Get agent detail
// ---------------------------------------------------------------------------

/**
 * Fetches the YAML prompt body for a Q in Connect AI Prompt by id, plus the
 * model id the prompt is configured against. Both fields live on
 * `aiPrompt.templateConfiguration.textFullAIPromptEditTemplateConfiguration.text`
 * and `aiPrompt.modelId` respectively (per the SDK's `AIPromptData` shape).
 *
 * Returns `null` for both fields on any failure (missing prompt, AccessDenied,
 * unknown template type) so the agent-detail page degrades gracefully — the
 * tools list still renders, the system-prompt section just shows the empty
 * state.
 *
 * @param promptId - The orchestration AI prompt id from the agent's configuration
 * @returns The resolved prompt text and model id, or `null` when either could not be fetched
 */
async function fetchPromptDetail(
  promptId: string,
): Promise<{ text: string; modelId: string } | null> {
  if (!promptId) return null;
  try {
    const client = getQConnectClient();
    const response = await client.send(
      new GetAIPromptCommand({
        assistantId: getAssistantId(),
        aiPromptId: promptId,
      }),
    );
    const promptData = response.aiPrompt;
    if (!promptData) return null;

    // The SDK models templateConfiguration as a tagged union; we only know
    // how to render the text-template variant. Fall through to null for
    // any other variant rather than guessing at the body.
    const tc = promptData.templateConfiguration as
      | { textFullAIPromptEditTemplateConfiguration?: { text?: string } }
      | undefined;
    const text = tc?.textFullAIPromptEditTemplateConfiguration?.text ?? "";
    const modelId = promptData.modelId ?? "";
    if (!text && !modelId) return null;
    return { text, modelId };
  } catch (error) {
    console.warn(
      `[discovery] GetAIPrompt(${promptId}) failed: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
    return null;
  }
}

/**
 * Fetches detailed information for a specific agent including tools and system prompt.
 */
export async function getAgentDetail(agentId: string): Promise<AgentDetail | null> {
  const client = getQConnectClient();

  const command = new GetAIAgentCommand({
    assistantId: getAssistantId(),
    aiAgentId: agentId,
  });

  const response = await client.send(command);
  const agent = response.aiAgent;

  if (!agent || agent.type !== "ORCHESTRATION") {
    return null;
  }

  const orchestrationConfig = (agent.configuration as any)?.orchestrationAIAgentConfiguration;
  const tools: ToolDefinition[] = (orchestrationConfig?.toolConfigurations ?? []).map(
    (tool: any) => ({
      toolName: tool.toolName ?? "",
      toolType: tool.toolType ?? "",
      description: tool.description ?? "",
      ...(tool.instruction?.instruction && { instruction: tool.instruction.instruction }),
      inputSchema: tool.inputSchema ?? {},
      // Few-shot examples injected by the orchestration runtime alongside
      // the tool description and instruction. Treat absent / null /
      // non-array `examples` fields identically as `[]` so the field is
      // never omitted from the response and downstream consumers can read
      // it without optional-chaining (R1.2, R1.5). Spread to a fresh array
      // so the upstream array is not aliased; preserve order verbatim
      // (no sort, no trim, no dedupe) and preserve every example string
      // verbatim including embedded whitespace, newlines, and quote
      // characters (R1.3, R1.4).
      examples: Array.isArray(tool.examples) ? [...tool.examples] : [],
    })
  );

  // Resolve the orchestration prompt id to the actual prompt body (YAML
  // template text) and the model id the prompt is configured against. The
  // assistant config only carries the prompt id; without this resolution
  // step the GUI would render the prompt id where the body should be and
  // would surface that same id as the model.
  const promptId = orchestrationConfig?.orchestrationAIPromptId ?? "";
  const promptDetail = await fetchPromptDetail(promptId);

  return {
    agentId: agent.aiAgentId!,
    name: agent.name!,
    type: "ORCHESTRATION",
    systemPrompt: promptDetail?.text ?? "",
    // Prefer the resolved model id from the prompt; fall back to the prompt
    // id only when GetAIPrompt failed (so we keep the prior behaviour of
    // showing *something* rather than an empty cell). Real model ids look
    // like `us.anthropic.claude-...`, so the fallback is easy to spot.
    modelId: promptDetail?.modelId || promptId || "unknown",
    tools,
  };
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

/**
 * API Gateway Lambda handler for the discovery endpoints.
 *
 * Routes:
 * - GET /agents → list all orchestration agents
 * - GET /agents/{agentId} → get agent detail
 */
export async function handler(event: {
  httpMethod?: string;
  pathParameters?: { agentId?: string } | null;
  resource?: string;
}): Promise<{ statusCode: number; body: string; headers: Record<string, string> }> {
  const method = event.httpMethod ?? "GET";
  const agentId = event.pathParameters?.agentId;

  if (method !== "GET") {
    return errorResponse(405, "MethodNotAllowed", `Method ${method} not allowed`);
  }

  try {
    if (!getAssistantId()) {
      return errorResponse(
        500,
        "ConfigurationError",
        "ASSISTANT_ID environment variable is not configured"
      );
    }

    // Route: GET /agents/{agentId}
    if (agentId) {
      const detail = await getAgentDetail(agentId);
      if (!detail) {
        return errorResponse(
          404,
          "AgentNotFound",
          `Agent ${agentId} not found or is not an ORCHESTRATION agent`
        );
      }
      return successResponse(200, detail);
    }

    // Route: GET /agents
    const agents = await listAgents();
    return successResponse(200, { agents });
  } catch (error: unknown) {
    return handleServiceError(error);
  }
}

// ---------------------------------------------------------------------------
// Error handling
// ---------------------------------------------------------------------------

function handleServiceError(error: unknown): {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
} {
  const errorName = (error as { name?: string })?.name ?? "";
  const errorMessage =
    error instanceof Error ? error.message : "An unexpected error occurred";

  console.error("[discovery] Service error:", errorName, errorMessage);

  switch (errorName) {
    case "ThrottlingException":
      return errorResponse(
        429,
        "ThrottlingException",
        "Request rate exceeded. Please retry after a brief delay.",
        true
      );

    case "AccessDeniedException":
    case "UnauthorizedException":
      return errorResponse(
        403,
        "AccessDenied",
        "Insufficient permissions to access Q in Connect agents. Verify IAM configuration."
      );

    case "ResourceNotFoundException":
      return errorResponse(
        404,
        "ResourceNotFound",
        "The configured assistant or agent was not found. Verify ASSISTANT_ID."
      );

    case "ValidationException":
      return errorResponse(
        400,
        "ValidationError",
        `Invalid request parameters: ${errorMessage}`
      );

    default:
      return errorResponse(
        500,
        "InternalError",
        "An unexpected error occurred while communicating with Q in Connect. Please retry.",
        true
      );
  }
}
