# Requirements Document

## Introduction

The Connect Agent Test Platform today supports a single test case shape — `tool_sequence` — where success is asserted against an ordered list of tool invocations on the agent's session. This shape is unsuitable for testing retrieval-augmented (RAG) responses produced by an orchestration agent that calls a `Retrieve` tool against a Knowledge Base: the assertion that matters is whether the agent's natural-language answer is grounded in the retrieved chunks, correct against a ground-truth answer, complete, and helpful — not which tool was called.

This feature adds a second test case type, `rag`, alongside the existing `tool_sequence` type. A RAG case carries a `question` and a `groundTruthAnswer`. At runtime the platform sends the question to the agent in a single-turn conversation, captures the agent's final response and the chunks the `Retrieve` tool returned (read from ListSpans), packages those into Bedrock RAG Evaluation's bring-your-own-inference-responses JSONL format, submits one batched evaluation job per run covering every RAG case in the run, polls until the job completes, reads the per-prompt metric scores, and renders them on the case detail page alongside the retrieved chunks. Pass/fail is decided per-metric against thresholds configurable on the suite, with a hard fail when Faithfulness drops below threshold.

The four built-in metrics scored at MVP are Faithfulness, Correctness, Completeness, and Helpfulness — Helpfulness is the closest holistic-usefulness analog to the user's "Relevance" in the retrieve-and-generate metric set (the dedicated `ContextRelevance` metric exists only in the retrieve-only metric set, which evaluates retrievers in isolation rather than the end-to-end RAG response we have).

A suite may hold a mix of `tool_sequence` and `rag` cases. The create-test form gains a Test Type dropdown defaulted to `tool_sequence`; selecting `rag` swaps the form to the RAG-specific field set.

### Non-Goals

- Custom metric definitions (Bedrock's custom metric JSON file format) are out of MVP — only the four built-in retrieve-and-generate metrics are scored.
- Retrieve-only evaluation (`ContextRelevance`, `ContextCoverage` against the retriever in isolation) is out of MVP — the platform tests end-to-end RAG responses, not standalone retrievers.
- Multi-turn RAG conversations are out of MVP — every RAG case is single-turn (question in, final answer out).
- The Customer_Simulator does not run on RAG cases — the question is the literal customer turn, not a goal-prompt for a simulated customer.
- Retrieve-and-generate against the Knowledge Base directly (bypassing the Connect agent) is out — the platform tests the deployed Connect orchestration agent, not the underlying KB.
- Pricing/cost surfacing in the GUI is out of MVP — costs are documented in operator docs.

## Glossary

- **Platform**: The Connect Agent Test Platform — the deployed serverless web application this feature extends.
- **TestCase_Type**: The discriminator field on a TestCase. Exactly one of `"tool_sequence"` (existing) or `"rag"` (new).
- **Tool_Sequence_Case**: A TestCase whose `type === "tool_sequence"`. Carries `successCriteria` (ordered ToolStep[]) and the existing simulator fields (persona, style, customerKnowledge, initialUtterance, sessionData, primingMessage, goalDescription).
- **RAG_Case**: A TestCase whose `type === "rag"`. Carries `question` (the customer's literal utterance) and `groundTruthAnswer` (the expected agent reply). Does NOT carry simulator fields (persona, style, customerKnowledge, initialUtterance, sessionData, primingMessage, goalDescription) at MVP.
- **Question**: The single customer utterance sent to the agent for a RAG case, max 1000 characters.
- **Ground_Truth_Answer**: The known-good agent reply against which the metric scoring compares the actual response, max 4000 characters.
- **Retrieve_Tool**: The Q in Connect orchestration tool that retrieves passages from a configured Knowledge Base. Surfaces in ListSpans as `execute_tool` spans whose `toolResult.values[].text.value` carries the chunk text and whose `SpanCitation` objects carry knowledgeBaseId / contentId / title.
- **Retrieved_Chunks**: The ordered list of passages the `Retrieve_Tool` returned during a single RAG case execution, derived from the case's session ListSpans. Each chunk carries `text`, optional `knowledgeBaseId`, optional `contentId`, optional `title`, and optional ordinal `index` within the retrieval.
- **Conversation_Driver**: The existing module at `src/backend/orchestration/conversation-driver.ts` that drives a Q in Connect session via CreateSession → SendMessage → poll for final agent message → ListSpans. Reused for RAG cases in single-turn mode.
- **RAG_Evaluation_Service**: Amazon Bedrock RAG Evaluation. The platform calls `bedrock:CreateEvaluationJob` with `applicationType=RagEvaluation`, BYOI retrieve-and-generate dataset, Bedrock judge model, and built-in metric set. Asynchronous — produces a job ARN and writes per-prompt + summary metric files to a configured S3 output bucket.
- **RAG_Job**: A single `CreateEvaluationJob` invocation submitted by the platform, batched per run, covering every `RAG_Case` whose conversation driver step succeeded.
- **RAG_Job_Bucket**: The S3 bucket the platform owns for RAG evaluation input JSONL files and output metric reports. Provisioned in the CDK stack alongside the existing DynamoDB table.
- **RAG_Metric**: One of `Faithfulness`, `Correctness`, `Completeness`, `Helpfulness`. Scored per-prompt by `RAG_Evaluation_Service` and surfaced as a `[0,1]` numeric score on each `TestCaseResult`. (`Faithfulness` matches the user's "Groundedness".)
- **RAG_Threshold**: A `[0,1]` numeric pass/fail threshold per `RAG_Metric` configured at the suite level. The default for all four metrics is `0.7`.
- **Faithfulness_Hard_Gate**: When a RAG case's `Faithfulness` score is strictly below the suite's `Faithfulness` threshold, the case status is `failed` regardless of the other three metric scores. The other metrics use AND semantics — every threshold must be met for `passed`.
- **Two_Stage_Run**: The run pipeline branching introduced for runs containing at least one `RAG_Case`. Stage 1 (`ExecuteCases`) drives every case via the `Conversation_Driver`. Stage 2 (`RAG_Evaluate`) submits the batched `RAG_Job`, polls until completion, reads results, and writes per-case metric scores.
- **RAG_Job_Status**: The Bedrock evaluation job status, one of `IN_PROGRESS`, `COMPLETED`, `FAILED`, `STOPPED`, mirrored on the run record while Stage 2 runs.
- **Per_Prompt_Metric_Output**: The per-prompt scores Bedrock writes to `s3://RAG_Job_Bucket/{job-name}/{job-uuid}/...` after `RAG_Job_Status` reaches `COMPLETED`. The platform reads the per-prompt file, joins by prompt index back to caseId, and persists the four scores onto each `TestCaseResult`.
- **TestCaseResult**: The existing per-case persisted record under `PK=RUN#{runId}, SK=CASE#{caseId}`. Extended for RAG cases with `caseType: "rag"`, optional `ragMetrics: { faithfulness, correctness, completeness, helpfulness }`, optional `retrievedChunks: RetrievedChunk[]`, and reuses the existing `evaluationError` field for RAG-specific failure codes.

## Requirements

### Requirement 1: TestCase Discriminator and Shape

**User Story:** As a tester authoring tests for an agent that uses the Retrieve tool, I want to mark a test case as `rag` so that the platform applies retrieval-aware authoring, runtime, and scoring rules to it instead of tool-sequence rules.

#### Acceptance Criteria

1. THE Platform SHALL extend the `TestCase` interface with a required `type` field of literal type `"tool_sequence" | "rag"`.
2. WHEN the Platform reads a persisted `TestCase` record that has no `type` field (records authored before this feature shipped), THE Platform SHALL treat the record as `type: "tool_sequence"` and SHALL NOT fail the read.
3. WHERE `type === "tool_sequence"`, THE Platform SHALL preserve every existing field on the TestCase shape (`successCriteria`, `persona`, `style`, `customerKnowledge`, `initialUtterance`, `goalDescription`, `sessionData`, `primingMessage`) byte-for-byte and SHALL NOT introduce any RAG-specific field on this case type.
4. WHERE `type === "rag"`, THE Platform SHALL require `question` (1..1000 characters, trimmed-non-empty) and `groundTruthAnswer` (1..4000 characters, trimmed-non-empty) and SHALL NOT require any of the simulator fields (`persona`, `style`, `customerKnowledge`, `initialUtterance`, `goalDescription`, `primingMessage`, `successCriteria`). The `sessionData` field SHALL be optional on RAG cases (max 20 key-value pairs, same constraint as tool-sequence cases) so that testers can inject per-case session context that drives content tag filters or other session-data-driven retrieval behavior.
5. WHERE `type === "rag"`, THE Platform SHALL reject persistence of any of the simulator fields listed in 1.4 (excluding `sessionData`) with HTTP 400 `{ error: "rag_case_extraneous_field", field }` so that the GUI cannot accidentally mix shapes.
6. THE Platform SHALL allow a single `TestSuite` to contain any mix of `tool_sequence` and `rag` cases — there is no homogeneity constraint at the suite level.
7. THE Platform SHALL preserve existing `TestSuite` fields verbatim — no `type` discriminator is added at the suite level.

### Requirement 2: GUI Authoring — Test Type Dropdown

**User Story:** As a tester creating a new test, I want a clear dropdown that lets me pick the test type so the form shows the right fields without me having to navigate to a different page.

#### Acceptance Criteria

1. WHEN a user opens the "Create test case" form on the suite detail page, THE form SHALL render a `Test Type` dropdown as the first field, with options `Conversation` (value `tool_sequence`) and `RAG` (value `rag`).
2. THE `Test Type` dropdown SHALL default to `Conversation`.
3. WHEN the user selects `Conversation`, THE form SHALL render the existing tool-sequence field set unchanged from current behavior.
4. WHEN the user selects `RAG`, THE form SHALL render exactly these fields: `Name` (max 100 chars), `Description` (max 2000 chars), `Question` (max 1000 chars), `Ground Truth Answer` (max 4000 chars), and an optional collapsible `Session Data` section (same key-value editor as tool-sequence cases, max 20 pairs) for injecting session context that drives content tag filters or other session-data-driven retrieval behavior.
5. WHEN the user switches the dropdown after typing into one mode's fields, THE form SHALL discard the values of the not-currently-shown fields on submit so a switched-then-submitted form cannot persist a hybrid record (R1.5 enforces this server-side; R2.5 is the UX that prevents the user from being surprised).
6. THE suite detail page's case list SHALL render a `Type` column showing the badge `Conversation` or `RAG` per case so the mixed-suite contents are scannable.
7. THE per-case edit form SHALL render the same field set the case was created with (matching `case.type`); the dropdown SHALL be disabled in edit mode so a case's type cannot be mutated post-creation (changing type is equivalent to creating a different case — the user should delete and recreate).

### Requirement 3: RAG Case Runtime — Single-Turn Conversation

**User Story:** As a tester running a RAG case, I want the platform to send the question once and capture the agent's first complete answer along with whatever chunks the Retrieve tool returned, so that the evaluation has a clean, single-question signal.

#### Acceptance Criteria

1. WHEN the run pipeline executes a `RAG_Case`, THE `Conversation_Driver` SHALL CreateSession against the suite's assistant + agent, send the case's `question` as a single SendMessage, poll until the agent's terminal text response is captured, and call ListSpans once after the terminal message.
2. THE `Conversation_Driver` SHALL NOT invoke the `Customer_Simulator` for `RAG_Case` execution — there is no simulated customer turn after the question.
3. THE `Conversation_Driver` SHALL persist the captured agent response on the `TestCaseResult` as the existing transcript shape (a single agent turn following a single customer turn).
4. WHEN the `Conversation_Driver` finishes a `RAG_Case`, THE platform SHALL extract `Retrieved_Chunks` from the session's ListSpans by selecting every `execute_tool` span whose tool name matches the agent's Retrieve tool name (resolved at run start from the AgentSnapshot — typically `Retrieve` but the snapshot is authoritative), iterating each span's `toolResult.values[]`, and producing one `RetrievedChunk` per `text.value` with the citation fields (`knowledgeBaseId`, `contentId`, `title`) populated from the corresponding `SpanCitation` objects when present.
5. THE platform SHALL persist `Retrieved_Chunks` on the `TestCaseResult` under the new `retrievedChunks: RetrievedChunk[]` field, preserving order, preserving each chunk's text verbatim including embedded whitespace and newlines, and never omitting the field — when no chunks were retrieved the field is the empty array `[]`.
6. IF the agent emits a terminal response without ever invoking the `Retrieve_Tool`, THEN THE platform SHALL persist `retrievedChunks: []` and SHALL still include the case in Stage 2 with an empty `retrievedPassages.retrievalResults: []` so the metric scoring runs against zero chunks (Faithfulness against zero chunks is informative — typically scores low — and surfaces as a normal pass/fail rather than an error).
7. IF the `Conversation_Driver` fails during a `RAG_Case` (timeout, session error, message-poll exhaustion), THEN THE platform SHALL set `case.status = "error"`, populate `errorMessage`, set `caseType = "rag"`, leave `retrievedChunks` unset, and exclude the case from Stage 2.

### Requirement 4: Two-Stage Run Pipeline

**User Story:** As a tester running a suite that contains RAG cases, I want the run to wait for the Bedrock evaluation job to finish before reporting results, so that the run dashboard's per-case scores are populated when the run reaches a terminal status.

#### Acceptance Criteria

1. WHEN a run starts, THE platform SHALL detect whether the suite contains any `RAG_Case`. WHERE the suite contains zero RAG cases, THE run pipeline SHALL execute exactly the existing single-stage flow with no Stage 2 — RAG infrastructure is not provisioned for tool-sequence-only runs.
2. WHERE the suite contains at least one `RAG_Case`, THE run pipeline SHALL execute the `Two_Stage_Run`: Stage 1 (`ExecuteCases`) followed by Stage 2 (`RAG_Evaluate`), with the run record's `status` remaining `running` from Stage 1 entry through Stage 2 exit.
3. THE Stage 1 (`ExecuteCases`) step SHALL drive every case in the suite (both `tool_sequence` and `rag`) through the `Conversation_Driver` with the platform's existing concurrency setting. WHEN every case has reached a terminal per-case state (passed / failed / error / timed_out for tool-sequence; or success-with-response-and-chunks vs error for rag), Stage 1 SHALL complete.
4. THE Stage 2 (`RAG_Evaluate`) step SHALL filter to only `RAG_Case` records that completed Stage 1 with a captured agent response (i.e. not `error`), assemble one BYOI retrieve-and-generate JSONL line per surviving case, upload the JSONL to `s3://{RAG_Job_Bucket}/{runId}/input.jsonl`, and call `bedrock:CreateEvaluationJob` once with all the lines batched into the single dataset.
5. WHEN at least one `RAG_Case` survived to Stage 2, THE platform SHALL poll `bedrock:GetEvaluationJob` every 30 seconds and SHALL fail the Stage 2 step after a hard cap of 30 minutes; on success THE platform SHALL read the per-prompt metric output from S3, join by prompt index back to `caseId`, and write the four metric scores onto each `TestCaseResult`.
6. WHEN every `RAG_Case` in Stage 1 ended in `error` (i.e. zero surviving for Stage 2), THE platform SHALL skip the `CreateEvaluationJob` invocation entirely, advance the run to its terminal status, and treat each errored RAG case as a normal `error`-status case (no `ragMetrics`, `evaluationError` populated with `INSUFFICIENT_RAG_DATA` only when Stage 1 itself failed for that case for reasons other than the case's own driver error).
7. WHEN Stage 2 completes successfully, THE run pipeline SHALL apply per-metric thresholds (Requirement 6) to compute each RAG case's `status` and SHALL transition the run to a terminal status (`completed`, `failed`, or `aborted`) per the existing run-status rules.

### Requirement 5: Bedrock RAG Evaluation Job — BYOI Dataset Construction

**User Story:** As a tester running RAG cases, I want the platform to build a Bedrock-compliant evaluation dataset from the captured Connect responses and ListSpans chunks so that the official Bedrock evaluator can score the responses without my having to manually export anything.

#### Acceptance Criteria

1. WHEN the platform constructs a BYOI retrieve-and-generate JSONL line for a `RAG_Case`, THE line SHALL be a valid JSON object on a single line conforming exactly to the Bedrock retrieve-and-generate BYOI schema documented at `https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base-evaluation-prompt-retrieve-generate.html` ("Prepare a dataset for a retrieve-and-generate evaluation job using your own inference response data").
2. THE line SHALL carry `conversationTurns[0].prompt.content[0].text` set verbatim to the case's `question`.
3. THE line SHALL carry `conversationTurns[0].referenceResponses[0].content[0].text` set verbatim to the case's `groundTruthAnswer`.
4. THE line SHALL carry `conversationTurns[0].output.text` set verbatim to the agent's terminal response captured in Stage 1.
5. THE line SHALL carry `conversationTurns[0].output.knowledgeBaseIdentifier` set to the `knowledgeBaseId` of the first non-empty `Retrieved_Chunk` if any chunk carried one, OR to the literal string `"connect-orchestration-retrieve"` when no chunk carried a `knowledgeBaseId` (Bedrock requires this field be a non-empty string; the literal sentinel surfaces in the report as the source identifier).
6. THE line SHALL carry `conversationTurns[0].output.modelIdentifier` set to the agent's model id from the AgentSnapshot.
7. THE line SHALL carry `conversationTurns[0].output.retrievedPassages.retrievalResults[]` with one entry per `RetrievedChunk`, each entry's `content.text` set verbatim to the chunk text, optional `name` set to the chunk's `title` when present, and optional `metadata` populated with `{ contentId, knowledgeBaseId }` when those fields are present on the chunk.
8. THE platform SHALL NOT populate `referenceContexts` on any line — the optional `referenceContexts` field is only used by custom metrics, which are out of MVP scope.
9. WHEN the platform uploads the JSONL to S3, the file SHALL be written to `s3://{RAG_Job_Bucket}/{runId}/input.jsonl` with `Content-Type: application/jsonl` and SHALL contain one JSON object per line with `\n` line endings, no leading or trailing blank lines.
10. THE platform SHALL preserve case ordering: line `i` of the JSONL corresponds to the i-th `RAG_Case` in the suite that survived Stage 1, and the platform SHALL persist the line-index → caseId mapping (e.g. on the run record under `PK=RUN#{runId}, SK=RAGJOB`) so the per-prompt output can be joined back to caseId regardless of how Bedrock orders the output.

### Requirement 6: Pass/Fail Decision and Suite-Level Thresholds

**User Story:** As a tester, I want the platform to flip a RAG case to `passed` or `failed` automatically based on the Bedrock metric scores and configurable thresholds so that the run dashboard surfaces actionable results without manual triage.

#### Acceptance Criteria

1. THE Platform SHALL extend `TestSuite` with an optional `ragThresholds: { faithfulness: number; correctness: number; completeness: number; helpfulness: number }` field where each value is in `[0,1]`.
2. WHEN a suite is created without `ragThresholds`, OR the field is absent on a record persisted before this feature shipped, THE Platform SHALL apply the default thresholds `{ faithfulness: 0.7, correctness: 0.7, completeness: 0.7, helpfulness: 0.7 }` for that suite.
3. WHEN the platform writes the per-case `ragMetrics` after Stage 2 completes, THE platform SHALL compute `case.status` as follows: IF `ragMetrics.faithfulness < threshold.faithfulness`, THEN `case.status = "failed"` (Faithfulness_Hard_Gate, R6.4 below). ELSE IF every other metric meets its threshold (i.e. `correctness >= threshold.correctness AND completeness >= threshold.completeness AND helpfulness >= threshold.helpfulness`), THEN `case.status = "passed"`. ELSE `case.status = "failed"`.
4. THE Faithfulness_Hard_Gate SHALL be the dominant rule: when Faithfulness fails, the case fails regardless of any other metric score, AND the per-case detail page SHALL surface a visible "Failed Faithfulness gate" badge so the user sees groundedness violations are non-negotiable. The platform SHALL log the hard-gate trigger for diagnostics.
5. THE GUI suite-edit form SHALL render four numeric inputs for the four thresholds when the suite contains at least one `RAG_Case`, defaulting unfilled values to `0.7` and accepting any value in `[0,1]` with one decimal place precision.
6. WHEN the user updates a suite's `ragThresholds`, THE Platform SHALL persist the new thresholds and SHALL NOT recompute pass/fail on past runs — the threshold applies to subsequent runs only. (Re-running a suite is the affordance for re-applying new thresholds.)
7. THE per-case detail page SHALL render each metric's score, the suite's threshold for that metric, and a clear visual indicator (green tick / red cross) per metric so the user can see which gate(s) caused the case to fail.

### Requirement 7: Per-Case Detail Page — RAG Render Surface

**User Story:** As a tester reviewing a failed RAG case, I want the case detail page to show the question, the agent's answer, the ground truth, the per-metric scores, and the retrieved chunks so that I can determine whether the answer was hallucinated, partially retrieved, or correctly grounded.

#### Acceptance Criteria

1. WHEN a user opens `/runs/{runId}/cases/{caseId}` for a case with `caseType === "rag"`, THE page SHALL render four top-level sections in this order: `Question`, `Agent's Answer`, `Ground Truth`, `Metrics`.
2. THE `Question` section SHALL render the case's question verbatim including embedded whitespace and newlines.
3. THE `Agent's Answer` section SHALL render the agent's terminal response verbatim including embedded whitespace and newlines.
4. THE `Ground Truth` section SHALL render the case's `groundTruthAnswer` verbatim.
5. THE `Metrics` section SHALL render four rows — `Faithfulness`, `Correctness`, `Completeness`, `Helpfulness` — each row showing the numeric score (3 decimal places), the suite's threshold for that metric, the pass/fail visual indicator from R6.7, and (when available) the metric's per-prompt explanation text from the Bedrock report.
6. THE page SHALL render a collapsible `Retrieved Chunks` panel beneath the four sections listing each chunk's `text` (preformatted, monospace, preserving whitespace and newlines), `title` if present, and the citation `knowledgeBaseId` and `contentId` if present. When the chunks list is empty the panel SHALL render the empty-state label "No chunks were retrieved for this question".
7. WHEN `case.status === "failed"` due to the `Faithfulness_Hard_Gate` (R6.4), THE page SHALL render the visible "Failed Faithfulness gate" badge above the `Metrics` section.
8. THE page SHALL NOT render the existing `Tools Invoked`, `Turn Count`, or tool-sequence-specific evaluation reasoning panels for a RAG case — those panels are exclusive to `tool_sequence` cases.

### Requirement 8: Failure Handling for the RAG Evaluation Job

**User Story:** As a tester whose Bedrock RAG evaluation job fails, I want the platform to surface a clear failure reason on each case rather than silently leaving scores blank, so I know whether to retry, fix my data, or contact AWS support.

#### Acceptance Criteria

1. THE Platform SHALL extend the `EvaluationErrorCode` union (currently `INSUFFICIENT_TRACE | TIMEOUT | JUDGE_ERROR | UNMAPPABLE_RESULT | MISSING_EVALUATOR`) with the new codes `RAG_JOB_FAILED`, `RAG_JOB_TIMEOUT`, `INSUFFICIENT_RAG_DATA`, `MALFORMED_RESULT`.
2. IF Stage 2's `bedrock:CreateEvaluationJob` returns a non-2xx response, THEN THE platform SHALL set `evaluationError = { code: "RAG_JOB_FAILED", reason: "<job-arn-or-error-message>" }` on every `RAG_Case` that was submitted to the job, leave `ragMetrics` unset, set `case.status = "error"`, and advance the run to terminal.
3. IF Stage 2's poll loop reaches the 30-minute hard cap without the job reaching `COMPLETED`, THEN THE platform SHALL call `bedrock:StopEvaluationJob` (best-effort), set `evaluationError = { code: "RAG_JOB_TIMEOUT", reason: "Bedrock evaluation job did not complete within 30 minutes" }` on every submitted RAG case, leave `ragMetrics` unset, set `case.status = "error"`, and advance the run to terminal.
4. IF the Bedrock per-prompt output for an individual case is malformed (missing the four metrics, non-numeric score values, or fails JSON parsing), THEN THE platform SHALL set `evaluationError = { code: "MALFORMED_RESULT", reason: "<details>" }` on that single case, leave its `ragMetrics` unset, set its `status = "error"`, and SHALL still surface successfully-scored cases in the same job — one bad row does not invalidate the others.
5. WHEN Stage 2 reads per-prompt output and finds a `caseId` in the line-index map that has NO corresponding output entry, THE platform SHALL set `evaluationError = { code: "MISSING_EVALUATOR", reason: "Bedrock did not return a result for this prompt", missingEvaluators: ["RagEvaluation"] }` on that case (reusing the existing `missingEvaluators` field semantically).
6. WHEN every `RAG_Case` ended Stage 1 in `error` (zero survivors), THE platform SHALL set `evaluationError = { code: "INSUFFICIENT_RAG_DATA", reason: "All RAG cases errored before evaluation could be submitted" }` only on the cases whose Stage 1 outcome was the kind of non-driver error that suggests the user's data was bad (out of MVP scope; for MVP every Stage 1 error keeps its existing error semantics and nothing extra is layered on top).
7. THE per-case detail page SHALL render the existing `evaluationError` alert pattern for each new error code with appropriate copy: `RAG_JOB_FAILED` → "RAG evaluation failed. Re-run the suite or contact support."; `RAG_JOB_TIMEOUT` → "RAG evaluation timed out after 30 minutes. Re-run the suite."; `MALFORMED_RESULT` → "Bedrock returned an unparseable result for this case."; `MISSING_EVALUATOR` → "Bedrock did not return a result for this case."

### Requirement 9: Observability and Operator Diagnostics

**User Story:** As an operator debugging a RAG run, I want CloudWatch logs and the run-level record to show the Bedrock job ARN, status, and S3 paths so that I can investigate failures without rebuilding the run from scratch.

#### Acceptance Criteria

1. WHEN Stage 2 calls `bedrock:CreateEvaluationJob`, THE platform SHALL log at INFO level the job ARN, the input JSONL S3 URI, the configured judge model id, the metric set, and the count of submitted cases.
2. THE Platform SHALL persist the job ARN, judge model id, input/output S3 URIs, submitted-case count, and final job status on a new persisted record at `PK=RUN#{runId}, SK=RAGJOB` so the run-detail API can surface them.
3. WHEN the run-detail API endpoint serves a run that contains a RAG job record, THE response SHALL include a `ragJob: { jobArn, status, judgeModelId, inputS3Uri, outputS3Uri, submittedCaseCount, startedAt, completedAt? }` field for operator diagnostics. The frontend may render this in an admin/diagnostics drawer; surfacing in the standard user-facing dashboard is not required.
4. WHEN any Stage 2 polling or read step fails, THE platform SHALL log at ERROR level the underlying error name and message (without echoing the full JSONL contents — those may contain sensitive ground truth answers).
5. THE Platform SHALL emit one CloudWatch metric per Stage 2 job: `RagEvaluationJobDurationSeconds` (gauge, dimension `runId`), so operators can spot a regression in evaluation latency without parsing logs.

### Requirement 10: Backward Compatibility and Data Migration

**User Story:** As an existing user with suites and cases authored before this feature shipped, I want my existing data to keep working without me having to migrate or re-author anything.

#### Acceptance Criteria

1. WHEN the Platform reads a `TestCase` record persisted before this feature shipped, THE Platform SHALL treat the record as `type: "tool_sequence"` per R1.2, render it in the GUI as a `Tool Use` case, and execute it through the existing single-stage pipeline.
2. WHEN the Platform reads a `TestSuite` record persisted before this feature shipped, THE Platform SHALL treat absent `ragThresholds` as the defaults from R6.2 and SHALL NOT fail the read.
3. WHEN the Platform reads a `TestCaseResult` record persisted before this feature shipped, THE Platform SHALL treat absent `caseType` as `"tool_sequence"`, absent `ragMetrics` as `undefined`, and absent `retrievedChunks` as `undefined` and SHALL NOT fail the read.
4. THE Platform SHALL NOT mutate any pre-existing record on read — backward-compatibility normalization is read-only and does not write back.
5. THE Platform SHALL NOT remove or rename any existing `TestCase`, `TestSuite`, or `TestCaseResult` field — every existing field is preserved verbatim.
6. WHEN a deployment of this feature lands on an account with zero existing RAG cases, THE platform SHALL provision the new `RAG_Job_Bucket` and IAM permissions but SHALL NOT submit any Bedrock evaluation jobs until a suite with at least one RAG case is run.

### Requirement 11: Property-Testable Behaviors

**User Story:** As a maintainer, I want the discriminator, the JSONL serialization, the threshold logic, and the chunk-extraction logic to be expressible as property tests, so that regressions are caught automatically.

#### Acceptance Criteria

1. FOR ANY `TestCase` whose `type === "rag"`, the JSONL serializer SHALL produce a single-line valid JSON object whose `prompt`, `referenceResponses`, `output.text`, and `output.retrievedPassages.retrievalResults[].content.text` round-trip equal the input case's `question`, `groundTruthAnswer`, captured response, and per-chunk `text` byte-for-byte.
2. FOR ANY four `[0,1]` metric scores and any four `[0,1]` thresholds, the pass/fail decision function from R6.3 SHALL return `"failed"` if `faithfulness < faithfulnessThreshold`, return `"passed"` if every metric is at least its threshold, and otherwise return `"failed"` — the function is pure and total over its input domain.
3. FOR ANY ListSpans payload containing zero or more `execute_tool` Retrieve spans (each with arbitrary `toolResult.values[]`), the chunk-extraction function SHALL produce a `RetrievedChunk[]` whose length equals the total `toolResult.values[]` count across those spans, in the same order, with each chunk's `text` byte-for-byte equal to the corresponding `text.value`.
4. FOR ANY two persisted `TestCase` records, the type-discriminator validator SHALL accept exactly the records satisfying R1.4 (RAG cases reject extraneous simulator fields and reject empty `question` or `groundTruthAnswer`) and exactly the records satisfying R1.3 (tool-sequence cases preserve the existing shape) — there is no third valid shape.


### Requirement 12: Opportunistic Faithfulness Check on Tool-Sequence Cases

**User Story:** As a tester running a tool-sequence case where the agent happens to call the Retrieve tool, I want the platform to automatically check whether the agent's response was grounded in the retrieved chunks, so that hallucinations surface without me having to author a separate RAG case for the same question.

#### Acceptance Criteria

1. WHEN a `tool_sequence` case's ListSpans output contains at least one `execute_tool` span whose tool name matches the agent's Retrieve tool (resolved from the AgentSnapshot), THE platform SHALL extract `Retrieved_Chunks` using the same chunk-extraction logic as RAG cases (R3.4) and SHALL persist them on the `TestCaseResult` under the existing `retrievedChunks` field.
2. WHEN `retrievedChunks` is non-empty on a completed `tool_sequence` case AND the suite's `ragThresholds.faithfulness` is defined (i.e. the suite has at least one RAG case or the user explicitly set thresholds), THE platform SHALL compute an opportunistic Faithfulness score inline via a single Bedrock Converse call (NOT via the async Bedrock RAG Evaluation batch job) immediately after the case's ListSpans are captured in Stage 1.
3. THE Converse-based Faithfulness evaluator SHALL send a structured judge prompt containing (a) the agent's final response and (b) the retrieved chunk texts, instruct the judge model to score how well the response is grounded in the provided passages on a `[0,1]` scale, and return a single numeric Faithfulness score. The prompt SHALL follow the same Faithfulness rubric semantics as Bedrock RAG Evaluation's built-in Faithfulness metric (i.e. "what fraction of the claims in the response are supported by the retrieved passages?").
4. THE Converse-based evaluator SHALL use the same judge model, retry posture (`baseMs: 1000, capMs: 10000, maxRetries: 2` on `ThrottlingException`), and `temperature: 0` settings as the existing Bedrock-calling Lambdas in the platform (`analysis.ts`, `comparison-summary.ts`).
5. WHEN the opportunistic Faithfulness evaluation completes, THE platform SHALL persist the score on the `TestCaseResult` under `ragMetrics: { faithfulness: number }` (Correctness, Completeness, Helpfulness left unset since there is no ground truth) and SHALL render it on the case detail page as an informational metric, NOT as a pass/fail gate — the case's `status` remains determined solely by the tool-sequence success criteria.
6. IF the suite does NOT contain any `RAG_Case` AND the suite has no explicit `ragThresholds` configured, THEN THE platform SHALL NOT perform the opportunistic Faithfulness check (no cost incurred for suites that have no RAG engagement at all). The user opts in by either (a) adding at least one RAG case to the suite, or (b) explicitly setting `ragThresholds` on a tool-sequence-only suite.
7. THE opportunistic Faithfulness check SHALL run inline during Stage 1 immediately after ListSpans completes for the case — it does NOT depend on Stage 2 and does NOT delay Stage 2's Bedrock RAG Evaluation job. The Converse call adds ~3–5 seconds per case, which is absorbed into the existing per-case execution window.
8. WHEN a `tool_sequence` case does NOT invoke the Retrieve tool (no chunks retrieved), THE platform SHALL NOT persist `retrievedChunks` on that case and SHALL NOT run the opportunistic Faithfulness check — the case is processed identically to the pre-feature behavior.
9. THE per-case detail page for a `tool_sequence` case that has a `ragMetrics.faithfulness` score SHALL render a "Groundedness" metric row beneath the existing evaluation reasoning section showing the Faithfulness score, the threshold, and a pass/fail visual indicator. This is informational — the case's overall `status` badge remains green/red based on tool-sequence criteria only.
10. FOR ANY `tool_sequence` case, the opportunistic Faithfulness score SHALL NOT influence the case's `status` field or the run's aggregate pass/fail counts. The score is surfaced for diagnostic visibility only.
11. IF the Converse-based Faithfulness call fails (throttle after retries, parse error, model error), THE platform SHALL log the failure, leave `ragMetrics` unset on the case, and SHALL NOT fail the case or delay the run — the opportunistic check is best-effort and the case proceeds with its tool-sequence pass/fail outcome.


### Requirement 13: Content Tag Filter Validation and Session Data Guidance

**User Story:** As a tester authoring a RAG case with session data intended to drive content tag filtering, I want the platform to validate that the agent's Retrieve tool is actually configured with a dynamic filter placeholder, so I don't waste a test run against an agent that silently ignores my filter values.

#### Acceptance Criteria

1. WHEN a RAG case is saved with `sessionData` containing one or more keys, THE Platform SHALL inspect the suite's agent's Retrieve tool configuration(s) (from the Discovery API / AgentSnapshot) to determine whether any Retrieve tool has override input values whose `retrievalConfiguration.filter.*.value` contains a `{{$.Custom.*}}` placeholder.
2. IF the test case's `sessionData` contains a key `K` and NO Retrieve tool on the agent has a `retrievalConfiguration.filter.*.value` override referencing `{{$.Custom.K}}`, THEN THE Platform SHALL surface a validation warning (NOT a hard error) on save informing the user that the session data key `K` does not appear to be referenced by any Retrieve tool's content tag filter configuration. The case SHALL still save — the warning is advisory because session data may serve purposes beyond tag filtering (e.g. prompt template interpolation).
3. IF the agent has NO Retrieve tool with ANY `retrievalConfiguration.filter.*.value` override containing a `{{$.Custom.*}}` placeholder, AND the user populates `sessionData` on a RAG case, THEN THE Platform SHALL surface an informational tooltip on the Session Data section reading: "This agent's Retrieve tool does not appear to have a dynamic content tag filter configured. Session data keys will only take effect if the agent's Retrieve tool has `retrievalConfiguration.filter.equals.value` set to a `{{$.Custom.*}}` placeholder. Configure the filter key on the agent first."
4. IF the agent has at least one Retrieve tool with a `retrievalConfiguration.filter.equals.key` override (the static key half) AND a corresponding `retrievalConfiguration.filter.equals.value` override containing `{{$.Custom.*}}`, THEN THE Platform SHALL render the expected session data key name(s) as hint text beneath the Session Data key-value editor (e.g. "This agent expects `Custom.industry` for content tag filtering") so the tester knows exactly which key to provide.
5. THE validation in R13.1–R13.4 SHALL be performed at test-case save time by reading the agent's current tool configuration from the Discovery API (or from a cached AgentSnapshot if one exists for the suite). The validation is best-effort — if the Discovery API call fails, the save SHALL succeed without the validation warning.
6. THE validation SHALL NOT apply to `tool_sequence` cases that carry `sessionData` — those cases already existed before this feature and their session data serves a broader set of purposes (pre-seeding contact context, driving tool arguments, etc.) that the platform does not attempt to validate.
