/**
 * Unit tests for the Conversation Driver module.
 *
 * Tests the pure/testable functions: accumulateToolSequence.
 * Tests throttle detection: isThrottlingError.
 * The main executeTestCase function requires integration testing with mocked Q in Connect.
 */

import { describe, it, expect } from "vitest";
import { accumulateToolSequence, isThrottlingError } from "../../src/backend/orchestration/conversation-driver";
import type { TranscriptTurn } from "../../src/shared/types";

describe("accumulateToolSequence", () => {
  it("returns empty array when no turns have tools", () => {
    const turns: TranscriptTurn[] = [
      { turnNumber: 1, role: "agent", text: "How can I help?", timestamp: "2024-01-01T00:00:00Z", elapsedMs: 100 },
      { turnNumber: 2, role: "customer", text: "I need help", timestamp: "2024-01-01T00:00:01Z", elapsedMs: 200 },
    ];
    expect(accumulateToolSequence(turns)).toEqual([]);
  });

  it("extracts tools in chronological order", () => {
    const turns: TranscriptTurn[] = [
      { turnNumber: 1, role: "agent", text: "Using tool A", toolSelected: "ToolA", timestamp: "2024-01-01T00:00:00Z", elapsedMs: 100 },
      { turnNumber: 2, role: "customer", text: "ok", timestamp: "2024-01-01T00:00:01Z", elapsedMs: 200 },
      { turnNumber: 3, role: "agent", text: "Using tool B", toolSelected: "ToolB", timestamp: "2024-01-01T00:00:02Z", elapsedMs: 300 },
      { turnNumber: 4, role: "agent", text: "Using tool C", toolSelected: "ToolC", timestamp: "2024-01-01T00:00:03Z", elapsedMs: 400 },
    ];
    expect(accumulateToolSequence(turns)).toEqual(["ToolA", "ToolB", "ToolC"]);
  });

  it("returns empty array for empty input", () => {
    expect(accumulateToolSequence([])).toEqual([]);
  });

  it("skips turns without toolSelected", () => {
    const turns: TranscriptTurn[] = [
      { turnNumber: 1, role: "agent", text: "Hello", timestamp: "2024-01-01T00:00:00Z", elapsedMs: 100 },
      { turnNumber: 2, role: "agent", text: "Tool used", toolSelected: "LookupCustomer", timestamp: "2024-01-01T00:00:01Z", elapsedMs: 200 },
      { turnNumber: 3, role: "agent", text: "Anything else?", timestamp: "2024-01-01T00:00:02Z", elapsedMs: 300 },
      { turnNumber: 4, role: "agent", text: "Tool used", toolSelected: "TransferCall", timestamp: "2024-01-01T00:00:03Z", elapsedMs: 400 },
    ];
    expect(accumulateToolSequence(turns)).toEqual(["LookupCustomer", "TransferCall"]);
  });

  it("handles turns with undefined toolSelected", () => {
    const turns: TranscriptTurn[] = [
      { turnNumber: 1, role: "agent", text: "Hello", toolSelected: undefined, timestamp: "2024-01-01T00:00:00Z", elapsedMs: 100 },
      { turnNumber: 2, role: "agent", text: "Done", toolSelected: "SubmitOrder", timestamp: "2024-01-01T00:00:01Z", elapsedMs: 200 },
    ];
    expect(accumulateToolSequence(turns)).toEqual(["SubmitOrder"]);
  });
});


describe("isThrottlingError", () => {
  it("returns true for ThrottlingException by name", () => {
    const error = { name: "ThrottlingException", message: "Rate exceeded" };
    expect(isThrottlingError(error)).toBe(true);
  });

  it("returns true for TooManyRequestsException by name", () => {
    const error = { name: "TooManyRequestsException", message: "Too many requests" };
    expect(isThrottlingError(error)).toBe(true);
  });

  it("returns true for HTTP 429 via $metadata.httpStatusCode", () => {
    const error = { name: "SomeError", $metadata: { httpStatusCode: 429 } };
    expect(isThrottlingError(error)).toBe(true);
  });

  it("returns true for HTTP 429 via statusCode property", () => {
    const error = { name: "SomeError", statusCode: 429 };
    expect(isThrottlingError(error)).toBe(true);
  });

  it("returns false for non-throttling errors", () => {
    const error = { name: "ValidationException", message: "Invalid input" };
    expect(isThrottlingError(error)).toBe(false);
  });

  it("returns false for generic Error objects (non-throttle)", () => {
    const error = new Error("Something went wrong");
    expect(isThrottlingError(error)).toBe(false);
  });

  it("returns false for null", () => {
    expect(isThrottlingError(null)).toBe(false);
  });

  it("returns false for undefined", () => {
    expect(isThrottlingError(undefined)).toBe(false);
  });

  it("returns false for non-object types", () => {
    expect(isThrottlingError("string")).toBe(false);
    expect(isThrottlingError(42)).toBe(false);
    expect(isThrottlingError(true)).toBe(false);
  });

  it("returns false for HTTP 500 errors", () => {
    const error = { name: "InternalServerError", $metadata: { httpStatusCode: 500 } };
    expect(isThrottlingError(error)).toBe(false);
  });

  it("returns true for ThrottlingException via code property", () => {
    const error = { code: "ThrottlingException", message: "Throttled" };
    expect(isThrottlingError(error)).toBe(true);
  });
});
