// Feature: rag-test-cases, Property 2: Pass/Fail Decision Function is Pure and Total
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { computeRagCaseStatus } from "@backend/orchestration/rag-decision";
import type { RagMetrics, RagThresholds } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Generator for a single metric value in [0, 1]. */
const metricArb = fc.double({ min: 0, max: 1, noNaN: true });

/** Generator for RagMetrics with four metric values in [0, 1]. */
const ragMetricsArb: fc.Arbitrary<RagMetrics> = fc.record({
  faithfulness: metricArb,
  correctness: metricArb,
  completeness: metricArb,
  helpfulness: metricArb,
});

/** Generator for RagThresholds with four threshold values in [0, 1]. */
const ragThresholdsArb: fc.Arbitrary<RagThresholds> = fc.record({
  faithfulness: metricArb,
  correctness: metricArb,
  completeness: metricArb,
  helpfulness: metricArb,
});

// ---------------------------------------------------------------------------
// Property 2: Pass/Fail Decision Function is Pure and Total
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 11.2, 6.3, 6.4**
 *
 * Property 2: Pass/Fail Decision Function is Pure and Total
 *
 * For any four numeric values in [0,1] (faithfulness, correctness,
 * completeness, helpfulness scores) and any four numeric values in [0,1]
 * (faithfulness, correctness, completeness, helpfulness thresholds), the
 * `computeRagCaseStatus` function:
 * - Returns "failed" if faithfulness < faithfulnessThreshold
 * - Returns "passed" if all four metrics >= respective thresholds
 * - Returns "failed" otherwise
 * - Never throws and always returns one of exactly two values
 */
describe("Property 2: Pass/Fail Decision Function is Pure and Total", () => {
  it("never throws and always returns 'passed' or 'failed'", () => {
    fc.assert(
      fc.property(ragMetricsArb, ragThresholdsArb, (metrics, thresholds) => {
        const result = computeRagCaseStatus(metrics, thresholds);
        expect(result === "passed" || result === "failed").toBe(true);
      }),
      { numRuns: 100 },
    );
  });

  it("returns 'failed' when faithfulness < faithfulnessThreshold (hard gate)", () => {
    fc.assert(
      fc.property(ragMetricsArb, ragThresholdsArb, (metrics, thresholds) => {
        // Pre-condition: faithfulness is strictly below threshold
        fc.pre(metrics.faithfulness < thresholds.faithfulness);

        const result = computeRagCaseStatus(metrics, thresholds);
        expect(result).toBe("failed");
      }),
      { numRuns: 100 },
    );
  });

  it("returns 'passed' when all four metrics >= respective thresholds", () => {
    fc.assert(
      fc.property(ragMetricsArb, ragThresholdsArb, (metrics, thresholds) => {
        // Pre-condition: all metrics meet their thresholds
        fc.pre(metrics.faithfulness >= thresholds.faithfulness);
        fc.pre(metrics.correctness >= thresholds.correctness);
        fc.pre(metrics.completeness >= thresholds.completeness);
        fc.pre(metrics.helpfulness >= thresholds.helpfulness);

        const result = computeRagCaseStatus(metrics, thresholds);
        expect(result).toBe("passed");
      }),
      { numRuns: 100 },
    );
  });

  it("returns 'failed' when faithfulness passes but at least one other metric fails", () => {
    fc.assert(
      fc.property(ragMetricsArb, ragThresholdsArb, (metrics, thresholds) => {
        // Pre-condition: faithfulness passes but at least one other metric fails
        fc.pre(metrics.faithfulness >= thresholds.faithfulness);
        fc.pre(
          metrics.correctness < thresholds.correctness ||
            metrics.completeness < thresholds.completeness ||
            metrics.helpfulness < thresholds.helpfulness,
        );

        const result = computeRagCaseStatus(metrics, thresholds);
        expect(result).toBe("failed");
      }),
      { numRuns: 100 },
    );
  });

  it("is deterministic: same inputs always produce the same output", () => {
    fc.assert(
      fc.property(ragMetricsArb, ragThresholdsArb, (metrics, thresholds) => {
        const result1 = computeRagCaseStatus(metrics, thresholds);
        const result2 = computeRagCaseStatus(metrics, thresholds);
        expect(result1).toBe(result2);
      }),
      { numRuns: 100 },
    );
  });
});
