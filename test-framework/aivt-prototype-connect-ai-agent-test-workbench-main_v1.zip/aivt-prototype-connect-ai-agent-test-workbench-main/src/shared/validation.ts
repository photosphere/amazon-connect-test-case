/**
 * Validation utilities for test suites and test cases.
 *
 * @module validation
 */

import {
  CASE_DESCRIPTION_MAX,
  CASE_NAME_MAX,
  CUSTOMER_KNOWLEDGE_KEY_MAX,
  CUSTOMER_KNOWLEDGE_MAX_PAIRS,
  CUSTOMER_KNOWLEDGE_VALUE_MAX,
  INITIAL_UTTERANCE_MAX,
  PARAMETER_CHECKS_MAX,
  SUCCESS_CRITERIA_MAX_STEPS,
  SUCCESS_CRITERIA_MIN_STEPS,
  SUITE_DESCRIPTION_MAX,
  SUITE_NAME_MAX,
} from "./constants";
import { TestCase, TestSuite, ToolSequenceTestCase } from "./types";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** A single validation error identifying the failing field and reason. */
export interface ValidationError {
  field: string;
  message: string;
}

/** Result of a validation operation. */
export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

// ---------------------------------------------------------------------------
// Suite Validation
// ---------------------------------------------------------------------------

/**
 * Validates a partial TestSuite input, collecting all errors without short-circuiting.
 *
 * Rules:
 * - `name`: required, non-empty after trim, max 128 chars
 * - `agentId`: required, non-empty after trim
 * - `description`: optional, but if provided max 500 chars
 */
export function validateTestSuite(input: Partial<TestSuite>): ValidationResult {
  const errors: ValidationError[] = [];

  // name: required, non-empty, max length
  if (input.name == null || input.name.trim() === "") {
    errors.push({ field: "name", message: "Name is required" });
  } else if (input.name.length > SUITE_NAME_MAX) {
    errors.push({
      field: "name",
      message: `Name must be at most ${SUITE_NAME_MAX} characters`,
    });
  }

  // agentId: required, non-empty
  if (input.agentId == null || input.agentId.trim() === "") {
    errors.push({ field: "agentId", message: "Agent ID is required" });
  }

  // description: optional, max length if provided
  if (input.description != null && input.description.length > SUITE_DESCRIPTION_MAX) {
    errors.push({
      field: "description",
      message: `Description must be at most ${SUITE_DESCRIPTION_MAX} characters`,
    });
  }

  return { valid: errors.length === 0, errors };
}

// ---------------------------------------------------------------------------
// Case Validation
// ---------------------------------------------------------------------------

/**
 * Validates a partial TestCase input, collecting all errors without short-circuiting.
 *
 * Rules:
 * - `name`: optional, but if provided max 100 chars
 * - `description`: required, non-empty after trim, max 2000 chars
 * - `initialUtterance`: required, non-empty after trim, max 1000 chars
 * - `customerKnowledge`: max 20 pairs; key max 100, value max 500
 * - `successCriteria`: required, 1–30 steps; each step needs non-empty toolName;
 *   parameterChecks max 10 per step
 */
export function validateTestCase(input: Partial<TestCase>): ValidationResult {
  const errors: ValidationError[] = [];
  // Cast to ToolSequenceTestCase partial for accessing tool-sequence-specific fields.
  // RAG case validation is handled separately in the cases handler (Task 9).
  const tsInput = input as Partial<ToolSequenceTestCase>;

  // name: optional, max length if provided
  if (input.name != null && input.name.length > CASE_NAME_MAX) {
    errors.push({
      field: "name",
      message: `Name must be at most ${CASE_NAME_MAX} characters`,
    });
  }

  // description: required, non-empty, max length
  if (input.description == null || input.description.trim() === "") {
    errors.push({ field: "description", message: "Description is required" });
  } else if (input.description.length > CASE_DESCRIPTION_MAX) {
    errors.push({
      field: "description",
      message: `Description must be at most ${CASE_DESCRIPTION_MAX} characters`,
    });
  }

  // goalDescription: optional. When provided it must respect the same
  // length cap as `description` so the simulator's scenario line and the
  // scaffold prompt stay bounded for the same reasons (Bedrock token
  // budget, log/UI rendering). An absent or empty value is the no-op
  // case — the simulator falls back to `description` at runtime.
  if (tsInput.goalDescription != null && tsInput.goalDescription.length > CASE_DESCRIPTION_MAX) {
    errors.push({
      field: "goalDescription",
      message: `Goal description must be at most ${CASE_DESCRIPTION_MAX} characters`,
    });
  }

  // initialUtterance: required, non-empty, max length
  if (tsInput.initialUtterance == null || tsInput.initialUtterance.trim() === "") {
    errors.push({ field: "initialUtterance", message: "Initial utterance is required" });
  } else if (tsInput.initialUtterance.length > INITIAL_UTTERANCE_MAX) {
    errors.push({
      field: "initialUtterance",
      message: `Initial utterance must be at most ${INITIAL_UTTERANCE_MAX} characters`,
    });
  }

  // customerKnowledge: optional, max pairs + key/value length
  if (tsInput.customerKnowledge != null) {
    const entries = Object.entries(tsInput.customerKnowledge);
    if (entries.length > CUSTOMER_KNOWLEDGE_MAX_PAIRS) {
      errors.push({
        field: "customerKnowledge",
        message: `Customer knowledge must have at most ${CUSTOMER_KNOWLEDGE_MAX_PAIRS} pairs`,
      });
    }
    for (const [key, value] of entries) {
      if (key.length > CUSTOMER_KNOWLEDGE_KEY_MAX) {
        errors.push({
          field: `customerKnowledge.${key}`,
          message: `Customer knowledge key must be at most ${CUSTOMER_KNOWLEDGE_KEY_MAX} characters`,
        });
      }
      if ((value as string).length > CUSTOMER_KNOWLEDGE_VALUE_MAX) {
        errors.push({
          field: `customerKnowledge.${key}`,
          message: `Customer knowledge value must be at most ${CUSTOMER_KNOWLEDGE_VALUE_MAX} characters`,
        });
      }
    }
  }

  // successCriteria: required, 1–30 steps
  if (tsInput.successCriteria == null || tsInput.successCriteria.length < SUCCESS_CRITERIA_MIN_STEPS) {
    errors.push({
      field: "successCriteria",
      message: `Success criteria must have at least ${SUCCESS_CRITERIA_MIN_STEPS} step`,
    });
  } else {
    if (tsInput.successCriteria.length > SUCCESS_CRITERIA_MAX_STEPS) {
      errors.push({
        field: "successCriteria",
        message: `Success criteria must have at most ${SUCCESS_CRITERIA_MAX_STEPS} steps`,
      });
    }
    for (let i = 0; i < tsInput.successCriteria.length; i++) {
      const step = tsInput.successCriteria[i];
      if (!step.toolName || step.toolName.trim() === "") {
        errors.push({
          field: `successCriteria[${i}].toolName`,
          message: "Tool name is required",
        });
      }
      if (step.parameterChecks && step.parameterChecks.length > PARAMETER_CHECKS_MAX) {
        errors.push({
          field: `successCriteria[${i}].parameterChecks`,
          message: `Parameter checks must have at most ${PARAMETER_CHECKS_MAX} entries`,
        });
      }
    }
  }

  return { valid: errors.length === 0, errors };
}
