// Feature: platform-hosting-and-evaluations, Property 3: Admin email is parsed into create-or-skip-or-reject
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { parseAdminEmail } from '../../../lib/admin-email';

/**
 * **Validates: Requirements 6.6, 7.1**
 *
 * Property 3: Admin email is parsed into create-or-skip-or-reject
 * For any raw input: absent/empty/whitespace-only resolves to `{ skip: true }`
 * (deploy succeeds, no user created); a valid email (non-empty local part,
 * single "@", domain with a ".") resolves to `{ email }` with the trimmed
 * address; any non-empty invalid value throws (fails the deploy, creates
 * nothing).
 */

/** Generators for the three classes of input. */

const blankArb = fc.oneof(
  fc.constant(undefined),
  fc.constant(''),
  fc.stringMatching(/^[ \t\n\r]+$/)
);

/** Build a valid email from non-empty, whitespace-free local/domain labels. */
const labelArb = fc
  .string({ minLength: 1, maxLength: 12 })
  .map((s) => s.replace(/[\s@.]/g, 'x'))
  .filter((s) => s.length > 0);

const validEmailArb = fc
  .tuple(labelArb, labelArb, fc.constantFrom('com', 'org', 'co.uk', 'io', 'dev'))
  .map(([local, domain, tld]) => `${local}@${domain}.${tld}`);

/** Non-empty invalid emails: violate exactly the spec's structural rules. */
const invalidEmailArb = fc.oneof(
  fc.constantFrom(
    'noatsign',
    'a@b', // no dot in domain
    '@example.com', // empty local part
    'a@@b.com', // multiple @
    'a@b@c.com',
    'a@.com', // empty label before dot
    'a@example.', // empty label after dot
    'plainaddress',
    'a b@example.com', // interior whitespace
    'a@exam ple.com'
  )
);

describe('Property 3: Admin email is parsed into create-or-skip-or-reject', () => {
  it('absent/empty/whitespace always resolves to skip', () => {
    fc.assert(
      fc.property(blankArb, (raw) => {
        const result = parseAdminEmail(raw as string | undefined);
        expect(result).toEqual({ skip: true });
      }),
      { numRuns: 100 }
    );
  });

  it('valid emails resolve to the trimmed email (no skip)', () => {
    fc.assert(
      fc.property(
        validEmailArb,
        fc.constantFrom('', ' ', '  ', '\t'),
        fc.constantFrom('', ' ', '  ', '\n'),
        (email, leadingPad, trailingPad) => {
          const result = parseAdminEmail(`${leadingPad}${email}${trailingPad}`);
          expect(result).toEqual({ email });
        }
      ),
      { numRuns: 100 }
    );
  });

  it('non-empty invalid emails always throw', () => {
    fc.assert(
      fc.property(invalidEmailArb, (raw) => {
        expect(() => parseAdminEmail(raw)).toThrow();
      }),
      { numRuns: 100 }
    );
  });

  it('result is mutually exclusive: skip XOR email, never both', () => {
    fc.assert(
      fc.property(
        fc.oneof(blankArb, validEmailArb),
        (raw) => {
          const result = parseAdminEmail(raw as string | undefined);
          const hasSkip = 'skip' in result;
          const hasEmail = 'email' in result;
          expect(hasSkip !== hasEmail).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });
});
