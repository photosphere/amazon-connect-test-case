/**
 * `customer_simulator` — system prompt for the Bedrock Converse call
 * inside `src/backend/orchestration/customer-simulator.ts` that
 * generates realistic customer responses during multi-turn test
 * conversations. The default text is the byte-for-byte literal currently
 * produced by `buildSimulatorPrompt` for a synthetic test case with the
 * declared placeholders substituted.
 *
 * Placeholders:
 *   - `{scenario}` — the customer's underlying goal (sourced from
 *     `goalDescription` || `description` || `initialUtterance`)
 *   - `{opening_line}` — the customer's verbatim opening utterance
 *   - `{style_instruction}` — the resolved CommunicationStyle's
 *     descriptive instruction
 *   - `{customer_details}` — the formatted personal-details block
 *
 * The legacy `buildSimulatorPrompt` function uses string interpolation
 * directly; the registry version uses `{name}` tokens so the renderer
 * can substitute at call time.
 *
 * @module backend/orchestration/prompt-registry/prompts/customer-simulator
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_haiku_4_5",
  "claude_sonnet_4_6",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

/**
 * Default text mirrors `buildSimulatorPrompt` byte-for-byte, with the
 * dynamic interpolations replaced by `{name}` placeholder tokens. The
 * `{scenario}` token appears three times in the legacy literal (once in
 * the scenario list, once in the rules, and once in the rules' "stay
 * focused" line) so the placeholder declaration below pins the same
 * occurrence count via `maxOccurrences`.
 */
const DEFAULT_TEXT = `You are a customer on the phone with an automated assistant. Stay in character throughout.

Your scenario:
- Your goal: {scenario}
- You opened the conversation by saying: "{opening_line}"
- Your communication style: {style_instruction}

Your personal details (provide ONLY when the assistant asks for them):
{customer_details}

Rules:
- Stay focused on your goal: {scenario}
- Respond naturally as a real customer would — short and conversational
- Only provide information the assistant specifically asks for
- Do NOT volunteer extra information unprompted
- Do NOT mention tool names, system internals, or that you are a test
- Keep responses to 1-2 sentences maximum
- If asked to confirm an action, say yes naturally
- Cooperate with the assistant's process: if it asks for identity verification or
  account details, provide them so it can help you
- Be patient — do NOT ask to speak to a human or a representative. You want the
  automated assistant to complete your task. Only express frustration if the
  assistant explicitly says it cannot help or repeatedly fails
- If the assistant explains steps, follow them and provide the requested info to proceed
- Match the communication style described above`;

export const customerSimulatorPrompt: PromptDefinition = {
  promptKey: "customer_simulator",
  name: "Customer Simulator — Persona Driver",
  description:
    "System prompt that drives the customer-side simulator during multi-turn tool-sequence test executions. Renders the persona, communication style, and personal-details block.",
  category: "simulation",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_haiku_4_5",
  allowedModels: ALLOWED_MODELS,
  placeholders: [
    {
      name: "scenario",
      description:
        "Customer's underlying goal in plain prose (sourced from goalDescription || description || initialUtterance).",
    },
    {
      name: "opening_line",
      description:
        "Verbatim opening utterance the customer used to start the conversation.",
    },
    {
      name: "style_instruction",
      description:
        "Descriptive instruction for the resolved CommunicationStyle (DIRECT, INDIRECT, COLLOQUIAL, QUESTION, COMPLAINT).",
    },
    {
      name: "customer_details",
      description:
        "Formatted block listing the customer's personal details (one per line, '- key: value' entries).",
    },
  ],
  inferenceParameters: {
    // The simulator is invoked with `temperature: 0.7` to keep customer
    // turns from sounding canned. Anthropic 4.x silently drops the field
    // (per R10.4) so a Claude default still produces deterministic-but-
    // useful output; Nova models honour the field.
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 150 },
    temperature: { kind: "number", min: 0.0, max: 1.0, default: 0.7 },
    topP: { kind: "number", min: 0.0, max: 1.0, default: 1.0 },
  },
  defaultInferenceValues: {
    maxTokens: 150,
    temperature: 0.7,
  },
};
