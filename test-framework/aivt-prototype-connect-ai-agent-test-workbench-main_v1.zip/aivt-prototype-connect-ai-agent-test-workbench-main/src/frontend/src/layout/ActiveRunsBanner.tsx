/**
 * Persistent flash-bar item showing active runs the current browser tab has
 * launched. Renders nothing when no runs are tracked. Each item links to the
 * corresponding run dashboard so the user can drill in from anywhere in the
 * app.
 *
 * Uses the same {@link useActiveRunsContext} hook the launch buttons use to
 * register a new tracked run, so a click on "Run case" or "Run suite" is
 * reflected in the banner within one polling cycle.
 */
import { useNavigate } from "react-router-dom";
import Flashbar, {
  FlashbarProps,
} from "@cloudscape-design/components/flashbar";
import Button from "@cloudscape-design/components/button";
import SpaceBetween from "@cloudscape-design/components/space-between";
import { RunStatus } from "../../../shared/enums";
import { useActiveRunsContext } from "../hooks/ActiveRunsContext";

export function ActiveRunsBanner() {
  const { runs, dismissRun, dismissAll } = useActiveRunsContext();
  const navigate = useNavigate();

  if (runs.length === 0) return null;

  const items: FlashbarProps.MessageDefinition[] = runs.map((run) => {
    const labelSuite = run.suiteName ? `"${run.suiteName}"` : run.suiteId;
    const progress =
      run.completed != null && run.total != null
        ? ` — ${run.completed}/${run.total} cases`
        : "";
    return {
      id: run.runId,
      type: run.status === RunStatus.RUNNING ? "in-progress" : "info",
      header: `Run in progress: ${labelSuite}`,
      content: `Run ${run.runId.slice(0, 8)}…${progress}`,
      // `dismissible` adds Cloudscape's built-in × control; `onDismiss`
      // removes the entry from the tab-local tracker so the banner stays
      // bounded even when a tab was closed mid-run and entries piled up
      // in localStorage.
      dismissible: true,
      onDismiss: () => dismissRun(run.runId),
      action: (
        <SpaceBetween direction="horizontal" size="xs">
          <Button
            onClick={() =>
              navigate(`/runs/${run.runId}?suiteId=${run.suiteId}`)
            }
          >
            Open dashboard
          </Button>
          {/*
            "Dismiss all" appears on every row but executes the same
            action regardless. Cloudscape Flashbar doesn't have a
            top-level utility slot, so attaching it to the action area
            of each item is the path of least resistance — the user can
            click it from any visible row and it clears the lot.
          */}
          {runs.length > 1 && (
            <Button variant="inline-link" onClick={dismissAll}>
              Dismiss all
            </Button>
          )}
        </SpaceBetween>
      ),
    };
  });

  return <Flashbar items={items} />;
}
