/**
 * Full-page error state shown when `/config.json` cannot be loaded.
 *
 * Requirement 5.4: A network failure, non-OK response, or malformed
 * `/config.json` MUST display a "runtime configuration unavailable" error
 * state, retain the user on the current page, and prevent any API calls from
 * being issued. This component is the visible part of that requirement; the
 * suppression of API calls is enforced in `api/client.ts` (`getBaseUrl`).
 */

import Alert from '@cloudscape-design/components/alert';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import Container from '@cloudscape-design/components/container';
import Header from '@cloudscape-design/components/header';
import SpaceBetween from '@cloudscape-design/components/space-between';
import type { RuntimeConfigError as RuntimeConfigErrorDetail } from './api';

export interface RuntimeConfigErrorProps {
  error: RuntimeConfigErrorDetail;
}

export function RuntimeConfigError({ error }: RuntimeConfigErrorProps) {
  return (
    <Box padding={{ vertical: 'xxl', horizontal: 'l' }}>
      <Container header={<Header variant="h1">Connect Agent Test Platform</Header>}>
        <SpaceBetween size="m">
          <Alert
            type="error"
            header="Runtime configuration unavailable"
            data-testid="runtime-config-error"
          >
            <SpaceBetween size="s">
              <Box variant="p">
                The application could not load its runtime configuration
                (<code>/config.json</code>) and cannot reach the API. The page
                has been kept open so you can retry, but no API requests will
                be issued until the configuration loads successfully.
              </Box>
              <Box variant="small">{error.message}</Box>
            </SpaceBetween>
          </Alert>
          <Button
            variant="primary"
            iconName="refresh"
            onClick={() => window.location.reload()}
          >
            Retry
          </Button>
        </SpaceBetween>
      </Container>
    </Box>
  );
}
