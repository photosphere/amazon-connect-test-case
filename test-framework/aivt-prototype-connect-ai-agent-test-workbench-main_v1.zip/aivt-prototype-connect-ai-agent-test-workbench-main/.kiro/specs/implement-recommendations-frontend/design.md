# Design Document: Implement Recommendations Frontend

## Overview

This design wires the existing scaffolded "Implement Recommendations" frontend components to the backend API through a centralized state machine hook (`useImplementRecommendations`). The hook manages the complete lifecycle of both the Direct Apply and Multi-Variant Experiment flows, coordinating transitions between existing UI shells (ModeSelector, ConfirmationDialog, ExperimentProgress, PostApplyPrompt, ConflictResolution) and dispatching API calls through a dedicated recommendations API wrapper module.

The architecture follows the established hook pattern in the codebase (`useActiveRuns` with localStorage-backed polling), adapted for the implement-recommendations domain where server-side state (experiment records) provides persistence across page navigation rather than localStorage.

**Key design decisions:**
- Single state machine hook rather than distributed component state — prevents inconsistent UI states and simplifies testing
- Dedicated API wrapper module (`api/recommendations.ts`) isolating endpoint knowledge from UI logic
- Banner polling at a slower interval (10s) than the orchestrator's active polling (5s) since the banner is informational, not blocking user flow
- State machine enforces valid transitions — invalid transition attempts are silently ignored rather than throwing

## Architecture

```mermaid
graph TD
    subgraph RunDashboard Page
        IB[ImplementButton] --> SM[useImplementRecommendations Hook]
        SM --> MS[ModeSelector]
        SM --> CD[ConfirmationDialog]
        SM --> CR[ConflictResolution]
        SM --> PAP[PostApplyPrompt]
        SM --> EP[ExperimentProgress]
        PB[Progress Banner] --> POLL[useExperimentBanner Hook]
    end

    subgraph TournamentViewPage
        TV[TournamentView] --> SM2[useImplementRecommendations Hook]
        SM2 --> CD2[ConfirmationDialog]
        SM2 --> CR2[ConflictResolution]
        SM2 --> PAP2[PostApplyPrompt]
    end

    subgraph API Layer
        RAPI[api/recommendations.ts]
        AC[apiClient]
        RAPI --> AC
    end

    SM --> RAPI
    SM2 --> RAPI
    POLL --> RAPI
```

**Data flow:**
1. User clicks "Implement Recommendations" → ImplementButton opens ModeSelector
2. ModeSelector fires `onDirectApply` or `onExperiment` → hook dispatches transition
3. Hook manages API calls through `api/recommendations.ts` → updates state → child components re-render
4. Progress Banner independently polls experiment status at 10s intervals for the Run Dashboard's informational display

## Components and Interfaces

### `useImplementRecommendations` Hook (Frontend_Orchestrator)

The core state machine hook. Instantiated once per page that needs the implement flow (RunDashboard, TournamentViewPage).

```typescript
// src/frontend/src/hooks/useImplementRecommendations.ts

import type {
  Recommendation,
  DriftedField,
  ExperimentStatus,
  PerSuiteRecommendation,
} from '../../../shared/types';

// --- State Machine Types ---

export type ImplementState =
  | 'idle'
  | 'loading_recommendations'
  | 'confirming'
  | 'applying'
  | 'conflict'
  | 'success'
  | 'experiment_starting'
  | 'experiment_polling'
  | 'experiment_completed'
  | 'experiment_failed'
  | 'error';

export interface ImplementContext {
  recommendations: PerSuiteRecommendation[];
  selectedIndices: number[];
  driftedFields: DriftedField[];
  experimentId: string | null;
  experimentStatus: ExperimentStatus | null;
  newVersionId: string | null;
  errorMessage: string | null;
  /** Variant letter when applying from TournamentView */
  applyingVariant: 'A' | 'B' | 'C' | null;
  /** Variant-specific recommendations when applying from TournamentView */
  variantRecommendations: Recommendation[] | null;
  /** Tracks elapsed polling time for 30-minute warning */
  pollingStartedAt: number | null;
}

export interface UseImplementRecommendationsProps {
  runId: string;
  suiteId: string;
  agentId: string;
}

export interface UseImplementRecommendationsReturn {
  // State
  state: ImplementState;
  context: ImplementContext;
  isLoading: boolean; // derived: true when state is loading/applying/starting

  // Actions
  startDirectApply: () => void;
  startExperiment: () => void;
  confirmApply: () => void;
  cancelDialog: () => void;
  forceApply: () => void;
  reAnalyze: () => void;
  reRunSuite: () => void;
  dismissSuccess: () => void;
  retryExperiment: () => void;
  fallbackToDirectApply: () => void;
  setSelectedIndices: (indices: number[]) => void;

  // TournamentView-specific
  applyVariant: (variant: 'A' | 'B' | 'C', recommendations: Recommendation[]) => void;
}
```

### Valid State Transitions

```mermaid
stateDiagram-v2
    [*] --> idle
    idle --> loading_recommendations: startDirectApply
    loading_recommendations --> confirming: fetch success
    loading_recommendations --> error: fetch failure
    confirming --> applying: confirmApply
    confirming --> idle: cancelDialog
    confirming --> experiment_starting: startExperiment (from mode switch)
    applying --> success: API 2xx with newVersionId
    applying --> conflict: API 409 with driftedFields
    applying --> error: API non-409 error
    conflict --> applying: forceApply
    conflict --> idle: cancelDialog
    conflict --> loading_recommendations: reAnalyze (navigates away)
    success --> idle: dismissSuccess
    experiment_starting --> experiment_polling: API 2xx
    experiment_starting --> error: API error
    experiment_polling --> experiment_completed: status=completed|cleaned_up
    experiment_polling --> experiment_failed: status=failed
    experiment_completed --> idle: navigate away
    experiment_completed --> applying: applyVariant
    experiment_failed --> idle: cancelDialog
    experiment_failed --> experiment_starting: retryExperiment
    error --> idle: cancelDialog
    error --> loading_recommendations: retry
```

### API Wrapper Module

```typescript
// src/frontend/src/api/recommendations.ts

import { apiClient } from './client';
import type {
  ApplyRecommendationsResponse,
  ExperimentCreateResponse,
  ExperimentRecord,
  PerSuiteRecommendation,
} from '../../../shared/types';

export interface FetchRecommendationsResponse {
  recommendations: PerSuiteRecommendation[];
  agentName: string;
  agentId: string;
}

/**
 * Fetch per-suite recommendations for a completed run.
 * GET /runs/{runId}/recommendations
 */
export function fetchRecommendations(
  runId: string,
  suiteId: string,
): Promise<FetchRecommendationsResponse> {
  return apiClient.get<FetchRecommendationsResponse>(
    `/runs/${runId}/recommendations?suiteId=${encodeURIComponent(suiteId)}`,
  );
}

/**
 * Apply recommendations directly to the agent.
 * POST /runs/{runId}/apply-recommendations
 */
export function applyRecommendations(
  runId: string,
  agentId: string,
  recommendationIndices: number[],
  force?: boolean,
): Promise<ApplyRecommendationsResponse> {
  return apiClient.post<ApplyRecommendationsResponse>(
    `/runs/${runId}/apply-recommendations`,
    { mode: 'direct', agentId, recommendationIndices, ...(force && { force: true }) },
  );
}

/**
 * Create a multi-variant experiment.
 * POST /runs/{runId}/experiments
 */
export function createExperiment(
  runId: string,
  agentId: string,
): Promise<ExperimentCreateResponse> {
  return apiClient.post<ExperimentCreateResponse>(
    `/runs/${runId}/experiments`,
    { mode: 'multi_variant', agentId },
  );
}

/**
 * Get experiment status and details.
 * GET /runs/{runId}/experiments/{experimentId}
 */
export function getExperiment(
  runId: string,
  experimentId: string,
): Promise<ExperimentRecord> {
  return apiClient.get<ExperimentRecord>(
    `/runs/${runId}/experiments/${experimentId}`,
  );
}

/**
 * Apply a variant's changes to the real agent.
 * POST /runs/{runId}/experiments/{experimentId}/apply
 */
export function applyVariant(
  runId: string,
  experimentId: string,
  variant: 'A' | 'B' | 'C',
): Promise<ApplyRecommendationsResponse> {
  return apiClient.post<ApplyRecommendationsResponse>(
    `/runs/${runId}/experiments/${experimentId}/apply`,
    { variant },
  );
}

/**
 * List experiments for a run.
 * GET /runs/{runId}/experiments
 */
export function listExperiments(
  runId: string,
): Promise<{ experiments: ExperimentRecord[] }> {
  return apiClient.get<{ experiments: ExperimentRecord[] }>(
    `/runs/${runId}/experiments`,
  );
}
```

### `useExperimentBanner` Hook (Progress Banner)

A lightweight polling hook for the Run Dashboard's informational banner. Separate from the orchestrator hook because:
1. It polls at a different interval (10s vs 5s)
2. It tolerates failures silently (retains last-known state)
3. It runs independently of whether the user is actively in the implement flow

```typescript
// src/frontend/src/hooks/useExperimentBanner.ts

export interface ExperimentBannerState {
  /** Whether an experiment exists for this run */
  hasExperiment: boolean;
  /** Current experiment record (null if no experiment or not yet fetched) */
  experiment: ExperimentRecord | null;
  /** Whether the banner is in an error state (3+ consecutive poll failures) */
  pollError: boolean;
  /** Whether the experiment is in a terminal state */
  isTerminal: boolean;
}

export function useExperimentBanner(runId: string | null): ExperimentBannerState;
```

**Polling strategy:**
- Initial fetch on mount: `GET /runs/{runId}/experiments` → pick first experiment
- If experiment exists and status is non-terminal: poll `GET /runs/{runId}/experiments/{experimentId}` every 10 seconds
- On poll failure: increment consecutive failure counter, retain last-known status
- After 3 consecutive failures: set `pollError = true` (renders inline error)
- On successful poll after failures: reset failure counter, clear `pollError`
- Stop polling when status reaches a terminal value or component unmounts

### ExperimentBannerPanel Component

A presentational component rendered on the RunDashboard when an experiment exists.

```typescript
// src/frontend/src/components/ImplementRecommendations/ExperimentBannerPanel.tsx

export interface ExperimentBannerPanelProps {
  experiment: ExperimentRecord;
  runId: string;
  pollError?: boolean;
}
```

Renders:
- **Active statuses** (`generating_variants`, `creating_agents`, `running`, `cleanup_in_progress`): StatusIndicator (in-progress) + status text + link to ExperimentProgress page
- **Completed/cleaned_up**: StatusIndicator (success) + "View Experiment Results" link to TournamentView
- **Failed**: StatusIndicator (error) + failure message + "View Details" link
- **Poll error**: Alert with "Status updates unavailable" message

## Data Models

### State Machine Transition Map

The valid transitions are encoded as a `Record<ImplementState, ImplementState[]>`:

```typescript
const VALID_TRANSITIONS: Record<ImplementState, ImplementState[]> = {
  idle: ['loading_recommendations'],
  loading_recommendations: ['confirming', 'error'],
  confirming: ['applying', 'idle', 'experiment_starting'],
  applying: ['success', 'conflict', 'error'],
  conflict: ['applying', 'idle', 'loading_recommendations'],
  success: ['idle'],
  experiment_starting: ['experiment_polling', 'error'],
  experiment_polling: ['experiment_completed', 'experiment_failed'],
  experiment_completed: ['idle', 'applying'],
  experiment_failed: ['idle', 'experiment_starting'],
  error: ['idle', 'loading_recommendations'],
};
```

### Initial Context

```typescript
const INITIAL_CONTEXT: ImplementContext = {
  recommendations: [],
  selectedIndices: [],
  driftedFields: [],
  experimentId: null,
  experimentStatus: null,
  newVersionId: null,
  errorMessage: null,
  applyingVariant: null,
  variantRecommendations: null,
  pollingStartedAt: null,
};
```

### Terminal Experiment Statuses

```typescript
const TERMINAL_STATUSES: ExperimentStatus[] = ['completed', 'failed', 'cleaned_up'];

function isTerminalStatus(status: ExperimentStatus): boolean {
  return TERMINAL_STATUSES.includes(status);
}
```

### Polling Configuration

| Context | Interval | Max consecutive failures |
|---------|----------|--------------------------|
| Orchestrator (active experiment flow) | 5,000 ms | N/A (transitions to failed) |
| Banner (informational) | 10,000 ms | 3 (then shows error) |
| 30-minute warning threshold | 1,800,000 ms | N/A |

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: State transition validity

*For any* current state and *for any* transition request, the state machine SHALL accept the transition if and only if the target state appears in the valid transitions map for the current state; otherwise the state SHALL remain unchanged and no side effects SHALL occur.

**Validates: Requirements 7.3, 7.4**

### Property 2: Direct apply payload correctness

*For any* non-empty array of recommendation indices and *for any* valid agentId, when the state machine is in state `confirming` and `confirmApply` is called, the dispatched API request SHALL contain `mode: "direct"`, the exact indices array, and the exact agentId.

**Validates: Requirements 1.2**

### Property 3: Success transition populates newVersionId

*For any* successful apply response containing a `newVersionId` string, the state machine SHALL transition from `applying` to `success` and the context's `newVersionId` field SHALL equal the response's `newVersionId` value.

**Validates: Requirements 1.3**

### Property 4: Conflict transition populates driftedFields

*For any* HTTP 409 response containing a `driftedFields` array, the state machine SHALL transition from `applying` to `conflict` and the context's `driftedFields` field SHALL contain exactly the drifted fields from the response.

**Validates: Requirements 1.4**

### Property 5: Error recovery preserves loaded data

*For any* non-409 error response received while in states `applying`, `loading_recommendations`, or `experiment_starting`, the state machine SHALL transition to `error` and SHALL preserve the `recommendations` array that was loaded prior to the error (not clear it to empty).

**Validates: Requirements 1.5, 8.2**

### Property 6: Force apply includes force flag

*For any* set of drifted fields and when the state is `conflict`, calling `forceApply` SHALL dispatch a request with `force: true` in addition to the original recommendation indices and agentId.

**Validates: Requirements 2.1**

### Property 7: Dismiss clears transient context

*For any* state that supports dismissal (conflict, success, error, experiment_failed, confirming), calling the dismiss/cancel action SHALL transition to `idle` and SHALL reset all transient context fields (recommendations, driftedFields, experimentId, experimentStatus, newVersionId, errorMessage, applyingVariant, variantRecommendations) to their initial empty values.

**Validates: Requirements 7.5**

### Property 8: Experiment creation transitions to polling

*For any* valid agentId, when `startExperiment` is called and the POST request succeeds with an experimentId, the state machine SHALL transition from `experiment_starting` to `experiment_polling` and the context SHALL contain the returned experimentId.

**Validates: Requirements 4.1**

### Property 9: Banner retains last-known status on transient failures

*For any* last-known experiment status and *for any* sequence of fewer than 3 consecutive poll failures, the banner's displayed status SHALL remain equal to the last successfully fetched status and `pollError` SHALL remain false.

**Validates: Requirements 5.6**

### Property 10: Variant apply populates correct recommendations

*For any* variant letter (A, B, or C) and *for any* array of variant-specific recommendations, calling `applyVariant` SHALL populate the context's `variantRecommendations` with exactly that variant's recommendations and set `applyingVariant` to the selected letter.

**Validates: Requirements 6.1, 6.2**

## Error Handling

### API Error Classification

| HTTP Status | Handler | State Transition |
|-------------|---------|------------------|
| 401/403 | `apiClient` handles (redirect to login) | N/A — page unloads |
| 409 | Orchestrator detects `driftedFields` in response | `applying` → `conflict` |
| 4xx (other) | Orchestrator reads error message | Current → `error` (preserving data) |
| 5xx | `apiClient` dispatches Flashbar notification + Orchestrator | Current → `error` |
| Network timeout | `apiClient` retries (2x exponential backoff) | State unchanged during retries |
| All retries exhausted | `apiClient` throws | Current → `error` |

### Polling Error Handling

**Orchestrator polling (5s, experiment flow active):**
- Non-retryable error → stop polling, transition to `experiment_failed`, show error in Flashbar
- Retryable error → `apiClient` handles retries transparently; if all retries fail, treat as non-retryable

**Banner polling (10s, informational):**
- Any failure → increment consecutive failure counter, retain last-known status
- 3 consecutive failures → set `pollError`, render inline error in banner
- Next success → reset counter, clear `pollError`

### Error Recovery Actions

From the `error` state, the user can:
1. **Retry** (if error was during `loading_recommendations`) → transitions back to `loading_recommendations`
2. **Cancel** → transitions to `idle`, clears all context
3. **Use Direct Apply** (if error was during experiment creation) → transitions to `loading_recommendations`

### Conflict Resolution Actions

| Action | API Call | On Success | On Failure |
|--------|----------|-----------|-----------|
| Apply anyway | `POST /apply-recommendations` with `force: true` | → `success` | → dismiss conflict, show Flashbar error |
| Cancel | None | → `idle` | N/A |
| Re-analyze | `POST /runs` with same suiteId | Navigate to new run | Show Flashbar error, stay on current view |

## Testing Strategy

### Property-Based Tests (fast-check)

Property-based testing is appropriate for this feature because the state machine logic is a pure function of (currentState, action, apiResponse) → (nextState, nextContext), with meaningful input variation across states, actions, and response payloads.

**Library:** [fast-check](https://github.com/dubzzz/fast-check) (already available in the frontend test setup)

**Configuration:** Minimum 100 iterations per property test.

Each property test is tagged with:
```
// Feature: implement-recommendations-frontend, Property {N}: {property_text}
```

**Properties to implement:**
1. State transition validity (Property 1)
2. Direct apply payload correctness (Property 2)
3. Success transition populates newVersionId (Property 3)
4. Conflict transition populates driftedFields (Property 4)
5. Error recovery preserves loaded data (Property 5)
6. Force apply includes force flag (Property 6)
7. Dismiss clears transient context (Property 7)
8. Experiment creation transitions to polling (Property 8)
9. Banner retains last-known status on transient failures (Property 9)
10. Variant apply populates correct recommendations (Property 10)

### Unit Tests (Vitest + React Testing Library)

Unit tests cover specific examples, edge cases, and integration points:

- **ImplementButton visibility gates**: production mode, no recommendations, running status
- **ModeSelector → hook dispatch**: clicking "Continue" with each radio option calls the correct hook action
- **ConfirmationDialog loading state**: verify disabled buttons during `applying` state
- **Zero-index edge case**: confirm button disabled when `selectedIndices` is empty
- **Re-run Suite flow**: success navigation, error re-enable
- **Polling cleanup on unmount**: verify clearInterval is called
- **30-minute warning**: fake timers trigger warning indicator
- **Banner 3-failure threshold**: three consecutive failures → pollError visible

### Integration Tests

Integration tests verify the complete flow with mocked API responses:

- Direct Apply happy path: button click → mode select → fetch → confirm → apply → success prompt
- Experiment happy path: mode select → create → poll (mocked intervals) → navigate to tournament
- Conflict flow: apply → 409 → conflict dialog → force apply → success
- Re-analyze flow: conflict → re-analyze → new run created → navigate
- Banner lifecycle: mount → poll active → status changes → banner updates → terminal → stop

### Test File Organization

```
src/frontend/src/hooks/__tests__/
  useImplementRecommendations.test.ts      — state machine unit + property tests
  useImplementRecommendations.property.ts  — property-based tests (fast-check)
  useExperimentBanner.test.ts              — banner polling logic tests
src/frontend/src/api/__tests__/
  recommendations.test.ts                  — API wrapper unit tests
src/frontend/src/components/ImplementRecommendations/__tests__/
  integration.test.tsx                     — full flow integration tests
```
