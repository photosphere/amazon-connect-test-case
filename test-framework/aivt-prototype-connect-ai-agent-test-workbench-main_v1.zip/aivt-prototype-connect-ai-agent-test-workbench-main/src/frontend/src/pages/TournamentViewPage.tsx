/**
 * TournamentViewPage — routable page wrapper for the TournamentView component.
 *
 * Route: /runs/:runId/experiments/:experimentId
 *
 * Fetches the experiment record and variant results, then renders the
 * TournamentView comparison component. Integrates the
 * `useImplementRecommendations` hook for variant apply, conflict resolution,
 * and post-apply prompts (Requirements 6.1–6.4).
 *
 * Requirements addressed:
 *   - R6.1: Apply variant opens ConfirmationDialog with variant diffs
 *   - R6.2: Confirm calls POST /experiments/{id}/apply with variant letter
 *   - R6.3: Loading state disables dialog actions during apply
 *   - R6.4: Cleaned-up experiment shows error notification
 *   - R8.7: Tournament View accessible via "Experiment Results" link
 *   - R12.2: Persistent, navigable view for experiment results
 *
 * @module pages/TournamentViewPage
 */

import { useCallback, useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import Alert from '@cloudscape-design/components/alert';
import Spinner from '@cloudscape-design/components/spinner';
import { apiClient, ApiClientError } from '../api';
import type { ExperimentRecord, Recommendation, TestCaseResult } from '../../../shared/types';
import {
  TournamentView,
  ConfirmationDialog,
  ConflictResolution,
  PostApplyPrompt,
} from '../components/ImplementRecommendations';
import { useImplementRecommendations } from '../hooks/useImplementRecommendations';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface ExperimentDetailResponse {
  experiment: ExperimentRecord;
  baselineResults: TestCaseResult[];
  variantResults: Record<'A' | 'B' | 'C', TestCaseResult[]>;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function TournamentViewPage() {
  const { runId, experimentId } = useParams<{
    runId: string;
    experimentId: string;
  }>();
  const navigate = useNavigate();

  const [data, setData] = useState<ExperimentDetailResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // ---------------------------------------------------------------------------
  // Implement Recommendations Hook
  // ---------------------------------------------------------------------------

  // Extract suiteId and agentId from the loaded experiment data.
  // The hook needs these for API calls. We use empty strings as defaults
  // until the experiment data loads — the hook won't fire actions until
  // the user interacts, by which point data will be loaded.
  const suiteId = data?.experiment.runId ?? runId ?? '';
  const agentId = data?.experiment.agentId ?? '';

  const {
    state: implementState,
    context: implementContext,
    isLoading: implementIsLoading,
    applyVariant,
    confirmApply,
    cancelDialog,
    forceApply,
    reAnalyze,
    reRunSuite,
    dismissSuccess,
  } = useImplementRecommendations({
    runId: runId ?? '',
    suiteId,
    agentId,
  });

  // ---------------------------------------------------------------------------
  // Data Fetching
  // ---------------------------------------------------------------------------

  const fetchExperiment = useCallback(async () => {
    if (!runId || !experimentId) return;
    setLoading(true);
    setError(null);
    try {
      const response = await apiClient.get<ExperimentDetailResponse>(
        `/runs/${runId}/experiments/${experimentId}`,
      );
      setData(response);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to load experiment results.');
      }
    } finally {
      setLoading(false);
    }
  }, [runId, experimentId]);

  useEffect(() => {
    void fetchExperiment();
  }, [fetchExperiment]);

  // ---------------------------------------------------------------------------
  // Handlers
  // ---------------------------------------------------------------------------

  /**
   * When a user clicks "Apply to Agent" on a variant, find the variant's
   * recommendations from the experiment's variantConfigs and invoke the
   * hook's `applyVariant` action — which transitions through the state
   * machine to open the ConfirmationDialog.
   */
  const handleApplyVariant = useCallback(
    (variant: 'A' | 'B' | 'C') => {
      if (!data) return;

      // Find the variant's recommendations from the experiment config
      const variantConfig = data.experiment.variantConfigs.find(
        (vc) => vc.variantLetter === variant,
      );
      const recommendations: Recommendation[] = variantConfig?.recommendations ?? [];

      applyVariant(variant, recommendations, experimentId ?? undefined);
    },
    [data, applyVariant],
  );

  const handleRetrySummary = useCallback(async () => {
    if (!runId || !experimentId) return;
    try {
      await apiClient.post(
        `/runs/${runId}/experiments/${experimentId}/retry-summary`,
      );
      void fetchExperiment();
    } catch {
      // Silent — the retry button stays available.
    }
  }, [runId, experimentId, fetchExperiment]);

  /**
   * Handle the "Re-run Suite" action from PostApplyPrompt.
   * Delegates to the hook's reRunSuite (which resets state), then
   * navigates back to the run dashboard.
   */
  const handleReRunSuite = useCallback(() => {
    reRunSuite();
    if (runId) {
      navigate(`/runs/${runId}`);
    }
  }, [reRunSuite, runId, navigate]);

  /**
   * Handle "Re-analyze" from ConflictResolution.
   * Delegates to the hook's reAnalyze, then navigates back to the run.
   */
  const handleReAnalyze = useCallback(() => {
    reAnalyze();
    if (runId) {
      navigate(`/runs/${runId}`);
    }
  }, [reAnalyze, runId, navigate]);

  // ---------------------------------------------------------------------------
  // Derive dialog state
  // ---------------------------------------------------------------------------

  // Build the recommendations list for ConfirmationDialog from the
  // hook context's variantRecommendations (populated by applyVariant action).
  const dialogRecommendations: Recommendation[] =
    implementContext.variantRecommendations ?? [];

  const agentName = data?.experiment.agentId ?? 'Agent';
  const variantLabel = implementContext.applyingVariant
    ? ` (Variant ${implementContext.applyingVariant})`
    : '';

  // ---------------------------------------------------------------------------
  // Render: Loading
  // ---------------------------------------------------------------------------

  if (loading) {
    return (
      <ContentLayout
        header={
          <Header
            variant="h1"
            actions={
              <Button variant="link" onClick={() => navigate(`/runs/${runId}`)}>
                Back to run
              </Button>
            }
          >
            Experiment Results
          </Header>
        }
      >
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <Spinner size="large" />
            <Box variant="p">Loading experiment results…</Box>
          </SpaceBetween>
        </Box>
      </ContentLayout>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: Error
  // ---------------------------------------------------------------------------

  if (error && !data) {
    return (
      <ContentLayout
        header={
          <Header
            variant="h1"
            actions={
              <Button variant="link" onClick={() => navigate(`/runs/${runId}`)}>
                Back to run
              </Button>
            }
          >
            Experiment Results
          </Header>
        }
      >
        <Alert
          type="error"
          statusIconAriaLabel="Error"
          action={<Button onClick={fetchExperiment}>Retry</Button>}
        >
          {error}
        </Alert>
      </ContentLayout>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: Tournament View with dialogs
  // ---------------------------------------------------------------------------

  if (!data) {
    return null;
  }

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description={`Experiment ${experimentId}`}
          actions={
            <Button variant="link" onClick={() => navigate(`/runs/${runId}`)}>
              Back to run
            </Button>
          }
        >
          Experiment Results
        </Header>
      }
    >
      <SpaceBetween size="l">
        {error && (
          <Alert
            type="error"
            dismissible
            onDismiss={() => setError(null)}
          >
            {error}
          </Alert>
        )}

        {/* PostApplyPrompt — rendered when apply is successful (R6.2) */}
        <PostApplyPrompt
          visible={implementState === 'success'}
          newVersionId={implementContext.newVersionId ?? ''}
          onReRunSuite={handleReRunSuite}
          onDismiss={dismissSuccess}
        />

        {/* TournamentView — core comparison component */}
        <TournamentView
          experiment={data.experiment}
          baselineResults={data.baselineResults}
          variantResults={data.variantResults}
          onApplyVariant={handleApplyVariant}
          onRetrySummary={handleRetrySummary}
          applyDisabled={implementIsLoading}
        />

        {/* ConfirmationDialog — shown when state is confirming or applying (R6.1, R6.3) */}
        <ConfirmationDialog
          visible={implementState === 'confirming' || implementState === 'applying'}
          agentName={`${agentName}${variantLabel}`}
          agentId={agentId}
          recommendations={dialogRecommendations}
          onConfirm={confirmApply}
          onCancel={cancelDialog}
          loading={implementState === 'applying'}
        />

        {/* ConflictResolution — shown when apply returns 409 conflict (R6.2) */}
        <ConflictResolution
          visible={implementState === 'conflict'}
          driftedFields={implementContext.driftedFields}
          onApplyAnyway={forceApply}
          onCancel={cancelDialog}
          onReAnalyze={handleReAnalyze}
        />
      </SpaceBetween>
    </ContentLayout>
  );
}
