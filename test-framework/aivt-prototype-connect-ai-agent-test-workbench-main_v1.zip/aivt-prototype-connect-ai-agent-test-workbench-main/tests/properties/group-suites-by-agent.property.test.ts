/**
 * Property tests for `groupSuitesByAgent` (agent-grouped-suites, Task 3.2).
 *
 * The frontend's agent-grouped Test Suites layout buckets enriched suites
 * under one section per distinct `agentName`, displays an accurate suite
 * count in each section header, and orders sections alphabetically. These
 * three properties pin those guarantees across all valid inputs:
 *
 *   - Property 4: Grouping produces one section per distinct agentName —
 *     the number of returned groups equals the number of distinct
 *     `agentName` values in the input, and every group's `agentName` is
 *     one of those distinct values.
 *   - Property 5: Suite count in group header is accurate — each group's
 *     `suites.length` equals the number of input suites sharing that
 *     group's `agentName`.
 *   - Property 6: Groups are alphabetically ordered — the returned groups
 *     are in ascending lexicographic order by `agentName` (matching the
 *     `String.prototype.localeCompare` comparator the implementation uses).
 *
 * The generator deliberately draws `agentName` values from a small pool of
 * candidate names so that collisions are frequent: with a wide-open string
 * generator nearly every suite would land in its own singleton group and
 * the "grouping" behaviour (multiple suites collapsing under one name)
 * would almost never be exercised. The pool mixes names that differ only
 * by case and by surrounding whitespace so the ordering property is tested
 * against the same locale-aware comparator the implementation relies on.
 *
 * **Validates: Requirements 2.1, 2.2, 2.4, 5.1**
 */

import fc from 'fast-check';
import { describe, expect, it } from 'vitest';

import {
  groupSuitesByAgent,
  type AgentGroup,
} from '../../src/frontend/src/utils/groupSuites';
import type { EnrichedTestSuite } from '../../src/shared/types';

// ---------------------------------------------------------------------------
// Generators
// ---------------------------------------------------------------------------

// A small pool of candidate agent names. Keeping the pool small forces
// frequent collisions so the grouping behaviour (many suites under one
// name) is actually exercised. The pool intentionally includes names that
// differ only by case ("Alpha" vs "alpha") and by surrounding whitespace
// (" Beta" vs "Beta") so the alphabetical-ordering property is checked
// against the locale-aware comparator the implementation uses, not a naive
// code-point sort.
const AGENT_NAME_POOL: readonly string[] = [
  'Alpha',
  'alpha',
  'Beta',
  ' Beta',
  'Gamma',
  'gamma agent',
  'Delta-1',
  'Delta-2',
  'Écho', // non-ASCII to exercise locale comparison
  'zulu',
  'agent-007',
  'agent-42',
];

const agentNameArb: fc.Arbitrary<string> = fc.constantFrom(...AGENT_NAME_POOL);

/**
 * Build a single {@link EnrichedTestSuite}. Only `agentName` is
 * load-bearing for the properties under test; the remaining fields are
 * populated with plausible values so the object is a faithful instance of
 * the type. `suiteId` is supplied by the caller (the array generator) so
 * every suite in an iteration is uniquely identifiable, which lets the
 * suite-count property reason about exact membership.
 */
function enrichedSuiteArb(suiteId: string): fc.Arbitrary<EnrichedTestSuite> {
  return agentNameArb.map((agentName) => ({
    tenantId: 'tenant-1',
    suiteId,
    name: `suite-${suiteId}`,
    agentId: `agent-id-${suiteId}`,
    agentName,
    assistantId: 'assistant-1',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  }));
}

/**
 * A list of enriched suites with unique `suiteId`s. The length spans the
 * empty list (a valid input the grouping function must handle) up to a
 * modest cap that keeps each iteration fast while still producing inputs
 * with many suites collapsing under the shared name pool.
 */
const suitesArb: fc.Arbitrary<EnrichedTestSuite[]> = fc
  .integer({ min: 0, max: 30 })
  .chain((count) =>
    fc.tuple(
      ...Array.from({ length: count }, (_unused, i) =>
        enrichedSuiteArb(String(i)),
      ),
    ),
  )
  .map((suites) => [...suites]);

// ---------------------------------------------------------------------------
// Properties
// ---------------------------------------------------------------------------

describe('groupSuitesByAgent — Property 4: one section per distinct agentName', () => {
  it('returns exactly as many groups as there are distinct agentName values, each matching a distinct input name', () => {
    fc.assert(
      fc.property(suitesArb, (suites) => {
        const groups = groupSuitesByAgent(suites);
        const distinctNames = new Set(suites.map((s) => s.agentName));

        // Group count equals the number of distinct agentName values.
        expect(groups.length).toBe(distinctNames.size);

        // Every group's agentName is one of the distinct input names, and
        // no agentName is repeated across groups.
        const groupNames = groups.map((g) => g.agentName);
        for (const name of groupNames) {
          expect(distinctNames.has(name)).toBe(true);
        }
        expect(new Set(groupNames).size).toBe(groupNames.length);

        // The set of group names is exactly the set of distinct input names.
        expect(new Set(groupNames)).toEqual(distinctNames);
      }),
      { numRuns: 200 },
    );
  });
});

describe('groupSuitesByAgent — Property 5: suite count in group header is accurate', () => {
  it("each group's suites length equals the number of input suites sharing that agentName", () => {
    fc.assert(
      fc.property(suitesArb, (suites) => {
        const groups = groupSuitesByAgent(suites);

        for (const group of groups) {
          const expectedCount = suites.filter(
            (s) => s.agentName === group.agentName,
          ).length;
          expect(group.suites.length).toBe(expectedCount);
          // Every suite placed in the group actually carries that name.
          for (const s of group.suites) {
            expect(s.agentName).toBe(group.agentName);
          }
        }

        // Conservation: no suite is dropped or duplicated across groups.
        const totalGrouped = groups.reduce(
          (sum, g) => sum + g.suites.length,
          0,
        );
        expect(totalGrouped).toBe(suites.length);
      }),
      { numRuns: 200 },
    );
  });
});

describe('groupSuitesByAgent — Property 6: groups are alphabetically ordered', () => {
  it('returns groups in ascending lexicographic order by agentName', () => {
    fc.assert(
      fc.property(suitesArb, (suites) => {
        const groups = groupSuitesByAgent(suites);

        // Adjacent groups are in non-descending order under the same
        // locale-aware comparator the implementation uses.
        for (let i = 0; i + 1 < groups.length; i++) {
          const cmp = groups[i].agentName.localeCompare(
            groups[i + 1].agentName,
          );
          expect(cmp).toBeLessThanOrEqual(0);
        }

        // Equivalently, the emitted name order equals the sorted order of
        // the distinct names.
        const groupNames = groups.map((g: AgentGroup) => g.agentName);
        const sortedNames = [...groupNames].sort((a, b) => a.localeCompare(b));
        expect(groupNames).toEqual(sortedNames);
      }),
      { numRuns: 200 },
    );
  });
});
