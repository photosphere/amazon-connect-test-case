/**
 * Admin user bootstrap — CloudFormation custom-resource Lambda handler.
 *
 * Backs the {@link AdminUserBootstrapConstruct} (`lib/admin-bootstrap-construct.ts`).
 * On a `Create`/`Update` lifecycle event it creates the first Cognito user from
 * the validated `Admin_Email` via `AdminCreateUser`, idempotently:
 *
 *  - `Username` and the `email` user attribute are both set to the validated
 *    email; `email_verified` is set to `'true'` so the address is pre-verified
 *    and usable as the sign-in alias (Reqs 6.4, consistent with the pool's
 *    `signInAliases: { email: true }`).
 *  - `MessageAction` is left at its default (NOT `SUPPRESS`) so Cognito sends the
 *    temporary-password invitation email to the admin (Req 6.2). This produces a
 *    user in the `FORCE_CHANGE_PASSWORD` state, requiring a password change on
 *    first sign-in (Reqs 6.3, 6.7).
 *  - `UsernameExistsException` is treated as success WITHOUT resetting the user's
 *    credentials or password-change status — repeat deploys with the same email
 *    are no-ops and an existing user is never overwritten (Reqs 6.5, 7.3, 12.1).
 *
 * `Delete` is an intentional no-op: the bootstrap never deletes or disables the
 * user it created, so removing the `Admin_Email` on a later deploy (which causes
 * CloudFormation to delete this custom resource) leaves the existing user intact
 * (Req 7.4).
 *
 * Uses AWS SDK v3 `@aws-sdk/client-cognito-identity-provider`. `AdminCreateUser`
 * / `AdminGetUser` are long-standing, stable APIs, so the client is left external
 * (served by the Lambda runtime SDK) per the NodejsFunction default — the
 * construct grants the role only these two actions on the specific user-pool ARN.
 *
 * Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.7, 7.3, 7.4, 12.1
 *
 * @module admin-user-bootstrap
 */

import {
  AdminCreateUserCommand,
  CognitoIdentityProviderClient,
  UsernameExistsException,
} from "@aws-sdk/client-cognito-identity-provider";

// ---------------------------------------------------------------------------
// CloudFormation custom-resource event/response shapes
// ---------------------------------------------------------------------------

/** Minimal shape of the CloudFormation custom-resource event we consume. */
export interface CustomResourceEvent {
  RequestType: "Create" | "Update" | "Delete";
  PhysicalResourceId?: string;
  ResourceProperties: {
    /** The Cognito User Pool id the user is created in. */
    UserPoolId: string;
    /** The validated admin email (username + email attribute). */
    AdminEmail: string;
    /**
     * A stable physical resource id derived from the email by the construct.
     * Echoed back so repeat deploys with the same email are no-ops and changing
     * the email converges by creating the new user (old user untouched).
     */
    PhysicalResourceId: string;
  };
}

/** Response shape returned to the custom-resource provider framework. */
export interface CustomResourceResponse {
  PhysicalResourceId: string;
  Data: Record<string, string>;
}

// ---------------------------------------------------------------------------
// Client setup (injectable for tests)
// ---------------------------------------------------------------------------

let cognitoClient: CognitoIdentityProviderClient | null = null;

function getCognitoClient(): CognitoIdentityProviderClient {
  if (!cognitoClient) {
    cognitoClient = new CognitoIdentityProviderClient({});
  }
  return cognitoClient;
}

/**
 * Allows tests to inject a mocked Cognito client.
 * @internal
 */
export function _setCognitoClient(
  client: CognitoIdentityProviderClient | null
): void {
  cognitoClient = client;
}

// ---------------------------------------------------------------------------
// Handler
// ---------------------------------------------------------------------------

/**
 * Resolve the physical resource id to report back. Prefer the stable id the
 * construct derived from the email; fall back to any id already assigned by the
 * provider framework, then to a constant so a response is always well-formed.
 */
function resolvePhysicalResourceId(event: CustomResourceEvent): string {
  return (
    event.ResourceProperties?.PhysicalResourceId ||
    event.PhysicalResourceId ||
    "admin-user-bootstrap"
  );
}

/**
 * Custom-resource Lambda handler for the admin user bootstrap.
 *
 * @param event The CloudFormation custom-resource lifecycle event.
 * @returns The physical resource id (stable, email-derived) and empty data.
 */
export async function handler(
  event: CustomResourceEvent
): Promise<CustomResourceResponse> {
  console.log(
    "[admin-bootstrap] Event:",
    JSON.stringify(
      { RequestType: event.RequestType, PhysicalResourceId: event.PhysicalResourceId },
      null,
      2
    )
  );

  const physicalResourceId = resolvePhysicalResourceId(event);

  // Delete is a deliberate no-op: never delete or disable the bootstrapped
  // user, so removing Admin_Email on a later deploy leaves the user intact
  // (Req 7.4).
  if (event.RequestType === "Delete") {
    console.log(
      "[admin-bootstrap] Delete event — no-op (the bootstrapped user is never deleted)."
    );
    return { PhysicalResourceId: physicalResourceId, Data: {} };
  }

  const { UserPoolId, AdminEmail } = event.ResourceProperties;

  if (!UserPoolId) {
    throw new Error("UserPoolId resource property is required");
  }
  if (!AdminEmail) {
    throw new Error("AdminEmail resource property is required");
  }

  const client = getCognitoClient();

  try {
    await client.send(
      new AdminCreateUserCommand({
        UserPoolId,
        // Email is the username AND the email attribute, consistent with the
        // pool's email sign-in alias (Req 6.4).
        Username: AdminEmail,
        UserAttributes: [
          { Name: "email", Value: AdminEmail },
          { Name: "email_verified", Value: "true" },
        ],
        // Default MessageAction (NOT SUPPRESS) so Cognito emails the temporary
        // password to the admin (Req 6.2). This yields the FORCE_CHANGE_PASSWORD
        // state, requiring a password change on first sign-in (Reqs 6.3, 6.7).
      })
    );

    console.log(
      `[admin-bootstrap] Created admin user '${AdminEmail}' (FORCE_CHANGE_PASSWORD, temp-password email sent).`
    );
  } catch (error) {
    // Idempotency: an already-existing user is success. Do NOT reset the user's
    // credentials or password-change status (Reqs 6.5, 7.3, 12.1).
    if (
      error instanceof UsernameExistsException ||
      (error as { name?: string })?.name === "UsernameExistsException"
    ) {
      console.log(
        `[admin-bootstrap] Admin user '${AdminEmail}' already exists — treating as success without resetting credentials.`
      );
      return { PhysicalResourceId: physicalResourceId, Data: {} };
    }

    // Any other error fails the custom resource (and therefore the deploy).
    console.error(
      "[admin-bootstrap] AdminCreateUser failed:",
      error instanceof Error ? error.message : String(error)
    );
    throw error;
  }

  return { PhysicalResourceId: physicalResourceId, Data: {} };
}
