import { describe, it, expect } from "vitest";
import {
  checkDrift,
} from "../../src/backend/orchestration/drift-detection";
import {
  AgentDetail,
  Recommendation,
  ToolDefinition,
} from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

function makeTool(overrides: Partial<ToolDefinition> = {}): ToolDefinition {
  return {
    toolName: "defaultTool",
    toolType: "CUSTOM",
    description: "A default tool",
    inputSchema: {},
    examples: [],
    ...overrides,
  };
}

function makeAgent(overrides: Partial<AgentDetail> = {}): AgentDetail {
  return {
    agentId: "agent-1",
    name: "TestAgent",
    type: "ORCHESTRATION",
    systemPrompt: "You are a helpful agent.",
    modelId: "anthropic.claude-3-haiku",
    tools: [],
    ...overrides,
  };
}

function makeRec(overrides: Partial<Recommendation> = {}): Recommendation {
  return {
    targetField: "tool_description",
    targetName: "defaultTool",
    currentText: "A default tool",
    suggestedText: "An improved tool",
    rationale: "Better description",
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("checkDrift", () => {
  describe("no drift cases", () => {
    it("returns no drift when tool_description matches exactly", () => {
      const agent = makeAgent({
        tools: [makeTool({ toolName: "lookup", description: "Find stuff" })],
      });
      const rec = makeRec({
        targetField: "tool_description",
        targetName: "lookup",
        currentText: "Find stuff",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.driftedFields).toHaveLength(0);
      expect(result.cleanFields).toEqual([rec]);
    });

    it("returns no drift when tool_instruction matches exactly", () => {
      const agent = makeAgent({
        tools: [makeTool({ toolName: "verify", instruction: "Use after greeting" })],
      });
      const rec = makeRec({
        targetField: "tool_instruction",
        targetName: "verify",
        currentText: "Use after greeting",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.cleanFields).toEqual([rec]);
    });

    it("returns no drift when tool_instruction is undefined and currentText is empty", () => {
      const agent = makeAgent({
        tools: [makeTool({ toolName: "verify" })], // instruction is undefined
      });
      const rec = makeRec({
        targetField: "tool_instruction",
        targetName: "verify",
        currentText: "", // empty matches undefined → ""
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.cleanFields).toEqual([rec]);
    });

    it("returns no drift when system_prompt matches exactly", () => {
      const agent = makeAgent({ systemPrompt: "Be helpful and concise." });
      const rec = makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "Be helpful and concise.",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.cleanFields).toEqual([rec]);
    });

    it("returns no drift for tool_examples when currentText matches an entry", () => {
      const agent = makeAgent({
        tools: [
          makeTool({
            toolName: "lookup",
            examples: ["Where is my order?", "Track package"],
          }),
        ],
      });
      const rec = makeRec({
        targetField: "tool_examples",
        targetName: "lookup",
        currentText: "Where is my order?",
        suggestedText: "Where is my order status?",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.cleanFields).toEqual([rec]);
    });

    it("returns no drift for tool_examples add operation (empty currentText)", () => {
      const agent = makeAgent({
        tools: [makeTool({ toolName: "lookup", examples: ["existing"] })],
      });
      const rec = makeRec({
        targetField: "tool_examples",
        targetName: "lookup",
        currentText: "", // add operation
        suggestedText: "new example",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.cleanFields).toEqual([rec]);
    });
  });

  describe("drift detected cases", () => {
    it("detects drift when tool_description has changed", () => {
      const agent = makeAgent({
        tools: [makeTool({ toolName: "lookup", description: "New description" })],
      });
      const rec = makeRec({
        targetField: "tool_description",
        targetName: "lookup",
        currentText: "Original description",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(true);
      expect(result.driftedFields).toHaveLength(1);
      expect(result.driftedFields[0]).toEqual({
        targetField: "tool_description",
        targetName: "lookup",
        expectedText: "Original description",
        actualText: "New description",
      });
      expect(result.cleanFields).toHaveLength(0);
    });

    it("detects drift when tool_instruction has changed", () => {
      const agent = makeAgent({
        tools: [
          makeTool({ toolName: "verify", instruction: "Use only after warm greeting" }),
        ],
      });
      const rec = makeRec({
        targetField: "tool_instruction",
        targetName: "verify",
        currentText: "Use only after greeting.",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(true);
      expect(result.driftedFields[0]).toEqual({
        targetField: "tool_instruction",
        targetName: "verify",
        expectedText: "Use only after greeting.",
        actualText: "Use only after warm greeting",
      });
    });

    it("detects drift when system_prompt has changed", () => {
      const agent = makeAgent({ systemPrompt: "Be very helpful." });
      const rec = makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "Be helpful.",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(true);
      expect(result.driftedFields[0]).toEqual({
        targetField: "system_prompt",
        targetName: "system_prompt",
        expectedText: "Be helpful.",
        actualText: "Be very helpful.",
      });
    });

    it("detects drift when tool_examples entry no longer exists", () => {
      const agent = makeAgent({
        tools: [makeTool({ toolName: "lookup", examples: ["Different example"] })],
      });
      const rec = makeRec({
        targetField: "tool_examples",
        targetName: "lookup",
        currentText: "Where is my order?",
        suggestedText: "Where is my order status?",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(true);
      expect(result.driftedFields[0].expectedText).toBe("Where is my order?");
    });

    it("detects drift when target tool does not exist", () => {
      const agent = makeAgent({ tools: [] }); // no tools
      const rec = makeRec({
        targetField: "tool_description",
        targetName: "missingTool",
        currentText: "Some description",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(true);
      expect(result.driftedFields[0]).toEqual({
        targetField: "tool_description",
        targetName: "missingTool",
        expectedText: "Some description",
        actualText: "",
      });
    });

    it("detects single-character difference as drift (no normalization)", () => {
      const agent = makeAgent({
        tools: [makeTool({ toolName: "t", description: "Hello " })], // trailing space
      });
      const rec = makeRec({
        targetField: "tool_description",
        targetName: "t",
        currentText: "Hello", // no trailing space
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(true);
      expect(result.driftedFields[0].actualText).toBe("Hello ");
    });
  });

  describe("mixed results", () => {
    it("separates drifted and clean recommendations correctly", () => {
      const agent = makeAgent({
        systemPrompt: "Original prompt",
        tools: [
          makeTool({ toolName: "toolA", description: "Desc A" }),
          makeTool({ toolName: "toolB", description: "Changed Desc B" }),
        ],
      });

      const recClean = makeRec({
        targetField: "tool_description",
        targetName: "toolA",
        currentText: "Desc A",
      });
      const recDrifted = makeRec({
        targetField: "tool_description",
        targetName: "toolB",
        currentText: "Original Desc B",
      });
      const recSystemClean = makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "Original prompt",
      });

      const result = checkDrift({
        recommendations: [recClean, recDrifted, recSystemClean],
        liveAgentConfig: agent,
      });

      expect(result.hasDrift).toBe(true);
      expect(result.driftedFields).toHaveLength(1);
      expect(result.driftedFields[0].targetName).toBe("toolB");
      expect(result.cleanFields).toHaveLength(2);
      expect(result.cleanFields).toContain(recClean);
      expect(result.cleanFields).toContain(recSystemClean);
    });

    it("returns hasDrift=false when all recommendations are clean", () => {
      const agent = makeAgent({
        systemPrompt: "Prompt",
        tools: [makeTool({ toolName: "t", description: "D", instruction: "I" })],
      });

      const recs: Recommendation[] = [
        makeRec({ targetField: "tool_description", targetName: "t", currentText: "D" }),
        makeRec({ targetField: "tool_instruction", targetName: "t", currentText: "I" }),
        makeRec({ targetField: "system_prompt", targetName: "system_prompt", currentText: "Prompt" }),
      ];

      const result = checkDrift({ recommendations: recs, liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.driftedFields).toHaveLength(0);
      expect(result.cleanFields).toHaveLength(3);
    });
  });

  describe("edge cases", () => {
    it("handles empty recommendations array", () => {
      const agent = makeAgent();
      const result = checkDrift({ recommendations: [], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.driftedFields).toHaveLength(0);
      expect(result.cleanFields).toHaveLength(0);
    });

    it("handles whitespace-only differences as drift", () => {
      const agent = makeAgent({
        tools: [makeTool({ toolName: "t", description: "Hello\n" })],
      });
      const rec = makeRec({
        targetField: "tool_description",
        targetName: "t",
        currentText: "Hello",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(true);
    });

    it("handles empty string system_prompt matching empty currentText", () => {
      const agent = makeAgent({ systemPrompt: "" });
      const rec = makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "",
        suggestedText: "New prompt",
      });

      const result = checkDrift({ recommendations: [rec], liveAgentConfig: agent });

      expect(result.hasDrift).toBe(false);
      expect(result.cleanFields).toEqual([rec]);
    });
  });
});
