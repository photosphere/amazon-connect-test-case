# Implementation Plan: Implement Recommendations Frontend

## Overview

Wire the existing scaffolded "Implement Recommendations" frontend component shells to the deployed backend API endpoints via a centralized state machine hook, a dedicated API wrapper module, and an informational experiment banner. All backend endpoints are deployed; all component shells exist. This plan builds the connective tissue: API module → state machine hook → wiring into RunDashboard and TournamentViewPage.

## Tasks

- [x] 1. Create API wrapper module and state machine hook
  - [x] 1.1 Create the recommendations API wrapper module
    - Create `src/frontend/src/api/recommendations.ts` with typed functions: `fetchRecommendations`, `applyRecommendations`, `createExperiment`, `getExperiment`, `applyVariant`, `listExperiments`
    - Each function delegates to the existing `apiClient` (get/post) at the correct endpoint path
    - Export all types and functions; re-export from `src/frontend/src/api/index.ts`
    - _Requirements: 1.1, 1.2, 4.1, 6.2_

  - [x] 1.2 Implement the `useImplementRecommendations` state machine hook
    - Create `src/frontend/src/hooks/useImplementRecommendations.ts`
    - Define types: `ImplementState`, `ImplementContext`, `UseImplementRecommendationsProps`, `UseImplementRecommendationsReturn`
    - Implement the `VALID_TRANSITIONS` map and transition enforcement (invalid transitions silently ignored)
    - Implement `INITIAL_CONTEXT` and a `useReducer`-based state machine
    - Implement all action methods: `startDirectApply`, `startExperiment`, `confirmApply`, `cancelDialog`, `forceApply`, `reAnalyze`, `reRunSuite`, `dismissSuccess`, `retryExperiment`, `fallbackToDirectApply`, `setSelectedIndices`, `applyVariant`
    - Implement 5-second polling via `useEffect` + `setInterval` for the `experiment_polling` state, with cleanup on unmount
    - Implement 30-minute warning threshold by storing `pollingStartedAt` on entering `experiment_polling`
    - Handle API responses: 2xx → success transitions, 409 → conflict with driftedFields, other errors → error state preserving loaded data
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 1.1–1.8, 2.1–2.5, 3.1–3.3, 4.1–4.8, 6.1–6.4, 8.1–8.4_

  - [x] 1.3 Write property tests for the state machine (Properties 1–8, 10)
    - **Property 1: State transition validity**
    - **Property 2: Direct apply payload correctness**
    - **Property 3: Success transition populates newVersionId**
    - **Property 4: Conflict transition populates driftedFields**
    - **Property 5: Error recovery preserves loaded data**
    - **Property 6: Force apply includes force flag**
    - **Property 7: Dismiss clears transient context**
    - **Property 8: Experiment creation transitions to polling**
    - **Property 10: Variant apply populates correct recommendations**
    - Create `src/frontend/src/hooks/__tests__/useImplementRecommendations.property.ts`
    - Use fast-check with minimum 100 iterations per property
    - Mock API calls; test the pure state logic
    - **Validates: Requirements 7.3, 7.4, 1.2, 1.3, 1.4, 1.5, 2.1, 7.5, 4.1, 6.1, 6.2, 8.2**

- [x] 2. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Create experiment banner hook and panel component
  - [x] 3.1 Implement the `useExperimentBanner` hook
    - Create `src/frontend/src/hooks/useExperimentBanner.ts`
    - On mount: call `listExperiments(runId)` → pick first experiment
    - If non-terminal: poll `getExperiment(runId, experimentId)` every 10 seconds
    - Track consecutive failure count; set `pollError` after 3 consecutive failures
    - On success after failures: reset counter, clear `pollError`
    - Stop polling on terminal status or unmount (clearInterval cleanup)
    - Return `ExperimentBannerState`: `{ hasExperiment, experiment, pollError, isTerminal }`
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6_

  - [x] 3.2 Create the `ExperimentBannerPanel` component
    - Create `src/frontend/src/components/ImplementRecommendations/ExperimentBannerPanel.tsx`
    - Accept props: `experiment: ExperimentRecord`, `runId: string`, `pollError?: boolean`
    - Render StatusIndicator + status text + navigation Link based on experiment status
    - Active statuses → "in-progress" indicator + link to ExperimentProgress page
    - Completed/cleaned_up → "success" indicator + "View Experiment Results" link to TournamentView
    - Failed → "error" indicator + failure message + "View Details" link
    - Poll error → Alert with "Status updates unavailable"
    - Export from the ImplementRecommendations barrel (`index.ts`)
    - _Requirements: 5.1, 5.2, 5.4, 5.5, 5.6_

  - [x] 3.3 Write property test for banner resilience (Property 9)
    - **Property 9: Banner retains last-known status on transient failures**
    - Create test in `src/frontend/src/hooks/__tests__/useExperimentBanner.test.ts`
    - Use fast-check to generate sequences of fewer than 3 consecutive failures
    - Assert `pollError` remains false and displayed status equals last successful fetch
    - **Validates: Requirements 5.6**

- [x] 4. Wire RunDashboard to the orchestrator hook
  - [x] 4.1 Integrate `useImplementRecommendations` into RunDashboard
    - Import and instantiate `useImplementRecommendations` with `runId`, `effectiveSuiteId`, and `suite.agentId`
    - Pass `startDirectApply` as `onDirectApply` prop to `ImplementButton`
    - Pass `startExperiment` as `onExperiment` prop to `ImplementButton`
    - Conditionally render `ConfirmationDialog` when state is `confirming` or `applying`, passing hook context
    - Conditionally render `ConflictResolution` when state is `conflict`, wiring `forceApply`, `cancelDialog`, `reAnalyze`
    - Conditionally render `PostApplyPrompt` when state is `success`, wiring `reRunSuite`, `dismissSuccess`
    - Conditionally render `ExperimentProgress` when state is `experiment_starting` or `experiment_polling`
    - Handle navigation to TournamentView on `experiment_completed` via `useNavigate`
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 2.1, 2.2, 2.3, 3.1, 3.2, 3.3, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 8.1_

  - [x] 4.2 Integrate `useExperimentBanner` into RunDashboard
    - Import and instantiate `useExperimentBanner(runId)`
    - Replace the existing inline experiment state/fetch logic (the `experiment` useState and its useEffect) with the banner hook's return value
    - Render `ExperimentBannerPanel` when `bannerState.hasExperiment` is true, passing `experiment`, `runId`, `pollError`
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6_

- [x] 5. Wire TournamentViewPage to the orchestrator hook for variant apply
  - [x] 5.1 Integrate `useImplementRecommendations` into TournamentViewPage
    - Import and instantiate the hook with `runId`, `suiteId` (extracted from experiment data or route), and `agentId` (from experiment data)
    - Replace the existing `handleApplyVariant` callback with the hook's `applyVariant` action
    - Conditionally render `ConfirmationDialog` when state is `confirming` or `applying`
    - Conditionally render `ConflictResolution` when state is `conflict`
    - Conditionally render `PostApplyPrompt` when state is `success`
    - Pass loading states through to disable TournamentView "Apply to Agent" buttons while the hook is busy
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

- [x] 6. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Unit and integration tests
  - [x] 7.1 Write unit tests for `useImplementRecommendations` hook
    - Create `src/frontend/src/hooks/__tests__/useImplementRecommendations.test.ts`
    - Test the Direct Apply happy path: idle → loading → confirming → applying → success
    - Test conflict path: applying → conflict → forceApply → success
    - Test error recovery: applying → error (preserves recommendations)
    - Test experiment path: idle → experiment_starting → experiment_polling → completed
    - Test 30-minute warning: fake timers, verify `pollingStartedAt` triggers warning
    - Test polling cleanup on unmount
    - Test zero-selection guard: confirmApply with empty `selectedIndices` stays in `confirming`
    - _Requirements: 1.1–1.8, 2.1–2.5, 4.1–4.8, 7.1–7.5, 8.1–8.4_

  - [x] 7.2 Write unit tests for `useExperimentBanner` hook
    - Create `src/frontend/src/hooks/__tests__/useExperimentBanner.test.ts`
    - Test initial fetch: no experiment → `hasExperiment: false`
    - Test polling: active experiment → polls every 10s → updates on status change
    - Test terminal detection: completed/failed → stops polling
    - Test 3-failure threshold: three consecutive errors → `pollError: true`
    - Test recovery: success after failures → `pollError: false`
    - _Requirements: 5.1–5.6_

  - [x] 7.3 Write unit tests for `api/recommendations.ts`
    - Create `src/frontend/src/api/__tests__/recommendations.test.ts`
    - Mock `apiClient` methods
    - Verify correct URL construction and payload shape for each function
    - Verify `force: true` inclusion in force-apply path
    - _Requirements: 1.2, 2.1, 4.1, 6.2_

  - [x] 7.4 Write integration tests for the full Direct Apply flow
    - Create `src/frontend/src/components/ImplementRecommendations/__tests__/integration.test.tsx`
    - Render RunDashboard with mocked API responses
    - Simulate: button click → mode select → fetch → confirm → apply → success prompt
    - Verify ConfirmationDialog renders recommendation diffs
    - Verify PostApplyPrompt shows newVersionId
    - _Requirements: 1.1, 1.2, 1.3, 1.6_

  - [x] 7.5 Write integration tests for the Experiment and Conflict flows
    - Add to the integration test file
    - Experiment path: mode select → create → poll (advance fake timers) → navigate to tournament view
    - Conflict path: apply → 409 → ConflictResolution renders → force apply → success
    - Banner lifecycle: mount with active experiment → poll → status change → banner updates → terminal → stop
    - _Requirements: 4.1, 4.3, 4.4, 2.1, 5.1, 5.3, 5.4_

- [x] 8. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design's Correctness Properties section
- Unit tests validate specific examples and edge cases
- The design uses TypeScript explicitly — all implementation uses TypeScript strict mode
- All backend APIs are already deployed; this is purely frontend work
- Component shells already exist — tasks wire callbacks and manage state, not create new components (except ExperimentBannerPanel)
- The existing `apiClient` handles auth, retries, and error notifications — the API wrapper is a thin typed layer on top

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["1.2", "3.1", "3.2"] },
    { "id": 2, "tasks": ["1.3", "3.3"] },
    { "id": 3, "tasks": ["4.1", "4.2", "5.1"] },
    { "id": 4, "tasks": ["7.1", "7.2", "7.3"] },
    { "id": 5, "tasks": ["7.4", "7.5"] }
  ]
}
```
