// Feature: connect-agent-test-platform, Property 3: Cascade Delete Completeness
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { DynamoDBService } from "@backend/services/dynamodb";
import { CommunicationStyle } from "@shared/enums";
import type { TestSuite, TestCase } from "@shared/types";

/**
 * **Validates: Requirements 4.6**
 *
 * Property 3: Cascade Delete Completeness
 * For any test suite containing N test cases, deleting the suite SHALL remove
 * exactly N+1 DynamoDB records (the suite record plus all N case records), and
 * subsequent queries for the suite or any of its cases SHALL return no results.
 */

// ---------------------------------------------------------------------------
// In-memory mock DynamoDBDocumentClient
// ---------------------------------------------------------------------------

/**
 * A minimal in-memory mock of DynamoDBDocumentClient that tracks items using
 * a Map keyed by "PK|SK". Supports Get, Put, Delete, Query, and BatchWrite
 * commands which are the operations used by DynamoDBService.
 */
function createMockDocumentClient() {
  const store = new Map<string, Record<string, unknown>>();

  function itemKey(pk: string, sk: string): string {
    return `${pk}|${sk}`;
  }

  const client = {
    send: async (command: unknown): Promise<unknown> => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
      const commandName = cmd.constructor.name;

      switch (commandName) {
        case "PutCommand": {
          const item = cmd.input.Item as Record<string, string>;
          const pk = item.PK;
          const sk = item.SK;
          const key = itemKey(pk, sk);

          // Respect ConditionExpression: "attribute_not_exists(PK)"
          if (
            cmd.input.ConditionExpression === "attribute_not_exists(PK)" &&
            store.has(key)
          ) {
            throw new Error("ConditionalCheckFailedException");
          }
          // Respect ConditionExpression: "attribute_exists(PK)"
          if (
            cmd.input.ConditionExpression === "attribute_exists(PK)" &&
            !store.has(key)
          ) {
            throw new Error("ConditionalCheckFailedException");
          }

          store.set(key, { ...item });
          return {};
        }

        case "GetCommand": {
          const getKey = cmd.input.Key as Record<string, string>;
          const pk = getKey.PK;
          const sk = getKey.SK;
          const item = store.get(itemKey(pk, sk));
          return { Item: item || undefined };
        }

        case "DeleteCommand": {
          const delKey = cmd.input.Key as Record<string, string>;
          const pk = delKey.PK;
          const sk = delKey.SK;
          store.delete(itemKey(pk, sk));
          return {};
        }

        case "QueryCommand": {
          const expr = cmd.input.KeyConditionExpression as string;
          const values = cmd.input.ExpressionAttributeValues as Record<string, string>;

          let results: Record<string, unknown>[] = [];

          if (expr.includes("begins_with")) {
            // Pattern: "PK = :pk AND begins_with(SK, :skPrefix)"
            const pk = values[":pk"];
            const skPrefix = values[":skPrefix"];
            for (const [key, item] of store.entries()) {
              const [storedPk] = key.split("|");
              const storedSk = (item as Record<string, string>).SK;
              if (storedPk === pk && storedSk && storedSk.startsWith(skPrefix)) {
                results.push(item);
              }
            }
          } else if (expr.includes("GSI1PK")) {
            // GSI1 query pattern
            const pk = values[":pk"];
            for (const [, item] of store.entries()) {
              if ((item as Record<string, string>).GSI1PK === pk) {
                results.push(item);
              }
            }
          } else {
            // Simple PK-only query
            const pk = values[":pk"];
            for (const [key, item] of store.entries()) {
              const [storedPk] = key.split("|");
              if (storedPk === pk) {
                results.push(item);
              }
            }
          }

          return { Items: results };
        }

        case "BatchWriteCommand": {
          const requestItems = cmd.input.RequestItems as Record<
            string,
            Array<{
              PutRequest?: { Item: Record<string, string> };
              DeleteRequest?: { Key: Record<string, string> };
            }>
          >;

          for (const [, requests] of Object.entries(requestItems)) {
            for (const request of requests) {
              if (request.PutRequest) {
                const item = request.PutRequest.Item;
                store.set(itemKey(item.PK, item.SK), { ...item });
              }
              if (request.DeleteRequest) {
                const delKey = request.DeleteRequest.Key;
                store.delete(itemKey(delKey.PK, delKey.SK));
              }
            }
          }
          return {};
        }

        case "UpdateCommand": {
          // Not needed for this test, but included for completeness
          return {};
        }

        default:
          throw new Error(`Unsupported command: ${commandName}`);
      }
    },
  };

  return { client, store };
}

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

const tenantIdArb = fc.hexaString({ minLength: 8, maxLength: 8 });
const suiteIdArb = fc.uuid();
const caseIdArb = fc.uuid();

/** Generate a valid TestSuite object. */
function suiteArb(tenantId: string, suiteId: string): fc.Arbitrary<TestSuite> {
  return fc.record({
    tenantId: fc.constant(tenantId),
    suiteId: fc.constant(suiteId),
    name: fc.string({ minLength: 1, maxLength: 128 }).filter((s) => s.trim().length > 0),
    description: fc.string({ maxLength: 500 }),
    agentId: fc.uuid(),
    assistantId: fc.uuid(),
    createdAt: fc.constant(new Date().toISOString()),
    updatedAt: fc.constant(new Date().toISOString()),
  });
}

/** Generate a valid TestCase object. */
function testCaseArb(suiteId: string, caseId: string): fc.Arbitrary<TestCase> {
  return fc.record({
    type: fc.constant("tool_sequence" as const),
    suiteId: fc.constant(suiteId),
    caseId: fc.constant(caseId),
    name: fc.string({ minLength: 1, maxLength: 100 }).filter((s) => s.trim().length > 0),
    description: fc.string({ minLength: 1, maxLength: 200 }),
    persona: fc.string({ minLength: 1, maxLength: 50 }),
    style: fc.constantFrom(
      CommunicationStyle.DIRECT,
      CommunicationStyle.INDIRECT,
      CommunicationStyle.COLLOQUIAL,
      CommunicationStyle.QUESTION,
      CommunicationStyle.COMPLAINT
    ),
    customerKnowledge: fc.constant({ key1: "value1" }),
    initialUtterance: fc.string({ minLength: 1, maxLength: 200 }),
    successCriteria: fc.constant([{ toolName: "SomeTool", required: true }]),
  });
}

// ---------------------------------------------------------------------------
// Property test
// ---------------------------------------------------------------------------

describe("Property 3: Cascade Delete Completeness", () => {
  it("deleting a suite removes exactly N+1 records (suite + N cases) and leaves no trace", async () => {
    await fc.assert(
      fc.asyncProperty(
        tenantIdArb,
        suiteIdArb,
        fc.integer({ min: 0, max: 50 }),
        async (tenantId, suiteId, numCases) => {
          // Create a fresh mock client for each iteration
          const { client } = createMockDocumentClient();
          const service = new DynamoDBService("TestTable", client as any);

          // Generate and create the suite
          const suite = fc.sample(suiteArb(tenantId, suiteId), 1)[0];
          await service.createSuite(suite);

          // Generate and create N test cases
          const caseIds: string[] = [];
          for (let i = 0; i < numCases; i++) {
            const caseId = fc.sample(caseIdArb, 1)[0];
            caseIds.push(caseId);
            const testCase = fc.sample(testCaseArb(suiteId, caseId), 1)[0];
            await service.createCase(testCase);
          }

          // Verify suite and cases exist before delete
          const suiteBeforeDelete = await service.getSuite(tenantId, suiteId);
          expect(suiteBeforeDelete).not.toBeNull();

          const casesBeforeDelete = await service.listCases(suiteId);
          expect(casesBeforeDelete).toHaveLength(numCases);

          // Perform cascade delete
          await service.deleteSuite(tenantId, suiteId);

          // Verify Property: suite is gone
          const suiteAfterDelete = await service.getSuite(tenantId, suiteId);
          expect(suiteAfterDelete).toBeNull();

          // Verify Property: all cases are gone
          const casesAfterDelete = await service.listCases(suiteId);
          expect(casesAfterDelete).toHaveLength(0);

          // Verify Property: individual case lookups return null
          for (const caseId of caseIds) {
            const caseResult = await service.getCase(suiteId, caseId);
            expect(caseResult).toBeNull();
          }
        }
      ),
      { numRuns: 100 }
    );
  });
});
