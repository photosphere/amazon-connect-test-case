/**
 * DynamoDB single-table service layer for the Connect Agent Test Platform.
 *
 * Uses composite keys per the design's data model table:
 * - TestSuite: PK=TENANT#{tenantId}, SK=SUITE#{suiteId}
 * - TestCase: PK=SUITE#{suiteId}, SK=CASE#{caseId}
 * - TestRun: PK=SUITE#{suiteId}, SK=RUN#{timestamp}
 * - TestResult: PK=RUN#{runId}, SK=CASE#{caseId}
 * - Transcript: PK=RUN#{runId}#CASE#{caseId}, SK=TURN#{turnNumber}
 * - AgentSnapshot: PK=RUN#{runId}, SK=SNAPSHOT
 *
 * @module dynamodb
 */

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  BatchWriteCommand,
  DeleteCommand,
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  QueryCommand,
  ScanCommand,
  TransactWriteCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import {
  AgentSnapshot,
  ExecutionStep,
  ExecutionTrace,
  PromptHistoryEntry,
  PromptKey,
  PromptOverride,
  TestCase,
  TestCaseResult,
  TestRun,
  TestSuite,
  TranscriptTurn,
} from "../../shared/types";

// ---------------------------------------------------------------------------
// Client setup
// ---------------------------------------------------------------------------

const TABLE_NAME = process.env.TABLE_NAME || "ConnectAgentTestPlatform";

const ddbClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(ddbClient, {
  marshallOptions: { removeUndefinedValues: true },
});

/**
 * Allows tests or external consumers to override the table name and client.
 */
export function createDynamoDBService(
  tableName: string,
  client: DynamoDBDocumentClient
) {
  return new DynamoDBService(tableName, client);
}

// ---------------------------------------------------------------------------
// systemInstructions truncation guard (350 KB limit)
// ---------------------------------------------------------------------------

/** Maximum byte size for systemInstructions after JSON serialization. */
const SYSTEM_INSTRUCTIONS_MAX_BYTES = 350 * 1024; // 358,400 bytes

/** Suffix appended when systemInstructions is truncated. */
const TRUNCATION_SUFFIX = "\n…[truncated]";

/**
 * Iterates through execution steps and truncates any
 * `inferenceMetadata.systemInstructions` that exceeds 350 KB after JSON
 * serialization. Returns a new array of steps with truncated values where
 * needed.
 *
 * If the truncation logic itself throws, the error propagates to the caller
 * and the TRACE row is NOT written.
 */
export function truncateSystemInstructions(
  steps: ExecutionStep[],
  runId: string,
  caseId: string
): ExecutionStep[] {
  return steps.map((step, index) => {
    const systemInstructions = step.inferenceMetadata?.systemInstructions;
    if (systemInstructions === undefined || systemInstructions === null) {
      return step;
    }

    const serialized = JSON.stringify(systemInstructions);
    const byteLength = Buffer.byteLength(serialized, "utf8");

    if (byteLength <= SYSTEM_INSTRUCTIONS_MAX_BYTES) {
      return step;
    }

    // Truncate the string itself at a byte boundary within 350 KB.
    const truncated = truncateStringToByteLimit(
      systemInstructions,
      SYSTEM_INSTRUCTIONS_MAX_BYTES
    );

    console.warn(
      `[writeExecutionTrace] systemInstructions truncated: runId=${runId}, caseId=${caseId}, stepIndex=${index} (${byteLength} bytes → ${SYSTEM_INSTRUCTIONS_MAX_BYTES} bytes)`
    );

    return {
      ...step,
      inferenceMetadata: {
        ...step.inferenceMetadata,
        systemInstructions: truncated + TRUNCATION_SUFFIX,
      },
    };
  });
}

/**
 * Truncates a string to fit within the specified byte limit (UTF-8),
 * ensuring we don't cut in the middle of a multi-byte character.
 */
function truncateStringToByteLimit(str: string, maxBytes: number): string {
  const buf = Buffer.from(str, "utf8");
  if (buf.length <= maxBytes) {
    return str;
  }

  // Slice the buffer to maxBytes, then decode back to string.
  // Buffer.toString will handle partial multi-byte characters by
  // stopping at the last complete character boundary.
  let truncatedBuf = buf.subarray(0, maxBytes);

  // Walk backwards to find a valid UTF-8 boundary. A continuation byte
  // starts with bits 10xxxxxx (0x80-0xBF). We need to back up past any
  // incomplete multi-byte sequence at the end.
  let end = truncatedBuf.length;
  while (end > 0 && (truncatedBuf[end - 1] & 0xc0) === 0x80) {
    end--;
  }
  // If we landed on a multi-byte start byte, check if the sequence is complete.
  // A leading byte of 110xxxxx needs 1 continuation, 1110xxxx needs 2, 11110xxx needs 3.
  if (end > 0) {
    const leadByte = truncatedBuf[end - 1];
    let expectedLength = 1;
    if ((leadByte & 0xe0) === 0xc0) expectedLength = 2;
    else if ((leadByte & 0xf0) === 0xe0) expectedLength = 3;
    else if ((leadByte & 0xf8) === 0xf0) expectedLength = 4;

    const availableBytes = truncatedBuf.length - (end - 1);
    if (availableBytes < expectedLength) {
      // Incomplete multi-byte character; remove the leading byte too.
      end--;
    }
  }

  truncatedBuf = truncatedBuf.subarray(0, end);
  return truncatedBuf.toString("utf8");
}

// ---------------------------------------------------------------------------
// Service class
// ---------------------------------------------------------------------------

export class DynamoDBService {
  constructor(
    private readonly tableName: string = TABLE_NAME,
    private readonly client: DynamoDBDocumentClient = docClient
  ) {}

  // -------------------------------------------------------------------------
  // Test Suite CRUD
  // -------------------------------------------------------------------------

  async createSuite(suite: TestSuite): Promise<void> {
    await this.client.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          PK: `${PK_PATTERNS.TENANT}${suite.tenantId}`,
          SK: `${SK_PATTERNS.SUITE}${suite.suiteId}`,
          ...suite,
          // GSI1: tenant + updatedAt
          GSI1PK: `${PK_PATTERNS.TENANT}${suite.tenantId}`,
          GSI1SK: suite.updatedAt,
          // GSI2: agent + createdAt
          GSI2PK: `AGENT#${suite.agentId}`,
          GSI2SK: suite.createdAt,
        },
        ConditionExpression: "attribute_not_exists(PK)",
      })
    );
  }

  async getSuite(tenantId: string, suiteId: string): Promise<TestSuite | null> {
    const result = await this.client.send(
      new GetCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.TENANT}${tenantId}`,
          SK: `${SK_PATTERNS.SUITE}${suiteId}`,
        },
      })
    );
    if (!result.Item) return null;
    return this.stripKeys<TestSuite>(result.Item);
  }

  async updateSuite(
    suite: Pick<TestSuite, "tenantId" | "suiteId"> &
      Partial<Pick<TestSuite, "name" | "description" | "updatedAt" | "ragThresholds">>
  ): Promise<void> {
    const expressionParts: string[] = [];
    const names: Record<string, string> = {};
    const values: Record<string, unknown> = {};

    if (suite.name !== undefined) {
      expressionParts.push("#n = :n");
      names["#n"] = "name";
      values[":n"] = suite.name;
    }
    if (suite.description !== undefined) {
      expressionParts.push("#d = :d");
      names["#d"] = "description";
      values[":d"] = suite.description;
    }
    if (suite.updatedAt !== undefined) {
      expressionParts.push("#u = :u, GSI1SK = :u");
      names["#u"] = "updatedAt";
      values[":u"] = suite.updatedAt;
    }
    if (suite.ragThresholds !== undefined) {
      expressionParts.push("ragThresholds = :rt");
      values[":rt"] = suite.ragThresholds;
    }

    if (expressionParts.length === 0) return;

    await this.client.send(
      new UpdateCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.TENANT}${suite.tenantId}`,
          SK: `${SK_PATTERNS.SUITE}${suite.suiteId}`,
        },
        UpdateExpression: `SET ${expressionParts.join(", ")}`,
        ...(Object.keys(names).length > 0 && { ExpressionAttributeNames: names }),
        ExpressionAttributeValues: values,
        ConditionExpression: "attribute_exists(PK)",
      })
    );
  }

  async deleteSuite(tenantId: string, suiteId: string): Promise<void> {
    // Cascade delete: remove suite record + all associated test cases
    const cases = await this.listCases(suiteId);

    // Collect all items to delete
    const deleteRequests: Array<{
      DeleteRequest: { Key: Record<string, string> };
    }> = [];

    // Suite record
    deleteRequests.push({
      DeleteRequest: {
        Key: {
          PK: `${PK_PATTERNS.TENANT}${tenantId}`,
          SK: `${SK_PATTERNS.SUITE}${suiteId}`,
        },
      },
    });

    // All case records
    for (const tc of cases) {
      deleteRequests.push({
        DeleteRequest: {
          Key: {
            PK: `${PK_PATTERNS.SUITE}${suiteId}`,
            SK: `${SK_PATTERNS.CASE}${tc.caseId}`,
          },
        },
      });
    }

    // BatchWriteItem supports max 25 items per request
    const batches = this.chunkArray(deleteRequests, 25);
    for (const batch of batches) {
      await this.client.send(
        new BatchWriteCommand({
          RequestItems: {
            [this.tableName]: batch,
          },
        })
      );
    }
  }

  async listSuites(tenantId: string): Promise<TestSuite[]> {
    const result = await this.client.send(
      new QueryCommand({
        TableName: this.tableName,
        IndexName: "GSI1",
        KeyConditionExpression: "GSI1PK = :pk",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.TENANT}${tenantId}`,
        },
        ScanIndexForward: false, // newest first
      })
    );
    return (result.Items || []).map((item) => this.stripKeys<TestSuite>(item));
  }

  // -------------------------------------------------------------------------
  // Test Case CRUD
  // -------------------------------------------------------------------------

  async createCase(testCase: TestCase): Promise<void> {
    await this.client.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          PK: `${PK_PATTERNS.SUITE}${testCase.suiteId}`,
          SK: `${SK_PATTERNS.CASE}${testCase.caseId}`,
          ...testCase,
        },
        ConditionExpression: "attribute_not_exists(PK)",
      })
    );
  }

  async getCase(suiteId: string, caseId: string): Promise<TestCase | null> {
    const result = await this.client.send(
      new GetCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.SUITE}${suiteId}`,
          SK: `${SK_PATTERNS.CASE}${caseId}`,
        },
      })
    );
    if (!result.Item) return null;
    return this.stripKeys<TestCase>(result.Item);
  }

  async updateCase(testCase: TestCase): Promise<void> {
    await this.client.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          PK: `${PK_PATTERNS.SUITE}${testCase.suiteId}`,
          SK: `${SK_PATTERNS.CASE}${testCase.caseId}`,
          ...testCase,
        },
        ConditionExpression: "attribute_exists(PK)",
      })
    );
  }

  async deleteCase(suiteId: string, caseId: string): Promise<void> {
    await this.client.send(
      new DeleteCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.SUITE}${suiteId}`,
          SK: `${SK_PATTERNS.CASE}${caseId}`,
        },
      })
    );
  }

  async listCases(suiteId: string): Promise<TestCase[]> {
    const result = await this.client.send(
      new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.SUITE}${suiteId}`,
          ":skPrefix": SK_PATTERNS.CASE,
        },
      })
    );
    return (result.Items || []).map((item) => this.stripKeys<TestCase>(item));
  }

  // -------------------------------------------------------------------------
  // Test Run operations
  // -------------------------------------------------------------------------

  async createRun(run: TestRun): Promise<void> {
    await this.client.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          PK: `${PK_PATTERNS.SUITE}${run.suiteId}`,
          SK: `${SK_PATTERNS.RUN}${run.startTime}`,
          ...run,
        },
      })
    );
  }

  async updateRun(
    run: Pick<TestRun, "suiteId" | "startTime"> &
      Partial<
        Pick<TestRun, "status" | "passed" | "failed" | "errors" | "endTime">
      >
  ): Promise<void> {
    const expressionParts: string[] = [];
    const names: Record<string, string> = {};
    const values: Record<string, unknown> = {};

    if (run.status !== undefined) {
      expressionParts.push("#s = :s");
      names["#s"] = "status";
      values[":s"] = run.status;
    }
    if (run.passed !== undefined) {
      expressionParts.push("passed = :p");
      values[":p"] = run.passed;
    }
    if (run.failed !== undefined) {
      expressionParts.push("failed = :f");
      values[":f"] = run.failed;
    }
    if (run.errors !== undefined) {
      expressionParts.push("errors = :e");
      values[":e"] = run.errors;
    }
    if (run.endTime !== undefined) {
      expressionParts.push("endTime = :et");
      values[":et"] = run.endTime;
    }

    if (expressionParts.length === 0) return;

    await this.client.send(
      new UpdateCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.SUITE}${run.suiteId}`,
          SK: `${SK_PATTERNS.RUN}${run.startTime}`,
        },
        UpdateExpression: `SET ${expressionParts.join(", ")}`,
        ...(Object.keys(names).length > 0 && {
          ExpressionAttributeNames: names,
        }),
        ExpressionAttributeValues: values,
      })
    );
  }

  async getRun(suiteId: string, startTime: string): Promise<TestRun | null> {
    const result = await this.client.send(
      new GetCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.SUITE}${suiteId}`,
          SK: `${SK_PATTERNS.RUN}${startTime}`,
        },
      })
    );
    if (!result.Item) return null;
    return this.stripKeys<TestRun>(result.Item);
  }

  async listRuns(suiteId: string): Promise<TestRun[]> {
    const result = await this.client.send(
      new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.SUITE}${suiteId}`,
          ":skPrefix": SK_PATTERNS.RUN,
        },
        ScanIndexForward: false, // newest first (descending by timestamp)
      })
    );
    return (result.Items || []).map((item) => this.stripKeys<TestRun>(item));
  }

  // -------------------------------------------------------------------------
  // Test Result operations
  // -------------------------------------------------------------------------

  async writeResult(result: TestCaseResult): Promise<void> {
    await this.client.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          PK: `${PK_PATTERNS.RUN}${result.runId}`,
          SK: `${SK_PATTERNS.CASE}${result.caseId}`,
          ...result,
        },
      })
    );
  }

  async getResult(
    runId: string,
    caseId: string
  ): Promise<TestCaseResult | null> {
    const result = await this.client.send(
      new GetCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.RUN}${runId}`,
          SK: `${SK_PATTERNS.CASE}${caseId}`,
        },
      })
    );
    if (!result.Item) return null;
    return this.stripKeys<TestCaseResult>(result.Item);
  }

  async listResults(runId: string): Promise<TestCaseResult[]> {
    const result = await this.client.send(
      new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.RUN}${runId}`,
          ":skPrefix": SK_PATTERNS.CASE,
        },
      })
    );
    return (result.Items || []).map(
      (item) => this.stripKeys<TestCaseResult>(item)
    );
  }

  // -------------------------------------------------------------------------
  // Transcript operations
  // -------------------------------------------------------------------------

  async writeTranscript(
    runId: string,
    caseId: string,
    turns: TranscriptTurn[]
  ): Promise<void> {
    // Write each turn as a separate item for efficient retrieval
    const writeRequests = turns.map((turn) => ({
      PutRequest: {
        Item: {
          PK: `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
          SK: `${SK_PATTERNS.TURN}${String(turn.turnNumber).padStart(4, "0")}`,
          ...turn,
        },
      },
    }));

    // BatchWriteItem supports max 25 items per request
    const batches = this.chunkArray(writeRequests, 25);
    for (const batch of batches) {
      await this.client.send(
        new BatchWriteCommand({
          RequestItems: {
            [this.tableName]: batch,
          },
        })
      );
    }
  }

  async getTranscript(
    runId: string,
    caseId: string
  ): Promise<TranscriptTurn[]> {
    const result = await this.client.send(
      new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
          ":skPrefix": SK_PATTERNS.TURN,
        },
        ScanIndexForward: true, // ascending by turn number
      })
    );
    return (result.Items || []).map(
      (item) => this.stripKeys<TranscriptTurn>(item)
    );
  }

  // -------------------------------------------------------------------------
  // Execution Trace operations (from ListSpans)
  // -------------------------------------------------------------------------

  /**
   * Persists the structured turn-by-turn execution trace for a case.
   * Stored as a single item (PK=RUN#{runId}#CASE#{caseId}, SK="TRACE").
   * Steps/toolSequence are serialized to JSON to keep the item compact and
   * avoid DynamoDB nested-attribute limits.
   *
   * Before serialization, applies a 350 KB truncation guard on each step's
   * `inferenceMetadata.systemInstructions` to prevent oversized items from
   * hitting DynamoDB's 400 KB item limit.
   */
  async writeExecutionTrace(
    runId: string,
    caseId: string,
    trace: ExecutionTrace
  ): Promise<void> {
    // Apply systemInstructions truncation guard before serialization.
    // If the truncation logic itself throws, we surface the error to the
    // caller and do NOT write the TRACE row.
    const guardedSteps = truncateSystemInstructions(
      trace.steps,
      runId,
      caseId
    );

    await this.client.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          PK: `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
          SK: SK_PATTERNS.TRACE,
          sessionId: trace.sessionId,
          aiAgentName: trace.aiAgentName,
          aiAgentType: trace.aiAgentType,
          toolSequence: trace.toolSequence,
          steps: JSON.stringify(guardedSteps),
          capturedAt: trace.capturedAt,
        },
      })
    );
  }

  /**
   * Retrieves the execution trace for a case, or null if none is stored.
   */
  async getExecutionTrace(
    runId: string,
    caseId: string
  ): Promise<ExecutionTrace | null> {
    const result = await this.client.send(
      new GetCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
          SK: SK_PATTERNS.TRACE,
        },
      })
    );
    if (!result.Item) return null;
    const item = this.stripKeys<Record<string, unknown>>(result.Item);
    const steps =
      typeof item.steps === "string" ? JSON.parse(item.steps) : item.steps ?? [];
    return {
      sessionId: (item.sessionId as string) ?? "",
      steps,
      toolSequence: (item.toolSequence as string[]) ?? [],
      aiAgentName: item.aiAgentName as string | undefined,
      aiAgentType: item.aiAgentType as string | undefined,
      capturedAt: (item.capturedAt as string) ?? "",
    };
  }

  // -------------------------------------------------------------------------
  // Agent Snapshot operations
  // -------------------------------------------------------------------------

  async writeSnapshot(runId: string, snapshot: AgentSnapshot): Promise<void> {
    await this.client.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          PK: `${PK_PATTERNS.RUN}${runId}`,
          SK: SK_PATTERNS.SNAPSHOT,
          ...snapshot,
        },
      })
    );
  }

  async getSnapshot(runId: string): Promise<AgentSnapshot | null> {
    const result = await this.client.send(
      new GetCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.RUN}${runId}`,
          SK: SK_PATTERNS.SNAPSHOT,
        },
      })
    );
    if (!result.Item) return null;
    return this.stripKeys<AgentSnapshot>(result.Item);
  }

  // -------------------------------------------------------------------------
  // Prompts_Store operations (Prompt Management feature)
  // -------------------------------------------------------------------------

  /**
   * Read the persisted override for a single `promptKey`. Returns `null`
   * when no override has ever been written (the registry's bundled
   * defaults apply at resolve time).
   *
   * The returned shape is the {@link PromptOverride} the resolver
   * consumes — sparse `text` / `modelKey` / `inferenceParameters` fields
   * are preserved verbatim so the resolver's default-fallback invariant
   * can fill missing fields individually.
   */
  async getPromptOverride(
    promptKey: PromptKey
  ): Promise<PromptOverride | null> {
    const result = await this.client.send(
      new GetCommand({
        TableName: this.tableName,
        Key: {
          PK: `${PK_PATTERNS.PROMPT}${promptKey}`,
          SK: SK_PATTERNS.OVERRIDE,
        },
      })
    );
    if (!result.Item) return null;
    return this.stripKeys<PromptOverride>(result.Item);
  }

  /**
   * Read every persisted override on the deployment, keyed by
   * `promptKey`. Returns an empty `Map` when no overrides exist. The
   * Prompts Lambda hands the result directly to the registry's
   * `resolvePrompt` resolver and to the runtime helper's per-warm cache.
   *
   * Implemented as a `Scan` filtered to the override sort key. The
   * dataset is bounded to thirteen entries (one per registered prompt)
   * even at saturation, so a `Scan` is the cheapest option here and
   * avoids the GSI maintenance a `Query`-friendly layout would require.
   * `Scan` will paginate if the table grows past 1 MiB of items, so
   * this loop walks `LastEvaluatedKey` defensively even though that
   * limit is far beyond the prompt-store's footprint.
   */
  async listPromptOverrides(): Promise<Map<PromptKey, PromptOverride>> {
    const overrides = new Map<PromptKey, PromptOverride>();
    let lastEvaluatedKey: Record<string, unknown> | undefined;
    do {
      const result = await this.client.send(
        new ScanCommand({
          TableName: this.tableName,
          FilterExpression: "begins_with(PK, :pkPrefix) AND SK = :sk",
          ExpressionAttributeValues: {
            ":pkPrefix": PK_PATTERNS.PROMPT,
            ":sk": SK_PATTERNS.OVERRIDE,
          },
          ExclusiveStartKey: lastEvaluatedKey,
        })
      );
      for (const item of result.Items ?? []) {
        const override = this.stripKeys<PromptOverride>(item);
        overrides.set(override.promptKey, override);
      }
      lastEvaluatedKey = result.LastEvaluatedKey;
    } while (lastEvaluatedKey);
    return overrides;
  }

  /**
   * Persist a prompt override transactionally with optimistic
   * concurrency. The write is a `TransactWriteItems` of:
   *
   *   1. `Put` of a `HISTORY#{paddedPriorVersion}` record snapshotting
   *      the prior override. Skipped when no prior override exists
   *      (`priorVersion === 0`) — the implicit default state is never
   *      persisted as a HISTORY row per the design's Data Models
   *      section.
   *   2. `Put` of the new `OVERRIDE` record carrying the sparse fields
   *      from `override`. The `ConditionExpression` asserts
   *      `attribute_not_exists(version) OR version = :priorVersion` so
   *      two concurrent edits cannot both succeed (R7.2 round-trip
   *      semantics).
   *
   * Eviction of the oldest history entry is intentionally NOT part of
   * this transaction — see {@link evictOldestHistoryEntry} for the
   * separate best-effort `DeleteItem` path.
   *
   * The caller MUST pass the `priorVersion` it observed when reading
   * the override; passing a stale value triggers the
   * `ConditionalCheckFailedException` path which surfaces as
   * {@link PromptOverrideVersionConflictError}. A `priorVersion` of `0`
   * means "no override has ever existed for this promptKey".
   */
  async putPromptOverride(
    override: PromptOverride,
    priorVersion: number,
    priorOverride: PromptOverride | null = null,
    changeKind: "edit" | "reset" = "edit"
  ): Promise<void> {
    const pk = `${PK_PATTERNS.PROMPT}${override.promptKey}`;
    const transactItems: NonNullable<
      ConstructorParameters<typeof TransactWriteCommand>[0]["TransactItems"]
    > = [];

    // Item 1: snapshot the prior override as a HISTORY row when one
    // exists. When `priorVersion === 0` there is no row to snapshot —
    // the implicit default state is never persisted as a HISTORY entry.
    if (priorVersion > 0 && priorOverride !== null) {
      const historyEntry: PromptHistoryEntry = {
        promptKey: priorOverride.promptKey,
        version: priorOverride.version,
        ...(priorOverride.text !== undefined && {
          text: priorOverride.text,
        }),
        ...(priorOverride.modelKey !== undefined && {
          modelKey: priorOverride.modelKey,
        }),
        ...(priorOverride.inferenceParameters !== undefined && {
          inferenceParameters: priorOverride.inferenceParameters,
        }),
        modifiedAt: priorOverride.lastModifiedAt,
        modifiedBy: priorOverride.lastModifiedBy,
        // Forward the email display hint from the prior override row
        // onto the history snapshot so the change-history table can
        // render the email of whoever made each historical edit.
        // Absent for snapshots whose prior override predates the
        // field — those rows fall back to the UUID-based display
        // path. Authoritative actor identity remains the
        // `modifiedBy` UUID.
        ...(priorOverride.lastModifiedByEmail !== undefined && {
          modifiedByEmail: priorOverride.lastModifiedByEmail,
        }),
        changeKind,
      };
      transactItems.push({
        Put: {
          TableName: this.tableName,
          Item: {
            PK: pk,
            SK: `${SK_PATTERNS.HISTORY}${this.padVersion(
              priorOverride.version
            )}`,
            ...historyEntry,
          },
        },
      });
    }

    // Item 2: conditional update of the OVERRIDE row. The condition
    // expression asserts the caller's view of `priorVersion` is still
    // current, so two concurrent writers cannot both observe the same
    // version and both succeed.
    transactItems.push({
      Put: {
        TableName: this.tableName,
        Item: {
          PK: pk,
          SK: SK_PATTERNS.OVERRIDE,
          ...override,
        },
        ConditionExpression:
          priorVersion === 0
            ? "attribute_not_exists(version)"
            : "version = :priorVersion",
        ...(priorVersion !== 0 && {
          ExpressionAttributeValues: { ":priorVersion": priorVersion },
        }),
      },
    });

    try {
      await this.client.send(
        new TransactWriteCommand({ TransactItems: transactItems })
      );
    } catch (err) {
      if (isConditionalCheckFailure(err)) {
        throw new PromptOverrideVersionConflictError(
          override.promptKey,
          priorVersion
        );
      }
      throw err;
    }
  }

  /**
   * Reset a prompt by transactionally snapshotting the prior edit AND
   * recording the reset itself as its own versioned event, then
   * deleting the OVERRIDE row. The reset is transactional for the
   * same reason `putPromptOverride` is: the history inserts and the
   * override delete must either all happen or none happen, so a crash
   * mid-reset cannot leave the prompt in a state where the override
   * is gone but the audit rows are missing.
   *
   * The transaction writes THREE items when a prior override exists:
   *
   *   1. **Prior-edit snapshot** at `SK=HISTORY#{paddedPriorVersion}`
   *      with `changeKind: "edit"`. This preserves the prior edit's
   *      audit trail. Earlier versions of this method coalesced the
   *      prior edit and the reset into a single HISTORY row labelled
   *      `changeKind: "reset"` at the prior edit's version number,
   *      which destroyed the edit's identity and produced a v=N row
   *      that subsequent post-reset edits could collide with (a
   *      post-reset first edit would otherwise land at v=1, replacing
   *      the freshly-written history). Splitting the rows preserves
   *      the audit trail and makes the version counter monotonic
   *      across the prompt's entire lifecycle.
   *
   *   2. **Reset event** at `SK=HISTORY#{paddedPriorVersion+1}` with
   *      `changeKind: "reset"`. This row records WHO did the reset
   *      and WHEN. It carries no `text`, no `modelKey`, no
   *      `inferenceParameters` — a reset returns the prompt to the
   *      bundled default, and the lack of sparse fields signals "use
   *      defaults" to any forensic reader.
   *
   *   3. **Conditional Delete** of the OVERRIDE row asserting
   *      `version = :priorVersion`. A concurrent edit between the
   *      handler's read and this call surfaces as
   *      {@link PromptOverrideVersionConflictError} via the
   *      `TransactionCanceledException` path.
   *
   * When no override exists (`priorOverride === null`) the call is a
   * no-op — there is nothing to snapshot, the prompt was already at
   * the bundled default so no reset event is meaningful either, and
   * there is no OVERRIDE row to delete. The handler returns 200 with
   * `version: 0` per R6.4 idempotence.
   *
   * Eviction of surplus history rows is intentionally NOT part of
   * this transaction — the post-reset count can exceed the cap by 2
   * (we just added two HISTORY rows), so the handler issues
   * {@link evictOldestHistoryEntry} after a successful reset to
   * drain any surplus.
   */
  async deletePromptOverride(
    promptKey: PromptKey,
    priorOverride: PromptOverride | null,
    resetEvent: {
      modifiedAt: string;
      modifiedBy: string;
      modifiedByEmail?: string;
    }
  ): Promise<void> {
    if (priorOverride === null) {
      // No-op reset: nothing to snapshot, nothing to delete. The
      // prompt was already at the bundled default; recording a
      // "reset" event with no prior state would not give a forensic
      // reader anything actionable.
      return;
    }

    const pk = `${PK_PATTERNS.PROMPT}${promptKey}`;

    // Item 1 — prior-edit snapshot. Captures exactly what the prior
    // OVERRIDE row carried so the audit trail's "what was replaced"
    // semantics are preserved across the reset boundary.
    const priorEditEntry: PromptHistoryEntry = {
      promptKey: priorOverride.promptKey,
      version: priorOverride.version,
      ...(priorOverride.text !== undefined && { text: priorOverride.text }),
      ...(priorOverride.modelKey !== undefined && {
        modelKey: priorOverride.modelKey,
      }),
      ...(priorOverride.inferenceParameters !== undefined && {
        inferenceParameters: priorOverride.inferenceParameters,
      }),
      modifiedAt: priorOverride.lastModifiedAt,
      modifiedBy: priorOverride.lastModifiedBy,
      // Forward the email display hint from the prior override row
      // onto the snapshot — same rationale as the edit path in
      // {@link putPromptOverride}.
      ...(priorOverride.lastModifiedByEmail !== undefined && {
        modifiedByEmail: priorOverride.lastModifiedByEmail,
      }),
      changeKind: "edit",
    };

    // Item 2 — reset event row. Carries the resetter's identity and a
    // fresh timestamp (NOT the prior override's timestamp) and is
    // intentionally sparse on body fields: a reset returns the prompt
    // to the bundled default, and a forensic reader spots the reset
    // by the absence of `text`/`modelKey`/`inferenceParameters` in
    // combination with `changeKind: "reset"`.
    const resetVersion = priorOverride.version + 1;
    const resetEntry: PromptHistoryEntry = {
      promptKey: priorOverride.promptKey,
      version: resetVersion,
      modifiedAt: resetEvent.modifiedAt,
      modifiedBy: resetEvent.modifiedBy,
      ...(resetEvent.modifiedByEmail !== undefined && {
        modifiedByEmail: resetEvent.modifiedByEmail,
      }),
      changeKind: "reset",
    };

    try {
      await this.client.send(
        new TransactWriteCommand({
          TransactItems: [
            {
              Put: {
                TableName: this.tableName,
                Item: {
                  PK: pk,
                  SK: `${SK_PATTERNS.HISTORY}${this.padVersion(
                    priorOverride.version
                  )}`,
                  ...priorEditEntry,
                },
              },
            },
            {
              Put: {
                TableName: this.tableName,
                Item: {
                  PK: pk,
                  SK: `${SK_PATTERNS.HISTORY}${this.padVersion(resetVersion)}`,
                  ...resetEntry,
                },
              },
            },
            {
              Delete: {
                TableName: this.tableName,
                Key: { PK: pk, SK: SK_PATTERNS.OVERRIDE },
                ConditionExpression: "version = :priorVersion",
                ExpressionAttributeValues: {
                  ":priorVersion": priorOverride.version,
                },
              },
            },
          ],
        })
      );
    } catch (err) {
      if (isConditionalCheckFailure(err)) {
        throw new PromptOverrideVersionConflictError(
          promptKey,
          priorOverride.version
        );
      }
      throw err;
    }
  }

  /**
   * Return the highest `version` across the prompt's persisted HISTORY
   * rows, or 0 when no history rows exist. Used by the Prompts handler
   * to compute the next version on a post-reset edit, where
   * `priorOverride === null` but the history may have rows up to v=N
   * (the reset event's row). The next edit must land at v=N+1, NOT
   * v=1, to avoid colliding with the reset event's HISTORY row left
   * behind by {@link deletePromptOverride}.
   *
   * Implementation: a `Query` against `PK=PROMPT#{promptKey}` filtered
   * to `begins_with(SK, "HISTORY#")` with `Limit: 1, ScanIndexForward:
   * false` returns the newest (highest-version) row in a single round
   * trip. The padded SK suffix's lex order matches numeric order so
   * the first row returned is the maximum.
   */
  async getLatestHistoryVersion(promptKey: PromptKey): Promise<number> {
    const result = await this.client.send(
      new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.PROMPT}${promptKey}`,
          ":skPrefix": SK_PATTERNS.HISTORY,
        },
        ScanIndexForward: false, // newest first
        Limit: 1,
      })
    );
    const items = result.Items ?? [];
    if (items.length === 0) return 0;
    const version = items[0].version;
    return typeof version === "number" ? version : 0;
  }

  /**
   * Return the persisted change history for a single prompt, sorted by
   * `version` descending so the most recent change appears first
   * (R7.3). Returns an empty array when the prompt has never been
   * overridden.
   *
   * The history sort-key suffix is zero-padded so DynamoDB's
   * lexicographic ordering matches numeric ordering up to ten billion
   * versions; we issue the `Query` with `ScanIndexForward: false` to
   * walk newest-first directly.
   */
  async listPromptHistory(
    promptKey: PromptKey
  ): Promise<PromptHistoryEntry[]> {
    const result = await this.client.send(
      new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.PROMPT}${promptKey}`,
          ":skPrefix": SK_PATTERNS.HISTORY,
        },
        ScanIndexForward: false, // newest first
      })
    );
    return (result.Items ?? []).map((item) =>
      this.stripKeys<PromptHistoryEntry>(item)
    );
  }

  /**
   * Best-effort eviction of surplus history entries for a prompt when
   * the post-write history count exceeds `maxEntries` per R7.2.
   * Intentionally a SEPARATE `DeleteItem` path (not part of the prior
   * transaction) so a transient DDB error here cannot roll back a
   * successful override write — at worst we accumulate a few extra
   * history entries, which the next eviction call picks up.
   *
   * Drains ALL surplus rows in one call rather than just one, because
   * a {@link deletePromptOverride} now adds two HISTORY rows in a
   * single transaction (the prior-edit snapshot AND the reset event)
   * so the cap can be exceeded by 2 in a single user action. We fetch
   * up to `maxEntries + 5` items so a typical surplus is drained in a
   * single round trip; if the cap was lowered drastically between
   * deploys the next eviction will pick up the residual.
   *
   * Failure is logged at warning level and swallowed: the caller's
   * 200 response stands and the user-visible state is unaffected.
   */
  async evictOldestHistoryEntry(
    promptKey: PromptKey,
    maxEntries: number
  ): Promise<void> {
    try {
      // Walk the oldest entries first by querying ascending; only
      // delete when we exceed the cap. The overshoot of `+5` covers
      // the worst typical case (a reset added 2 rows on top of the
      // cap, plus a small buffer for any legacy surplus left by a
      // previously-failed eviction).
      const result = await this.client.send(
        new QueryCommand({
          TableName: this.tableName,
          KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
          ExpressionAttributeValues: {
            ":pk": `${PK_PATTERNS.PROMPT}${promptKey}`,
            ":skPrefix": SK_PATTERNS.HISTORY,
          },
          ScanIndexForward: true, // oldest first
          Limit: maxEntries + 5,
        })
      );
      const items = result.Items ?? [];
      if (items.length <= maxEntries) {
        return; // under the cap — nothing to evict
      }
      // Delete every surplus entry in one pass. Iterating issues one
      // DeleteItem per surplus row; the call site is best-effort so a
      // mid-loop failure is acceptable and the next successful
      // eviction reclaims whatever residual remains.
      const surplus = items.slice(0, items.length - maxEntries);
      for (const item of surplus) {
        const sk = item.SK as string;
        await this.client.send(
          new DeleteCommand({
            TableName: this.tableName,
            Key: {
              PK: `${PK_PATTERNS.PROMPT}${promptKey}`,
              SK: sk,
            },
          })
        );
      }
    } catch (err) {
      console.warn(
        `[dynamodb] evictOldestHistoryEntry failed for promptKey="${promptKey}"; ` +
          `the next successful eviction will reclaim the surplus entry. ` +
          `Underlying error: ${
            err instanceof Error ? err.message : String(err)
          }`
      );
    }
  }

  // -------------------------------------------------------------------------
  // Private helpers
  // -------------------------------------------------------------------------

  /**
   * Remove DynamoDB key attributes (PK, SK, GSI keys) from an item,
   * returning only domain data.
   */
  private stripKeys<T>(item: Record<string, unknown>): T {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { PK, SK, GSI1PK, GSI1SK, GSI2PK, GSI2SK, ...rest } = item;
    return rest as unknown as T;
  }

  /**
   * Split an array into chunks of the specified size.
   */
  private chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * Zero-pad a version number to ten digits so the
   * `HISTORY#{paddedVersion}` sort key's lexicographic ordering matches
   * numeric ordering up to ten billion versions — far past anything
   * the platform will hit in practice. Per the design's Data Models
   * section.
   */
  private padVersion(version: number): string {
    return String(version).padStart(10, "0");
  }
}

// ---------------------------------------------------------------------------
// Prompts_Store typed errors
// ---------------------------------------------------------------------------

/**
 * Thrown by {@link DynamoDBService.putPromptOverride} and
 * {@link DynamoDBService.deletePromptOverride} when the optimistic
 * concurrency check fails — i.e. the override's persisted `version`
 * has moved on between the caller's read and the transactional write,
 * indicating a concurrent edit. The Prompts handler catches this and
 * surfaces a structured 409 / retry-friendly error to the client.
 */
export class PromptOverrideVersionConflictError extends Error {
  public readonly name = "PromptOverrideVersionConflictError";
  constructor(
    public readonly promptKey: string,
    public readonly observedPriorVersion: number
  ) {
    super(
      `Prompt override version conflict for promptKey="${promptKey}"; ` +
        `the persisted version moved past the caller's observed prior ` +
        `version=${observedPriorVersion}. Re-read the override and retry.`
    );
  }
}

/**
 * AWS SDK v3 surfaces `ConditionalCheckFailedException` either as the
 * top-level exception (single-item writes) or wrapped in a
 * `TransactionCanceledException` whose `CancellationReasons[]` carry
 * `ConditionalCheckFailed` codes (transactional writes). This helper
 * matches both shapes so the call sites can map either to the typed
 * {@link PromptOverrideVersionConflictError}.
 */
function isConditionalCheckFailure(err: unknown): boolean {
  if (!err || typeof err !== "object") return false;
  const candidate = err as {
    name?: string;
    CancellationReasons?: Array<{ Code?: string }>;
  };
  if (candidate.name === "ConditionalCheckFailedException") return true;
  if (candidate.name === "TransactionCanceledException") {
    const reasons = candidate.CancellationReasons ?? [];
    return reasons.some((r) => r?.Code === "ConditionalCheckFailed");
  }
  return false;
}

// ---------------------------------------------------------------------------
// Default singleton instance
// ---------------------------------------------------------------------------

export const dynamoDBService = new DynamoDBService();
