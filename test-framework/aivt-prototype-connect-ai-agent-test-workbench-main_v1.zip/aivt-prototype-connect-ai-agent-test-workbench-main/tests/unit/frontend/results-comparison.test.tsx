// @vitest-environment jsdom
/**
 * Component tests for the score-aware results and comparison rendering
 * delivered in tasks 20.4 and 20.5.
 *
 * Validates:
 *  - **Requirement 8.6** — When AgentCore Evaluate cannot produce a complete,
 *    mappable result for a case, the recorded `Evaluation_Error_State` is
 *    surfaced in the UI rather than swallowed by a fallback heuristic.
 *  - **Requirement 10.4** — A case in the error state SHALL render the recorded
 *    reason (or its short label) in place of the three numeric scores in the
 *    results view, so a reader sees *why* the scores are missing.
 *  - **Requirement 15.2** — The comparison view distinguishes per-metric
 *    `improved` / `regressed` / `unchanged` / `not-comparable` outcomes for
 *    each case present in both runs.
 *  - **Requirement 15.5** — A case missing scores in either run (e.g. an
 *    `Evaluation_Error_State` in one run) MUST be classified `not-comparable`
 *    and rendered as such, distinct from `unchanged`.
 *
 * The tests exercise the real `ResultsViewer` and `Comparison` page modules.
 * The only mocked seams are the `apiClient` (so the test does not hit the
 * network) and the two `react-router-dom` hooks the pages consume
 * (`useParams`, `useSearchParams`, used purely to inject the runId/suiteId
 * the pages would otherwise read from the URL). Every other module — the
 * `compareScores` helper, the StatusIndicator labels, the run-comparison
 * categoriser — runs as in production.
 */

import React from 'react';
import {
  describe,
  it,
  expect,
  beforeAll,
  beforeEach,
  afterEach,
  vi,
} from 'vitest';
import {
  render,
  screen,
  waitFor,
  cleanup,
  fireEvent,
} from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

import type {
  AgentSnapshot,
  ExecutionTrace,
  TestCaseResult,
  TestRun,
  TestSuite,
  TranscriptTurn,
} from '../../../src/shared/types';
import { CaseStatus, RunStatus } from '../../../src/shared/enums';

// ---------------------------------------------------------------------------
// Mock the apiClient seam BEFORE importing the page modules so the page modules
// pick up the mocked exports. `vi.mock` is hoisted above all imports, so the
// mock fns must be declared via `vi.hoisted` to be safely referenced from the
// factory.
// ---------------------------------------------------------------------------

const { apiGetMock, apiPostMock, apiPutMock, apiDeleteMock } = vi.hoisted(
  () => ({
    apiGetMock: vi.fn(),
    apiPostMock: vi.fn(),
    apiPutMock: vi.fn(),
    apiDeleteMock: vi.fn(),
  })
);

vi.mock('../../../src/frontend/src/api', () => {
  class MockApiClientError extends Error {
    public readonly status: number;
    public readonly retryable: boolean;
    constructor(status: number, message: string, retryable: boolean) {
      super(message);
      this.name = 'ApiClientError';
      this.status = status;
      this.retryable = retryable;
    }
  }
  class MockRuntimeConfigUnavailableError extends Error {
    constructor(message = 'Runtime configuration unavailable.') {
      super(message);
      this.name = 'RuntimeConfigUnavailableError';
    }
  }
  return {
    apiClient: {
      get: apiGetMock,
      post: apiPostMock,
      put: apiPutMock,
      delete: apiDeleteMock,
    },
    ApiClientError: MockApiClientError,
    RuntimeConfigUnavailableError: MockRuntimeConfigUnavailableError,
    loadConfig: vi.fn(),
    getConfig: vi.fn(),
    getConfigStatus: vi.fn(),
    subscribeToNotifications: vi.fn(() => () => {}),
    notifyError: vi.fn(),
  };
});

// ---------------------------------------------------------------------------
// Mock react-router-dom hooks. The frontend ships its own copy of
// react-router-dom under `src/frontend/node_modules`, which imports `react`
// from a *different* react copy than the one rendering the test tree (jsdom
// + the root node_modules React aliased by vitest.config.ts). Importing the
// real router hooks therefore produces "Invalid hook call" errors. Since
// these tests only need the hooks' return values (the runId from the URL,
// the suiteId search-param), substituting them with simple mocks keeps the
// test focused on the actual page-rendering behavior under test.
// ---------------------------------------------------------------------------

const { routerState } = vi.hoisted(() => ({
  routerState: {
    runId: '' as string,
    searchParams: new URLSearchParams(),
  },
}));

vi.mock('react-router-dom', () => ({
  useParams: () => ({ runId: routerState.runId }),
  useSearchParams: () => [
    routerState.searchParams,
    (next: URLSearchParams | Record<string, string>) => {
      routerState.searchParams =
        next instanceof URLSearchParams ? next : new URLSearchParams(next);
    },
  ],
}));

// Page modules are imported AFTER the vi.mock calls above so they receive the
// mocked apiClient and the stubbed react-router-dom hooks. ES module imports
// are hoisted to the top of the file, but vi.mock is hoisted above all imports
// (via the vitest plugin), so the mock factories are guaranteed to register
// before these imports execute.
import { ResultsViewer } from '../../../src/frontend/src/pages/ResultsViewer';
import { Comparison } from '../../../src/frontend/src/pages/Comparison';

// ---------------------------------------------------------------------------
// jsdom polyfills required by Cloudscape components
// ---------------------------------------------------------------------------

beforeAll(() => {
  const g = globalThis as unknown as {
    ResizeObserver?: unknown;
    IntersectionObserver?: unknown;
  };
  if (typeof g.ResizeObserver === 'undefined') {
    g.ResizeObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
    };
  }
  if (typeof g.IntersectionObserver === 'undefined') {
    g.IntersectionObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
      takeRecords(): unknown[] {
        return [];
      }
      readonly root = null;
      readonly rootMargin = '';
      readonly thresholds: ReadonlyArray<number> = [];
    };
  }
  if (typeof window.matchMedia !== 'function') {
    window.matchMedia = (query: string) =>
      ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => {},
        removeListener: () => {},
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => false,
      }) as MediaQueryList;
  }
});

beforeEach(() => {
  apiGetMock.mockReset();
  apiPostMock.mockReset();
  apiPutMock.mockReset();
  apiDeleteMock.mockReset();
  // Default post resolution — covers panels (failure analysis, comparison
  // summary) that fire a POST when their parent page mounts. Tests that
  // care about a specific POST stack `.mockResolvedValueOnce(...)` on top
  // of this default and the queued response wins.
  apiPostMock.mockResolvedValue({});
  routerState.runId = '';
  routerState.searchParams = new URLSearchParams();
});

afterEach(() => {
  cleanup();
});

// ---------------------------------------------------------------------------
// Fixture builders
// ---------------------------------------------------------------------------

function buildRun(overrides: Partial<TestRun> = {}): TestRun {
  return {
    suiteId: 'suite-1',
    runId: 'run-default',
    status: RunStatus.COMPLETED,
    totalCases: 2,
    passed: 1,
    failed: 0,
    errors: 1,
    concurrency: 9,
    startTime: '2025-01-01T00:00:00.000Z',
    endTime: '2025-01-01T00:05:00.000Z',
    sfnExecutionArn:
      'arn:aws:states:us-east-1:000000000000:execution:catp:run-default',
    ...overrides,
  };
}

function buildScoredResult(
  caseId: string,
  scores: { goal: number; helpfulness: number; toolAccuracy: number },
  overrides: Partial<TestCaseResult> = {}
): TestCaseResult {
  return {
    runId: 'run-default',
    caseId,
    status: CaseStatus.PASSED,
    toolsInvoked: ['verifyIdentity', 'lookupAccount'],
    turnCount: 4,
    latencyMs: 1234,
    goalSuccessScore: scores.goal,
    helpfulnessScore: scores.helpfulness,
    toolAccuracyScore: scores.toolAccuracy,
    ...overrides,
  };
}

function buildErrorResult(
  caseId: string,
  evaluationError: NonNullable<TestCaseResult['evaluationError']>,
  overrides: Partial<TestCaseResult> = {}
): TestCaseResult {
  return {
    runId: 'run-default',
    caseId,
    status: CaseStatus.ERROR,
    toolsInvoked: [],
    turnCount: 0,
    latencyMs: 0,
    evaluationError,
    // Note: goalSuccessScore / helpfulnessScore / toolAccuracyScore are
    // deliberately UNSET — the Evaluation_Error_State is the structural
    // signal that scores are unavailable (Req 10.3).
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// ResultsViewer — Reqs 8.6, 10.4
// ---------------------------------------------------------------------------

describe('ResultsViewer renders three scores or the error reason', () => {
  function renderResultsViewer(runId: string) {
    routerState.runId = runId;
    return render(<ResultsViewer />);
  }

  it(
    'renders the three numeric scores for a scored case and the recorded ' +
      'evaluationError reason for an error-state case',
    async () => {
      const runId = 'run-results-1';

      const scoredResult = buildScoredResult('case-pass', {
        goal: 0.91,
        helpfulness: 0.82,
        toolAccuracy: 0.73,
      });
      const errorResult = buildErrorResult('case-error', {
        code: 'MISSING_EVALUATOR',
        reason: 'AgentCore Evaluate did not return goalSuccess for this case.',
        missingEvaluators: ['goalSuccess'],
      });

      apiGetMock.mockImplementation(async (path: string) => {
        if (path === `/runs/${runId}`) {
          return {
            run: buildRun({ runId, totalCases: 2, passed: 1, errors: 1 }),
            progress: {
              totalCases: 2,
              completed: 2,
              passed: 1,
              failed: 0,
              errors: 1,
              accuracy: 0.5,
            },
            results: [scoredResult, errorResult],
          };
        }
        throw new Error(`Unexpected path: ${path}`);
      });

      renderResultsViewer(runId);

      // Wait for the run detail to load and the table to render the case ids.
      const scoredRowHeading = await screen.findByText('case-pass');
      expect(scoredRowHeading).toBeInTheDocument();
      expect(screen.getByText('case-error')).toBeInTheDocument();

      // ---------------------------------------------------------------------
      // Req 10.4 (positive case) — three numeric scores rendered for the
      // scored case. Each score column uses two-decimal formatting and the
      // values picked here are pairwise distinct so each `getByText` is
      // unambiguous.
      // ---------------------------------------------------------------------
      expect(screen.getByText('0.91')).toBeInTheDocument(); // goalSuccessScore
      expect(screen.getByText('0.82')).toBeInTheDocument(); // helpfulnessScore
      expect(screen.getByText('0.73')).toBeInTheDocument(); // toolAccuracyScore

      // ---------------------------------------------------------------------
      // Req 8.6 / 10.4 (error case) — the row surfaces the recorded error
      // reason via the short MISSING_EVALUATOR badge, which embeds the
      // omitted evaluator names. The full reason text is rendered in the
      // expandable section below the table; we expand the section and assert
      // the literal `evaluationError.reason` is shown.
      // ---------------------------------------------------------------------
      // Short label badge (caseId column) — replaces the previous "Fallback"
      // heuristic and is visible without expanding the row.
      expect(
        screen.getByText('Missing evaluator: goalSuccess')
      ).toBeInTheDocument();

      // The score columns for the error row render the placeholder "—"
      // rather than a numeric score, since `evaluationError` ⇒ scores unset.
      // The whole table contains exactly three "—" placeholders for the
      // error row's three score columns.
      const placeholders = screen.getAllByText('—');
      expect(placeholders.length).toBeGreaterThanOrEqual(3);

      // Expand the case-error transcript section to reveal the full reason
      // text recorded on `evaluationError.reason`.
      const expandableHeader = screen.getByRole('button', {
        name: /case-error — transcript/i,
      });
      fireEvent.click(expandableHeader);

      await waitFor(() => {
        expect(
          screen.getByText(
            'AgentCore Evaluate did not return goalSuccess for this case.'
          )
        ).toBeInTheDocument();
      });

      // The Alert header records the machine-readable code so a reader can
      // file the right kind of follow-up bug.
      expect(
        screen.getByText(/evaluation unavailable \(missing_evaluator\)/i)
      ).toBeInTheDocument();
    }
  );
});

// ---------------------------------------------------------------------------
// Comparison — Reqs 15.2, 15.4
// ---------------------------------------------------------------------------

describe('Comparison view distinguishes per-metric outcomes and shows summary counts', () => {
  function renderComparison(suiteId: string) {
    routerState.searchParams = new URLSearchParams({ suiteId });
    return render(<Comparison />);
  }

  function buildSuite(): TestSuite {
    return {
      tenantId: 'tenant-1',
      suiteId: 'suite-1',
      name: 'Banking Suite',
      description: 'Suite under test',
      agentId: 'agent-1',
      assistantId: 'assistant-1',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2025-01-01T00:00:00.000Z',
    };
  }

  it(
    'renders improved / regressed / unchanged / not-comparable per-metric ' +
      'outcomes and the suite-level summary counts when comparing two runs',
    async () => {
      const suite = buildSuite();

      const runA = buildRun({
        runId: 'run-A',
        startTime: '2025-01-01T00:00:00.000Z',
        endTime: '2025-01-01T00:05:00.000Z',
      });
      const runB = buildRun({
        runId: 'run-B',
        startTime: '2025-01-02T00:00:00.000Z',
        endTime: '2025-01-02T00:05:00.000Z',
      });

      // Case 1: present in both runs with three numeric scores in each →
      // exercises improved (goalSuccess), regressed (helpfulness), and
      // unchanged (toolAccuracy) classifications respectively.
      const caseOneA = buildScoredResult('case-1', {
        goal: 0.5,
        helpfulness: 0.9,
        toolAccuracy: 0.5,
      });
      const caseOneB = buildScoredResult('case-1', {
        goal: 0.8, // delta = +0.300 → improved
        helpfulness: 0.6, // delta = -0.300 → regressed
        toolAccuracy: 0.5, // delta =  0.000 → unchanged
      });

      // Case 2: scored in run A, error-state in run B → all three metric
      // deltas are `not-comparable` per Req 15.5.
      const caseTwoA = buildScoredResult('case-2', {
        goal: 0.7,
        helpfulness: 0.7,
        toolAccuracy: 0.7,
      });
      const caseTwoB = buildErrorResult('case-2', {
        code: 'INSUFFICIENT_TRACE',
        reason: 'Trace ended before any evaluator could run.',
      });

      apiGetMock.mockImplementation(async (path: string) => {
        if (path === '/suites') {
          return { suites: [suite] };
        }
        if (path.startsWith(`/suites/${suite.suiteId}/runs`)) {
          return { runs: [runA, runB] };
        }
        if (path === `/runs/${runA.runId}`) {
          return {
            run: runA,
            progress: {
              totalCases: 2,
              completed: 2,
              passed: 2,
              failed: 0,
              errors: 0,
              accuracy: 1,
            },
            results: [caseOneA, caseTwoA],
          };
        }
        if (path === `/runs/${runB.runId}`) {
          return {
            run: runB,
            progress: {
              totalCases: 2,
              completed: 2,
              passed: 1,
              failed: 0,
              errors: 1,
              accuracy: 0.5,
            },
            results: [caseOneB, caseTwoB],
          };
        }
        if (path.endsWith('/snapshot')) {
          // Force the snapshot fetch to resolve to a valid (empty) snapshot.
          // The component already tolerates rejection, but resolving keeps
          // the test focused on score-comparison rendering.
          const snapshot: AgentSnapshot = {
            tools: [],
            systemPrompt: '',
            modelId: 'm',
            capturedAt: '2025-01-01T00:00:00.000Z',
          };
          return { snapshot };
        }
        throw new Error(`Unexpected path: ${path}`);
      });

      const { container } = renderComparison(suite.suiteId);

      // The suite is preselected via the `?suiteId=` query param, which
      // triggers an automatic fetch of run history. Wait for the two runs to
      // appear in the run-history table.
      await screen.findByText(/Run History/i);
      await waitFor(() => {
        expect(apiGetMock).toHaveBeenCalledWith(
          expect.stringContaining(`/suites/${suite.suiteId}/runs`)
        );
      });

      // Wait for the run rows to render — they show their RFC-4122-style
      // truncated runIds in a code box and the formatted accuracy.
      await waitFor(() => {
        expect(
          screen.getByText(`${runA.runId.slice(0, 12)}...`)
        ).toBeInTheDocument();
        expect(
          screen.getByText(`${runB.runId.slice(0, 12)}...`)
        ).toBeInTheDocument();
      });

      // Select both runs by clicking their row checkboxes. Cloudscape's
      // selection-type=multi renders an `<input type="checkbox">` per row
      // (plus a header "select all" checkbox). Click the two row
      // checkboxes (skipping index 0 which is the header).
      const checkboxes = container.querySelectorAll(
        'input[type="checkbox"]'
      ) as NodeListOf<HTMLInputElement>;
      // Expect at least 3: one header + two row checkboxes. Cloudscape may
      // additionally render hidden / decorative checkboxes — we filter to
      // those that look interactive (not disabled, visible name).
      const rowCheckboxes = Array.from(checkboxes).filter(
        (cb) => !cb.disabled
      );
      expect(rowCheckboxes.length).toBeGreaterThanOrEqual(3);

      // Click the row checkboxes — index 0 is the header in Cloudscape.
      fireEvent.click(rowCheckboxes[1]);
      fireEvent.click(rowCheckboxes[2]);

      // Trigger the comparison.
      const compareButton = await screen.findByRole('button', {
        name: /compare selected runs/i,
      });
      await waitFor(() => {
        expect(compareButton).not.toBeDisabled();
      });
      fireEvent.click(compareButton);

      // Wait for both run detail fetches to land.
      await waitFor(() => {
        expect(apiGetMock).toHaveBeenCalledWith(`/runs/${runA.runId}`);
        expect(apiGetMock).toHaveBeenCalledWith(`/runs/${runB.runId}`);
      });

      // Switch to the Score Deltas tab so its content is rendered. Cloudscape
      // Tabs renders only the active panel.
      const scoreDeltasTab = await screen.findByRole('tab', {
        name: /score deltas/i,
      });
      fireEvent.click(scoreDeltasTab);

      // -------------------------------------------------------------------
      // Req 15.2 — all four classifications are visually distinguished.
      // The score-delta cells render `<StatusIndicator>` with a label and a
      // signed delta string, so each classification is distinct text.
      // -------------------------------------------------------------------
      await waitFor(() => {
        expect(screen.getByText('Improved (+0.300)')).toBeInTheDocument();
      });
      expect(screen.getByText('Regressed (-0.300)')).toBeInTheDocument();
      expect(screen.getByText('Unchanged (±0.000)')).toBeInTheDocument();
      // `not-comparable` is rendered as a "Not comparable" indicator next to
      // a "—" placeholder. Three metrics × case-2 ⇒ 3 occurrences in the
      // per-case table. The per-metric summary block adds 3 more (one per
      // metric), so we expect ≥ 3 occurrences total.
      const notComparableNodes = screen.getAllByText('Not comparable');
      expect(notComparableNodes.length).toBeGreaterThanOrEqual(3);

      // -------------------------------------------------------------------
      // Req 15.4 — per-metric suite-level summary counts. The summary block
      // shows one row per metric × four classification counts. With our
      // fixtures:
      //   goalSuccessScore   → improved=1, regressed=0, unchanged=0, notCmp=1
      //   helpfulnessScore   → improved=0, regressed=1, unchanged=0, notCmp=1
      //   toolAccuracyScore  → improved=0, regressed=0, unchanged=1, notCmp=1
      // -------------------------------------------------------------------
      // The "Improved: 1" label is unique to Goal Success.
      expect(screen.getByText('Improved: 1')).toBeInTheDocument();
      // The "Regressed: 1" label is unique to Helpfulness.
      expect(screen.getByText('Regressed: 1')).toBeInTheDocument();
      // The "Unchanged: 1" label is unique to Tool Accuracy.
      expect(screen.getByText('Unchanged: 1')).toBeInTheDocument();
      // "Not comparable: 1" appears once per metric (3 instances).
      expect(screen.getAllByText('Not comparable: 1').length).toBe(3);
      // "Improved: 0" appears under Helpfulness and Tool Accuracy (2).
      expect(screen.getAllByText('Improved: 0').length).toBe(2);

      // The metric labels themselves anchor the per-metric summary columns —
      // each must be present so a reader can attribute the counts above to
      // the right metric. They appear multiple times (table column header,
      // per-metric summary block); we just assert at least one of each is
      // visible to confirm the metric is labeled.
      expect(screen.getAllByText('Goal Success').length).toBeGreaterThan(0);
      expect(screen.getAllByText('Helpfulness').length).toBeGreaterThan(0);
      expect(screen.getAllByText('Tool Accuracy').length).toBeGreaterThan(0);
    }
  );
});

// ---------------------------------------------------------------------------
// ResultsViewer transcript — rich interleaved timeline
// ---------------------------------------------------------------------------
//
// Validates that the run-dashboard's per-row TranscriptView renders the
// same rich timeline the per-case detail page renders, instead of the
// previous plain `TranscriptTurn[]` view. Specifically: customer turn
// text, agent reasoning text from the execution trace's `inference`
// step, real `execute_tool` calls with their arguments, and the
// `synthetic_control_tool` explanatory parenthetical (RETURN_TO_CONTROL
// markers whose payload is not surfaced by ListSpans). The shared
// {@link TimelineTranscript} component is the single source of truth
// for these invariants — the test asserts the component is wired into
// the dashboard's expandable row, not the component's own rendering
// (covered by `tests/unit/frontend/CaseDetail.test.tsx`).

describe('ResultsViewer renders the rich interleaved transcript timeline', () => {
  function renderResultsViewer(runId: string) {
    routerState.runId = runId;
    return render(<ResultsViewer />);
  }

  it(
    'expands a case and surfaces customer turn text, tool name + arguments, ' +
      'inference reasoning, and the synthetic_control_tool parenthetical',
    async () => {
      const runId = 'run-rich-transcript';
      const failedCase = buildScoredResult('case-rich', {
        goal: 0.4,
        helpfulness: 0.3,
        toolAccuracy: 0.2,
      });
      // Override the default PASSED status from `buildScoredResult` so the
      // case is rendered in the FAILED bucket — the FailureAnalysis panel
      // would otherwise short-circuit out.
      failedCase.status = CaseStatus.FAILED;

      // Persisted transcript carries the customer's question and the
      // agent's reply. When a trace is present, the `agent` turn is
      // skipped by the dedup rule (the trace's `inference` step is the
      // richer version).
      const transcript: TranscriptTurn[] = [
        {
          turnNumber: 1,
          role: 'customer',
          text: 'Please escalate to a human.',
          timestamp: '2024-01-01T00:00:00.000Z',
          elapsedMs: 0,
        },
        {
          turnNumber: 2,
          role: 'agent',
          text: 'Looking up your account now.',
          timestamp: '2024-01-01T00:00:01.000Z',
          elapsedMs: 1000,
          toolSelected: 'lookupAccount',
        },
      ];

      // Execution trace carries the rich detail: an inference step
      // (agent reasoning), a real execute_tool step (lookupAccount with
      // observable args), and a synthetic_control_tool marker for the
      // Escalate handoff whose payload ListSpans did not surface.
      const executionTrace: ExecutionTrace = {
        sessionId: 'session-1',
        toolSequence: ['lookupAccount', 'Escalate'],
        capturedAt: '2024-01-01T00:00:05.000Z',
        steps: [
          {
            index: 0,
            type: 'inference',
            spanName: 'inference',
            timestamp: '2024-01-01T00:00:01.000Z',
            text: 'I will look up the account, then escalate.',
          },
          {
            index: 1,
            type: 'tool',
            spanName: 'execute_tool',
            timestamp: '2024-01-01T00:00:02.000Z',
            tool: {
              toolName: 'lookupAccount',
              arguments: { accountId: 'ACCT-12345' },
              result: { status: 'success', balance: 42 },
              success: true,
            },
          },
          {
            index: 2,
            type: 'tool',
            spanName: 'synthetic_control_tool',
            timestamp: '2024-01-01T00:00:03.000Z',
            tool: {
              toolName: 'Escalate',
              arguments: {},
              result: {},
              success: true,
            },
          },
        ],
      };

      apiGetMock.mockImplementation(async (path: string) => {
        if (path === `/runs/${runId}`) {
          return {
            run: buildRun({
              runId,
              totalCases: 1,
              passed: 0,
              failed: 1,
              errors: 0,
            }),
            progress: {
              totalCases: 1,
              completed: 1,
              passed: 0,
              failed: 1,
              errors: 0,
              accuracy: 0,
            },
            results: [failedCase],
          };
        }
        if (path === `/runs/${runId}/cases/${failedCase.caseId}`) {
          return {
            result: failedCase,
            transcript,
            executionTrace,
          };
        }
        throw new Error(`Unexpected path: ${path}`);
      });

      // The FailureAnalysis panel that mounts when a completed run has
      // failures fires `POST /runs/{runId}/analyze` on mount. Override
      // the file-level default `{}` with a structurally-valid empty
      // response so its `caseAnalyses.map(...)` does not throw.
      apiPostMock.mockResolvedValue({
        caseAnalyses: [],
        generatedAt: '2024-01-01T00:00:00.000Z',
        modelId: 'test-model',
      });

      renderResultsViewer(runId);

      // Wait for the case row to render in the table.
      await screen.findByText('case-rich');

      // Expand the transcript section. Cloudscape's ExpandableSection
      // renders the header as a button.
      const expandableHeader = screen.getByRole('button', {
        name: /case-rich — transcript/i,
      });
      fireEvent.click(expandableHeader);

      // The TranscriptView fetches `/runs/{runId}/cases/{caseId}` and
      // hands the response off to the shared TimelineTranscript
      // component. Wait for the customer turn text to appear, which
      // confirms the timeline rendered.
      await waitFor(() => {
        expect(
          screen.getByText('Please escalate to a human.'),
        ).toBeInTheDocument();
      });

      // The agent's reasoning text comes from the execution trace's
      // `inference` step, NOT the transcript's `role: "agent"` turn
      // (which is suppressed when a trace is present). The shared
      // component renders the inference text verbatim.
      expect(
        screen.getByText('I will look up the account, then escalate.'),
      ).toBeInTheDocument();

      // Real execute_tool step: tool name in the row label and
      // arguments rendered as a JSON block. The args block is a
      // line-wrapped <pre>, so we assert on the document HTML rather
      // than text-node matching.
      expect(screen.getByText(/Tool · lookupAccount/)).toBeInTheDocument();
      const html = document.body.innerHTML;
      expect(html).toMatch(/args\s+\{[\s\S]*"accountId"/);

      // Synthetic control-tool: the Escalate marker renders the
      // explanatory parenthetical instead of misleading `args {}` /
      // `result {}` blocks. The wording mirrors
      // `SYNTHETIC_CONTROL_TOOL_NOTE` in the judge prompt-rendering
      // layer so the user sees the same message in both surfaces.
      expect(screen.getByText(/Tool · Escalate/)).toBeInTheDocument();
      expect(
        screen.getByText(
          /RETURN_TO_CONTROL — call arguments and result not surfaced by ListSpans\./i,
        ),
      ).toBeInTheDocument();

      // The transcript's agent turn ("Looking up your account now.")
      // must NOT be rendered — the trace's inference step is the
      // richer version of the same content, and rendering both would
      // duplicate the agent's voice in the timeline.
      expect(
        screen.queryByText('Looking up your account now.'),
      ).not.toBeInTheDocument();
    },
  );
});
