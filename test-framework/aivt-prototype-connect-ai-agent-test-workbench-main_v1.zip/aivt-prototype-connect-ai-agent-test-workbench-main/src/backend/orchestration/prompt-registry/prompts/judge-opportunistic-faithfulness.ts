/**
 * `judge_opportunistic_faithfulness` — system prompt for the inline
 * Bedrock Converse call inside
 * `src/backend/orchestration/opportunistic-faithfulness.ts`. Unlike the
 * three AgentCore-template judges, the opportunistic faithfulness
 * scorer is platform-authored: it runs inline during a Stage-1 case
 * execution to score groundedness whenever the agent invokes the
 * Retrieve tool, on a fast 15-second budget.
 *
 * The default text mirrors `buildFaithfulnessPrompt` byte-for-byte, with
 * the dynamic `${passagesList}` and `${agentResponse}` interpolations
 * replaced by `{passages}` and `{agent_response}` placeholder tokens so
 * the platform's standard renderer can substitute at call time.
 *
 * @module backend/orchestration/prompt-registry/prompts/judge-opportunistic-faithfulness
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

const DEFAULT_TEXT = `You are an expert evaluator assessing whether an AI assistant's response is grounded in the provided reference passages.

## Retrieved Passages
{passages}

## Assistant's Response
{agent_response}

## Task
Score the faithfulness of the assistant's response on a scale from 0.0 to 1.0, where:
- 1.0 = every claim in the response is directly supported by the retrieved passages
- 0.0 = no claims in the response are supported by the retrieved passages

Respond with ONLY a JSON object: {"score": <number between 0.0 and 1.0>}`;

export const judgeOpportunisticFaithfulnessPrompt: PromptDefinition = {
  promptKey: "judge_opportunistic_faithfulness",
  name: "Judge — Opportunistic Faithfulness",
  description:
    "Inline platform-authored faithfulness judge invoked during Stage-1 case execution whenever the agent calls the Retrieve tool. Scores groundedness on [0.0, 1.0].",
  category: "evaluation",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [
    {
      name: "passages",
      description:
        "Numbered list of retrieved passages from the agent's Retrieve tool invocation.",
      maxOccurrences: 1,
    },
    {
      name: "agent_response",
      description:
        "The agent's terminal response text the judge is evaluating for groundedness.",
      maxOccurrences: 1,
    },
  ],
  // The closing line embeds a literal `{"score": ...}` JSON sample that
  // is NOT a placeholder. Declared here so the validation pipeline's
  // unknown-placeholder detector does not flag it as an edit.
  literalBraceRegions: [
    {
      start: 'Respond with ONLY a JSON object: {',
      end: "}",
    },
  ],
  inferenceParameters: {
    // Tiny output — only needs to emit `{"score": <number>}`.
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 50 },
  },
  defaultInferenceValues: {
    maxTokens: 50,
  },
};
