# Security & Required Permissions

This document is intended to be handed to a security team reviewing the Connect
Agent Test Platform before deployment. It enumerates **every AWS permission the
solution needs** and separates them into two distinct concerns:

1. **Deploy-time permissions** — what the human or CI principal running
   `cdk deploy` needs. These are broad provisioning permissions used once per
   deploy.
2. **Runtime permissions** — what the stack grants to its own Lambda execution
   roles and authenticated-user role. These are least-privilege, scoped to the
   resources the platform creates plus the specified Connect instance.

It also lists the **Amazon Connect / Q in Connect prerequisites** that must
already exist in the target account, and the **account-level guardrails** (SCPs,
permission boundaries) that can block an otherwise-correct deployment.

> Scope note: permissions are derived from the CDK source in `lib/`. Where a
> grant is created by a CDK L2 helper (e.g. `table.grantReadWriteData(fn)`), the
> expanded action list is summarized. The synthesized CloudFormation template is
> always the authoritative source — run `npx cdk synth` and inspect the
> `AWS::IAM::Policy` / `AWS::IAM::Role` resources to verify against this doc.

---

## 1. Deploy-time permissions (the CDK deployer)

The principal running `cdk deploy` provisions the entire stack. In a sandbox or
prototype account this is typically an Admin role. In a locked-down account, the
security team must grant the deployer the following service permissions. These
are **provisioning** permissions — they are used at deploy time only and are not
held by any runtime component.

### CDK bootstrap

CDK requires a one-time bootstrap (`cdk bootstrap`) which creates the CDK
toolkit stack (an S3 assets bucket, an ECR repo, and deploy/file-publishing
roles). Bootstrapping needs broad CloudFormation + IAM + S3 + ECR permissions.
If the account is already CDK-bootstrapped, the deployer instead needs
`sts:AssumeRole` on the CDK-created `cdk-*-deploy-role-*` /
`cdk-*-file-publishing-role-*` roles.

### Provisioning actions used by this stack

Each service below shows the provisioning actions used and why. Long action
lists are broken onto separate lines for readability.

**CloudFormation** — deploy/update the stack
- `cloudformation:CreateStack`, `UpdateStack`, `DeleteStack`
- `cloudformation:DescribeStacks`, `GetTemplate`
- `cloudformation:CreateChangeSet`, `ExecuteChangeSet`

**IAM** — create the Lambda execution roles, Step Functions roles, the Bedrock evaluation role, and the authenticated-user role
- `iam:CreateRole`, `DeleteRole`, `TagRole`
- `iam:AttachRolePolicy`, `PutRolePolicy`, `DeleteRolePolicy`
- `iam:CreatePolicy`, `PassRole`

**Lambda** — create the ~26 application Lambdas and the CDK custom-resource provider Lambdas
- `lambda:CreateFunction`, `UpdateFunctionCode`, `UpdateFunctionConfiguration`
- `lambda:DeleteFunction`, `AddPermission`
- `lambda:InvokeFunction` (custom resources)

**DynamoDB** — create the single-table store
- `dynamodb:CreateTable`, `UpdateTable`, `DeleteTable`
- `dynamodb:DescribeTable`, `TagResource`

**Step Functions** — create the test-run and experiment state machines
- `states:CreateStateMachine`, `UpdateStateMachine`, `DeleteStateMachine`
- `states:DescribeStateMachine`, `TagResource`

**S3** — frontend asset bucket, RAG eval bucket, CDK asset uploads
- `s3:CreateBucket`, `DeleteBucket`, `PutBucketPolicy`, `PutBucketPublicAccessBlock`
- `s3:PutObject`, `DeleteObject`

**CloudFront** — frontend distribution
- `cloudfront:CreateDistribution`, `UpdateDistribution`
- `cloudfront:CreateCloudFrontOriginAccessIdentity`, `CreateInvalidation`

**Cognito** — authentication
- `cognito-idp:CreateUserPool`, `CreateUserPoolClient`, `CreateUserPoolDomain`
- `cognito-identity:CreateIdentityPool`, `SetIdentityPoolRoles`

**API Gateway** — REST API + Cognito authorizer
- `apigateway:POST`, `PUT`, `GET`, `DELETE` on `/restapis*`

**CloudWatch Logs** — Lambda / state machine logging
- `logs:CreateLogGroup`, `PutRetentionPolicy`, `DeleteLogGroup`

**Secrets Manager** — machine-client secret for CI/CD callers
- `secretsmanager:CreateSecret`, `PutSecretValue`, `DeleteSecret`, `TagResource`

**SNS** — Cognito email delivery path (where applicable)
- `sns:CreateTopic`, `Subscribe`

> A managed policy such as `PowerUserAccess` plus the ability to create IAM roles
> covers all of the above. If the security team prefers a bespoke deploy policy,
> the table above is the action set to start from; validate with
> `cdk synth` + a dry-run `create-change-set` in the target account.

### Deploy-time API calls made by custom resources

Two custom resources call AWS APIs **at deploy time** using their own execution
roles (created by the stack, see §2), not the deployer's credentials. They are
listed here because their actions must also be permitted by any account-level
guardrail (see §4):

- **Assistant discovery** (`lib/assistant-discovery.ts`):
  `connect:ListIntegrationAssociations` (scoped to the Connect instance ARN) and
  `wisdom:GetAssistant` / `qconnect:GetAssistant`. Resolves the Q in Connect
  assistant associated with the specified Connect instance.
- **Admin user bootstrap** (`lib/admin-bootstrap-construct.ts`, only when
  `adminEmail` is supplied): `cognito-idp:AdminCreateUser`,
  `cognito-idp:AdminGetUser` (scoped to the created user pool).

---

## 2. Runtime permissions (provisioned by the stack)

The stack creates a dedicated, least-privilege execution role per Lambda. The
tables below list the **non-DynamoDB, non-logging** grants (every Lambda gets
CloudWatch Logs write and X-Ray via the standard execution role; DynamoDB access
is noted per role). All Q in Connect grants use **both** `wisdom:` and
`qconnect:` action prefixes because the service spans two ARN namespaces.

### Q in Connect — session & runtime (test execution)

Granted to the Conversation Driver and related orchestration Lambdas. Scoped to
the assistant and session ARNs of the discovered assistant.

| Action (`wisdom:` + `qconnect:`) | Purpose |
|---|---|
| `CreateSession` | Start a Q in Connect session per test case |
| `SendMessage` | Send customer turns to the agent |
| `GetNextMessage` | Poll for agent responses |
| `UpdateSessionData` | Inject pre-conversation session data (`$.Custom.*`, e.g. `customerPhoneNumber`) into the `Custom` namespace |
| `ListSpans` | Read the execution trace (tool sequence, reasoning) |

### Q in Connect — agent configuration (discovery, scoring, apply)

| Action (`wisdom:` + `qconnect:`) | Granted to | Purpose |
|---|---|---|
| `ListAIAgents` | Discovery, Suites, Cases | List agents on the instance |
| `GetAIAgent` | Discovery, Cases, Scaffold, Run trigger, Apply | Read agent config (tools, instructions, examples) |
| `GetAIPrompt` | Discovery, Run trigger, Apply | Read the system prompt body |
| `UpdateAIAgent` | Apply Recommendations / Experiments | **Write** — apply fixes to the live agent |
| `UpdateAIPrompt` | Apply Recommendations / Experiments | **Write** — apply prompt fixes |
| `CreateAIAgent` / `DeleteAIAgent` | Experiments | **Write** — temporary variant agents |

> **Write actions are omitted entirely when `instanceMode=production`.** In
> production mode the Lambda roles physically lack `UpdateAIAgent`,
> `UpdateAIPrompt`, `CreateAIAgent`, and `DeleteAIAgent` — see
> [operations.md → IAM model](operations.md#iam-model) and
> [operations.md → instance modes](operations.md#instance-modes).

### Amazon Connect — contact lifecycle (test execution)

Granted to the Conversation Driver. Scoped to the Connect instance ARN.

| Action | Purpose |
|---|---|
| `connect:StartChatContact` | Mint a real contact so the session has a bindable ContactARN (required by ORCHESTRATION agent MCP tools) |
| `connect:StopContact` | Tear down the minted contact after the case |
| `connect:DescribeContact` | Resolve contact metadata |

### Bedrock — judge scoring & AI generation

| Action | Granted to | Scope |
|---|---|---|
| `bedrock:InvokeModel` | All scoring/scaffold/analysis Lambdas | Inference-profile + foundation-model ARNs in `us-east-1`, `us-east-2`, `us-west-2` |
| `bedrock:Converse` | Bedrock-judge Lambdas | Same |
| `bedrock:InvokeModelWithResponseStream` | Conversation Driver (customer simulator) | Same |
| `bedrock:CreateEvaluationJob` / `GetEvaluationJob` | RAG evaluation Lambdas | RAG Knowledge Base evaluation |
| `iam:PassRole` | RAG submit Lambda | Pass the Bedrock evaluation role to `bedrock.amazonaws.com` (condition-scoped) |

The exact model set per Lambda is surfaced on the `…BedrockGrantSummary`
CloudFormation outputs so a reviewer can read it off without parsing IAM JSON.

### Step Functions

| Action | Granted to | Scope |
|---|---|---|
| `states:StartExecution`, `StopExecution` | Run trigger | The test-run state machine ARN |
| `states:StartExecution` | Experiment create | The experiment state machine ARN |
| `states:DescribeExecution` | Experiment get | Status reconciliation |

### DynamoDB

Single table. `grantReadWriteData` (expands to `GetItem`, `BatchGetItem`,
`Query`, `Scan`, `PutItem`, `UpdateItem`, `DeleteItem`, `BatchWriteItem`, plus
`DescribeTable`) for mutating handlers; `grantReadData` for read-only handlers
(`results`, `audit`, `experiment-get`). All access is tenant-scoped by partition
key (`PK=TENANT#{tenantId}`) — see
[operations.md → tenant isolation](operations.md#iam-model).

### Cognito (authenticated-user role)

The Cognito Identity Pool issues short-lived credentials to signed-in users. The
attached role grants `wisdom:`/`qconnect:` `CreateSession`, `SendMessage`,
`GetNextMessage` (scoped to assistant/session ARNs) and `bedrock:InvokeModel` /
`bedrock:Converse` (deploy-region foundation models). These are reserved for
future browser-side calls; today all calls go through API Gateway.

---

## 3. Amazon Connect / Q in Connect prerequisites

These must exist in the target account **before** deployment:

- An **Amazon Connect instance** (you supply its UUID via the
  `connectInstanceId` CDK context parameter).
- **Amazon Q in Connect enabled and associated** with that instance (a
  `WISDOM_ASSISTANT` integration association). The assistant-discovery custom
  resource resolves the assistant from this association and **fails the deploy**
  if none exists.
- **Bedrock model access** enabled for the judge/generation models in the
  deploy region(s). See [deployment.md](deployment.md) for the model list.

---

## 4. Account-level guardrails that can block deployment

Even with a correct deploy policy and correct stack-provisioned roles, the
following account controls can cause failures. Flag these to the security team:

- **Service Control Policies (SCPs).** An SCP that denies any action listed in
  §1 or §2 overrides the grant. Of particular note: the assistant-discovery
  custom resource needs `connect:ListIntegrationAssociations` — an SCP or
  boundary that allows `wisdom:*` but not the `connect:` action will fail the
  deploy at the custom-resource step.
- **Permission boundaries on Lambda execution roles.** Permission boundaries are
  an *intersection*: even though the stack attaches the grants in §2, the
  boundary must also allow them or the runtime call is denied. If your account
  enforces a boundary on all created roles, ensure it permits the Q in Connect,
  Connect, Bedrock, Step Functions, and DynamoDB actions above. CDK supports
  applying a boundary via `iam.PermissionsBoundary` if your account requires one.
- **`iam:PassRole` restrictions.** The RAG submit Lambda passes a role to
  `bedrock.amazonaws.com`. A `PassRole` condition restricting target services can
  block RAG evaluation.
- **Region restrictions.** Bedrock grants span `us-east-1`, `us-east-2`,
  `us-west-2` for inference-profile routing. An SCP restricting regions can deny
  cross-region model invocation.

---

## 5. How to verify against your account

```bash
# 1. Synthesize and inspect every IAM policy/role the stack will create
npx cdk synth -c connectInstanceId=YOUR-INSTANCE-UUID > /tmp/template.yaml
# Search the synthesized template for AWS::IAM::Policy and AWS::IAM::Role

# 2. Dry-run the deploy as a change set (no resources created) to surface
#    deploy-time permission gaps without mutating the account
npx cdk deploy --no-execute -c connectInstanceId=YOUR-INSTANCE-UUID

# 3. After deploy, confirm runtime roles resolved the correct assistant
#    (the AssistantId stack output should match the instance's associated assistant)
```

For instance-mode IAM behavior, the audit trail, and tenant isolation details,
see **[operations.md](operations.md)**.
