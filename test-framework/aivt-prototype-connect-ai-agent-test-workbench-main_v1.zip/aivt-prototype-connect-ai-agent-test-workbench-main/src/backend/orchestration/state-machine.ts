/**
 * Step Functions state machine definition for test run orchestration.
 *
 * Defines the CDK construct for the state machine:
 *   PrepareRun → ParallelTestCases (Map, maxConcurrency=9) → Choice{hasRagCases?}
 *     Choice -- yes (surviving RAG cases) → SubmitRagJob → Choice{submitted?}
 *       submitted -- SKIPPED → WriteResults
 *       submitted -- otherwise → Wait(30s) → CheckRagJobStatus → Choice{status}
 *         status -- InProgress → loop back to Wait
 *         status -- Completed/Failed/Stopped/Timeout → ReadRagResults → WriteResults
 *     Choice -- no → EvaluateResults → WriteResults
 *
 * Each map iteration: ConversationDriver → RecordTranscript → WriteCaseResult
 * Error handling: catch per-case errors, continue map iteration.
 *
 * @module state-machine
 */

import * as cdk from "aws-cdk-lib";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import * as tasks from "aws-cdk-lib/aws-stepfunctions-tasks";
import * as lambda from "aws-cdk-lib/aws-lambda";
import { Construct } from "constructs";
import { CONCURRENCY } from "../../shared/constants";

// ---------------------------------------------------------------------------
// Construct Props
// ---------------------------------------------------------------------------

export interface TestRunStateMachineProps {
  /** Lambda function that prepares the run (writes initial DDB record, snapshots agent config). */
  prepareRunFn: lambda.IFunction;
  /** Lambda function that drives a single test case conversation. */
  conversationDriverFn: lambda.IFunction;
  /** Lambda function that records the transcript to DDB. */
  recordTranscriptFn: lambda.IFunction;
  /** Lambda function that writes a single case result to DDB for progressive reads. */
  writeCaseResultFn: lambda.IFunction;
  /** Lambda function that evaluates all results via AgentCore. */
  evaluateResultsFn: lambda.IFunction;
  /** Lambda function that writes final scores and run summary to DDB. */
  writeResultsFn: lambda.IFunction;
  /**
   * Lambda that submits the Bedrock RAG evaluation job (Stage 2, step 1).
   * Loads cases, serializes JSONL, uploads to S3, calls the Bedrock
   * evaluation API. When provided (along with checkRagJobFn and
   * readRagResultsFn), the state machine adds a Wait/Choice poll loop
   * after the Map step for RAG runs.
   */
  submitRagJobFn?: lambda.IFunction;
  /**
   * Lambda that polls GetEvaluationJob status (Stage 2, step 2).
   * Called in a loop with a 30s Wait state until the job completes.
   */
  checkRagJobFn?: lambda.IFunction;
  /**
   * Lambda that reads per-prompt results from S3 and writes metrics to DDB
   * (Stage 2, step 3). Also handles the error path for failed/timed-out jobs.
   */
  readRagResultsFn?: lambda.IFunction;
}

// ---------------------------------------------------------------------------
// Construct
// ---------------------------------------------------------------------------

/**
 * CDK construct that creates a Step Functions state machine for test run orchestration.
 *
 * Flow:
 *   PrepareRun → ParallelTestCases (Map, maxConcurrency=9) → Choice{hasRagCases?}
 *     Choice -- yes → SubmitRagJob → Choice{submitted?}
 *       submitted -- SKIPPED → WriteResults
 *       submitted -- otherwise → Wait(30s) → CheckRagJobStatus → Choice{status}
 *         status -- InProgress → loop back to Wait
 *         status -- Completed/Failed/Stopped/Timeout → ReadRagResults → WriteResults
 *     Choice -- no → EvaluateResults → WriteResults
 *
 * Each map iteration:
 *   ConversationDriver → RecordTranscript → WriteCaseResult
 *
 * The ConversationDriver fetches the reasoning trace (ListSpans) inline and
 * RecordTranscript persists both the transcript and the structured execution
 * trace, so a separate trace-fetching step is no longer needed.
 *
 * Error isolation: An error in one test case marks that case as errored but does NOT
 * abort other cases. Each case catches its own errors and continues the map iteration.
 *
 * Two-Stage Pipeline: When the suite contains RAG cases and at least one survives
 * Stage 1 (i.e. completes with a captured response), the pipeline transitions to
 * Stage 2 which uses a Step Functions Wait/Choice poll loop (SubmitRagJob →
 * Wait → CheckRagJobStatus → Choice) to avoid Lambda timeout. The poll loop is
 * FREE (Wait states cost nothing). When no RAG cases survive, the pipeline skips
 * Stage 2 and proceeds to EvaluateResults (tool-sequence scoring) directly.
 */
export class TestRunStateMachine extends Construct {
  /** The Step Functions state machine. */
  public readonly stateMachine: sfn.StateMachine;

  constructor(scope: Construct, id: string, props: TestRunStateMachineProps) {
    super(scope, id);

    // -------------------------------------------------------------------
    // Step 1: PrepareRun
    // Writes initial run record to DDB, snapshots agent config.
    // Input: full execution input (suiteId, tenantId, concurrency, agentSnapshot, testCases)
    // Output: run metadata + testCases array passed through
    // -------------------------------------------------------------------
    const prepareRun = new tasks.LambdaInvoke(this, "PrepareRun", {
      lambdaFunction: props.prepareRunFn,
      outputPath: "$.Payload",
      retryOnServiceExceptions: true,
    });

    // -------------------------------------------------------------------
    // Per-case steps (inside Map iteration)
    // -------------------------------------------------------------------

    // ConversationDriver: runs the full multi-turn conversation for one test case
    const conversationDriver = new tasks.LambdaInvoke(
      this,
      "ConversationDriver",
      {
        lambdaFunction: props.conversationDriverFn,
        outputPath: "$.Payload",
        retryOnServiceExceptions: true,
      }
    );

    // RecordTranscript: writes conversation transcript to DDB
    const recordTranscript = new tasks.LambdaInvoke(
      this,
      "RecordTranscript",
      {
        lambdaFunction: props.recordTranscriptFn,
        outputPath: "$.Payload",
        retryOnServiceExceptions: true,
      }
    );

    // WriteCaseResult: writes the individual test case result to DDB immediately
    // so that the Results Lambda can serve partial results during execution
    const writeCaseResult = new tasks.LambdaInvoke(
      this,
      "WriteCaseResult",
      {
        lambdaFunction: props.writeCaseResultFn,
        outputPath: "$.Payload",
        retryOnServiceExceptions: true,
      }
    );

    // -------------------------------------------------------------------
    // Per-case error handling
    // On error: mark the case as errored, continue map iteration
    // -------------------------------------------------------------------
    const markCaseError = new sfn.Pass(this, "MarkCaseError", {
      parameters: {
        "caseId.$": "$.caseId",
        status: "error",
        "errorMessage.$": "$.error.Cause",
      },
    });

    // Chain the per-case steps:
    // ConversationDriver → RecordTranscript → WriteCaseResult
    // The ConversationDriver fetches the reasoning trace (ListSpans) inline and
    // RecordTranscript persists both the transcript and the execution trace, so
    // a separate FetchReasoningTrace step is no longer needed.
    const perCaseChain = conversationDriver
      .next(recordTranscript)
      .next(writeCaseResult);

    // Add catch to each step — if any step in the per-case chain fails,
    // we catch and mark the case as errored (continuing the map iteration)
    conversationDriver.addCatch(markCaseError, {
      errors: ["States.ALL"],
      resultPath: "$.error",
    });

    recordTranscript.addCatch(markCaseError, {
      errors: ["States.ALL"],
      resultPath: "$.error",
    });

    writeCaseResult.addCatch(markCaseError, {
      errors: ["States.ALL"],
      resultPath: "$.error",
    });

    // -------------------------------------------------------------------
    // Step 2: ParallelTestCases (Map state)
    // Iterates over each test case with maxConcurrency=9
    // -------------------------------------------------------------------
    const parallelTestCases = new sfn.Map(this, "ParallelTestCases", {
      maxConcurrency: CONCURRENCY,
      itemsPath: "$.testCases",
      itemSelector: {
        "caseId.$": "$$.Map.Item.Value.caseId",
        "testCase.$": "$$.Map.Item.Value",
        "runId.$": "$.runId",
        "suiteId.$": "$.suiteId",
        "startTime.$": "$.startTime",
        "agentId.$": "$.agentId",
        "assistantId.$": "$.assistantId",
      },
      resultPath: "$.caseResults",
    });

    parallelTestCases.itemProcessor(perCaseChain);

    // -------------------------------------------------------------------
    // Step 3: EvaluateResults
    // Submits tool-sequence transcripts to AgentCore for scoring.
    // Skips cases where caseType === "rag" — those are scored by Stage 2.
    // Uses resultPath to preserve the full state (caseResults, runId, etc.)
    // -------------------------------------------------------------------
    const evaluateResults = new tasks.LambdaInvoke(this, "EvaluateResults", {
      lambdaFunction: props.evaluateResultsFn,
      resultPath: "$.evaluationOutput",
      retryOnServiceExceptions: true,
    });

    // -------------------------------------------------------------------
    // Step 5: WriteResults
    // Writes final scores and run summary to DDB
    // -------------------------------------------------------------------
    const writeResults = new tasks.LambdaInvoke(this, "WriteResults", {
      lambdaFunction: props.writeResultsFn,
      outputPath: "$.Payload",
      retryOnServiceExceptions: true,
    });

    // -------------------------------------------------------------------
    // Conditional Stage 2 branch (RAG Evaluate — Wait/Choice poll loop)
    // When the three RAG Lambdas are provided, the state machine adds a
    // sub-workflow after the Map step:
    //   SubmitRagJob → Wait(30s) → CheckRagJobStatus → Choice{status}
    //     - InProgress → loop back to Wait
    //     - Completed → ReadRagResults → WriteResults
    //     - Failed/Stopped/Timeout → ReadRagResults (error path) → WriteResults
    //
    // This replaces the old single RAG_Evaluate Lambda that polled in-process
    // (burning 15 min of compute while waiting for the Bedrock job).
    // -------------------------------------------------------------------
    let definition: sfn.IChainable;

    if (props.submitRagJobFn && props.checkRagJobFn && props.readRagResultsFn) {
      // --- SubmitRagJob: loads cases, serializes JSONL, creates the job ---
      const submitRagJob = new tasks.LambdaInvoke(this, "SubmitRagJob", {
        lambdaFunction: props.submitRagJobFn,
        resultPath: "$.ragJobState",
        retryOnServiceExceptions: true,
      });

      // --- Wait state: 30s between polls (FREE — no compute cost) ---
      const waitForRagJob = new sfn.Wait(this, "WaitForRagJob", {
        time: sfn.WaitTime.duration(cdk.Duration.seconds(30)),
      });

      // --- CheckRagJobStatus: calls GetEvaluationJob, returns status ---
      // Uses resultPath to preserve the full state (including $.caseResults
      // needed by WriteResults). The Lambda receives the full state and
      // extracts jobArn from either the top level (subsequent polls from its
      // own pass-through output) or from $.ragJobState.Payload (first poll).
      const checkRagJobStatus = new tasks.LambdaInvoke(this, "CheckRagJobStatus", {
        lambdaFunction: props.checkRagJobFn,
        resultPath: "$.ragCheckResult",
        retryOnServiceExceptions: true,
      });

      // --- ReadRagResults: reads S3 output, writes metrics/errors to DDB ---
      const readRagResults = new tasks.LambdaInvoke(this, "ReadRagResults", {
        lambdaFunction: props.readRagResultsFn,
        resultPath: "$.ragEvaluationOutput",
        retryOnServiceExceptions: true,
      });

      // --- Choice state: route based on job status ---
      const ragJobComplete = new sfn.Choice(this, "RagJobComplete?");

      // Wire the poll loop:
      //   Wait → Check → Choice
      //     Choice: InProgress → back to Wait
      //     Choice: Completed → ReadRagResults
      //     Choice: otherwise (Failed/Stopped/Timeout) → ReadRagResults (error path)
      waitForRagJob.next(checkRagJobStatus);
      checkRagJobStatus.next(ragJobComplete);

      ragJobComplete
        .when(sfn.Condition.stringEquals("$.ragCheckResult.Payload.status", "Completed"), readRagResults)
        .when(sfn.Condition.stringEquals("$.ragCheckResult.Payload.status", "InProgress"), waitForRagJob)
        .otherwise(readRagResults); // error path handled inside ReadRagResults

      readRagResults.next(writeResults);

      // --- SubmitRagJob short-circuit: if status === "SKIPPED", go directly to WriteResults ---
      // The Choice after SubmitRagJob checks whether the job was actually submitted
      // or if it short-circuited (zero survivors / create failed).
      // Note: SubmitRagJob uses resultPath so its output is at $.ragJobState.Payload
      const submitRagJobRouting = new sfn.Choice(this, "RagJobSubmitted?");
      submitRagJobRouting
        .when(sfn.Condition.stringEquals("$.ragJobState.Payload.status", "SKIPPED"), writeResults)
        .otherwise(waitForRagJob);

      submitRagJob.next(submitRagJobRouting);

      // --- Top-level Choice: hasRagCases? ---
      const hasRagCasesChoice = new sfn.Choice(this, "HasSurvivingRagCases");

      evaluateResults.next(writeResults);

      // DEFENSIVE: IsPresent guard + boolean check (see comment above).
      hasRagCasesChoice
        .when(
          sfn.Condition.and(
            sfn.Condition.isPresent("$.hasRagCases"),
            sfn.Condition.booleanEquals("$.hasRagCases", true),
          ),
          submitRagJob,
        )
        .otherwise(evaluateResults);

      definition = prepareRun
        .next(parallelTestCases)
        .next(hasRagCasesChoice);
    } else {
      // Legacy linear flow (no RAG support)
      definition = prepareRun
        .next(parallelTestCases)
        .next(evaluateResults)
        .next(writeResults);
    }

    // -------------------------------------------------------------------
    // Create the state machine
    // -------------------------------------------------------------------
    this.stateMachine = new sfn.StateMachine(this, "TestRunStateMachine", {
      definitionBody: sfn.DefinitionBody.fromChainable(definition),
      timeout: cdk.Duration.hours(2),
      tracingEnabled: true,
      comment:
        "Orchestrates test run execution: PrepareRun → ParallelTestCases → Choice(RAG?) → [RAG_Evaluate | EvaluateResults] → WriteResults",
    });
  }
}
