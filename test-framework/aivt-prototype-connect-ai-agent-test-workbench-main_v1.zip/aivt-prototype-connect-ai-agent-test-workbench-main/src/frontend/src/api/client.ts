/**
 * API client with Cognito JWT token injection, 401/403 re-authentication,
 * 5xx error notification dispatch, and network timeout retry.
 *
 * Base URL resolution:
 * - Reads `apiEndpoint` from the validated runtime config loaded by
 *   {@link loadConfig} at startup.
 * - If the runtime config is not `ready`, requests are short-circuited with a
 *   `RuntimeConfigUnavailableError` so we never issue a request against an
 *   undefined endpoint (Requirement 5.4).
 */

import { getAccessToken, getStoredUserEmail, redirectToLogin } from '../auth';
import { getConfig } from './config';
import { notifyError } from './notifications';

export interface ApiError {
  status: number;
  message: string;
  retryable: boolean;
}

export class ApiClientError extends Error {
  public readonly status: number;
  public readonly retryable: boolean;
  /**
   * Structured error code lifted from the response body when the backend
   * returned a `{ error, code, details? }` payload. Undefined for network
   * errors and for backends that don't emit a structured `code` field.
   *
   * Typed as a generic `string` here so the base client stays
   * resource-agnostic; per-resource API wrappers (e.g.
   * `src/frontend/src/api/prompts.ts`) narrow the union and translate to
   * resource-specific typed error classes.
   */
  public readonly code?: string;
  /**
   * Structured details object lifted from the response body's `details`
   * field. The shape is per-error-code (e.g. `PROMPT_TEXT_TOO_LARGE`
   * carries `{ observedBytes, limitBytes }`); see the per-resource error
   * tables in the design docs.
   */
  public readonly details?: Record<string, unknown>;

  constructor(
    status: number,
    message: string,
    retryable: boolean,
    options?: {
      code?: string;
      details?: Record<string, unknown>;
    },
  ) {
    super(message);
    this.name = 'ApiClientError';
    this.status = status;
    this.retryable = retryable;
    if (options?.code !== undefined) {
      this.code = options.code;
    }
    if (options?.details !== undefined) {
      this.details = options.details;
    }
  }
}

/**
 * Thrown when the runtime configuration has not loaded successfully and the
 * caller attempted an API request. The application's runtime-config error
 * state should be displayed instead of issuing the request.
 */
export class RuntimeConfigUnavailableError extends Error {
  constructor(message = 'Runtime configuration is unavailable; cannot issue API requests.') {
    super(message);
    this.name = 'RuntimeConfigUnavailableError';
  }
}

/** Network timeout in milliseconds */
const NETWORK_TIMEOUT_MS = 30_000;

/** Max retries for network timeouts */
const MAX_NETWORK_RETRIES = 2;

/** Base delay for network timeout retry (ms) */
const RETRY_BASE_DELAY_MS = 1_000;

/**
 * Resolve the API base URL from the validated runtime config.
 *
 * Throws {@link RuntimeConfigUnavailableError} when the runtime config is not
 * `ready` so callers cannot accidentally issue requests with an undefined
 * `apiEndpoint` (Requirement 5.4). The application's error UI surfaces this
 * to the user; the request is never sent.
 */
function getBaseUrl(): string {
  const runtimeConfig = getConfig();
  if (!runtimeConfig?.apiEndpoint) {
    throw new RuntimeConfigUnavailableError();
  }
  // API Gateway emits stage URLs with a trailing slash (e.g.
  // `https://xxx.execute-api.us-east-1.amazonaws.com/prod/`). Callers always
  // pass paths with a leading slash (`/agents`, `/runs/{id}`), so we strip
  // any trailing slash here to avoid producing `/prod//agents`, which API
  // Gateway treats as a different (unmatched) route and which returns a
  // CORS-headerless error response in the browser.
  return runtimeConfig.apiEndpoint.replace(/\/+$/, '');
}

/**
 * Fetch with an AbortController timeout.
 * Throws a TypeError-like error on timeout so we can detect it.
 */
async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    return response;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Determine if an error is a network timeout or connectivity failure.
 */
function isNetworkError(err: unknown): boolean {
  if (err instanceof DOMException && err.name === 'AbortError') return true;
  if (err instanceof TypeError) return true; // fetch throws TypeError on network failure
  return false;
}

/**
 * Sleep for a given number of milliseconds.
 */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Make an authenticated API request.
 *
 * Behavior:
 * - Suppresses the request and throws {@link RuntimeConfigUnavailableError}
 *   if runtime config is not ready (Requirement 5.4).
 * - Injects the Cognito access token as a Bearer token.
 * - On 401 or 403, surfaces a "session expired, please sign in again"
 *   notification and redirects to the Cognito hosted UI (Requirements 5.5, 5.6).
 * - On 5xx, dispatches a flash notification.
 * - On network timeout, retries with exponential backoff.
 */
async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  // Resolve the base URL first. If runtime config isn't ready, fail fast
  // before we ever touch fetch — the caller's UI will render the runtime-
  // configuration-unavailable error state (Requirement 5.4).
  const baseUrl = getBaseUrl();

  const token = await getAccessToken();

  if (!token) {
    notifyError('Your session is no longer valid. Redirecting to sign in...', false);
    redirectToLogin();
    throw new ApiClientError(401, 'Not authenticated', false);
  }

  const url = `${baseUrl}${path}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
    ...(options.headers as Record<string, string> || {}),
  };

  // Display-hint header — propagates the signed-in user's email from
  // the ID token so the backend can persist a human-readable
  // `lastModifiedByEmail` alongside the existing `lastModifiedBy`
  // Cognito `sub` UUID. The email is NOT a security boundary; the
  // request is already authenticated by the access token in
  // `Authorization`, and the persisted `sub` claim remains
  // authoritative for "who made this edit". This header is purely a
  // UI display hint, and the backend ignores it for any
  // accountability-relevant decision.
  const email = getStoredUserEmail();
  if (email) {
    headers['X-User-Email'] = email;
  }

  const init: RequestInit = { ...options, headers };

  // Retry loop for network timeouts
  for (let attempt = 0; attempt <= MAX_NETWORK_RETRIES; attempt++) {
    try {
      const response = await fetchWithTimeout(url, init, NETWORK_TIMEOUT_MS);

      // Handle 401/403: token missing/expired/insufficient — show error and
      // redirect to the Cognito hosted UI to re-authenticate
      // (Requirements 5.5, 5.6).
      if (response.status === 401 || response.status === 403) {
        const reason =
          response.status === 401
            ? 'Your session has expired. Please sign in again.'
            : 'You are not authorized for this resource. Please sign in again.';
        notifyError(reason, false);
        redirectToLogin();
        throw new ApiClientError(
          response.status,
          reason,
          false,
        );
      }

      // Handle other errors
      if (!response.ok) {
        let errorMessage = `API error: ${response.status} ${response.statusText}`;
        let errorCode: string | undefined;
        let errorDetails: Record<string, unknown> | undefined;
        try {
          const errorBody = await response.json();
          // Platform error shape per the design docs:
          //   { error: string, code?: string, details?: object, message?: string }
          // `error` is the user-facing summary; `message` is a legacy
          // alias still used by some endpoints. Either takes precedence
          // over the default `<status> <statusText>` text.
          if (typeof errorBody?.error === 'string') {
            errorMessage = errorBody.error;
          } else if (typeof errorBody?.message === 'string') {
            errorMessage = errorBody.message;
          }
          if (typeof errorBody?.code === 'string') {
            errorCode = errorBody.code;
          }
          if (
            errorBody?.details !== undefined &&
            errorBody.details !== null &&
            typeof errorBody.details === 'object' &&
            !Array.isArray(errorBody.details)
          ) {
            errorDetails = errorBody.details as Record<string, unknown>;
          }
        } catch {
          // Use default error message
        }

        const retryable = response.status >= 500 || response.status === 429;

        // Dispatch global flash notification for 5xx errors
        if (response.status >= 500) {
          notifyError(errorMessage, retryable);
        }

        throw new ApiClientError(response.status, errorMessage, retryable, {
          code: errorCode,
          details: errorDetails,
        });
      }

      // Handle 204 No Content
      if (response.status === 204) {
        return undefined as T;
      }

      return response.json() as Promise<T>;
    } catch (err) {
      // If it's an ApiClientError (not a network error), rethrow immediately
      if (err instanceof ApiClientError) {
        throw err;
      }

      // Network timeout or connectivity failure — retry with backoff
      if (isNetworkError(err)) {
        if (attempt < MAX_NETWORK_RETRIES) {
          const delay = RETRY_BASE_DELAY_MS * Math.pow(2, attempt);
          notifyError(
            `Network timeout. Retrying in ${Math.round(delay / 1000)}s... (attempt ${attempt + 1}/${MAX_NETWORK_RETRIES})`,
            true
          );
          await sleep(delay);
          continue;
        }
      } else {
        throw err;
      }
    }
  }

  // All retries exhausted
  notifyError('Network request failed after retries. Please check your connection.', true);
  throw new ApiClientError(0, 'Network timeout after retries', true);
}

/**
 * API client methods organized by resource.
 */
export const apiClient = {
  get<T>(path: string): Promise<T> {
    return request<T>(path, { method: 'GET' });
  },

  post<T>(path: string, body?: unknown): Promise<T> {
    return request<T>(path, {
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined,
    });
  },

  put<T>(path: string, body?: unknown): Promise<T> {
    return request<T>(path, {
      method: 'PUT',
      body: body ? JSON.stringify(body) : undefined,
    });
  },

  delete<T>(path: string, body?: unknown): Promise<T> {
    return request<T>(path, {
      method: 'DELETE',
      body: body ? JSON.stringify(body) : undefined,
    });
  },
};
