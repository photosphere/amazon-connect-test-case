import { describe, it, expect, beforeEach } from "vitest";
import {
  handler,
  _setDDBClient,
  APIGatewayEvent,
} from "../../src/backend/handlers/audit";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../src/shared/constants";

// ---------------------------------------------------------------------------
// Mock DynamoDB client
// ---------------------------------------------------------------------------

function createMockClient(
  items: Record<string, unknown>[] = [],
  lastEvaluatedKey?: Record<string, unknown>,
) {
  const sendFn = async () => {
    return {
      Items: items,
      LastEvaluatedKey: lastEvaluatedKey,
    };
  };

  return { send: sendFn } as unknown as DynamoDBDocumentClient;
}

// ---------------------------------------------------------------------------
// Event helpers
// ---------------------------------------------------------------------------

function makeEvent(overrides: Partial<APIGatewayEvent> = {}): APIGatewayEvent {
  return {
    httpMethod: "GET",
    resource: "/audit",
    requestContext: {
      authorizer: {
        claims: { sub: "tenant-abc-123" },
      },
    },
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("audit handler", () => {
  beforeEach(() => {
    _setDDBClient(null);
  });

  describe("authentication", () => {
    it("returns 401 when no authorizer claims are present", async () => {
      _setDDBClient(createMockClient());
      const event = makeEvent({
        requestContext: {},
      });
      const response = await handler(event);
      expect(response.statusCode).toBe(401);
      expect(JSON.parse(response.body)).toEqual({
        error: "Unauthorized: missing tenant identity",
      });
    });

    it("returns 401 when claims are empty", async () => {
      _setDDBClient(createMockClient());
      const event = makeEvent({
        requestContext: { authorizer: { claims: {} } },
      });
      const response = await handler(event);
      expect(response.statusCode).toBe(401);
    });
  });

  describe("method validation", () => {
    it("returns 405 for non-GET methods", async () => {
      _setDDBClient(createMockClient());
      const event = makeEvent({ httpMethod: "POST" });
      const response = await handler(event);
      expect(response.statusCode).toBe(405);
      expect(JSON.parse(response.body)).toEqual({
        error: "Method not allowed",
      });
    });
  });

  describe("successful queries", () => {
    it("returns empty records array when no audit records exist", async () => {
      _setDDBClient(createMockClient([]));
      const event = makeEvent();
      const response = await handler(event);
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.records).toEqual([]);
      expect(body.nextToken).toBeUndefined();
    });

    it("returns audit records with DynamoDB keys stripped", async () => {
      const items = [
        {
          PK: `${PK_PATTERNS.TENANT}tenant-abc-123`,
          SK: `${SK_PATTERNS.AUDIT}2025-01-15T10:00:00Z`,
          tenantId: "tenant-abc-123",
          timestamp: "2025-01-15T10:00:00Z",
          runId: "run-1",
          agentId: "agent-1",
          source: "direct_apply",
          previousVersionId: "v1",
          newVersionId: "v2",
          recommendations: [],
        },
        {
          PK: `${PK_PATTERNS.TENANT}tenant-abc-123`,
          SK: `${SK_PATTERNS.AUDIT}2025-01-14T09:00:00Z`,
          tenantId: "tenant-abc-123",
          timestamp: "2025-01-14T09:00:00Z",
          runId: "run-2",
          agentId: "agent-1",
          source: "experiment_apply",
          experimentId: "exp-1",
          appliedVariant: "B",
          previousVersionId: "v2",
          newVersionId: "v3",
          recommendations: [],
        },
      ];
      _setDDBClient(createMockClient(items));
      const event = makeEvent();
      const response = await handler(event);
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.records).toHaveLength(2);
      // Keys should be stripped
      expect(body.records[0].PK).toBeUndefined();
      expect(body.records[0].SK).toBeUndefined();
      expect(body.records[0].tenantId).toBe("tenant-abc-123");
      expect(body.records[0].source).toBe("direct_apply");
      expect(body.records[1].source).toBe("experiment_apply");
      expect(body.records[1].appliedVariant).toBe("B");
    });

    it("returns nextToken when LastEvaluatedKey is present", async () => {
      const lastKey = {
        PK: `${PK_PATTERNS.TENANT}tenant-abc-123`,
        SK: `${SK_PATTERNS.AUDIT}2025-01-10T00:00:00Z`,
      };
      _setDDBClient(createMockClient([{ tenantId: "tenant-abc-123", timestamp: "2025-01-15T10:00:00Z", runId: "run-1", agentId: "agent-1", source: "direct_apply", previousVersionId: "v1", newVersionId: "v2", recommendations: [] }], lastKey));
      const event = makeEvent();
      const response = await handler(event);
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.nextToken).toBeDefined();
      // Decode the token and verify it matches the LastEvaluatedKey
      const decoded = JSON.parse(
        Buffer.from(body.nextToken, "base64").toString("utf-8"),
      );
      expect(decoded).toEqual(lastKey);
    });

    it("uses client_id claim when sub is not present", async () => {
      let capturedInput: Record<string, unknown> | undefined;
      const mockClient = {
        send: async (command: { input: Record<string, unknown> }) => {
          capturedInput = command.input;
          return { Items: [], LastEvaluatedKey: undefined };
        },
      } as unknown as DynamoDBDocumentClient;
      _setDDBClient(mockClient);

      const event = makeEvent({
        requestContext: {
          authorizer: {
            claims: { client_id: "machine-client-xyz" },
          },
        },
      });
      const response = await handler(event);
      expect(response.statusCode).toBe(200);
      expect(capturedInput?.ExpressionAttributeValues).toEqual({
        ":pk": `${PK_PATTERNS.TENANT}machine-client-xyz`,
        ":skPrefix": SK_PATTERNS.AUDIT,
      });
    });
  });

  describe("pagination", () => {
    it("passes decoded nextToken as ExclusiveStartKey", async () => {
      let capturedInput: Record<string, unknown> | undefined;
      const mockClient = {
        send: async (command: { input: Record<string, unknown> }) => {
          capturedInput = command.input;
          return { Items: [], LastEvaluatedKey: undefined };
        },
      } as unknown as DynamoDBDocumentClient;
      _setDDBClient(mockClient);

      const startKey = {
        PK: `${PK_PATTERNS.TENANT}tenant-abc-123`,
        SK: `${SK_PATTERNS.AUDIT}2025-01-10T00:00:00Z`,
      };
      const token = Buffer.from(JSON.stringify(startKey)).toString("base64");
      const event = makeEvent({
        queryStringParameters: { nextToken: token },
      });
      const response = await handler(event);
      expect(response.statusCode).toBe(200);
      expect(capturedInput?.ExclusiveStartKey).toEqual(startKey);
    });

    it("returns 400 for invalid nextToken", async () => {
      _setDDBClient(createMockClient());
      const event = makeEvent({
        queryStringParameters: { nextToken: "not-valid-base64!!!" },
      });
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
      expect(JSON.parse(response.body)).toEqual({
        error: "Invalid nextToken",
      });
    });
  });

  describe("DynamoDB query configuration", () => {
    it("queries with correct key condition and ScanIndexForward=false", async () => {
      let capturedInput: Record<string, unknown> | undefined;
      const mockClient = {
        send: async (command: { input: Record<string, unknown> }) => {
          capturedInput = command.input;
          return { Items: [], LastEvaluatedKey: undefined };
        },
      } as unknown as DynamoDBDocumentClient;
      _setDDBClient(mockClient);

      const event = makeEvent();
      await handler(event);

      expect(capturedInput?.KeyConditionExpression).toBe(
        "PK = :pk AND begins_with(SK, :skPrefix)",
      );
      expect(capturedInput?.ExpressionAttributeValues).toEqual({
        ":pk": `${PK_PATTERNS.TENANT}tenant-abc-123`,
        ":skPrefix": SK_PATTERNS.AUDIT,
      });
      expect(capturedInput?.ScanIndexForward).toBe(false);
      expect(capturedInput?.Limit).toBe(50);
    });
  });

  describe("error handling", () => {
    it("returns 500 when DynamoDB throws", async () => {
      const mockClient = {
        send: async () => {
          throw new Error("DynamoDB connection failed");
        },
      } as unknown as DynamoDBDocumentClient;
      _setDDBClient(mockClient);

      const event = makeEvent();
      const response = await handler(event);
      expect(response.statusCode).toBe(500);
      expect(JSON.parse(response.body)).toEqual({
        error: "Internal server error",
      });
    });
  });
});
