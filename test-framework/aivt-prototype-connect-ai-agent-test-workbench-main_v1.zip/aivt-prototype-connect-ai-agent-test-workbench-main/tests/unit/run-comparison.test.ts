import { describe, it, expect } from "vitest";
import { compareRuns } from "../../src/shared/utils/run-comparison";
import { CaseStatus } from "../../src/shared/enums";
import { TestCaseResult } from "../../src/shared/types";

function makeResult(
  caseId: string,
  status: CaseStatus,
  runId = "run-1"
): TestCaseResult {
  return {
    runId,
    caseId,
    status,
    toolsInvoked: [],
    turnCount: 3,
    latencyMs: 1000,
  };
}

describe("compareRuns", () => {
  it("returns empty result for two empty runs", () => {
    const result = compareRuns([], []);
    expect(result.entries).toHaveLength(0);
    expect(result.summary).toEqual({
      unchanged: 0,
      statusChanged: 0,
      added: 0,
      removed: 0,
    });
  });

  it("classifies cases present in both with same status as unchanged", () => {
    const runA = [makeResult("case-1", CaseStatus.PASSED)];
    const runB = [makeResult("case-1", CaseStatus.PASSED, "run-2")];

    const result = compareRuns(runA, runB);
    expect(result.entries).toHaveLength(1);
    expect(result.entries[0]).toEqual({
      caseId: "case-1",
      category: "unchanged",
      previousStatus: CaseStatus.PASSED,
      currentStatus: CaseStatus.PASSED,
    });
    expect(result.summary.unchanged).toBe(1);
  });

  it("classifies cases with different status as status-changed", () => {
    const runA = [makeResult("case-1", CaseStatus.PASSED)];
    const runB = [makeResult("case-1", CaseStatus.FAILED, "run-2")];

    const result = compareRuns(runA, runB);
    expect(result.entries).toHaveLength(1);
    expect(result.entries[0]).toEqual({
      caseId: "case-1",
      category: "status-changed",
      previousStatus: CaseStatus.PASSED,
      currentStatus: CaseStatus.FAILED,
    });
    expect(result.summary.statusChanged).toBe(1);
  });

  it("classifies cases only in runB as added", () => {
    const runA: TestCaseResult[] = [];
    const runB = [makeResult("case-new", CaseStatus.PASSED, "run-2")];

    const result = compareRuns(runA, runB);
    expect(result.entries).toHaveLength(1);
    expect(result.entries[0]).toEqual({
      caseId: "case-new",
      category: "added",
      currentStatus: CaseStatus.PASSED,
    });
    expect(result.summary.added).toBe(1);
  });

  it("classifies cases only in runA as removed", () => {
    const runA = [makeResult("case-old", CaseStatus.FAILED)];
    const runB: TestCaseResult[] = [];

    const result = compareRuns(runA, runB);
    expect(result.entries).toHaveLength(1);
    expect(result.entries[0]).toEqual({
      caseId: "case-old",
      category: "removed",
      previousStatus: CaseStatus.FAILED,
    });
    expect(result.summary.removed).toBe(1);
  });

  it("handles a mixed comparison with all categories", () => {
    const runA = [
      makeResult("case-1", CaseStatus.PASSED),
      makeResult("case-2", CaseStatus.FAILED),
      makeResult("case-3", CaseStatus.ERROR),
    ];
    const runB = [
      makeResult("case-1", CaseStatus.PASSED, "run-2"),
      makeResult("case-2", CaseStatus.PASSED, "run-2"),
      makeResult("case-4", CaseStatus.PASSED, "run-2"),
    ];

    const result = compareRuns(runA, runB);
    expect(result.summary).toEqual({
      unchanged: 1,
      statusChanged: 1,
      added: 1,
      removed: 1,
    });
  });

  it("summary counts sum to total entries", () => {
    const runA = [
      makeResult("a", CaseStatus.PASSED),
      makeResult("b", CaseStatus.FAILED),
    ];
    const runB = [
      makeResult("b", CaseStatus.PASSED, "run-2"),
      makeResult("c", CaseStatus.PASSED, "run-2"),
    ];

    const result = compareRuns(runA, runB);
    const { unchanged, statusChanged, added, removed } = result.summary;
    expect(unchanged + statusChanged + added + removed).toBe(
      result.entries.length
    );
  });
});
