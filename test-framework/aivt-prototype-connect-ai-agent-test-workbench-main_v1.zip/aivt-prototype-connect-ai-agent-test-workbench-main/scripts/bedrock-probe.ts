#!/usr/bin/env node
/**
 * Bedrock Conformance_Probe runner — validates that every entry in the
 * Supported_Models catalog exposes the exact Converse `inferenceConfig`
 * surface the platform's Model_Capability_Profile says it does, and
 * validates that the RAG Evaluation Job (`CreateEvaluationJob` →
 * `StopEvaluationJob`) round-trip works end-to-end.
 *
 * Architecture (mirrors the existing `scripts/bedrock-judge-probe.ts`):
 *   - parseArgs()             — read CLI flags (--dry-run, --models, --region, --report-path).
 *   - buildPositiveProbe(m)   — Converse with profile.acceptsTopLevel keys (default values),
 *                               maxTokens=32 (R18.8 cost cap), synthetic "ping" user message.
 *   - buildNegativeProbe(m)   — Converse with exactly ONE forbidden key set to its
 *                               profile-default value (Anthropic 4.x: temperature=0.5).
 *                               Asserts a 4xx response. A 200 dumps the request+response
 *                               and fails the build (R18.3 — the doc-lag sentinel).
 *   - buildRagJobProbe()      — CreateEvaluationJob → StopEvaluationJob.
 *   - isRegionReachable(m)    — skips models whose routing-regions are unreachable from the
 *                               current AWS region; emits a structured warning per R18.8.
 *   - runProbe(probe, client) — sends the command, times it, captures the outcome.
 *   - main()                  — iterates the catalog, collects results, writes the report,
 *                               exits with non-zero status if any probe failed.
 *
 * Run: `npm run probe:bedrock` (live)  or  `npm run probe:bedrock -- --dry-run` (mocked).
 *
 * Cost (live, default catalog, default model set): one positive + one negative probe per
 * model that has a non-empty `forbids[]`. The strict `anthropic_claude_4x` profile
 * (Claude Opus 4.8) runs both probes; the lax `anthropic_claude_4x_lax` profile
 * (Claude Sonnet 4.6 / Haiku 4.5) and the `amazon_nova` profile have empty `forbids[]`
 * so only the positive probe runs and the negative probe reports `skipped: true`.
 * Plus one RAG-job round-trip. Every Converse caps `maxTokens` at 32 → ~$0.01 total
 * per run.
 *
 * Exit code:
 *   - 0 — every non-skipped probe reported `ok: true`.
 *   - 1 — at least one non-skipped probe reported `ok: false` (4xx on positive, 2xx on
 *         negative, CreateEvaluationJob threw, etc.).
 *
 * @module scripts/bedrock-probe
 */

import { writeFile } from "node:fs/promises";

import {
  BedrockClient,
  CreateEvaluationJobCommand,
  StopEvaluationJobCommand,
} from "@aws-sdk/client-bedrock";
import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ConverseCommandInput,
} from "@aws-sdk/client-bedrock-runtime";

import {
  CAPABILITY_PROFILES,
  SUPPORTED_MODELS,
  type ModelKey,
  type SupportedModel,
} from "../src/backend/orchestration/prompt-registry";

// ---------------------------------------------------------------------------
// CLI args
// ---------------------------------------------------------------------------

/**
 * Parsed CLI arguments. {@link parseArgs} fills sensible defaults for any
 * flag the caller omits so `main` doesn't have to special-case missing
 * values.
 */
export interface ProbeArgs {
  /** When true, skip every `client.send` call and report success synthetically. */
  dryRun: boolean;
  /** Path the JSON report is written to. */
  reportPath: string;
  /** AWS region the probe runs against. */
  region: string;
  /** ModelKeys to probe; defaults to every key in SUPPORTED_MODELS. */
  models: readonly ModelKey[];
}

/**
 * Parse the script's CLI flags from the supplied argv (defaults to
 * `process.argv.slice(2)`). Recognised flags:
 *
 *   --dry-run                — boolean (default false)
 *   --report-path <path>     — string  (default "bedrock-probe-report.json")
 *   --region <region>        — string  (default $AWS_REGION or "us-east-1")
 *   --models <a,b,c>         — comma-separated ModelKey list (default: all six)
 *
 * Unknown ModelKeys in --models cause a synth-time throw so a typo cannot
 * silently skip a model.
 */
export function parseArgs(
  argv: readonly string[] = process.argv.slice(2),
): ProbeArgs {
  let dryRun = false;
  let reportPath = "bedrock-probe-report.json";
  let region = process.env.AWS_REGION ?? "us-east-1";
  let modelsArg: string | undefined;

  for (let i = 0; i < argv.length; i++) {
    const flag = argv[i];
    switch (flag) {
      case "--dry-run":
        dryRun = true;
        break;
      case "--report-path":
        reportPath = argv[++i] ?? reportPath;
        break;
      case "--region":
        region = argv[++i] ?? region;
        break;
      case "--models":
        modelsArg = argv[++i];
        break;
      default:
        if (flag.startsWith("--")) {
          throw new Error(`Unknown flag: ${flag}`);
        }
    }
  }

  const allModelKeys = Object.keys(SUPPORTED_MODELS) as ModelKey[];
  const models: readonly ModelKey[] = modelsArg
    ? modelsArg.split(",").map((m) => {
        const trimmed = m.trim();
        if (!Object.prototype.hasOwnProperty.call(SUPPORTED_MODELS, trimmed)) {
          throw new Error(
            `Unknown modelKey "${trimmed}" in --models; valid keys: ${allModelKeys.join(", ")}`,
          );
        }
        return trimmed as ModelKey;
      })
    : allModelKeys;

  return { dryRun, reportPath, region, models };
}

// ---------------------------------------------------------------------------
// Profile-default inference values
// ---------------------------------------------------------------------------

/**
 * Per-key default value the probe uses when populating the positive and
 * negative probes. The values are intentionally conservative and live
 * inside the profile's declared numeric range — the goal is "issue a
 * minimal Converse that the model accepts," not "find the optimum."
 *
 * `maxTokens` is capped at 32 by the R18.8 cost guardrail in
 * {@link buildPositiveProbe}; the value here is the per-key default the
 * negative probe uses when injecting a forbidden key.
 */
const PROFILE_DEFAULT_VALUES: Readonly<Record<string, unknown>> = {
  maxTokens: 32,
  temperature: 0.5,
  topP: 0.9,
  topK: 50,
  stopSequences: [],
};

// ---------------------------------------------------------------------------
// Probe builders
// ---------------------------------------------------------------------------

/**
 * Discriminator for the kind of probe a builder emits. Used so
 * {@link runProbe} can dispatch on the wire type without re-importing the
 * SDK command classes.
 */
export type ProbeKind = "positive" | "negative" | "ragJob";

/**
 * A built probe — the SDK command that will be sent (or skipped, in
 * dry-run mode) plus the metadata the runner uses to render the report.
 */
export interface BuiltProbe {
  kind: ProbeKind;
  /** ModelKey this probe targets; `null` for the RAG-job probe (model-implicit). */
  modelKey: ModelKey | null;
  /** The SDK command instance to send. */
  command: ConverseCommand | CreateEvaluationJobCommand;
  /** Free-form description used in logs and the report. */
  description: string;
  /**
   * For negative probes, the structured-error code we expect; mismatch
   * is the doc-lag sentinel signal. Undefined for positive and RAG-job.
   */
  expectedNegativeKey?: string;
}

/**
 * Build the **positive probe** for one model. The probe issues a Converse
 * with `inferenceConfig` populated from every key in the model's profile
 * `acceptsTopLevel` (using {@link PROFILE_DEFAULT_VALUES} for the
 * defaults), `maxTokens` overridden to 32 to honour R18.8's cost cap, and
 * a synthetic single-turn `"ping"` user message. Nova's `topK` (the only
 * `acceptsAdditional` key in the catalog) is placed under
 * `additionalModelRequestFields.inferenceConfig.topK` per R17.4.
 *
 * The runner asserts the response carries non-empty text — a 4xx or an
 * empty body counts as a failure.
 */
export function buildPositiveProbe(model: SupportedModel): BuiltProbe {
  const profile = CAPABILITY_PROFILES[model.capabilityProfileKey];

  const inferenceConfig: Record<string, unknown> = {};
  for (const key of profile.acceptsTopLevel) {
    inferenceConfig[key] = PROFILE_DEFAULT_VALUES[key];
  }
  // R18.8 cost cap: maxTokens always 32 regardless of profile default.
  inferenceConfig.maxTokens = 32;

  const additionalInferenceConfig: Record<string, unknown> = {};
  for (const key of profile.acceptsAdditional) {
    additionalInferenceConfig[key] = PROFILE_DEFAULT_VALUES[key];
  }

  const command = new ConverseCommand({
    modelId: model.inferenceProfileId,
    messages: [{ role: "user", content: [{ text: "ping" }] }],
    inferenceConfig: inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(Object.keys(additionalInferenceConfig).length > 0
      ? {
          additionalModelRequestFields: {
            inferenceConfig: additionalInferenceConfig,
          } as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  return {
    kind: "positive",
    modelKey: model.modelKey,
    command,
    description: `${model.modelKey}: positive Converse with ${profile.acceptsTopLevel.length} top-level + ${profile.acceptsAdditional.length} additional inference keys`,
  };
}

/**
 * Build the **negative probe** for one model. The probe issues a Converse
 * carrying exactly ONE key from the profile's `forbids[]` (set to its
 * profile-default value) on top of the positive probe's accepted keys,
 * and asserts the API returns a 4xx. A 200 indicates the model has
 * silently relaxed its forbid contract — the runner dumps the request
 * and response and fails the build per R18.3 (the doc-lag sentinel).
 *
 * Returns `null` for profiles with an empty `forbids[]` (e.g. `amazon_nova`):
 * there is no forbidden key to inject, so the negative probe is N/A and
 * the runner reports it as `skipped: true`.
 */
export function buildNegativeProbe(model: SupportedModel): BuiltProbe | null {
  const profile = CAPABILITY_PROFILES[model.capabilityProfileKey];
  if (profile.forbids.length === 0) {
    return null;
  }

  // Anthropic 4.x: try `temperature=0.5` per task spec. For any other
  // profile that grows a `forbids[]` later, pick the first forbidden key.
  const forbiddenKey = profile.forbids.includes("temperature")
    ? "temperature"
    : profile.forbids[0];
  const forbiddenValue = PROFILE_DEFAULT_VALUES[forbiddenKey];

  // Build inferenceConfig with the model's accepted keys + the forbidden
  // one. Sending only the forbidden key on its own would be ambiguous —
  // the API might reject for missing required arguments rather than for
  // the forbidden key. Including the accepted keys isolates the failure
  // signal to the forbidden field.
  const inferenceConfig: Record<string, unknown> = {};
  for (const key of profile.acceptsTopLevel) {
    inferenceConfig[key] = PROFILE_DEFAULT_VALUES[key];
  }
  inferenceConfig.maxTokens = 32;
  inferenceConfig[forbiddenKey] = forbiddenValue;

  const command = new ConverseCommand({
    modelId: model.inferenceProfileId,
    messages: [{ role: "user", content: [{ text: "ping" }] }],
    inferenceConfig: inferenceConfig as ConverseCommandInput["inferenceConfig"],
  });

  return {
    kind: "negative",
    modelKey: model.modelKey,
    command,
    description: `${model.modelKey}: negative Converse with forbidden key "${forbiddenKey}=${String(forbiddenValue)}" — expects 4xx`,
    expectedNegativeKey: forbiddenKey,
  };
}

/**
 * Build the **RAG-job probe**. Issues a `CreateEvaluationJob` with the
 * minimum-viable `RagEvaluation` config and the current `rag_evaluation_job`
 * prompt's resolved evaluator-model id. The runner follows it immediately
 * with a `StopEvaluationJob` per R18.2; a `Stop` failure on an
 * `IN_PROGRESS` job is logged with the `jobArn` and the job is allowed to
 * terminate naturally rather than blocking the probe run.
 *
 * Requires three environment variables to be set for the live probe:
 *   - `BEDROCK_EVAL_ROLE_ARN`     — IAM role bedrock assumes for the job.
 *   - `RAG_PROBE_BUCKET`          — S3 bucket holding a one-record probe input.
 *   - `RAG_PROBE_INPUT_S3_URI`    — full s3:// URI of that input.
 *
 * Returns `null` when any required env var is missing — the runner
 * reports the RAG-job probe as `skipped: true` with the reason captured
 * in the report so a misconfigured environment doesn't fail an otherwise
 * green probe run.
 */
export function buildRagJobProbe(): {
  probe: BuiltProbe;
  jobName: string;
} | null {
  const roleArn = process.env.BEDROCK_EVAL_ROLE_ARN;
  const bucket = process.env.RAG_PROBE_BUCKET;
  const inputS3Uri = process.env.RAG_PROBE_INPUT_S3_URI;
  if (!roleArn || !bucket || !inputS3Uri) {
    return null;
  }

  // The rag_evaluation_job prompt resolves to whichever model the
  // override store currently elects (or the bundled default). The probe
  // intentionally goes through the registry rather than hardcoding
  // claude_sonnet_4_6 so a deployment that has overridden the evaluator
  // model still validates the active one.
  const ragModel = SUPPORTED_MODELS.claude_sonnet_4_6;
  const jobName = `rag-probe-${Date.now()}`;
  const outputPath = `s3://${bucket}/probe-output/`;

  const command = new CreateEvaluationJobCommand({
    jobName,
    roleArn,
    applicationType: "RagEvaluation",
    evaluationConfig: {
      automated: {
        datasetMetricConfigs: [
          {
            taskType: "Custom",
            metricNames: [
              "Builtin.Faithfulness",
              "Builtin.Correctness",
              "Builtin.Completeness",
              "Builtin.Helpfulness",
            ],
            dataset: {
              name: `probe-input-${jobName}`,
              datasetLocation: { s3Uri: inputS3Uri },
            },
          },
        ],
        evaluatorModelConfig: {
          bedrockEvaluatorModels: [
            { modelIdentifier: ragModel.inferenceProfileId },
          ],
        },
      },
    },
    inferenceConfig: {
      ragConfigs: [
        {
          precomputedRagSourceConfig: {
            retrieveAndGenerateSourceConfig: {
              ragSourceIdentifier: "connect-orchestration-retrieve",
            },
          },
        },
      ],
    },
    outputDataConfig: { s3Uri: outputPath },
  });

  return {
    probe: {
      kind: "ragJob",
      modelKey: null,
      command,
      description: `RAG-job probe with evaluator modelIdentifier="${ragModel.inferenceProfileId}"`,
    },
    jobName,
  };
}

// ---------------------------------------------------------------------------
// Region reachability
// ---------------------------------------------------------------------------

/**
 * Return `true` when the executing AWS region is in the model's
 * `routingRegions[]`. Used to skip models that the current region cannot
 * reach (e.g. a model routed via a single in-region inference profile
 * when the runner executes from a different region). Emits a structured
 * warning log per R18.8 so the operator sees the skip in the build output.
 */
export function isRegionReachable(
  model: SupportedModel,
  executingRegion: string,
): boolean {
  const reachable = model.routingRegions.includes(executingRegion);
  if (!reachable) {
    console.warn(
      JSON.stringify({
        level: "warn",
        component: "bedrock-probe",
        event: "region_unreachable",
        modelKey: model.modelKey,
        executingRegion,
        routingRegions: model.routingRegions,
        message: `Skipping ${model.modelKey}: executing region "${executingRegion}" is not in the model's routingRegions[]`,
      }),
    );
  }
  return reachable;
}

// ---------------------------------------------------------------------------
// Probe runner
// ---------------------------------------------------------------------------

/** Outcome of a single probe — what the report carries. */
export interface ProbeOutcome {
  ok: boolean;
  elapsedMs: number;
  skipped: boolean;
  /** Why the probe was skipped (region unreachable, missing env, profile has no forbids, etc.). */
  reason?: string;
  /** Job ARN — RAG-job probe only. */
  jobArn?: string;
  /** Failure detail for non-skipped failures. */
  error?: string;
}

/**
 * Run one probe. In dry-run mode the command is built but never sent;
 * the outcome is `{ ok: true, elapsedMs: 0, skipped: false }`. In live
 * mode the command is sent through the supplied client; positive probes
 * succeed on a non-empty Converse response, negative probes succeed on a
 * 4xx, and the RAG-job probe succeeds on a non-empty `jobArn` (the
 * caller follows up with `StopEvaluationJob`).
 */
export async function runProbe(
  probe: BuiltProbe,
  options: {
    dryRun: boolean;
    runtimeClient: BedrockRuntimeClient;
    bedrockClient: BedrockClient;
  },
): Promise<ProbeOutcome> {
  if (options.dryRun) {
    return { ok: true, elapsedMs: 0, skipped: false };
  }

  const startedAt = Date.now();

  if (probe.kind === "ragJob") {
    try {
      const response = (await options.bedrockClient.send(
        probe.command as CreateEvaluationJobCommand,
      )) as { jobArn?: string };
      const elapsedMs = Date.now() - startedAt;
      const jobArn = response.jobArn ?? "";
      if (!jobArn) {
        return {
          ok: false,
          elapsedMs,
          skipped: false,
          error: "CreateEvaluationJob returned no jobArn",
        };
      }
      return { ok: true, elapsedMs, skipped: false, jobArn };
    } catch (err) {
      return {
        ok: false,
        elapsedMs: Date.now() - startedAt,
        skipped: false,
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }

  // Converse probes (positive + negative).
  try {
    const response = (await options.runtimeClient.send(
      probe.command as ConverseCommand,
    )) as {
      output?: { message?: { content?: Array<{ text?: string }> } };
    };
    const elapsedMs = Date.now() - startedAt;

    if (probe.kind === "positive") {
      const text =
        response.output?.message?.content
          ?.map((b) => b.text ?? "")
          .join("") ?? "";
      if (text.length === 0) {
        return {
          ok: false,
          elapsedMs,
          skipped: false,
          error: "Positive probe returned an empty Converse response",
        };
      }
      return { ok: true, elapsedMs, skipped: false };
    }

    // Negative probe — a 200 here is the doc-lag sentinel signal (R18.3).
    // Dump the request and response so the build log carries the forensic
    // trail and fail the run.
    console.error(
      JSON.stringify({
        level: "error",
        component: "bedrock-probe",
        event: "negative_probe_unexpectedly_passed",
        modelKey: probe.modelKey,
        forbiddenKey: probe.expectedNegativeKey,
        request: (probe.command as ConverseCommand).input,
        response,
        message:
          "Negative probe returned 200 — the model silently re-accepted the forbidden key. Update the Model_Capability_Profile and re-run.",
      }),
    );
    return {
      ok: false,
      elapsedMs,
      skipped: false,
      error: `Negative probe unexpectedly passed (forbidden key "${probe.expectedNegativeKey}" was accepted)`,
    };
  } catch (err) {
    const elapsedMs = Date.now() - startedAt;
    if (probe.kind === "negative") {
      // 4xx is the success case for the negative probe.
      const message = err instanceof Error ? err.message : String(err);
      return { ok: true, elapsedMs, skipped: false, error: message };
    }
    return {
      ok: false,
      elapsedMs,
      skipped: false,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

// ---------------------------------------------------------------------------
// Report writer
// ---------------------------------------------------------------------------

/** The aggregate report shape written to `--report-path`. */
export interface ProbeReport {
  probedAt: string;
  executingRegion: string;
  dryRun: boolean;
  results: Record<
    string,
    {
      positive: ProbeOutcome;
      negative: ProbeOutcome;
    }
  >;
  ragJobProbe: ProbeOutcome;
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

/**
 * Iterate the catalog, run each probe, write the report, and exit
 * non-zero on any failure. Tests import the named helpers above; only
 * `node scripts/bedrock-probe.ts` reaches `main`.
 */
export async function main(args: ProbeArgs = parseArgs()): Promise<number> {
  const runtimeClient = new BedrockRuntimeClient({ region: args.region });
  const bedrockClient = new BedrockClient({ region: args.region });

  const results: ProbeReport["results"] = {};
  let anyFailure = false;

  for (const modelKey of args.models) {
    const model = SUPPORTED_MODELS[modelKey];

    // Region reachability gate (R18.8).
    if (!isRegionReachable(model, args.region)) {
      results[modelKey] = {
        positive: {
          ok: true,
          elapsedMs: 0,
          skipped: true,
          reason: `executing region ${args.region} not in routingRegions [${model.routingRegions.join(", ")}]`,
        },
        negative: {
          ok: true,
          elapsedMs: 0,
          skipped: true,
          reason: `executing region ${args.region} not in routingRegions [${model.routingRegions.join(", ")}]`,
        },
      };
      continue;
    }

    // Positive probe.
    const positiveProbe = buildPositiveProbe(model);
    console.info(`[bedrock-probe] ${positiveProbe.description}`);
    const positive = await runProbe(positiveProbe, {
      dryRun: args.dryRun,
      runtimeClient,
      bedrockClient,
    });
    if (!positive.ok && !positive.skipped) {
      anyFailure = true;
    }

    // Negative probe (skipped when forbids is empty — e.g. amazon_nova).
    const negativeProbe = buildNegativeProbe(model);
    let negative: ProbeOutcome;
    if (negativeProbe === null) {
      negative = {
        ok: true,
        elapsedMs: 0,
        skipped: true,
        reason: `${model.capabilityProfileKey} forbids[] is empty — no negative probe to run`,
      };
    } else {
      console.info(`[bedrock-probe] ${negativeProbe.description}`);
      negative = await runProbe(negativeProbe, {
        dryRun: args.dryRun,
        runtimeClient,
        bedrockClient,
      });
      if (!negative.ok && !negative.skipped) {
        anyFailure = true;
      }
    }

    results[modelKey] = { positive, negative };
  }

  // RAG-job probe.
  const ragBuilt = buildRagJobProbe();
  let ragJobProbe: ProbeOutcome;
  if (ragBuilt === null) {
    ragJobProbe = {
      ok: true,
      elapsedMs: 0,
      skipped: true,
      reason:
        "BEDROCK_EVAL_ROLE_ARN, RAG_PROBE_BUCKET, or RAG_PROBE_INPUT_S3_URI not set — skipping RAG-job probe",
    };
    console.warn(
      JSON.stringify({
        level: "warn",
        component: "bedrock-probe",
        event: "rag_job_skipped",
        message: ragJobProbe.reason,
      }),
    );
  } else {
    console.info(`[bedrock-probe] ${ragBuilt.probe.description}`);
    ragJobProbe = await runProbe(ragBuilt.probe, {
      dryRun: args.dryRun,
      runtimeClient,
      bedrockClient,
    });
    if (!ragJobProbe.ok && !ragJobProbe.skipped) {
      anyFailure = true;
    }

    // Best-effort StopEvaluationJob if the create succeeded (live only).
    if (!args.dryRun && ragJobProbe.ok && ragJobProbe.jobArn) {
      try {
        await bedrockClient.send(
          new StopEvaluationJobCommand({ jobIdentifier: ragJobProbe.jobArn }),
        );
        console.info(
          `[bedrock-probe] StopEvaluationJob ok jobArn=${ragJobProbe.jobArn}`,
        );
      } catch (stopErr) {
        // R18.2: if the job is IN_PROGRESS and Stop rejects, log the jobArn
        // and let the job terminate naturally — do not fail the probe run
        // on this. The worst case is a few minutes of wasted compute.
        console.warn(
          JSON.stringify({
            level: "warn",
            component: "bedrock-probe",
            event: "stop_evaluation_job_failed",
            jobArn: ragJobProbe.jobArn,
            message:
              stopErr instanceof Error ? stopErr.message : String(stopErr),
          }),
        );
      }
    }
  }

  const report: ProbeReport = {
    probedAt: new Date().toISOString(),
    executingRegion: args.region,
    dryRun: args.dryRun,
    results,
    ragJobProbe,
  };

  await writeFile(args.reportPath, JSON.stringify(report, null, 2));
  console.info(`[bedrock-probe] Wrote report to ${args.reportPath}`);

  return anyFailure ? 1 : 0;
}

// Only auto-run when invoked as a script. Vitest imports the module to
// exercise the builders; we don't want main() to fire during unit tests.
const invokedDirectly =
  typeof process !== "undefined" &&
  process.argv[1] !== undefined &&
  /bedrock-probe\.[cm]?[jt]s$/.test(process.argv[1]);

if (invokedDirectly) {
  main()
    .then((code) => process.exit(code))
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
