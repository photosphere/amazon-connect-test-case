/**
 * Property 2: Reset idempotence.
 *
 * For any non-empty sequence of `PUT` and `reset` operations against a
 * single `promptKey`, ending in a `reset`, applying one additional
 * `reset` MUST leave the state unchanged: `effectiveText`,
 * `currentModelKey`, `inferenceParameters`, `version: 0`, and
 * `isOverridden: false` are byte-for-byte equal across the
 * post-final-reset and post-extra-reset captures, and both equal the
 * registry's bundled defaults for the prompt.
 *
 * Equivalently: the reset operation is a fixed point of the
 * Prompts_Store. Once a prompt has been reset, the store is in the
 * "no override exists" state and a second reset is a no-op all the way
 * down — no history row is appended (priorOverride is null), no
 * conditional check is evaluated, and no version is bumped. The
 * resolver's behaviour against an empty override map is deterministic
 * and pure, so the resolved `(text, modelKey, inferenceParameters,
 * version)` tuple is unchanged.
 *
 * The persistence layer under test is the {@link DynamoDBService}'s
 * Prompts_Store CRUD methods (Task 5.1), specifically the interplay
 * between `putPromptOverride`, `deletePromptOverride`, and
 * `getPromptOverride` across a sequenced operation log. The real DDB
 * document client is replaced with the same in-memory mock the
 * round-trip test (`tests/properties/prompts-override-roundtrip.property.test.ts`)
 * uses, duplicated here per the task brief — keeping it co-located with
 * the test means a future change to one test's mock cannot silently
 * break the other.
 *
 * The post-reset state is captured two ways: (a) `getPromptOverride`
 * returns `null`, confirming the OVERRIDE row is gone; (b)
 * `resolvePrompt` against an empty override map returns the prompt's
 * bundled defaults with `version: 0`. Both readings are taken before
 * and after the extra reset so a divergence in either path surfaces as
 * a counter-example.
 *
 * The "ending in a reset" pre-condition is enforced at the generator
 * boundary: if fast-check happens to draw a sequence whose last op is
 * a `PUT`, a single `reset` is appended. This keeps the pre-condition
 * cheap to enforce and lets the shrinker walk freely over the rest of
 * the sequence — the per-iteration op count budget is 20 inclusive of
 * the appended reset, so the in-memory mock never has to materialise
 * unbounded history.
 *
 * Generators are the shared `promptKeyArb`, `validTextArb`, and
 * `validInferenceParametersArb` from `tests/properties/generators.ts`
 * so the valid-input distribution stays consistent with the other
 * property tests in the wave.
 *
 * **Validates: Requirements 6.4, 15.2**
 */

import fc from "fast-check";
import { describe, expect, it } from "vitest";
import type { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

import {
  PROMPT_REGISTRY,
  resolvePrompt,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";
import type {
  PromptDefinition,
  PromptKey,
  PromptOverride,
} from "../../src/backend/orchestration/prompt-registry";
import {
  createDynamoDBService,
  type DynamoDBService,
} from "../../src/backend/services/dynamodb";

import {
  promptKeyArb,
  validInferenceParametersArb,
  validTextArb,
} from "./generators";

const TABLE_NAME = "PropertyTestTable";

// ---------------------------------------------------------------------------
// In-memory DynamoDB document client mock.
//
// Duplicated from `prompts-override-roundtrip.property.test.ts` per the
// task brief. The shape and semantics are identical: a
// `Map<string, Record<string, unknown>>` keyed by the composite
// `PK#SK` string, supporting `TransactWriteCommand`, `GetCommand`, and
// `ScanCommand` with the exact two `ConditionExpression` shapes the
// service emits. Anything else throws so a divergence between the
// service and the mock surfaces as a test failure here rather than as
// a silent pass.
//
// Returning a fresh client per-iteration keeps the property pure: no
// state leaks between iterations, no fast-check shrinker artefact can
// accidentally re-use a stale row.
// ---------------------------------------------------------------------------

interface PutAction {
  TableName?: string;
  Item: Record<string, unknown>;
  ConditionExpression?: string;
  ExpressionAttributeValues?: Record<string, unknown>;
}

interface DeleteAction {
  TableName?: string;
  Key: { PK: string; SK: string };
  ConditionExpression?: string;
  ExpressionAttributeValues?: Record<string, unknown>;
}

interface TransactItem {
  Put?: PutAction;
  Delete?: DeleteAction;
}

function conditionalCheckFailed(): Error {
  // Mirrors the shape `putPromptOverride` / `deletePromptOverride`
  // catch — wrapped `TransactionCanceledException` with a per-item
  // `CancellationReasons[].Code === "ConditionalCheckFailed"`.
  const err = Object.assign(new Error("Transaction cancelled"), {
    name: "TransactionCanceledException",
    CancellationReasons: [{ Code: "ConditionalCheckFailed" }],
  });
  return err;
}

function evaluatePutCondition(
  store: Map<string, Record<string, unknown>>,
  put: PutAction,
): void {
  const condition = put.ConditionExpression;
  if (!condition) return;
  const key = `${put.Item.PK}#${put.Item.SK}`;
  const existing = store.get(key);
  if (condition === "attribute_not_exists(version)") {
    if (existing && existing.version !== undefined) {
      throw conditionalCheckFailed();
    }
    return;
  }
  if (condition === "version = :priorVersion") {
    const priorVersion = put.ExpressionAttributeValues?.[":priorVersion"];
    if (!existing || existing.version !== priorVersion) {
      throw conditionalCheckFailed();
    }
    return;
  }
  throw new Error(
    `In-memory mock does not understand ConditionExpression: ${condition}`,
  );
}

function evaluateDeleteCondition(
  store: Map<string, Record<string, unknown>>,
  del: DeleteAction,
): void {
  const condition = del.ConditionExpression;
  if (!condition) return;
  const key = `${del.Key.PK}#${del.Key.SK}`;
  const existing = store.get(key);
  if (condition === "version = :priorVersion") {
    const priorVersion = del.ExpressionAttributeValues?.[":priorVersion"];
    if (!existing || existing.version !== priorVersion) {
      throw conditionalCheckFailed();
    }
    return;
  }
  throw new Error(
    `In-memory mock does not understand ConditionExpression: ${condition}`,
  );
}

function makeInMemoryDocClient(): DynamoDBDocumentClient {
  const store = new Map<string, Record<string, unknown>>();

  const send = async (cmd: unknown): Promise<unknown> => {
    const name = (cmd as object).constructor.name;
    const input = (cmd as { input: Record<string, unknown> }).input;

    if (name === "TransactWriteCommand") {
      const items = (input.TransactItems ?? []) as TransactItem[];
      // Two-phase apply: validate every condition first, only mutate
      // once every condition holds. Mirrors DDB's all-or-nothing
      // transactional semantics — a failed condition on the second
      // item must not leave the first item written.
      for (const item of items) {
        if (item.Put) evaluatePutCondition(store, item.Put);
        if (item.Delete) evaluateDeleteCondition(store, item.Delete);
      }
      for (const item of items) {
        if (item.Put) {
          const k = `${item.Put.Item.PK}#${item.Put.Item.SK}`;
          // Shallow-clone on write so callers cannot mutate the stored
          // row by holding a reference to the input Item.
          store.set(k, { ...item.Put.Item });
        }
        if (item.Delete) {
          const k = `${item.Delete.Key.PK}#${item.Delete.Key.SK}`;
          store.delete(k);
        }
      }
      return {};
    }

    if (name === "GetCommand") {
      const key = input.Key as { PK: string; SK: string };
      const item = store.get(`${key.PK}#${key.SK}`);
      // Shallow-clone on read so the service's `stripKeys` cannot
      // mutate the underlying stored row.
      return item ? { Item: { ...item } } : {};
    }

    if (name === "ScanCommand") {
      const filter = input.FilterExpression as string | undefined;
      const eav = (input.ExpressionAttributeValues ?? {}) as Record<
        string,
        unknown
      >;
      const matches: Array<Record<string, unknown>> = [];
      for (const row of store.values()) {
        if (filter === "begins_with(PK, :pkPrefix) AND SK = :sk") {
          if (
            typeof row.PK === "string" &&
            row.PK.startsWith(String(eav[":pkPrefix"])) &&
            row.SK === eav[":sk"]
          ) {
            matches.push({ ...row });
          }
        } else if (!filter) {
          matches.push({ ...row });
        } else {
          throw new Error(
            `In-memory mock does not understand FilterExpression: ${filter}`,
          );
        }
      }
      return { Items: matches };
    }

    throw new Error(
      `In-memory mock received unexpected command: ${name}. ` +
        `Extend the mock to handle it explicitly.`,
    );
  };

  return { send } as unknown as DynamoDBDocumentClient;
}

// ---------------------------------------------------------------------------
// Operation interpreter
// ---------------------------------------------------------------------------

/**
 * One operation in a generated reset-idempotence sequence. `PUT`
 * carries a generated `(text, modelKey, inferenceParameters)` triple
 * valid for the prompt; `RESET` simply names the prompt to clear.
 *
 * The discriminator is `kind` so a `switch` (or in our case an `if`
 * tower in {@link applyOp}) can narrow exhaustively without runtime
 * `in`-checks.
 */
type Operation =
  | {
      kind: "put";
      promptKey: PromptKey;
      text: string;
      modelKey: NonNullable<PromptOverride["modelKey"]>;
      inferenceParameters: Readonly<Record<string, unknown>>;
    }
  | { kind: "reset"; promptKey: PromptKey };

/**
 * Apply a single generated {@link Operation} against the live service,
 * tracking the version monotonicity that `putPromptOverride`'s
 * conditional check requires. The interpreter reads the current
 * override row before each op so the `priorVersion` it passes is the
 * one DDB will see — a stale read would trip the optimistic-concurrency
 * check and surface as a noisy test failure rather than a property
 * counter-example, so we always read fresh.
 *
 * `seq` is a per-test counter used to vary the `lastModifiedAt` ISO
 * timestamps so the auditor field is plausibly distinct across ops in
 * the same iteration. The field is irrelevant to the property under
 * test — both pre- and post-extra-reset captures observe `null`
 * overrides — but a synthetic distinct value reduces the chance of a
 * future test accidentally relying on equality across two ops with the
 * same timestamp.
 */
async function applyOp(
  service: DynamoDBService,
  op: Operation,
  seq: { n: number },
): Promise<void> {
  const prior = await service.getPromptOverride(op.promptKey);
  if (op.kind === "reset") {
    // deletePromptOverride is a no-op when prior is null; otherwise it
    // transactionally snapshots the prior edit + writes a reset event
    // row + deletes the OVERRIDE row. Either way the post-condition
    // is "no override row". The service's own idempotence on the
    // null-prior branch is the kernel of the property under test —
    // the extra reset at the end of the iteration body exercises this
    // exact branch.
    seq.n += 1;
    await service.deletePromptOverride(op.promptKey, prior, {
      modifiedAt: `2024-06-01T12:00:${String(seq.n % 60).padStart(2, "0")}.000Z`,
      modifiedBy: "property-test",
    });
    return;
  }
  const priorVersion = prior?.version ?? 0;
  seq.n += 1;
  const newOverride: PromptOverride = {
    promptKey: op.promptKey,
    text: op.text,
    modelKey: op.modelKey,
    inferenceParameters: op.inferenceParameters,
    version: priorVersion + 1,
    // Synthesised distinct timestamp per op (see fn-doc above).
    lastModifiedAt: `2024-06-01T12:00:${String(seq.n % 60).padStart(2, "0")}.000Z`,
    lastModifiedBy: "property-test",
  };
  await service.putPromptOverride(newOverride, priorVersion, prior, "edit");
}

// ---------------------------------------------------------------------------
// Per-prompt operation arbitraries
// ---------------------------------------------------------------------------

/**
 * Build a fast-check arbitrary that emits valid `PUT` and `RESET`
 * operations against a single `promptKey`. The `PUT` branch chains
 * through the prompt's `allowedModels[]` and the shared
 * `validTextArb` / `validInferenceParametersArb` so every generated
 * `PUT` would itself pass the validation pipeline (R4.5–R4.10).
 * Constraining to valid PUTs is deliberate: the property under test is
 * about persistence-layer idempotence, not about the validation
 * pipeline, so non-valid bodies would only obscure the signal.
 *
 * The `oneof` weights `PUT` and `RESET` equally; this keeps roughly
 * half the sequence as resets, which is the regime where the
 * idempotence kernel (back-to-back resets, the exact case the property
 * pins) shrinks down to most cleanly.
 */
function operationArbForPrompt(
  promptKey: PromptKey,
  prompt: PromptDefinition,
): fc.Arbitrary<Operation> {
  const putArb: fc.Arbitrary<Operation> = fc
    .constantFrom(...prompt.allowedModels)
    .chain((modelKey) => {
      const model = SUPPORTED_MODELS[modelKey];
      return fc
        .tuple(validTextArb(prompt), validInferenceParametersArb(prompt, model))
        .map(([text, inferenceParameters]) => ({
          kind: "put" as const,
          promptKey,
          text,
          modelKey,
          inferenceParameters,
        }));
    });
  const resetArb: fc.Arbitrary<Operation> = fc.constant({
    kind: "reset" as const,
    promptKey,
  });
  return fc.oneof(putArb, resetArb);
}

// ---------------------------------------------------------------------------
// Sequence arbitrary — non-empty, ≤20 ops, always ending in a RESET.
//
// fast-check first draws a non-empty op list of length 1..20. If the
// last op is already a RESET we keep the sequence as-is (the natural
// generator path); otherwise we append a single RESET. The post-fix-up
// length therefore lies in [1, 21], which slightly exceeds the
// task-stated cap of 20. The deliberate choice is to preserve the
// shrinker's ability to walk freely over the natural draw rather than
// reserve a slot for the appended reset and constrain the upstream
// length to 19 — the extra op is at most a single deterministic step
// so the in-memory mock's footprint stays bounded either way.
// ---------------------------------------------------------------------------

interface Sequence {
  promptKey: PromptKey;
  prompt: PromptDefinition;
  ops: readonly Operation[];
}

const sequenceArb: fc.Arbitrary<Sequence> = promptKeyArb.chain((promptKey) => {
  const prompt = PROMPT_REGISTRY[promptKey];
  return fc
    .array(operationArbForPrompt(promptKey, prompt), {
      minLength: 1,
      maxLength: 20,
    })
    .map((ops) => {
      const last = ops[ops.length - 1];
      if (last.kind === "reset") {
        return { promptKey, prompt, ops };
      }
      return {
        promptKey,
        prompt,
        ops: [...ops, { kind: "reset" as const, promptKey }],
      };
    });
});

// ---------------------------------------------------------------------------
// The property
// ---------------------------------------------------------------------------

describe("Property 2 — Reset idempotence", () => {
  it("an extra reset after a sequence ending in a reset leaves the resolved state unchanged", async () => {
    await fc.assert(
      fc.asyncProperty(sequenceArb, async ({ promptKey, prompt, ops }) => {
        const client = makeInMemoryDocClient();
        const service = createDynamoDBService(TABLE_NAME, client);
        const seq = { n: 0 };

        // 1. Apply the generated sequence. The last op is guaranteed
        //    to be a RESET by construction of `sequenceArb`, so on
        //    return the OVERRIDE row for `promptKey` is gone.
        for (const op of ops) {
          await applyOp(service, op, seq);
        }

        // 2. Capture the state after the final reset.
        //    - The persistence layer's view: the OVERRIDE row is null.
        //    - The resolver's view: bundled defaults with version=0.
        //    These two readings are taken via independent paths so a
        //    divergence in either layer is observable.
        const overrideAfterFirst = await service.getPromptOverride(promptKey);
        expect(
          overrideAfterFirst,
          `[${promptKey}] override should be null after the sequence's terminal RESET`,
        ).toBeNull();
        const resolvedAfterFirst = resolvePrompt(promptKey, new Map());

        // 3. Apply ONE additional reset. The service's
        //    deletePromptOverride is a no-op when priorOverride is
        //    null, so this call does not consult DDB at all — the
        //    idempotence kernel under test. The resetEvent argument
        //    is required by the signature but unused on the null-
        //    prior branch.
        await service.deletePromptOverride(
          promptKey,
          await service.getPromptOverride(promptKey),
          {
            modifiedAt: "2024-06-01T12:00:00.000Z",
            modifiedBy: "property-test",
          },
        );

        // 4. Re-capture the state. Element-wise equality with the
        //    pre-extra-reset capture is the property's post-condition.
        const overrideAfterSecond = await service.getPromptOverride(promptKey);
        const resolvedAfterSecond = resolvePrompt(promptKey, new Map());

        expect(
          overrideAfterSecond,
          `[${promptKey}] override should still be null after the extra RESET`,
        ).toBeNull();

        // Element-wise equality across the two captures. Each field is
        // asserted individually so a shrinker counter-example points
        // at the specific field that diverged rather than at an opaque
        // object diff.
        expect(resolvedAfterSecond.text).toBe(resolvedAfterFirst.text);
        expect(resolvedAfterSecond.modelKey).toBe(resolvedAfterFirst.modelKey);
        expect(resolvedAfterSecond.inferenceParameters).toEqual(
          resolvedAfterFirst.inferenceParameters,
        );
        expect(resolvedAfterSecond.version).toBe(resolvedAfterFirst.version);
        expect(resolvedAfterSecond.modelId).toBe(resolvedAfterFirst.modelId);

        // 5. The state must equal the registry's bundled defaults for
        //    the prompt — the explicit shape the spec calls out
        //    (`effectiveText`, `currentModelKey`, `inferenceParameters`,
        //    `version: 0`, `isOverridden: false`). `isOverridden` maps
        //    to "override row is null", which we've already asserted
        //    above.
        expect(resolvedAfterFirst.text).toBe(prompt.defaultText);
        expect(resolvedAfterFirst.modelKey).toBe(prompt.defaultModelKey);
        expect(resolvedAfterFirst.inferenceParameters).toEqual(
          prompt.defaultInferenceValues,
        );
        expect(resolvedAfterFirst.version).toBe(0);
      }),
      // R15.6 requires ≥100 iterations; 100 is the explicit task
      // requirement and gives the fast-check shrinker enough budget
      // to produce a minimal counter-example without bloating CI
      // runtime. The op-count cap (≤20 per iteration) keeps each
      // iteration's wall-clock under a millisecond on the in-memory
      // mock, so 100 iterations stay well under the suite's
      // per-test budget.
      { numRuns: 100 },
    );
  });
});
