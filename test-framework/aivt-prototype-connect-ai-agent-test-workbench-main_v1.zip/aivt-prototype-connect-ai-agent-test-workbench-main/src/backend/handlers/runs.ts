/**
 * Run Trigger Lambda — POST /runs, POST /runs/{runId}/abort
 *
 * Starts a new test run by snapshotting agent configuration, creating a run
 * record, and starting a Step Functions execution. Also supports aborting an
 * in-progress run.
 *
 * Environment variables:
 * - TABLE_NAME: DynamoDB table name
 * - CONNECT_INSTANCE_ID: The Connect instance identifier
 * - ASSISTANT_ID: The Q in Connect assistant identifier
 * - STATE_MACHINE_ARN: Step Functions state machine ARN
 *
 * @module runs
 */

import {
  QConnectClient,
  GetAIAgentCommand,
  GetAIPromptCommand,
} from "@aws-sdk/client-qconnect";
import {
  SFNClient,
  StartExecutionCommand,
  StopExecutionCommand,
} from "@aws-sdk/client-sfn";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { DynamoDBService, createDynamoDBService } from "../services/dynamodb";
import { CONCURRENCY } from "../../shared/constants";
import { RunStatus } from "../../shared/enums";
import type { AgentSnapshot, TestRun, ToolDefinition } from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

function getTableName(): string {
  return process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
}

function getAssistantId(): string {
  return process.env.ASSISTANT_ID ?? "";
}

function getStateMachineArn(): string {
  return process.env.STATE_MACHINE_ARN ?? "";
}

function getRegion(): string {
  return process.env.AWS_REGION ?? "us-east-1";
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

let qconnectClient: QConnectClient | null = null;
let sfnClient: SFNClient | null = null;
let dbService: DynamoDBService | null = null;

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: getRegion() });
  }
  return qconnectClient;
}

function getSFNClient(): SFNClient {
  if (!sfnClient) {
    sfnClient = new SFNClient({ region: getRegion() });
  }
  return sfnClient;
}

function getDBService(): DynamoDBService {
  if (!dbService) {
    const ddbClient = new DynamoDBClient({});
    const docClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
    dbService = createDynamoDBService(getTableName(), docClient);
  }
  return dbService;
}

/** @internal — allows test injection */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

/** @internal — allows test injection */
export function _setSFNClient(client: SFNClient | null): void {
  sfnClient = client;
}

/** @internal — allows test injection */
export function _setDBService(service: DynamoDBService | null): void {
  dbService = service;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  body?: string | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, string>;
    };
  };
}

export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(statusCode: number, body: unknown): APIGatewayResponse {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

function extractTenantId(event: APIGatewayEvent): string | null {
  const claims = event.requestContext?.authorizer?.claims;
  // Interactive user: sub claim; Machine client: client_id claim
  return claims?.sub ?? claims?.client_id ?? null;
}

function generateId(): string {
  const hex = "0123456789abcdef";
  let id = "";
  for (let i = 0; i < 24; i++) {
    id += hex[Math.floor(Math.random() * 16)];
  }
  return id;
}

function nowISO(): string {
  return new Date().toISOString();
}

// ---------------------------------------------------------------------------
// Snapshot agent configuration
// ---------------------------------------------------------------------------

/**
 * Calls GetAIAgent to capture a point-in-time snapshot of the agent config.
 *
 * Resolves the orchestration prompt id to the actual prompt body and the
 * model id the prompt is configured against, so the persisted snapshot
 * carries the same content the GUI shows under "System Prompt" rather
 * than the bare prompt-id string. Failures fetching the prompt detail
 * are logged but non-fatal — the snapshot still captures the tools
 * (which is what the platform's tool-accuracy / failure-analysis
 * pipelines need).
 */
async function snapshotAgent(agentId: string): Promise<AgentSnapshot> {
  const client = getQConnectClient();

  const command = new GetAIAgentCommand({
    assistantId: getAssistantId(),
    aiAgentId: agentId,
  });

  const response = await client.send(command);
  const agent = response.aiAgent;

  if (!agent) {
    throw new Error(`Agent ${agentId} not found`);
  }

  const orchestrationConfig =
    agent.configuration?.orchestrationAIAgentConfiguration;
  const tools: ToolDefinition[] = (
    orchestrationConfig?.toolConfigurations ?? []
  ).map((tool) => {
    // The QConnect SDK's `ToolConfiguration` type does not yet expose
    // `examples` at the top level (the API surfaces it but the SDK
    // typings lag), so widen through `unknown` to read the field
    // defensively without disabling type-checking on the rest of the
    // mapper.
    const upstreamExamples = (tool as unknown as { examples?: unknown })
      .examples;
    return {
      toolName: tool.toolName!,
      toolType: tool.toolType!,
      description: tool.description ?? "",
      ...(tool.instruction?.instruction && {
        instruction: tool.instruction.instruction,
      }),
      inputSchema: (tool.inputSchema as Record<string, unknown>) ?? {},
      // Capture few-shot examples that were active at run start so the
      // persisted snapshot reflects what the orchestration runtime injects
      // into the system prompt at inference time. Mirrors the Discovery
      // Lambda mapping: absent / null / non-array collapses to [] so the
      // field is never omitted (R3.1, R3.2). Order and string content
      // are preserved verbatim — no trim, no normalization.
      examples: Array.isArray(upstreamExamples)
        ? [...(upstreamExamples as string[])]
        : [],
    };
  });

  const promptId = orchestrationConfig?.orchestrationAIPromptId ?? "";
  let systemPrompt = "";
  let modelId = promptId || "unknown";
  if (promptId) {
    try {
      const promptResp = await client.send(
        new GetAIPromptCommand({
          assistantId: getAssistantId(),
          aiPromptId: promptId,
        }),
      );
      const promptData = promptResp.aiPrompt;
      const tc = promptData?.templateConfiguration as
        | { textFullAIPromptEditTemplateConfiguration?: { text?: string } }
        | undefined;
      systemPrompt = tc?.textFullAIPromptEditTemplateConfiguration?.text ?? "";
      if (promptData?.modelId) modelId = promptData.modelId;
    } catch (error) {
      console.warn(
        `[runs] GetAIPrompt(${promptId}) failed; snapshot will omit prompt body: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  }

  return {
    tools,
    systemPrompt,
    modelId,
    capturedAt: nowISO(),
  };
}

// ---------------------------------------------------------------------------
// Route: POST /runs
// ---------------------------------------------------------------------------

async function startRun(
  tenantId: string,
  body: string | null
): Promise<APIGatewayResponse> {
  if (!body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let input: { suiteId?: string; concurrency?: number; caseIds?: string[] };
  try {
    input = JSON.parse(body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  if (!input.suiteId) {
    return jsonResponse(400, { error: "suiteId is required" });
  }

  // Optional `caseIds` lets the caller scope a run to a subset of the
  // suite's cases (used by the per-case "Run" action in the GUI). When
  // present it MUST be a non-empty array of strings; the resulting run
  // executes the same translate→judge→aggregate→assemble pipeline as a
  // full-suite run, just over the filtered case list.
  if (input.caseIds !== undefined) {
    if (
      !Array.isArray(input.caseIds) ||
      input.caseIds.length === 0 ||
      !input.caseIds.every((c) => typeof c === "string" && c.trim() !== "")
    ) {
      return jsonResponse(400, {
        error:
          "caseIds, when provided, must be a non-empty array of non-empty strings.",
      });
    }
  }

  const suiteId = input.suiteId;
  const concurrency = input.concurrency ?? CONCURRENCY;
  const caseIdFilter = input.caseIds;

  if (!getStateMachineArn()) {
    return jsonResponse(500, {
      error: "ConfigurationError",
      message: "STATE_MACHINE_ARN is not configured",
    });
  }

  if (!getAssistantId()) {
    return jsonResponse(500, {
      error: "ConfigurationError",
      message: "ASSISTANT_ID is not configured",
    });
  }

  const db = getDBService();

  // Verify suite exists and belongs to tenant
  const suite = await db.getSuite(tenantId, suiteId);
  if (!suite) {
    return jsonResponse(404, { error: "Suite not found" });
  }

  // Get all test cases for the suite
  const allCases = await db.listCases(suiteId);
  if (allCases.length === 0) {
    return jsonResponse(400, {
      error: "Suite has no test cases. Add at least one test case before running.",
    });
  }

  // Apply optional caseIds filter (preserves the suite's case order so the
  // Step Functions Map state still respects authoring order). Reject the
  // request if any of the requested ids don't belong to the suite — better
  // than silently dropping them.
  let testCases = allCases;
  if (caseIdFilter !== undefined) {
    const requested = new Set(caseIdFilter);
    testCases = allCases.filter((c) => requested.has(c.caseId));
    const found = new Set(testCases.map((c) => c.caseId));
    const missing = caseIdFilter.filter((id) => !found.has(id));
    if (missing.length > 0) {
      return jsonResponse(400, {
        error: `caseIds contains ids not in suite "${suiteId}": ${missing.join(", ")}`,
      });
    }
  }

  // Snapshot agent config
  const agentSnapshot = await snapshotAgent(suite.agentId);

  // Create run record
  const startTime = nowISO();
  const runId = generateId();

  const run: TestRun = {
    suiteId,
    runId,
    status: RunStatus.RUNNING,
    totalCases: testCases.length,
    passed: 0,
    failed: 0,
    errors: 0,
    concurrency,
    startTime,
    sfnExecutionArn: "", // will be updated after starting execution
  };

  await db.createRun(run);

  // Save agent snapshot
  await db.writeSnapshot(runId, agentSnapshot);

  // Start Step Functions execution.
  //
  // The state machine input carries BOTH `runId` AND `startTime` so that
  // PrepareRun (the first state) can write its own DDB record at the same
  // composite key (PK=SUITE#{suiteId}, SK=RUN#{startTime}) the API just
  // created. Without `startTime`, PrepareRun mints a new timestamp, which
  // produces a second record under a different SK and leaves the runId
  // pointing at two physical records — that bug was the cause of GET
  // /runs/{runId} 404s on a freshly launched run, since the API's record
  // had its `runId` overwritten on PrepareRun's later put-with-different-SK.
  const sfn = getSFNClient();
  const executionInput = JSON.stringify({
    suiteId,
    tenantId,
    runId,
    startTime,
    concurrency,
    agentSnapshot: { ...agentSnapshot, agentId: suite.agentId },
    testCases,
  });

  const startExecCommand = new StartExecutionCommand({
    stateMachineArn: getStateMachineArn(),
    name: `run-${runId}-${Date.now()}`,
    input: executionInput,
  });

  const execResult = await sfn.send(startExecCommand);
  const sfnExecutionArn = execResult.executionArn ?? "";

  // Update run record with execution ARN
  await db.updateRun({
    suiteId,
    startTime,
    status: RunStatus.RUNNING,
  });

  // We need to store the ARN — update the run object in DDB
  // The DynamoDBService.updateRun doesn't support sfnExecutionArn directly,
  // so we re-create the run record with the ARN included
  const updatedRun: TestRun = { ...run, sfnExecutionArn };
  await db.createRun(updatedRun);

  return jsonResponse(201, { runId, sfnExecutionArn, status: RunStatus.RUNNING });
}

// ---------------------------------------------------------------------------
// Route: POST /runs/{runId}/abort
// ---------------------------------------------------------------------------

async function abortRun(
  tenantId: string,
  runId: string
): Promise<APIGatewayResponse> {
  const db = getDBService();

  // List runs to find the one with matching runId
  // Since the SK is RUN#{timestamp}, we need to query by suite and find the run
  // The runId is stored as an attribute on the run record
  // We need to find which suite this run belongs to — we'll look up suites for the tenant
  const suites = await db.listSuites(tenantId);

  let foundRun: TestRun | null = null;
  for (const suite of suites) {
    const runs = await db.listRuns(suite.suiteId);
    const match = runs.find((r) => r.runId === runId);
    if (match) {
      foundRun = match;
      break;
    }
  }

  if (!foundRun) {
    return jsonResponse(404, { error: "Run not found" });
  }

  if (foundRun.status !== RunStatus.RUNNING) {
    return jsonResponse(400, {
      error: `Cannot abort run with status: ${foundRun.status}`,
    });
  }

  // Stop the Step Functions execution
  if (foundRun.sfnExecutionArn) {
    const sfn = getSFNClient();
    const stopCommand = new StopExecutionCommand({
      executionArn: foundRun.sfnExecutionArn,
      cause: "User-initiated abort",
    });
    await sfn.send(stopCommand);
  }

  // Update run status to ABORTED
  await db.updateRun({
    suiteId: foundRun.suiteId,
    startTime: foundRun.startTime,
    status: RunStatus.ABORTED,
    endTime: nowISO(),
  });

  return jsonResponse(200, { message: "Run aborted", runId });
}

// ---------------------------------------------------------------------------
// Main handler / router
// ---------------------------------------------------------------------------

/**
 * Lambda handler for run trigger and abort operations.
 * Routes based on httpMethod and resource path pattern.
 */
export async function handler(
  event: APIGatewayEvent
): Promise<APIGatewayResponse> {
  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  // Extract tenant ID from Cognito authorizer claims
  const tenantId = extractTenantId(event);
  if (!tenantId) {
    return jsonResponse(401, { error: "Unauthorized: missing tenant identity" });
  }

  const method = event.httpMethod;
  const resource = event.resource;
  const runId = event.pathParameters?.runId ?? null;

  try {
    // Route: POST /runs
    if (method === "POST" && resource === "/runs") {
      return await startRun(tenantId, event.body ?? null);
    }

    // Route: POST /runs/{runId}/abort
    if (
      method === "POST" &&
      resource === "/runs/{runId}/abort" &&
      runId
    ) {
      return await abortRun(tenantId, runId);
    }

    return jsonResponse(404, {
      error: `Route not found: ${method} ${resource}`,
    });
  } catch (error: unknown) {
    console.error(
      "[runs] Handler error:",
      error instanceof Error ? error.message : error
    );

    const errorName = (error as { name?: string })?.name ?? "";

    if (errorName === "ThrottlingException") {
      return jsonResponse(429, {
        error: "ThrottlingException",
        message: "Request rate exceeded. Please retry after a brief delay.",
        retryable: true,
        retryAfterSeconds: 5,
      });
    }

    if (errorName === "ExecutionAlreadyExists") {
      return jsonResponse(409, {
        error: "ExecutionAlreadyExists",
        message: "A run with this configuration is already in progress.",
      });
    }

    if (errorName === "ExecutionDoesNotExist") {
      return jsonResponse(404, {
        error: "ExecutionNotFound",
        message: "The Step Functions execution was not found.",
      });
    }

    return jsonResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
}
