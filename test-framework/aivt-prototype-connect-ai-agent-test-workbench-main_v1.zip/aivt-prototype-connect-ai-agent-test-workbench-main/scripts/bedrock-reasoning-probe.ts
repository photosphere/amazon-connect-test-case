#!/usr/bin/env node
/**
 * Bedrock reasoning probe — validates that the reasoning-enriched failure
 * analysis prompt produces valid structured root-cause analysis when invoked
 * directly via Bedrock Converse.
 *
 * Loads `tmp/spans-mortgage-rate.json`, parses it into an ExecutionTrace,
 * builds the failure analysis prompt (with or without the reasoning trace
 * section), and calls Bedrock Converse to validate the end-to-end pipeline.
 *
 * Run:
 *   npx tsx scripts/bedrock-reasoning-probe.ts                   # with reasoning (default)
 *   npx tsx scripts/bedrock-reasoning-probe.ts --without-reasoning  # baseline comparison
 *   ANALYSIS_MODEL_ID=us.anthropic.claude-haiku-4-5-20251001-v1:0 npx tsx scripts/bedrock-reasoning-probe.ts
 *
 * Cost: 1 Bedrock Converse call with ~6–8K input tokens → ~$0.03–$0.05 per run.
 */
import { readFileSync } from "node:fs";
import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ContentBlock,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";
import {
  parseSpansToTrace,
  type RawSpan,
} from "../src/backend/orchestration/span-parser";
import { buildAnalysisPrompt } from "../src/backend/handlers/analysis";
import type {
  ExecutionTrace,
  ToolDefinition,
  TranscriptTurn,
} from "../src/shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";
const ANALYSIS_MODEL_ID =
  process.env.ANALYSIS_MODEL_ID ??
  "us.anthropic.claude-sonnet-4-20250514-v1:0";

const SESSION_ID = "b324a670-d71b-4c4e-a77f-4fb53d071890";
const CASE_ID = "probe-mortgage-rate";
const EXPECTED_TOOLS = ["verifyIdentity", "getAccounts", "getLoanDetails", "Complete"];

/** The v2 system prompt from the failure_analysis prompt definition. */
const SYSTEM_PROMPT_TEXT =
  "You are an expert at diagnosing AI agent failures. Analyze the provided test case data and produce structured root cause analysis with actionable recommendations. The user message may include a ## Reasoning trace section containing the agent's chain-of-thought reasoning for inference steps — use this to determine whether the agent misunderstood the goal, picked the wrong tool, hallucinated a constraint, or was misled by the system prompt. Always respond with valid JSON matching the requested schema.";

const VALID_ROOT_CAUSE_CATEGORIES = [
  "overlapping_tool_descriptions",
  "missing_disambiguation",
  "incorrect_tool_prioritization",
  "incomplete_tool_description",
  "system_prompt_gap",
  "missing_tool_instruction",
  "parameter_mismatch",
  "other",
] as const;

const REASONING_KEYWORDS = [
  "reasoning",
  "thought",
  "identity",
  "verify",
  "verification",
  "phone",
  "SSN",
  "chain-of-thought",
  "misunderstood",
  "step",
];

// ---------------------------------------------------------------------------
// CLI argument parsing
// ---------------------------------------------------------------------------

const args = process.argv.slice(2);
const withoutReasoning = args.includes("--without-reasoning");
const mode = withoutReasoning ? "WITHOUT reasoning" : "WITH reasoning";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Extract customer turns from raw inference spans' inputMessages.
 */
function extractCustomerTurns(rawSpans: RawSpan[]): string[] {
  const turns: string[] = [];
  for (const span of rawSpans) {
    if (span.spanName !== "inference") continue;
    const inputs = span.attributes?.inputMessages ?? [];
    for (const m of inputs) {
      for (const v of m.values ?? []) {
        if (v.text?.value) {
          turns.push(v.text.value);
          break;
        }
      }
      break; // Only first message per inference span
    }
  }
  return turns;
}

/**
 * Build TranscriptTurn[] from customer text extracted from spans.
 */
function buildTranscript(customerTurns: string[]): TranscriptTurn[] {
  return customerTurns.map((text, i) => ({
    turnNumber: i + 1,
    role: "customer" as const,
    text,
    timestamp: new Date().toISOString(),
    elapsedMs: 0,
  }));
}

/**
 * Extract tool definitions from the system instructions in the fixture.
 * Falls back to basic definitions based on known tool names.
 */
function extractAgentTools(_rawSpans: RawSpan[]): ToolDefinition[] {
  // Known tools from the fixture's system prompt
  const tools: ToolDefinition[] = [
    {
      toolName: "verifyIdentity",
      toolType: "TOOL",
      description: "Verify a customer's identity using phone number and last four digits of SSN.",
      instruction: "If you have access to the customers phone number through the custom attribute customerPhoneNumber then use that and do not ask the customer for their phone number. Only ask if that phone number fails to work for authentication or if it is missing.",
      inputSchema: { phoneNumber: "string", ssnLastFour: "string" },
      examples: [
        "I see that the customers phone number is already available in the customerPhoneNumber attribute so I will just ask for the last four digits of their social security number for authentication",
      ],
    },
    {
      toolName: "getAccounts",
      toolType: "TOOL",
      description: "Retrieve a list of customer accounts after identity verification.",
      inputSchema: { authToken: "string" },
      examples: [],
    },
    {
      toolName: "getLoanDetails",
      toolType: "TOOL",
      description: "Get detailed loan information including balance, rate, and payment schedule.",
      inputSchema: { loanId: "string", authToken: "string" },
      examples: [],
    },
    {
      toolName: "Complete",
      toolType: "TOOL",
      description: "Mark the conversation as complete.",
      instruction: "Mark the conversation as complete ONLY after confirming the customer has no additional questions or needs. Always ask if there's anything else you can help with before using this tool.",
      inputSchema: {},
      examples: [],
    },
    {
      toolName: "Escalate",
      toolType: "TOOL",
      description: "Escalate the conversation to a human agent.",
      instruction: "Escalate the conversation to a human agent when you cannot provide adequate assistance, when other tools fail or return errors, or when the customer's request requires human intervention.",
      inputSchema: {},
      examples: [
        "Good example - Tool errors:\n<message>\nI'm having trouble accessing the information you need right now. Would you like me to connect you with a human agent who can help you further?\n</message>",
        "Good example - Frustrated customer:\n<message>\nI understand your frustration with this issue. Would you like me to connect you with a human agent who can help you further?\n</message>",
        "Bad example (avoid this):\n<message>\nI'm unable to help with this. Let me escalate you to a human agent.\n</message>",
      ],
    },
    {
      toolName: "GetPayoffQuote",
      toolType: "TOOL",
      description: "Generate a payoff quote for the customer's loan.",
      inputSchema: { loanId: "string", authToken: "string" },
      examples: [],
    },
    {
      toolName: "makePayment",
      toolType: "TOOL",
      description: "Process a payment on the customer's loan.",
      inputSchema: { loanId: "string", amount: "number", paymentMethodId: "string" },
      examples: [],
    },
    {
      toolName: "getPaymentMethods",
      toolType: "TOOL",
      description: "Retrieve available payment methods for the customer.",
      inputSchema: { authToken: "string" },
      examples: [],
    },
  ];
  return tools;
}

/**
 * Extract systemInstructions text from the first inference span.
 */
function extractSystemPrompt(rawSpans: RawSpan[]): string {
  for (const span of rawSpans) {
    if (span.spanName !== "inference") continue;
    const instructions = span.attributes?.systemInstructions;
    if (instructions && instructions.length > 0) {
      const texts = instructions
        .map((si) => (si.text?.value as string) ?? "")
        .filter((t) => t.length > 0);
      if (texts.length > 0) return texts.join("\n\n");
    }
  }
  return "(system prompt not available)";
}

/**
 * Truncate a section for display, showing first/last N chars.
 */
function truncateSection(text: string, maxChars = 500): string {
  if (text.length <= maxChars * 2 + 20) return text;
  return (
    text.slice(0, maxChars) +
    `\n\n... [${text.length - maxChars * 2} chars truncated] ...\n\n` +
    text.slice(-maxChars)
  );
}

/**
 * Extract JSON from Bedrock response text — handles both raw JSON and
 * fenced code blocks.
 */
function extractJson(raw: string): string {
  // Try fenced code block first
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
  if (fenced) return fenced[1].trim();
  // Find first { ... last } pair
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start >= 0 && end > start) return raw.slice(start, end + 1);
  return raw.trim();
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main(): Promise<void> {
  console.log("=".repeat(70));
  console.log("BEDROCK REASONING PROBE — Failure Analysis Pipeline");
  console.log("=".repeat(70));
  console.log(`Mode: ${mode}`);
  console.log(`Model: ${ANALYSIS_MODEL_ID}`);
  console.log(`Region: ${REGION}`);
  console.log();

  // Step 1: Load raw spans
  const fixtureRaw = readFileSync("tmp/spans-mortgage-rate.json", "utf-8");
  const rawSpans: RawSpan[] = JSON.parse(fixtureRaw);
  console.log(`Loaded ${rawSpans.length} raw spans from tmp/spans-mortgage-rate.json`);

  // Step 2: Parse through parseSpansToTrace
  const trace: ExecutionTrace = parseSpansToTrace(SESSION_ID, rawSpans);
  console.log(
    `Parsed trace: ${trace.steps.length} steps, ${trace.toolSequence.length} tool calls`
  );
  console.log(`Tool sequence: ${trace.toolSequence.join(" → ") || "(none)"}`);
  console.log();

  // Step 3: Build the failure analysis prompt
  const customerTurns = extractCustomerTurns(rawSpans);
  const transcript = buildTranscript(customerTurns);
  const agentTools = extractAgentTools(rawSpans);
  const systemPrompt = extractSystemPrompt(rawSpans);

  // If --without-reasoning, strip reasoning from steps so the reasoning section
  // is not appended.
  const traceForPrompt: ExecutionTrace | null = withoutReasoning
    ? {
        ...trace,
        steps: trace.steps.map((s) => ({ ...s, reasoning: undefined })),
      }
    : trace;

  const userMessage = buildAnalysisPrompt({
    caseId: CASE_ID,
    testCaseDefinition: null,
    transcript,
    reasoningTrace: traceForPrompt,
    expectedTools: EXPECTED_TOOLS,
    actualTools: trace.toolSequence,
    agentTools,
    systemPrompt,
  });

  // Step 4: Print rendered prompt (truncated)
  console.log("=".repeat(70));
  console.log("RENDERED PROMPT (truncated sections)");
  console.log("=".repeat(70));

  // Split by ## headings and truncate each
  const sections = userMessage.split(/(?=^## )/m);
  for (const section of sections) {
    const heading = section.match(/^## .+/)?.[0] ?? "(preamble)";
    const body = section.replace(/^## .+\n?/, "");
    console.log(`\n--- ${heading} ---`);
    console.log(truncateSection(body));
  }
  console.log();

  // Step 5: Call Bedrock Converse
  console.log("=".repeat(70));
  console.log("CALLING BEDROCK CONVERSE");
  console.log("=".repeat(70));

  const client = new BedrockRuntimeClient({ region: REGION });
  const messages: Message[] = [
    { role: "user", content: [{ text: userMessage }] as ContentBlock[] },
  ];

  const startTime = Date.now();
  let responseText: string;
  try {
    const resp = await client.send(
      new ConverseCommand({
        modelId: ANALYSIS_MODEL_ID,
        messages,
        system: [{ text: SYSTEM_PROMPT_TEXT }],
        inferenceConfig: { maxTokens: 4096, temperature: 0 },
      })
    );
    const latencyMs = Date.now() - startTime;
    responseText =
      resp.output?.message?.content
        ?.map((b) => ("text" in b ? b.text ?? "" : ""))
        .join("") ?? "";

    if (!responseText) {
      console.log("ERROR: Bedrock returned no text");
      process.exit(1);
    }

    console.log(`Latency: ${latencyMs}ms`);
    console.log(
      `Usage: ${resp.usage?.inputTokens ?? "?"} input / ${resp.usage?.outputTokens ?? "?"} output tokens`
    );
    console.log();
  } catch (err: unknown) {
    const latencyMs = Date.now() - startTime;
    console.log(`ERROR after ${latencyMs}ms: ${(err as Error).message}`);
    process.exit(1);
  }

  // Step 6: Parse the JSON response
  console.log("=".repeat(70));
  console.log("PARSING RESPONSE");
  console.log("=".repeat(70));

  let parsed: {
    rootCauseCategory: string;
    explanation: string;
    recommendations: Array<{
      targetField: string;
      targetName: string;
      currentText: string;
      suggestedText: string;
      rationale: string;
    }>;
  };

  try {
    const jsonStr = extractJson(responseText);
    parsed = JSON.parse(jsonStr);
  } catch (err: unknown) {
    console.log(`ERROR: Failed to parse response as JSON`);
    console.log(`Raw response (first 1000 chars): ${responseText.slice(0, 1000)}`);
    process.exit(1);
  }

  // Step 7: Validate the response
  console.log("=".repeat(70));
  console.log("VALIDATION");
  console.log("=".repeat(70));

  const errors: string[] = [];

  // 7a: rootCauseCategory
  if (
    !VALID_ROOT_CAUSE_CATEGORIES.includes(
      parsed.rootCauseCategory as (typeof VALID_ROOT_CAUSE_CATEGORIES)[number]
    )
  ) {
    errors.push(
      `rootCauseCategory "${parsed.rootCauseCategory}" is not a valid category. ` +
        `Valid: ${VALID_ROOT_CAUSE_CATEGORIES.join(", ")}`
    );
  } else {
    console.log(`✓ rootCauseCategory: "${parsed.rootCauseCategory}"`);
  }

  // 7b: explanation is non-empty string
  if (typeof parsed.explanation !== "string" || parsed.explanation.length === 0) {
    errors.push("explanation is missing or empty");
  } else {
    console.log(`✓ explanation: ${parsed.explanation.length} chars`);
  }

  // 7c: explanation mentions at least one reasoning-related keyword
  if (!withoutReasoning) {
    const explanationLower = (parsed.explanation ?? "").toLowerCase();
    const matchedKeyword = REASONING_KEYWORDS.find((kw) =>
      explanationLower.includes(kw.toLowerCase())
    );
    if (!matchedKeyword) {
      errors.push(
        `explanation does not mention any reasoning-related keywords: ${REASONING_KEYWORDS.join(", ")}`
      );
    } else {
      console.log(`✓ explanation references reasoning (keyword: "${matchedKeyword}")`);
    }
  } else {
    console.log(`○ skipping reasoning keyword check (--without-reasoning mode)`);
  }

  // 7d: recommendations is an array of 1-5 items
  if (!Array.isArray(parsed.recommendations)) {
    errors.push("recommendations is not an array");
  } else if (parsed.recommendations.length < 1 || parsed.recommendations.length > 5) {
    errors.push(
      `recommendations has ${parsed.recommendations.length} items (expected 1-5)`
    );
  } else {
    console.log(`✓ recommendations: ${parsed.recommendations.length} items`);
  }

  // 7e: Each recommendation has required fields
  const VALID_TARGET_FIELDS = [
    "tool_description",
    "tool_instruction",
    "tool_examples",
    "system_prompt",
  ];
  const requiredRecFields = [
    "targetField",
    "targetName",
    "currentText",
    "suggestedText",
    "rationale",
  ] as const;

  if (Array.isArray(parsed.recommendations)) {
    for (let i = 0; i < parsed.recommendations.length; i++) {
      const rec = parsed.recommendations[i];
      for (const field of requiredRecFields) {
        if (typeof rec[field] !== "string") {
          errors.push(`recommendations[${i}].${field} is missing or not a string`);
        }
      }
      if (
        typeof rec.targetField === "string" &&
        !VALID_TARGET_FIELDS.includes(rec.targetField)
      ) {
        errors.push(
          `recommendations[${i}].targetField "${rec.targetField}" is not valid. ` +
            `Valid: ${VALID_TARGET_FIELDS.join(", ")}`
        );
      }
    }
    // Print first recommendation details
    if (parsed.recommendations.length > 0) {
      const first = parsed.recommendations[0];
      console.log(`  [0] targetField: "${first.targetField}", targetName: "${first.targetName}"`);
      console.log(`      rationale: "${first.rationale?.slice(0, 100)}..."`);
    }
  }

  console.log();

  // Step 8: Print summary
  console.log("=".repeat(70));
  console.log("SUMMARY");
  console.log("=".repeat(70));
  console.log(`Model:            ${ANALYSIS_MODEL_ID}`);
  console.log(`Mode:             ${mode}`);
  console.log(`Root cause:       ${parsed.rootCauseCategory}`);
  console.log(`Recommendations:  ${parsed.recommendations?.length ?? 0}`);
  console.log(`Validation:       ${errors.length === 0 ? "PASSED ✓" : `FAILED (${errors.length} error(s))`}`);

  if (errors.length > 0) {
    console.log();
    console.log("Validation errors:");
    for (const e of errors) {
      console.log(`  ✗ ${e}`);
    }
    process.exit(1);
  }

  console.log();
  console.log("Explanation (first 300 chars):");
  console.log(`  ${parsed.explanation.slice(0, 300)}`);
  process.exit(0);
}

main().catch((err) => {
  console.error("Unhandled error:", err);
  process.exit(1);
});
