# Agent State Backup & Rollback

Snapshot and restore Q in Connect AI agents + AI prompts so the
implement-recommendations apply / experiment-apply flows can be rolled back.

These scripts use the project's pinned `@aws-sdk/client-qconnect`, which models
the full `orchestrationAIAgentConfiguration` shape. (The system AWS CLI v2.27 is
too old and collapses the config to `SDK_UNKNOWN_MEMBER`, losing tool configs —
do **not** use `aws qconnect get-ai-agent` for backups.)

## What gets mutated by an apply

The platform's `config-writer` applies:
- tool-surface changes (`tool_description`, `tool_instruction`, `tool_examples`)
  via a single `UpdateAIAgent` call
- `system_prompt` changes via a single `UpdateAIPrompt` call

So a complete rollback needs both the agent config and its prompt template — the
backup captures both.

## Backup (read-only)

```bash
ASSISTANT_ID=<assistant-uuid> npx tsx scripts/backup-agent-state.ts
```

Writes `backups/agent-state/<timestamp>/` with:
- `agents-manifest.json`, `prompts-manifest.json` — full inventory
- `agents/<id>.json` — full agent config per agent
- `prompts/<id>.json` — full prompt template per prompt
- `backup-summary.json` — per-resource ok/error status

SAVED-status draft agents/prompts with no published `$LATEST` will report
"does not exist" — that's expected. The apply path uses the same
`GetAIAgent`/`GetAIPrompt` calls, so it can't target those drafts either.

`backups/` is gitignored (snapshots may contain sensitive prompt content).

## Restore (dry run by default)

```bash
# Preview ALL resources (no writes):
ASSISTANT_ID=<assistant-uuid> npx tsx scripts/restore-agent-state.ts \
  --backup=backups/agent-state/<timestamp>

# Preview only the resources you changed during testing:
ASSISTANT_ID=<assistant-uuid> npx tsx scripts/restore-agent-state.ts \
  --backup=backups/agent-state/<timestamp> --only=<agentId>,<promptId>

# Actually write the rollback (scope it with --only):
ASSISTANT_ID=<assistant-uuid> npx tsx scripts/restore-agent-state.ts \
  --backup=backups/agent-state/<timestamp> --only=<agentId>,<promptId> --apply
```

Always run the dry run first, and prefer `--only=` scoping so you restore exactly
the agent/prompt you touched rather than overwriting everything.

## Current assistant

- Assistant ID: `5664eea5-381d-468e-bfba-302b69ae6dec`
- Region: `us-east-1`
- Account: `104220062740` (dev / Isengard)
