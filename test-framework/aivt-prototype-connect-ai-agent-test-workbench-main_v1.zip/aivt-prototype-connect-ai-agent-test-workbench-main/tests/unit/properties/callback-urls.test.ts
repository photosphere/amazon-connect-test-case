// Feature: platform-hosting-and-evaluations, Property 2: Callback URLs are validated, deduplicated, and always include CloudFront
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { validateCallbackUrls } from '../../../lib/callback-urls';

/**
 * **Validates: Requirements 4.4, 4.6**
 *
 * Property 2: Callback URLs are validated, deduplicated, and always include CloudFront
 * For any list of provided URLs plus a CloudFront URL: when all entries are
 * well-formed absolute URLs, the result is the trimmed, deduplicated,
 * insertion-order-preserving set (each unique URL exactly once) and always
 * contains the CloudFront URL. When any entry is empty/whitespace or not a
 * well-formed absolute URL, the helper throws (registering nothing).
 */

/** A well-formed absolute URL drawn from a small, realistic pool. */
const absoluteUrlArb = fc.oneof(
  fc.constantFrom(
    'https://example.com',
    'https://example.com/',
    'https://app.example.com/callback',
    'http://localhost:3000',
    'https://d123.cloudfront.net',
    'https://foo.bar/path?x=1'
  ),
  fc
    .webUrl({ withQueryParameters: true, withFragments: false })
    .filter((u) => u.trim().length > 0)
);

const cloudFrontUrlArb = fc.constantFrom(
  'https://d111111abcdef8.cloudfront.net',
  'https://d222222ghijkl9.cloudfront.net'
);

/** An invalid entry: empty/whitespace or a non-absolute / malformed URL. */
const invalidEntryArb = fc.oneof(
  fc.constant(''),
  fc.constantFrom(' ', '   ', '\t', '\n'),
  fc.constantFrom('not a url', '/relative/path', 'example.com', 'foo', '://missing-scheme')
);

describe('Property 2: Callback URLs are validated, deduplicated, and always include CloudFront', () => {
  it('all-valid input yields trimmed, deduplicated, order-preserving result including CloudFront', () => {
    fc.assert(
      fc.property(
        fc.array(absoluteUrlArb, { minLength: 0, maxLength: 8 }),
        cloudFrontUrlArb,
        (contextUrls, cloudFrontUrl) => {
          const result = validateCallbackUrls([...contextUrls, cloudFrontUrl], cloudFrontUrl);

          // Always includes the CloudFront URL.
          expect(result).toContain(cloudFrontUrl);

          // No duplicates.
          expect(new Set(result).size).toBe(result.length);

          // Every result entry is one of the trimmed inputs.
          const trimmedInputs = new Set([...contextUrls, cloudFrontUrl].map((u) => u.trim()));
          for (const r of result) {
            expect(trimmedInputs.has(r)).toBe(true);
          }

          // Insertion order preserved: result equals first-seen dedupe order.
          const seen = new Set<string>();
          const expectedOrder: string[] = [];
          for (const u of [...contextUrls, cloudFrontUrl]) {
            const t = u.trim();
            if (!seen.has(t)) {
              seen.add(t);
              expectedOrder.push(t);
            }
          }
          expect(result).toEqual(expectedOrder);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('duplicate entries are collapsed to exactly one occurrence each', () => {
    fc.assert(
      fc.property(
        fc.array(absoluteUrlArb, { minLength: 1, maxLength: 5 }),
        cloudFrontUrlArb,
        (urls, cloudFrontUrl) => {
          // Duplicate every url and append CloudFront twice.
          const withDupes = [...urls, ...urls, cloudFrontUrl, cloudFrontUrl];
          const result = validateCallbackUrls(withDupes, cloudFrontUrl);

          expect(new Set(result).size).toBe(result.length);
          for (const u of urls) {
            expect(result.filter((r) => r === u.trim())).toHaveLength(1);
          }
          expect(result.filter((r) => r === cloudFrontUrl)).toHaveLength(1);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('throws when any provided entry is empty/whitespace or not an absolute URL', () => {
    fc.assert(
      fc.property(
        fc.array(absoluteUrlArb, { minLength: 0, maxLength: 5 }),
        invalidEntryArb,
        cloudFrontUrlArb,
        (validUrls, invalidEntry, cloudFrontUrl) => {
          // Insert the invalid entry at an arbitrary position.
          const candidates = [...validUrls, invalidEntry, cloudFrontUrl];
          expect(() => validateCallbackUrls(candidates, cloudFrontUrl)).toThrow();
        }
      ),
      { numRuns: 100 }
    );
  });

  it('CloudFront URL is always present even if not in the provided list', () => {
    fc.assert(
      fc.property(
        fc.array(absoluteUrlArb, { minLength: 0, maxLength: 6 }),
        cloudFrontUrlArb,
        (contextUrls, cloudFrontUrl) => {
          // Provide only the context URLs in the list; pass CloudFront separately.
          const result = validateCallbackUrls([...contextUrls, cloudFrontUrl], cloudFrontUrl);
          expect(result).toContain(cloudFrontUrl);
          expect(result.length).toBeGreaterThan(0);
        }
      ),
      { numRuns: 100 }
    );
  });
});
