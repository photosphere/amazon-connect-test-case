/**
 * Knowledge template parameter deduplication utility.
 *
 * For any ordered tool sequence where multiple tools share input parameters
 * with the same name, produces exactly one entry per unique parameter name,
 * grouped under the first tool in the sequence that requires it.
 *
 * @module parameter-dedup
 */

/** Schema for a tool with its parameter names. */
export interface ToolSchema {
  toolName: string;
  parameters: string[]; // parameter names
}

/** A single entry in the deduplicated knowledge template. */
export interface KnowledgeTemplateEntry {
  paramName: string;
  toolGroup: string; // The first tool that requires this parameter
}

/**
 * Deduplicates parameters across an ordered sequence of tools.
 *
 * Walks through tools in order. For each parameter in each tool, if the
 * parameter name has not been seen before, it is added to the result grouped
 * under the current tool. Duplicate parameter names are skipped.
 *
 * @param tools - Ordered list of tool schemas
 * @returns Deduplicated knowledge template entries
 */
export function deduplicateParameters(
  tools: ToolSchema[]
): KnowledgeTemplateEntry[] {
  const seen = new Set<string>();
  const result: KnowledgeTemplateEntry[] = [];

  for (const tool of tools) {
    for (const paramName of tool.parameters) {
      if (!seen.has(paramName)) {
        seen.add(paramName);
        result.push({ paramName, toolGroup: tool.toolName });
      }
    }
  }

  return result;
}
