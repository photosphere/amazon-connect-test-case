# Requirements Document

## Introduction

This feature closes the remaining end-to-end usability gaps in the already-deployed Connect Agent Test Platform (a serverless CDK/TypeScript application running in AWS account 104220062740, us-east-1). The core test-execution pipeline already works: it mints a real Amazon Connect contact, drives a multi-turn conversation against a Q in Connect ORCHESTRATION agent via the session API, captures the tool sequence and a structured execution trace from ListSpans, and stores results in DynamoDB.

Three capability areas remain before the platform is usable end-to-end by a first-time deployer:

1. **Frontend Hosting / Deployment** — The CloudFront distribution serves the React/Cloudscape frontend from an S3 bucket, but the build is never uploaded, so CloudFront returns NoSuchKey for index.html. The build must be produced, uploaded, and accompanied by a runtime config.json generated from stack outputs; the CloudFront cache must be invalidated on deploy; and the Cognito hosted-UI callback URLs must include the deployed CloudFront URL.

2. **First-User Bootstrap** — There is no web UI user after deploy. An optional admin email supplied at deploy time should auto-create the first Cognito user, while deploys without an admin email must still succeed.

3. **Real AgentCore Evaluations Integration (+ local test harness)** — The Evaluation Lambda is currently a stub that always falls back to local tool-accuracy scoring, so goal-success and helpfulness scores are never produced. This feature integrates the Amazon Bedrock AgentCore Evaluations service to score each test case. Because AgentCore's `Evaluate` API only accepts OpenTelemetry spans/events with a supported instrumentation scope (not Q in Connect ListSpans output or a plain transcript), the Platform translates each captured Execution_Trace into synthetic OTel session spans, submits the session once, and lets AgentCore fan out across its evaluators (goal success = whole session, helpfulness = per turn, tool selection = per tool call). It maps and aggregates the returned scores onto the result record. When an evaluation fails, times out, or returns incomplete results, the Platform surfaces an explicit error in place of that case's scores rather than silently substituting local scoring (which would be indistinguishable from a real managed result). As a first-class requirement, it also provides a local script so the translation and evaluation integration can be exercised and iterated on from a developer machine without redeploying the stack.

### Non-Goals

- **Contact Lens transcript-on-CTR**: Enabling Contact Lens on the contact-creator flow and verifying that Q in Connect session-API transcripts land on the contact's CTR is deferred and requires separate empirical validation.
- **Local debug helper cleanup**: Deleting local investigation scripts (trace.mjs, probe*.mjs, prompt.mjs, scratch/dummy-flow.json) is housekeeping, not part of this feature.

## Glossary

- **Platform**: The Connect Agent Test Platform — the deployed serverless web application this feature extends.
- **Q_in_Connect**: Amazon Q in Connect, the session-based assistant service whose APIs (CreateSession, SendMessage, GetNextMessage, ListSpans) drive test conversations against AI agents.
- **ORCHESTRATION_Agent**: A Q in Connect AI Agent of type ORCHESTRATION, configured with tools and a system prompt, that the Platform tests.
- **ListSpans**: The Q in Connect API that returns a session's ordered spans, including `execute_tool` spans, used to derive the authoritative tool sequence and reasoning steps.
- **Execution_Trace**: The structured, ordered record of agent reasoning and tool calls (with arguments, results, and success/error status) produced by `parseSpansToTrace` from ListSpans output and persisted in DynamoDB under SK="TRACE".
- **Transcript**: The ordered sequence of conversation turns (customer and agent messages plus tool selections) recorded for a single test case execution.
- **AgentCore_Evaluations**: The Amazon Bedrock AgentCore Evaluations service that scores agent performance using built-in and custom evaluators. Its on-demand `Evaluate` API accepts `sessionSpans` — OpenTelemetry spans and events with a supported instrumentation scope (e.g. `strands.telemetry.tracer`, `opentelemetry.instrumentation.langchain`, `openinference.instrumentation.langchain`). It does NOT accept Q in Connect ListSpans output or a plain transcript directly.
- **OTel_Session_Spans**: The OpenTelemetry-formatted spans and events (with a supported scope, `invoke_agent` and `execute_tool` span shapes, and `input`/`output` message event bodies) that the Platform synthesizes from a captured Execution_Trace in order to submit a session to AgentCore_Evaluations.
- **Evaluator_Granularity**: The unit each evaluator scores. Session-level evaluators (e.g. `Builtin.GoalSuccessRate`) score the whole conversation; trace-level evaluators (e.g. `Builtin.Helpfulness`) score each assistant turn; tool-level evaluators (e.g. `Builtin.ToolSelectionAccuracy`) score each tool call. AgentCore fans the evaluation out across these units from a single submitted session.
- **Builtin_Evaluator**: A pre-configured AgentCore evaluator referenced as `Builtin.EvaluatorName` (for example `Builtin.Helpfulness`, `Builtin.GoalSuccessRate`) whose model and prompt configuration cannot be modified.
- **Custom_Evaluator**: A user-defined AgentCore evaluator, either an LLM-as-a-judge evaluator (own model, instructions, and scoring schema) or a code-based evaluator (own AWS Lambda implementing deterministic checks). The ordered tool-subsequence accuracy metric is a candidate for a code-based Custom_Evaluator.
- **Evaluation_Lambda**: The backend Lambda (`src/backend/orchestration/evaluation.ts`) invoked in the EvaluateResults step of the state machine, which scores each test case result.
- **TestCaseResult**: The DynamoDB-persisted record for a single test case within a run, including the score fields `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` (each 0.0–1.0).
- **Evaluation_Error_State**: The state recorded on a TestCaseResult when AgentCore_Evaluations fails, times out, or returns an incomplete result. It carries an explicit error reason and leaves `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` unset. The results view displays this error in place of the scores. The Platform does NOT substitute local scoring in this state.
- **Evaluation_Harness**: A local script, run from a developer machine against a saved/sample transcript or a real session, that exercises the AgentCore Evaluations integration without deploying the stack.
- **Runtime_Config**: The `/config.json` document the frontend fetches at startup (see `src/frontend/src/api/config.ts`), containing `apiEndpoint`, `cognitoUserPoolId`, `cognitoClientId`, `cognitoDomain`, and `region`.
- **Web_Client**: The Cognito User Pool app client used by the interactive hosted-UI login (CDK output `UserPoolClientId`). The `cognitoClientId` field of Runtime_Config MUST reference this client.
- **M2M_Client**: The Cognito machine-to-machine app client configured with the `client_credentials` grant (CDK output `MachineClientId`), used by CI/CD. The Runtime_Config MUST NOT reference this client.
- **CloudFront_URL**: The HTTPS URL of the Platform's CloudFront distribution (CDK output `CloudFrontUrl`).
- **Frontend_Bucket**: The S3 bucket (defined in `lib/storage-construct.ts`) that CloudFront serves the frontend assets from.
- **BucketDeployment**: A CDK `aws-s3-deployment.BucketDeployment` construct that uploads assets to an S3 bucket and optionally invalidates a CloudFront distribution.
- **Admin_Email**: An optional email address supplied at deploy time (CDK context parameter or stack prop) used to auto-create the first Cognito Web_Client user.
- **Deployer**: A person or automated pipeline that runs `cdk deploy` to provision or update the Platform.
- **Test_Run**: An execution of a Test Suite, identified by a run id and a timestamp and associated with its suite id, against which results and scores are recorded. Run creation, history, and two-run selection already exist in the base Platform.
- **Score_Delta**: For a given metric (`goalSuccessScore`, `helpfulnessScore`, or `toolAccuracyScore`) and a test case present in two compared runs, the later run's value minus the earlier run's value, classified as improved (> 0), regressed (< 0), or unchanged (= 0).
- **Span_Fixture**: A real ListSpans payload captured from an actual completed test session and saved as a checked-in test fixture, used to validate that the trace-to-OTel translation and downstream score processing behave correctly against genuine data (not just synthetic samples).

## Requirements

### Requirement 1: Frontend Build Upload to S3

**User Story:** As a deployer, I want the frontend build to be uploaded to the S3 bucket during deploy, so that CloudFront serves the application instead of returning NoSuchKey.

#### Acceptance Criteria

1. WHEN the CDK stack is deployed, THE Platform SHALL upload all files and subdirectories within the frontend build output directory (`src/frontend/dist`), recursively including nested asset subdirectories, to the Frontend_Bucket using a BucketDeployment construct, preserving the relative directory structure of the build output.
2. WHEN the CDK stack is deployed, THE Platform SHALL ensure the Frontend_Bucket contains an `index.html` object at the bucket root so that the CloudFront default root object resolves successfully.
3. WHEN a user requests the CloudFront_URL root path after deployment completes, THE Platform SHALL return the frontend `index.html` document with an HTTP 200 response.
4. IF, at deploy time before any frontend asset is uploaded, the frontend build output directory (`src/frontend/dist`) does not exist or contains no `index.html` at its root, THEN THE Platform SHALL fail the deployment with an error message identifying the missing build output and SHALL NOT modify the existing contents of the Frontend_Bucket.
5. WHEN a user navigates to a client-side route under the CloudFront_URL, THE Platform SHALL serve the `index.html` document via the existing 403/404 SPA fallback and return an HTTP 200 response so that client-side routing resolves.

### Requirement 2: CloudFront Cache Invalidation on Deploy

**User Story:** As a deployer, I want the CloudFront cache invalidated when I deploy new frontend assets, so that users receive the latest build instead of stale cached files.

#### Acceptance Criteria

1. WHEN the BucketDeployment uploads frontend assets to the Frontend_Bucket, THE Platform SHALL create a CloudFront cache invalidation covering path pattern `/*` on the CloudFront distribution that serves the CloudFront_URL.
2. WHEN a deploy that changes frontend assets completes successfully, THE Platform SHALL return the byte-identical newly uploaded asset content, and not any previously cached version, in response to every request to the CloudFront_URL issued after deploy completion.
3. WHILE a deploy that changes frontend assets is running, THE Platform SHALL block reporting the deploy as successful until the CloudFront cache invalidation for path pattern `/*` reaches completed status.
4. IF the CloudFront cache invalidation cannot be created or does not reach completed status within 30 minutes during deployment, THEN THE Platform SHALL fail the deployment with an error message identifying the invalidation failure and SHALL NOT report the deploy as successful.

### Requirement 3: Runtime Config Generation and Upload

**User Story:** As a deployer, I want the deploy to generate and upload config.json from stack outputs, so that the frontend loads the correct API endpoint and Cognito settings without a rebuild.

#### Acceptance Criteria

1. WHEN the CDK stack is deployed, THE Platform SHALL generate a `config.json` document and upload it to the root key of the Frontend_Bucket so that it is served at the path `/config.json` through CloudFront.
2. THE Platform SHALL populate `config.json` with the fields `apiEndpoint`, `cognitoUserPoolId`, `cognitoClientId`, `cognitoDomain`, and `region`, each set to a non-empty string value sourced from the corresponding stack output.
3. THE Platform SHALL set the `config.json` `cognitoClientId` field to the Web_Client identifier (`UserPoolClientId`) and SHALL NOT set it to the M2M_Client identifier (`MachineClientId`).
4. WHEN the frontend fetches `/config.json` at startup, THE Platform SHALL return an HTTP 200 response containing a valid JSON document whose `apiEndpoint` equals the deployed API Gateway prod-stage invoke URL and whose `region` equals the AWS Region into which the stack is deployed.
5. WHEN frontend assets and `config.json` are uploaded in the same deploy, THE Platform SHALL retain `config.json` in the Frontend_Bucket after the asset upload completes, so that uploading the build does not delete the generated configuration.
6. IF any stack output required to populate the `config.json` fields is missing or empty at deploy time, THEN THE Platform SHALL fail the deployment with an error message identifying the missing output and SHALL NOT upload an incomplete `config.json` to the Frontend_Bucket.

### Requirement 4: Cognito Callback URLs Include CloudFront

**User Story:** As a platform user, I want the hosted-UI login to redirect back to the deployed CloudFront URL, so that the sign-in round-trip completes from the hosted application.

#### Acceptance Criteria

1. WHEN the CDK stack is deployed, THE Platform SHALL register the CloudFront_URL as an allowed callback URL on the Cognito Web_Client.
2. WHEN the CDK stack is deployed, THE Platform SHALL register the CloudFront_URL as an allowed logout URL on the Cognito Web_Client.
3. WHEN a user initiates hosted-UI sign-in from the CloudFront_URL and completes authentication successfully, THE Platform SHALL redirect the user to a registered CloudFront_URL callback target and establish an authenticated session that grants access to the Web_Client's protected views.
4. WHERE a deployer provides additional callback URLs via the `callbackUrls` context parameter, THE Platform SHALL register each provided URL in addition to the CloudFront_URL, registering each unique URL exactly once.
5. IF a user initiates hosted-UI sign-in from the CloudFront_URL and authentication does not complete successfully, THEN THE Platform SHALL redirect the user to a registered CloudFront_URL target without establishing an authenticated session and SHALL present an indication that sign-in did not complete.
6. IF a callback URL provided via the `callbackUrls` context parameter is empty or is not a well-formed absolute URL, THEN THE Platform SHALL fail the deployment with an error indicating the invalid callback URL and SHALL NOT register any callback URLs from that parameter.

### Requirement 5: Hosted Frontend End-to-End Operation

**User Story:** As a platform user, I want to load the CloudFront URL, sign in, and use the application, so that I can operate the platform entirely from the hosted UI.

#### Acceptance Criteria

1. WHEN a user loads the CloudFront_URL in a browser, THE Platform SHALL fetch Runtime_Config and display the Cloudscape application interface within 5 seconds.
2. WHILE a user holds an authenticated Cognito session, WHEN the frontend has loaded Runtime_Config, THE Platform SHALL issue API requests to the `apiEndpoint` from Runtime_Config that carry the access token from the user's authenticated Cognito session.
3. WHEN an authenticated user invokes an API-backed view (such as listing agents, suites, or runs), THE Platform SHALL return the requested data within 10 seconds using the `apiEndpoint` and Cognito settings from the injected Runtime_Config, without relying on any locally provided (build-time) environment variables.
4. IF `/config.json` cannot be loaded by the frontend at startup due to a network failure, an unsuccessful response, or a malformed document, THEN THE Platform SHALL display an error state indicating that runtime configuration is unavailable, retain the user on the current page, and SHALL NOT issue API requests using an undefined `apiEndpoint`.
5. WHEN an unauthenticated user loads the CloudFront_URL, THE Platform SHALL redirect the user to the Cognito hosted-UI sign-in page.
6. IF an authenticated API request to the `apiEndpoint` returns an authorization failure (such as a missing or expired token), THEN THE Platform SHALL display an error state and prompt the user to re-authenticate through the Cognito hosted UI.

### Requirement 6: Optional Admin User Bootstrap on Deploy

**User Story:** As a deployer, I want to optionally provide an admin email at deploy time to auto-create the first Cognito user, so that the web interface has a usable login without manual console steps.

#### Acceptance Criteria

1. WHERE a Deployer provides a valid Admin_Email value via CDK context parameter or stack prop, THE Platform SHALL create exactly one corresponding user in the Cognito User Pool during deployment via an AdminCreateUser operation.
2. WHEN the Platform creates the bootstrapped user from the Admin_Email, THE Platform SHALL trigger the Cognito temporary-password email to the Admin_Email address.
3. WHEN the bootstrapped user signs in through the hosted UI with the temporary password, THE Platform SHALL enforce the force-change-password flow and SHALL NOT grant access to the application until the password change completes.
4. WHERE a Deployer provides a valid Admin_Email value, THE Platform SHALL create the bootstrapped user with the Admin_Email as the user's email attribute and sign-in identifier, consistent with the user pool's email sign-in alias configuration.
5. IF a user with the provided Admin_Email already exists in the user pool, THEN THE Platform SHALL complete the deployment successfully without overwriting the existing user's credentials or password-change status.
6. IF a Deployer provides an Admin_Email value that is not a valid email address (defined as a non-empty local part, a single "@" separator, and a domain containing at least one "."), THEN THE Platform SHALL fail the deployment with an error indicating that the Admin_Email is invalid and SHALL NOT create a Cognito user.
7. WHEN the Platform creates the bootstrapped user from the Admin_Email, THE Platform SHALL configure the user account to require a password change on first sign-in.

### Requirement 7: Deploy Succeeds Without Admin Email

**User Story:** As a CI/CD operator, I want deploys to succeed when no admin email is provided, so that automated deploys do not fail on the bootstrap step.

#### Acceptance Criteria

1. IF no Admin_Email value is provided at deploy time (the Admin_Email CDK context parameter and stack prop are both absent, empty, or contain only whitespace), THEN THE Platform SHALL skip the Cognito Web_Client user-creation step and SHALL complete the deployment to a CREATE_COMPLETE or UPDATE_COMPLETE state with no bootstrap-related resource reported as failed.
2. WHEN a deployment completes without an Admin_Email, THE Platform SHALL provision every resource other than the bootstrapped Cognito Web_Client user identically to a deployment that includes an Admin_Email, such that the CloudFront_URL serves the frontend and the API Gateway endpoint accepts authenticated requests.
3. WHEN the Admin_Email parameter changes between deploys from absent to a non-empty value, or from one non-empty value to a different non-empty value, THE Platform SHALL converge the stack to the requested state and complete the deployment to an UPDATE_COMPLETE state without failing on the user-bootstrap step.
4. WHEN the Admin_Email parameter changes between deploys from a non-empty value to absent, empty, or whitespace-only, THE Platform SHALL complete the deployment to an UPDATE_COMPLETE state, skip the user-creation step, and SHALL NOT delete or disable any Cognito Web_Client user created by a prior deploy.

### Requirement 8: AgentCore Evaluations Integration

**User Story:** As a tester, I want each test case scored by the real AgentCore Evaluations service, so that runs produce managed goal-success and helpfulness scores instead of only local tool accuracy.

#### Acceptance Criteria

1. WHEN the Evaluation_Lambda processes a test case result, THE Platform SHALL submit the test case session exactly once to AgentCore_Evaluations and SHALL request the `Builtin.GoalSuccessRate` (session-level), `Builtin.Helpfulness` (trace-level), and `Builtin.ToolSelectionAccuracy` (tool-level) built-in evaluators.
2. THE Platform SHALL replace the stub `callAgentCoreEvaluation` implementation with a real call to AgentCore_Evaluations using an AWS SDK client pinned to a fixed (exact) version and bundled with the Evaluation_Lambda.
3. WHEN AgentCore_Evaluations returns scores for a test case, THE Platform SHALL map the session-level goal-attainment result to `goalSuccessScore`, aggregate the per-turn helpfulness results into `helpfulnessScore`, and aggregate the per-tool-call tool-selection results into `toolAccuracyScore` on the TestCaseResult, each normalized to a decimal value in the inclusive range 0.0–1.0, with any value below 0.0 stored as 0.0 and any value above 1.0 stored as 1.0.
4. THE Platform SHALL document the aggregation method used to reduce per-turn and per-tool-call evaluator results into a single `helpfulnessScore` and a single `toolAccuracyScore`, and SHALL apply that method consistently.
5. WHEN AgentCore_Evaluations returns scores for a test case, THE Platform SHALL persist the mapped scores to the TestCaseResult DynamoDB item (PK=`RUN#{runId}`, SK=`CASE#{caseId}`).
6. WHEN a test run completes with AgentCore scoring applied, THE Platform SHALL display the `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` for each scored test case in the results view, each shown as a numeric value within the inclusive range 0.0–1.0.
7. IF AgentCore_Evaluations returns one requested evaluator result for a test case but omits another, THEN THE Platform SHALL store the returned score(s) on the TestCaseResult, set the Evaluation_Error_State with an error reason identifying the omitted evaluator, and complete processing of that test case without marking the run failed.

### Requirement 9: Execution Trace Translation to OTel Session Spans

**User Story:** As a tester, I want the agent's captured session data translated into the OpenTelemetry span/event format AgentCore requires, so that the managed evaluators can score the actual conversation and tool usage.

#### Acceptance Criteria

1. WHEN the Evaluation_Lambda prepares a test case for AgentCore_Evaluations, THE Platform SHALL synthesize OTel_Session_Spans from the captured Execution_Trace and Transcript, emitting one `invoke_agent`-style span per assistant turn and one `execute_tool`-style span per tool call, preserving their recorded chronological order under a single session identifier.
2. THE Platform SHALL set a supported instrumentation scope name on the synthesized OTel_Session_Spans and SHALL include the corresponding span events with `input`/`output` message bodies, so that AgentCore_Evaluations accepts the submission without a validation error.
3. THE Platform SHALL populate each `execute_tool`-style span with the tool name, the arguments the agent supplied, and the tool result captured in the Execution_Trace, and SHALL include the set of available tools (from the agent snapshot) required by tool-level and session-level evaluators.
4. THE Platform SHALL include, in the data submitted for the session, the expected tool sequence (the ordered tool names from the test case success criteria) so that tool-selection scoring can be assessed against the test case's intended behavior.
5. IF the captured Execution_Trace contains no `execute_tool` spans and no assistant turns, THEN THE Platform SHALL treat the session as not submittable and set the Evaluation_Error_State with an error reason indicating insufficient trace data, and SHALL NOT substitute local scoring.
6. THE Platform SHALL implement the trace-to-OTel translation as a standalone, unit-testable module so that the synthesized OTel_Session_Spans can be validated against the AgentCore input schema without a deploy.

### Requirement 10: Evaluation Error Surfacing (No Silent Fallback)

**User Story:** As a tester, I want evaluation failures surfaced as explicit errors in place of scores, so that I never mistake a degraded or inconsistent result for a real AgentCore evaluation.

#### Acceptance Criteria

1. IF AgentCore_Evaluations does not return a result for a test case within 60 seconds of the evaluation submission, THEN THE Platform SHALL set the Evaluation_Error_State on that TestCaseResult with an error reason indicating a timeout, and SHALL NOT substitute local scoring.
2. IF AgentCore_Evaluations returns an error response for a test case, or returns a result that cannot be mapped to valid scores, THEN THE Platform SHALL set the Evaluation_Error_State on that TestCaseResult with an error reason describing the failure, and SHALL NOT substitute local scoring.
3. WHEN the Evaluation_Error_State is set on a TestCaseResult, THE Platform SHALL leave `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` unset (no numeric value).
4. WHEN the Evaluation_Error_State is set on a TestCaseResult, THE Platform SHALL display the recorded error reason in the results view in place of the score values for that test case.
5. WHEN one or more test cases enter the Evaluation_Error_State, THE Platform SHALL complete the run, SHALL persist a TestCaseResult for every test case, and SHALL NOT mark the run itself as failed solely because individual cases entered the Evaluation_Error_State.
6. THE Platform SHALL NOT compute or persist `toolAccuracyScore` from the local `calculateToolAccuracy` logic as a substitute for an AgentCore_Evaluations result in any test case's scored output.

### Requirement 11: Local AgentCore Evaluation Harness

**User Story:** As a developer, I want to run the AgentCore evaluation integration from a local script against a saved or live session, so that I can iterate on evaluation logic without redeploying the stack for every change.

#### Acceptance Criteria

1. THE Platform SHALL provide a local Evaluation_Harness script that invokes the AgentCore_Evaluations integration from a developer machine without requiring a CDK deploy.
2. WHEN a developer runs the Evaluation_Harness against a saved or sample transcript file, THE Evaluation_Harness SHALL translate it into OTel_Session_Spans, submit them to AgentCore_Evaluations, and print the returned `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore`.
3. WHERE a developer supplies a Q in Connect session identifier, THE Evaluation_Harness SHALL retrieve the session Execution_Trace via ListSpans and submit it to AgentCore_Evaluations for evaluation.
4. THE Evaluation_Harness SHALL invoke the same evaluation submission and score-mapping code path used by the Evaluation_Lambda, so that local results are representative of deployed behavior.
5. IF AgentCore_Evaluations returns an error or does not respond within the configured request timeout (default 60 seconds), THEN THE Evaluation_Harness SHALL print the failure reason and exit with a non-zero status.
6. THE Evaluation_Harness SHALL accept its input source as a command-line argument that is either a transcript file path or a Q in Connect session identifier.
7. IF the Evaluation_Harness is invoked without a valid input source, THEN THE Evaluation_Harness SHALL print usage guidance and exit with a non-zero status.
8. IF the specified transcript file does not exist or cannot be parsed as a valid transcript, THEN THE Evaluation_Harness SHALL print an error message identifying the invalid input and exit with a non-zero status without submitting to AgentCore_Evaluations.
9. IF the supplied session identifier cannot be resolved or ListSpans returns no Execution_Trace spans, THEN THE Evaluation_Harness SHALL print an error message indicating the Execution_Trace could not be retrieved and exit with a non-zero status without submitting to AgentCore_Evaluations.

### Requirement 12: Idempotent and Repeatable Deployment

**User Story:** As a deployer, I want deploys to remain idempotent and repeatable, so that re-running a deploy converges to the same state without manual cleanup.

#### Acceptance Criteria

1. WHEN a Deployer runs `cdk deploy` two or more consecutive times with identical context parameters, stack props, and frontend build output, THE Platform SHALL complete each deploy after the first with a success status and SHALL report zero resource additions, replacements, or deletions for those subsequent deploys, without requiring manual resource creation or deletion between deploys.
2. WHEN frontend assets are unchanged between deploys, THE Platform SHALL retain the existing Frontend_Bucket objects (including `index.html` and `config.json`) and SHALL keep the CloudFront_URL returning `index.html` with an HTTP 200 response throughout and after the deploy.
3. IF a `cdk deploy` execution fails, THEN THE Platform SHALL roll the CloudFormation stack back to its last successful deployed state, SHALL leave no resources created during that execution in place, and SHALL exit with a non-zero status and an error message identifying the failure.
4. WHEN a Deployer runs `cdk deploy` with unchanged inputs, THE Platform SHALL preserve the resource identifiers of the Frontend_Bucket, CloudFront distribution, Cognito User Pool, Web_Client, and M2M_Client across deploys and SHALL NOT delete and recreate those resources.
5. IF a `cdk deploy` execution fails after frontend assets were uploaded, THEN THE Platform SHALL leave the previously served frontend content intact so that the CloudFront_URL continues to return `index.html` with an HTTP 200 response.

### Requirement 13: No Secrets in the Frontend Bundle

**User Story:** As a security reviewer, I want the deployed frontend to contain no secrets, so that publicly served assets cannot leak credentials.

#### Acceptance Criteria

1. THE Platform SHALL exclude the M2M_Client secret and any Secrets Manager secret values from the frontend assets and from `config.json`.
2. THE Platform SHALL limit `config.json` to non-secret runtime configuration values (`apiEndpoint`, `cognitoUserPoolId`, `cognitoClientId`, `cognitoDomain`, `region`).
3. THE Platform SHALL reference the Web_Client (which has no client secret) in `config.json` so that no client secret is embedded in publicly served assets.

### Requirement 14: Least-Privilege Credentials for the Evaluation Harness

**User Story:** As a security reviewer, I want the local evaluation harness to run with least-privilege credentials, so that local iteration does not require broad or production-admin access.

#### Acceptance Criteria

1. THE Evaluation_Harness SHALL invoke only the AWS operations required to call AgentCore_Evaluations and to read Q in Connect session spans via ListSpans, and SHALL complete successfully when run under credentials scoped to only those operations.
2. THE Evaluation_Harness SHALL obtain AWS credentials from the developer's environment (such as a named profile or environment credentials).
3. THE Evaluation_Harness SHALL NOT contain embedded or hardcoded long-lived AWS credentials in source.
4. IF no AWS credentials are available in the developer's environment when the Evaluation_Harness runs, THEN THE Evaluation_Harness SHALL report that credentials are missing and exit with a non-zero status without invoking any AWS operation.
5. IF the supplied credentials are denied permission to call AgentCore_Evaluations or ListSpans, THEN THE Evaluation_Harness SHALL report which operation was denied, SHALL NOT silently fall back to partial or local-only scoring, and SHALL exit with a non-zero status.

### Requirement 15: Score-Aware Run Comparison

**User Story:** As a tester, I want the two-run comparison to show per-metric score deltas, so that I can see at a glance which evaluation scores improved or regressed after an agent change.

> Note: Run creation (with run id, timestamp, and suite id), run history, two-run selection, status-change classification (passed/failed/added/removed), and agent-config diff already exist in the base Platform (Requirement 13 of the connect-agent-test-platform spec). This requirement layers score deltas on top of that existing comparison and is limited to that addition.

#### Acceptance Criteria

1. WHEN a user selects two test runs for comparison, THE Platform SHALL, for each test case present in both runs, compute the per-metric delta for `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` as the later run's value minus the earlier run's value.
2. WHEN the comparison view displays a per-metric delta for a test case, THE Platform SHALL classify each metric as improved (delta greater than 0), regressed (delta less than 0), or unchanged (delta equal to 0), and SHALL visually distinguish the three classifications.
3. WHERE a metric score is present in one of the two runs but absent in the other (including a run whose case is in the Evaluation_Error_State), THE Platform SHALL display the delta as not-comparable for that metric rather than computing a numeric delta.
4. WHEN a user views the two-run comparison, THE Platform SHALL display a suite-level summary of how many test cases improved, regressed, and were unchanged for each metric.
5. WHEN a user views the results view for a single run, THE Platform SHALL display the `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` for each scored test case, and SHALL display the recorded error reason in place of the scores for any case in the Evaluation_Error_State.
6. THE Platform SHALL implement the per-metric delta and improved/regressed/unchanged classification as a standalone, unit-testable function so that score-comparison correctness can be verified without a deploy.

### Requirement 16: Validation Against Real Captured Spans

**User Story:** As a developer, I want the trace-to-OTel translation and score processing validated against real captured spans, so that I have confidence the implementation works on genuine data and not just synthetic samples.

#### Acceptance Criteria

1. THE Platform SHALL include at least two Span_Fixtures captured from real completed test sessions (for example, a multi-tool success session and a failure/escalation session) as checked-in test fixtures.
2. THE Platform SHALL provide an automated test that runs the trace-to-OTel translation against each Span_Fixture and asserts that the synthesized OTel_Session_Spans conform to the AgentCore input schema (required fields, supported scope, matched span/event pairing).
3. WHEN the translation runs against a Span_Fixture, THE test SHALL assert that every `execute_tool` entry in the source trace is represented as a tool-level span and every assistant turn is represented as a trace-level span, with order preserved.
4. WHEN the Evaluation_Harness is run against a Span_Fixture, THE Evaluation_Harness SHALL submit the translated session to AgentCore_Evaluations and report the returned per-metric scores, so a developer can confirm end-to-end processing on real data.
5. WHERE a Span_Fixture is derived from a real session, THE Platform SHALL redact or use non-production placeholder values for any sensitive customer data (for example, phone number and SSN-last-four) in the checked-in fixture.
