// Feature: trace-reasoning-and-latency, Property 11: Duration label formatting
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { formatDuration } from "../../../src/frontend/src/components/Transcript/TimelineTranscript";

/**
 * **Validates: Requirements 6.1**
 *
 * Property 11: Duration label formatting
 *
 * For any integer `d` in [0, 86400000]:
 * - if d < 1000, the formatted label is `"${d} ms"`
 * - if d >= 1000, the formatted label is `"${(d/1000).toFixed(1)} s"` (half-up rounding)
 *
 * The function is total and never throws for any input in the domain.
 * Returns null for inputs outside [0, 86400000] or non-numeric inputs.
 */

describe("Feature: trace-reasoning-and-latency, Property 11: Duration label formatting", () => {
  // -------------------------------------------------------------------------
  // Property: sub-second durations format as "${d} ms"
  // -------------------------------------------------------------------------
  it("formats integers in [0, 999] as '${d} ms'", () => {
    fc.assert(
      fc.property(fc.integer({ min: 0, max: 999 }), (d) => {
        const result = formatDuration(d);
        expect(result).toBe(`${d} ms`);
      }),
      { numRuns: 100 }
    );
  });

  // -------------------------------------------------------------------------
  // Property: durations >= 1000 format as "${(d/1000).toFixed(1)} s"
  // -------------------------------------------------------------------------
  it("formats integers in [1000, 86400000] as '${(d/1000).toFixed(1)} s'", () => {
    fc.assert(
      fc.property(fc.integer({ min: 1000, max: 86400000 }), (d) => {
        const result = formatDuration(d);
        expect(result).toBe(`${(d / 1000).toFixed(1)} s`);
      }),
      { numRuns: 100 }
    );
  });

  // -------------------------------------------------------------------------
  // Property: function is total — never throws for any integer in [0, 86400000]
  // -------------------------------------------------------------------------
  it("never throws for any integer in [0, 86400000]", () => {
    fc.assert(
      fc.property(fc.integer({ min: 0, max: 86400000 }), (d) => {
        expect(() => formatDuration(d)).not.toThrow();
        const result = formatDuration(d);
        expect(typeof result).toBe("string");
      }),
      { numRuns: 100 }
    );
  });

  // -------------------------------------------------------------------------
  // Property: returns null for negative integers
  // -------------------------------------------------------------------------
  it("returns null for negative values", () => {
    fc.assert(
      fc.property(fc.integer({ min: -1_000_000, max: -1 }), (d) => {
        expect(formatDuration(d)).toBeNull();
      }),
      { numRuns: 100 }
    );
  });

  // -------------------------------------------------------------------------
  // Property: returns null for values > 86400000
  // -------------------------------------------------------------------------
  it("returns null for values greater than 86400000", () => {
    fc.assert(
      fc.property(fc.integer({ min: 86400001, max: 100_000_000 }), (d) => {
        expect(formatDuration(d)).toBeNull();
      }),
      { numRuns: 100 }
    );
  });

  // -------------------------------------------------------------------------
  // Property: returns null for non-numeric inputs
  // -------------------------------------------------------------------------
  it("returns null for non-numeric inputs (undefined, null, NaN, Infinity)", () => {
    expect(formatDuration(undefined)).toBeNull();
    expect(formatDuration(null)).toBeNull();
    expect(formatDuration(NaN as unknown as number)).toBeNull();
    expect(formatDuration(Infinity as unknown as number)).toBeNull();
    expect(formatDuration(-Infinity as unknown as number)).toBeNull();
  });

  // -------------------------------------------------------------------------
  // Edge case verification
  // -------------------------------------------------------------------------
  it("verifies specific edge cases per design", () => {
    expect(formatDuration(0)).toBe("0 ms");
    expect(formatDuration(999)).toBe("999 ms");
    expect(formatDuration(1000)).toBe("1.0 s");
    expect(formatDuration(1550)).toBe("1.6 s");
    expect(formatDuration(1549)).toBe("1.5 s");
    expect(formatDuration(86400000)).toBe("86400.0 s");
    expect(formatDuration(-1)).toBeNull();
    expect(formatDuration(86400001)).toBeNull();
  });
});
