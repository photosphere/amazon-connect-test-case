# Design Document: Agent-Grouped Suites

## Overview

This feature transforms the Test Suites page from a flat table into an agent-grouped layout and enriches the `GET /suites` backend response with resolved agent names. The frontend groups suites under Cloudscape `ExpandableSection` headers per agent, while the backend resolves `agentId → agentName` at read time using the existing discovery logic (Connect Q `ListAIAgents`).

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  Frontend (React + Cloudscape)                                  │
│                                                                 │
│  TestSuites.tsx                                                 │
│    ├─ GET /suites → receives enriched suites with agentName     │
│    ├─ groupSuitesByAgent(suites) → Map<agentName, TestSuite[]>  │
│    ├─ Renders ExpandableSection per agent (alphabetical)        │
│    │   └─ Table per section (Name, Description, Last Run,       │
│    │      Last Updated)                                         │
│    └─ Preserves expand/collapse state across refreshes          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ GET /suites
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Backend (Lambda)                                               │
│                                                                 │
│  suites.ts handler                                              │
│    └─ listSuites(tenantId)                                      │
│         ├─ db.listSuites(tenantId)  → TestSuite[]               │
│         ├─ listAgents()             → AgentSummary[]            │
│         │   (imported from discovery.ts)                        │
│         ├─ buildAgentNameMap(agents) → Map<agentId, name>       │
│         └─ enrichWithAgentName(suites, map)                     │
│              → EnrichedTestSuite[] (agentName computed)          │
└─────────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              ▼                               ▼
┌──────────────────────┐        ┌──────────────────────────────┐
│  DynamoDB            │        │  Q in Connect                │
│  (suites, cases)     │        │  ListAIAgents API            │
└──────────────────────┘        └──────────────────────────────┘
```

## Components and Interfaces

### Backend: Agent-Name Enrichment

#### `EnrichedTestSuite` (response-only type)

```typescript
// src/shared/types.ts — addition
/** TestSuite with computed agentName for display. Never persisted. */
export interface EnrichedTestSuite extends TestSuite {
  /** Resolved agent display name; falls back to agentId if unresolvable. */
  agentName: string;
}
```

#### `buildAgentNameMap` (pure function in suites handler)

```typescript
// src/backend/handlers/suites.ts — new helper

import { listAgents } from './discovery';
import type { AgentSummary } from '../../shared/types';

/**
 * Builds a lookup map from agentId → agent display name.
 * Pure function — easy to unit test independently.
 */
function buildAgentNameMap(agents: AgentSummary[]): Map<string, string> {
  const map = new Map<string, string>();
  for (const agent of agents) {
    map.set(agent.agentId, agent.name);
  }
  return map;
}
```

#### `enrichWithAgentName` (pure function in suites handler)

```typescript
// src/backend/handlers/suites.ts — new helper

import type { TestSuite, EnrichedTestSuite } from '../../shared/types';

/**
 * Enriches each suite with agentName resolved from the map.
 * Falls back to the literal agentId when the agent is not found.
 */
function enrichWithAgentName(
  suites: TestSuite[],
  agentNameMap: Map<string, string>
): EnrichedTestSuite[] {
  return suites.map((suite) => ({
    ...suite,
    agentName: agentNameMap.get(suite.agentId) ?? suite.agentId,
  }));
}
```

#### Updated `listSuites` handler

```typescript
async function listSuites(tenantId: string): Promise<APIGatewayResponse> {
  const db = getDBService();
  const [suites, agents] = await Promise.all([
    db.listSuites(tenantId),
    listAgents(),  // imported from discovery.ts
  ]);

  const agentNameMap = buildAgentNameMap(agents);
  const enriched = enrichWithAgentName(
    suites.map(normalizeSuiteOnRead),
    agentNameMap
  );

  return jsonResponse(200, { suites: enriched });
}
```

**Error handling**: If `listAgents()` throws (Q in Connect unavailable), the handler catches it and falls back to an empty agent map — all suites get `agentName = agentId`. This preserves the page's ability to render even when the agent service is down.

```typescript
async function listSuites(tenantId: string): Promise<APIGatewayResponse> {
  const db = getDBService();
  const suites = await db.listSuites(tenantId);

  let agentNameMap: Map<string, string>;
  try {
    const agents = await listAgents();
    agentNameMap = buildAgentNameMap(agents);
  } catch (err) {
    console.warn('[suites] Failed to resolve agent names, falling back to agentId:', err);
    agentNameMap = new Map();
  }

  const enriched = enrichWithAgentName(
    suites.map(normalizeSuiteOnRead),
    agentNameMap
  );

  return jsonResponse(200, { suites: enriched });
}
```

### Frontend: Grouped Layout

#### `groupSuitesByAgent` (pure utility function)

```typescript
// src/frontend/src/utils/groupSuites.ts

import type { EnrichedTestSuite } from '../../../shared/types';

export interface AgentGroup {
  agentName: string;
  suites: EnrichedTestSuite[];
}

/**
 * Groups suites by agentName and returns groups sorted alphabetically
 * by agent name. Suites within each group preserve their original order.
 */
export function groupSuitesByAgent(suites: EnrichedTestSuite[]): AgentGroup[] {
  const map = new Map<string, EnrichedTestSuite[]>();

  for (const suite of suites) {
    const group = map.get(suite.agentName) ?? [];
    group.push(suite);
    map.set(suite.agentName, group);
  }

  return Array.from(map.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([agentName, groupSuites]) => ({ agentName, suites: groupSuites }));
}
```

#### Updated `TestSuites.tsx` component structure

The page replaces the flat `<Table>` with a list of `<ExpandableSection>` components, each containing a per-agent `<Table>`.

```typescript
// src/frontend/src/pages/TestSuites.tsx — key structural changes

import ExpandableSection from '@cloudscape-design/components/expandable-section';
import { groupSuitesByAgent, type AgentGroup } from '../utils/groupSuites';
import type { EnrichedTestSuite } from '../../../shared/types';

export function TestSuites() {
  const [suites, setSuites] = useState<EnrichedTestSuite[]>([]);
  // Track expand/collapse state per agentName; all start expanded (true).
  const [expandedAgents, setExpandedAgents] = useState<Record<string, boolean>>({});

  // After fetch, initialise any new agents as expanded
  useEffect(() => {
    const groups = groupSuitesByAgent(suites);
    setExpandedAgents((prev) => {
      const next = { ...prev };
      for (const g of groups) {
        if (!(g.agentName in next)) next[g.agentName] = true;
      }
      return next;
    });
  }, [suites]);

  const groups = groupSuitesByAgent(suites);

  return (
    <ContentLayout header={/* page header with Refresh + Create suite */}>
      <SpaceBetween size="l">
        {/* error alert */}
        {loading && <Spinner />}
        {!loading && groups.length === 0 && /* empty state */}
        {groups.map((group) => (
          <ExpandableSection
            key={group.agentName}
            headerText={`${group.agentName} (${group.suites.length} suite${group.suites.length !== 1 ? 's' : ''})`}
            expanded={expandedAgents[group.agentName] ?? true}
            onChange={({ detail }) =>
              setExpandedAgents((prev) => ({
                ...prev,
                [group.agentName]: detail.expanded,
              }))
            }
          >
            <Table
              columnDefinitions={perAgentColumnDefs}
              items={group.suites}
              trackBy="suiteId"
              selectionType="single"
              /* selection + actions (Run, Delete) scoped to this table */
            />
          </ExpandableSection>
        ))}
      </SpaceBetween>
    </ContentLayout>
  );
}
```

#### Per-agent table columns

| Column | Source | Notes |
|--------|--------|-------|
| Suite Name | `suite.name` | Link to `/suites/{suiteId}` |
| Description | `suite.description` | Truncated or `—` if empty |
| Last Run | `lastRuns[suiteId]` | StatusIndicator + View link (existing logic) |
| Last Updated | `suite.updatedAt` | Formatted via `toLocaleString()` |

No "Agent ID" column — the grouping header conveys agent association.

#### Selection and actions

Each per-agent table supports single-row selection. The Run suite, Delete, and Edit actions operate on the selected suite within that table. Selection state is per-table (only one suite can be selected at a time across the page — selecting in one table clears selection in others).

## Data Models

No DynamoDB schema changes. The `agentName` field is computed at read time in the Lambda response and never written to the table.

**Response shape change for `GET /suites`:**

```typescript
// Before
{ suites: TestSuite[] }

// After
{ suites: EnrichedTestSuite[] }
// where EnrichedTestSuite = TestSuite & { agentName: string }
```

This is a backward-compatible additive change — existing consumers that don't read `agentName` continue working.

## Error Handling

| Failure | Backend behavior | Frontend behavior |
|---------|------------------|-------------------|
| `listAgents()` throws | Catch, log warning, use empty map → all suites get `agentName = agentId` | Renders correctly (groups by agent ID strings) |
| DynamoDB `listSuites` throws | 500 returned | Shows error alert with Retry |
| Single suite's last-run fetch fails | N/A (frontend concern) | That suite shows spinner briefly, then "Never run" |
| Empty suites list | Returns `{ suites: [] }` | Empty state with "Create suite" CTA |

## Testing Strategy

### Unit Tests (Example-based)

- Backend: Verify `listSuites` calls `listAgents` and returns enriched response (integration mock)
- Frontend: Verify ExpandableSection expand/collapse interaction (2.3)
- Frontend: Verify per-agent table columns match spec — no Agent ID column (2.5, 2.6)
- Frontend: Verify suite name link navigates to `/suites/{suiteId}` (3.1)
- Frontend: Verify Create suite, Run suite, Delete, Refresh actions (3.2–3.5)
- Frontend: Verify loading, empty, and error states (4.1–4.4)

### Property-Based Tests

- `enrichWithAgentName` — Properties 1, 2 (enrichment correctness + fallback)
- `groupSuitesByAgent` — Properties 4, 5, 6 (grouping count, suite count, ordering)
- Expand/collapse state logic — Properties 7, 8 (initial expanded state, preservation)

### Integration Tests

- `GET /suites` end-to-end with mocked DynamoDB + mocked Q in Connect (Property 3: agentName not persisted)
- `GET /suites` graceful degradation when `listAgents` throws

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Agent name enrichment correctness

*For any* list of suites and any agent listing where the agent's `agentId` matches the suite's `agentId`, the enriched suite's `agentName` SHALL equal the agent's `name` field.

**Validates: Requirements 1.1**

### Property 2: Agent name fallback to agentId

*For any* suite whose `agentId` does NOT appear in the agent listing (empty list, missing agent, or API failure), the enriched suite's `agentName` SHALL equal the literal `agentId` string.

**Validates: Requirements 1.2**

### Property 3: agentName is never persisted

*For any* suite created or updated via the Suites API, the DynamoDB record SHALL NOT contain an `agentName` attribute.

**Validates: Requirements 1.4**

### Property 4: Grouping produces one section per distinct agentName

*For any* non-empty list of enriched suites, the `groupSuitesByAgent` function SHALL return exactly as many groups as there are distinct `agentName` values in the input, and each group's `agentName` SHALL match one of those distinct values.

**Validates: Requirements 2.1, 2.2**

### Property 5: Suite count in group header is accurate

*For any* group returned by `groupSuitesByAgent`, the length of the group's `suites` array SHALL equal the number of input suites that share that group's `agentName`.

**Validates: Requirements 2.4**

### Property 6: Groups are alphabetically ordered

*For any* list of enriched suites, the groups returned by `groupSuitesByAgent` SHALL be sorted in ascending lexicographic order by `agentName`.

**Validates: Requirements 5.1**

### Property 7: All sections expanded on initial render

*For any* set of distinct agent names derived from the suites response, the initial `expandedAgents` state SHALL map every agent name to `true`.

**Validates: Requirements 5.2**

### Property 8: Collapse state preserved across refresh

*For any* agent section that a user has collapsed (set to `false` in `expandedAgents`), after a refresh re-fetches suites and re-computes groups, that agent's expanded state SHALL remain `false` if the agent still appears in the new data.

**Validates: Requirements 5.3**
