/**
 * Failure Analysis page — the canonical full-detail view for per-case
 * recommendations (R11.4). Reachable from the Results Viewer.
 *
 * Behavior in this revision (actionable-recommendations task 10.3):
 *
 *   - The mount-time fetch is a POST to `/runs/{runId}/analyze` WITHOUT
 *     `force`. The Lambda's persisted-read shortcut returns the records
 *     without re-invoking Bedrock when an analysis already exists for
 *     every failed case in the run (R6.2, R10.9, R11.1).
 *   - The "Re-analyze" header action POSTs `{ force: true, suiteId? }`,
 *     overwrites the persisted records, and refreshes local state on
 *     success (R11.3).
 *   - The page reads the new flat `caseAnalyses[]` response shape from
 *     `analysis.ts` (the legacy `individualAnalyses` / `groupedAnalyses`
 *     split has been retired). Group-by-root-cause runs client-side via
 *     the shared `failure-grouping` util so this page and the
 *     Recommended_Changes_Panel share one canonical implementation
 *     (R11.1, R13.1).
 *   - The `Recommendation` and `FailureCaseAnalysis` types are imported
 *     from `src/shared/types.ts` and `src/shared/utils/failure-grouping.ts`
 *     so there is exactly one canonical shape across the codebase
 *     (R13.1).
 *   - The "Re-analyze to incorporate the now-captured examples" banner
 *     surfaces when the persisted analysis predates the examples-aware
 *     snapshot — detected by reading `GET /runs/{runId}/snapshot` and
 *     finding every tool's `examples` array missing or empty (R12.6).
 *   - The inline notice listing the failed-to-persist case IDs from
 *     `partialFailures` surfaces alongside the rendered analyses (R12.5).
 *
 * The page MUST NOT compute recommendations independently — every render
 * branch reads from the persisted record (R11.1).
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@cloudscape-design/components/header';
import Container from '@cloudscape-design/components/container';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import Alert from '@cloudscape-design/components/alert';
import StatusIndicator from '@cloudscape-design/components/status-indicator';
import Spinner from '@cloudscape-design/components/spinner';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import Badge from '@cloudscape-design/components/badge';
import Link from '@cloudscape-design/components/link';
import Tabs from '@cloudscape-design/components/tabs';
import { apiClient, ApiClientError, getConfig } from '../api';
import type {
  AgentSnapshot,
  Recommendation,
  ToolSurface,
} from '../../../shared/types';
import {
  groupFailuresByRootCause,
  type FailureCaseAnalysis,
  type FailureGroup,
} from '../../../shared/utils/failure-grouping';
import { RunStatus } from '../../../shared/enums';
import { ImplementButton } from '../components/ImplementRecommendations';

// ---------------------------------------------------------------------------
// Wire-format response types — mirror backend `analysis.ts` shapes
// ---------------------------------------------------------------------------

/**
 * Per-case analysis as persisted under
 * `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` and returned in the
 * `caseAnalyses[]` array of {@link AnalyzeResponse}. Mirrors
 * `PerCaseAnalysis` exported by `src/backend/handlers/analysis.ts`.
 *
 * The display-time grouping uses `FailureCaseAnalysis` from the shared
 * `failure-grouping` util — this wire-format type is its superset
 * (carries `generatedAt` / `modelId` metadata the grouping helper does
 * not need).
 */
interface PerCaseAnalysis {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;
  recommendations: Recommendation[];
  generatedAt: string;
  modelId: string;
}

/** Response body for `POST /runs/{runId}/analyze`. */
interface AnalyzeResponse {
  caseAnalyses: PerCaseAnalysis[];
  generatedAt: string;
  modelId: string;
  /** Case IDs whose Bedrock analysis succeeded but DDB persistence failed (R6.6). */
  partialFailures?: string[];
}

/** Response body for `GET /runs/{runId}/snapshot`. */
interface SnapshotResponse {
  snapshot: AgentSnapshot;
}

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface FailureAnalysisProps {
  runId: string;
  suiteId?: string;
  /** The agent ID for this run's suite. Required for the ImplementButton. */
  agentId?: string;
  /** Run status — used to control ImplementButton visibility. */
  runStatus?: string;
}

// ---------------------------------------------------------------------------
// Display helpers
// ---------------------------------------------------------------------------

function formatCategory(category: string): string {
  return category
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function categoryBadgeColor(category: string): 'red' | 'blue' | 'grey' {
  switch (category) {
    case 'overlapping_tool_descriptions':
    case 'incorrect_tool_prioritization':
      return 'red';
    case 'missing_disambiguation':
    case 'system_prompt_gap':
    case 'missing_tool_instruction':
    case 'incomplete_tool_description':
      return 'blue';
    default:
      return 'grey';
  }
}

/**
 * Human-readable label for a {@link ToolSurface} value. Includes
 * `tool_examples` per the actionable-recommendations Tool_Surface
 * extension (R5.1, R13.1). Falls back to the raw string for any
 * unrecognized value so a contract violation is visible rather than
 * silently rendered as a blank header.
 */
function targetFieldLabel(field: ToolSurface | string): string {
  switch (field) {
    case 'tool_description':
      return 'Tool Description';
    case 'tool_instruction':
      return 'Tool Instruction';
    case 'tool_examples':
      return 'Tool Examples';
    case 'system_prompt':
      return 'System Prompt';
    default:
      return String(field);
  }
}

/**
 * True iff every tool in the snapshot has no `examples` field on its
 * persisted record (R12.6 cue — pre-feature snapshots). Mirrors the
 * detection logic used by `RecommendedChangesPanel.tsx` so the banner
 * surfaces consistently across both surfaces.
 *
 * The runtime snapshot read normalizes missing/null to `[]`. We can
 * only detect "predates" by checking that EVERY tool has an empty
 * examples array. False positives are possible (an agent may
 * genuinely have no examples on any tool) but the banner action is
 * non-destructive — it offers a Re-analyze — so a false positive is
 * recoverable.
 */
function snapshotPredatesExamples(snapshot: AgentSnapshot | null): boolean {
  if (!snapshot) return false;
  const tools = snapshot.tools ?? [];
  if (tools.length === 0) return false;
  return tools.every(
    (t) => !Array.isArray(t.examples) || t.examples.length === 0,
  );
}

// ---------------------------------------------------------------------------
// Diff View Component
// ---------------------------------------------------------------------------

function DiffView({ recommendation, suiteId }: { recommendation: Recommendation; suiteId?: string }) {
  const navigate = useNavigate();

  const isTestCaseRec = recommendation.targetField === 'test_case';

  return (
    <div style={{ marginBottom: '12px' }}>
      <SpaceBetween size="xs">
        <Box variant="small">
          {isTestCaseRec ? (
            <SpaceBetween direction="horizontal" size="xs">
              <Badge color="blue">Fix test</Badge>
              {recommendation.testCaseField && (
                <span style={{ color: '#5f6b7a' }}>
                  · {recommendation.testCaseField}
                </span>
              )}
            </SpaceBetween>
          ) : (
            <>
              <strong>{targetFieldLabel(recommendation.targetField)}</strong>
              {recommendation.targetName !== 'system_prompt' && (
                <span style={{ marginLeft: '8px', color: '#5f6b7a' }}>
                  ({recommendation.targetName})
                </span>
              )}
            </>
          )}
        </Box>

        {/* Current text — empty render is meaningful for tool_examples add */}
        <div
          style={{
            backgroundColor: '#fdf0f0',
            border: '1px solid #d91515',
            borderRadius: '4px',
            padding: '8px 12px',
            fontFamily: 'monospace',
            fontSize: '13px',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
          }}
        >
          <Box variant="small" color="text-status-error">
            <strong>− Current</strong>
          </Box>
          {recommendation.currentText || (
            <Box variant="small" color="text-status-inactive">
              (empty)
            </Box>
          )}
        </div>

        {/* Suggested text — empty render is meaningful for tool_examples remove */}
        <div
          style={{
            backgroundColor: '#f2fcf3',
            border: '1px solid #037f0c',
            borderRadius: '4px',
            padding: '8px 12px',
            fontFamily: 'monospace',
            fontSize: '13px',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
          }}
        >
          <Box variant="small" color="text-status-success">
            <strong>+ Suggested</strong>
          </Box>
          {recommendation.suggestedText || (
            <Box variant="small" color="text-status-inactive">
              (empty)
            </Box>
          )}
        </div>

        {/* Rationale */}
        {recommendation.rationale && (
          <Box variant="small" color="text-body-secondary">
            <em>Rationale: {recommendation.rationale}</em>
          </Box>
        )}

        {/* Deep-link to test case editor for test_case recommendations */}
        {isTestCaseRec && suiteId && (
          <Link
            onFollow={(e) => {
              e.preventDefault();
              const caseId = encodeURIComponent(recommendation.targetName);
              const field = recommendation.testCaseField
                ? `&field=${encodeURIComponent(recommendation.testCaseField)}`
                : '';
              navigate(`/suites/${encodeURIComponent(suiteId)}?editCase=${caseId}${field}`);
            }}
            href={`/suites/${encodeURIComponent(suiteId ?? '')}?editCase=${encodeURIComponent(recommendation.targetName)}${recommendation.testCaseField ? `&field=${encodeURIComponent(recommendation.testCaseField)}` : ''}`}
          >
            Edit test case
          </Link>
        )}
      </SpaceBetween>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Individual Failure Analysis Component
// ---------------------------------------------------------------------------

function IndividualAnalysisView({ analysis, suiteId }: { analysis: FailureCaseAnalysis; suiteId?: string }) {
  return (
    <Container
      header={
        <Header
          variant="h3"
          description={
            <SpaceBetween direction="horizontal" size="xs">
              <Badge color={categoryBadgeColor(analysis.rootCauseCategory)}>
                {formatCategory(analysis.rootCauseCategory)}
              </Badge>
              {!analysis.traceAvailable && (
                <StatusIndicator type="info">
                  No reasoning trace
                </StatusIndicator>
              )}
            </SpaceBetween>
          }
        >
          {analysis.caseId}
        </Header>
      }
    >
      <SpaceBetween size="m">
        {/* Trace unavailability notice */}
        {!analysis.traceAvailable && (
          <Alert type="info" statusIconAriaLabel="Info">
            Reasoning trace evidence was unavailable for this test case. Analysis is
            based on the conversation transcript and tool sequences only.
          </Alert>
        )}

        {/* Root cause explanation */}
        <div>
          <Box variant="awsui-key-label">Root Cause Explanation</Box>
          <Box variant="p">{analysis.explanation}</Box>
        </div>

        {/* Recommendations */}
        {analysis.recommendations.length > 0 && (
          <ExpandableSection
            headerText={`Recommendations (${analysis.recommendations.length})`}
            variant="footer"
            defaultExpanded
          >
            <SpaceBetween size="m">
              {analysis.recommendations.map((rec, idx) => (
                <DiffView key={idx} recommendation={rec} suiteId={suiteId} />
              ))}
            </SpaceBetween>
          </ExpandableSection>
        )}

        {analysis.recommendations.length === 0 && (
          <Box variant="small" color="text-status-inactive">
            No specific recommendations generated for this failure.
          </Box>
        )}
      </SpaceBetween>
    </Container>
  );
}

// ---------------------------------------------------------------------------
// Grouped Failure Analysis Component
// ---------------------------------------------------------------------------

function GroupedAnalysisView({ group, suiteId }: { group: FailureGroup; suiteId?: string }) {
  return (
    <Container
      header={
        <Header
          variant="h3"
          description={
            <Badge color={categoryBadgeColor(group.rootCauseCategory)}>
              {formatCategory(group.rootCauseCategory)}
            </Badge>
          }
        >
          Shared Root Cause — {group.caseIds.length} test cases
        </Header>
      }
    >
      <SpaceBetween size="m">
        {/* Affected cases */}
        <div>
          <Box variant="awsui-key-label">Affected Test Cases</Box>
          <SpaceBetween direction="horizontal" size="xs">
            {group.caseIds.map((caseId) => (
              <Box key={caseId} variant="code" fontSize="body-s">
                {caseId}
              </Box>
            ))}
          </SpaceBetween>
        </div>

        {/* Consolidated explanation */}
        <div>
          <Box variant="awsui-key-label">Root Cause Explanation</Box>
          <Box variant="p">{group.explanation}</Box>
        </div>

        {/* Consolidated recommendations */}
        {group.recommendations.length > 0 && (
          <ExpandableSection
            headerText={`Consolidated Recommendations (${group.recommendations.length})`}
            variant="footer"
            defaultExpanded
          >
            <SpaceBetween size="m">
              {group.recommendations.map((rec, idx) => (
                <DiffView key={idx} recommendation={rec} suiteId={suiteId} />
              ))}
            </SpaceBetween>
          </ExpandableSection>
        )}
      </SpaceBetween>
    </Container>
  );
}

// ---------------------------------------------------------------------------
// Main Component
// ---------------------------------------------------------------------------

export function FailureAnalysis({ runId, suiteId, agentId, runStatus }: FailureAnalysisProps) {
  const [analysis, setAnalysis] = useState<AnalyzeResponse | null>(null);
  const [snapshot, setSnapshot] = useState<AgentSnapshot | null>(null);
  const [loading, setLoading] = useState(false);
  const [reanalyzing, setReanalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Guard against re-fetch on every parent re-render. Mount-time fetch
  // runs exactly once per (runId, suiteId) tuple so that progress polls
  // on the parent page do not retrigger Bedrock-backed reads.
  const fetchedKeyRef = useRef<string | null>(null);

  // ---------------------------------------------------------------------------
  // Fetch persisted analysis (no `force`) — relies on the Lambda's
  // persisted-read shortcut to avoid re-invoking Bedrock (R6.2, R11.1).
  // ---------------------------------------------------------------------------

  const fetchPersistedAnalysis = useCallback(async (): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      const body: Record<string, unknown> = {};
      if (suiteId) {
        body.suiteId = suiteId;
      }

      const response = await apiClient.post<AnalyzeResponse>(
        `/runs/${runId}/analyze`,
        body,
      );
      setAnalysis(response);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to load failure analysis.');
      }
    } finally {
      setLoading(false);
    }
  }, [runId, suiteId]);

  // ---------------------------------------------------------------------------
  // Fetch the run's agent snapshot — used solely as the cue for the
  // R12.6 "Re-analyze to incorporate the now-captured examples" banner.
  // Failures are silent: when the snapshot can't be read, the banner
  // simply doesn't surface, which is the correct fallback.
  // ---------------------------------------------------------------------------

  const fetchSnapshot = useCallback(async (): Promise<void> => {
    try {
      const response = await apiClient.get<SnapshotResponse>(
        `/runs/${runId}/snapshot`,
      );
      setSnapshot(response.snapshot);
    } catch {
      // Silent — the banner stays hidden if the snapshot can't be read.
    }
  }, [runId]);

  // ---------------------------------------------------------------------------
  // Re-analyze action — POSTs `{ force: true, suiteId? }` to bypass the
  // persisted-read shortcut and overwrite the persisted records (R11.3).
  // After success, refresh local state so the next render shows the
  // regenerated content; refresh the snapshot too so the banner clears
  // when the underlying snapshot has the captured examples.
  // ---------------------------------------------------------------------------

  const handleReanalyze = useCallback(async (): Promise<void> => {
    setReanalyzing(true);
    setError(null);

    try {
      const body: Record<string, unknown> = { force: true };
      if (suiteId) {
        body.suiteId = suiteId;
      }

      const response = await apiClient.post<AnalyzeResponse>(
        `/runs/${runId}/analyze`,
        body,
      );
      setAnalysis(response);
      // Refresh the snapshot in the background — silent on failure.
      void fetchSnapshot();
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to re-run failure analysis.');
      }
    } finally {
      setReanalyzing(false);
    }
  }, [runId, suiteId, fetchSnapshot]);

  // ---------------------------------------------------------------------------
  // Mount-time fetch
  // ---------------------------------------------------------------------------

  useEffect(() => {
    const key = `${runId}|${suiteId ?? ''}`;
    if (fetchedKeyRef.current === key) return;
    fetchedKeyRef.current = key;
    void Promise.all([fetchPersistedAnalysis(), fetchSnapshot()]);
  }, [runId, suiteId, fetchPersistedAnalysis, fetchSnapshot]);

  // ---------------------------------------------------------------------------
  // Group per-case analyses by root-cause category for display.
  // The grouping is a pure function of the persisted records — repeating
  // it on every render is cheap (the input is bounded by the failed-case
  // count) but `useMemo` keeps the reference stable so child components
  // do not re-render unnecessarily.
  // ---------------------------------------------------------------------------

  const grouping = useMemo<{
    individual: FailureCaseAnalysis[];
    grouped: FailureGroup[];
  }>(() => {
    if (!analysis) {
      return { individual: [], grouped: [] };
    }
    const inputs: FailureCaseAnalysis[] = analysis.caseAnalyses.map((a) => ({
      caseId: a.caseId,
      rootCauseCategory: a.rootCauseCategory,
      explanation: a.explanation,
      traceAvailable: a.traceAvailable,
      recommendations: a.recommendations,
    }));
    return groupFailuresByRootCause(inputs);
  }, [analysis]);

  // ---------------------------------------------------------------------------
  // Render: Loading (initial only — Re-analyze surfaces the spinner via
  // the Header button's `loading` prop)
  // ---------------------------------------------------------------------------

  if (loading && !analysis) {
    return (
      <Container
        header={<Header variant="h2">Failure Analysis</Header>}
      >
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <Spinner size="large" />
            <Box variant="p">
              Loading failure analysis…
            </Box>
          </SpaceBetween>
        </Box>
      </Container>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: Error (mount-time fetch failed and we have no data to show)
  // ---------------------------------------------------------------------------

  if (error && !analysis) {
    return (
      <Container
        header={
          <Header
            variant="h2"
            actions={
              <Button onClick={fetchPersistedAnalysis} iconName="refresh">
                Retry
              </Button>
            }
          >
            Failure Analysis
          </Header>
        }
      >
        <Alert type="error" statusIconAriaLabel="Error">
          {error}
        </Alert>
      </Container>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: No failures
  // ---------------------------------------------------------------------------

  if (analysis && analysis.caseAnalyses.length === 0) {
    return (
      <Container
        header={<Header variant="h2">Failure Analysis</Header>}
      >
        <Alert type="success" statusIconAriaLabel="Success">
          No failures detected in this test run. All test cases passed.
        </Alert>
      </Container>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: Not yet triggered (fallback — should not happen given the
  // mount-time fetch, but kept as a defensive entry point)
  // ---------------------------------------------------------------------------

  if (!analysis) {
    return (
      <Container
        header={
          <Header
            variant="h2"
            actions={
              <Button variant="primary" onClick={fetchPersistedAnalysis}>
                Load failure analysis
              </Button>
            }
          >
            Failure Analysis
          </Header>
        }
      >
        <Box textAlign="center" padding="l" color="text-status-inactive">
          Click "Load failure analysis" to view AI-powered root cause
          explanations and recommendations for failed test cases.
        </Box>
      </Container>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: Results
  // ---------------------------------------------------------------------------

  const totalAnalyzed = analysis.caseAnalyses.length;
  const hasGrouped = grouping.grouped.length > 0;
  const hasIndividual = grouping.individual.length > 0;

  // Count cases without trace (computed off the flat `caseAnalyses[]`
  // list rather than the grouping output so it always reflects the
  // total even when every case collapses into a single shared group).
  const casesWithoutTrace = analysis.caseAnalyses.filter(
    (a) => !a.traceAvailable,
  ).length;

  const partialFailureIds = analysis.partialFailures ?? [];
  const showExamplesBanner = snapshotPredatesExamples(snapshot);

  return (
    <Container
      header={
        <Header
          variant="h2"
          description={`${totalAnalyzed} failed test case${totalAnalyzed !== 1 ? 's' : ''} analyzed`}
          actions={
            <Button
              onClick={handleReanalyze}
              iconName="refresh"
              loading={reanalyzing}
            >
              Re-analyze
            </Button>
          }
        >
          Failure Analysis
        </Header>
      }
    >
      <SpaceBetween size="l">
        {/* R12.6 — pre-feature snapshot banner. Suppressed when no
            tool-sequence analyses exist (RAG-only runs have no
            recommendations that benefit from re-analysis with examples). */}
        {showExamplesBanner && analysis && analysis.caseAnalyses.length > 0 && (
          <Alert
            type="info"
            statusIconAriaLabel="Info"
            header="Examples not captured for this run"
            action={
              <Button onClick={handleReanalyze} loading={reanalyzing}>
                Re-analyze
              </Button>
            }
          >
            This run was captured before tool examples were tracked. Re-analyze
            to incorporate the now-captured examples into the recommendations.
          </Alert>
        )}

        {/* R12.5 — partial-failures notice */}
        {partialFailureIds.length > 0 && (
          <Alert type="warning" statusIconAriaLabel="Warning">
            Per-case analysis failed for cases: {partialFailureIds.join(', ')}
          </Alert>
        )}

        {/* Re-analyze error (data is still rendered from the prior
            successful fetch). */}
        {error && analysis && (
          <Alert type="error" statusIconAriaLabel="Error" dismissible onDismiss={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* Summary */}
        <ColumnLayout columns={3} variant="text-grid">
          <div>
            <Box variant="awsui-key-label">Failures Analyzed</Box>
            <Box variant="p" fontSize="heading-l">
              {totalAnalyzed}
            </Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Shared Root Causes</Box>
            <Box variant="p" fontSize="heading-l">
              {grouping.grouped.length}
            </Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Unique Root Causes</Box>
            <Box variant="p" fontSize="heading-l">
              {grouping.individual.length}
            </Box>
          </div>
        </ColumnLayout>

        {/* Missing traces warning */}
        {casesWithoutTrace > 0 && (
          <Alert type="info" statusIconAriaLabel="Info">
            Reasoning trace evidence was unavailable for {casesWithoutTrace} test
            case{casesWithoutTrace !== 1 ? 's' : ''}. Analysis for those cases is
            based on conversation transcripts and tool sequences only.
          </Alert>
        )}

        {/* Implement Recommendations button — per-suite section (R1.2).
            Rendered when the analysis has recommendations and the user
            has provided the agentId (from the parent suite). */}
        {agentId && totalAnalyzed > 0 && (
          <ImplementButton
            runId={runId}
            suiteId={suiteId ?? ''}
            agentId={agentId}
            hasRecommendations={totalAnalyzed > 0}
            runStatus={(runStatus as RunStatus) ?? RunStatus.COMPLETED}
            instanceMode={
              (getConfig()?.instanceMode ?? 'development') as
                | 'production'
                | 'development'
            }
          />
        )}

        {/* Tabbed view: grouped vs individual */}
        {(hasGrouped || hasIndividual) && (
          <Tabs
            tabs={[
              ...(hasGrouped
                ? [
                    {
                      id: 'grouped',
                      label: `Grouped (${grouping.grouped.length})`,
                      content: (
                        <SpaceBetween size="l">
                          {grouping.grouped.map((group) => (
                            <GroupedAnalysisView
                              key={group.rootCauseCategory}
                              group={group}
                              suiteId={suiteId}
                            />
                          ))}
                        </SpaceBetween>
                      ),
                    },
                  ]
                : []),
              ...(hasIndividual
                ? [
                    {
                      id: 'individual',
                      label: `Individual (${grouping.individual.length})`,
                      content: (
                        <SpaceBetween size="l">
                          {grouping.individual.map((a) => (
                            <IndividualAnalysisView
                              key={a.caseId}
                              analysis={a}
                              suiteId={suiteId}
                            />
                          ))}
                        </SpaceBetween>
                      ),
                    },
                  ]
                : []),
            ]}
          />
        )}
      </SpaceBetween>
    </Container>
  );
}
