import { useCallback, useEffect, useRef, useState } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import Container from '@cloudscape-design/components/container';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import Alert from '@cloudscape-design/components/alert';
import ProgressBar from '@cloudscape-design/components/progress-bar';
import StatusIndicator from '@cloudscape-design/components/status-indicator';
import Table, { type TableProps } from '@cloudscape-design/components/table';
import Spinner from '@cloudscape-design/components/spinner';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import { apiClient, ApiClientError, getConfig, revertApply, getApplyStatus } from '../api';
import type { TestRun, TestCaseResult, TestSuite } from '../../../shared/types';
import { RunStatus, CaseStatus } from '../../../shared/enums';
import { formatDurationMs } from '../../../shared/utils/time-formatting';
import { useActiveRunsContext } from '../hooks/ActiveRunsContext';
import { useExperimentBanner } from '../hooks/useExperimentBanner';
import { useImplementRecommendations } from '../hooks/useImplementRecommendations';
import { RecommendedChangesPanel } from '../components/RecommendedChangesPanel';
import {
  ImplementButton,
  ConfirmationDialog,
  ConflictResolution,
  PostApplyPrompt,
  ExperimentProgress,
} from '../components/ImplementRecommendations';
import { ExperimentBannerPanel } from '../components/ImplementRecommendations/ExperimentBannerPanel';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface RunProgress {
  totalCases: number;
  completed: number;
  passed: number;
  failed: number;
  errors: number;
  accuracy: number;
}

interface RunDetailResponse {
  run: TestRun;
  progress: RunProgress;
  results: TestCaseResult[];
}

interface StartRunResponse {
  runId: string;
  sfnExecutionArn: string;
  status: string;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function formatElapsedTime(seconds: number): string {
  const totalSeconds = Math.max(0, Math.floor(seconds));
  const minutes = Math.floor(totalSeconds / 60);
  const remainingSeconds = totalSeconds % 60;
  const mm = String(minutes).padStart(2, '0');
  const ss = String(remainingSeconds).padStart(2, '0');
  return `${mm}:${ss}`;
}

function getElapsedSeconds(startTime: string, endTime?: string): number {
  const start = new Date(startTime).getTime();
  const end = endTime ? new Date(endTime).getTime() : Date.now();
  return Math.max(0, Math.floor((end - start) / 1000));
}

function caseStatusIndicator(status: CaseStatus) {
  switch (status) {
    case CaseStatus.PASSED:
      return <StatusIndicator type="success">Passed</StatusIndicator>;
    case CaseStatus.FAILED:
      return <StatusIndicator type="error">Failed</StatusIndicator>;
    case CaseStatus.ERROR:
      return <StatusIndicator type="warning">Error</StatusIndicator>;
    case CaseStatus.TIMED_OUT:
      return <StatusIndicator type="warning">Timed out</StatusIndicator>;
    default:
      return <StatusIndicator type="info">{status}</StatusIndicator>;
  }
}

function runStatusIndicator(status: RunStatus) {
  switch (status) {
    case RunStatus.RUNNING:
      return <StatusIndicator type="in-progress">Running</StatusIndicator>;
    case RunStatus.COMPLETED:
      return <StatusIndicator type="success">Completed</StatusIndicator>;
    case RunStatus.FAILED:
      return <StatusIndicator type="error">Failed</StatusIndicator>;
    case RunStatus.ABORTED:
      return <StatusIndicator type="stopped">Aborted</StatusIndicator>;
    default:
      return <StatusIndicator type="info">{status}</StatusIndicator>;
  }
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const POLL_INTERVAL_MS = 3000;

// ---------------------------------------------------------------------------
// Main Component
// ---------------------------------------------------------------------------

export function RunDashboard() {
  const { runId: routeRunId } = useParams<{ runId: string }>();
  const [searchParams] = useSearchParams();
  const suiteIdParam = searchParams.get('suiteId');
  const { trackRun } = useActiveRunsContext();
  const navigate = useNavigate();

  // State.
  // The runId state seeds from the URL but only when the URL carries a real
  // id; the `"new"` sentinel means "ready to start" (suiteId is in
  // ?suiteId=...) and must NOT be treated as an existing run id (otherwise
  // the polling effect would issue GET /runs/new and 404).
  const [runId, setRunId] = useState<string | null>(
    routeRunId && routeRunId !== 'new' ? routeRunId : null,
  );
  const [run, setRun] = useState<TestRun | null>(null);
  const [progress, setProgress] = useState<RunProgress | null>(null);
  const [results, setResults] = useState<TestCaseResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [starting, setStarting] = useState(false);
  const [aborting, setAborting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Suite metadata — fetched once to obtain the agentId for the
  // ImplementButton and other suite-scoped features.
  const [suite, setSuite] = useState<TestSuite | null>(null);

  // Experiment banner state — polling hook that discovers and tracks
  // experiment lifecycle for the informational banner (R5.1–R5.6).
  const bannerState = useExperimentBanner(runId);

  // Resolve the suiteId we should hint to API calls and render in the
  // header. Prefer the URL query param when present (the launching
  // navigation always sets it), and fall back to the run record itself
  // once it has loaded.
  const effectiveSuiteId = suiteIdParam ?? run?.suiteId ?? null;

  // Implement Recommendations state machine — orchestrates Direct Apply
  // and Experiment flows (R1–R4, R6–R8).
  const implementRecs = useImplementRecommendations({
    runId: runId ?? '',
    suiteId: effectiveSuiteId ?? '',
    agentId: suite?.agentId ?? '',
  });

  // Refs for polling
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ---------------------------------------------------------------------------
  // Implement Recommendations — page-level handlers
  // ---------------------------------------------------------------------------

  /**
   * Start a fresh run for the same suite and navigate to its dashboard.
   * Shared by the "Re-run Suite" (PostApplyPrompt, R3.1) and "Re-analyze"
   * (ConflictResolution, R2.3) actions — both reset the implement state
   * machine, then kick off a new run.
   */
  const startFreshRunForSuite = useCallback(async () => {
    if (!effectiveSuiteId) {
      setError('Cannot start a new run: suite is unknown.');
      return;
    }
    try {
      const response = await apiClient.post<StartRunResponse>('/runs', {
        suiteId: effectiveSuiteId,
      });
      trackRun(response.runId, effectiveSuiteId);
      navigate(`/runs/${response.runId}?suiteId=${encodeURIComponent(effectiveSuiteId)}`);
    } catch (err) {
      setError(
        err instanceof ApiClientError ? err.message : 'Failed to start a new run.',
      );
    }
  }, [effectiveSuiteId, navigate, trackRun]);

  const handleReRunSuite = useCallback(async () => {
    implementRecs.reRunSuite();
    await startFreshRunForSuite();
  }, [implementRecs, startFreshRunForSuite]);

  const handleReAnalyze = useCallback(async () => {
    implementRecs.cancelDialog();
    await startFreshRunForSuite();
  }, [implementRecs, startFreshRunForSuite]);

  // Revert state
  const [reverting, setReverting] = useState(false);
  const [canRevert, setCanRevert] = useState(false);
  const [applyReverted, setApplyReverted] = useState(false);

  const handleRevert = useCallback(async () => {
    if (!runId) return;
    setReverting(true);
    try {
      await revertApply(runId);
      implementRecs.dismissSuccess();
      setCanRevert(false);
      setApplyReverted(true);
    } catch (err) {
      setError(
        err instanceof ApiClientError ? err.message : 'Failed to revert changes.',
      );
    } finally {
      setReverting(false);
    }
  }, [runId, implementRecs]);

  // Check if this run has an un-reverted apply on mount
  useEffect(() => {
    if (!runId) return;
    let cancelled = false;
    (async () => {
      try {
        const status = await getApplyStatus(runId);
        if (!cancelled && status.canRevert) {
          setCanRevert(true);
        }
      } catch {
        // Silent — the banner just won't show
      }
    })();
    return () => { cancelled = true; };
  }, [runId]);

  // ---------------------------------------------------------------------------
  // Fetch run details
  // ---------------------------------------------------------------------------

  /**
   * If the URL didn't carry `?suiteId=` but we've now loaded the run
   * record (which knows its suite), backfill the query string so the
   * URL is bookmarkable and the polling effect can hint subsequent
   * GETs without an extra round-trip. We use replaceState rather than
   * navigate() so the user's history isn't polluted.
   */
  useEffect(() => {
    if (!suiteIdParam && run?.suiteId && runId) {
      window.history.replaceState(
        null,
        '',
        `/runs/${runId}?suiteId=${encodeURIComponent(run.suiteId)}`,
      );
    }
  }, [suiteIdParam, run?.suiteId, runId]);

  // Navigate to TournamentView when experiment completes (R4.4).
  useEffect(() => {
    if (
      implementRecs.state === 'experiment_completed' &&
      runId &&
      implementRecs.context.experimentId
    ) {
      navigate(
        `/runs/${runId}/experiments/${implementRecs.context.experimentId}`,
      );
    }
  }, [implementRecs.state, implementRecs.context.experimentId, runId, navigate]);

  const fetchRunDetails = useCallback(
    async (id: string) => {
      try {
        // The Run Dashboard always has the suiteId in the query string when
        // landing on a real run, either because it just launched the run
        // (replaceState put `?suiteId=` in the URL) or because the user
        // arrived via a deep link from the Suites list (which always
        // appends `?suiteId=`). Pass it through to the GET /runs/{runId}
        // endpoint as a hint so it can resolve the run record from the
        // legacy `PK=SUITE#{suiteId}, SK=RUN#{startTime}` partition (the
        // server only writes a single-key SUMMARY record after WriteResults
        // completes, so an in-progress run is otherwise invisible to the
        // by-id GET).
        const hint = effectiveSuiteId;
        const url = hint
          ? `/runs/${id}?suiteId=${encodeURIComponent(hint)}`
          : `/runs/${id}`;
        const response = await apiClient.get<RunDetailResponse>(url);
        setRun(response.run);
        setProgress(response.progress);
        setResults(response.results);
        setError(null);
        return response.run;
      } catch (err) {
        if (err instanceof ApiClientError) {
          setError(err.message);
        } else {
          setError('Failed to fetch run details.');
        }
        return null;
      }
    },
    [effectiveSuiteId],
  );

  // ---------------------------------------------------------------------------
  // Start a new run
  // ---------------------------------------------------------------------------

  const handleStartRun = async () => {
    if (!suiteIdParam) {
      setError('No suiteId provided. Navigate from a test suite to start a run.');
      return;
    }

    setStarting(true);
    setError(null);

    try {
      const response = await apiClient.post<StartRunResponse>('/runs', {
        suiteId: suiteIdParam,
      });
      setRunId(response.runId);
      // Register the new run with the tab-local active-runs tracker so
      // the persistent banner in AppLayout follows the user across pages
      // until the run reaches a terminal status.
      trackRun(response.runId, suiteIdParam);
      // Update URL without full navigation
      window.history.replaceState(null, '', `/runs/${response.runId}?suiteId=${suiteIdParam}`);
      // Immediately fetch run details
      await fetchRunDetails(response.runId);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to start run.');
      }
    } finally {
      setStarting(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Abort run
  // ---------------------------------------------------------------------------

  const handleAbortRun = async () => {
    if (!runId) return;
    setAborting(true);
    setError(null);

    try {
      await apiClient.post(`/runs/${runId}/abort`);
      // Fetch updated run details immediately
      await fetchRunDetails(runId);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to abort run.');
      }
    } finally {
      setAborting(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Polling logic
  // ---------------------------------------------------------------------------

  const isRunActive = run?.status === RunStatus.RUNNING;

  // Start/stop polling based on run status
  useEffect(() => {
    if (runId && isRunActive) {
      // Poll for updates every 3 seconds
      pollRef.current = setInterval(async () => {
        const updatedRun = await fetchRunDetails(runId);
        if (updatedRun && updatedRun.status !== RunStatus.RUNNING) {
          // Run is done, stop polling
          if (pollRef.current) {
            clearInterval(pollRef.current);
            pollRef.current = null;
          }
        }
      }, POLL_INTERVAL_MS);

      return () => {
        if (pollRef.current) {
          clearInterval(pollRef.current);
          pollRef.current = null;
        }
      };
    }
  }, [runId, isRunActive, fetchRunDetails]);

  // Elapsed time timer (updates every second while run is active)
  useEffect(() => {
    if (isRunActive && run?.startTime) {
      // Update immediately
      setElapsedSeconds(getElapsedSeconds(run.startTime));

      timerRef.current = setInterval(() => {
        setElapsedSeconds(getElapsedSeconds(run.startTime));
      }, 1000);

      return () => {
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
      };
    } else if (run?.startTime) {
      // Run is finished — compute final elapsed
      setElapsedSeconds(getElapsedSeconds(run.startTime, run.endTime));
    }
  }, [isRunActive, run?.startTime, run?.endTime]);

  // Initial fetch if a real runId is in the URL. The "new" sentinel is
  // routed at /runs/new and means "ready to start a new run for the suiteId
  // in ?suiteId=..."; treating it as a real id triggers a 404 against
  // GET /runs/new and shows a misleading "Failed to fetch" banner before the
  // user has even clicked Start.
  // Reset run state when the route changes to a different runId. Without this,
  // navigating from a completed run's dashboard to a new run (same route pattern,
  // different param) leaves the old progress/status visible until the first fetch.
  useEffect(() => {
    if (routeRunId && routeRunId !== 'new') {
      setRun(null);
      setProgress(null);
      setResults([]);
      setError(null);
      setElapsedSeconds(0);
      setRunId(routeRunId);
      setLoading(true);
      fetchRunDetails(routeRunId).finally(() => setLoading(false));
    }
  }, [routeRunId, fetchRunDetails]);

  // Fetch suite metadata to obtain agentId for the ImplementButton.
  // Runs once per effectiveSuiteId and caches in local state.
  useEffect(() => {
    if (!effectiveSuiteId) return;
    let cancelled = false;
    (async () => {
      try {
        const suiteData = await apiClient.get<TestSuite>(
          `/suites/${effectiveSuiteId}`,
        );
        if (!cancelled) setSuite(suiteData);
      } catch {
        // Silent — the ImplementButton simply won't render if agentId is unknown.
      }
    })();
    return () => { cancelled = true; };
  }, [effectiveSuiteId]);

  // ---------------------------------------------------------------------------
  // Column definitions for results table
  // ---------------------------------------------------------------------------

  const columnDefinitions: TableProps.ColumnDefinition<TestCaseResult>[] = [
    {
      id: 'caseId',
      header: 'Case ID',
      // Click-through to the per-case detail page. We pass the suiteId
      // hint along (when known) so the case-detail page's links back to
      // the run dashboard preserve the suite context — the dashboard's
      // GET /runs/{runId} call needs that hint to resolve in-progress
      // run records that haven't written a SUMMARY yet.
      cell: (item) => (
        <Button
          variant="inline-link"
          onClick={() => {
            const suite = effectiveSuiteId ?? '';
            const qs = suite
              ? `?suiteId=${encodeURIComponent(suite)}`
              : '';
            navigate(`/runs/${runId}/cases/${item.caseId}${qs}`);
          }}
          ariaLabel={`Open detail for case ${item.caseId}`}
        >
          {item.caseId}
        </Button>
      ),
      sortingField: 'caseId',
    },
    {
      id: 'status',
      header: 'Status',
      cell: (item) => caseStatusIndicator(item.status),
      sortingField: 'status',
    },
    {
      id: 'toolsInvoked',
      header: 'Tools Invoked',
      cell: (item) => item.toolsInvoked.join(' → ') || '—',
    },
    {
      id: 'turnCount',
      header: 'Turns',
      cell: (item) => item.turnCount,
      sortingField: 'turnCount',
    },
    {
      id: 'latencyMs',
      // Persisted attribute is still `latencyMs` for backward compat
      // with existing records, but the case-level value represents the
      // run *duration* of the case (start of conversation → end). The
      // display label uses the precise term so it isn't conflated with
      // turn-level / tool-call latency the platform also captures.
      header: 'Duration',
      cell: (item) => formatDurationMs(item.latencyMs),
      sortingField: 'latencyMs',
    },
    {
      id: 'toolAccuracy',
      header: 'Tool Accuracy',
      cell: (item) =>
        item.toolAccuracyScore != null
          ? `${(item.toolAccuracyScore * 100).toFixed(0)}%`
          : '—',
    },
    {
      id: 'goalSuccess',
      header: 'Goal Success',
      cell: (item) =>
        item.goalSuccessScore != null
          ? `${(item.goalSuccessScore * 100).toFixed(0)}%`
          : '—',
    },
    {
      id: 'error',
      header: 'Error',
      cell: (item) => item.errorMessage || '—',
    },
  ];

  // ---------------------------------------------------------------------------
  // Render: Loading state
  // ---------------------------------------------------------------------------

  if (loading) {
    return (
      <ContentLayout header={<Header variant="h1">Run Dashboard</Header>}>
        <Box textAlign="center" padding="l">
          <Spinner size="large" />
        </Box>
      </ContentLayout>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: No run yet — show start button
  // ---------------------------------------------------------------------------

  if (!runId && !run) {
    return (
      <ContentLayout
        header={
          <Header
            variant="h1"
            description={
              suiteIdParam
                ? `Start a new run for suite ${suiteIdParam}`
                : 'Pick a test suite to start a run.'
            }
            actions={
              <Button variant="link" onClick={() => navigate('/suites')}>
                Back to suites
              </Button>
            }
          >
            Run Dashboard
          </Header>
        }
      >
        <Container header={<Header variant="h2">Start New Run</Header>}>
          <SpaceBetween size="m">
            {error && (
              <Alert type="error" dismissible onDismiss={() => setError(null)}>
                {error}
              </Alert>
            )}
            {suiteIdParam ? (
              <SpaceBetween size="s">
                <Box variant="p">
                  Suite: <strong>{suiteIdParam}</strong>
                </Box>
                <Button
                  variant="primary"
                  onClick={handleStartRun}
                  loading={starting}
                >
                  Start run
                </Button>
              </SpaceBetween>
            ) : (
              <Box variant="p" color="text-status-info">
                Navigate from a test suite to start a run. Provide a suiteId parameter.
              </Box>
            )}
          </SpaceBetween>
        </Container>
      </ContentLayout>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: Run in progress or completed
  // ---------------------------------------------------------------------------

  const progressPercentage =
    progress && progress.totalCases > 0
      ? Math.round((progress.completed / progress.totalCases) * 100)
      : 0;

  const isTerminal =
    run?.status === RunStatus.COMPLETED ||
    run?.status === RunStatus.FAILED ||
    run?.status === RunStatus.ABORTED;

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description={
            // Surface the parent suite right in the header so the dashboard
            // doesn't feel orphaned (especially on a hard reload). When we
            // know the suiteId from either the URL or the loaded run, render
            // it as a clickable "Suite: <id> ↗" link back to the suite
            // detail page; otherwise show just the runId so the page is
            // never blank.
            effectiveSuiteId ? (
              <SpaceBetween direction="horizontal" size="xs">
                <span>Suite:</span>
                <Button
                  variant="inline-link"
                  onClick={() => navigate(`/suites/${effectiveSuiteId}`)}
                >
                  {effectiveSuiteId}
                </Button>
                <Box variant="small" color="text-status-inactive">
                  · Run: {runId}
                </Box>
              </SpaceBetween>
            ) : (
              `Run: ${runId}`
            )
          }
          actions={
            <SpaceBetween direction="horizontal" size="xs">
              {/* Always offer a way back to the suite, even mid-run.
                  Hidden when we genuinely don't know the suite (rare —
                  only on a hand-typed /runs/<id> for a run that has no
                  results yet, which the server can't resolve). */}
              {effectiveSuiteId && (
                <Button
                  variant="link"
                  onClick={() => navigate(`/suites/${effectiveSuiteId}`)}
                >
                  Back to suite
                </Button>
              )}
              {isRunActive && (
                <Button
                  onClick={handleAbortRun}
                  loading={aborting}
                  variant="normal"
                >
                  Abort run
                </Button>
              )}
            </SpaceBetween>
          }
        >
          Run Dashboard
        </Header>
      }
    >
      <SpaceBetween size="l">
        {error && (
          <Alert type="error" dismissible onDismiss={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* Revert banner — shown when this run has an un-reverted apply */}
        {canRevert && implementRecs.state !== 'success' && (
          <Alert
            type="info"
            statusIconAriaLabel="Info"
            action={
              <Button onClick={handleRevert} loading={reverting}>
                Revert Changes
              </Button>
            }
          >
            Recommendations were applied from this run. You can revert to restore the previous agent configuration.
          </Alert>
        )}

        {/* Revert success confirmation */}
        {applyReverted && (
          <Alert
            type="success"
            dismissible
            onDismiss={() => setApplyReverted(false)}
          >
            Changes reverted successfully. The agent has been restored to its previous configuration.
          </Alert>
        )}

        {/* Progress Section */}
        <Container
          header={
            <Header variant="h2">
              {isTerminal ? 'Final Summary' : 'Progress'}
            </Header>
          }
        >
          <SpaceBetween size="m">
            {/* Status */}
            <ColumnLayout columns={4} variant="text-grid">
              <div>
                <Box variant="awsui-key-label">Status</Box>
                <div>{run ? runStatusIndicator(run.status) : '—'}</div>
              </div>
              <div>
                <Box variant="awsui-key-label">Elapsed Time</Box>
                <div>{formatElapsedTime(elapsedSeconds)}</div>
              </div>
              <div>
                <Box variant="awsui-key-label">Completed</Box>
                <div>
                  {progress ? `${progress.completed} / ${progress.totalCases}` : '—'}
                </div>
              </div>
              <div>
                <Box variant="awsui-key-label">Accuracy</Box>
                <div>
                  {progress ? `${progress.accuracy.toFixed(1)}%` : '—'}
                </div>
              </div>
            </ColumnLayout>

            {/* Progress Bar */}
            <ProgressBar
              value={progressPercentage}
              label="Test cases completed"
              description={
                progress
                  ? `${progress.completed} of ${progress.totalCases} test cases`
                  : undefined
              }
              status={isTerminal ? 'success' : 'in-progress'}
              resultText={isTerminal ? `${progressPercentage}% complete` : undefined}
            />

            {/* Counts */}
            <ColumnLayout columns={3} variant="text-grid">
              <div>
                <Box variant="awsui-key-label">Passed</Box>
                <Box variant="p" color="text-status-success">
                  {progress?.passed ?? 0}
                </Box>
              </div>
              <div>
                <Box variant="awsui-key-label">Failed</Box>
                <Box variant="p" color="text-status-error">
                  {progress?.failed ?? 0}
                </Box>
              </div>
              <div>
                <Box variant="awsui-key-label">Errors</Box>
                <Box variant="p" color="text-status-warning">
                  {progress?.errors ?? 0}
                </Box>
              </div>
            </ColumnLayout>
          </SpaceBetween>
        </Container>

        {/* Recommended Changes Panel — sits above the results table per
            R10.1. Rendered only when we have a real runId (i.e. not in the
            `/runs/new` "ready to start" sentinel state) so the panel does
            not flash a transient empty state before the run record loads.
            The panel's own mount-time fetch runs once per mount; since the
            polling effect updates `progress`/`run` state without
            re-mounting this subtree, it does not retrigger Bedrock calls. */}
        {runId && (
          <RecommendedChangesPanel
            key={runId}
            runId={runId}
            suiteId={effectiveSuiteId ?? undefined}
            runStatus={run?.status ?? RunStatus.RUNNING}
            failedCount={progress?.failed ?? 0}
            errorCount={progress?.errors ?? 0}
          />
        )}

        {/* Implement Recommendations button — rendered in the panel
            header area when the run has recommendations (R1.1). The
            button is hidden when instanceMode=production, no
            recommendations, or the run is still running. */}
        {runId && suite && (
          <ImplementButton
            runId={runId}
            suiteId={effectiveSuiteId ?? ''}
            agentId={suite.agentId}
            hasRecommendations={(progress?.failed ?? 0) > 0}
            runStatus={run?.status ?? RunStatus.RUNNING}
            instanceMode={
              (getConfig()?.instanceMode ?? 'development') as
                | 'production'
                | 'development'
            }
            onDirectApply={implementRecs.startDirectApply}
            onExperiment={implementRecs.startExperiment}
          />
        )}

        {/* ConfirmationDialog — shown when state is confirming or applying (R1.1–R1.8) */}
        <ConfirmationDialog
          visible={
            implementRecs.state === 'confirming' ||
            implementRecs.state === 'applying'
          }
          agentName={suite?.agentId ?? ''}
          agentId={suite?.agentId ?? ''}
          recommendations={implementRecs.context.recommendations}
          onConfirm={implementRecs.confirmApply}
          onCancel={implementRecs.cancelDialog}
          loading={implementRecs.state === 'applying'}
        />

        {/* ConflictResolution — shown when state is conflict (R2.1–R2.5) */}
        <ConflictResolution
          visible={implementRecs.state === 'conflict'}
          driftedFields={implementRecs.context.driftedFields}
          onApplyAnyway={implementRecs.forceApply}
          onCancel={implementRecs.cancelDialog}
          onReAnalyze={handleReAnalyze}
        />

        {/* PostApplyPrompt — shown when state is success (R3.1–R3.3) */}
        <PostApplyPrompt
          visible={implementRecs.state === 'success'}
          newVersionId={implementRecs.context.newVersionId ?? ''}
          onReRunSuite={handleReRunSuite}
          onDismiss={implementRecs.dismissSuccess}
          onRevert={handleRevert}
          reverting={reverting}
        />

        {/* Error recovery (R1.5, R8.2) — a non-409 failure during the
            implement flow lands here. Surface the message with Retry and
            Dismiss actions so the user is never left without a next step. */}
        {implementRecs.state === 'error' && (
          <Alert
            type="error"
            header="Could not complete the request"
            dismissible
            onDismiss={implementRecs.cancelDialog}
            action={
              <Button onClick={implementRecs.startDirectApply}>Retry</Button>
            }
          >
            {implementRecs.context.errorMessage ??
              'An unexpected error occurred.'}
          </Alert>
        )}

        {/* ExperimentProgress — shown during experiment_starting,
            experiment_polling, or experiment_failed states (R4.1–R4.8) */}
        {(implementRecs.state === 'experiment_starting' ||
          implementRecs.state === 'experiment_polling' ||
          implementRecs.state === 'experiment_failed') && (
          <SpaceBetween size="s">
            <ExperimentProgress
              experimentId={implementRecs.context.experimentId ?? ''}
              status={
                implementRecs.state === 'experiment_failed'
                  ? 'failed'
                  : implementRecs.context.experimentStatus ?? 'generating_variants'
              }
              runId={runId ?? ''}
            />
            {/* Failure recovery actions (R4.5): retry the experiment or
                fall back to Direct Apply. */}
            {implementRecs.state === 'experiment_failed' && (
              <Box float="right">
                <SpaceBetween direction="horizontal" size="xs">
                  <Button onClick={implementRecs.cancelDialog}>Dismiss</Button>
                  <Button onClick={implementRecs.fallbackToDirectApply}>
                    Use Direct Apply
                  </Button>
                  <Button variant="primary" onClick={implementRecs.retryExperiment}>
                    Retry
                  </Button>
                </SpaceBetween>
              </Box>
            )}
          </SpaceBetween>
        )}

        {/* Experiment Banner — surfaces when the run has an active or
            completed experiment (R5.1–R5.6). Uses the useExperimentBanner
            polling hook for lifecycle tracking. */}
        {runId && bannerState.hasExperiment && (
          <ExperimentBannerPanel
            experiment={bannerState.experiment!}
            runId={runId}
            pollError={bannerState.pollError}
          />
        )}

        {/* Results Table */}
        <Container header={<Header variant="h2">Test Case Results</Header>}>
          <Table
            columnDefinitions={columnDefinitions}
            items={results}
            loading={loading}
            loadingText="Loading results..."
            trackBy="caseId"
            variant="embedded"
            empty={
              <Box textAlign="center" padding="l">
                <SpaceBetween size="m">
                  <b>No results yet</b>
                  <Box variant="p" color="inherit">
                    {isRunActive
                      ? 'Results will appear as test cases complete.'
                      : 'No test case results available.'}
                  </Box>
                </SpaceBetween>
              </Box>
            }
            header={
              <Header counter={`(${results.length})`}>
                Results
              </Header>
            }
          />
        </Container>
      </SpaceBetween>
    </ContentLayout>
  );
}
