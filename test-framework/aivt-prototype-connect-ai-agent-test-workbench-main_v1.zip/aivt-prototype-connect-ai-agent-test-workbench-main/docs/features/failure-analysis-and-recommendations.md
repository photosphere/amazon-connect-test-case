# Failure analysis and recommendations

How the platform turns failed test cases into specific, actionable edits to the agent.

## Two tiers of recommendation

### Tier 1 — Per-case recommendations

For each failed case, Bedrock analyzes the conversation transcript, the structured execution trace, and the agent snapshot to produce:

- A **root cause category** (e.g. `missing_disambiguation`, `incomplete_tool_description`, `system_prompt_gap`).
- A natural-language **explanation** of why the agent went wrong.
- A list of **specific recommendations** — each one targeting one of the four editable surfaces with current text, suggested text, and rationale.

Endpoint: `POST /runs/{runId}/analyze`. Source: `src/backend/handlers/analysis.ts`.

### Tier 2 — Per-suite recommendations

For the run as a whole, Bedrock looks across all failed cases and produces a small, prioritized set of consolidated recommendations: "if you make these 1–3 changes, you'd most lift this run." Each recommendation includes a **predicted impact** statement listing which failed cases it expects to flip from failing to passing.

Endpoint: `POST /runs/{runId}/recommend-suite`. Source: `src/backend/handlers/suite-recommend.ts`.

## The four editable surfaces

Recommendations target exactly one of:

| `targetField` | What it is |
|---|---|
| `tool_description` | The tool's description shown to the agent at inference time. Drives "is this tool relevant to the current request?". |
| `tool_instruction` | The tool's usage instructions. Drives "when should I use this tool?". |
| `tool_examples` | Few-shot demonstration strings injected into the prompt alongside the description and instruction. Drives "what does a customer query that uses this tool look like?". |
| `system_prompt` | The agent's overall system prompt. Drives high-level routing behavior and tone. |

These are the four fields the Q in Connect orchestration runtime injects into the agent's effective prompt at inference time. The platform never recommends edits to fields the runtime doesn't consume (e.g. tool input schemas, model IDs, knowledge base bindings).

## Recommendation shape

```typescript
interface Recommendation {
  targetField: "tool_description" | "tool_instruction" | "tool_examples" | "system_prompt";
  targetName: string;          // tool name, or literal "system_prompt" for the system prompt
  currentText: string;         // exact existing text to replace or remove
  suggestedText: string;       // replacement text or new content
  rationale: string;           // why this edit helps
}
```

Per-suite recommendations extend this with prioritization and predicted impact:

```typescript
interface PerSuiteRecommendation extends Recommendation {
  priority: number;            // 1 = highest. Monotonic with array index.
  predictedImpact: {
    liftedCaseIds: string[];   // failed case IDs expected to flip to passing
    rationale: string;
  };
}
```

## Tool examples — encoding three operations

Because `tool_examples` is an array of strings, recommendations against it support three operations encoded in the `(currentText, suggestedText)` pair:

| Operation | Encoding |
|---|---|
| **add** | `currentText: ""`, `suggestedText: <new example>` |
| **remove** | `currentText: <exact existing example>`, `suggestedText: ""` |
| **replace** | both non-empty; `currentText` must match an existing example exactly |

The frontend's diff renderer detects the operation from the pair and styles accordingly (green highlight for add, red for remove, both for replace).

## Persistence

Per-case analyses are stored at `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}`:

```typescript
interface PerCaseAnalysis {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;       // false if ListSpans evidence was unavailable
  recommendations: Recommendation[];
  generatedAt: string;
  modelId: string;
}
```

Per-suite analyses are stored at `PK=RUN#{runId}, SK=ANALYSIS#SUITE`:

```typescript
{
  recommendations: PerSuiteRecommendation[];  // sorted by priority
  generatedAt: string;
  modelId: string;
}
```

### Why persistence matters

Bedrock calls cost money. Re-fetching is expensive if it re-pays. The persistence shortcut is a first-class feature:

- `POST /runs/{runId}/analyze` without `force: true` — if every failed case has a persisted analysis, return them without invoking Bedrock. **Free re-fetch.**
- With `force: true` — re-invoke Bedrock for every failed case, overwrite persisted records, update `generatedAt` timestamps.

Same pattern for `/recommend-suite`. A user navigating to the Run Dashboard, leaving, and coming back later doesn't re-pay.

If DynamoDB persistence fails for a per-case analysis, the analysis is still returned to the caller (the user gets their recommendations) and the failure is logged — a transient DDB error doesn't block the user.

## Surfacing in the UI

Three places render recommendations:

### Run Dashboard — Recommended Changes Panel

The persistent panel above the results table on the Run Dashboard. Renders both tiers:

- The per-suite consolidated set with priority ordering and predicted-impact statements.
- A drill-down into per-case recommendations grouped by failure category.

When a run has zero failures, the panel shows the "all cases passed" empty state. When the panel hasn't been generated yet, it triggers generation on user action (not automatically — the user explicitly asks for it).

### Failure Analysis View

Reachable from the Results Viewer. The canonical full-detail view: per-case analyses grouped by root cause category, with the full structured display (root cause badge, explanation, trace availability indicator, recommendations as side-by-side diffs).

The view treats persisted records as the source of truth. The "Re-analyze" header action POSTs `{ force: true }` to overwrite.

A surface-specific banner appears when the run snapshot predates the `examples` field (R12.6 detection): "This run was captured before tool examples were tracked. Re-analyze to incorporate the now-captured examples into the recommendations."

### Per-case Detail Page

For failed cases, the case detail page renders the persisted per-case analysis below the transcript and execution trace. If no analysis exists yet, a **Generate recommendations** action triggers single-case analysis (not the whole run). A deep link navigates to the full Failure Analysis view with the case anchored.

For passed cases, error cases, or timed-out cases, the recommendations section is omitted.

## Tool examples — the missing surface

A lesson from feature evolution: orchestration agents inject `examples` into the prompt at runtime. The platform initially didn't capture this field, so the recommendation engine couldn't suggest example edits — a major class of fixes was invisible.

The actionable-recommendations feature added end-to-end support:

1. **Discovery API** extracts `examples` from `toolConfigurations[].examples` on `GetAIAgent`.
2. **Agent Browser** displays the `examples` array per tool with empty-state handling.
3. **Agent Snapshot** persists `examples` per tool at run start.
4. **Run comparison** detects `tool-examples-changed` independently of `tool-modified` (a tool whose only change is its examples gets a dedicated diff record).
5. **Recommendation engine** includes the per-tool examples in the analysis prompt and produces `tool_examples` recommendations.
6. **Frontend diff renderer** handles add/remove/replace operations distinctly.

When reading old snapshots that predate this feature, missing `examples` fields are treated as `[]` so reads never fail. The "examples not captured for this run" banner surfaces re-analyze as a non-destructive remediation.

## Failure category bucketing

The analysis engine categorizes each failure into one of:

- `overlapping_tool_descriptions` — multiple tools sound applicable; agent picked the wrong one.
- `incorrect_tool_prioritization` — agent picked a later-stage tool before its prerequisite.
- `missing_disambiguation` — agent had no signal to distinguish similar requests.
- `system_prompt_gap` — system prompt doesn't address this scenario.
- `missing_tool_instruction` — tool exists but has no instruction text.
- `incomplete_tool_description` — tool description doesn't cover the relevant use case.
- `tool_examples_gap` — tool would benefit from a few-shot example covering this case.
- `agent_misunderstood_intent` — agent's reasoning trace shows it misinterpreted the customer.
- `other` — anything that doesn't fit the above.

The frontend uses these categories to color-code the failure analysis view and group cases sharing a root cause for the per-suite consolidation.

## What you do with these

Two paths from a recommendation to a real change:

1. **[Apply directly](implement-recommendations.md#direct-apply)** — write the recommended text back to the live agent in one click, with drift detection.
2. **[Multi-variant experiment](implement-recommendations.md#multi-variant-experiments)** — generate 3 diverse rewrites of the recommendation, test each in parallel against a temporary cloned agent, apply the winner.

Both paths are gated by [INSTANCE_MODE](../operations.md#instance-modes) — disabled in production deployments.
