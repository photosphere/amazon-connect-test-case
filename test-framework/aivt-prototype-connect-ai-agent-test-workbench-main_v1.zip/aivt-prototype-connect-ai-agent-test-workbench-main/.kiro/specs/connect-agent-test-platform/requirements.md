# Requirements Document

## Introduction

A web platform for automated testing of Amazon Connect AI Agents. The platform bridges Amazon Q in Connect's session-based API with Bedrock AgentCore evaluation capabilities, enabling users to create test suites, run multi-turn conversational tests against live AI agents, and score results using AgentCore evaluators. Deployed as a serverless web application with Cognito authentication, CDK infrastructure, and a React + Cloudscape frontend.

## Glossary

- **Platform**: The Connect Agent Test Platform web application
- **Connect_Instance**: An Amazon Connect instance specified at deployment time
- **AI_Agent**: A Q in Connect AI Agent (type ORCHESTRATION) configured with tools and a system prompt on the Connect instance
- **Test_Suite**: A named collection of test cases targeting a specific AI Agent
- **Test_Case**: A single customer scenario consisting of a persona description, customer knowledge, and success criteria
- **Test_Run**: A single execution of a Test Suite against an AI Agent, producing scored results
- **Conversation_Driver**: The backend component that manages Q in Connect sessions, sends messages using the aiAgentId override on SendMessage, handles filler responses, and conducts multi-turn conversations
- **Customer_Simulator**: A Bedrock-powered LLM actor that plays the role of a customer persona during multi-turn test conversations
- **Evaluator**: An AgentCore evaluation component that scores conversation transcripts for goal success, helpfulness, and tool selection accuracy
- **Session**: A Q in Connect session created via CreateSession (with required name parameter) used to conduct a single test conversation
- **Filler_Response**: An intermediate "..." response from Q in Connect indicating the agent is still processing (not a clarifying question)
- **Tool_Selection**: The agent's choice of tool extracted from conversationSessionData under the key "Tool"
- **AgentCore**: Amazon Bedrock AgentCore Evaluations service used for post-conversation scoring
- **Transcript**: The full ordered sequence of turns (customer and agent messages, tool invocations) recorded during a test conversation
- **ListSpans**: A Q in Connect API that returns the AI Agent's internal reasoning trace for a session, including tool selection logic, considered tools, and rejection reasons
- **Machine_Client**: A Cognito App Client configured with client_credentials grant for non-interactive programmatic access from CI/CD pipelines or automation tools

## Requirements

### Requirement 1: Authentication and Authorization

**User Story:** As a platform user, I want to authenticate securely and access only the resources associated with my Connect instance, so that test data is protected and access is controlled.

#### Acceptance Criteria

1. THE Platform SHALL authenticate users via an Amazon Cognito User Pool before granting access to any functionality
2. IF a user is not authenticated or their session token has expired, THEN THE Platform SHALL redirect the user to the Cognito-hosted sign-in page and preserve the originally requested URL for post-authentication redirect
3. WHEN a user successfully authenticates, THE Platform SHALL issue temporary AWS credentials via a Cognito Identity Pool with an IAM role that permits only Q in Connect session APIs and Bedrock Converse API actions scoped to the user's configured Connect instance ARN
4. THE Platform SHALL restrict API access to authenticated users by validating Cognito tokens on every API Gateway request
5. IF a request to the API contains an invalid, expired, or missing authentication token, THEN THE Platform SHALL reject the request with an HTTP 401 response and an error message indicating the authentication failure reason
6. IF temporary AWS credentials expire during an active user session, THEN THE Platform SHALL automatically refresh the credentials via the Cognito Identity Pool without interrupting the user's workflow

### Requirement 2: Connect Instance Configuration

**User Story:** As a deployer, I want to specify my Amazon Connect instance at deployment time, so that the platform discovers and tests agents on that instance.

#### Acceptance Criteria

1. WHEN deploying the CDK stack, THE Platform SHALL accept a Connect instance ID (UUID format, 36 characters) as a required CDK context parameter and validate that it is non-empty before proceeding with synthesis
2. THE Platform SHALL configure IAM permissions scoped to the specified Connect instance ARN for Q in Connect session operations (CreateSession, SendMessage, GetNextMessage) and agent discovery operations (GetAIAgent, ListAIAgents), using both `wisdom:` and `qconnect:` resource ARN prefixes
3. WHEN the deployment completes, THE Platform SHALL store the Connect instance ID and assistant ID as Lambda environment variables accessible to all backend Lambda functions
4. WHEN the stack is deployed, THE Platform SHALL discover the assistant ID by calling ListAssistants filtered to the specified Connect instance, and SHALL use the single returned assistant ID as the runtime assistant identifier
5. IF the specified Connect instance ID has no associated Q in Connect assistant, THEN THE Platform SHALL fail the deployment with an error message indicating that no assistant was found for the provided instance ID

### Requirement 3: AI Agent Discovery and Display

**User Story:** As a tester, I want to see all AI Agents on my Connect instance, so that I can select which agent to test.

#### Acceptance Criteria

1. WHEN a user navigates to the agent browser page, THE Platform SHALL call ListAIAgents on the configured assistant and display all returned agents in a list, showing results within 5 seconds of page load
2. THE Platform SHALL display for each agent: name, agent ID, type, tool count, and model ID
3. WHEN a user selects an AI Agent, THE Platform SHALL retrieve the agent's full configuration using GetAIAgent, including the system prompt, configured tools (with descriptions and input schemas), and associated model
4. THE Platform SHALL display the agent's tool list with tool name, description, and input schema for each tool
5. THE Platform SHALL display the agent's system prompt text in a read-only view
6. IF ListAIAgents returns zero agents, THEN THE Platform SHALL display a message indicating no agents are available on the configured assistant
7. IF the ListAIAgents or GetAIAgent API call fails, THEN THE Platform SHALL display an error message indicating the failure reason and provide the user an option to retry the request

### Requirement 4: Test Suite Management

**User Story:** As a tester, I want to create and manage test suites for a specific AI Agent, so that I can organize my test scenarios.

#### Acceptance Criteria

1. THE Platform SHALL provide a form-based interface for creating a new Test Suite with a required name (maximum 128 characters), an optional description (maximum 500 characters), and an associated AI Agent selected from discovered agents
2. THE Platform SHALL persist Test Suites to DynamoDB with a composite key of tenant ID and suite ID
3. IF a user submits the Test Suite form with a missing name or without selecting an AI Agent, THEN THE Platform SHALL display a validation error indicating which required fields are missing and SHALL NOT create the Test Suite
4. WHEN a user opens an existing Test Suite, THE Platform SHALL load and display all associated Test Cases showing each case's name and status
5. THE Platform SHALL allow editing a Test Suite name and description, subject to the same validation constraints as creation
6. THE Platform SHALL allow deleting a Test Suite only after the user confirms the deletion, and SHALL remove the Test Suite and all its associated Test Cases upon confirmation

### Requirement 5: Test Case Authoring

**User Story:** As a tester, I want to define individual test cases that describe a customer scenario with multi-step tool sequences, so that the platform can simulate that customer through a complete journey and evaluate agent performance across all steps.

#### Acceptance Criteria

1. THE Platform SHALL provide a form-based editor for creating a Test Case with the following fields: name (maximum 100 characters), description of the customer use case (maximum 2000 characters), persona communication style, customer knowledge as key-value pairs (maximum 20 pairs, each key maximum 100 characters and each value maximum 500 characters), initial utterance (maximum 1000 characters), and success criteria
2. THE Platform SHALL support success criteria defined as an ordered sequence of expected tool invocations containing between 1 and 30 steps, where each step specifies a tool name and optional parameter value checks (maximum 10 parameter checks per step), representing the complete tool chain required to fulfill the customer's goal (such as AuthStep1 → AuthStep2 → RetrieveBookings → SearchFlights → RebookFlight)
3. THE Platform SHALL allow the user to mark individual steps in the tool sequence as required or optional to accommodate cases where the agent may legitimately skip a step, with newly added steps defaulting to required
4. IF the user attempts to save a Test Case that is missing a description, initial utterance, or has no expected tool in the success criteria, THEN THE Platform SHALL prevent the save operation and display a validation error message indicating which required fields are missing
5. THE Platform SHALL store Test Cases in DynamoDB associated with their parent Test Suite
6. WHEN a user specifies customer knowledge key-value pairs, THE Platform SHALL make those values available to the Customer Simulator during test execution as persona context

### Requirement 6: Intelligent Test Case Scaffolding

**User Story:** As a tester, I want the platform to reason about the agent's tools when I describe a customer goal, determine the likely tool chain, and generate the customer knowledge template automatically, so that I only need to provide the scenario description and fill in the test data.

#### Acceptance Criteria

1. WHEN a user provides a customer goal description for a Test Case, THE Platform SHALL use Bedrock to analyze all tools configured on the target AI Agent and return an ordered sequence of tool invocations required to fulfill that goal within 30 seconds, with each tool in the sequence labeled as required (must be invoked for goal completion) or optional (may be invoked depending on conversation path)
2. WHEN the Platform completes tool sequence inference, THE Platform SHALL present the inferred tool sequence to the user as the suggested success criteria, displaying each tool's name, its position in the sequence, and its required/optional label
3. WHEN the user accepts or modifies the inferred tool sequence, THE Platform SHALL analyze the input schema of each tool in the sequence to identify all input parameters needed, then generate a consolidated customer knowledge template containing one field per unique parameter, where parameters are considered duplicates if they share the same parameter name across multiple tools in the sequence
4. THE Platform SHALL use Bedrock to map each technical parameter name in the generated template to a descriptive customer-facing label and group parameters by the first tool in the sequence that requires them
5. IF Bedrock cannot determine a tool sequence from the provided goal description (due to ambiguity, insufficient tool coverage, or service error), THEN THE Platform SHALL display a message indicating the reason the sequence could not be inferred and allow the user to manually build the tool sequence and knowledge template
6. THE Platform SHALL allow the user to accept, modify, reorder, add, or remove tools in the suggested sequence and fields in the generated knowledge template before saving the Test Case

### Requirement 7: Test Execution via Conversation Driver

**User Story:** As a tester, I want to run a test suite against a live AI Agent, so that I can measure the agent's ability to handle complete customer journeys that span multiple tool invocations.

#### Acceptance Criteria

1. WHEN a user triggers a test run, THE Platform SHALL initiate a Step Functions execution that runs all Test Cases in the suite concurrently (up to a configurable concurrency limit defaulting to 9)
2. THE Conversation_Driver SHALL create a fresh Q in Connect session for each Test Case using CreateSession with a generated name parameter in the format "test-{random 8-character hex string}"
3. THE Conversation_Driver SHALL send messages using the aiAgentId parameter on SendMessage to override the default session agent and invoke the target AI Agent directly
4. THE Conversation_Driver SHALL poll GetNextMessage at an interval of 300 milliseconds with a maximum timeout of 60 seconds per poll cycle, and SHALL identify filler responses (text consisting solely of "...", "......", or "…") by checking whether the nextMessageToken has advanced, continuing to poll rather than treating filler as agent output
5. WHEN the AI Agent selects a tool, THE Conversation_Driver SHALL record the tool selection, send a follow-up message to continue the conversation (allowing the agent to proceed to subsequent tools in the journey), and NOT terminate the conversation until the agent produces a final text response with no further tool selection or the maximum turn limit is reached
6. WHEN the AI Agent responds with text that is not a filler response and no tool selection is present, THE Conversation_Driver SHALL invoke the Customer Simulator to generate a contextual follow-up response and continue the conversation up to a configurable maximum number of turns (default 20)
7. THE Conversation_Driver SHALL extract the selected tool name from the conversationSessionData array under the key "Tool" by reading the stringValue property of the matching entry when the agent makes a tool selection
8. THE Conversation_Driver SHALL track the ordered sequence of all tools invoked across the entire multi-turn conversation for comparison against the Test Case success criteria
9. THE Conversation_Driver SHALL implement exponential backoff with jitter for throttling errors (HTTP 429 or ThrottlingException or TooManyRequestsException) starting with a base delay of 2 seconds, capping at 30 seconds, with a maximum of 3 retries per API call
10. THE Conversation_Driver SHALL record the full conversation transcript for each Test Case execution including all turns with role (customer or agent), message text, tool selections, and per-turn elapsed time in milliseconds
11. THE Conversation_Driver SHALL call the ListSpans API after each test case conversation completes to retrieve the agent's reasoning trace and store it alongside the transcript
12. IF CreateSession or SendMessage returns a non-throttling error during a Test Case execution, THEN THE Conversation_Driver SHALL mark that Test Case result as an error with the failure reason and proceed to the next Test Case without aborting the suite
13. IF the poll cycle exceeds the 60-second timeout without receiving a tool selection or non-filler text response, THEN THE Conversation_Driver SHALL mark that Test Case result as timed out and proceed to the next Test Case

### Requirement 8: Customer Simulation

**User Story:** As a tester, I want the platform to simulate realistic customer behavior during multi-turn conversations, so that agent responses are tested under realistic conditions.

#### Acceptance Criteria

1. THE Customer_Simulator SHALL use Amazon Bedrock Converse API to generate customer responses based on the Test Case persona, communication style, goal, and customer knowledge, with generated responses limited to a maximum of 150 tokens
2. THE Customer_Simulator SHALL flip conversation roles when calling Bedrock: customer messages become assistant role and agent messages become user role, so the model generates responses as the customer
3. THE Customer_Simulator SHALL only reveal customer knowledge values when the agent specifically asks for them, not volunteer information proactively
4. THE Customer_Simulator SHALL include all prior turns from the current test case execution in the Bedrock Converse API call, with roles flipped per criterion 2, so the model produces contextually coherent responses
5. IF the Bedrock Converse API call fails, THEN THE Customer_Simulator SHALL return a fixed affirmative response (e.g., a short confirmation phrase), log the error, and continue the test case execution without marking it as failed
6. THE Customer_Simulator SHALL construct a system prompt that includes the Test Case goal, the communication style description, and the customer knowledge values formatted as personal details the model may reveal only when asked
7. IF the Test Case defines a communication style, THEN THE Customer_Simulator SHALL map it to a descriptive instruction in the system prompt that constrains the model's tone and phrasing to match that style

### Requirement 9: AgentCore Evaluation Scoring

**User Story:** As a tester, I want test results scored by AgentCore evaluators, so that I get standardized quality metrics beyond simple tool match.

#### Acceptance Criteria

1. WHEN a test run completes, THE Platform SHALL submit conversation transcripts to AgentCore Evaluations for scoring using Builtin.GoalSuccessRate and Builtin.Helpfulness evaluators, and SHALL treat the submission as failed if no response is received within 60 seconds per test case
2. THE Platform SHALL define and register a custom AgentCore evaluator for ToolSelectionAccuracy that checks whether the expected tool sequence from success criteria appears as an ordered subsequence of tools invoked during the conversation (allowing other tools between required steps), distinguishing between required steps (must appear in order) and optional steps (may appear anywhere or not at all), and producing a numeric score from 0.0 to 1.0
3. WHEN AgentCore evaluation scores are received for a test run, THE Platform SHALL store each score (goal success as 0.0–1.0, helpfulness as 0.0–1.0, tool accuracy as 0.0–1.0) in the TestResults DynamoDB item for the corresponding test case
4. WHEN AgentCore evaluation results are available, THE Platform SHALL display per-test-case scores in the results view alongside the conversation transcript, showing each score as a numeric value with its label
5. IF AgentCore evaluation returns an error response or does not respond within 60 seconds for a test case, THEN THE Platform SHALL fall back to a local pass/fail determination based on tool selection subsequence matching against success criteria and SHALL display a warning indicator on that test case stating that managed scoring is unavailable
6. WHEN the Platform performs local fallback scoring, THE Platform SHALL assign a tool accuracy score of 1.0 if all required tools from the success criteria appear as an ordered subsequence in the invoked tools, and 0.0 otherwise, and SHALL leave goal success and helpfulness scores empty

### Requirement 10: Test Results Display

**User Story:** As a tester, I want to view detailed test run results, so that I can understand agent performance and diagnose failures.

#### Acceptance Criteria

1. WHEN a test run completes, THE Platform SHALL display a results summary showing total test cases, passed count, failed count, error count, and overall accuracy percentage rounded to one decimal place
2. THE Platform SHALL display a results table with one row per test case showing: test case name, status (passed, failed, or error), tools invoked, turn count, latency in milliseconds, and a goal success score between 0 and 1 representing the LLM judge evaluation
3. THE Platform SHALL display the results table sorted by status (errors first, then failed, then passed) and secondarily by test case name in alphabetical order
4. WHEN a user expands a test case row, THE Platform SHALL display the full conversation transcript with role labels (customer/agent), message text, tool selections, and timestamps in ISO 8601 format
5. THE Platform SHALL allow filtering results by status (passed, failed, error) and by tool invoked
6. WHILE a test run is in progress, THE Platform SHALL display results for completed test cases with a progress indicator showing how many test cases remain pending
7. IF a test case encounters an execution exception before producing a result, THEN THE Platform SHALL display that test case with error status and an error message indicating the failure reason
8. THE Platform SHALL store test run results in DynamoDB keyed by suite ID and run timestamp for historical access

### Requirement 11: Live Run Progress

**User Story:** As a tester, I want to see test execution progress in real time, so that I know whether a run is succeeding or encountering problems.

#### Acceptance Criteria

1. WHILE a test run is in progress, THE Platform SHALL display a progress indicator showing completed test cases out of total, current pass/fail/error counts, and elapsed time in MM:SS format
2. WHILE a test run is in progress, THE Platform SHALL update the progress display within 5 seconds of each test case completing, without requiring a page refresh
3. WHILE a test run is in progress, THE Platform SHALL display an abort button that, when activated, terminates the Step Functions execution
4. WHEN a user activates the abort action, THE Platform SHALL update the run status to a terminated state within 10 seconds and stop displaying the progress indicator as active
5. WHEN a test run completes or is aborted, THE Platform SHALL display a final summary showing total passed, failed, and error counts, total elapsed time, and the terminal status of the run

### Requirement 12: Failure Analysis and Recommendations

**User Story:** As a tester, I want the platform to analyze test failures using agent reasoning traces and recommend specific changes to tool descriptions or the system prompt, so that I can improve agent accuracy without manually diagnosing each failure.

#### Acceptance Criteria

1. WHEN a test case completes, THE Platform SHALL call the ListSpans API on the Q in Connect session to retrieve the AI Agent's internal reasoning trace, including tool selection logic, considered tools, and rejection reasons
2. WHEN a test case fails, THE Platform SHALL use Bedrock to analyze the conversation transcript, the ListSpans reasoning trace, the expected tool sequence, the actual tool sequence, and the agent's configured tool descriptions and system prompt to determine the likely root cause of the failure
3. WHEN the failure analysis for a test case completes, THE Platform SHALL present a plain-language explanation of why the failed test case did not achieve the expected outcome, incorporating at least one piece of evidence from the reasoning trace (such as "The agent's reasoning trace shows it considered TransferFunds but ranked PayBill higher because the PayBill description also mentions 'send money to a recipient'")
4. WHEN a failure root cause is identified, THE Platform SHALL generate between 1 and 5 actionable recommendations per failed test case, where each recommendation includes a proposed edit to a specific tool description, tool instruction field, or system prompt text that addresses the identified root cause
5. THE Platform SHALL display recommendations as a diff view showing the current text and the suggested replacement for each proposed change
6. WHEN 2 or more test cases within the same test run fail and the Bedrock analysis attributes them to the same root cause category (such as overlapping tool descriptions, missing disambiguation guidance, or incorrect tool prioritization), THE Platform SHALL group those failures and present a consolidated recommendation rather than repeating the same suggestion per test case
7. IF the ListSpans API returns no reasoning trace data or the API call fails, THEN THE Platform SHALL proceed with failure analysis using the available conversation transcript and tool sequences, and SHALL indicate in the explanation that reasoning trace evidence was unavailable

### Requirement 13: Historical Results and Comparison

**User Story:** As a tester, I want to re-run test suites and compare results across runs, so that I can detect regressions when agent configuration changes.

#### Acceptance Criteria

1. THE Platform SHALL persist all Test Runs in DynamoDB keyed by suite ID and run timestamp, retaining per-case scores, transcripts, and evaluation metrics for a minimum of 90 days
2. WHEN a user re-runs a Test Suite, THE Platform SHALL create a new Test Run record without overwriting previous results
3. THE Platform SHALL provide a run history view listing past runs for a Test Suite sorted by run timestamp in descending order, displaying summary metrics (accuracy, pass rate, average latency) for each run, with a maximum of 50 runs per page and pagination controls to access older runs
4. WHEN a user selects two test runs for comparison, THE Platform SHALL display a comparison view showing which test cases changed status (passed-to-failed, failed-to-passed, error-to-passed, passed-to-error) between the runs, and SHALL indicate test cases that exist in only one of the two runs as "added" or "removed"
5. THE Platform SHALL snapshot the AI Agent configuration (tools, prompt, model) at the time of each test run and store it with the run record
6. WHEN a user views a comparison between two test runs, THE Platform SHALL display a configuration diff highlighting changes to tools, prompt, and model between the two run snapshots, so that result differences can be correlated with configuration changes

### Requirement 14: Infrastructure as Code

**User Story:** As a deployer, I want the entire platform deployed via CDK, so that the infrastructure is repeatable, version-controlled, and follows AWS best practices.

#### Acceptance Criteria

1. THE Platform SHALL be defined as a CDK (TypeScript) application that deploys all required resources: Cognito User Pool and Identity Pool, API Gateway, Lambda functions, Step Functions state machine, DynamoDB tables, S3 bucket, and CloudFront distribution
2. THE Platform SHALL deploy the React frontend as a static site to S3 with CloudFront distribution
3. THE Platform SHALL create a separate IAM role for each Lambda function where each role grants only the permissions required by that function's actions, scoped to the specific Connect instance ARN provided as a deployment parameter and the specific Bedrock model ARNs used by the platform
4. WHEN a user runs cdk deploy providing the required parameters (AWS account, region, Connect instance ARN, and Cognito callback URL), THE Platform SHALL provision all resources such that the CloudFront URL serves the frontend, the API Gateway endpoint accepts authenticated requests, and test suite execution completes successfully against the configured Connect instance without any manual resource creation or configuration steps
5. IF a cdk deploy execution fails, THEN THE Platform SHALL roll back all resources created during that execution to avoid partially provisioned environments

### Requirement 15: Machine-to-Machine Authentication (CI/CD)

**User Story:** As a CI/CD pipeline operator, I want to trigger test runs and retrieve results programmatically without interactive login, so that I can automate agent regression testing as part of my deployment workflow.

#### Acceptance Criteria

1. THE Platform SHALL configure a Cognito Resource Server on the User Pool with a custom scope `test-platform/run` that grants access to test execution and results retrieval API endpoints
2. THE Platform SHALL create a second Cognito App Client configured with the `client_credentials` OAuth grant type, associated with the `test-platform/run` scope, and generate a client ID and client secret pair for machine-to-machine authentication
3. WHEN a CI/CD client calls the Cognito token endpoint (`POST /oauth2/token`) with the client ID, client secret, and `grant_type=client_credentials`, THE Platform SHALL return a valid access token that the API Gateway Cognito authorizer accepts on all API routes
4. THE Platform SHALL ensure the API Gateway Cognito authorizer validates both user-pool tokens (from interactive login) and client-credentials tokens (from machine clients) without requiring separate authorizer configurations
5. WHEN a machine client makes an API request with a valid client-credentials access token, THE Platform SHALL use a default tenant identifier derived from the client ID for data isolation, since no user identity is associated with the token
6. THE Platform SHALL output the machine client ID and the Cognito token endpoint URL as CDK stack outputs so that CI/CD pipelines can retrieve them without manual configuration
7. THE Platform SHALL store the machine client secret in AWS Secrets Manager and output the secret ARN as a CDK stack output, allowing pipelines to retrieve the secret via the AWS SDK
