/**
 * `suite_scaffold` — system prompt for the Bedrock Converse call that
 * infers the ordered tool-chain sequence inside the
 * `POST /suites/{suiteId}/cases/scaffold` handler. The user message
 * (containing the customer goal and the agent's tool catalog) is
 * constructed dynamically by `buildToolSequencePrompt`; the registered
 * prompt is the literal `system` block lifted byte-for-byte from
 * `src/backend/handlers/scaffold.ts`'s `inferToolSequence` call.
 *
 * Resolved at the callsite via `resolvePromptLive("suite_scaffold")`
 * after the Wave 1 migration (Task 15.2 of the plan). Until then the
 * registry definition exists but the callsite still reads its literal —
 * the registry is the source of truth, the callsite is the consumer.
 *
 * @module backend/orchestration/prompt-registry/prompts/suite-scaffold
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

/**
 * The byte-for-byte literal currently passed as the `system` text in the
 * `inferToolSequence` `ConverseCommand` in `scaffold.ts`. Any edit here
 * must remain identical to that literal until the Wave 1 migration lands;
 * the unit-test invariant in Task 2.7 imports both this constant and the
 * legacy module and compares the strings directly.
 */
const DEFAULT_TEXT =
  "You are an AI agent tool chain analyzer. Respond only with valid JSON matching the requested schema. Do not include markdown code fences.";

export const suiteScaffoldPrompt: PromptDefinition = {
  promptKey: "suite_scaffold",
  name: "Suite Scaffold — Tool Chain Analyzer",
  description:
    "System prompt for the Converse call that infers an ordered tool-chain sequence from a customer goal. Used by the suite-level case-scaffolding endpoint.",
  category: "scaffolding",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [],
  inferenceParameters: {
    // Anthropic 4.x capability profile accepts only `maxTokens`. Bound the
    // upper end of the schema by Sonnet 4.6's per-model output cap so the
    // dry-render validator catches an over-large override before persistence.
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 4_096 },
  },
  defaultInferenceValues: {
    maxTokens: 4_096,
  },
};
