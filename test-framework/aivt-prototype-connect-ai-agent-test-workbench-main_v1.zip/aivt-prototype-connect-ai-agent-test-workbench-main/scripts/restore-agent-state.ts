/**
 * restore-agent-state.ts — Roll back Q in Connect AI agents / AI prompts from a
 * snapshot produced by backup-agent-state.ts.
 *
 * Mirrors what the platform's config-writer does on apply:
 *   - tool-surface state  -> UpdateAIAgent  (orchestrationAIAgentConfiguration)
 *   - system-prompt state -> UpdateAIPrompt (templateConfiguration)
 *
 * SAFETY:
 *   - Defaults to a DRY RUN. It prints exactly which agents/prompts it would
 *     update and exits without mutating anything.
 *   - Pass --apply to actually perform the writes.
 *   - Restrict scope with --only=<id>[,<id>...] to restore just the resources
 *     you changed during testing (recommended).
 *
 * Usage:
 *   ASSISTANT_ID=<uuid> npx tsx scripts/restore-agent-state.ts --backup=<dir>            # dry run, all
 *   ASSISTANT_ID=<uuid> npx tsx scripts/restore-agent-state.ts --backup=<dir> --only=<agentOrPromptId>
 *   ASSISTANT_ID=<uuid> npx tsx scripts/restore-agent-state.ts --backup=<dir> --only=<id> --apply
 */
import * as fs from 'fs';
import * as path from 'path';
import {
  QConnectClient,
  GetAIAgentCommand,
  UpdateAIAgentCommand,
  GetAIPromptCommand,
  UpdateAIPromptCommand,
} from '@aws-sdk/client-qconnect';

const ASSISTANT_ID = process.env.ASSISTANT_ID;
if (!ASSISTANT_ID) throw new Error('Set ASSISTANT_ID to the Q in Connect assistant UUID');
const REGION = process.env.AWS_REGION ?? 'us-east-1';

const args = process.argv.slice(2);
const backupArg = args.find((a) => a.startsWith('--backup='));
if (!backupArg) throw new Error('Provide --backup=<snapshot dir>');
const backupDir = backupArg.split('=')[1];
const apply = args.includes('--apply');
const onlyArg = args.find((a) => a.startsWith('--only='));
const onlyIds = onlyArg ? new Set(onlyArg.split('=')[1].split(',')) : null;

const client = new QConnectClient({ region: REGION });

/** Strip a trailing :version qualifier from an ID. */
function bareId(id: string): string {
  return id.includes(':') ? id.split(':')[0] : id;
}

async function restoreAgent(file: string): Promise<void> {
  const snap = JSON.parse(fs.readFileSync(file, 'utf8'));
  const agentId = bareId(snap.aiAgentId as string);
  if (onlyIds && !onlyIds.has(agentId) && !onlyIds.has(snap.aiAgentId)) return;

  const cfg = snap.configuration?.orchestrationAIAgentConfiguration;
  if (!cfg) {
    console.log(`  [skip] agent ${snap.name} (${agentId}) — no orchestration config in snapshot`);
    return;
  }

  console.log(`  agent ${snap.name} (${agentId})`);
  console.log(`    promptId: ${cfg.orchestrationAIPromptId}`);
  console.log(`    tools:    ${Array.isArray(cfg.toolConfigurations) ? cfg.toolConfigurations.length : 'n/a'}`);

  if (!apply) {
    console.log('    [dry run] would UpdateAIAgent with snapshot configuration');
    return;
  }

  // Re-read for visibilityStatus required by UpdateAIAgent.
  const live = await client.send(
    new GetAIAgentCommand({ assistantId: ASSISTANT_ID, aiAgentId: agentId }),
  );
  const visibilityStatus = live.aiAgent?.visibilityStatus ?? snap.visibilityStatus;

  // Build tool configurations. UpdateAIAgent WITHOUT toolConfigurations
  // WIPES them (the API does NOT preserve when omitted). MCP tools reject
  // inputSchema/description/title/outputSchema overrides, so we strip those
  // while preserving the rest. RTC tools keep their full shape.
  const rawTools: any[] = cfg.toolConfigurations ?? [];
  const sanitizedTools = rawTools.map((t: any) => {
    if (t.toolType === 'RETURN_TO_CONTROL') return t;
    // MCP: strip fields the API rejects
    const { inputSchema, description, title, outputSchema, ...rest } = t;
    return rest;
  });

  await client.send(
    new UpdateAIAgentCommand({
      assistantId: ASSISTANT_ID,
      aiAgentId: agentId,
      visibilityStatus,
      configuration: {
        orchestrationAIAgentConfiguration: {
          orchestrationAIPromptId: cfg.orchestrationAIPromptId,
          toolConfigurations: sanitizedTools,
          ...(cfg.locale ? { locale: cfg.locale } : {}),
          ...(cfg.connectInstanceArn ? { connectInstanceArn: cfg.connectInstanceArn } : {}),
          ...(cfg.orchestrationAIGuardrailId ? { orchestrationAIGuardrailId: cfg.orchestrationAIGuardrailId } : {}),
        },
      },
    }),
  );
  console.log('    [applied] UpdateAIAgent complete (prompt re-pointed, tools preserved)');
}

async function restorePrompt(file: string): Promise<void> {
  const snap = JSON.parse(fs.readFileSync(file, 'utf8'));
  const promptId = bareId(snap.aiPromptId as string);
  if (onlyIds && !onlyIds.has(promptId) && !onlyIds.has(snap.aiPromptId)) return;

  const templateConfiguration = snap.templateConfiguration;
  if (!templateConfiguration) {
    console.log(`  [skip] prompt ${snap.name} (${promptId}) — no templateConfiguration in snapshot`);
    return;
  }

  console.log(`  prompt ${snap.name} (${promptId})`);
  if (!apply) {
    console.log('    [dry run] would UpdateAIPrompt with snapshot template');
    return;
  }

  const live = await client.send(
    new GetAIPromptCommand({ assistantId: ASSISTANT_ID, aiPromptId: promptId }),
  );
  const visibilityStatus = live.aiPrompt?.visibilityStatus ?? snap.visibilityStatus;

  await client.send(
    new UpdateAIPromptCommand({
      assistantId: ASSISTANT_ID,
      aiPromptId: promptId,
      visibilityStatus,
      templateConfiguration,
    }),
  );
  console.log('    [applied] UpdateAIPrompt complete');
}

async function main() {
  const agentsDir = path.join(backupDir, 'agents');
  const promptsDir = path.join(backupDir, 'prompts');

  console.log(
    `${apply ? 'APPLYING' : 'DRY RUN'} restore from ${backupDir}` +
      (onlyIds ? ` (only: ${[...onlyIds].join(', ')})` : ' (all resources)'),
  );

  console.log('Agents:');
  for (const f of fs.existsSync(agentsDir) ? fs.readdirSync(agentsDir) : []) {
    if (f.endsWith('.json')) await restoreAgent(path.join(agentsDir, f));
  }

  console.log('Prompts:');
  for (const f of fs.existsSync(promptsDir) ? fs.readdirSync(promptsDir) : []) {
    if (f.endsWith('.json')) await restorePrompt(path.join(promptsDir, f));
  }

  console.log(apply ? 'Restore complete.' : 'Dry run complete. Re-run with --apply to write.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
