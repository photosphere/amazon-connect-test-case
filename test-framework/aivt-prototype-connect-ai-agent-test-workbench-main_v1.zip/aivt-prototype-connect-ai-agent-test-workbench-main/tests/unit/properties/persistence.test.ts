// Feature: connect-agent-test-platform, Property 2: Entity Persistence Round-Trip
import { describe, it, expect, beforeEach } from "vitest";
import fc from "fast-check";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { createDynamoDBService } from "@backend/services/dynamodb";
import { CaseStatus, CommunicationStyle } from "@shared/enums";

/**
 * **Validates: Requirements 4.2, 5.5, 9.3, 10.8**
 *
 * Property 2: Entity Persistence Round-Trip
 * For any valid test suite, test case, or test result object,
 * persisting it to DynamoDB and then retrieving it by its composite key
 * SHALL produce an object equal to the original (all fields preserved,
 * no data loss or corruption during serialization/deserialization).
 */

// ---------------------------------------------------------------------------
// In-memory mock DynamoDBDocumentClient
// ---------------------------------------------------------------------------

/**
 * Creates a mock DynamoDBDocumentClient backed by an in-memory Map.
 * The mock intercepts PutCommand and GetCommand to store/retrieve items
 * by their composite PK+SK key.
 */
function createMockDocClient(): {
  client: DynamoDBDocumentClient;
  store: Map<string, Record<string, unknown>>;
} {
  const store = new Map<string, Record<string, unknown>>();

  const client = {
    send: async (command: unknown) => {
      const cmd = command as { input: Record<string, unknown>; constructor: { name: string } };
      const commandName = cmd.constructor.name;

      if (commandName === "PutCommand") {
        const item = cmd.input.Item as Record<string, unknown>;
        const key = `${item.PK}#${item.SK}`;
        // Simulate DynamoDB marshalling by deep-cloning via JSON (removes undefined)
        store.set(key, JSON.parse(JSON.stringify(item)));
        return {};
      }

      if (commandName === "GetCommand") {
        const keyObj = cmd.input.Key as Record<string, string>;
        const key = `${keyObj.PK}#${keyObj.SK}`;
        const item = store.get(key);
        return { Item: item ? { ...item } : undefined };
      }

      if (commandName === "QueryCommand") {
        // Return empty items for query operations (not needed for round-trip)
        return { Items: [] };
      }

      if (commandName === "BatchWriteCommand") {
        return {};
      }

      return {};
    },
  } as unknown as DynamoDBDocumentClient;

  return { client, store };
}

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Generates a non-empty alphanumeric-like string suitable for IDs. */
const idArb = fc.string({ minLength: 1, maxLength: 36 }).filter((s) => s.trim().length > 0);

/** Generates a non-empty string for names and descriptions. */
const nonEmptyStringArb = (maxLength: number) =>
  fc.string({ minLength: 1, maxLength }).filter((s) => s.trim().length > 0);

/** Generates an ISO 8601 timestamp string. */
const isoTimestampArb = fc.date({ min: new Date("2020-01-01"), max: new Date("2030-12-31") })
  .map((d) => d.toISOString());

/** Generates a valid TestSuite. */
const testSuiteArb = fc.record({
  tenantId: idArb,
  suiteId: idArb,
  name: nonEmptyStringArb(128),
  description: fc.option(nonEmptyStringArb(500), { nil: undefined }),
  agentId: idArb,
  assistantId: idArb,
  createdAt: isoTimestampArb,
  updatedAt: isoTimestampArb,
});

/** Generates a valid ToolStep. */
const toolStepArb = fc.record({
  toolName: nonEmptyStringArb(50),
  required: fc.boolean(),
  parameterChecks: fc.option(
    fc.array(
      fc.record({
        paramName: fc.string({ minLength: 1, maxLength: 50 }),
        expectedValue: fc.string({ maxLength: 100 }),
      }),
      { minLength: 0, maxLength: 10 }
    ),
    { nil: undefined }
  ),
});

/** Generates a valid TestCase. */
const testCaseArb = fc.record({
  type: fc.constant("tool_sequence" as const),
  suiteId: idArb,
  caseId: idArb,
  name: nonEmptyStringArb(100),
  description: nonEmptyStringArb(2000),
  persona: nonEmptyStringArb(100),
  style: fc.constantFrom(
    CommunicationStyle.DIRECT,
    CommunicationStyle.INDIRECT,
    CommunicationStyle.COLLOQUIAL,
    CommunicationStyle.QUESTION,
    CommunicationStyle.COMPLAINT
  ),
  customerKnowledge: fc.dictionary(
    fc.string({ minLength: 1, maxLength: 50 }),
    fc.string({ minLength: 1, maxLength: 100 }),
    { minKeys: 0, maxKeys: 10 }
  ),
  initialUtterance: nonEmptyStringArb(1000),
  successCriteria: fc.array(toolStepArb, { minLength: 1, maxLength: 10 }),
});

/** Generates a valid TestCaseResult. */
const testCaseResultArb = fc.record({
  runId: idArb,
  caseId: idArb,
  status: fc.constantFrom(
    CaseStatus.PASSED,
    CaseStatus.FAILED,
    CaseStatus.ERROR,
    CaseStatus.TIMED_OUT
  ),
  toolsInvoked: fc.array(nonEmptyStringArb(50), { minLength: 0, maxLength: 10 }),
  turnCount: fc.nat({ max: 20 }),
  latencyMs: fc.nat({ max: 60000 }),
  goalSuccessScore: fc.option(fc.double({ min: 0, max: 1, noNaN: true }), { nil: undefined }),
  helpfulnessScore: fc.option(fc.double({ min: 0, max: 1, noNaN: true }), { nil: undefined }),
  toolAccuracyScore: fc.option(fc.double({ min: 0, max: 1, noNaN: true }), { nil: undefined }),
  errorMessage: fc.option(nonEmptyStringArb(500), { nil: undefined }),
});

// ---------------------------------------------------------------------------
// Property tests
// ---------------------------------------------------------------------------

describe("Property 2: Entity Persistence Round-Trip", () => {
  beforeEach(() => {
    createMockDocClient();
  });

  it("TestSuite round-trip preserves all fields", async () => {
    await fc.assert(
      fc.asyncProperty(testSuiteArb, async (suite) => {
        const { client } = createMockDocClient();
        const service = createDynamoDBService("TestTable", client);

        await service.createSuite(suite);
        const retrieved = await service.getSuite(suite.tenantId, suite.suiteId);

        expect(retrieved).not.toBeNull();
        // Compare all domain fields (stripKeys removes PK/SK/GSI keys)
        expect(retrieved!.tenantId).toEqual(suite.tenantId);
        expect(retrieved!.suiteId).toEqual(suite.suiteId);
        expect(retrieved!.name).toEqual(suite.name);
        expect(retrieved!.agentId).toEqual(suite.agentId);
        expect(retrieved!.assistantId).toEqual(suite.assistantId);
        expect(retrieved!.createdAt).toEqual(suite.createdAt);
        expect(retrieved!.updatedAt).toEqual(suite.updatedAt);
        // description may be undefined — compare accordingly
        if (suite.description !== undefined) {
          expect(retrieved!.description).toEqual(suite.description);
        } else {
          expect(retrieved!.description).toBeUndefined();
        }
      }),
      { numRuns: 100 }
    );
  });

  it("TestCase round-trip preserves all fields", async () => {
    await fc.assert(
      fc.asyncProperty(testCaseArb, async (testCase) => {
        const { client } = createMockDocClient();
        const service = createDynamoDBService("TestTable", client);

        await service.createCase(testCase);
        const retrieved = await service.getCase(testCase.suiteId, testCase.caseId);

        expect(retrieved).not.toBeNull();
        expect(retrieved!.suiteId).toEqual(testCase.suiteId);
        expect(retrieved!.caseId).toEqual(testCase.caseId);
        expect(retrieved!.name).toEqual(testCase.name);
        expect(retrieved!.description).toEqual(testCase.description);
        expect((retrieved as any).persona).toEqual(testCase.persona);
        expect((retrieved as any).style).toEqual(testCase.style);
        expect((retrieved as any).customerKnowledge).toEqual(testCase.customerKnowledge);
        expect((retrieved as any).initialUtterance).toEqual(testCase.initialUtterance);
        expect((retrieved as any).successCriteria).toEqual(testCase.successCriteria);
      }),
      { numRuns: 100 }
    );
  });

  it("TestCaseResult round-trip preserves all fields", async () => {
    await fc.assert(
      fc.asyncProperty(testCaseResultArb, async (result) => {
        const { client } = createMockDocClient();
        const service = createDynamoDBService("TestTable", client);

        await service.writeResult(result);
        const retrieved = await service.getResult(result.runId, result.caseId);

        expect(retrieved).not.toBeNull();
        expect(retrieved!.runId).toEqual(result.runId);
        expect(retrieved!.caseId).toEqual(result.caseId);
        expect(retrieved!.status).toEqual(result.status);
        expect(retrieved!.toolsInvoked).toEqual(result.toolsInvoked);
        expect(retrieved!.turnCount).toEqual(result.turnCount);
        expect(retrieved!.latencyMs).toEqual(result.latencyMs);

        // Optional score fields
        if (result.goalSuccessScore !== undefined) {
          expect(retrieved!.goalSuccessScore).toEqual(result.goalSuccessScore);
        } else {
          expect(retrieved!.goalSuccessScore).toBeUndefined();
        }
        if (result.helpfulnessScore !== undefined) {
          expect(retrieved!.helpfulnessScore).toEqual(result.helpfulnessScore);
        } else {
          expect(retrieved!.helpfulnessScore).toBeUndefined();
        }
        if (result.toolAccuracyScore !== undefined) {
          expect(retrieved!.toolAccuracyScore).toEqual(result.toolAccuracyScore);
        } else {
          expect(retrieved!.toolAccuracyScore).toBeUndefined();
        }
        if (result.errorMessage !== undefined) {
          expect(retrieved!.errorMessage).toEqual(result.errorMessage);
        } else {
          expect(retrieved!.errorMessage).toBeUndefined();
        }
      }),
      { numRuns: 100 }
    );
  });
});
