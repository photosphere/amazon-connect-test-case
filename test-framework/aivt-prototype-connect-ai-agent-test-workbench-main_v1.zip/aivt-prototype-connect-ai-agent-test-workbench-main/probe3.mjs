// Test how to satisfy the MCP gateway's "ContactARN not found in session" error.
// Strategy A: inject ContactARN-ish keys via UpdateSessionData (Custom namespace).
// Strategy B: pass a made-up contactArn on CreateSession (root binding).
// Strategy C: both.
import {
  QConnectClient,
  CreateSessionCommand,
  SendMessageCommand,
  GetNextMessageCommand,
  ListSpansCommand,
  UpdateSessionDataCommand,
} from "@aws-sdk/client-qconnect";
import { randomUUID } from "crypto";

const REGION = "us-east-1";
const ASSISTANT_ID = "5664eea5-381d-468e-bfba-302b69ae6dec";
const INSTANCE_ID = "46837cc7-8562-4b3f-92b2-1bae0ede624b";
const ANYBANK = "d54d3dee-b9ec-415a-9a4b-b4769426f365";
// Give both ANI and SSN up front so the agent calls verifyIdentity on turn 1.
const UTTERANCE =
  "Hi, my phone number is 407 462 9069 and the last four of my SSN is 1234. Can you pull up my mortgage?";

const client = new QConnectClient({ region: REGION });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function fakeContactArn() {
  return `arn:aws:connect:${REGION}:104220062740:instance/${INSTANCE_ID}/contact/${randomUUID()}`;
}

async function drive(sessionId, token) {
  // Poll through up to ~25s so verifyIdentity gets called and returns.
  let cur = token;
  const start = Date.now();
  while (Date.now() - start < 25000) {
    const r = await client.send(
      new GetNextMessageCommand({ assistantId: ASSISTANT_ID, sessionId, nextMessageToken: cur })
    );
    const status = r.conversationState?.status;
    cur = r.nextMessageToken ?? cur;
    if (status === "CLOSED") break;
    await sleep(500);
  }
}

async function verifyResult(sessionId) {
  let nextToken;
  const results = [];
  do {
    const resp = await client.send(
      new ListSpansCommand({ assistantId: ASSISTANT_ID, sessionId, nextToken, maxResults: 100 })
    );
    for (const s of resp.spans ?? []) {
      if (s.spanName === "execute_tool") {
        const a = s.attributes ?? {};
        for (const o of a.outputMessages ?? []) {
          for (const v of o.values ?? []) {
            const tr = v.toolResult;
            if (tr) results.push(JSON.stringify(tr.values?.[0]?.text?.value ?? tr));
          }
        }
      }
    }
    nextToken = resp.nextToken;
  } while (nextToken);
  return results;
}

async function strategy(label, { sessionData, contactArn }) {
  const name = `probe3-${Math.random().toString(16).slice(2, 10)}`;
  try {
    const cs = await client.send(
      new CreateSessionCommand({
        assistantId: ASSISTANT_ID,
        name,
        ...(contactArn ? { contactArn } : {}),
      })
    );
    const sessionId = cs.session?.sessionId;

    if (sessionData) {
      await client.send(
        new UpdateSessionDataCommand({ assistantId: ASSISTANT_ID, sessionId, data: sessionData })
      );
    }

    const sm = await client.send(
      new SendMessageCommand({
        assistantId: ASSISTANT_ID,
        sessionId,
        type: "TEXT",
        message: { value: { text: { value: UTTERANCE } } },
        aiAgentId: ANYBANK,
      })
    );
    await drive(sessionId, sm.nextMessageToken);
    await sleep(1500);
    const results = await verifyResult(sessionId);
    console.log(`\n### ${label}`);
    console.log(`session=${sessionId}`);
    console.log(`verifyIdentity toolResults: ${results.length ? results.join(" | ") : "<none captured>"}`);
  } catch (e) {
    console.log(`\n### ${label}\nERROR: ${e.name}: ${e.message}`);
  }
}

const ani = [{ key: "ANI", value: { stringValue: "4074629069" } }];
const arn = fakeContactArn();

// A: ANI + ContactARN-ish keys as session data
await strategy("A: session data ContactARN/contactId keys", {
  sessionData: [
    ...ani,
    { key: "ContactARN", value: { stringValue: arn } },
    { key: "contactArn", value: { stringValue: arn } },
    { key: "ContactId", value: { stringValue: arn.split("/").pop() } },
    { key: "contactId", value: { stringValue: arn.split("/").pop() } },
  ],
});

// B: made-up contactArn on CreateSession (root binding) + ANI
await strategy("B: CreateSession contactArn + ANI session data", {
  contactArn: arn,
  sessionData: ani,
});

// C: both
await strategy("C: CreateSession contactArn + ContactARN session data", {
  contactArn: arn,
  sessionData: [...ani, { key: "ContactARN", value: { stringValue: arn } }],
});

console.log("\nDONE");
