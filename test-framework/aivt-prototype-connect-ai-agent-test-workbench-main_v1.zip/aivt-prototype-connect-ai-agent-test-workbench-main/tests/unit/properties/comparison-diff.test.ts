// Feature: connect-agent-test-platform, Property 14: Run comparison diff correctness
// Feature: connect-agent-test-platform, Property 15: Agent configuration diff
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { compareRuns } from "@shared/utils/run-comparison";
import { diffAgentConfigs } from "@shared/utils/config-diff";
import { CaseStatus } from "@shared/enums";
import type { TestCaseResult, AgentSnapshot, ToolDefinition } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

const caseStatusArb = fc.constantFrom(
  CaseStatus.PASSED,
  CaseStatus.FAILED,
  CaseStatus.ERROR,
  CaseStatus.TIMED_OUT
);

/** Generates a minimal TestCaseResult with a given caseId and status. */
function testCaseResultArb(caseId: string, status: CaseStatus): TestCaseResult {
  return {
    runId: "run-placeholder",
    caseId,
    status,
    toolsInvoked: [],
    turnCount: 1,
    latencyMs: 100,
  };
}

/** Generates a unique caseId string. */
const caseIdArb = fc.string({ minLength: 1, maxLength: 20 }).filter((s) => s.trim().length > 0);

/** Generates a ToolDefinition. */
const toolDefinitionArb: fc.Arbitrary<ToolDefinition> = fc.record({
  toolName: fc.string({ minLength: 1, maxLength: 30 }).filter((s) => s.trim().length > 0),
  toolType: fc.constantFrom("function", "action", "query"),
  description: fc.string({ minLength: 0, maxLength: 100 }),
  instruction: fc.option(fc.string({ maxLength: 100 }), { nil: undefined }),
  inputSchema: fc.constant({}),
  examples: fc.constant<string[]>([]),
});

/** Generates an AgentSnapshot with unique tool names (matching real agent behavior). */
const agentSnapshotArb: fc.Arbitrary<AgentSnapshot> = fc
  .record({
    tools: fc.array(toolDefinitionArb, { minLength: 0, maxLength: 10 }),
    systemPrompt: fc.string({ maxLength: 200 }),
    modelId: fc.string({ minLength: 1, maxLength: 50 }),
    capturedAt: fc.constant("2024-01-01T00:00:00Z"),
  })
  .map((snapshot) => {
    // Deduplicate tools by toolName (agents have unique tool names in practice)
    const seen = new Set<string>();
    const uniqueTools = snapshot.tools.filter((t) => {
      if (seen.has(t.toolName)) return false;
      seen.add(t.toolName);
      return true;
    });
    return { ...snapshot, tools: uniqueTools };
  });

// ---------------------------------------------------------------------------
// Property 14: Run comparison diff correctness
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 13.4, 13.6**
 *
 * Property 14: Run comparison diff correctness
 * For any two test run result sets R₁ and R₂ for the same suite, the comparison
 * function SHALL correctly identify: (a) cases present in both with a status change,
 * (b) cases present in R₂ but not R₁ as "added", (c) cases present in R₁ but not
 * R₂ as "removed", and (d) cases with unchanged status.
 */
describe("Property 14: Run comparison diff correctness", () => {
  it("total entries equals union of all caseIds from both runs", () => {
    fc.assert(
      fc.property(
        fc.uniqueArray(caseIdArb, { minLength: 0, maxLength: 15 }),
        fc.uniqueArray(caseIdArb, { minLength: 0, maxLength: 15 }),
        fc.func(caseStatusArb),
        fc.func(caseStatusArb),
        (caseIdsA, caseIdsB, statusGenA, statusGenB) => {
          const runA: TestCaseResult[] = caseIdsA.map((id) =>
            testCaseResultArb(id, statusGenA(id))
          );
          const runB: TestCaseResult[] = caseIdsB.map((id) =>
            testCaseResultArb(id, statusGenB(id))
          );

          const result = compareRuns(runA, runB);

          const expectedUnion = new Set([...caseIdsA, ...caseIdsB]);
          const actualCaseIds = new Set(result.entries.map((e) => e.caseId));

          expect(actualCaseIds.size).toBe(expectedUnion.size);
          for (const id of expectedUnion) {
            expect(actualCaseIds.has(id)).toBe(true);
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  it("each case is classified correctly based on presence and status", () => {
    fc.assert(
      fc.property(
        fc.uniqueArray(caseIdArb, { minLength: 0, maxLength: 10 }),
        fc.uniqueArray(caseIdArb, { minLength: 0, maxLength: 10 }),
        fc.func(caseStatusArb),
        fc.func(caseStatusArb),
        (caseIdsA, caseIdsB, statusGenA, statusGenB) => {
          const setA = new Set(caseIdsA);
          const setB = new Set(caseIdsB);

          const runA: TestCaseResult[] = caseIdsA.map((id) =>
            testCaseResultArb(id, statusGenA(id))
          );
          const runB: TestCaseResult[] = caseIdsB.map((id) =>
            testCaseResultArb(id, statusGenB(id))
          );

          const mapA = new Map(runA.map((r) => [r.caseId, r.status]));
          const mapB = new Map(runB.map((r) => [r.caseId, r.status]));

          const result = compareRuns(runA, runB);

          for (const entry of result.entries) {
            const inA = setA.has(entry.caseId);
            const inB = setB.has(entry.caseId);

            if (inA && inB) {
              const statusA = mapA.get(entry.caseId)!;
              const statusB = mapB.get(entry.caseId)!;
              if (statusA === statusB) {
                expect(entry.category).toBe("unchanged");
                expect(entry.previousStatus).toBe(statusA);
                expect(entry.currentStatus).toBe(statusB);
              } else {
                expect(entry.category).toBe("status-changed");
                expect(entry.previousStatus).toBe(statusA);
                expect(entry.currentStatus).toBe(statusB);
              }
            } else if (inB && !inA) {
              expect(entry.category).toBe("added");
              expect(entry.currentStatus).toBe(mapB.get(entry.caseId));
              expect(entry.previousStatus).toBeUndefined();
            } else if (inA && !inB) {
              expect(entry.category).toBe("removed");
              expect(entry.previousStatus).toBe(mapA.get(entry.caseId));
              expect(entry.currentStatus).toBeUndefined();
            }
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  it("summary counts match entry classifications", () => {
    fc.assert(
      fc.property(
        fc.uniqueArray(caseIdArb, { minLength: 0, maxLength: 12 }),
        fc.uniqueArray(caseIdArb, { minLength: 0, maxLength: 12 }),
        fc.func(caseStatusArb),
        fc.func(caseStatusArb),
        (caseIdsA, caseIdsB, statusGenA, statusGenB) => {
          const runA: TestCaseResult[] = caseIdsA.map((id) =>
            testCaseResultArb(id, statusGenA(id))
          );
          const runB: TestCaseResult[] = caseIdsB.map((id) =>
            testCaseResultArb(id, statusGenB(id))
          );

          const result = compareRuns(runA, runB);

          const unchanged = result.entries.filter((e) => e.category === "unchanged").length;
          const statusChanged = result.entries.filter((e) => e.category === "status-changed").length;
          const added = result.entries.filter((e) => e.category === "added").length;
          const removed = result.entries.filter((e) => e.category === "removed").length;

          expect(result.summary.unchanged).toBe(unchanged);
          expect(result.summary.statusChanged).toBe(statusChanged);
          expect(result.summary.added).toBe(added);
          expect(result.summary.removed).toBe(removed);

          // Total entries = sum of all categories
          expect(unchanged + statusChanged + added + removed).toBe(result.entries.length);
        }
      ),
      { numRuns: 100 }
    );
  });
});

// ---------------------------------------------------------------------------
// Property 15: Agent configuration diff
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 13.4, 13.6**
 *
 * Property 15: Agent configuration diff
 * For any two agent configuration snapshots, the diff function SHALL identify all
 * differences. Returns zero diff only when identical.
 */
describe("Property 15: Agent configuration diff", () => {
  it("returns zero changes only when snapshots are functionally identical", () => {
    fc.assert(
      fc.property(agentSnapshotArb, (snapshot) => {
        // Compare a snapshot to a deep clone of itself
        const clone: AgentSnapshot = JSON.parse(JSON.stringify(snapshot));
        const result = diffAgentConfigs(snapshot, clone);

        expect(result.hasChanges).toBe(false);
        expect(result.changes).toHaveLength(0);
      }),
      { numRuns: 100 }
    );
  });

  it("detects tool additions when snapshot B has extra tools", () => {
    fc.assert(
      fc.property(
        agentSnapshotArb,
        fc.array(toolDefinitionArb, { minLength: 1, maxLength: 5 }),
        (baseSnapshot, extraTools) => {
          // Ensure extra tools have unique names not in the base snapshot
          const existingNames = new Set(baseSnapshot.tools.map((t) => t.toolName));
          const uniqueExtras = extraTools
            .map((t, i) => ({ ...t, toolName: `__extra_${i}_${t.toolName}` }))
            .filter((t) => !existingNames.has(t.toolName));

          if (uniqueExtras.length === 0) return; // skip if no unique extras

          const snapshotB: AgentSnapshot = {
            ...baseSnapshot,
            tools: [...baseSnapshot.tools, ...uniqueExtras],
          };

          const result = diffAgentConfigs(baseSnapshot, snapshotB);

          const addedChanges = result.changes.filter((c) => c.changeType === "tool-added");
          expect(addedChanges.length).toBe(uniqueExtras.length);
          for (const extra of uniqueExtras) {
            expect(addedChanges.some((c) => c.toolName === extra.toolName)).toBe(true);
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  it("detects tool removals when snapshot B is missing tools", () => {
    fc.assert(
      fc.property(
        agentSnapshotArb.filter((s) => s.tools.length > 0),
        (snapshot) => {
          // Remove one or more tools from B
          const removedCount = Math.max(1, Math.floor(snapshot.tools.length / 2));
          const removedTools = snapshot.tools.slice(0, removedCount);
          const remainingTools = snapshot.tools.slice(removedCount);

          const snapshotB: AgentSnapshot = {
            ...snapshot,
            tools: remainingTools,
          };

          const result = diffAgentConfigs(snapshot, snapshotB);

          const removedChanges = result.changes.filter((c) => c.changeType === "tool-removed");
          // Account for potential duplicate toolNames in generated data
          const uniqueRemovedNames = new Set(removedTools.map((t) => t.toolName));
          const uniqueRemainingNames = new Set(remainingTools.map((t) => t.toolName));
          const actuallyRemoved = [...uniqueRemovedNames].filter(
            (name) => !uniqueRemainingNames.has(name)
          );

          expect(removedChanges.length).toBe(actuallyRemoved.length);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("detects tool modifications (description or instruction changes)", () => {
    fc.assert(
      fc.property(
        agentSnapshotArb.filter((s) => s.tools.length > 0),
        fc.string({ minLength: 1, maxLength: 50 }),
        (snapshot, newDescription) => {
          // Modify the first tool's description
          const modifiedTools = snapshot.tools.map((t, i) =>
            i === 0 ? { ...t, description: t.description + newDescription } : { ...t }
          );

          const snapshotB: AgentSnapshot = {
            ...snapshot,
            tools: modifiedTools,
          };

          const result = diffAgentConfigs(snapshot, snapshotB);

          // The modified tool should show up as tool-modified (if description actually changed)
          if (snapshot.tools[0].description !== modifiedTools[0].description) {
            const modifiedChanges = result.changes.filter(
              (c) => c.changeType === "tool-modified" && c.toolName === snapshot.tools[0].toolName
            );
            expect(modifiedChanges.length).toBeGreaterThanOrEqual(1);
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  it("detects system prompt changes", () => {
    fc.assert(
      fc.property(
        agentSnapshotArb,
        fc.string({ minLength: 1, maxLength: 100 }),
        (snapshot, suffix) => {
          const snapshotB: AgentSnapshot = {
            ...snapshot,
            systemPrompt: snapshot.systemPrompt + suffix,
          };

          const result = diffAgentConfigs(snapshot, snapshotB);

          const promptChanges = result.changes.filter(
            (c) => c.changeType === "system-prompt-changed"
          );
          expect(promptChanges.length).toBe(1);
          expect(result.hasChanges).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("detects model ID changes", () => {
    fc.assert(
      fc.property(
        agentSnapshotArb,
        fc.string({ minLength: 1, maxLength: 50 }).filter((s) => s.trim().length > 0),
        (snapshot, newModelId) => {
          // Ensure newModelId is different
          const differentModel =
            newModelId === snapshot.modelId ? newModelId + "_v2" : newModelId;

          const snapshotB: AgentSnapshot = {
            ...snapshot,
            modelId: differentModel,
          };

          const result = diffAgentConfigs(snapshot, snapshotB);

          const modelChanges = result.changes.filter((c) => c.changeType === "model-changed");
          expect(modelChanges.length).toBe(1);
          expect(result.hasChanges).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("hasChanges is true iff changes array is non-empty", () => {
    fc.assert(
      fc.property(agentSnapshotArb, agentSnapshotArb, (snapshotA, snapshotB) => {
        const result = diffAgentConfigs(snapshotA, snapshotB);

        if (result.changes.length > 0) {
          expect(result.hasChanges).toBe(true);
        } else {
          expect(result.hasChanges).toBe(false);
        }
      }),
      { numRuns: 100 }
    );
  });
});
