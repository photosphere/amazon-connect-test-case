// Feature: implement-recommendations, Property 2: Write payload purity
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import {
  buildUpdatedTools,
  buildUpdatedSystemPrompt,
} from "@backend/orchestration/config-writer";
import type {
  Recommendation,
  ToolDefinition,
} from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Non-empty tool name (1–30 chars, printable ASCII). */
const toolNameArb: fc.Arbitrary<string> = fc.string({
  minLength: 1,
  maxLength: 30,
  unit: fc.char().filter((c) => c >= " " && c <= "~"),
});

/** Non-empty text for field values (1–200 chars). */
const nonEmptyTextArb: fc.Arbitrary<string> = fc.string({
  minLength: 1,
  maxLength: 200,
});

/**
 * Generates a ToolDefinition with the given or random fields.
 */
function makeToolDef(
  toolName: string,
  description: string,
  instruction: string,
  examples: string[],
): ToolDefinition {
  return {
    toolName,
    toolType: "CODE_INTERPRETER",
    description,
    instruction,
    inputSchema: {},
    examples,
  };
}

/** Generates a random ToolDefinition with a given name. */
const toolDefArb = (name: string): fc.Arbitrary<ToolDefinition> =>
  fc.record({
    toolName: fc.constant(name),
    toolType: fc.constant("CODE_INTERPRETER"),
    description: nonEmptyTextArb,
    instruction: nonEmptyTextArb,
    inputSchema: fc.constant({}),
    examples: fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 5 }),
  });

// ---------------------------------------------------------------------------
// Property 2: Write payload purity
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 3.2, 18.2**
 *
 * Property 2: Write payload purity
 *
 * For any set of Recommendation objects and any valid agent configuration,
 * the `buildUpdatedTools` function SHALL produce an updated tools array
 * containing exactly the `suggestedText` values from the applied
 * recommendations mapped to their correct tool fields, and no other field
 * modifications. The write operation is a pure function from
 * (currentConfig, recommendations) → updatedConfig — fields not targeted by
 * any recommendation remain byte-for-byte identical to the input config.
 */
describe("Feature: implement-recommendations, Property 2: Write payload purity", () => {
  describe("untargeted fields remain byte-for-byte identical", () => {
    it("tools not referenced by any recommendation are entirely unchanged", () => {
      fc.assert(
        fc.property(
          // Generate 2-4 tools with unique names
          fc
            .uniqueArray(toolNameArb, { minLength: 2, maxLength: 4 })
            .chain((names) =>
              fc.tuple(
                fc.tuple(...names.map((n) => toolDefArb(n))),
                fc.constant(names),
              ),
            ),
          nonEmptyTextArb,
          (toolsAndNames, suggestedText) => {
            const [tools, names] = toolsAndNames;
            const toolsArray = [...tools] as ToolDefinition[];

            // Target only the FIRST tool's description
            const rec: Recommendation = {
              targetField: "tool_description",
              targetName: names[0],
              currentText: toolsArray[0].description,
              suggestedText,
              rationale: "test",
            };

            const result = buildUpdatedTools(toolsArray, [rec]);

            // All tools EXCEPT the first should be entirely unchanged
            for (let i = 1; i < toolsArray.length; i++) {
              expect(result[i].toolName).toBe(toolsArray[i].toolName);
              expect(result[i].toolType).toBe(toolsArray[i].toolType);
              expect(result[i].description).toBe(toolsArray[i].description);
              expect(result[i].instruction).toBe(toolsArray[i].instruction);
              expect(result[i].inputSchema).toEqual(toolsArray[i].inputSchema);
              expect(result[i].examples).toEqual(toolsArray[i].examples);
            }
          },
        ),
        { numRuns: 100 },
      );
    });

    it("non-targeted fields on a targeted tool remain unchanged (description rec doesn't touch instruction/examples)", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 5 }),
          nonEmptyTextArb,
          (toolName, description, instruction, examples, suggestedText) => {
            const tool = makeToolDef(toolName, description, instruction, examples);

            const rec: Recommendation = {
              targetField: "tool_description",
              targetName: toolName,
              currentText: description,
              suggestedText,
              rationale: "test",
            };

            const result = buildUpdatedTools([tool], [rec]);

            // instruction and examples are unchanged
            expect(result[0].instruction).toBe(instruction);
            expect(result[0].examples).toEqual(examples);
            // toolName, toolType, inputSchema unchanged
            expect(result[0].toolName).toBe(toolName);
            expect(result[0].toolType).toBe("CODE_INTERPRETER");
            expect(result[0].inputSchema).toEqual({});
          },
        ),
        { numRuns: 100 },
      );
    });

    it("non-targeted fields on a targeted tool remain unchanged (instruction rec doesn't touch description/examples)", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 5 }),
          nonEmptyTextArb,
          (toolName, description, instruction, examples, suggestedText) => {
            const tool = makeToolDef(toolName, description, instruction, examples);

            const rec: Recommendation = {
              targetField: "tool_instruction",
              targetName: toolName,
              currentText: instruction,
              suggestedText,
              rationale: "test",
            };

            const result = buildUpdatedTools([tool], [rec]);

            // description and examples are unchanged
            expect(result[0].description).toBe(description);
            expect(result[0].examples).toEqual(examples);
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("targeted fields contain exactly the suggestedText", () => {
    it("tool_description: targeted field equals suggestedText", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 5 }),
          (toolName, description, instruction, suggestedText, examples) => {
            const tool = makeToolDef(toolName, description, instruction, examples);

            const rec: Recommendation = {
              targetField: "tool_description",
              targetName: toolName,
              currentText: description,
              suggestedText,
              rationale: "test",
            };

            const result = buildUpdatedTools([tool], [rec]);

            expect(result[0].description).toBe(suggestedText);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("tool_instruction: targeted field equals suggestedText", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 5 }),
          (toolName, description, instruction, suggestedText, examples) => {
            const tool = makeToolDef(toolName, description, instruction, examples);

            const rec: Recommendation = {
              targetField: "tool_instruction",
              targetName: toolName,
              currentText: instruction,
              suggestedText,
              rationale: "test",
            };

            const result = buildUpdatedTools([tool], [rec]);

            expect(result[0].instruction).toBe(suggestedText);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("system_prompt: buildUpdatedSystemPrompt wraps the suggestedText in YAML envelope", () => {
      fc.assert(
        fc.property(
          nonEmptyTextArb,
          nonEmptyTextArb,
          (currentPrompt, suggestedText) => {
            const rec: Recommendation = {
              targetField: "system_prompt",
              targetName: "system_prompt",
              currentText: currentPrompt,
              suggestedText,
              rationale: "test",
            };

            const result = buildUpdatedSystemPrompt(currentPrompt, [rec]);

            // Result starts with YAML system block header
            expect(result.startsWith('system: |')).toBe(true);
            // Result contains the messages section
            expect(result).toContain('messages:');
            expect(result).toContain('{{$.conversationHistory}}');
            // The suggestedText content is present (indented by 2 spaces)
            const firstLine = suggestedText.split('\n')[0];
            expect(result).toContain(`  ${firstLine}`);
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("tool_examples operations: add, remove, replace", () => {
    it("add: new example is appended to the examples array", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 5 }),
          nonEmptyTextArb,
          (toolName, description, instruction, existingExamples, newExample) => {
            const tool = makeToolDef(toolName, description, instruction, existingExamples);

            // add operation: currentText is empty, suggestedText is non-empty
            const rec: Recommendation = {
              targetField: "tool_examples",
              targetName: toolName,
              currentText: "",
              suggestedText: newExample,
              rationale: "test",
            };

            const result = buildUpdatedTools([tool], [rec]);

            // The new example should be appended
            expect(result[0].examples).toHaveLength(existingExamples.length + 1);
            expect(result[0].examples[result[0].examples.length - 1]).toBe(newExample);
            // All existing examples are still there in original order
            for (let i = 0; i < existingExamples.length; i++) {
              expect(result[0].examples[i]).toBe(existingExamples[i]);
            }
          },
        ),
        { numRuns: 100 },
      );
    });

    it("remove: matching example is filtered out from the array", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 4 }),
          (toolName, description, instruction, targetExample, otherExamples) => {
            // Ensure targetExample is unique among examples for clarity
            const cleanOthers = otherExamples.filter((e) => e !== targetExample);
            const allExamples = [targetExample, ...cleanOthers];
            const tool = makeToolDef(toolName, description, instruction, allExamples);

            // remove operation: currentText is non-empty, suggestedText is empty
            const rec: Recommendation = {
              targetField: "tool_examples",
              targetName: toolName,
              currentText: targetExample,
              suggestedText: "",
              rationale: "test",
            };

            const result = buildUpdatedTools([tool], [rec]);

            // The target example should be gone
            expect(result[0].examples).not.toContain(targetExample);
            // Other examples remain
            for (const other of cleanOthers) {
              expect(result[0].examples).toContain(other);
            }
          },
        ),
        { numRuns: 100 },
      );
    });

    it("replace: matching example is swapped with suggestedText", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 4 }),
          (toolName, description, instruction, targetExample, replacement, otherExamples) => {
            fc.pre(targetExample !== replacement);
            // Ensure targetExample is unique among examples for clarity
            const cleanOthers = otherExamples.filter((e) => e !== targetExample);
            const allExamples = [targetExample, ...cleanOthers];
            const tool = makeToolDef(toolName, description, instruction, allExamples);

            // replace operation: both currentText and suggestedText are non-empty
            const rec: Recommendation = {
              targetField: "tool_examples",
              targetName: toolName,
              currentText: targetExample,
              suggestedText: replacement,
              rationale: "test",
            };

            const result = buildUpdatedTools([tool], [rec]);

            // The original example should be replaced
            expect(result[0].examples).not.toContain(targetExample);
            expect(result[0].examples).toContain(replacement);
            // The replacement is at the same index as the original
            expect(result[0].examples[0]).toBe(replacement);
            // Other examples remain unchanged
            for (const other of cleanOthers) {
              expect(result[0].examples).toContain(other);
            }
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("immutability: input arrays are not mutated", () => {
    it("buildUpdatedTools does not mutate the input tools array", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 1, maxLength: 5 }),
          nonEmptyTextArb,
          (toolName, description, instruction, examples, suggestedText) => {
            const tool = makeToolDef(toolName, description, instruction, examples);
            const originalTools = [tool];

            // Deep snapshot before calling the function
            const snapshotDescription = tool.description;
            const snapshotInstruction = tool.instruction;
            const snapshotExamples = [...tool.examples];
            const snapshotToolName = tool.toolName;

            const rec: Recommendation = {
              targetField: "tool_description",
              targetName: toolName,
              currentText: description,
              suggestedText,
              rationale: "test",
            };

            buildUpdatedTools(originalTools, [rec]);

            // Original tool should be unchanged
            expect(originalTools[0].description).toBe(snapshotDescription);
            expect(originalTools[0].instruction).toBe(snapshotInstruction);
            expect(originalTools[0].examples).toEqual(snapshotExamples);
            expect(originalTools[0].toolName).toBe(snapshotToolName);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("buildUpdatedTools does not mutate the input examples array on add operation", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 1, maxLength: 5 }),
          nonEmptyTextArb,
          (toolName, description, instruction, examples, newExample) => {
            const tool = makeToolDef(toolName, description, instruction, examples);
            const originalExamplesLength = tool.examples.length;
            const originalExamplesCopy = [...tool.examples];

            const rec: Recommendation = {
              targetField: "tool_examples",
              targetName: toolName,
              currentText: "",
              suggestedText: newExample,
              rationale: "test",
            };

            buildUpdatedTools([tool], [rec]);

            // Original examples array should be unchanged
            expect(tool.examples).toHaveLength(originalExamplesLength);
            expect(tool.examples).toEqual(originalExamplesCopy);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("buildUpdatedTools does not mutate the input examples array on remove operation", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 4 }),
          (toolName, description, instruction, targetExample, otherExamples) => {
            const allExamples = [targetExample, ...otherExamples];
            const tool = makeToolDef(toolName, description, instruction, allExamples);
            const originalExamplesCopy = [...tool.examples];

            const rec: Recommendation = {
              targetField: "tool_examples",
              targetName: toolName,
              currentText: targetExample,
              suggestedText: "",
              rationale: "test",
            };

            buildUpdatedTools([tool], [rec]);

            // Original examples array should be unchanged
            expect(tool.examples).toEqual(originalExamplesCopy);
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("system_prompt: no-op when no system_prompt recommendations", () => {
    it("buildUpdatedSystemPrompt returns the original prompt when no system_prompt recs exist", () => {
      fc.assert(
        fc.property(
          nonEmptyTextArb,
          toolNameArb,
          nonEmptyTextArb,
          (currentPrompt, toolName, suggestedText) => {
            // Only tool-surface recs, no system_prompt recs
            const toolRec: Recommendation = {
              targetField: "tool_description",
              targetName: toolName,
              currentText: "whatever",
              suggestedText,
              rationale: "test",
            };

            const result = buildUpdatedSystemPrompt(currentPrompt, [toolRec]);

            expect(result).toBe(currentPrompt);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("buildUpdatedSystemPrompt ignores tool-surface recs and only applies system_prompt recs", () => {
      fc.assert(
        fc.property(
          nonEmptyTextArb,
          nonEmptyTextArb,
          toolNameArb,
          nonEmptyTextArb,
          (currentPrompt, promptSuggested, toolName, toolSuggested) => {
            const recs: Recommendation[] = [
              {
                targetField: "tool_description",
                targetName: toolName,
                currentText: "some text",
                suggestedText: toolSuggested,
                rationale: "test",
              },
              {
                targetField: "system_prompt",
                targetName: "system_prompt",
                currentText: currentPrompt,
                suggestedText: promptSuggested,
                rationale: "test",
              },
            ];

            const result = buildUpdatedSystemPrompt(currentPrompt, recs);

            // Should contain the system_prompt recommendation's suggestedText
            // wrapped in the Q in Connect YAML envelope
            expect(result).toContain(promptSuggested.split('\n')[0]);
            expect(result.startsWith('system: |')).toBe(true);
            expect(result).toContain('messages:');
            expect(result).toContain('{{$.conversationHistory}}');
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("buildUpdatedTools filters out system_prompt recommendations", () => {
    it("system_prompt recommendations do not affect the tools array", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 5 }),
          nonEmptyTextArb,
          nonEmptyTextArb,
          (toolName, description, instruction, examples, promptCurrent, promptSuggested) => {
            const tool = makeToolDef(toolName, description, instruction, examples);

            // Only system_prompt rec — should not affect tools
            const rec: Recommendation = {
              targetField: "system_prompt",
              targetName: "system_prompt",
              currentText: promptCurrent,
              suggestedText: promptSuggested,
              rationale: "test",
            };

            const result = buildUpdatedTools([tool], [rec]);

            // Tool should be entirely unchanged
            expect(result[0].description).toBe(description);
            expect(result[0].instruction).toBe(instruction);
            expect(result[0].examples).toEqual(examples);
            expect(result[0].toolName).toBe(toolName);
          },
        ),
        { numRuns: 100 },
      );
    });
  });
});
