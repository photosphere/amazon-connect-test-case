/**
 * Experiment Apply Lambda — POST /runs/{runId}/experiments/{experimentId}/apply
 *
 * Applies a selected variant's configuration changes to the live agent via
 * Q in Connect management APIs. Implements the "Apply Winning Variant" flow
 * from the Multi-Variant Experiment feature.
 *
 * Flow:
 * 1. Validate INSTANCE_MODE !== "production" → 403
 * 2. Load experiment record from DynamoDB
 * 3. Extract variant config for the specified variant letter
 * 4. Validate agentId belongs to the configured assistant
 * 5. Call GetAIAgent to fetch the live agent config
 * 6. Run drift detection → 409 on conflict
 * 7. Call config writer to apply changes
 * 8. Persist audit record
 * 9. Update experiment record with appliedVariant and appliedAt
 * 10. Return success with new version ID
 *
 * Environment variables:
 * - TABLE_NAME: DynamoDB table name
 * - INSTANCE_MODE: "production" or "development"
 * - ASSISTANT_ID: The Q in Connect assistant identifier
 *
 * @module experiment-apply
 */

import {
  QConnectClient,
  GetAIAgentCommand,
  GetAIPromptCommand,
} from "@aws-sdk/client-qconnect";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import type {
  AgentDetail,
  AuditRecord,
  ExperimentRecord,
  ToolDefinition,
  VariantConfig,
} from "../../shared/types";
import { checkDrift } from "../orchestration/drift-detection";
import { writeConfig } from "../orchestration/config-writer";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

function getTableName(): string {
  return process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
}

function getInstanceMode(): string {
  return process.env.INSTANCE_MODE ?? "development";
}

function getAssistantId(): string {
  return process.env.ASSISTANT_ID ?? "";
}

function getRegion(): string {
  return process.env.AWS_REGION ?? "us-east-1";
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

let qconnectClient: QConnectClient | null = null;
let ddbDocClient: DynamoDBDocumentClient | null = null;

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: getRegion() });
  }
  return qconnectClient;
}

function getDDBDocClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

/** @internal — allows test injection */
export function _setDDBDocClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  body?: string | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, string>;
    };
  };
}

export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

export interface ExperimentApplyRequest {
  variant: "A" | "B" | "C";
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(statusCode: number, body: unknown): APIGatewayResponse {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

function extractTenantId(event: APIGatewayEvent): string | null {
  const claims = event.requestContext?.authorizer?.claims;
  return claims?.sub ?? claims?.client_id ?? null;
}

function nowISO(): string {
  return new Date().toISOString();
}

const VALID_VARIANTS = new Set(["A", "B", "C"]);

// ---------------------------------------------------------------------------
// DynamoDB Accessors
// ---------------------------------------------------------------------------

/**
 * Strips DynamoDB key attributes (PK, SK, GSI*) from an item.
 */
function stripKeys<T>(item: Record<string, unknown>): T {
  const copy = { ...item };
  delete copy.PK;
  delete copy.SK;
  delete copy.GSI1PK;
  delete copy.GSI1SK;
  delete copy.GSI2PK;
  delete copy.GSI2SK;
  return copy as unknown as T;
}

/**
 * Load experiment record from DynamoDB.
 */
async function loadExperiment(
  runId: string,
  experimentId: string
): Promise<ExperimentRecord | null> {
  const client = getDDBDocClient();
  const result = await client.send(
    new GetCommand({
      TableName: getTableName(),
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `${SK_PATTERNS.EXPERIMENT}${experimentId}`,
      },
    })
  );
  if (!result.Item) return null;
  return stripKeys<ExperimentRecord>(result.Item as Record<string, unknown>);
}

/**
 * Fetch the live agent configuration as AgentDetail by calling GetAIAgent.
 * Also validates that the agent belongs to the configured assistant.
 */
async function fetchLiveAgentConfig(agentId: string): Promise<AgentDetail | null> {
  const client = getQConnectClient();
  const assistantId = getAssistantId();

  const response = await client.send(
    new GetAIAgentCommand({
      assistantId,
      aiAgentId: agentId,
    })
  );

  const agent = response.aiAgent;
  if (!agent) return null;

  const orchestrationConfig = (agent.configuration as any)
    ?.orchestrationAIAgentConfiguration;

  const tools: ToolDefinition[] = (
    orchestrationConfig?.toolConfigurations ?? []
  ).map((tool: any) => ({
    toolName: tool.toolName ?? "",
    toolType: tool.toolType ?? "",
    description: tool.description ?? "",
    ...(tool.instruction?.instruction && {
      instruction: tool.instruction.instruction,
    }),
    inputSchema: tool.inputSchema ?? {},
    examples: Array.isArray(tool.examples) ? [...tool.examples] : [],
  }));

  // Resolve system prompt from the orchestration prompt
  const promptId = orchestrationConfig?.orchestrationAIPromptId ?? "";
  let systemPrompt = "";
  let modelId = promptId || "unknown";

  if (promptId) {
    try {
      const promptResp = await client.send(
        new GetAIPromptCommand({
          assistantId,
          aiPromptId: promptId,
        })
      );
      const promptData = promptResp.aiPrompt;
      const tc = promptData?.templateConfiguration as
        | { textFullAIPromptEditTemplateConfiguration?: { text?: string } }
        | undefined;
      systemPrompt = tc?.textFullAIPromptEditTemplateConfiguration?.text ?? "";
      if (promptData?.modelId) modelId = promptData.modelId;
    } catch (error) {
      console.warn(
        `[experiment-apply] GetAIPrompt(${promptId}) failed: ${
          error instanceof Error ? error.message : String(error)
        }`
      );
    }
  }

  return {
    agentId: agent.aiAgentId!,
    name: agent.name!,
    type: "ORCHESTRATION",
    systemPrompt,
    modelId,
    tools,
  };
}

/**
 * Persist audit record at PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}.
 */
async function persistAuditRecord(record: AuditRecord): Promise<void> {
  const client = getDDBDocClient();
  await client.send(
    new PutCommand({
      TableName: getTableName(),
      Item: {
        PK: `${PK_PATTERNS.TENANT}${record.tenantId}`,
        SK: `${SK_PATTERNS.AUDIT}${record.timestamp}`,
        ...record,
      },
    })
  );
}

/**
 * Update experiment record with appliedVariant and appliedAt.
 */
async function updateExperimentApplied(
  runId: string,
  experimentId: string,
  variant: "A" | "B" | "C",
  appliedAt: string
): Promise<void> {
  const client = getDDBDocClient();
  await client.send(
    new UpdateCommand({
      TableName: getTableName(),
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `${SK_PATTERNS.EXPERIMENT}${experimentId}`,
      },
      UpdateExpression: "SET appliedVariant = :variant, appliedAt = :appliedAt",
      ExpressionAttributeValues: {
        ":variant": variant,
        ":appliedAt": appliedAt,
      },
    })
  );
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

/**
 * Lambda handler for POST /runs/{runId}/experiments/{experimentId}/apply.
 */
export async function handler(
  event: APIGatewayEvent
): Promise<APIGatewayResponse> {
  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  // --- Step 1: Validate INSTANCE_MODE ---
  if (getInstanceMode() === "production") {
    return jsonResponse(403, {
      error: "write_disabled",
      reason: "Agent writes and experiments are disabled in production mode",
    });
  }

  // Extract tenant ID from Cognito authorizer claims
  const tenantId = extractTenantId(event);
  if (!tenantId) {
    return jsonResponse(401, { error: "Unauthorized: missing tenant identity" });
  }

  // Extract path parameters
  const runId = event.pathParameters?.runId;
  const experimentId = event.pathParameters?.experimentId;

  if (!runId) {
    return jsonResponse(400, { error: "runId is required" });
  }
  if (!experimentId) {
    return jsonResponse(400, { error: "experimentId is required" });
  }

  // Parse request body
  if (!event.body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let request: ExperimentApplyRequest;
  try {
    request = JSON.parse(event.body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  // Validate variant field
  if (!request.variant || !VALID_VARIANTS.has(request.variant)) {
    return jsonResponse(400, {
      error: "variant must be one of: \"A\", \"B\", \"C\"",
    });
  }

  try {
    // --- Step 2: Load experiment record ---
    const experiment = await loadExperiment(runId, experimentId);
    if (!experiment) {
      return jsonResponse(404, { error: "experiment_not_found" });
    }

    // --- Step 3: Extract variant config for the requested variant letter ---
    const variantConfig: VariantConfig | undefined =
      experiment.variantConfigs.find(
        (vc) => vc.variantLetter === request.variant
      );

    if (!variantConfig) {
      return jsonResponse(404, {
        error: "variant_not_found",
        reason: `Variant ${request.variant} not found in experiment ${experimentId}`,
      });
    }

    // --- Step 4: Validate agentId belongs to configured assistant ---
    let liveAgentConfig: AgentDetail | null;
    try {
      liveAgentConfig = await fetchLiveAgentConfig(experiment.agentId);
    } catch (error: unknown) {
      const errorName = (error as { name?: string })?.name ?? "";
      if (
        errorName === "ResourceNotFoundException" ||
        errorName === "ValidationException"
      ) {
        return jsonResponse(400, {
          error: "agent_not_found",
          reason: `Agent ${experiment.agentId} not found on assistant ${getAssistantId()}`,
        });
      }
      throw error;
    }

    if (!liveAgentConfig) {
      return jsonResponse(400, {
        error: "agent_not_found",
        reason: `Agent ${experiment.agentId} not found or is not an orchestration agent`,
      });
    }

    // --- Step 5: Run drift detection ---
    const driftResult = checkDrift({
      recommendations: variantConfig.recommendations,
      liveAgentConfig,
    });

    // --- Step 6: Return 409 on drift ---
    if (driftResult.hasDrift) {
      return jsonResponse(409, {
        success: false,
        error: "drift_detected",
        driftedFields: driftResult.driftedFields,
      });
    }

    // --- Step 7: Call config writer ---
    const writeResult = await writeConfig({
      agentId: experiment.agentId,
      assistantId: getAssistantId(),
      recommendations: variantConfig.recommendations,
      currentConfig: liveAgentConfig,
    });

    if (!writeResult.success) {
      return jsonResponse(500, {
        success: false,
        error: writeResult.error ?? "Write operation failed",
      });
    }

    // Determine the version ID to report
    const newVersionId =
      writeResult.newAgentVersionId ??
      writeResult.newPromptVersionId ??
      "unknown";

    // --- Step 8: Persist audit record ---
    const timestamp = nowISO();
    const auditRecord: AuditRecord = {
      tenantId,
      timestamp,
      runId,
      agentId: experiment.agentId,
      source: "experiment_apply",
      experimentId,
      appliedVariant: request.variant,
      previousVersionId: liveAgentConfig.agentId,
      newVersionId,
      recommendations: variantConfig.recommendations,
      driftDetected: false,
      userDecision: "normal",
    };
    await persistAuditRecord(auditRecord);

    // --- Step 9: Update experiment record ---
    await updateExperimentApplied(
      runId,
      experimentId,
      request.variant,
      timestamp
    );

    // --- Step 10: Return success ---
    return jsonResponse(200, {
      success: true,
      newVersionId,
    });
  } catch (error: unknown) {
    console.error(
      "[experiment-apply] Handler error:",
      error instanceof Error ? error.message : error
    );

    const errorName = (error as { name?: string })?.name ?? "";

    if (errorName === "ThrottlingException") {
      return jsonResponse(429, {
        error: "ThrottlingException",
        message: "Request rate exceeded. Please retry after a brief delay.",
        retryable: true,
        retryAfterSeconds: 5,
      });
    }

    return jsonResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
}
