# Span Fixtures (`Span_Fixture`)

Checked-in `Span_Fixture` files captured from real completed test sessions, used
to validate the trace-to-OTel translation and downstream score processing
against genuine ListSpans-shaped data (Requirement 16).

Each fixture conforms to the `SpanFixture` shape defined in
`design.md` (§ Data Models / `Span_Fixture`):

```ts
interface SpanFixture {
  name: string;                       // e.g. "multi-tool-success"
  description: string;
  sessionId: string;
  rawSpans: RawSpan[];                // ListSpans-shaped input to parseSpansToTrace
  expectedToolSequence: string[];     // ground-truth assertion aid (Req 16.3)
  availableTools: ToolDefinition[];   // agent snapshot at capture time (Req 9.3)
  expectedToolNames: string[];        // success-criteria trajectory (Req 9.4)
}
```

## Redaction

Per Requirement 16.5, every fixture committed to this directory uses
**non-production placeholder values** for sensitive customer data. The
redaction conventions below are enforced by `tests/unit/fixtures-redaction.test.ts`:

| Field             | Placeholder                          | Notes                                                              |
| ----------------- | ------------------------------------ | ------------------------------------------------------------------ |
| Phone (E.164)     | `+15555550100` … `+15555550199`      | NANP `555-01XX` block is reserved for fictitious use.              |
| SSN last-four     | `0000`                               | Fixed placeholder. `XXXX` may be substituted in free-text.         |
| Customer name     | `Alice Example`, `Pat Sample`        | Generic, non-real names.                                           |
| Account / loan id | `ACCT-EXAMPLE-0001`, `LOAN-DEMO-…`   | Synthetic ids only.                                                |

When adding a new fixture, replace any captured PII with a value from the table
above (or an analogous synthetic placeholder) **before** committing the file.

## Files

- `multi-tool-success.json` — Customer asks about an auto-loan balance; agent
  verifies identity and fetches loan details and answers in two assistant turns
  with two successful tool calls (`verifyIdentity`, `getLoanDetails`).
- `failure-escalation.json` — Customer disputes a charge; agent verifies
  identity, the dispute lookup tool errors, and the agent escalates to a human
  (`verifyIdentity` → `lookupBillingDispute` (error) → `escalateToHuman`).
