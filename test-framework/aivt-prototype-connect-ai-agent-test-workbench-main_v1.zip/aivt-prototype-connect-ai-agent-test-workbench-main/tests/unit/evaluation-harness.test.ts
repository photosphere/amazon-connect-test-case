/**
 * Unit tests for the local Evaluation Harness — Task 6.2.
 *
 * Validates: Requirements 9.4, 9.5, 9.6, 9.7, 9.8, 9.9, 10.4, 10.5
 *
 * Coverage:
 *   1. Argument resolver — file path on disk vs UUID-shaped session id
 *      (Req 9.5).
 *   2. No-arg invocation prints usage and exits non-zero with no AWS
 *      call (Req 9.6).
 *   3. Missing / unparseable / wrong-shape transcript file → exit 1
 *      with no judge call (Req 9.7).
 *   4. Empty `qconnect:ListSpans` response → exit 1 with no judge call
 *      (Req 9.8).
 *   5. Missing AWS credentials → exit 1 with no AWS call attempted
 *      (Req 10.4).
 *   6. `bedrock:Converse` access-denied → reports the operation and
 *      exits 1 with no local-scoring fallback (Reqs 9.9, 10.5).
 *   7. `qconnect:ListSpans` access-denied → reports the operation and
 *      exits 1 with no local-scoring fallback (Reqs 9.8, 10.5).
 *   8. Judge timeout / parse error → reports the operation and exits 1
 *      with no fallback (Reqs 9.9, 10.5).
 *   9. Static check — the harness imports the same `evaluateCaseSession`,
 *      `judge-prompt-rendering`, `bedrock-judge-client`, and
 *      `evaluation-scoring` modules as the deployed Evaluation Lambda
 *      (Req 9.4).
 *
 * The harness is exercised via its single public export `runHarness(argv)`,
 * with the Bedrock judge client (`_setBedrockClient`), the Q in Connect
 * `ListSpansCommand` SDK call (`vi.mock`), the credential provider chain
 * (`vi.mock`), and the filesystem (real OS temp dir) mocked. No real AWS
 * calls are made.
 */

import {
  afterEach,
  beforeAll,
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from "vitest";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

// ---------------------------------------------------------------------------
// Module-level mocks for the AWS SDK pieces the harness uses on its normal
// paths. Both must be declared BEFORE the harness import so the mocks are
// hoisted into place before the harness's top-level `import {…}` statements
// execute.
// ---------------------------------------------------------------------------

/**
 * Spy on the `defaultProvider` from `@aws-sdk/credential-provider-node`. The
 * harness calls this in its credential pre-flight; the mock lets us swap
 * "credentials available" / "credentials missing" between tests. Default
 * behaviour (a single static access key) keeps the credential check happy
 * for tests that don't care about it.
 */
const credentialProviderImpl = vi.fn(async () => ({
  accessKeyId: "AKIATEST",
  secretAccessKey: "secret",
}));
vi.mock("@aws-sdk/credential-provider-node", () => ({
  defaultProvider: () => credentialProviderImpl,
}));

/**
 * Spy on `QConnectClient.send`. The harness constructs the client inside
 * `loadFromSession`, so swapping the prototype's `send` method intercepts
 * every call without requiring a `_setQConnectClient` seam in the harness
 * itself.
 *
 * `ListSpansCommand` is preserved so the harness's `new ListSpansCommand({
 * … })` call works; the mock simply records the command instance and
 * returns whatever the test set up via `qConnectSendImpl`.
 */
const qConnectSendImpl = vi.fn(
  async (_cmd: unknown): Promise<{ spans?: unknown[]; nextToken?: string }> => {
    return { spans: [] };
  },
);
vi.mock("@aws-sdk/client-qconnect", async () => {
  const actual =
    await vi.importActual<typeof import("@aws-sdk/client-qconnect")>(
      "@aws-sdk/client-qconnect",
    );
  class StubQConnectClient {
    send(cmd: unknown): Promise<unknown> {
      return qConnectSendImpl(cmd);
    }
  }
  return {
    ...actual,
    QConnectClient: StubQConnectClient,
  };
});

// ---------------------------------------------------------------------------
// Imports — pulled in AFTER the mocks above are declared.
// ---------------------------------------------------------------------------

import { ConverseCommand } from "@aws-sdk/client-bedrock-runtime";
import { runHarness } from "../../scripts/evaluation-harness";
import {
  _setBedrockClient,
  _resetBedrockClient,
} from "../../src/backend/orchestration/bedrock-judge-client";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import { SUPPORTED_MODELS } from "../../src/backend/orchestration/prompt-registry";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";

// ---------------------------------------------------------------------------
// Helpers for capturing stderr / stdout the harness writes.
// ---------------------------------------------------------------------------

interface CapturedStreams {
  stdout: string;
  stderr: string;
}

/**
 * Captures everything the harness writes via `console.log` (stdout) and
 * `process.stderr.write` (stderr) for the duration of `fn`. Each spy is
 * restored before the function returns so a failed assertion does not
 * leave the process streams in a mocked state.
 */
async function captureStreams(
  fn: () => Promise<number>,
): Promise<{ exitCode: number; streams: CapturedStreams }> {
  const stdoutChunks: string[] = [];
  const stderrChunks: string[] = [];
  const logSpy = vi
    .spyOn(console, "log")
    .mockImplementation((...args: unknown[]) => {
      stdoutChunks.push(args.map((a) => String(a)).join(" "));
    });
  const stderrSpy = vi
    .spyOn(process.stderr, "write")
    .mockImplementation((chunk: string | Uint8Array): boolean => {
      stderrChunks.push(
        typeof chunk === "string" ? chunk : Buffer.from(chunk).toString(),
      );
      return true;
    });
  try {
    const exitCode = await fn();
    return {
      exitCode,
      streams: {
        stdout: stdoutChunks.join("\n"),
        stderr: stderrChunks.join(""),
      },
    };
  } finally {
    logSpy.mockRestore();
    stderrSpy.mockRestore();
  }
}

// ---------------------------------------------------------------------------
// Bedrock judge mock helpers — emulate one Converse call returning a fenced
// JSON block, or rejecting with a typed AWS error / timeout.
// ---------------------------------------------------------------------------

/**
 * Builds a Converse response carrying `text` as the model's single text
 * content block. Mirrors the shape `bedrock-judge-client.parseJudgeResponse`
 * flattens.
 */
function makeConverseResponse(text: string): unknown {
  return { output: { message: { content: [{ text }] }, stopReason: "end_turn" } };
}

/**
 * Bedrock client whose `send` returns a fenced-JSON envelope shaped to
 * match whichever AWS-published evaluator template the prompt belongs to.
 * Heuristic: the three built-in templates contain unique sentences in
 * their preamble; matching those keeps the mock readable and resilient to
 * placeholder substitution.
 */
function bedrockClientReturning(
  reasoning = "test reasoning",
): { send: ReturnType<typeof vi.fn> } {
  const send = vi.fn().mockImplementation((command: unknown) => {
    const cmd = command as {
      input?: { messages?: Array<{ content?: Array<{ text?: string }> }> };
    };
    const text =
      cmd.input?.messages?.[0]?.content?.map((b) => b.text ?? "").join("") ??
      "";
    let score: string;
    if (text.includes("evaluating the helpfulness")) {
      // Helpfulness rubric: 7 ordinal labels.
      score = "Very Helpful";
    } else {
      // GoalSuccessRate and ToolSelectionAccuracy both use Yes/No.
      score = "Yes";
    }
    return Promise.resolve(
      makeConverseResponse(
        "```json\n" + JSON.stringify({ reasoning, score }) + "\n```",
      ),
    );
  });
  return { send };
}

// ---------------------------------------------------------------------------
// Fixtures — minimal Span_Fixture and trace/transcript file payloads
// reused across tests. Shapes match `loadFromFile` in the harness.
// ---------------------------------------------------------------------------

const VALID_SPAN_FIXTURE = JSON.stringify({
  sessionId: "session-fixture-1",
  rawSpans: [
    {
      spanName: "inference",
      startTimestamp: "2024-01-01T00:00:00.500Z",
      attributes: {
        aiAgentName: "TestAgent",
        aiAgentType: "ORCHESTRATION",
        outputMessages: [
          { values: [{ text: { value: "I can help with that." } }] },
        ],
      },
    },
    {
      spanName: "execute_tool",
      startTimestamp: "2024-01-01T00:00:00.700Z",
      attributes: {
        inputMessages: [
          {
            values: [
              {
                toolUse: {
                  name: "LookupOrder",
                  arguments: '{"orderId":"42"}',
                },
              },
            ],
          },
        ],
        outputMessages: [
          {
            values: [
              {
                toolResult: {
                  values: [
                    {
                      text: {
                        value: '{"status":"success","total":99.99}',
                      },
                    },
                  ],
                },
              },
            ],
          },
        ],
      },
    },
  ],
  expectedToolNames: ["LookupOrder"],
  availableTools: [
    {
      toolName: "LookupOrder",
      toolType: "LAMBDA",
      description: "Look up an order by id.",
      inputSchema: { type: "object" },
    },
  ],
  transcript: [
    {
      turnNumber: 1,
      role: "customer",
      text: "Look up order 42.",
      timestamp: "2024-01-01T00:00:00.000Z",
      elapsedMs: 0,
    },
  ],
});

// ---------------------------------------------------------------------------
// Tempfile management — each test that needs a file on disk gets its own
// path under a per-suite temp directory; everything is cleaned up after.
// ---------------------------------------------------------------------------

let tmpDir: string;

beforeAll(() => {
  tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "evaluation-harness-"));
});

afterEach(() => {
  // Reset every spy / module singleton between tests.
  _resetBedrockClient();
  _setPromptRegistryStore(null);
  _clearPromptRegistryCaches();
  qConnectSendImpl.mockReset();
  qConnectSendImpl.mockImplementation(async () => ({ spans: [] }));
  credentialProviderImpl.mockReset();
  credentialProviderImpl.mockImplementation(async () => ({
    accessKeyId: "AKIATEST",
    secretAccessKey: "secret",
  }));
});

beforeEach(() => {
  // Wave 3 (Task 20.3) retired the legacy `JUDGE_MODEL_ID` env var:
  // the judge client now resolves its model id and inference parameters
  // through `resolvePromptForRun(...)` against the Prompts_Store stubbed
  // below. Pin AWS_REGION so QConnectClient construction is happy in
  // the tests that exercise session mode.
  process.env.AWS_REGION = process.env.AWS_REGION ?? "us-east-1";

  // Wave-2 migration (Task 17.6): the judge client now resolves its
  // prompt via `resolvePromptForRun(...)` against the Prompts_Store.
  // Inject an in-memory stub so the resolver returns the registry's
  // bundled defaults without hitting DynamoDB. Same pattern as
  // `tests/unit/customer-simulator.test.ts`.
  _clearPromptRegistryCaches();
  const promptStore = {
    getSnapshot: vi.fn().mockResolvedValue(null),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  } as unknown as DynamoDBService;
  _setPromptRegistryStore(promptStore);
});

/** Writes `contents` under a unique filename in the suite's temp dir. */
function writeTempFile(name: string, contents: string): string {
  const p = path.join(tmpDir, name);
  fs.writeFileSync(p, contents, "utf8");
  return p;
}

/** A non-existent path inside the suite's temp dir (parent exists). */
function nonExistentPath(name: string): string {
  return path.join(tmpDir, name);
}

// ---------------------------------------------------------------------------
// 1. Argument resolver — file vs session id discrimination (Req 9.5)
// ---------------------------------------------------------------------------

describe("runHarness — argument resolver discriminates file vs session id (Req 9.5)", () => {
  it("treats a path that exists on disk as file mode", async () => {
    const filePath = writeTempFile(
      "valid-fixture.json",
      VALID_SPAN_FIXTURE,
    );
    _setBedrockClient(
      bedrockClientReturning("all goals achieved") as unknown as Parameters<
        typeof _setBedrockClient
      >[0],
    );

    const { exitCode } = await captureStreams(() => runHarness([filePath]));

    // File-mode resolution succeeded — we got past the load step into
    // the judge fan-out (which the mocked client services). The
    // QConnect SDK was NEVER called: file mode does not need ListSpans.
    expect(exitCode).toBe(0);
    expect(qConnectSendImpl).not.toHaveBeenCalled();
  });

  it("treats a UUID-shaped argument that is not on disk as session mode", async () => {
    const sessionId = "12345678-1234-1234-1234-1234567890ab";
    // ListSpans returns no spans → harness exits non-zero with the
    // ListSpans operation tag (covered in detail by tests below).
    qConnectSendImpl.mockImplementation(async () => ({ spans: [] }));

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([sessionId, "--assistant-id", "assist-stub"]),
    );

    // Routed through session mode: ListSpans was attempted exactly once.
    expect(qConnectSendImpl).toHaveBeenCalledTimes(1);
    expect(exitCode).not.toBe(0);
    // The error tag identifies the upstream operation so an operator
    // can grep it out of stderr.
    expect(streams.stderr).toContain("[qconnect:ListSpans]");
  });

  it("prefers file mode when a UUID-named argument resolves to a real file", async () => {
    const sessionLikeName = "12345678-1234-1234-1234-1234567890ab";
    const filePath = writeTempFile(sessionLikeName, VALID_SPAN_FIXTURE);
    _setBedrockClient(
      bedrockClientReturning("all goals achieved") as unknown as Parameters<
        typeof _setBedrockClient
      >[0],
    );

    const { exitCode } = await captureStreams(() => runHarness([filePath]));

    // File-mode wins: the file was loaded and ListSpans was never called.
    expect(exitCode).toBe(0);
    expect(qConnectSendImpl).not.toHaveBeenCalled();
  });

  it("rejects a non-existent, non-UUID argument as an [argument] error and never calls AWS", async () => {
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([nonExistentPath("does-not-exist-and-not-a-uuid")]),
    );

    expect(exitCode).toBe(2);
    expect(streams.stderr).toContain("[argument]");
    // No AWS calls of any kind — the credential check has not even run
    // yet at this point.
    expect(bedrock.send).not.toHaveBeenCalled();
    expect(qConnectSendImpl).not.toHaveBeenCalled();
    expect(credentialProviderImpl).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// 2. No-arg invocation (Req 9.6)
// ---------------------------------------------------------------------------

describe("runHarness — no-arg → usage + exit non-zero (Req 9.6)", () => {
  it("prints the usage banner to stderr and returns a non-zero exit code", async () => {
    const { exitCode, streams } = await captureStreams(() => runHarness([]));

    expect(exitCode).not.toBe(0);
    // Usage banner sent to stderr (per harness contract for argument
    // failures). The first line is the `[argument]` tag.
    expect(streams.stderr).toContain("[argument]");
    expect(streams.stderr).toMatch(/Usage:/i);
    // Zero AWS calls (Req 9.6 — the harness rejects the missing arg
    // before any credential or network operation).
    expect(qConnectSendImpl).not.toHaveBeenCalled();
    expect(credentialProviderImpl).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// 3. Missing / garbage / wrong-shape file (Req 9.7)
// ---------------------------------------------------------------------------

describe("runHarness — missing or unparseable transcript file (Req 9.7)", () => {
  it("exits non-zero on a non-existent file path with no judge call", async () => {
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    // A non-UUID, non-existent path resolves to `[argument]` (the
    // harness can't disambiguate "file the user typo'd" from "session
    // id they typo'd") — but either way no judge call occurs.
    const { exitCode, streams } = await captureStreams(() =>
      runHarness([nonExistentPath("never-existed.json")]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toMatch(/\[argument\]/);
    expect(bedrock.send).not.toHaveBeenCalled();
  });

  it("exits non-zero with [load-file] when the file is not valid JSON", async () => {
    const filePath = writeTempFile("garbage.json", "this-is-not-json{");
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([filePath]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[load-file]");
    // No submission to the Bedrock judge — Req 9.7's "without invoking
    // the Bedrock_Judge_Client".
    expect(bedrock.send).not.toHaveBeenCalled();
  });

  it("exits non-zero with [load-file] when the file is JSON but the wrong shape", async () => {
    const filePath = writeTempFile(
      "wrong-shape.json",
      JSON.stringify({ unrelated: "thing" }),
    );
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([filePath]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[load-file]");
    expect(bedrock.send).not.toHaveBeenCalled();
  });

  it("exits non-zero with [load-file] when a Span_Fixture has zero parsable steps", async () => {
    // rawSpans present but neither inference nor execute_tool, so
    // parseSpansToTrace yields an empty trace.
    const emptyFixture = JSON.stringify({
      sessionId: "empty-session",
      rawSpans: [
        {
          spanName: "irrelevant_span",
          startTimestamp: "2024-01-01T00:00:00Z",
          attributes: {},
        },
      ],
    });
    const filePath = writeTempFile("empty-span-fixture.json", emptyFixture);
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([filePath]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[load-file]");
    expect(bedrock.send).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// 4. Empty ListSpans response (Req 9.8)
// ---------------------------------------------------------------------------

describe("runHarness — empty ListSpans (Req 9.8)", () => {
  it("exits non-zero, names ListSpans, and never submits to the judge when no spans return", async () => {
    qConnectSendImpl.mockImplementation(async () => ({ spans: [] }));
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const sessionId = "12345678-1234-1234-1234-1234567890ab";
    const { exitCode, streams } = await captureStreams(() =>
      runHarness([sessionId, "--assistant-id", "assist-stub"]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[qconnect:ListSpans]");
    expect(streams.stderr).toMatch(/no spans/i);
    // No Bedrock judge call: Req 9.8 — "exit with a non-zero status
    // without invoking the Bedrock_Judge_Client".
    expect(bedrock.send).not.toHaveBeenCalled();
    // ListSpans was the only AWS call attempted (Req 10.1 — the only
    // AWS operation on the harness's normal path besides Converse).
    expect(qConnectSendImpl).toHaveBeenCalledTimes(1);
  });

  it("exits non-zero with [qconnect:ListSpans] when spans return but parse to zero steps", async () => {
    // Spans of an unrecognized type → parseSpansToTrace yields an empty
    // trace, which the harness reports under the ListSpans op tag.
    qConnectSendImpl.mockImplementation(async () => ({
      spans: [
        {
          spanName: "irrelevant_span",
          startTimestamp: "2024-01-01T00:00:00Z",
          attributes: {},
        },
      ],
    }));
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const sessionId = "12345678-1234-1234-1234-1234567890ab";
    const { exitCode, streams } = await captureStreams(() =>
      runHarness([sessionId, "--assistant-id", "assist-stub"]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[qconnect:ListSpans]");
    expect(bedrock.send).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// 5. Missing AWS credentials (Req 10.4)
// ---------------------------------------------------------------------------

describe("runHarness — missing credentials (Req 10.4)", () => {
  it("exits non-zero with [credentials] tag in session mode and never makes any AWS call", async () => {
    credentialProviderImpl.mockImplementation(async () => {
      throw new Error("Could not load credentials from any providers");
    });
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const sessionId = "12345678-1234-1234-1234-1234567890ab";
    const { exitCode, streams } = await captureStreams(() =>
      runHarness([sessionId, "--assistant-id", "assist-stub"]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[credentials]");
    // The credential check was consulted exactly once...
    expect(credentialProviderImpl).toHaveBeenCalledTimes(1);
    // ...and zero AWS operations were attempted (Req 10.4 — "without
    // invoking any AWS operation").
    expect(qConnectSendImpl).not.toHaveBeenCalled();
    expect(bedrock.send).not.toHaveBeenCalled();
  });

  it("also short-circuits in file mode — no judge call when credentials are missing", async () => {
    credentialProviderImpl.mockImplementation(async () => {
      throw new Error("Could not load credentials from any providers");
    });
    const filePath = writeTempFile(
      "creds-missing-fixture.json",
      VALID_SPAN_FIXTURE,
    );
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([filePath]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[credentials]");
    expect(bedrock.send).not.toHaveBeenCalled();
  });

  it("treats an empty access key as a missing-credentials failure", async () => {
    credentialProviderImpl.mockImplementation(async () => ({
      accessKeyId: "",
      secretAccessKey: "secret",
    }));
    const filePath = writeTempFile(
      "creds-empty-fixture.json",
      VALID_SPAN_FIXTURE,
    );
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([filePath]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[credentials]");
    expect(bedrock.send).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// 6. bedrock:Converse access-denied (Req 9.9 / Req 10.5)
// ---------------------------------------------------------------------------

describe("runHarness — bedrock:Converse access-denied (Reqs 9.9, 10.5)", () => {
  it("reports the Converse operation, exits non-zero, and never substitutes local scoring", async () => {
    const filePath = writeTempFile(
      "access-denied-fixture.json",
      VALID_SPAN_FIXTURE,
    );
    const accessDenied = Object.assign(
      new Error(
        "User: arn:aws:iam::123:user/me is not authorized to perform: bedrock:InvokeModel",
      ),
      { name: "AccessDeniedException" },
    );
    const send = vi.fn().mockRejectedValue(accessDenied);
    _setBedrockClient(
      { send } as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([filePath]),
    );

    expect(exitCode).not.toBe(0);
    // The harness names the failing operation in the stderr tag so an
    // operator can match on `[bedrock:Converse]` directly (Req 10.5).
    expect(streams.stderr).toContain("[bedrock:Converse]");
    // The reason references the Converse failure category (`JUDGE_ERROR`)
    // surfaced through `evaluateCaseSession`'s error mapping.
    expect(streams.stderr).toMatch(/access|denied|judge/i);
    // No score values were ever printed for the case — the harness
    // does NOT silently fall back to a local-scoring substitute
    // (Req 10.5 / Req 8.8). The `goalSuccessScore` line, if printed at
    // all, must show `(unset)`.
    expect(streams.stdout).not.toMatch(/goalSuccessScore:\s+0\.\d+/);
    expect(streams.stdout).not.toMatch(/helpfulnessScore:\s+0\.\d+/);
    expect(streams.stdout).not.toMatch(/toolAccuracyScore:\s+0\.\d+/);
  });
});

// ---------------------------------------------------------------------------
// 7. qconnect:ListSpans access-denied (Reqs 9.8, 10.5)
// ---------------------------------------------------------------------------

describe("runHarness — qconnect:ListSpans access-denied (Reqs 9.8, 10.5)", () => {
  it("reports the ListSpans operation and exits non-zero with no judge call", async () => {
    const accessDenied = Object.assign(
      new Error(
        "User: arn:aws:iam::123:user/me is not authorized to perform: wisdom:ListSpans",
      ),
      { name: "AccessDeniedException" },
    );
    qConnectSendImpl.mockRejectedValueOnce(accessDenied);
    const bedrock = bedrockClientReturning();
    _setBedrockClient(
      bedrock as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const sessionId = "12345678-1234-1234-1234-1234567890ab";
    const { exitCode, streams } = await captureStreams(() =>
      runHarness([sessionId, "--assistant-id", "assist-stub"]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[qconnect:ListSpans]");
    expect(streams.stderr).toMatch(/access denied/i);
    // No Bedrock judge call ever issued (Req 9.8 — "without invoking
    // the Bedrock_Judge_Client") and no local-scoring fallback
    // (Req 10.5).
    expect(bedrock.send).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// 8. Judge timeout / parse error (Reqs 9.9, 10.5)
// ---------------------------------------------------------------------------

describe("runHarness — judge timeout / error (Reqs 9.9, 10.5)", () => {
  it("reports a Bedrock Converse timeout and exits non-zero with no fallback", async () => {
    const filePath = writeTempFile(
      "timeout-fixture.json",
      VALID_SPAN_FIXTURE,
    );
    // The judge client honours `abortSignal`; this mock implements the
    // exact shape (rejects with an `AbortError` when the wrapper aborts)
    // so the wrapper's per-call `setTimeout` triggers a `JudgeTimeoutError`.
    const send = vi.fn().mockImplementation(
      (_cmd: unknown, opts?: { abortSignal?: AbortSignal }) =>
        new Promise<never>((_, reject) => {
          opts?.abortSignal?.addEventListener("abort", () => {
            const err = new Error("aborted");
            err.name = "AbortError";
            reject(err);
          });
        }),
    );
    _setBedrockClient(
      { send } as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    // Tight timeout so the test does not wait the default 60s.
    const { exitCode, streams } = await captureStreams(() =>
      runHarness([filePath, "--timeout-ms", "25"]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[bedrock:Converse]");
    expect(streams.stderr).toMatch(/timed out|did not return/i);
    // The error is surfaced — local scoring never substitutes a
    // numeric score (Req 10.5 / Req 8.5 / Req 8.8). The score lines,
    // if printed, are `(unset)`.
    expect(streams.stdout).not.toMatch(/goalSuccessScore:\s+0\.\d+/);
  });

  it("reports an unmappable Converse response and exits non-zero with no fallback", async () => {
    const filePath = writeTempFile(
      "parse-error-fixture.json",
      VALID_SPAN_FIXTURE,
    );
    // Bedrock returns a payload that is neither fenced JSON nor a
    // recoverable braced-substring → JudgeResponseParseError →
    // UNMAPPABLE_RESULT.
    const send = vi
      .fn()
      .mockResolvedValue(makeConverseResponse("I refuse to evaluate this."));
    _setBedrockClient(
      { send } as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode, streams } = await captureStreams(() =>
      runHarness([filePath]),
    );

    expect(exitCode).not.toBe(0);
    expect(streams.stderr).toContain("[bedrock:Converse]");
    expect(streams.stderr).toMatch(/unmappable|unparseable|parse/i);
    // The judge `send` was actually invoked (to discover the parse
    // failure) — but no numeric score is ever printed.
    expect(send).toHaveBeenCalled();
    expect(streams.stdout).not.toMatch(/goalSuccessScore:\s+0\.\d+/);
  });
});

// ---------------------------------------------------------------------------
// 9. Static check — same shared modules as the deployed Lambda (Req 9.4)
// ---------------------------------------------------------------------------

describe("Evaluation Harness — shared code path with the Lambda (Req 9.4)", () => {
  const repoRoot = path.resolve(__dirname, "../..");
  const harnessSource = fs.readFileSync(
    path.join(repoRoot, "scripts", "evaluation-harness.ts"),
    "utf8",
  );
  const lambdaSource = fs.readFileSync(
    path.join(repoRoot, "src/backend/orchestration", "evaluation.ts"),
    "utf8",
  );

  it("imports `evaluateCaseSession` from the same evaluation module the Lambda exports it from", () => {
    expect(harnessSource).toMatch(
      /import\s*\{[^}]*\bevaluateCaseSession\b[^}]*\}\s*from\s+['"][^'"]*orchestration\/evaluation['"]/,
    );
    // And the Lambda must export it (sanity check; if this regresses
    // the harness's import would fail typecheck, but a clear assertion
    // beats a silent compile error).
    expect(lambdaSource).toMatch(
      /export\s+async\s+function\s+evaluateCaseSession/,
    );
  });

  it("imports `renderJudgePromptContext` from the same prompt-rendering module the Lambda uses", () => {
    expect(harnessSource).toMatch(
      /import\s*\{[^}]*\brenderJudgePromptContext\b[^}]*\}\s*from\s+['"][^'"]*shared\/utils\/judge-prompt-rendering['"]/,
    );
    expect(lambdaSource).toMatch(
      /import\s*\{[^}]*\brenderJudgePromptContext\b[^}]*\}\s*from\s+['"][^'"]*judge-prompt-rendering['"]/,
    );
  });

  it("imports the `judge` entrypoint from the same bedrock-judge-client module the Lambda uses", () => {
    expect(harnessSource).toMatch(
      /import\s*\{[^}]*\bjudge\b[^}]*\}\s*from\s+['"][^'"]*orchestration\/bedrock-judge-client['"]/,
    );
    expect(lambdaSource).toMatch(
      /import\s*\{[^}]*\bjudge\b[^}]*\}\s*from\s+['"][^'"]*bedrock-judge-client['"]/,
    );
  });

  it("transitively reuses the same `evaluation-scoring` Score_Scale tables as the Lambda", () => {
    // The harness does not need to import `evaluation-scoring.ts`
    // directly — it composes `evaluateCaseSession`, which itself maps
    // labels through the Score_Scale tables exported from
    // `evaluation-scoring.ts`. This assertion locks the Lambda's
    // dependency on the canonical scale module so the harness's shared
    // code path inherits it.
    expect(lambdaSource).toMatch(
      /import\s*\{[^}]*GOAL_SUCCESS_SCALE[^}]*\}\s*from\s+['"][^'"]*evaluation-scoring['"]/,
    );
    expect(lambdaSource).toMatch(/HELPFULNESS_SCALE/);
    expect(lambdaSource).toMatch(/TOOL_SELECTION_SCALE/);
  });

  it("never imports the local `tool-accuracy` scoring helper (Reqs 8.5, 8.8, 10.5)", () => {
    // The harness must not be a back-door for local scoring — same
    // forbidden symbols as the Lambda's `evaluation-no-fallback`
    // static guard.
    expect(harnessSource).not.toMatch(/from\s+['"][^'"]*tool-accuracy/);
    expect(harnessSource).not.toMatch(/\bcalculateToolAccuracy\b/);
  });

  it("never imports the obsolete AgentCore client modules", () => {
    expect(harnessSource).not.toMatch(/agentcore-client/);
    expect(harnessSource).not.toMatch(/trace-to-otel/);
    expect(harnessSource).not.toMatch(/buildOtelSession/);
  });
});

// ---------------------------------------------------------------------------
// 10. Wave-2 (Task 17.6 / 17.8) — every Converse the harness dispatches
// carries the registry-resolved `(modelId, inferenceConfig)` shape.
//
// The harness shares the deployed Lambda's judge client. The legacy
// `process.env.JUDGE_MODEL_ID ?? "..."` fallback was retired in Wave 2;
// the judge client now resolves its model id and inference parameters
// via `resolvePromptForRun(promptKey, runId)` against the Prompts_Store
// the test setup injects above. Because the suite-wide `beforeEach`
// installs an empty-overrides + null-snapshot store, the resolver
// yields the registry's bundled `judge_*` defaults — Anthropic Claude
  // Sonnet 4.6, `maxTokens: 2048`, and no other inference keys per the
// Anthropic Claude 4.x capability profile (R17.4).
//
// _Validates: Requirements 10.1, 11.2, 17.4_
// ---------------------------------------------------------------------------

describe("runHarness — registry-resolved (modelId, inferenceConfig) on every judge Converse (R10.1, R11.2, R17.4)", () => {
  it("dispatches every Converse with modelId = registry-resolved Sonnet 4.6 and inferenceConfig = { maxTokens } only", async () => {
    const filePath = writeTempFile(
      "registry-shape-fixture.json",
      VALID_SPAN_FIXTURE,
    );

    const captured: Array<InstanceType<typeof ConverseCommand>> = [];
    const send = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as InstanceType<typeof ConverseCommand>;
      captured.push(cmd);
      const text =
        cmd.input.messages?.[0]?.content
          ?.map((b) => ("text" in b ? b.text ?? "" : ""))
          .join("") ?? "";
      const score = text.includes("evaluating the helpfulness")
        ? "Very Helpful"
        : "Yes";
      return Promise.resolve({
        output: {
          message: {
            content: [
              {
                text: "```json\n" + JSON.stringify({ reasoning: "r", score }) + "\n```",
              },
            ],
          },
          stopReason: "end_turn",
        },
      });
    });
    _setBedrockClient(
      { send } as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { exitCode } = await captureStreams(() => runHarness([filePath]));

    // Sanity: the harness ran to completion and dispatched at least one
    // judge call. The fixture has one inference span and one
    // execute_tool span, so the fan-out is 1 GSR + 1 Helpfulness + 1
    // ToolSelection = 3 calls.
    expect(exitCode).toBe(0);
    expect(captured.length).toBeGreaterThanOrEqual(1);

    const expectedModelId = SUPPORTED_MODELS.claude_sonnet_4_6.inferenceProfileId;
    for (const cmd of captured) {
      expect(cmd).toBeInstanceOf(ConverseCommand);
      // R10.1 + R11.2: the modelId comes from the registry-resolved
      // judge prompt definition (default `claude_sonnet_4_6`), not
      // from `process.env.JUDGE_MODEL_ID`.
      expect(cmd.input.modelId).toBe(expectedModelId);
      expect(cmd.input.modelId).toMatch(/^us\.anthropic\.claude-sonnet/);

      // R17.4: Anthropic Claude 4.x accepts `maxTokens` only. The other
      // four Converse keys are forbidden by the profile and silently
      // dropped by `buildInferenceConfig`. No `additionalModelRequestFields`
      // — only Nova carries `topK` under that field.
      const inferenceConfig = cmd.input.inferenceConfig ?? {};
      expect(Object.keys(inferenceConfig).sort()).toEqual(["maxTokens"]);
      expect(inferenceConfig.maxTokens).toBe(2048);
      expect(inferenceConfig.temperature).toBeUndefined();
      expect(inferenceConfig.topP).toBeUndefined();
      expect(cmd.input.additionalModelRequestFields).toBeUndefined();
    }
  });
});
