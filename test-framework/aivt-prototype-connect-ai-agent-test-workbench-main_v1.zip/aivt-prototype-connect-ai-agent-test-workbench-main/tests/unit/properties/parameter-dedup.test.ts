// Feature: connect-agent-test-platform, Property 13: Knowledge template parameter deduplication
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import {
  deduplicateParameters,
  ToolSchema,
} from "@shared/utils/parameter-dedup";

/**
 * **Validates: Requirements 6.3**
 *
 * Property 13: Knowledge template parameter deduplication
 * For any ordered tool sequence where multiple tools share input parameters
 * with the same name, the generated customer knowledge template SHALL contain
 * exactly one entry per unique parameter name, and that entry SHALL be grouped
 * under the first tool in the sequence that requires it.
 */

// ---------------------------------------------------------------------------
// Generators
// ---------------------------------------------------------------------------

/** Small pool of parameter names to force overlaps between tools. */
const paramNameArb = fc.constantFrom(
  "accountId",
  "phoneNumber",
  "email",
  "customerId",
  "orderId",
  "amount",
  "currency",
  "startDate",
  "endDate",
  "destination"
);

/** Generate a tool schema with 0-8 parameters drawn from the shared pool. */
const toolSchemaArb: fc.Arbitrary<ToolSchema> = fc.record({
  toolName: fc.string({ minLength: 1, maxLength: 30 }).filter((s) => s.trim().length > 0),
  parameters: fc.array(paramNameArb, { minLength: 0, maxLength: 8 }),
});

/** Generate a list of 1-10 tools with overlapping parameters. */
const toolListArb: fc.Arbitrary<ToolSchema[]> = fc.array(toolSchemaArb, {
  minLength: 1,
  maxLength: 10,
});

// ---------------------------------------------------------------------------
// Property tests
// ---------------------------------------------------------------------------

describe("Property 13: Knowledge template parameter deduplication", () => {
  it("output contains exactly one entry per unique parameter name across all tools", () => {
    fc.assert(
      fc.property(toolListArb, (tools) => {
        const result = deduplicateParameters(tools);

        // Collect all unique parameter names from the input
        const allParams = new Set<string>();
        for (const tool of tools) {
          for (const param of tool.parameters) {
            allParams.add(param);
          }
        }

        // Result should have exactly one entry per unique param
        expect(result).toHaveLength(allParams.size);

        // Every unique param from input must appear in output
        const outputParams = new Set(result.map((e) => e.paramName));
        expect(outputParams.size).toBe(allParams.size);
        for (const param of allParams) {
          expect(outputParams.has(param)).toBe(true);
        }
      }),
      { numRuns: 100 }
    );
  });

  it("each entry's toolGroup is the FIRST tool in the sequence that uses that parameter", () => {
    fc.assert(
      fc.property(toolListArb, (tools) => {
        const result = deduplicateParameters(tools);

        // For each entry in the result, verify its toolGroup is the first tool
        // in the input sequence that contains that parameter
        for (const entry of result) {
          const firstTool = tools.find((t) =>
            t.parameters.includes(entry.paramName)
          );
          expect(firstTool).toBeDefined();
          expect(entry.toolGroup).toBe(firstTool!.toolName);
        }
      }),
      { numRuns: 100 }
    );
  });

  it("no parameter appears more than once in output", () => {
    fc.assert(
      fc.property(toolListArb, (tools) => {
        const result = deduplicateParameters(tools);

        const paramNames = result.map((e) => e.paramName);
        const uniqueParamNames = new Set(paramNames);
        expect(paramNames.length).toBe(uniqueParamNames.size);
      }),
      { numRuns: 100 }
    );
  });

  it("all unique parameters from input are present in output (no data loss)", () => {
    fc.assert(
      fc.property(toolListArb, (tools) => {
        const result = deduplicateParameters(tools);

        // Collect all unique parameter names from the input
        const allInputParams = new Set<string>();
        for (const tool of tools) {
          for (const param of tool.parameters) {
            allInputParams.add(param);
          }
        }

        const outputParams = new Set(result.map((e) => e.paramName));

        // Every input param must be in output
        for (const param of allInputParams) {
          expect(outputParams.has(param)).toBe(true);
        }

        // No extra params in output that weren't in input
        for (const param of outputParams) {
          expect(allInputParams.has(param)).toBe(true);
        }
      }),
      { numRuns: 100 }
    );
  });

  it("output preserves encounter order (first-seen order)", () => {
    fc.assert(
      fc.property(toolListArb, (tools) => {
        const result = deduplicateParameters(tools);

        // Reconstruct expected order by walking tools in sequence
        const seen = new Set<string>();
        const expectedOrder: string[] = [];
        for (const tool of tools) {
          for (const param of tool.parameters) {
            if (!seen.has(param)) {
              seen.add(param);
              expectedOrder.push(param);
            }
          }
        }

        const actualOrder = result.map((e) => e.paramName);
        expect(actualOrder).toEqual(expectedOrder);
      }),
      { numRuns: 100 }
    );
  });
});
