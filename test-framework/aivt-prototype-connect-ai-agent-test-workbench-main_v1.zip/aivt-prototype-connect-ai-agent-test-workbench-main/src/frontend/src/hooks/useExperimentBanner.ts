/**
 * useExperimentBanner — lightweight polling hook for the Run Dashboard's
 * informational experiment progress banner.
 *
 * Separate from the orchestrator hook (`useImplementRecommendations`) because:
 * 1. It polls at a slower interval (10s vs 5s) — informational, not blocking
 * 2. It tolerates failures silently (retains last-known state)
 * 3. It runs independently of whether the user is in the implement flow
 *
 * Lifecycle:
 *   - On mount: calls `listExperiments(runId)` → picks the first experiment
 *   - If the experiment is in a non-terminal status: polls
 *     `getExperiment(runId, experimentId)` every 10 seconds
 *   - On poll failure: increments consecutive failure counter, retains last
 *     known status. After 3 consecutive failures, sets `pollError = true`
 *   - On success after failures: resets failure counter, clears `pollError`
 *   - Stops polling when the experiment reaches a terminal status or the
 *     component unmounts (clearInterval cleanup)
 *
 * @module frontend/hooks/useExperimentBanner
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { listExperiments, getExperiment } from '../api/recommendations';
import type { ExperimentRecord } from '../../../shared/types';
import type { ExperimentStatus } from '../../../shared/types';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Poll interval for the informational banner (slower than orchestrator's 5s). */
const POLL_INTERVAL_MS = 10_000;

/** Number of consecutive failures before surfacing an error to the user. */
const MAX_CONSECUTIVE_FAILURES = 3;

/** Experiment statuses that indicate the lifecycle is complete. */
const TERMINAL_STATUSES: ExperimentStatus[] = ['completed', 'failed', 'cleaned_up'];

function isTerminalStatus(status: ExperimentStatus): boolean {
  return TERMINAL_STATUSES.includes(status);
}

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

export interface ExperimentBannerState {
  /** Whether an experiment exists for this run. */
  hasExperiment: boolean;
  /** Current experiment record (null if no experiment or not yet fetched). */
  experiment: ExperimentRecord | null;
  /** Whether the banner is in an error state (3+ consecutive poll failures). */
  pollError: boolean;
  /** Whether the experiment is in a terminal state. */
  isTerminal: boolean;
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useExperimentBanner(runId: string | null): ExperimentBannerState {
  const [experiment, setExperiment] = useState<ExperimentRecord | null>(null);
  const [pollError, setPollError] = useState(false);

  // Track consecutive failures in a ref to avoid triggering re-renders on
  // each failed poll (only update state when crossing the threshold).
  const failureCountRef = useRef(0);

  // Store the experimentId once discovered so we poll the specific endpoint.
  const experimentIdRef = useRef<string | null>(null);

  // Determine derived state
  const hasExperiment = experiment !== null;
  const isTerminal = experiment !== null && isTerminalStatus(experiment.status);

  /**
   * Handle a successful poll response: update experiment state, reset
   * failure tracking, and clear any previous pollError.
   */
  const handlePollSuccess = useCallback((record: ExperimentRecord) => {
    setExperiment(record);
    if (failureCountRef.current > 0) {
      failureCountRef.current = 0;
      setPollError(false);
    }
  }, []);

  /**
   * Handle a poll failure: increment consecutive failure counter.
   * After MAX_CONSECUTIVE_FAILURES, surface pollError to the UI.
   * The last-known experiment state is retained (not cleared).
   */
  const handlePollFailure = useCallback(() => {
    failureCountRef.current += 1;
    if (failureCountRef.current >= MAX_CONSECUTIVE_FAILURES) {
      setPollError(true);
    }
  }, []);

  useEffect(() => {
    if (!runId) return;

    let cancelled = false;
    let intervalId: ReturnType<typeof setInterval> | null = null;

    /**
     * Initial fetch: discover whether an experiment exists for this run.
     */
    const initialize = async () => {
      try {
        const response = await listExperiments(runId);
        if (cancelled) return;

        if (response.experiments.length === 0) {
          // No experiment for this run — nothing to display or poll.
          return;
        }

        const first = response.experiments[0];
        experimentIdRef.current = first.experimentId;
        handlePollSuccess(first);

        // If the experiment is already terminal, no need to poll.
        if (isTerminalStatus(first.status)) {
          return;
        }

        // Start polling for status updates.
        intervalId = setInterval(poll, POLL_INTERVAL_MS);
      } catch {
        // Initial fetch failure — treat as "no experiment" for now.
        // The user can refresh the page to retry.
        if (!cancelled) {
          handlePollFailure();
        }
      }
    };

    /**
     * Poll the specific experiment endpoint for status updates.
     */
    const poll = async () => {
      if (!experimentIdRef.current || !runId) return;

      try {
        const record = await getExperiment(runId, experimentIdRef.current);
        if (cancelled) return;

        handlePollSuccess(record);

        // Stop polling once the experiment reaches a terminal status.
        if (isTerminalStatus(record.status)) {
          if (intervalId !== null) {
            clearInterval(intervalId);
            intervalId = null;
          }
        }
      } catch {
        if (!cancelled) {
          handlePollFailure();
        }
      }
    };

    void initialize();

    return () => {
      cancelled = true;
      if (intervalId !== null) {
        clearInterval(intervalId);
      }
    };
  }, [runId, handlePollSuccess, handlePollFailure]);

  return {
    hasExperiment,
    experiment,
    pollError,
    isTerminal,
  };
}
