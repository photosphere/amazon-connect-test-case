/**
 * Filler response detection for Q in Connect messages.
 *
 * Q in Connect sends intermediate "filler" responses (e.g., "...", "......", "…")
 * while the agent is still processing. These must be detected and skipped so the
 * conversation driver continues polling rather than treating them as real output.
 *
 * A response is a filler if and only if:
 * 1. The text matches a known filler pattern ("...", "......", or "…")
 * 2. The nextMessageToken has NOT advanced (tokenAdvanced is false)
 *
 * If the token has advanced, it indicates the message is substantive even if the
 * text happens to match a filler pattern.
 *
 * @module filler-detection
 */

/** Known filler text patterns from Q in Connect. */
const FILLER_PATTERNS: ReadonlySet<string> = new Set(["...", "......", "\u2026"]);

/**
 * Determines whether a response is a filler (non-substantive) response.
 *
 * @param text - The message text from GetNextMessage (may be null/undefined)
 * @param tokenAdvanced - Whether the nextMessageToken advanced from the previous poll
 * @returns true if the response is a filler that should be skipped, false otherwise
 */
export function isFillerResponse(
  text: string | undefined | null,
  tokenAdvanced: boolean
): boolean {
  if (text == null) {
    return false;
  }

  if (tokenAdvanced) {
    return false;
  }

  return FILLER_PATTERNS.has(text);
}
