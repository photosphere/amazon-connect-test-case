/**
 * Prompts catalog landing page.
 *
 * Fetches `GET /prompts` via the typed {@link listPrompts} client and renders
 * a Cloudscape Table over the registry's prompts. Implements the four UX
 * requirements from R13.2–R13.7:
 *
 *   - R13.2: Table columns over `name`, `category`, current
 *     `currentModelDisplayName`, `lastModifiedAt`, `lastModifiedBy`, plus a
 *     Cloudscape `Badge` cell for the `isOverridden` flag.
 *
 *   - R13.4: row click navigates to `/prompts/{promptKey}`. The "Name"
 *     column also renders as a click-through Link so keyboard users can
 *     follow the row without first selecting it (mirrors the convention
 *     used on the Test Suites list).
 *
 *   - R13.5: while the `GET /prompts` request is in flight, the table is
 *     not rendered at all — a centered Cloudscape StatusIndicator stands
 *     in for the rows so the user does not see partial chrome flicker
 *     between login and the response landing.
 *
 *   - R13.6: a transport error OR a >10s timeout surfaces a Cloudscape
 *     Alert with a Retry action that re-issues the same request. The
 *     base API client already retries network timeouts with backoff at
 *     30s, but R13.6 specifically wants the user to see a banner if the
 *     overall response misses the 10s budget — so we run our own race
 *     timer in parallel and trip the error state on whichever fires first.
 *
 *   - R13.7: when the response is empty (the registry build has dropped
 *     to zero declared prompts — a bug, but render-safely defended), the
 *     page shows an empty-state Box reading "No prompts available".
 *
 * R2.2 sort: results are pre-sorted by `category` then `name` ascending,
 * case-insensitive, before being handed to the Table so the initial
 * render is deterministic regardless of which order the backend chose.
 */

import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Alert from '@cloudscape-design/components/alert';
import Badge from '@cloudscape-design/components/badge';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import Link from '@cloudscape-design/components/link';
import SpaceBetween from '@cloudscape-design/components/space-between';
import StatusIndicator from '@cloudscape-design/components/status-indicator';
import Table, { type TableProps } from '@cloudscape-design/components/table';
import { ApiClientError, listPrompts, type PromptListItem } from '../api';
import { PromptApiError } from '../api/prompts';

/**
 * Hard cap on how long we wait for `GET /prompts` to land before flipping
 * the page into the error state per R13.6. The base API client has its
 * own 30s timeout-with-retry layer; this 10s timer is purely a UX gate so
 * the user is never staring at a spinner indefinitely on a slow link.
 */
const LIST_PROMPTS_TIMEOUT_MS = 10_000;

/**
 * Race `listPrompts()` against a 10s timer. Whichever wins decides the
 * page state — a successful response populates the table, a timeout
 * surfaces the R13.6 retry banner. If `listPrompts` rejects after the
 * timer already fired, the rejection is swallowed because the page has
 * already moved on; React state updates from a stale promise are guarded
 * by an `isCurrent` ref captured by the caller.
 */
async function listPromptsWithBudget(): Promise<PromptListItem[]> {
  const result = await Promise.race([
    listPrompts().then((r) => ({ kind: 'ok' as const, prompts: r.prompts })),
    new Promise<{ kind: 'timeout' }>((resolve) =>
      setTimeout(
        () => resolve({ kind: 'timeout' as const }),
        LIST_PROMPTS_TIMEOUT_MS,
      ),
    ),
  ]);
  if (result.kind === 'timeout') {
    throw new Error(
      `Loading prompts is taking longer than ${
        LIST_PROMPTS_TIMEOUT_MS / 1_000
      }s. Check your connection and try again.`,
    );
  }
  return result.prompts;
}

/**
 * Case-insensitive comparator over (`category`, `name`) per R2.2. The
 * backend already sorts the response, but pre-sorting here keeps the
 * page deterministic if the response order ever drifts and lets the
 * Cloudscape Table's user-driven re-sort fall back to a stable initial
 * order when the user clears column sorting.
 */
function compareByCategoryThenName(a: PromptListItem, b: PromptListItem): number {
  const byCategory = a.category.localeCompare(b.category, undefined, {
    sensitivity: 'base',
  });
  if (byCategory !== 0) return byCategory;
  return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
}

/**
 * Format an ISO-8601 instant for the "Last modified" column. `null` shows
 * an em-dash so a never-overridden prompt is visually distinct from an
 * old override.
 */
function formatTimestamp(iso: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleString();
}

export function PromptsListPage(): JSX.Element {
  const navigate = useNavigate();
  const [prompts, setPrompts] = useState<PromptListItem[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // Cloudscape `<Table>` sorting is controlled — without these state
  // hooks plus `onSortingChange` the column header triangles render but
  // clicking them is a no-op (the items array never re-orders). The
  // initial state matches the R2.2 default-row order
  // (`category` ascending) so the first paint and the user's first
  // click on the Category header agree.
  const [sortingColumn, setSortingColumn] = useState<
    TableProps.SortingColumn<PromptListItem>
  >({
    sortingField: 'category',
  });
  const [sortingDescending, setSortingDescending] = useState(false);

  const fetchPrompts = useCallback(async () => {
    setLoading(true);
    setError(null);
    // Hide stale rows while the refetch is in flight so the UI never
    // shows a previous response merged with an in-progress one. This
    // matches R13.5 ("rows hidden until the response arrives") even on
    // a manual retry, not just on first mount.
    setPrompts(null);
    try {
      const next = await listPromptsWithBudget();
      next.sort(compareByCategoryThenName);
      setPrompts(next);
    } catch (err) {
      // Map the platform's typed errors back to a user-facing message.
      // PromptApiError carries the structured `code` (e.g. PROMPT_NOT_FOUND
      // is impossible on the list endpoint — included for completeness);
      // ApiClientError covers transport/auth failures; everything else
      // (notably the Promise.race timeout) is surfaced as plain text.
      if (err instanceof PromptApiError) {
        setError(err.message);
      } else if (err instanceof ApiClientError) {
        setError(err.message);
      } else if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred while loading prompts.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPrompts();
  }, [fetchPrompts]);

  /**
   * Cloudscape column definitions. Sorting fields are case-insensitive
   * via `sortingComparator` so the column header sort matches the
   * default-row order R2.2 mandates.
   */
  const columnDefinitions = useMemo<
    TableProps.ColumnDefinition<PromptListItem>[]
  >(
    () => [
      {
        id: 'name',
        header: 'Name',
        sortingField: 'name',
        cell: (item) => (
          <Link
            onFollow={(e) => {
              e.preventDefault();
              navigate(`/prompts/${encodeURIComponent(item.promptKey)}`);
            }}
            href={`/prompts/${encodeURIComponent(item.promptKey)}`}
          >
            {item.name}
          </Link>
        ),
        sortingComparator: (a, b) =>
          a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }),
      },
      {
        id: 'category',
        header: 'Category',
        sortingField: 'category',
        cell: (item) => item.category,
        sortingComparator: (a, b) =>
          a.category.localeCompare(b.category, undefined, {
            sensitivity: 'base',
          }),
      },
      {
        id: 'currentModelDisplayName',
        header: 'Model',
        sortingField: 'currentModelDisplayName',
        cell: (item) => item.currentModelDisplayName,
        sortingComparator: (a, b) =>
          a.currentModelDisplayName.localeCompare(
            b.currentModelDisplayName,
            undefined,
            { sensitivity: 'base' },
          ),
      },
      {
        id: 'isOverridden',
        header: 'Status',
        sortingField: 'isOverridden',
        // Renders an "Override" badge for prompts the user has tuned
        // and a neutral "Default" badge otherwise so the user can tell
        // at a glance which prompts are running registry-bundled text
        // vs. a deployment-local edit.
        cell: (item) =>
          item.isOverridden ? (
            <Badge color="blue">Override</Badge>
          ) : (
            <Badge color="grey">Default</Badge>
          ),
        sortingComparator: (a, b) =>
          Number(a.isOverridden) - Number(b.isOverridden),
      },
      {
        id: 'lastModifiedAt',
        header: 'Last modified',
        sortingField: 'lastModifiedAt',
        cell: (item) => formatTimestamp(item.lastModifiedAt),
        sortingComparator: (a, b) => {
          // Null sorts last (never-overridden prompts are "older" than any edit)
          const aT = a.lastModifiedAt
            ? Date.parse(a.lastModifiedAt)
            : Number.NEGATIVE_INFINITY;
          const bT = b.lastModifiedAt
            ? Date.parse(b.lastModifiedAt)
            : Number.NEGATIVE_INFINITY;
          return aT - bT;
        },
      },
      {
        id: 'lastModifiedBy',
        header: 'Last modified by',
        // Prefer the captured display-hint email over the stable
        // Cognito `sub` UUID. The UUID is still in `lastModifiedBy`
        // for forensic use; the email is only for display, and falls
        // through to "—" when neither field is populated (the row
        // has never been overridden, OR the editor was an M2M client
        // that didn't supply the `X-User-Email` header).
        cell: (item) => item.lastModifiedByEmail ?? item.lastModifiedBy ?? '—',
      },
    ],
    [navigate],
  );

  // ---- Loading state (R13.5) ------------------------------------------
  // Render a centered StatusIndicator with no table chrome so the rows
  // are demonstrably hidden until the response lands. We keep the
  // page header so the user sees they're on the right page.
  if (loading) {
    return (
      <ContentLayout
        header={
          <Header
            variant="h1"
            description="Inspect and tune the prompts the platform sends to Bedrock."
          >
            Prompts
          </Header>
        }
      >
        <Box textAlign="center" padding="xl">
          <StatusIndicator type="loading">Loading prompts…</StatusIndicator>
        </Box>
      </ContentLayout>
    );
  }

  // ---- Error state (R13.6) --------------------------------------------
  if (error) {
    return (
      <ContentLayout
        header={
          <Header
            variant="h1"
            description="Inspect and tune the prompts the platform sends to Bedrock."
          >
            Prompts
          </Header>
        }
      >
        <Alert
          type="error"
          header="Could not load prompts"
          action={<Button onClick={fetchPrompts}>Retry</Button>}
        >
          {error}
        </Alert>
      </ContentLayout>
    );
  }

  // ---- Loaded state (table render, possibly empty) --------------------
  // `prompts` is non-null here because the loading branch returned
  // above. We coerce-default to `[]` to keep TypeScript happy; the
  // empty-state branch on the Table itself handles R13.7.
  const items = prompts ?? [];

  // Apply the active sort. Cloudscape's controlled `<Table>` does NOT
  // re-sort items on its own when `sortingColumn` / `sortingDescending`
  // change — the parent owns that logic so the table stays a pure view
  // over whatever array we pass in. We look up the matching column's
  // `sortingComparator` and apply it (and the descending flag) here so
  // the rows visibly re-order on every triangle click. Falling back to
  // the unsorted items when no comparator matches keeps the table
  // render-safe if a future column drops its comparator.
  const sortedItems = (() => {
    const activeColumn = columnDefinitions.find(
      (col) => col.sortingField === sortingColumn.sortingField
        || col.sortingComparator === sortingColumn.sortingComparator
        || col.id === sortingColumn.sortingField,
    );
    const comparator = activeColumn?.sortingComparator;
    if (!comparator) return items;
    const sorted = [...items].sort(comparator);
    return sortingDescending ? sorted.reverse() : sorted;
  })();

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description="Inspect and tune the prompts the platform sends to Bedrock."
          actions={
            <Button iconName="refresh" onClick={fetchPrompts}>
              Refresh
            </Button>
          }
        >
          Prompts
        </Header>
      }
    >
      <Table
        columnDefinitions={columnDefinitions}
        items={sortedItems}
        trackBy="promptKey"
        variant="full-page"
        // Controlled sort — see the `sortingColumn` / `sortingDescending`
        // state declared near the top of this component. Without these
        // three props wired together, the column-header triangles render
        // but clicking them is a no-op.
        sortingColumn={sortingColumn}
        sortingDescending={sortingDescending}
        onSortingChange={(e) => {
          setSortingColumn(e.detail.sortingColumn);
          setSortingDescending(e.detail.isDescending ?? false);
        }}
        // Row click → detail page per R13.4. The Cloudscape Table's
        // selection types ('single' | 'multi') are intentionally NOT
        // used here — we want a row click to navigate, not to flip a
        // checkbox.
        onRowClick={(e) => {
          const promptKey = e.detail.item.promptKey;
          navigate(`/prompts/${encodeURIComponent(promptKey)}`);
        }}
        header={<Header counter={`(${items.length})`}>Prompts</Header>}
        // R13.7 empty state. Rendered by the Table when `items` is
        // empty; the registry always has thirteen entries today, so
        // this branch effectively guards against a future regression.
        empty={
          <Box textAlign="center" color="inherit" padding="l">
            <SpaceBetween size="s">
              <b>No prompts available</b>
              <Box variant="p" color="inherit">
                The platform did not return any prompts. This usually means a
                registry build regression — please contact the platform team.
              </Box>
            </SpaceBetween>
          </Box>
        }
      />
    </ContentLayout>
  );
}
