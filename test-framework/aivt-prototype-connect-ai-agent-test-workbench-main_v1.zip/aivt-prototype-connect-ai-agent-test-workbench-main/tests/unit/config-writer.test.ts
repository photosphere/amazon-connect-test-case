import { describe, it, expect, vi, beforeEach } from "vitest";
import {
  buildUpdatedTools,
  buildUpdatedSystemPrompt,
  writeConfig,
  _setQConnectClient,
  WritePayload,
} from "../../src/backend/orchestration/config-writer";
import type {
  AgentDetail,
  Recommendation,
  ToolDefinition,
} from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

function makeTool(overrides: Partial<ToolDefinition> = {}): ToolDefinition {
  return {
    toolName: "searchFlights",
    toolType: "LAMBDA",
    description: "Search available flights",
    instruction: "Use for flight searches only",
    inputSchema: { type: "object" },
    examples: ["Example: search LAX to JFK"],
    ...overrides,
  };
}

function makeAgent(overrides: Partial<AgentDetail> = {}): AgentDetail {
  return {
    agentId: "agent-1",
    name: "TestAgent",
    type: "ORCHESTRATION",
    systemPrompt: "You are a helpful travel agent.",
    modelId: "anthropic.claude-3-haiku",
    tools: [makeTool()],
    ...overrides,
  };
}

function makeRec(overrides: Partial<Recommendation> = {}): Recommendation {
  return {
    targetField: "tool_description",
    targetName: "searchFlights",
    currentText: "Search available flights",
    suggestedText: "Search for available flights by origin and destination",
    rationale: "More specific",
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// buildUpdatedTools
// ---------------------------------------------------------------------------

describe("buildUpdatedTools", () => {
  it("applies tool_description recommendation to the correct tool", () => {
    const tools = [makeTool()];
    const recs = [makeRec()];

    const result = buildUpdatedTools(tools, recs);

    expect(result[0].description).toBe(
      "Search for available flights by origin and destination"
    );
    // Other fields unchanged
    expect(result[0].toolName).toBe("searchFlights");
    expect(result[0].instruction).toBe("Use for flight searches only");
    expect(result[0].examples).toEqual(["Example: search LAX to JFK"]);
  });

  it("applies tool_instruction recommendation", () => {
    const tools = [makeTool()];
    const recs = [
      makeRec({
        targetField: "tool_instruction",
        currentText: "Use for flight searches only",
        suggestedText: "Use for flight searches. Verify dates before calling.",
      }),
    ];

    const result = buildUpdatedTools(tools, recs);

    expect(result[0].instruction).toBe(
      "Use for flight searches. Verify dates before calling."
    );
    expect(result[0].description).toBe("Search available flights");
  });

  it("applies tool_examples add operation (empty currentText)", () => {
    const tools = [makeTool()];
    const recs = [
      makeRec({
        targetField: "tool_examples",
        currentText: "",
        suggestedText: "Example: search SFO to LAX on 2025-03-01",
      }),
    ];

    const result = buildUpdatedTools(tools, recs);

    expect(result[0].examples).toEqual([
      "Example: search LAX to JFK",
      "Example: search SFO to LAX on 2025-03-01",
    ]);
  });

  it("applies tool_examples remove operation (empty suggestedText)", () => {
    const tools = [makeTool()];
    const recs = [
      makeRec({
        targetField: "tool_examples",
        currentText: "Example: search LAX to JFK",
        suggestedText: "",
      }),
    ];

    const result = buildUpdatedTools(tools, recs);

    expect(result[0].examples).toEqual([]);
  });

  it("applies tool_examples replace operation (both non-empty)", () => {
    const tools = [makeTool()];
    const recs = [
      makeRec({
        targetField: "tool_examples",
        currentText: "Example: search LAX to JFK",
        suggestedText: "Example: search from LAX to JFK on 2025-01-15",
      }),
    ];

    const result = buildUpdatedTools(tools, recs);

    expect(result[0].examples).toEqual([
      "Example: search from LAX to JFK on 2025-01-15",
    ]);
  });

  it("does not mutate the original tools array", () => {
    const tools = [makeTool()];
    const originalDescription = tools[0].description;
    const recs = [makeRec()];

    buildUpdatedTools(tools, recs);

    expect(tools[0].description).toBe(originalDescription);
  });

  it("leaves unrelated tools untouched", () => {
    const tools = [
      makeTool(),
      makeTool({
        toolName: "bookFlight",
        description: "Book a confirmed flight",
      }),
    ];
    const recs = [makeRec()]; // targets searchFlights only

    const result = buildUpdatedTools(tools, recs);

    expect(result[1].description).toBe("Book a confirmed flight");
    expect(result[1].toolName).toBe("bookFlight");
  });

  it("applies multiple recommendations to different tools", () => {
    const tools = [
      makeTool(),
      makeTool({
        toolName: "bookFlight",
        description: "Book a flight",
        instruction: "Use after search",
      }),
    ];
    const recs = [
      makeRec(),
      makeRec({
        targetName: "bookFlight",
        targetField: "tool_instruction",
        currentText: "Use after search",
        suggestedText: "Use after successful search. Confirm with customer.",
      }),
    ];

    const result = buildUpdatedTools(tools, recs);

    expect(result[0].description).toBe(
      "Search for available flights by origin and destination"
    );
    expect(result[1].instruction).toBe(
      "Use after successful search. Confirm with customer."
    );
  });

  it("skips system_prompt recommendations", () => {
    const tools = [makeTool()];
    const recs = [
      makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "old prompt",
        suggestedText: "new prompt",
      }),
    ];

    const result = buildUpdatedTools(tools, recs);

    // Tools unchanged
    expect(result[0].description).toBe("Search available flights");
  });

  it("skips recommendations targeting non-existent tools", () => {
    const tools = [makeTool()];
    const recs = [
      makeRec({
        targetName: "nonExistentTool",
      }),
    ];

    const result = buildUpdatedTools(tools, recs);

    expect(result[0].description).toBe("Search available flights");
  });
});

// ---------------------------------------------------------------------------
// buildUpdatedSystemPrompt
// ---------------------------------------------------------------------------

describe("buildUpdatedSystemPrompt", () => {
  it("wraps the suggestedText in the Q in Connect YAML envelope", () => {
    const result = buildUpdatedSystemPrompt("Old prompt", [
      makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "Old prompt",
        suggestedText: "New improved prompt",
      }),
    ]);

    expect(result.startsWith("system: |")).toBe(true);
    expect(result).toContain("  New improved prompt");
    expect(result).toContain("messages:");
    expect(result).toContain('{{$.conversationHistory}}');
  });

  it("returns the current prompt when no system_prompt recs exist", () => {
    const result = buildUpdatedSystemPrompt("Current prompt", [
      makeRec({ targetField: "tool_description" }),
    ]);

    expect(result).toBe("Current prompt");
  });

  it("applies the last system_prompt recommendation when multiple exist", () => {
    const result = buildUpdatedSystemPrompt("Original", [
      makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "Original",
        suggestedText: "First edit",
      }),
      makeRec({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "Original",
        suggestedText: "Second edit wins",
      }),
    ]);

    expect(result).toContain("  Second edit wins");
    expect(result).not.toContain("  First edit");
    expect(result.startsWith("system: |")).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// writeConfig (integration with mocked SDK)
// ---------------------------------------------------------------------------

describe("writeConfig", () => {
  function createMockClient(sendFn: (command: unknown) => Promise<unknown>) {
    return { send: vi.fn(sendFn) } as any;
  }

  beforeEach(() => {
    _setQConnectClient(null);
  });

  it("calls UpdateAIAgent for tool-surface recommendations", async () => {
    const mockClient = createMockClient(async (command: unknown) => {
      const name = (command as any).constructor?.name;
      if (name === "GetAIAgentCommand") {
        return {
          aiAgent: {
            aiAgentId: "agent-1",
            visibilityStatus: "PUBLISHED",
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: "prompt-1",
                toolConfigurations: [],
              },
            },
          },
        };
      }
      if (name === "UpdateAIAgentCommand") {
        return { aiAgent: { aiAgentId: "agent-1-v2" } };
      }
      return {};
    });
    _setQConnectClient(mockClient);

    const payload: WritePayload = {
      agentId: "agent-1",
      assistantId: "asst-1",
      recommendations: [makeRec()],
      currentConfig: makeAgent(),
    };

    const result = await writeConfig(payload);

    expect(result.success).toBe(true);
    expect(result.newAgentVersionId).toBe("agent-1-v2");
    expect(result.newPromptVersionId).toBeUndefined();
    expect(mockClient.send).toHaveBeenCalledTimes(2); // GetAIAgent + UpdateAIAgent
  });

  it("calls UpdateAIPrompt for system_prompt recommendations", async () => {
    const mockClient = createMockClient(async (command: unknown) => {
      const name = (command as any).constructor?.name;
      if (name === "GetAIAgentCommand") {
        return {
          aiAgent: {
            aiAgentId: "agent-1",
            visibilityStatus: "PUBLISHED",
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: "prompt-1",
              },
            },
          },
        };
      }
      if (name === "GetAIPromptCommand") {
        return {
          aiPrompt: {
            aiPromptId: "prompt-1",
            visibilityStatus: "PUBLISHED",
            modelId: "anthropic.claude-3",
          },
        };
      }
      if (name === "UpdateAIPromptCommand") {
        return { aiPrompt: { aiPromptId: "prompt-1-v2" } };
      }
      return {};
    });
    _setQConnectClient(mockClient);

    const payload: WritePayload = {
      agentId: "agent-1",
      assistantId: "asst-1",
      recommendations: [
        makeRec({
          targetField: "system_prompt",
          targetName: "system_prompt",
          currentText: "You are a helpful travel agent.",
          suggestedText: "You are a knowledgeable travel agent.",
        }),
      ],
      currentConfig: makeAgent(),
    };

    const result = await writeConfig(payload);

    expect(result.success).toBe(true);
    expect(result.newPromptVersionId).toBe("prompt-1-v2");
    expect(result.newAgentVersionId).toBeUndefined();
  });

  it("returns error when UpdateAIAgent fails", async () => {
    const mockClient = createMockClient(async (command: unknown) => {
      const name = (command as any).constructor?.name;
      if (name === "GetAIAgentCommand") {
        return {
          aiAgent: {
            aiAgentId: "agent-1",
            visibilityStatus: "PUBLISHED",
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: "prompt-1",
              },
            },
          },
        };
      }
      if (name === "UpdateAIAgentCommand") {
        throw new Error("Access denied");
      }
      return {};
    });
    _setQConnectClient(mockClient);

    const payload: WritePayload = {
      agentId: "agent-1",
      assistantId: "asst-1",
      recommendations: [makeRec()],
      currentConfig: makeAgent(),
    };

    const result = await writeConfig(payload);

    expect(result.success).toBe(false);
    expect(result.error).toBe("Access denied");
  });

  it("returns error when no prompt ID is found for system_prompt update", async () => {
    const mockClient = createMockClient(async (command: unknown) => {
      const name = (command as any).constructor?.name;
      if (name === "GetAIAgentCommand") {
        return {
          aiAgent: {
            aiAgentId: "agent-1",
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: "",
              },
            },
          },
        };
      }
      return {};
    });
    _setQConnectClient(mockClient);

    const payload: WritePayload = {
      agentId: "agent-1",
      assistantId: "asst-1",
      recommendations: [
        makeRec({
          targetField: "system_prompt",
          targetName: "system_prompt",
          currentText: "old",
          suggestedText: "new",
        }),
      ],
      currentConfig: makeAgent(),
    };

    const result = await writeConfig(payload);

    expect(result.success).toBe(false);
    expect(result.error).toContain("no orchestration AI prompt ID");
  });

  it("handles both tool and prompt recommendations in a single call", async () => {
    const mockClient = createMockClient(async (command: unknown) => {
      const name = (command as any).constructor?.name;
      if (name === "GetAIAgentCommand") {
        return {
          aiAgent: {
            aiAgentId: "agent-1",
            visibilityStatus: "PUBLISHED",
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: "prompt-1",
              },
            },
          },
        };
      }
      if (name === "GetAIPromptCommand") {
        return {
          aiPrompt: {
            aiPromptId: "prompt-1",
            visibilityStatus: "PUBLISHED",
            modelId: "anthropic.claude-3",
          },
        };
      }
      if (name === "UpdateAIAgentCommand") {
        return { aiAgent: { aiAgentId: "agent-1-v2" } };
      }
      if (name === "UpdateAIPromptCommand") {
        return { aiPrompt: { aiPromptId: "prompt-1-v2" } };
      }
      return {};
    });
    _setQConnectClient(mockClient);

    const payload: WritePayload = {
      agentId: "agent-1",
      assistantId: "asst-1",
      recommendations: [
        makeRec(),
        makeRec({
          targetField: "system_prompt",
          targetName: "system_prompt",
          currentText: "You are a helpful travel agent.",
          suggestedText: "You are an expert travel agent.",
        }),
      ],
      currentConfig: makeAgent(),
    };

    const result = await writeConfig(payload);

    expect(result.success).toBe(true);
    expect(result.newAgentVersionId).toBe("agent-1-v2");
    expect(result.newPromptVersionId).toBe("prompt-1-v2");
  });
});
