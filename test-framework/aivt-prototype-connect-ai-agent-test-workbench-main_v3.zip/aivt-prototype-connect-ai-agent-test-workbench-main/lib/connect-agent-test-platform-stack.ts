import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { CognitoAuth } from './cognito-auth';
import { StorageConstruct } from './storage-construct';
import { OrchestrationConstruct } from './orchestration-construct';
import { ApiConstruct } from './api-construct';
import { AssistantDiscovery } from './assistant-discovery';
import { ContactCreatorFlow } from './contact-creator-flow';
import { FrontendDeploymentConstruct } from './frontend-deployment-construct';
import { AdminUserBootstrapConstruct } from './admin-bootstrap-construct';
import { ImplementRecommendationsConstruct } from './implement-recommendations-construct';
import { validateCallbackUrls } from './callback-urls';

export interface ConnectAgentTestPlatformStackProps extends cdk.StackProps {
  connectInstanceId: string;
  /**
   * Additional hosted-UI callback/logout URLs to register on the Cognito
   * Web_Client, in addition to the deployed CloudFront URL (which is always
   * registered). May also be supplied via the `callbackUrls` CDK context
   * parameter. Invalid (empty/non-absolute) entries fail the deploy (Req 4.6).
   */
  callbackUrls?: string[];
  /**
   * Optional admin email used to bootstrap the first Cognito Web_Client user at
   * deploy time. May also be supplied via the `adminEmail` CDK context
   * parameter. When absent/empty/whitespace, no bootstrap resource is created
   * and the deploy still succeeds (Reqs 7.1, 7.2).
   */
  adminEmail?: string;
  /**
   * Optional override for the frontend build output directory uploaded by the
   * `FrontendDeploymentConstruct`. Defaults to `src/frontend/dist`. Provided so
   * CDK assertion tests can supply a fixture build dir without relying on a
   * real Vite build. Real deploys MUST leave this unset.
   */
  frontendBuildDir?: string;
  /**
   * Optional explicit name for the RAG evaluation artifacts S3 bucket. May
   * also be supplied via the `ragJobBucketName` CDK context parameter. S3
   * bucket names are globally unique; when omitted, CloudFormation
   * auto-generates a unique name so each deployment is collision-free.
   */
  ragJobBucketName?: string;
}

export class ConnectAgentTestPlatformStack extends cdk.Stack {
  public readonly cognitoAuth: CognitoAuth;
  public readonly storage: StorageConstruct;
  public readonly orchestration: OrchestrationConstruct;
  public readonly api: ApiConstruct;
  public readonly assistantDiscovery: AssistantDiscovery;
  public readonly contactCreatorFlow: ContactCreatorFlow;
  public readonly frontendDeployment: FrontendDeploymentConstruct;
  public readonly adminBootstrap: AdminUserBootstrapConstruct;
  public readonly implementRecommendations: ImplementRecommendationsConstruct;

  constructor(scope: Construct, id: string, props: ConnectAgentTestPlatformStackProps) {
    super(scope, id, props);

    // Resolve additional callback URLs from stack prop or CDK context.
    const contextCallbackUrls = props.callbackUrls
      ?? (this.node.tryGetContext('callbackUrls') as string[] | undefined)
      ?? ['http://localhost:5173'];

    // Resolve the optional admin email from stack prop or CDK context. Left
    // as-is (undefined/empty/whitespace permitted) — the bootstrap construct
    // applies parseAdminEmail to decide skip-vs-create-vs-reject (Reqs 6.6, 7.1).
    const adminEmail = props.adminEmail
      ?? (this.node.tryGetContext('adminEmail') as string | undefined);

    // --- Storage: DynamoDB + S3/CloudFront ---
    // Created first so the CloudFront URL (a synth-time token) is available to
    // compose the Cognito Web_Client callback/logout URLs below. Construct
    // logical IDs are derived from the construct path, not creation order, so
    // this ordering does not change any resource identifier (Req 12.4).
    this.storage = new StorageConstruct(this, 'Storage');

    // The deployed CloudFront URL. This is an unresolved CDK token at synth, so
    // it cannot be parsed/validated as a concrete URL here; it is appended after
    // validating the concrete context URLs to guarantee it is always registered
    // (Reqs 4.1, 4.2). CloudFormation resolves the token within this same stack.
    const cloudFrontUrl = `https://${this.storage.distribution.distributionDomainName}`;

    // Web_Client callback/logout URLs: validate + dedupe the concrete,
    // context-provided URLs (rejecting empty/non-absolute entries, Req 4.6),
    // then always include the CloudFront URL (Reqs 4.1, 4.2, 4.4).
    const webClientUrls = [
      ...validateCallbackUrls(contextCallbackUrls),
      cloudFrontUrl,
    ];

    // --- Cognito Authentication ---
    this.cognitoAuth = new CognitoAuth(this, 'Auth', {
      connectInstanceId: props.connectInstanceId,
      callbackUrls: webClientUrls,
      logoutUrls: webClientUrls,
    });

    // --- Assistant Discovery: Custom resource calls ListIntegrationAssociations at deploy time ---
    // Resolves the assistant actually associated with the Connect instance
    // (IntegrationType WISDOM_ASSISTANT). Fails deployment if none is associated.
    this.assistantDiscovery = new AssistantDiscovery(this, 'AssistantDiscovery', {
      connectInstanceId: props.connectInstanceId,
    });
    const assistantId = this.assistantDiscovery.assistantId;

    // Connect instance ARN for resources scoped to the instance
    const connectInstanceArn = `arn:aws:connect:${this.region}:${this.account}:instance/${props.connectInstanceId}`;

    // --- Contact Creator Flow: minimal flow used to mint synthetic contacts ---
    // so Q in Connect sessions have a bindable ContactARN for ORCHESTRATION tools.
    this.contactCreatorFlow = new ContactCreatorFlow(this, 'ContactCreatorFlow', {
      connectInstanceArn,
    });

    // --- Orchestration: Step Functions + Lambdas ---
    this.orchestration = new OrchestrationConstruct(this, 'Orchestration', {
      connectInstanceId: props.connectInstanceId,
      assistantId,
      table: this.storage.table,
      contactCreatorFlowId: this.contactCreatorFlow.contactFlowId,
      ragJobBucketName: props.ragJobBucketName,
    });

    // --- API Gateway + Lambda Functions ---
    this.api = new ApiConstruct(this, 'Api', {
      userPool: this.cognitoAuth.userPool,
      table: this.storage.table,
      connectInstanceId: props.connectInstanceId,
      assistantId,
      stateMachineArn: this.orchestration.stateMachine.stateMachineArn,
    });

    // --- Instance Mode: production/development flag (Req 19.1) ---
    // Controls whether agent-write operations are permitted. Defaults to
    // "development" when unspecified.
    const instanceMode = (
      this.node.tryGetContext('instanceMode') as string | undefined
    ) ?? 'development';
    if (instanceMode !== 'production' && instanceMode !== 'development') {
      throw new Error(
        `Invalid instanceMode "${instanceMode}". Must be "production" or "development".`
      );
    }

    // --- Implement Recommendations: apply + experiment infrastructure ---
    this.implementRecommendations = new ImplementRecommendationsConstruct(
      this,
      'ImplementRecommendations',
      {
        table: this.storage.table,
        connectInstanceId: props.connectInstanceId,
        assistantId,
        instanceMode: instanceMode as 'production' | 'development',
        existingStateMachineArn: this.orchestration.stateMachine.stateMachineArn,
        api: this.api.api,
        authorizer: this.api.authorizer,
        // Reuse the read-only Results Lambda from ApiConstruct so
        // GET /runs/{runId}/experiments shares the same DynamoDB read
        // grant rather than provisioning a duplicate handler.
        resultsLambda: this.api.resultsLambda,
      },
    );

    // --- Frontend Deployment: upload build + config.json, invalidate CloudFront ---
    // config.json is sourced strictly from the non-secret runtime outputs.
    // cognitoClientId is the Web_Client id (UserPoolClientId) — NEVER the M2M
    // MachineClientId (Reqs 3.3, 13.3).
    // instanceMode is injected so the frontend can hide write actions without
    // an API round-trip (Req 19.8).
    this.frontendDeployment = new FrontendDeploymentConstruct(this, 'FrontendDeployment', {
      frontendBucket: this.storage.frontendBucket,
      distribution: this.storage.distribution,
      runtimeConfig: {
        apiEndpoint: this.api.api.url,
        cognitoUserPoolId: this.cognitoAuth.userPool.userPoolId,
        cognitoClientId: this.cognitoAuth.userPoolClient.userPoolClientId,
        cognitoDomain: this.cognitoAuth.cognitoDomain,
        region: this.region,
        instanceMode,
      },
      buildDir: props.frontendBuildDir,
    });

    // --- Optional First-User Bootstrap ---
    // When adminEmail is absent/empty/whitespace, the construct creates NO
    // resources (Reqs 7.1, 7.2); a non-empty invalid value fails synth (Req 6.6).
    this.adminBootstrap = new AdminUserBootstrapConstruct(this, 'AdminBootstrap', {
      userPool: this.cognitoAuth.userPool,
      adminEmail,
    });

    new cdk.CfnOutput(this, 'ConnectInstanceId', {
      value: props.connectInstanceId,
      description: 'The Connect instance ID used by this platform',
    });

    new cdk.CfnOutput(this, 'AssistantId', {
      value: assistantId,
      description: 'The discovered Q in Connect assistant ID',
    });

    new cdk.CfnOutput(this, 'ContactCreatorFlowId', {
      value: this.contactCreatorFlow.contactFlowId,
      description: 'The dummy contact-creator flow ID used to mint contacts for test runs',
    });
  }
}
