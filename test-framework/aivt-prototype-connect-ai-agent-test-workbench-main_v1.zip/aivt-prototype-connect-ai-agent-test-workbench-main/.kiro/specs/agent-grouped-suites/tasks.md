# Implementation Plan: Agent-Grouped Suites

## Overview

Transform the Test Suites page from a flat table into an agent-grouped layout. The backend `GET /suites` endpoint is enriched with resolved agent names (via Connect Q `ListAIAgents`), and the frontend groups suites under Cloudscape `ExpandableSection` headers per agent. Implementation is in TypeScript across backend Lambda handlers and a React/Cloudscape frontend.

## Tasks

- [x] 1. Add shared type and backend enrichment logic
  - [x] 1.1 Add `EnrichedTestSuite` interface to shared types
    - Add a new interface `EnrichedTestSuite` extending `TestSuite` with an `agentName: string` field in `src/shared/types.ts`
    - This type is response-only and never persisted
    - _Requirements: 1.1, 1.4_

  - [x] 1.2 Implement `buildAgentNameMap` and `enrichWithAgentName` helpers in suites handler
    - Add `buildAgentNameMap(agents: AgentSummary[]): Map<string, string>` that builds a lookup from agentId → agent name
    - Add `enrichWithAgentName(suites: TestSuite[], agentNameMap: Map<string, string>): EnrichedTestSuite[]` that maps each suite to include the resolved name, falling back to agentId when not found
    - Import `listAgents` from `./discovery`
    - _Requirements: 1.1, 1.2, 1.3_

  - [x] 1.3 Update `listSuites` handler to call `listAgents` and return enriched response
    - Modify `listSuites(tenantId)` to call `listAgents()` with graceful error handling (catch → empty map)
    - Combine `buildAgentNameMap` + `enrichWithAgentName` to return `EnrichedTestSuite[]`
    - Log a warning when agent resolution fails
    - _Requirements: 1.1, 1.2, 1.3, 1.4_

  - [x] 1.4 Write property tests for enrichment logic
    - **Property 1: Agent name enrichment correctness** — for any matching agentId, enriched agentName equals the agent's name
    - **Property 2: Agent name fallback to agentId** — for unresolvable agentIds, agentName equals the literal agentId
    - **Validates: Requirements 1.1, 1.2**

- [x] 2. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Implement frontend grouping utility
  - [x] 3.1 Create `groupSuitesByAgent` utility function
    - Create `src/frontend/src/utils/groupSuites.ts`
    - Implement `groupSuitesByAgent(suites: EnrichedTestSuite[]): AgentGroup[]` that groups suites by `agentName`, sorts groups alphabetically, and preserves suite order within groups
    - Export `AgentGroup` interface (`{ agentName: string; suites: EnrichedTestSuite[] }`)
    - _Requirements: 2.1, 2.2, 5.1_

  - [x] 3.2 Write property tests for `groupSuitesByAgent`
    - **Property 4: Grouping produces one section per distinct agentName** — group count equals distinct agentName count
    - **Property 5: Suite count in group header is accurate** — each group's suites length equals input count for that agentName
    - **Property 6: Groups are alphabetically ordered** — output groups are sorted in ascending lexicographic order by agentName
    - **Validates: Requirements 2.1, 2.2, 2.4, 5.1**

- [x] 4. Refactor TestSuites page to agent-grouped layout
  - [x] 4.1 Replace flat table with ExpandableSection-per-agent layout
    - Update `src/frontend/src/pages/TestSuites.tsx` to use `EnrichedTestSuite` type
    - Import and use `groupSuitesByAgent` to compute groups from fetched suites
    - Replace the single `<Table>` with a loop rendering `<ExpandableSection>` per agent group, each containing a per-agent `<Table>`
    - Display header text as `"AgentName (N suites)"` format
    - Remove the "Agent ID" column from the per-agent table (grouping conveys association)
    - Retain columns: Suite Name (link to detail), Description, Last Run, Last Updated
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6_

  - [x] 4.2 Implement expand/collapse state management
    - Add `expandedAgents` state as `Record<string, boolean>` initialized with all agents expanded (`true`)
    - Wire `ExpandableSection` `expanded` and `onChange` props to this state
    - After fetch, auto-expand newly discovered agents while preserving existing collapse states
    - _Requirements: 5.2, 5.3_

  - [x] 4.3 Wire selection and actions within grouped layout
    - Implement single-row selection per table; selecting in one table clears selection in others
    - Connect Run suite, Delete, and Create suite actions with same behavior as before
    - Ensure Refresh re-fetches and re-renders grouped layout
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

  - [x] 4.4 Implement loading, empty, and error states
    - Show loading spinner while fetching
    - Show empty state with "Create suite" CTA when suites list is empty
    - Show error alert with Retry action on fetch failure
    - Show spinner in Last Run column for suites with pending last-run data
    - _Requirements: 4.1, 4.2, 4.3, 4.4_

- [x] 5. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Unit tests for backend and frontend
  - [x] 6.1 Write unit tests for `listSuites` enrichment integration
    - Test that `listSuites` calls `listAgents` and returns enriched response
    - Test graceful fallback when `listAgents` throws (agentName = agentId)
    - Add test in `tests/unit/suites.test.ts`
    - _Requirements: 1.1, 1.2, 1.3_

  - [x] 6.2 Write unit tests for frontend expand/collapse behavior
    - **Property 7: All sections expanded on initial render** — initial expandedAgents maps every agent to true
    - **Property 8: Collapse state preserved across refresh** — collapsed agents remain collapsed after re-fetch
    - Add test in `tests/unit/frontend/` directory
    - _Requirements: 5.2, 5.3_

- [x] 7. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
- The implementation language is TypeScript (matching the existing project)
- `fast-check` is already available as a dev dependency for property-based tests
- Existing test patterns in `tests/properties/` and `tests/unit/` provide templates

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["1.2", "3.1"] },
    { "id": 2, "tasks": ["1.3", "3.2"] },
    { "id": 3, "tasks": ["1.4", "4.1"] },
    { "id": 4, "tasks": ["4.2", "4.3"] },
    { "id": 5, "tasks": ["4.4"] },
    { "id": 6, "tasks": ["6.1", "6.2"] }
  ]
}
```
