import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { computeProgressDisplay } from "@shared/utils/progress-display";
import { formatElapsedTime } from "@shared/utils/time-formatting";

describe("Property Tests: Progress Display Computation", () => {
  // Feature: connect-agent-test-platform, Property 17: Progress Display Computation
  describe("Property 17: Progress Display Computation", () => {
    /**
     * Validates: Requirements 11.1, 11.5
     */

    it("formatted elapsed time matches MM:SS pattern for any non-negative seconds", () => {
      fc.assert(
        fc.property(
          fc.nat(100000),
          fc.nat(100),
          fc.nat(100),
          fc.nat(100),
          fc.nat(1000),
          (elapsedSeconds, passed, failed, errors, totalCases) => {
            const result = computeProgressDisplay({
              passed,
              failed,
              errors,
              totalCases,
              elapsedSeconds,
            });
            expect(result.formattedElapsedTime).toMatch(/^\d{2,}:\d{2}$/);
          }
        ),
        { numRuns: 100 }
      );
    });

    it("formatted elapsed time equals formatElapsedTime(elapsedSeconds)", () => {
      fc.assert(
        fc.property(
          fc.nat(100000),
          fc.nat(50),
          fc.nat(50),
          fc.nat(50),
          fc.nat(200),
          (elapsedSeconds, passed, failed, errors, totalCases) => {
            const result = computeProgressDisplay({
              passed,
              failed,
              errors,
              totalCases,
              elapsedSeconds,
            });
            expect(result.formattedElapsedTime).toBe(
              formatElapsedTime(elapsedSeconds)
            );
          }
        ),
        { numRuns: 100 }
      );
    });

    it("completed always equals passed + failed + errors", () => {
      fc.assert(
        fc.property(
          fc.nat(1000),
          fc.nat(1000),
          fc.nat(1000),
          fc.nat(100000),
          fc.nat(3000),
          (passed, failed, errors, elapsedSeconds, totalCases) => {
            const result = computeProgressDisplay({
              passed,
              failed,
              errors,
              totalCases,
              elapsedSeconds,
            });
            expect(result.completed).toBe(
              result.passed + result.failed + result.errors
            );
          }
        ),
        { numRuns: 100 }
      );
    });

    it("all count fields are non-negative integers", () => {
      fc.assert(
        fc.property(
          fc.nat(500),
          fc.nat(500),
          fc.nat(500),
          fc.nat(2000),
          fc.nat(100000),
          (passed, failed, errors, totalCases, elapsedSeconds) => {
            const result = computeProgressDisplay({
              passed,
              failed,
              errors,
              totalCases,
              elapsedSeconds,
            });
            expect(Number.isInteger(result.completed)).toBe(true);
            expect(Number.isInteger(result.passed)).toBe(true);
            expect(Number.isInteger(result.failed)).toBe(true);
            expect(Number.isInteger(result.errors)).toBe(true);
            expect(Number.isInteger(result.totalCases)).toBe(true);
            expect(result.completed).toBeGreaterThanOrEqual(0);
            expect(result.passed).toBeGreaterThanOrEqual(0);
            expect(result.failed).toBeGreaterThanOrEqual(0);
            expect(result.errors).toBeGreaterThanOrEqual(0);
            expect(result.totalCases).toBeGreaterThanOrEqual(0);
          }
        ),
        { numRuns: 100 }
      );
    });

    it("seconds part of formatted time is always 00–59", () => {
      fc.assert(
        fc.property(
          fc.nat(100000),
          fc.nat(50),
          fc.nat(50),
          fc.nat(50),
          fc.nat(200),
          (elapsedSeconds, passed, failed, errors, totalCases) => {
            const result = computeProgressDisplay({
              passed,
              failed,
              errors,
              totalCases,
              elapsedSeconds,
            });
            const ssPart = parseInt(
              result.formattedElapsedTime.split(":")[1],
              10
            );
            expect(ssPart).toBeGreaterThanOrEqual(0);
            expect(ssPart).toBeLessThanOrEqual(59);
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
