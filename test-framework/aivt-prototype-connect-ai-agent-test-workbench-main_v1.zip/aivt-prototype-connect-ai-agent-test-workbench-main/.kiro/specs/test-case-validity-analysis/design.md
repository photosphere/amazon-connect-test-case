# Design Document: Test Case Validity Analysis

## Overview

This feature extends the Recommendation_Engine to detect and surface **test case defects** — situations where a test case fails not because the agent misbehaved but because the test case's expectations are unreasonable, contradictory, or impossible given the agent's instructions. Today the analysis engine assumes every failure is an agent problem; this feature adds a new classification path that uses the agent's reasoning trace as the primary signal: when the chain-of-thought shows the agent made a sound decision that conflicts with the test's success criteria, the analysis should blame the test, not the agent.

The design adds six coordinated changes across the stack:

1. **Test case definition in the prompt** — The per-case analysis prompt gains a `## Test Case Definition` section (name, persona, initial utterance, success criteria, customer knowledge, goal description) so the LLM can evaluate whether expectations are reasonable. The case record is fetched from DynamoDB at analysis time using `PK=SUITE#{suiteId}, SK=CASE#{caseId}`.

2. **New root cause category** — `test_case_defect` joins the existing eight categories. The prompt instructs the LLM to assign this category when reasoning trace evidence shows the agent deliberately chose not to invoke an expected tool based on its instructions.

3. **New recommendation target** — `test_case` extends the `RecommendationTarget` union (the type currently named `ToolSurface`). A `test_case` recommendation carries an additional `testCaseField` property identifying which field to edit (`successCriteria`, `initialUtterance`, `persona`, `customerKnowledge`, `goalDescription`).

4. **Suite-level partitioning** — The per-suite consolidation prompt partitions failures into "Agent Deficiency" and "Test Case Defect" groups, producing the appropriate recommendation target type for each group.

5. **UI treatment** — The Recommended Changes Panel groups and visually distinguishes agent recommendations (orange "Fix agent" badge) from test case recommendations (blue "Fix test" badge).

6. **Persistence & backward compatibility** — New `test_case` recommendations are stored in the same `recommendations[]` array on existing DDB records. Pre-feature records render unchanged; the UI partitions by `targetField` at render time.

### Design Rationale Summary

- **Why fetch the test case record at analysis time** rather than embedding it in the run snapshot: The snapshot captures agent configuration (system prompt, tools) which changes between runs and must be pinned. Test case definitions are authored by the user and rarely change between runs; the live record is the source of truth. Fetching at analysis time avoids bloating every snapshot with N test case payloads and ensures re-analysis (`force: true`) picks up test case edits the user made after seeing initial results.

- **Why a single extended `RecommendationTarget` type** rather than a parallel interface: Both agent and test case recommendations share the same diff shape (`currentText` → `suggestedText`) and the same rendering component. The `testCaseField` property discriminates sub-target only when needed. Keeping a single type means the per-suite recommendations array, the persistence schema, and the UI partitioning logic all stay unified.

- **Why client-side partitioning** rather than separate DDB keys for agent vs test case recommendations: A single `recommendations[]` array preserves the unified priority ordering across both types (Requirement 6.4). The frontend already partitions by `targetField` using the existing `bucketByTargetField` utility; extending it to handle `test_case` is a one-line change.

- **Why the reasoning trace is the primary signal**: The trace captures the agent's internal decision-making rationale. Without it, distinguishing "agent refused correctly" from "agent failed to act" requires structural heuristics alone (missing tools in config, contradictory persona). The trace provides the definitive evidence that the agent's reasoning was sound, making the `test_case_defect` classification high-confidence.

## Architecture

```mermaid
graph TB
    subgraph Storage["DynamoDB"]
        CaseDef[("PK=SUITE#suiteId<br/>SK=CASE#caseId<br/>(test case definition)")]
        SnapDDB[("PK=RUN#runId<br/>SK=SNAPSHOT")]
        TraceDDB[("PK=RUN#runId#CASE#caseId<br/>SK=TRACE")]
        CaseAnalysis[("PK=RUN#runId<br/>SK=ANALYSIS#CASE#caseId")]
        SuiteAnalysis[("PK=RUN#runId<br/>SK=ANALYSIS#SUITE")]
    end

    subgraph Analysis["Recommendation Engine (extended)"]
        AnaL[Analysis Lambda<br/>analysis.ts<br/>POST /runs/runId/analyze]
        SuiteL[Suite Recommend Lambda<br/>suite-recommend.ts<br/>POST /runs/runId/recommend-suite]
        BR[Bedrock Converse<br/>Sonnet 4.6]
    end

    subgraph Frontend["Frontend (extended)"]
        RCP[RecommendedChangesPanel<br/>badge + section grouping]
        FAV[Failure Analysis View<br/>per-case detail]
        CED[Test Case Editor<br/>deep-link target]
    end

    CaseDef -->|fetch at analysis time| AnaL
    SnapDDB --> AnaL
    TraceDDB --> AnaL
    SnapDDB --> SuiteL
    CaseAnalysis --> SuiteL

    AnaL <--> BR
    SuiteL <--> BR
    AnaL --> CaseAnalysis
    SuiteL --> SuiteAnalysis

    CaseAnalysis --> RCP
    SuiteAnalysis --> RCP
    CaseAnalysis --> FAV
    FAV -.deep link.-> CED
```

### Change Map (extensions only — no new Lambda)

| Module | Change scope |
|---|---|
| `src/shared/types.ts` | Extend `RecommendationTarget` to include `test_case`. Add `TestCaseTargetField` type. Add optional `testCaseField` to `Recommendation`. Add `testCaseDefect` boolean to `PerCaseAnalysis` response. |
| `src/backend/handlers/analysis.ts` | Fetch full test case record. Render `## Test Case Definition` section. Extend prompt with `test_case_defect` category and `test_case` target instructions. Validate `testCaseField` on `test_case` recommendations. |
| `src/backend/handlers/suite-recommend.ts` | Partition failures by `rootCauseCategory`. Render two labeled sections. Accept `test_case` as valid `targetField`. Validate `liftedCaseIds` per partition. |
| `src/backend/orchestration/prompt-registry/prompts/failure-analysis.ts` | Bump to v3 — system prompt updated to reference test case defect detection and reasoning trace comparison. |
| `src/backend/orchestration/prompt-registry/prompts/suite-recommendation.ts` | Bump version — system prompt updated to handle dual-partition prompt structure. |
| `src/shared/utils/recommendation-bucketing.ts` | Extend `bucketByTargetField` to handle `test_case` as a fifth bucket. |
| `src/frontend/src/components/RecommendedChangesPanel.tsx` | Section grouping (Agent / Test Case). Badge colors. |
| `src/frontend/src/pages/FailureAnalysis.tsx` | Render `test_case` recommendations with blue badge + `testCaseField` sub-label. Deep-link to test case editor. |

## Components and Interfaces

### Extended Type Interfaces (`src/shared/types.ts`)

```typescript
/**
 * Extended recommendation target type. Includes the four existing
 * ToolSurface values plus `test_case` for recommendations that target
 * the test case definition rather than the agent's configuration.
 */
export type RecommendationTarget =
  | "tool_description"
  | "tool_instruction"
  | "tool_examples"
  | "system_prompt"
  | "test_case";

/**
 * The editable fields on a test case that a `test_case` recommendation
 * may target. One of these is required when `targetField === "test_case"`.
 */
export type TestCaseTargetField =
  | "successCriteria"
  | "initialUtterance"
  | "persona"
  | "customerKnowledge"
  | "goalDescription";

/**
 * Extended recommendation shape. The `targetField` type widens from
 * `ToolSurface` to `RecommendationTarget`. The optional `testCaseField`
 * is present when `targetField === "test_case"` and absent otherwise.
 */
export interface Recommendation {
  targetField: RecommendationTarget;
  targetName: string;
  currentText: string;
  suggestedText: string;
  rationale: string;
  /**
   * Present when `targetField === "test_case"`. Identifies which field
   * of the test case definition the recommendation edits. Absent (undefined)
   * for agent-targeted recommendations.
   */
  testCaseField?: TestCaseTargetField;
}
```

### Backend: Test Case Definition Fetcher (`analysis.ts` extension)

```typescript
/**
 * Fetch the full test case definition from DynamoDB for prompt inclusion.
 * Key: PK=SUITE#{suiteId}, SK=CASE#{caseId}.
 *
 * Returns the full ToolSequenceTestCase record or null if not found
 * (case deleted between run and analysis).
 */
async function getTestCaseDefinition(
  suiteId: string,
  caseId: string
): Promise<ToolSequenceTestCase | null> {
  const client = getDDBClient();
  const result = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.SUITE}${suiteId}`,
        SK: `${SK_PATTERNS.CASE}${caseId}`,
      },
    })
  );
  if (!result.Item) return null;
  const { PK, SK, ...data } = result.Item as Record<string, unknown>;
  void PK; void SK;
  return data as unknown as ToolSequenceTestCase;
}
```

**Design decision**: The fetch uses a single `GetCommand` per case rather than a batch query for all cases. This is acceptable because the per-case analysis loop already processes cases sequentially (one Bedrock call per case); adding one Get per iteration adds ~5ms latency per case, dwarfed by the ~5s Bedrock call. A batch fetch is a future optimization if analysis becomes parallelized.

### Backend: Test Case Definition Renderer

```typescript
/**
 * Render the ## Test Case Definition section for inclusion in the
 * per-case analysis prompt. Placed immediately after ## Test Case: {caseId}
 * and before ## Conversation Transcript.
 */
function renderTestCaseDefinition(
  testCase: ToolSequenceTestCase | null
): string {
  if (!testCase) {
    return "## Test Case Definition\n(Test case record not found — analysis will proceed without test case context)";
  }

  const lines: string[] = ["## Test Case Definition"];
  lines.push(`Name: ${testCase.name}`);
  lines.push(`Description: ${testCase.description}`);
  lines.push(`Persona: ${testCase.persona}`);
  lines.push(`Style: ${testCase.style}`);
  lines.push(`Initial Utterance: ${testCase.initialUtterance}`);
  lines.push(
    `Goal: ${testCase.goalDescription?.trim() || "(not specified)"}`
  );

  // Customer Knowledge
  const entries = Object.entries(testCase.customerKnowledge ?? {});
  if (entries.length === 0) {
    lines.push("Customer Knowledge: (none)");
  } else {
    lines.push("Customer Knowledge:");
    for (const [key, value] of entries) {
      lines.push(`  - ${key}: ${value}`);
    }
  }

  // Success Criteria
  lines.push("Success Criteria:");
  const criteria = testCase.successCriteria ?? [];
  criteria.forEach((step, idx) => {
    lines.push(
      `  ${idx + 1}. ${step.toolName} (required: ${step.required})`
    );
    if (step.parameterChecks && step.parameterChecks.length > 0) {
      for (const pc of step.parameterChecks) {
        lines.push(`    - ${pc.paramName} = ${pc.expectedValue}`);
      }
    }
  });

  return lines.join("\n");
}
```

### Backend: Extended `buildAnalysisPrompt` (prompt placement)

The `## Test Case Definition` section is inserted immediately after the `## Test Case: {caseId}` header and before `## Conversation Transcript`:

```typescript
export function buildAnalysisPrompt(params: {
  caseId: string;
  testCaseDefinition: ToolSequenceTestCase | null;  // NEW
  transcript: TranscriptTurn[];
  reasoningTrace: ExecutionTrace | null;
  expectedTools: string[];
  actualTools: string[];
  agentTools: ToolDefinition[];
  systemPrompt: string;
}): string {
  const { caseId, testCaseDefinition, /* ... */ } = params;

  let userMessage = `Analyze the following failed test case and determine the root cause.

## Test Case: ${caseId}

${renderTestCaseDefinition(testCaseDefinition)}

## Conversation Transcript
${formatTranscript(transcript)}
...`;
  // (remainder of prompt follows existing structure)
}
```

### Backend: Per-Case Prompt Extension (root cause + recommendations)

The instructions block is extended with:

1. `test_case_defect` added to the root cause enumeration
2. `test_case` added to valid `targetField` values
3. `testCaseField` property documented in the response schema
4. Sound Decision Signal detection instructions
5. Constraint: at most one `test_case` recommendation per case

```
## Instructions
...
Analyze why this test case failed. Determine:
1. The root cause category (choose ONE from: overlapping_tool_descriptions,
   missing_disambiguation, incorrect_tool_prioritization,
   incomplete_tool_description, system_prompt_gap, missing_tool_instruction,
   parameter_mismatch, test_case_defect, other)

   - test_case_defect: The agent's reasoning trace shows it made a correct
     decision based on its instructions, but the test case expected different
     behavior. The test case's expectations are unreasonable, contradictory,
     or impossible. Prefer this over "other" when the reasoning trace provides
     clear evidence that the agent deliberately chose not to invoke an expected
     tool because its instructions prohibit that action without a prerequisite
     the test did not arrange.

   - When the reasoning trace is unavailable, test_case_defect MAY still be
     assigned if the test case definition alone provides sufficient evidence
     (e.g., success criteria requiring a tool not in the agent's configuration,
     persona contradicting expected behavior), but note reduced confidence in
     the explanation.

   - When uncertain, default to an agent-deficiency category rather than
     test_case_defect.

2. A plain-language explanation...

3. Between 1 and 5 actionable recommendations...

The five valid `targetField` values are `tool_description`, `tool_instruction`,
`tool_examples`, `system_prompt`, and `test_case`.

For `test_case` recommendations:
- Set `targetName` to the caseId of the test case.
- Include a `testCaseField` property with one of: `successCriteria`,
  `initialUtterance`, `persona`, `customerKnowledge`, `goalDescription`.
  - successCriteria: when the expected tool sequence is wrong or too strict
  - initialUtterance: when the opening message doesn't align with the expected path
  - persona: when the persona makes the expected behavior impossible
  - customerKnowledge: when missing/wrong context prevents the expected tool invocations
  - goalDescription: when the goal statement contradicts the success criteria
- `test_case` recommendations are ONLY valid when rootCauseCategory is
  `test_case_defect`.
- Produce at most ONE `test_case` recommendation per case (the single most
  impactful edit).

## Sound Decision Signal Detection

Compare the agent's reasoning trace against the test case's success criteria.
Look for these patterns:
  (a) Agent cites its instructions as the reason for not invoking a tool
  (b) Agent cites safety or compliance guardrails
  (c) Agent cites missing prerequisite information that the persona/session
      data did not provide
  (d) Agent cites ambiguity requiring clarification before acting

When the reasoning trace contains a Sound Decision Signal that directly
conflicts with a `required: true` tool in the success criteria, classify as
`test_case_defect` UNLESS there is stronger evidence that the agent's
reasoning was itself flawed (e.g., hallucinated a constraint not in its
system prompt).

Include a direct quote from the reasoning trace in the explanation to let
the reviewer verify the classification.

When the success criteria contain a tool name that does not appear in the
agent's tool configuration, flag this as a strong `test_case_defect` signal.

Respond in the following JSON format ONLY (no markdown code fences):
{
  "rootCauseCategory": "category_name",
  "explanation": "...",
  "recommendations": [
    {
      "targetField": "...",
      "targetName": "...",
      "currentText": "...",
      "suggestedText": "...",
      "rationale": "...",
      "testCaseField": "successCriteria|initialUtterance|persona|customerKnowledge|goalDescription"
    }
  ]
}
```

### Backend: Per-Case Validation Extension

```typescript
/**
 * Extended set of valid targetField values (adds "test_case").
 */
const VALID_TARGET_FIELDS: ReadonlySet<RecommendationTarget> = new Set([
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
  "test_case",
]);

const VALID_TEST_CASE_FIELDS: ReadonlySet<TestCaseTargetField> = new Set([
  "successCriteria",
  "initialUtterance",
  "persona",
  "customerKnowledge",
  "goalDescription",
]);

/**
 * Extended sanitizeRecommendations — validates test_case recommendations
 * carry a valid testCaseField, and that test_case recommendations only
 * appear when rootCauseCategory is test_case_defect.
 */
function sanitizeRecommendations(
  caseId: string,
  recommendations: Recommendation[],
  rootCauseCategory: string,
): Recommendation[] {
  return recommendations.filter((rec, idx) => {
    // Existing validation: invalid targetField
    if (!VALID_TARGET_FIELDS.has(rec.targetField)) {
      console.warn(`[analysis] dropping rec ${idx} for case ${caseId}: invalid targetField=${rec.targetField}`);
      return false;
    }
    // Existing validation: empty targetName
    if (!rec.targetName || rec.targetName.trim().length === 0) {
      console.warn(`[analysis] dropping rec ${idx} for case ${caseId}: empty targetName`);
      return false;
    }
    // Existing validation: no-op (both empty)
    if (rec.currentText.length === 0 && rec.suggestedText.length === 0) {
      console.warn(`[analysis] dropping rec ${idx} for case ${caseId}: no-op`);
      return false;
    }
    // NEW: test_case recommendations require valid testCaseField
    if (rec.targetField === "test_case") {
      if (!rec.testCaseField || !VALID_TEST_CASE_FIELDS.has(rec.testCaseField)) {
        console.warn(`[analysis] dropping rec ${idx} for case ${caseId}: test_case missing/invalid testCaseField`);
        return false;
      }
      // test_case only valid with test_case_defect root cause
      if (rootCauseCategory !== "test_case_defect") {
        console.warn(`[analysis] dropping rec ${idx} for case ${caseId}: test_case rec with non-defect root cause`);
        return false;
      }
    }
    // Non-test_case recommendations must NOT have testCaseField
    if (rec.targetField !== "test_case" && rec.testCaseField) {
      // Strip the field silently — it's a model hallucination
      rec.testCaseField = undefined;
    }
    return true;
  });
}
```

### Backend: Suite Consolidation Partitioning (`suite-recommend.ts`)

The `buildUserMessage` function is extended to partition failures:

```typescript
export function buildUserMessage(params: {
  failedCaseIds: string[];
  snapshot: AgentSnapshot;
  failedResults: TestCaseResult[];
  perCaseAnalyses: Map<string, PersistedCaseAnalysis>;
}): string {
  const { failedCaseIds, snapshot, failedResults, perCaseAnalyses } = params;

  // Partition by root cause category
  const testCaseDefectIds: string[] = [];
  const agentDeficiencyIds: string[] = [];
  for (const caseId of failedCaseIds) {
    const analysis = perCaseAnalyses.get(caseId);
    if (analysis?.rootCauseCategory === "test_case_defect") {
      testCaseDefectIds.push(caseId);
    } else {
      agentDeficiencyIds.push(caseId);
    }
  }

  // ... Run Summary and Agent Configuration sections unchanged ...

  // Per-Case Failures — now split into two labeled sections
  let perCaseSection = "";

  if (agentDeficiencyIds.length > 0) {
    perCaseSection += "## Agent Deficiency Failures\n";
    perCaseSection += renderFailureBlocks(agentDeficiencyIds, failedResults, perCaseAnalyses);
    perCaseSection += "\n";
  }

  if (testCaseDefectIds.length > 0) {
    perCaseSection += "## Test Case Defect Failures\n";
    perCaseSection += renderFailureBlocks(testCaseDefectIds, failedResults, perCaseAnalyses);
    perCaseSection += "\n";
  }

  // Instructions — extended to reference both target types
  const instructions = `## Instructions
Produce a JSON object matching this schema:
{
  "recommendations": [
    {
      "targetField": "tool_description" | "tool_instruction" | "tool_examples" | "system_prompt" | "test_case",
      "targetName": "<tool name, 'system_prompt', or case_id>",
      "currentText": "...",
      "suggestedText": "...",
      "rationale": "...",
      "priority": <positive integer>,
      "testCaseField": "<only when targetField is test_case: successCriteria|initialUtterance|persona|customerKnowledge|goalDescription>",
      "predictedImpact": {
        "liftedCaseIds": ["<case_id>", ...],
        "rationale": "..."
      }
    }
  ]
}

Constraints:
- Agent-targeted recommendations (tool_description, tool_instruction, tool_examples, system_prompt) should address cases from the "Agent Deficiency Failures" section only. Their liftedCaseIds MUST only reference case IDs from that section.
- Test-case-targeted recommendations (test_case) should address cases from the "Test Case Defect Failures" section only. Their liftedCaseIds MUST only reference case IDs from that section.
- Maintain a unified priority ordering across both recommendation types — relative impact determines priority regardless of target type.
- Return ONLY recommendations you judge actionable. Returning an empty array is valid.
- Order the array such that index 0 is the highest-leverage change.
- Output ONLY the JSON object. No markdown fences, no preamble, no commentary.`;

  return [runSummary, "", agentConfig, "", systemPromptSection, "", perCaseSection, instructions].join("\n");
}
```

### Backend: Suite Recommendation Validation Extension

```typescript
/**
 * Extended filter: validates test_case recommendations have liftedCaseIds
 * only from the test_case_defect partition, and agent recommendations
 * only from the agent deficiency partition.
 */
export function filterAndNormalizeSuiteRecommendations(
  candidates: PerSuiteRecommendation[],
  failedCaseIds: ReadonlySet<string>,
  testCaseDefectCaseIds: ReadonlySet<string>,  // NEW
): PerSuiteRecommendation[] {
  // ... existing validation ...
  // NEW: for test_case recs, liftedCaseIds must be subset of testCaseDefectCaseIds
  // For agent recs, liftedCaseIds must be subset of (failedCaseIds - testCaseDefectCaseIds)
}
```

### Frontend: Recommendation Partitioning Utility Extension

```typescript
// src/shared/utils/recommendation-bucketing.ts (extended)

export type RecommendationBucket =
  | "tool_description"
  | "tool_instruction"
  | "tool_examples"
  | "system_prompt"
  | "test_case";

/**
 * Partition recommendations into agent-targeted and test-case-targeted groups.
 * Every input record appears in exactly one output group; the union equals
 * the input (Property 11.1).
 */
export function partitionByTargetType<T extends { targetField: string }>(
  recommendations: T[]
): { agent: T[]; testCase: T[] } {
  const agent: T[] = [];
  const testCase: T[] = [];
  for (const rec of recommendations) {
    if (rec.targetField === "test_case") {
      testCase.push(rec);
    } else {
      agent.push(rec);
    }
  }
  return { agent, testCase };
}
```

### Frontend: RecommendedChangesPanel Badge Rendering

```typescript
// Badge component for recommendation type
function RecommendationBadge({ targetField }: { targetField: string }) {
  if (targetField === "test_case") {
    return (
      <Badge color="blue">Fix test</Badge>
    );
  }
  return (
    <Badge color="severity-medium">Fix agent</Badge>  // orange
  );
}
```

The panel renders two sections when both types are present:
1. **Agent recommendations** — light orange background tint, rendered first
2. **Test case recommendations** — light blue background tint, rendered second

When only one type exists, only that section is rendered without the other's header.

### Frontend: Per-Case Detail Sub-Label

For `test_case` recommendations on the per-case page:

```
Fix test · successCriteria
```

Rendered as: `<Badge color="blue">Fix test</Badge> <span>· {testCaseField}</span>`

The recommendation card includes a "Edit test case" link that navigates to the test case editor with the target field pre-selected.

## Data Models

### Extended `Recommendation` (persisted shape)

```typescript
{
  targetField: "test_case",                    // NEW value
  targetName: "case-abc-123",                  // the caseId
  currentText: "1. verifyIdentity (required: true)\n2. processPayment (required: true)",
  suggestedText: "1. verifyIdentity (required: true)\n2. confirmPayment (required: true)\n3. processPayment (required: true)",
  rationale: "The agent correctly refuses to process payment without confirmation...",
  testCaseField: "successCriteria"             // NEW optional field
}
```

### Extended `PerCaseAnalysis` (persisted at `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}`)

```typescript
{
  PK: `RUN#${runId}`,
  SK: `ANALYSIS#CASE#${caseId}`,
  caseId: string,
  rootCauseCategory: string,         // now includes "test_case_defect"
  explanation: string,
  traceAvailable: boolean,
  recommendations: Recommendation[], // may include test_case recs
  generatedAt: string,
  modelId: string,
  failureAnalysisPromptVersion?: number,
  // NEW: convenience boolean for UI consumers
  testCaseDefect: boolean,           // true when rootCauseCategory === "test_case_defect"
}
```

The `testCaseDefect` boolean is derived at write time from `rootCauseCategory === "test_case_defect"` so that UI consumers can switch rendering without string comparison.

### Extended `PerSuiteRecommendation` (persisted at `PK=RUN#{runId}, SK=ANALYSIS#SUITE`)

Same shape as before but `targetField` can now be `"test_case"` and `testCaseField` is present on those entries. The unified priority ordering is maintained across both recommendation types.

### Backward Compatibility

| Record type | Pre-feature state | Post-feature read behavior |
|---|---|---|
| `ANALYSIS#CASE#` without `testCaseField` | All recs are agent-targeted | UI treats missing `testCaseField` as agent-targeted; renders orange badge |
| `ANALYSIS#CASE#` without `testCaseDefect` | Not present | UI treats absent field as `false` |
| `ANALYSIS#SUITE` without `test_case` recs | All recs are agent-targeted | No change in rendering |
| `rootCauseCategory` not `test_case_defect` | Eight existing categories | Renders as before; no test case section |



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Test case definition renderer completeness

*For any* valid `ToolSequenceTestCase` with a non-empty `name`, `description`, `persona`, `initialUtterance`, and at least one entry in `successCriteria`, the rendered `## Test Case Definition` string SHALL contain: the literal `"## Test Case Definition"`, the test case's `name`, `description`, `persona`, `style`, `initialUtterance`, every `toolName` from `successCriteria`, and either each key-value pair from `customerKnowledge` or the literal `"(none)"` when the map is empty. When `goalDescription` is absent or whitespace-only, the output SHALL contain `"Goal: (not specified)"`.

**Validates: Requirements 1.1, 1.3, 1.4, 1.5, 11.5**

### Property 2: Prompt section ordering

*For any* inputs to `buildAnalysisPrompt` that include a non-null test case definition, the rendered user message SHALL contain `"## Test Case Definition"` at a character index strictly greater than the index of `"## Test Case:"` and strictly less than the index of `"## Conversation Transcript"`.

**Validates: Requirements 1.2**

### Property 3: Test case recommendation validation invariant

*For any* array of `Recommendation` records and any `rootCauseCategory` string, after `sanitizeRecommendations` processing: (a) every surviving recommendation with `targetField === "test_case"` has a `testCaseField` value that is one of the five valid `TestCaseTargetField` values (`successCriteria`, `initialUtterance`, `persona`, `customerKnowledge`, `goalDescription`), and (b) no surviving recommendation with `targetField === "test_case"` exists when `rootCauseCategory` is not `"test_case_defect"`.

**Validates: Requirements 3.3, 3.4, 11.3**

### Property 4: Recommendation partitioning invariant

*For any* array of `Recommendation` records (with `targetField` values drawn from the five valid `RecommendationTarget` values), the `partitionByTargetType` function SHALL produce two arrays (`agent` and `testCase`) such that: (a) every input record appears in exactly one output array, (b) the concatenation of both output arrays (in any order) is a permutation of the input, and (c) every record in `testCase` has `targetField === "test_case"` and every record in `agent` has `targetField` in the four `ToolSurface` values.

**Validates: Requirements 8.1, 8.2, 11.1**

### Property 5: Per-case analysis persistence round-trip

*For any* valid `PerCaseAnalysis` record whose `recommendations` array contains `test_case` entries with valid `testCaseField` values, writing the record to DynamoDB and reading it back SHALL produce a record whose `test_case` recommendations carry identical `targetField`, `targetName`, `testCaseField`, `currentText`, `suggestedText`, and `rationale` values.

**Validates: Requirements 10.1, 10.2, 10.3**

### Property 6: Suite failure partition correctness

*For any* set of `PersistedCaseAnalysis` records with various `rootCauseCategory` values, the suite prompt partition function SHALL place every record with `rootCauseCategory === "test_case_defect"` in the test-case-defect group and every other record in the agent-deficiency group, where the union of both groups equals the input and the intersection is empty.

**Validates: Requirements 6.1**

### Property 7: Suite liftedCaseIds partition subset

*For any* persisted per-suite analysis, every `PerSuiteRecommendation` with `targetField === "test_case"` SHALL have `predictedImpact.liftedCaseIds` entries that are a subset of the case IDs classified as `test_case_defect` in the per-case analyses for that run. Conversely, every agent-targeted recommendation SHALL have `liftedCaseIds` entries that are a subset of the non-`test_case_defect` case IDs.

**Validates: Requirements 6.3, 11.4**

### Property 8: Suite priority ordering across mixed recommendation types

*For any* array of `PerSuiteRecommendation` records (containing both agent-targeted and test-case-targeted entries) after server-side sorting and renumbering, the `priority` values SHALL be monotonically non-decreasing with array index: `recommendations[i].priority <= recommendations[j].priority` for all `i < j`, regardless of `targetField`.

**Validates: Requirements 6.4**

### Property 9: Valid test_case_defect analysis preserves test_case recommendations

*For any* `PerCaseAnalysis` where `rootCauseCategory === "test_case_defect"` and the `recommendations` array contains at least one well-formed `test_case` recommendation (valid `testCaseField`, non-empty `targetName`, non-empty `currentText` or `suggestedText`), the `sanitizeRecommendations` function SHALL preserve at least one `test_case` recommendation in the output.

**Validates: Requirements 11.2**

### Property 10: successCriteria currentText is non-empty

*For any* `Recommendation` with `targetField === "test_case"` and `testCaseField === "successCriteria"` that survives validation, the `currentText` field SHALL be a non-empty string (since every test case has at least one success criterion tool step, the formatted criteria is never empty).

**Validates: Requirements 11.6**

## Error Handling

| Scenario | Handling |
|----------|----------|
| Test case record not found (deleted between run and analysis) | Render `"(Test case record not found — analysis will proceed without test case context)"` in the prompt; analysis continues without test case context |
| Test case record is a RAG case (type !== "tool_sequence") | Skip test case definition rendering; analysis proceeds as before (RAG cases have no successCriteria) |
| `testCaseField` absent on a `test_case` recommendation from Bedrock | Drop the recommendation before persistence; log the malformed entry |
| `testCaseField` has invalid value (not one of five valid values) | Drop the recommendation before persistence; log |
| `test_case` recommendation with non-`test_case_defect` root cause | Drop the recommendation before persistence; log |
| `test_case` recommendation with empty `targetName` | Drop the recommendation (existing no-op/empty-name rule) |
| Suite liftedCaseIds references agent-deficiency cases on a `test_case` rec | Drop the offending case ID from liftedCaseIds (not the whole rec) |
| Suite liftedCaseIds references test-case-defect cases on an agent rec | Drop the offending case ID from liftedCaseIds (not the whole rec) |
| `suiteId` not provided in request body | Skip test case definition fetch; render `"## Test Case Definition\n(Suite context unavailable — analysis will proceed without test case context)"` |
| DynamoDB GetCommand for test case fails (transient error) | Log error; render fallback message; analysis continues |
| Pre-feature `ANALYSIS#CASE#` records read (no `testCaseDefect` field) | Treat as `testCaseDefect: false`; render with orange badge |
| Pre-feature `ANALYSIS#SUITE` records read (no `test_case` recs) | Render as agent-only; no test case section shown |

## Testing Strategy

### Property-Based Tests (fast-check, minimum 100 iterations each)

The feature's pure logic layer — test case definition rendering, recommendation validation, partitioning, and persistence round-trip — is well-suited to property-based testing. Each property above maps to a single `fast-check` test tagged with the property number.

**Library**: `fast-check` (already available in the project's test dependencies)

**Tag format**: `Feature: test-case-validity-analysis, Property {N}: {title}`

**Test locations**:
- `tests/unit/properties/test-case-definition-renderer.test.ts` — Properties 1, 2
- `tests/unit/properties/test-case-recommendation-validation.test.ts` — Properties 3, 9, 10
- `tests/unit/properties/recommendation-partitioning.test.ts` — Property 4
- `tests/unit/properties/test-case-persistence-roundtrip.test.ts` — Property 5
- `tests/unit/properties/suite-partition-and-ordering.test.ts` — Properties 6, 7, 8

### Unit Tests (example-based)

| Area | Test file | Coverage |
|------|-----------|----------|
| Renderer edge cases | `tests/unit/test-case-definition-renderer.test.ts` | Null test case, empty customerKnowledge, missing goalDescription, RAG case skip |
| Validation edge cases | `tests/unit/analysis-validation.test.ts` | test_case rec with wrong root cause dropped, testCaseField stripped from agent recs |
| Prompt content | `tests/unit/analysis-prompt-content.test.ts` | test_case_defect in enumeration, Sound Decision Signal text present, five testCaseField values in instructions |
| Suite partitioning | `tests/unit/suite-recommend-partition.test.ts` | All-defect run, no-defect run, mixed run |
| UI badges | `tests/unit/components/RecommendedChangesPanel.test.tsx` | Blue badge for test_case, orange badge for agent, section grouping, single-type rendering |
| Backward compat | `tests/unit/backward-compat.test.ts` | Pre-feature records render without errors, missing testCaseField treated as agent |
| Per-case detail | `tests/unit/components/FailureAnalysis.test.tsx` | testCaseField sub-label, deep-link to editor |

### Integration Tests

| Area | Coverage |
|------|----------|
| End-to-end analysis with test case fetch | Mock DDB with test case record, verify prompt includes definition |
| Suite consolidation with mixed partitions | Mock per-case analyses, verify prompt has two sections |
| Force re-analyze reclassification | Verify force:true with new prompt can reclassify `other` → `test_case_defect` |
| Backward compat read | Read pre-feature persisted records, verify no errors |

### Dual Testing Balance

- **Unit tests** focus on: edge cases (null test case, RAG cases), specific badge rendering, prompt content assertions, backward compatibility paths.
- **Property tests** focus on: universal invariants (partition completeness, validation rules, ordering, round-trip) that hold across all valid inputs. Property tests catch the subtle bugs that example-based tests miss — e.g., a partitioning function that works for the tested examples but fails on an unusual targetField value.
