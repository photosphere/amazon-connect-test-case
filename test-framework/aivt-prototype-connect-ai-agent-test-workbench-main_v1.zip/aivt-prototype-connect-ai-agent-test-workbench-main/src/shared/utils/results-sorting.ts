/**
 * Results sorting utility for the test results display.
 *
 * Sorts test case results by status priority (error > failed > passed),
 * then alphabetically by test case name (case-insensitive).
 *
 * @module results-sorting
 */

import { CaseStatus } from "../enums";

/**
 * Priority order for result statuses.
 * Lower number = higher priority (appears first).
 */
const STATUS_PRIORITY: Record<CaseStatus, number> = {
  [CaseStatus.ERROR]: 0,
  [CaseStatus.TIMED_OUT]: 1,
  [CaseStatus.FAILED]: 2,
  [CaseStatus.PENDING_EVALUATION]: 3,
  [CaseStatus.PASSED]: 4,
};

/** Minimum shape required for sorting — a result with status and name. */
export interface SortableResult {
  status: CaseStatus;
  name: string;
}

/**
 * Sorts test case results by status priority, then alphabetically by name.
 *
 * Status ordering: error first, then timed_out, then failed, then passed.
 * Within the same status group, results are sorted alphabetically by name
 * (case-insensitive).
 *
 * Returns a new array — does not mutate the input.
 *
 * @param results - Array of sortable results (must have status and name)
 * @returns A new sorted array
 *
 * @example
 * sortResults([
 *   { status: CaseStatus.PASSED, name: "Bravo" },
 *   { status: CaseStatus.ERROR, name: "Alpha" },
 *   { status: CaseStatus.FAILED, name: "Charlie" },
 * ])
 * // Returns: [Error-Alpha, Failed-Charlie, Passed-Bravo]
 */
export function sortResults<T extends SortableResult>(results: T[]): T[] {
  if (!results || results.length === 0) {
    return [];
  }

  return [...results].sort((a, b) => {
    const priorityA = STATUS_PRIORITY[a.status] ?? 4;
    const priorityB = STATUS_PRIORITY[b.status] ?? 4;

    if (priorityA !== priorityB) {
      return priorityA - priorityB;
    }

    return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
  });
}
