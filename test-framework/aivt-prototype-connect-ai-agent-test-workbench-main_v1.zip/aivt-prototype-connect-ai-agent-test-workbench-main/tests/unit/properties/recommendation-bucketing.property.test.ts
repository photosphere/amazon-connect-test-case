// Feature: actionable-recommendations, Property 1: Bucketing partitions
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import { bucketByTargetField } from "@shared/utils/recommendation-bucketing";
import type { Recommendation, ToolSurface } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** The four valid Tool_Surface values (R5.1, R13.2). */
const toolSurfaceArb: fc.Arbitrary<ToolSurface> = fc.constantFrom<ToolSurface>(
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
);

/**
 * Arbitrary {@link Recommendation}. The `targetField` is drawn uniformly
 * from the four valid surfaces; every other field is an unconstrained
 * string. The bucketing function does not inspect anything beyond
 * `targetField`, but generating realistic-looking records keeps the
 * property test grounded in the actual on-the-wire shape.
 */
const recommendationArb: fc.Arbitrary<Recommendation> = fc.record({
  targetField: toolSurfaceArb,
  targetName: fc.string({ minLength: 0, maxLength: 40 }),
  currentText: fc.string({ minLength: 0, maxLength: 80 }),
  suggestedText: fc.string({ minLength: 0, maxLength: 80 }),
  rationale: fc.string({ minLength: 0, maxLength: 80 }),
});

/** Arrays of length 0..50 per the task spec. */
const recommendationsArrayArb: fc.Arbitrary<Recommendation[]> = fc.array(
  recommendationArb,
  { minLength: 0, maxLength: 50 },
);

// ---------------------------------------------------------------------------
// Property 1: Bucketing partitions
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 15.1**
 *
 * Property 1: Bucketing partitions
 *
 * For any array of `Recommendation` records with valid `targetField`
 * values, `bucketByTargetField` partitions the records into exactly four
 * groups keyed by Tool_Surface, where:
 *   - each record appears in exactly one group corresponding to its
 *     `targetField`,
 *   - the union of the four groups equals the input multiset (no record
 *     is added, dropped, or duplicated),
 *   - and the order within each bucket matches the input filter order
 *     (stable partition).
 */
describe("Feature: actionable-recommendations, Property 1: Bucketing partitions", () => {
  it("each record lands in the bucket keyed by its targetField (and nowhere else)", () => {
    fc.assert(
      fc.property(recommendationsArrayArb, (xs) => {
        const buckets = bucketByTargetField(xs);

        for (const surface of [
          "tool_description",
          "tool_instruction",
          "tool_examples",
          "system_prompt",
        ] as const) {
          for (const rec of buckets[surface]) {
            expect(rec.targetField).toBe(surface);
          }
        }
      }),
      { numRuns: 100 },
    );
  });

  it("the four output arrays' concatenation is a permutation of the input multiset", () => {
    fc.assert(
      fc.property(recommendationsArrayArb, (xs) => {
        const buckets = bucketByTargetField(xs);
        const concat = [
          ...buckets.tool_description,
          ...buckets.tool_instruction,
          ...buckets.tool_examples,
          ...buckets.system_prompt,
        ];

        // Same cardinality.
        expect(concat).toHaveLength(xs.length);

        // Same multiset: every input record (by reference) is in the
        // concatenated output exactly once.
        const remaining = [...concat];
        for (const rec of xs) {
          const idx = remaining.indexOf(rec);
          expect(idx).toBeGreaterThanOrEqual(0);
          remaining.splice(idx, 1);
        }
        expect(remaining).toHaveLength(0);
      }),
      { numRuns: 100 },
    );
  });

  it("order within each bucket matches the input's filtered subsequence (stable partition)", () => {
    fc.assert(
      fc.property(recommendationsArrayArb, (xs) => {
        const buckets = bucketByTargetField(xs);

        for (const surface of [
          "tool_description",
          "tool_instruction",
          "tool_examples",
          "system_prompt",
        ] as const) {
          const expected = xs.filter((r) => r.targetField === surface);
          expect(buckets[surface]).toEqual(expected);
        }
      }),
      { numRuns: 100 },
    );
  });

  it("the bucket sizes sum to the input length and are correct per surface", () => {
    fc.assert(
      fc.property(recommendationsArrayArb, (xs) => {
        const buckets = bucketByTargetField(xs);

        const counts: Record<ToolSurface, number> = {
          tool_description: 0,
          tool_instruction: 0,
          tool_examples: 0,
          system_prompt: 0,
        };
        for (const rec of xs) counts[rec.targetField as ToolSurface]++;

        expect(buckets.tool_description).toHaveLength(counts.tool_description);
        expect(buckets.tool_instruction).toHaveLength(counts.tool_instruction);
        expect(buckets.tool_examples).toHaveLength(counts.tool_examples);
        expect(buckets.system_prompt).toHaveLength(counts.system_prompt);

        const total =
          buckets.tool_description.length +
          buckets.tool_instruction.length +
          buckets.tool_examples.length +
          buckets.system_prompt.length;
        expect(total).toBe(xs.length);
      }),
      { numRuns: 100 },
    );
  });

  it("returns four buckets even when the input is empty (no missing keys)", () => {
    // Sanity-check the boundary case from inside the property runner so
    // empty-array shrinks land here and not in the larger properties above.
    fc.assert(
      fc.property(fc.constant<Recommendation[]>([]), (xs) => {
        const buckets = bucketByTargetField(xs);
        expect(Object.keys(buckets).sort()).toEqual([
          "system_prompt",
          "tool_description",
          "tool_examples",
          "tool_instruction",
        ]);
        expect(buckets.tool_description).toEqual([]);
        expect(buckets.tool_instruction).toEqual([]);
        expect(buckets.tool_examples).toEqual([]);
        expect(buckets.system_prompt).toEqual([]);
      }),
      { numRuns: 1 },
    );
  });
});
