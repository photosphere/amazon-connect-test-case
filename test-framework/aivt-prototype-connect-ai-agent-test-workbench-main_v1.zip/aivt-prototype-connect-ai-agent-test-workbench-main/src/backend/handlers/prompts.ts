/**
 * Prompts Lambda — API Gateway handler for the Prompt Management feature.
 *
 * Routes (every route uses Cognito + `test-platform/run` scope wired on the
 * API Gateway side; this handler simply assumes a valid principal in
 * `event.requestContext.authorizer.claims`):
 *
 *   - `GET    /prompts`                          → {@link handleListPrompts}
 *   - `GET    /prompts/{promptKey}`              → {@link handleGetPrompt}
 *   - `PUT    /prompts/{promptKey}`              → {@link handleUpdatePrompt}
 *   - `POST   /prompts/{promptKey}/reset`        → {@link handleResetPrompt}
 *   - `GET    /prompts/{promptKey}/history`      → {@link handleGetHistory}
 *   - `GET    /prompts/active-runs`              → {@link handleActiveRuns}
 *
 * The dispatcher mirrors `src/backend/handlers/audit.ts` byte-for-byte: a
 * single `handler` entrypoint matches `(httpMethod, resource)` and delegates
 * to a per-route handler. The route shape strings come straight from the
 * design's API contract section.
 *
 * Data path summary:
 *
 *   - **List / Get / History**: read the live override store via
 *     {@link DynamoDBService.listPromptOverrides} /
 *     {@link DynamoDBService.getPromptOverride} /
 *     {@link DynamoDBService.listPromptHistory}, layer the
 *     {@link PROMPT_REGISTRY} bundled defaults, and shape the response
 *     per the design's API contract.
 *
 *   - **Update**: run the strict-ordered validation pipeline
 *     (`validatePromptKeyExists` → `validateTextSize` →
 *     `validatePlaceholdersPresent` → `validatePlaceholderOccurrenceCap`
 *     → `validateNoUnknownPlaceholders` → `validateModelMembership` →
 *     `validateCapabilityProfileCompliance` → `validateNumericBounds` →
 *     `validateDryRender`); on success, issue
 *     {@link DynamoDBService.putPromptOverride} with optimistic
 *     concurrency, then write a best-effort `prompt_edit` audit record
 *     and trigger best-effort history eviction (R7.2).
 *
 *   - **Reset**: reject when `body.confirm` is not strictly `true`
 *     (R6.6); otherwise issue {@link DynamoDBService.deletePromptOverride}
 *     (idempotent for the "no override exists" case per R6.4) and write
 *     a best-effort `prompt_reset` audit record.
 *
 *   - **Active runs**: scan the platform's single DDB table for runs
 *     whose `status ∈ {"running", "pending"}` and return the count
 *     (R16.5). The query is gate-keeping for the frontend's
 *     `ActiveRunsFlashbar` warning so a user editing a prompt during an
 *     in-flight run sees the "edit will not affect this run" message.
 *
 * Audit semantics — every prompt edit and reset writes one
 * `PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}` record carrying a SHA-256
 * hash and UTF-8 byte length of the new text rather than the text itself
 * (R9.4). Audit failures are logged at error level and DO NOT affect the
 * 200 response (R9.3 — "best-effort audit, consistent with the existing
 * Apply Recommendations behaviour").
 *
 * @module backend/handlers/prompts
 */

import { createHash } from "node:crypto";

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  PutCommand,
  ScanCommand,
} from "@aws-sdk/lib-dynamodb";

import { fillTemplate } from "../orchestration/bedrock-judge-client";
import {
  CAPABILITY_PROFILES,
  PROMPT_REGISTRY,
  SUPPORTED_MODELS,
} from "../orchestration/prompt-registry";
import {
  PromptOverrideVersionConflictError,
  dynamoDBService,
  DynamoDBService,
} from "../services/dynamodb";
import {
  PK_PATTERNS,
  PROMPT_HISTORY_MAX_ENTRIES,
  SK_PATTERNS,
} from "../../shared/constants";
import type {
  ModelKey,
  Placeholder,
  PromptDefinition,
  PromptHistoryEntry,
  PromptKey,
  PromptOverride,
} from "../../shared/types";
import {
  validateCapabilityProfileCompliance,
  validateDryRender,
  validateModelMembership,
  validateNoUnknownPlaceholders,
  validateNumericBounds,
  validatePlaceholderOccurrenceCap,
  validatePlaceholdersPresent,
  validatePromptKeyExists,
  validateTextSize,
  type ValidationResult,
} from "./prompts-validation";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

function getTableName(): string {
  return process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
}

/**
 * Maximum age (ms) for a run record to be counted as "active" by
 * `GET /prompts/active-runs`. The platform's longest legitimate run is
 * well under an hour even on a worst-case suite (`MAX_TURNS × concurrency
 * × POLL_TIMEOUT_MS` for the conversation phase plus the 30-minute RAG
 * evaluation hard cap). Two hours is therefore a generous ceiling that
 * still excludes zombies left behind by abnormally terminated runs
 * (Lambda crash, Step Functions abort, etc.) which were never reconciled
 * to a terminal status. See the jsdoc on {@link handleActiveRuns} for
 * the rationale and a note on the missing janitor process.
 */
const ACTIVE_RUNS_MAX_AGE_MS = 2 * 60 * 60 * 1000; // 2 hours

// ---------------------------------------------------------------------------
// API Gateway types
// ---------------------------------------------------------------------------

/** API Gateway proxy event (subset relevant to this handler). */
export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  body?: string | null;
  /**
   * API Gateway forwards request headers under `headers` for the proxy
   * integration. The Prompts handler reads only the
   * `X-User-Email` display-hint header here; every other auth and
   * routing decision keys on `requestContext.authorizer.claims`.
   * Header keys are case-insensitive on the wire but API Gateway
   * preserves the casing the client sent, so the handler does its own
   * case-insensitive lookup in {@link extractDisplayEmail}.
   */
  headers?: Record<string, string | undefined> | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, string>;
    };
  };
}

/** Standard API Gateway proxy response. */
export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

// ---------------------------------------------------------------------------
// Clients (lazy-init + test-injectable, mirrors the audit handler pattern)
// ---------------------------------------------------------------------------

let docClient: DynamoDBDocumentClient | null = null;
let promptStore: DynamoDBService | null = null;

function getDocClient(): DynamoDBDocumentClient {
  if (!docClient) {
    docClient = DynamoDBDocumentClient.from(new DynamoDBClient({}), {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return docClient;
}

function getPromptStore(): DynamoDBService {
  return promptStore ?? dynamoDBService;
}

/** @internal — allows test injection of the raw DDB document client (used for audit + active-runs scan). */
export function _setDDBClient(client: DynamoDBDocumentClient | null): void {
  docClient = client;
}

/** @internal — allows test injection of the {@link DynamoDBService} the handler delegates Prompts_Store CRUD to. */
export function _setPromptStore(store: DynamoDBService | null): void {
  promptStore = store;
}

// ---------------------------------------------------------------------------
// Response helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(
  statusCode: number,
  body: unknown,
): APIGatewayResponse {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

/**
 * Convert a {@link ValidationResult} failure into the platform-standard
 * `{ error, code, details? }` 400 response shape used elsewhere in the
 * Prompts API. The handler short-circuits on the first failing stage so
 * every validation error surfaces with exactly one structured `code`.
 */
function validationFailureResponse(
  result: Extract<ValidationResult, { ok: false }>,
): APIGatewayResponse {
  // `PROMPT_NOT_FOUND` is the one validation code mapped to 404 per the
  // design's Error Handling table; every other failure is a 400.
  const status = result.code === "PROMPT_NOT_FOUND" ? 404 : 400;
  return jsonResponse(status, {
    error: humanReadableErrorMessage(result.code),
    code: result.code,
    ...(result.details !== undefined && { details: result.details }),
  });
}

/**
 * Map a structured error code to a human-readable message. Frontend code
 * switches on `code` for UX rendering, so the message is informational
 * only — keep it short and unambiguous.
 */
function humanReadableErrorMessage(code: string): string {
  switch (code) {
    case "PROMPT_NOT_FOUND":
      return "Prompt not found";
    case "PROMPT_TEXT_TOO_LARGE":
      return "Prompt text exceeds the size cap";
    case "PLACEHOLDERS_MISSING":
      return "Prompt text is missing required placeholders";
    case "PLACEHOLDER_COUNT_EXCEEDED":
      return "Prompt text contains a placeholder more times than allowed";
    case "UNKNOWN_PLACEHOLDER":
      return "Prompt text contains an undeclared placeholder";
    case "MODEL_NOT_ALLOWED":
      return "Requested model is not in this prompt's allowed list";
    case "MODEL_FORBIDS_KEY":
      return "Inference parameters contain a key the resolved model forbids";
    case "INFERENCE_PARAMETER_OUT_OF_BOUNDS":
      return "Inference parameter is outside the declared range";
    case "DRY_RENDER_FAILED":
      return "Prompt failed the server-side dry-render check";
    case "RESET_CONFIRMATION_REQUIRED":
      return "Reset requires explicit confirmation";
    case "VERSION_CONFLICT":
      return "Prompt was modified concurrently; please re-read and retry";
    default:
      return "Validation failed";
  }
}

// ---------------------------------------------------------------------------
// Auth helpers
// ---------------------------------------------------------------------------

/**
 * Extract the authenticated principal's identifier and tenant id from the
 * Cognito authorizer claims. The Prompts API uses the same identity-extraction
 * pattern as the existing Audit and Apply Recommendations handlers (R8.3):
 *
 *   - For interactive users: `claims.sub` (Cognito subject UUID).
 *   - For machine clients (M2M tokens): `claims.client_id`.
 *
 * Per R8.3, Prompt overrides themselves are deployment-global; the
 * `tenantId` returned here is used only when writing the per-edit audit
 * record (R9.1). The `userId` is what lands in `lastModifiedBy` on the
 * override and history rows (R4.2).
 */
interface AuthContext {
  /** Identifier persisted on `lastModifiedBy` (R4.2). */
  userId: string;
  /** Identifier used as the audit record's partition key (R9.1, R8.3). */
  tenantId: string;
  /**
   * Optional human-readable email lifted from the
   * `X-User-Email` request header for persistence on
   * `lastModifiedByEmail`. Validated against a basic email regex
   * before this struct is populated; missing or malformed headers
   * yield `undefined`.
   *
   * Display-hint only — never used for authorization. The
   * authoritative actor identifier is {@link AuthContext.userId},
   * which is keyed on the access token's `sub` / `client_id` claim.
   */
  displayEmail?: string;
}

/**
 * Basic email regex for the display-hint header. Matches the same
 * conservative shape Cognito uses for its hosted-UI email field —
 * `local@domain.tld` with no whitespace, no nested `@`, no leading or
 * trailing dots. The regex is intentionally lenient compared to RFC
 * 5322 because the value is purely informational; an invalid email
 * just falls through to `undefined` so the row stores no display hint.
 *
 * Matters because the header is attacker-controlled: an unauthenticated
 * caller cannot reach this code (the API Gateway authorizer is in
 * front), but an authenticated caller could supply any string they
 * like. We do NOT trust this value for any decision; we only persist
 * it for the Prompts page to display. The regex is a sanity check so
 * the rendered cell is never a string injection vector.
 */
const DISPLAY_EMAIL_REGEX =
  /^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$/;

/** Cap on the persisted display-email length so a hostile header can't bloat DDB. */
const DISPLAY_EMAIL_MAX_LEN = 254;

/**
 * Read the display-hint email from the request headers, validate
 * shape + length, and return it. Returns `undefined` for missing,
 * malformed, or oversize values so callers can persist the existing
 * UUID-based `lastModifiedBy` without an extra branch.
 *
 * Looks up the header case-insensitively because API Gateway preserves
 * the client's casing on the proxy event.
 */
function extractDisplayEmail(
  headers: APIGatewayEvent["headers"],
): string | undefined {
  if (!headers) return undefined;
  let raw: string | undefined;
  for (const [name, value] of Object.entries(headers)) {
    if (name.toLowerCase() === "x-user-email" && typeof value === "string") {
      raw = value;
      break;
    }
  }
  if (!raw) return undefined;
  const trimmed = raw.trim();
  if (
    trimmed.length === 0 ||
    trimmed.length > DISPLAY_EMAIL_MAX_LEN ||
    !DISPLAY_EMAIL_REGEX.test(trimmed)
  ) {
    return undefined;
  }
  return trimmed;
}

function extractAuth(event: APIGatewayEvent): AuthContext | null {
  const claims = event.requestContext?.authorizer?.claims;
  const principal = claims?.sub ?? claims?.client_id;
  if (!principal) {
    return null;
  }
  // The existing Audit and Apply Recommendations handlers treat the
  // authenticated principal as both the actor and the tenant id. Prompt
  // overrides are deployment-global (R8.3) so the `tenantId` here is
  // exactly the audit record's partition key — never used to scope
  // override reads or writes.
  const displayEmail = extractDisplayEmail(event.headers);
  return {
    userId: principal,
    tenantId: principal,
    ...(displayEmail !== undefined ? { displayEmail } : {}),
  };
}

// ---------------------------------------------------------------------------
// Time helper
// ---------------------------------------------------------------------------

function nowISO(): string {
  return new Date().toISOString();
}

// ---------------------------------------------------------------------------
// Audit writer (best-effort per R9.3)
// ---------------------------------------------------------------------------

/**
 * Best-effort audit writer for `prompt_edit` and `prompt_reset` records.
 * Mirrors the persistence shape used by `apply-recommendations.ts`:
 * `PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}` with the audit fields
 * spread alongside the keys.
 *
 * Per R9.4, the *full prompt text is never persisted in the audit
 * payload* — only the SHA-256 hash and the UTF-8 byte length. The hash
 * is the same value the future "diff against history" UI can compare
 * against to identify identical edits without leaking text.
 *
 * Per R9.3, a write failure here MUST NOT affect the caller's 200
 * response. Callers `await` this function but discard its outcome via
 * the `try/catch` wrapper at the call site; the `catch` logs the
 * underlying error at `console.error` level and otherwise swallows it.
 */
async function writePromptAuditRecord(args: {
  tenantId: string;
  source: "prompt_edit" | "prompt_reset";
  promptKey: PromptKey;
  previousVersion: number;
  newVersion: number;
  /** Present on `prompt_edit`; the new text whose hash and length we record. */
  newText?: string;
  timestamp: string;
}): Promise<void> {
  const client = getDocClient();
  const item: Record<string, unknown> = {
    PK: `${PK_PATTERNS.TENANT}${args.tenantId}`,
    SK: `${SK_PATTERNS.AUDIT}${args.timestamp}`,
    tenantId: args.tenantId,
    timestamp: args.timestamp,
    // The audit table's existing schema requires `runId`, `agentId`,
    // `previousVersionId`, `newVersionId`, and `recommendations` so the
    // existing `GET /audit` reader does not have to special-case the new
    // `source` literals. Prompt edits are not tied to a run or an agent;
    // we use empty strings and an empty recommendations array for those
    // shape-required fields and carry the prompt-specific payload as
    // extra attributes on the same item.
    runId: "",
    agentId: "",
    source: args.source,
    previousVersionId: String(args.previousVersion),
    newVersionId: String(args.newVersion),
    recommendations: [],
    userDecision: "normal",
    // Prompt-specific payload. R9.4: text body is NOT persisted; only the
    // hash and length so the audit table size stays bounded.
    promptKey: args.promptKey,
    previousVersion: args.previousVersion,
    newVersion: args.newVersion,
  };
  if (args.newText !== undefined) {
    item.textHash = createHash("sha256").update(args.newText, "utf8").digest("hex");
    item.textLength = Buffer.byteLength(args.newText, "utf8");
  }
  await client.send(
    new PutCommand({
      TableName: getTableName(),
      Item: item,
    }),
  );
}

// ---------------------------------------------------------------------------
// Render helpers (used by handleGetPrompt's `allowedModels[]` shaping)
// ---------------------------------------------------------------------------

/**
 * Shape one supported model entry for the API response. The frontend's
 * `ModelSelector` consumes this to render the dropdown and rebuild the
 * `InferenceParameterForm` when the user picks a different model.
 */
function shapeAllowedModel(modelKey: ModelKey): {
  modelKey: ModelKey;
  displayName: string;
  inferenceProfileId: string;
  vendor: "anthropic" | "amazon";
  capabilityProfileKey: string;
  capabilityProfile: {
    acceptsTopLevel: string[];
    acceptsAdditional: string[];
    forbids: string[];
    numericRanges: Record<string, { min: number; max: number }>;
  };
} {
  const model = SUPPORTED_MODELS[modelKey];
  const profile = CAPABILITY_PROFILES[model.capabilityProfileKey];
  return {
    modelKey: model.modelKey,
    displayName: model.displayName,
    inferenceProfileId: model.inferenceProfileId,
    vendor: model.vendor,
    capabilityProfileKey: model.capabilityProfileKey,
    capabilityProfile: {
      acceptsTopLevel: [...profile.acceptsTopLevel],
      acceptsAdditional: [...profile.acceptsAdditional],
      forbids: [...profile.forbids],
      numericRanges: { ...profile.numericRanges },
    },
  };
}

/**
 * Build a synthetic placeholder context for the dry-render stage —
 * `{name}` → `[name]` for every declared placeholder. The validator
 * needs a fully-rendered text so the SDK's request shape coercion sees
 * a payload it can actually serialise; the sentinel values are short
 * and unique so a renderer bug surfaces as a structured throw rather
 * than a silent string truncation.
 */
function buildSyntheticPlaceholderContext(
  placeholders: readonly Placeholder[],
): Record<string, string> {
  const context: Record<string, string> = {};
  for (const placeholder of placeholders) {
    context[placeholder.name] = `[${placeholder.name}]`;
  }
  return context;
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------

/**
 * `GET /prompts` — list the registry's thirteen entries layered with the
 * live override snapshot. Sorted by `category` then by `name` ascending
 * (R2.2). Body fields (`defaultText`, `overrideText`) are NOT included
 * (R2.4) — only metadata; the per-prompt detail endpoint serves the
 * bodies.
 */
async function handleListPrompts(): Promise<APIGatewayResponse> {
  const overrides = await getPromptStore().listPromptOverrides();
  const entries: Array<{
    promptKey: PromptKey;
    name: string;
    category: string;
    description: string;
    defaultModelKey: ModelKey;
    currentModelKey: ModelKey;
    defaultModelDisplayName: string;
    currentModelDisplayName: string;
    lastModifiedAt: string | null;
    lastModifiedBy: string | null;
    /**
     * Optional human-readable email of the most recent editor — same
     * display-hint contract as {@link PromptOverride.lastModifiedByEmail}.
     * Absent when the row was persisted before the field existed and
     * when the editor's call did not supply the `X-User-Email`
     * header. Null is NOT used here (vs. the UUID field above) because
     * the UI distinguishes "never set" (column hides the email) from
     * "explicitly null" — only "never set" applies to display hints.
     */
    lastModifiedByEmail?: string;
    version: number;
    isOverridden: boolean;
  }> = [];

  for (const promptKey of Object.keys(PROMPT_REGISTRY) as PromptKey[]) {
    const definition = PROMPT_REGISTRY[promptKey];
    const override = overrides.get(promptKey);
    const currentModelKey: ModelKey =
      override?.modelKey ?? definition.defaultModelKey;
    entries.push({
      promptKey: definition.promptKey,
      name: definition.name,
      category: definition.category,
      description: definition.description,
      defaultModelKey: definition.defaultModelKey,
      currentModelKey,
      defaultModelDisplayName: SUPPORTED_MODELS[definition.defaultModelKey].displayName,
      currentModelDisplayName: SUPPORTED_MODELS[currentModelKey].displayName,
      lastModifiedAt: override?.lastModifiedAt ?? null,
      lastModifiedBy: override?.lastModifiedBy ?? null,
      ...(override?.lastModifiedByEmail !== undefined
        ? { lastModifiedByEmail: override.lastModifiedByEmail }
        : {}),
      version: override?.version ?? 0,
      isOverridden: override != null,
    });
  }

  // Deterministic ordering across reloads: category, then name. Both
  // comparisons are case-insensitive so a typo'd capitalisation in one
  // definition file does not flip the row order between deploys.
  entries.sort((a, b) => {
    const c = a.category.localeCompare(b.category, undefined, {
      sensitivity: "base",
    });
    if (c !== 0) return c;
    return a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
  });

  return jsonResponse(200, { prompts: entries });
}

/**
 * `GET /prompts/{promptKey}` — read one prompt's full detail, including
 * `defaultText`, `effectiveText` (override-or-default), and the resolved
 * model's capability profile so the frontend can render the editor and
 * the parameter form correctly.
 */
async function handleGetPrompt(
  promptKey: string,
): Promise<APIGatewayResponse> {
  const keyCheck = validatePromptKeyExists(promptKey);
  if (!keyCheck.ok) {
    return validationFailureResponse(keyCheck);
  }
  const typedKey = promptKey as PromptKey;
  const definition = PROMPT_REGISTRY[typedKey];
  const override = await getPromptStore().getPromptOverride(typedKey);

  const effectiveText = override?.text ?? definition.defaultText;
  const currentModelKey: ModelKey =
    override?.modelKey ?? definition.defaultModelKey;
  const inferenceParameters: Readonly<Record<string, unknown>> =
    override?.inferenceParameters ?? definition.defaultInferenceValues;

  return jsonResponse(200, {
    promptKey: definition.promptKey,
    name: definition.name,
    description: definition.description,
    category: definition.category,
    defaultText: definition.defaultText,
    effectiveText,
    defaultModelKey: definition.defaultModelKey,
    currentModelKey,
    inferenceParameters,
    inferenceParameterSchema: definition.inferenceParameters,
    placeholders: [...definition.placeholders],
    allowedModels: definition.allowedModels.map((modelKey) =>
      shapeAllowedModel(modelKey),
    ),
    lastModifiedAt: override?.lastModifiedAt ?? null,
    lastModifiedBy: override?.lastModifiedBy ?? null,
    ...(override?.lastModifiedByEmail !== undefined
      ? { lastModifiedByEmail: override.lastModifiedByEmail }
      : {}),
    version: override?.version ?? 0,
    isOverridden: override != null,
  });
}

/**
 * `PUT /prompts/{promptKey}` — persist a prompt override. Runs the
 * validation pipeline in the strict order from the design (R4.5–R4.10,
 * R5.1, R5.4, R12.1–R12.5), issues `putPromptOverride` with optimistic
 * concurrency, then writes a best-effort `prompt_edit` audit record.
 *
 * Sparse semantics: any subset of `text`, `modelKey`,
 * `inferenceParameters` may be supplied. Missing fields fall back to the
 * registry's bundled default at resolve time per R10.1.
 */
async function handleUpdatePrompt(
  promptKey: string,
  rawBody: string | null,
  auth: AuthContext,
): Promise<APIGatewayResponse> {
  // Stage 1 — promptKey existence (R4.1, design pipeline step 1).
  const keyCheck = validatePromptKeyExists(promptKey);
  if (!keyCheck.ok) {
    return validationFailureResponse(keyCheck);
  }
  const typedKey = promptKey as PromptKey;
  const definition = PROMPT_REGISTRY[typedKey];

  // Stage 2 — body parse. Mirrors the pipeline's "reject malformed JSON"
  // step; no structured code per the design table.
  if (rawBody === null || rawBody === "") {
    return jsonResponse(400, { error: "Request body is required" });
  }
  let body: {
    text?: string;
    modelKey?: ModelKey;
    inferenceParameters?: Record<string, unknown>;
  };
  try {
    body = JSON.parse(rawBody);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }
  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    return jsonResponse(400, { error: "Request body must be a JSON object" });
  }
  // Light shape pre-checks — the validation pipeline assumes the right
  // TypeScript shapes; reject obviously-wrong payloads early.
  if (body.text !== undefined && typeof body.text !== "string") {
    return jsonResponse(400, { error: "`text` must be a string" });
  }
  if (body.modelKey !== undefined && typeof body.modelKey !== "string") {
    return jsonResponse(400, { error: "`modelKey` must be a string" });
  }
  if (
    body.inferenceParameters !== undefined &&
    (typeof body.inferenceParameters !== "object" ||
      body.inferenceParameters === null ||
      Array.isArray(body.inferenceParameters))
  ) {
    return jsonResponse(400, {
      error: "`inferenceParameters` must be a JSON object",
    });
  }

  const orderedStages: Array<() => ValidationResult> = [
    // Stage 3 — text size.
    () => validateTextSize(body.text, definition),
    // Stage 4 — placeholder presence.
    () => validatePlaceholdersPresent(body.text, definition),
    // Stage 5 — placeholder occurrence cap.
    () => validatePlaceholderOccurrenceCap(body.text, definition),
    // Stage 6 — unknown placeholder detection.
    () => validateNoUnknownPlaceholders(body.text, definition),
    // Stage 7 — model membership.
    () => validateModelMembership(body.modelKey, definition),
  ];
  for (const stage of orderedStages) {
    const result = stage();
    if (!result.ok) {
      return validationFailureResponse(result);
    }
  }

  // For Stages 8–10 we need the *resolved* (override-merged) model and
  // inference parameters because the request body is sparse. Read the
  // current override AND the highest persisted history version once so
  // the merge below uses a fresh view; the optimistic-concurrency
  // check inside `putPromptOverride` will catch any concurrent writer
  // that bumped the version between this read and our write.
  //
  // The history-version read is what fixes the post-reset edit
  // collision: a reset clears the OVERRIDE row but leaves a HISTORY
  // row at v=N+1 carrying `changeKind: "reset"`. After the reset,
  // `getPromptOverride` returns null, so the naive `priorVersion+1`
  // computation would land the next edit at v=1 — colliding with the
  // first edit's history snapshot at v=1. We take the max of the two
  // counters here so the next edit always lands strictly above any
  // persisted row's version, keeping the prompt's lifecycle counter
  // monotonic across edits and resets.
  const [priorOverride, latestHistoryVersion] = await Promise.all([
    getPromptStore().getPromptOverride(typedKey),
    getPromptStore().getLatestHistoryVersion(typedKey),
  ]);
  const resolvedModelKey: ModelKey =
    body.modelKey ??
    priorOverride?.modelKey ??
    definition.defaultModelKey;
  const mergedInferenceParameters: Readonly<Record<string, unknown>> =
    body.inferenceParameters ??
    priorOverride?.inferenceParameters ??
    definition.defaultInferenceValues;

  // Stage 8 — capability-profile compliance.
  const compliance = validateCapabilityProfileCompliance(
    mergedInferenceParameters,
    resolvedModelKey,
  );
  if (!compliance.ok) {
    return validationFailureResponse(compliance);
  }

  // Stage 9 — numeric bounds.
  const bounds = validateNumericBounds(
    mergedInferenceParameters,
    definition,
    resolvedModelKey,
  );
  if (!bounds.ok) {
    return validationFailureResponse(bounds);
  }

  // Stage 10 — dry-render. Build the synthetic placeholder context, fill
  // the resolved text, then ask the validator to construct (but not
  // send) a Bedrock Converse command. Any throw surfaces as
  // `DRY_RENDER_FAILED`.
  const resolvedText = body.text ?? priorOverride?.text ?? definition.defaultText;
  let renderedText: string;
  try {
    renderedText = fillTemplate(
      resolvedText,
      buildSyntheticPlaceholderContext(definition.placeholders),
    );
  } catch (err) {
    return jsonResponse(400, {
      error: humanReadableErrorMessage("DRY_RENDER_FAILED"),
      code: "DRY_RENDER_FAILED",
      details: {
        step: "fillTemplate",
        message: err instanceof Error ? err.message : String(err),
      },
    });
  }
  const dryRender = validateDryRender(
    renderedText,
    resolvedModelKey,
    mergedInferenceParameters,
  );
  if (!dryRender.ok) {
    return validationFailureResponse(dryRender);
  }

  // All stages passed — persist the override transactionally with
  // optimistic concurrency. The new version is one above the highest
  // counter we've seen for this prompt: either the current OVERRIDE
  // row's version (steady-state edit path) or the highest persisted
  // HISTORY row's version (post-reset first-edit path, where the
  // OVERRIDE is gone but the reset event left a v=N+1 history row
  // behind). Taking the max keeps the prompt's lifecycle counter
  // monotonic so the new OVERRIDE row never collides with an
  // existing HISTORY row.
  //
  // `priorVersion` (used for the conditional check on the OVERRIDE
  // Put inside `putPromptOverride`) remains the OVERRIDE row's
  // version: the conditional is asserting "the OVERRIDE row I read
  // is still the OVERRIDE row that exists", which is unrelated to
  // history rows. After a reset, `priorVersion === 0` correctly
  // becomes `attribute_not_exists(version)` because no OVERRIDE row
  // exists.
  const priorVersion = priorOverride?.version ?? 0;
  const newVersion = Math.max(priorVersion, latestHistoryVersion) + 1;
  const timestamp = nowISO();
  const newOverride: PromptOverride = {
    promptKey: typedKey,
    // Persist sparse: only fields explicitly supplied or carried forward
    // from the prior override. The resolver fills missing fields from
    // the bundled default at resolve time per R10.1.
    ...(body.text !== undefined
      ? { text: body.text }
      : priorOverride?.text !== undefined
        ? { text: priorOverride.text }
        : {}),
    ...(body.modelKey !== undefined
      ? { modelKey: body.modelKey }
      : priorOverride?.modelKey !== undefined
        ? { modelKey: priorOverride.modelKey }
        : {}),
    ...(body.inferenceParameters !== undefined
      ? { inferenceParameters: body.inferenceParameters }
      : priorOverride?.inferenceParameters !== undefined
        ? { inferenceParameters: priorOverride.inferenceParameters }
        : {}),
    version: newVersion,
    lastModifiedAt: timestamp,
    lastModifiedBy: auth.userId,
    ...(auth.displayEmail !== undefined
      ? { lastModifiedByEmail: auth.displayEmail }
      : {}),
  };

  try {
    await getPromptStore().putPromptOverride(
      newOverride,
      priorVersion,
      priorOverride,
      "edit",
    );
  } catch (err) {
    if (err instanceof PromptOverrideVersionConflictError) {
      return jsonResponse(409, {
        error: humanReadableErrorMessage("VERSION_CONFLICT"),
        code: "VERSION_CONFLICT",
        details: { promptKey: typedKey },
      });
    }
    throw err;
  }

  // Best-effort history eviction (R7.2). The `putPromptOverride` write
  // already snapshotted the prior version; eviction trims to the
  // `PROMPT_HISTORY_MAX_ENTRIES` cap. Failures are logged inside
  // `evictOldestHistoryEntry` and do not affect the response.
  await getPromptStore().evictOldestHistoryEntry(
    typedKey,
    PROMPT_HISTORY_MAX_ENTRIES,
  );

  // Best-effort audit write (R9.1, R9.3, R9.4). The text body itself is
  // never persisted to the audit table — only the hash and length.
  try {
    await writePromptAuditRecord({
      tenantId: auth.tenantId,
      source: "prompt_edit",
      promptKey: typedKey,
      previousVersion: priorVersion,
      newVersion,
      newText: resolvedText,
      timestamp,
    });
  } catch (auditErr) {
    console.error(
      "[prompts] Audit write failed for prompt_edit; the override remains in effect (R9.3).",
      auditErr instanceof Error ? auditErr.message : auditErr,
    );
  }

  return jsonResponse(200, {
    promptKey: typedKey,
    version: newVersion,
    lastModifiedAt: timestamp,
    lastModifiedBy: auth.userId,
    ...(auth.displayEmail !== undefined
      ? { lastModifiedByEmail: auth.displayEmail }
      : {}),
  });
}

/**
 * `POST /prompts/{promptKey}/reset` — revert a prompt to its bundled
 * default. R6.6 requires the body to carry `confirm: true` strictly;
 * anything else returns 400 `RESET_CONFIRMATION_REQUIRED`. The reset is
 * idempotent for the "no override exists" case (R6.4): a double-reset
 * leaves the prompt in the same state as a single one.
 */
async function handleResetPrompt(
  promptKey: string,
  rawBody: string | null,
  auth: AuthContext,
): Promise<APIGatewayResponse> {
  const keyCheck = validatePromptKeyExists(promptKey);
  if (!keyCheck.ok) {
    return validationFailureResponse(keyCheck);
  }
  const typedKey = promptKey as PromptKey;

  // R6.6 — `confirm: true` is required. We accept an empty body as
  // missing-confirm rather than parse-error so the structured code is
  // unambiguous.
  let body: { confirm?: unknown } | null = null;
  if (rawBody !== null && rawBody !== "") {
    try {
      body = JSON.parse(rawBody);
    } catch {
      return jsonResponse(400, { error: "Invalid JSON in request body" });
    }
    if (typeof body !== "object" || body === null || Array.isArray(body)) {
      return jsonResponse(400, {
        error: "Request body must be a JSON object",
      });
    }
  }
  if (body?.confirm !== true) {
    return jsonResponse(400, {
      error: humanReadableErrorMessage("RESET_CONFIRMATION_REQUIRED"),
      code: "RESET_CONFIRMATION_REQUIRED",
    });
  }

  const priorOverride = await getPromptStore().getPromptOverride(typedKey);
  const previousVersion = priorOverride?.version ?? 0;
  const timestamp = nowISO();

  // `deletePromptOverride` is a no-op when `priorOverride === null` —
  // that's the idempotent "reset against an unmodified prompt" path
  // (R6.4). When a prior override exists, the call is transactional:
  // prior-edit snapshot + reset event + override delete in a single
  // TransactWriteItems. The resetter's identity and a fresh timestamp
  // are forwarded onto the reset event row so the change-history
  // table can attribute the reset to who performed it.
  try {
    await getPromptStore().deletePromptOverride(typedKey, priorOverride, {
      modifiedAt: timestamp,
      modifiedBy: auth.userId,
      ...(auth.displayEmail !== undefined
        ? { modifiedByEmail: auth.displayEmail }
        : {}),
    });
  } catch (err) {
    if (err instanceof PromptOverrideVersionConflictError) {
      return jsonResponse(409, {
        error: humanReadableErrorMessage("VERSION_CONFLICT"),
        code: "VERSION_CONFLICT",
        details: { promptKey: typedKey },
      });
    }
    throw err;
  }

  // Best-effort history eviction (R7.2). The reset transaction added
  // up to two HISTORY rows (the prior-edit snapshot and the reset
  // event) so the cap can be exceeded by 2 in a single user action;
  // the helper now drains all surplus rows in one pass. Skipped on
  // the idempotent no-op path because no rows were added.
  if (priorOverride !== null) {
    await getPromptStore().evictOldestHistoryEntry(
      typedKey,
      PROMPT_HISTORY_MAX_ENTRIES,
    );
  }

  // Best-effort audit write (R9.2). We write the audit record even on
  // the no-op idempotent reset so the audit trail captures the intent;
  // `previousVersion: 0` distinguishes the no-op case for any future
  // forensic readers.
  try {
    await writePromptAuditRecord({
      tenantId: auth.tenantId,
      source: "prompt_reset",
      promptKey: typedKey,
      previousVersion,
      newVersion: 0,
      timestamp,
    });
  } catch (auditErr) {
    console.error(
      "[prompts] Audit write failed for prompt_reset; the reset remains in effect (R9.3).",
      auditErr instanceof Error ? auditErr.message : auditErr,
    );
  }

  return jsonResponse(200, {
    promptKey: typedKey,
    version: 0 as const,
    resetAt: timestamp,
  });
}

/**
 * `GET /prompts/{promptKey}/history` — return the prompt's full edit
 * trail sorted by `version` descending (R7.3). At most ten entries
 * (R7.2) — that cap is enforced at write time by
 * `evictOldestHistoryEntry`, but the read path defensively slices to
 * the same cap so a temporarily-larger history (e.g. between writes
 * before the eviction completes) cannot leak extra entries.
 *
 * Read-time entry shape:
 *
 *   - The persisted HISTORY rows in DynamoDB are snapshots of *prior*
 *     overrides — they record what was replaced, not what was just
 *     saved. The bundled default is implicit (it lives in code, not
 *     DDB) so the first edit replaces nothing snapshot-able and zero
 *     HISTORY rows are written. The second edit then snapshots the
 *     first into HISTORY, the third snapshots the second, and so on.
 *
 *   - That shape is correct for forensic queries ("what did v3 replace?")
 *     but produces a confusing UX: after edit #1 the table is empty,
 *     after edit #2 the table has one row labelled v1, etc. — i.e.
 *     N edits but only N-1 visible rows.
 *
 *   - To match the operator's intuition that "N edits → N rows with
 *     versions 1…N, newest first", this handler prepends the *current*
 *     OVERRIDE row (when one exists) as a synthetic top-of-list entry.
 *     The synthetic entry is sourced from the same OVERRIDE row that
 *     `GET /prompts/{key}` already exposes, so the surface stays
 *     consistent: the table's top row always matches the editor's
 *     "current version" badge. The persisted HISTORY rows below
 *     remain exactly what they were — prior-version snapshots.
 *
 *   - When no override exists (pristine prompt running its bundled
 *     default), the table is empty as before. R7.2's ten-entry cap
 *     applies to the combined synthetic+persisted list so the wire
 *     payload size remains predictable.
 */
async function handleGetHistory(
  promptKey: string,
): Promise<APIGatewayResponse> {
  const keyCheck = validatePromptKeyExists(promptKey);
  if (!keyCheck.ok) {
    return validationFailureResponse(keyCheck);
  }
  const typedKey = promptKey as PromptKey;
  const definition = PROMPT_REGISTRY[typedKey];
  const store = getPromptStore();

  // Two concurrent reads: the current OVERRIDE row (the synthetic
  // top-of-list entry) and the persisted HISTORY rows. They live on
  // the same partition (`PK=PROMPT#{promptKey}`) so DDB throughput
  // isn't a concern. We do them in parallel because the OVERRIDE row
  // is small and the HISTORY query is the expensive one.
  const [override, persistedHistory] = await Promise.all([
    store.getPromptOverride(typedKey),
    store.listPromptHistory(typedKey),
  ]);

  // Shape one HISTORY entry into the wire response. Pulled out as a
  // helper so the synthetic entry below uses identical default-merge
  // semantics to the persisted rows — no chance of the synthetic row
  // looking subtly different (e.g. missing the `text` default merge).
  const shapeEntry = (entry: PromptHistoryEntry) => {
    const effectiveModelKey: ModelKey =
      entry.modelKey ?? definition.defaultModelKey;
    const effectiveInferenceParameters: Readonly<Record<string, unknown>> =
      entry.inferenceParameters ?? definition.defaultInferenceValues;
    return {
      version: entry.version,
      text: entry.text ?? definition.defaultText,
      modelKey: effectiveModelKey,
      inferenceParameters: effectiveInferenceParameters,
      modifiedAt: entry.modifiedAt,
      modifiedBy: entry.modifiedBy,
      ...(entry.modifiedByEmail !== undefined
        ? { modifiedByEmail: entry.modifiedByEmail }
        : {}),
      changeKind: entry.changeKind,
    };
  };

  // Build the synthetic "current edit" entry from the OVERRIDE row
  // when one exists. The synthetic entry's `changeKind` is "edit" —
  // a reset clears the OVERRIDE row, so by definition we only reach
  // this branch when the most recent action that *kept* an override
  // was an edit. The synthetic entry's `version` is the same number
  // the OVERRIDE row carries (every edit increments it by 1) so the
  // table renders versions 1, 2, 3, … N for N edits.
  const synthetic: PromptHistoryEntry | null = override
    ? {
        promptKey: typedKey,
        version: override.version,
        ...(override.text !== undefined && { text: override.text }),
        ...(override.modelKey !== undefined && {
          modelKey: override.modelKey,
        }),
        ...(override.inferenceParameters !== undefined && {
          inferenceParameters: override.inferenceParameters,
        }),
        modifiedAt: override.lastModifiedAt,
        modifiedBy: override.lastModifiedBy,
        ...(override.lastModifiedByEmail !== undefined && {
          modifiedByEmail: override.lastModifiedByEmail,
        }),
        changeKind: "edit",
      }
    : null;

  // Stitch the synthetic entry on top of the persisted history. The
  // store already returns newest-first; the synthetic row is by
  // construction the newest. We then slice to the documented cap so
  // a temporarily-larger persisted list (e.g. between writes and the
  // best-effort eviction) does not leak extra rows.
  const combined: PromptHistoryEntry[] = synthetic
    ? [synthetic, ...persistedHistory]
    : [...persistedHistory];
  const trimmed = combined.slice(0, PROMPT_HISTORY_MAX_ENTRIES);
  const shaped = trimmed.map(shapeEntry);

  return jsonResponse(200, { history: shaped });
}

/**
 * `GET /prompts/active-runs` — return the count of test runs whose
 * `status` is `running` or `pending` (R16.5). The frontend's
 * `ActiveRunsFlashbar` polls this endpoint once on mount and once
 * before submitting an edit/reset, surfacing an info banner when the
 * user's edit lands during an in-flight run.
 *
 * Implementation: scan the platform's single DDB table filtered to run
 * records (`PK begins_with SUITE#`, `SK begins_with RUN#`) AND
 * `status ∈ {"running", "pending"}` AND `startTime` within the recent
 * window. The age cutoff defends against zombie records left behind by
 * abnormally terminated runs (Lambda crash, SFn abort, etc.) that were
 * never reconciled to a terminal status. The platform's longest
 * legitimate run is bounded by `MAX_TURNS × concurrency × POLL_TIMEOUT_MS`
 * for tool-sequence cases plus the 30-minute RAG-job hard cap, which
 * caps total wall-clock at well under an hour even on a worst-case
 * suite — so any `running` record older than two hours is definitively
 * a zombie. Counting it would mislead the user editing a prompt into
 * thinking there's an in-flight run when there isn't.
 *
 * The active-runs endpoint is interactive and infrequent (a handful of
 * calls per page open), so a filtered scan is cheaper than maintaining
 * a status GSI for this single use case.
 *
 * The scan paginates defensively — DDB returns `LastEvaluatedKey` when
 * the scanned bytes exceed 1 MiB, even with a filter expression — so
 * the loop walks the cursor until exhausted before returning.
 *
 * NOTE: the underlying zombie records still exist in DDB and continue
 * to surface on the Run Dashboard. Cleaning them up requires a
 * dedicated janitor task that reconciles each `running` row against
 * its Step Functions execution status — out of scope for this fix.
 * This change only stops the count from misleading the Prompts page.
 */
async function handleActiveRuns(): Promise<APIGatewayResponse> {
  const client = getDocClient();
  // Two-hour ceiling — see jsdoc above. Anything older than this is a
  // zombie that the run-record reconciler has not yet cleaned up.
  const cutoffIso = new Date(
    Date.now() - ACTIVE_RUNS_MAX_AGE_MS,
  ).toISOString();
  let count = 0;
  let lastEvaluatedKey: Record<string, unknown> | undefined;
  do {
    const result = await client.send(
      new ScanCommand({
        TableName: getTableName(),
        FilterExpression:
          "begins_with(PK, :suitePrefix) AND begins_with(SK, :runPrefix) AND #s IN (:running, :pending) AND startTime >= :cutoff",
        ExpressionAttributeNames: { "#s": "status" },
        ExpressionAttributeValues: {
          ":suitePrefix": PK_PATTERNS.SUITE,
          ":runPrefix": SK_PATTERNS.RUN,
          ":running": "running",
          ":pending": "pending",
          ":cutoff": cutoffIso,
        },
        ExclusiveStartKey: lastEvaluatedKey,
        // Project only the partition key — we just need the count.
        ProjectionExpression: "PK",
      }),
    );
    count += result.Items?.length ?? 0;
    lastEvaluatedKey = result.LastEvaluatedKey;
  } while (lastEvaluatedKey);

  return jsonResponse(200, { count });
}

// ---------------------------------------------------------------------------
// Main handler — API Gateway proxy integration routing
// ---------------------------------------------------------------------------

/**
 * Lambda entrypoint. Mirrors the dispatcher pattern from `audit.ts` —
 * matches `(httpMethod, resource)` against the design's API contract
 * routes and delegates to a per-route handler. Unmatched methods or
 * paths return `405` / `404` respectively.
 *
 * Authorization is performed by API Gateway (Cognito + `test-platform/run`
 * scope). This handler defensively falls back to `401` when the
 * authorizer claims are missing — that path is unreachable in
 * production but keeps unit tests deterministic.
 */
export async function handler(
  event: APIGatewayEvent,
): Promise<APIGatewayResponse> {
  const { httpMethod, resource } = event;

  // CORS preflight passes through with a 200 + CORS headers.
  if (httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  const auth = extractAuth(event);
  if (!auth) {
    return jsonResponse(401, {
      error: "Unauthorized: missing tenant identity",
    });
  }

  const promptKey = event.pathParameters?.promptKey;

  try {
    if (resource === "/prompts" && httpMethod === "GET") {
      return await handleListPrompts();
    }
    if (resource === "/prompts/active-runs" && httpMethod === "GET") {
      return await handleActiveRuns();
    }
    if (resource === "/prompts/{promptKey}" && httpMethod === "GET") {
      if (!promptKey) {
        return jsonResponse(400, { error: "promptKey is required" });
      }
      return await handleGetPrompt(promptKey);
    }
    if (resource === "/prompts/{promptKey}" && httpMethod === "PUT") {
      if (!promptKey) {
        return jsonResponse(400, { error: "promptKey is required" });
      }
      return await handleUpdatePrompt(promptKey, event.body ?? null, auth);
    }
    if (
      resource === "/prompts/{promptKey}/reset" &&
      httpMethod === "POST"
    ) {
      if (!promptKey) {
        return jsonResponse(400, { error: "promptKey is required" });
      }
      return await handleResetPrompt(promptKey, event.body ?? null, auth);
    }
    if (
      resource === "/prompts/{promptKey}/history" &&
      httpMethod === "GET"
    ) {
      if (!promptKey) {
        return jsonResponse(400, { error: "promptKey is required" });
      }
      return await handleGetHistory(promptKey);
    }

    return jsonResponse(404, {
      error: `Not found: ${httpMethod} ${resource}`,
    });
  } catch (error) {
    console.error(
      "[prompts] Handler error:",
      error instanceof Error ? error.message : error,
    );
    return jsonResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
}

// ---------------------------------------------------------------------------
// Internal exports for unit testing
// ---------------------------------------------------------------------------

export {
  handleActiveRuns,
  handleGetHistory,
  handleGetPrompt,
  handleListPrompts,
  handleResetPrompt,
  handleUpdatePrompt,
};

// Re-export the typed concurrency error so the property tests and the
// unit tests for the handler can pattern-match on it without reaching
// across modules.
export { PromptOverrideVersionConflictError };

// Re-export the {@link PromptDefinition} type so frontend code generation
// tools (and the integration tests) can derive the response shape from
// a single import surface without reaching into `shared/types.ts`.
export type { PromptDefinition };
