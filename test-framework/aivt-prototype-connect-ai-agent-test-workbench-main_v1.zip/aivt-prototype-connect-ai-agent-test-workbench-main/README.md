# Connect Agent Test Platform

A serverless web application for **automated, end-to-end testing of Amazon Q in Connect AI Agents**. Define realistic customer scenarios, run them in parallel against a live agent, score the results with managed LLM judges, and apply targeted fixes — all without leaving the platform.

> Internal AWS Solutions Architect tool for evaluating and iterating on Q in Connect agents in customer environments.

## Why this exists

Q in Connect AI Agents are configured through tool descriptions, instructions, examples, and a system prompt. Small wording changes can produce large behavior changes, and there is no built-in regression test suite. This platform closes that gap:

- **Catch regressions** before customers do — re-run the same suite after any agent edit and see exactly which conversations changed.
- **Quantify quality** — every test case gets a goal-success score, helpfulness score, and tool-accuracy score from an LLM judge using Amazon's published evaluator rubrics.
- **Get specific fixes, not vibes** — when a test fails, the platform analyzes the trace and suggests precise edits to the description, instruction, examples, or system prompt that would lift it.
- **Try changes safely** — generate three diverse rewrites of a recommendation, run the suite against each in parallel, and apply the winner with one click.

## What's in the box

| Capability | What it does |
|---|---|
| **Agent discovery** | Lists every Q in Connect agent on your Connect instance. Shows tools, instructions, examples, system prompt. |
| **Test suite authoring** | Form-based editor for two test types: tool-sequence (multi-turn customer journeys) and RAG (single-turn question/answer with retrieval). |
| **AI test scaffolding** | Describe a customer goal in plain English; Bedrock infers the expected tool sequence and generates a customer-knowledge template. |
| **Parallel test execution** | Step Functions runs your suite against the live agent with up to 9 concurrent sessions. Live progress on the run dashboard. |
| **Bedrock judge scoring** | Three managed evaluator rubrics (`GoalSuccessRate`, `Helpfulness`, `ToolSelectionAccuracy`) score every case automatically. |
| **RAG case scoring** | Question/answer cases evaluated against four metrics: Faithfulness, Correctness, Completeness, Helpfulness — via Bedrock Knowledge Base evaluation. |
| **Run comparison** | Side-by-side diff of two runs with per-case status changes and an AI-generated summary of what improved or regressed. |
| **Failure analysis** | Per-case root-cause analysis with concrete edit suggestions, plus a per-suite "top 3 changes that would lift this run the most" panel. |
| **Direct apply** | Confirmation-gated write of recommended changes back to the live agent via `UpdateAIAgent` / `UpdateAIPrompt`. Drift detection prevents overwriting concurrent edits. |
| **Multi-variant experiments** | Generate 3 diverse variants of a recommendation, test all 3 in parallel against temporary agents, view a tournament comparison, apply the winner. |
| **Audit trail** | Every write to the live agent is recorded with the user, timestamp, before/after version, and recommendations applied. |

## Architecture at a glance

```
┌─────────────────────────────────────────────────────────────────────┐
│                  React + Cloudscape frontend                         │
│           (CloudFront → S3, Cognito-protected)                       │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │ Cognito JWT
┌─────────────────────────────────▼───────────────────────────────────┐
│              API Gateway (Cognito authorizer)                        │
└──┬──────────┬──────────┬──────────┬──────────┬──────────┬───────────┘
   │          │          │          │          │          │
┌──▼─┐    ┌───▼──┐   ┌───▼──┐   ┌───▼──┐  ┌───▼───┐  ┌───▼────┐
│Disc│    │Suites│   │ Runs │   │Anal- │  │Apply  │  │Experi- │     ... 11 Lambdas
│over│    │Cases │   │      │   │ysis  │  │Recs   │  │ment    │
│y   │    │      │   │      │   │      │  │       │  │ (×4)   │
└──┬─┘    └───┬──┘   └───┬──┘   └───┬──┘  └───┬───┘  └───┬────┘
   │          │          │          │          │          │
┌──▼──────────▼──────────▼──────────▼──────────▼──────────▼───────────┐
│           DynamoDB single table  •  Step Functions (×2)              │
│           Q in Connect APIs  •  Bedrock Converse                     │
└──────────────────────────────────────────────────────────────────────┘
```

For the full architecture deep-dive, see [docs/architecture.md](docs/architecture.md).

## Quick links

### For users

- **[User guide](docs/user-guide.md)** — getting started, walkthroughs for every workflow
- **[Test suites and cases](docs/features/test-suites-and-cases.md)** — authoring tests
- **[Test execution](docs/features/test-execution.md)** — running suites and reading results
- **[Failure analysis and recommendations](docs/features/failure-analysis-and-recommendations.md)** — making sense of failed tests
- **[Implement recommendations](docs/features/implement-recommendations.md)** — applying fixes (direct apply + experiments)

### For builders

- **[Architecture](docs/architecture.md)** — components, state machines, data model
- **[Deployment](docs/deployment.md)** — prerequisites, CDK context, deploy/destroy
- **[API reference](docs/api-reference.md)** — every REST endpoint
- **[Operations](docs/operations.md)** — instance modes, IAM, audit, troubleshooting
- **[Bedrock judge evaluations](docs/features/bedrock-judge-evaluations.md)** — how scoring works
- **[RAG test cases](docs/features/rag-test-cases.md)** — how single-turn RAG cases are scored

## Getting started in 5 minutes

```bash
# 1. Install dependencies
npm install

# 2. Build the frontend bundle (Vite). The CDK BucketDeployment uploads
#    src/frontend/dist on deploy, so this step is required.
npm run build

# 3. Deploy to your AWS account (requires CDK bootstrap)
npx cdk deploy \
  --context connectInstanceId=YOUR-CONNECT-INSTANCE-UUID \
  --context adminEmail=you@example.com \
  --context instanceMode=development

# 4. Open the CloudFront URL printed in the stack outputs
#    Sign in with the temporary password emailed to adminEmail.
```

For the full deployment guide including Bedrock model access, Q in Connect prerequisites, and CI/CD setup, see [docs/deployment.md](docs/deployment.md).

## Project layout

```
.
├── bin/                      CDK app entry point
├── lib/                      CDK constructs (one file per logical component)
├── src/
│   ├── backend/
│   │   ├── handlers/         API Gateway Lambda handlers
│   │   ├── orchestration/    Step Functions tasks + pure logic modules
│   │   ├── services/         Shared service clients (DynamoDB, etc.)
│   │   └── bootstrap/        Custom resource handlers
│   ├── frontend/             React + Cloudscape app (Vite)
│   └── shared/               Types, enums, constants used by both ends
├── tests/
│   ├── unit/                 Vitest unit tests
│   ├── property/             fast-check property-based tests
│   └── fixtures/             Real captured ListSpans payloads
├── scripts/                  Operator scripts (evaluation harness, etc.)
└── .kiro/specs/              Feature specifications (requirements + design)
```

## Common commands

```bash
npm run build               # Build the frontend bundle into src/frontend/dist (Vite). REQUIRED before cdk deploy.
npm run typecheck           # Typecheck the CDK + backend TypeScript with tsc (does not emit anything cdk consumes).
npm test                    # Run all tests
npm run test:watch          # Watch mode
npm run synth               # CDK synth
npm run deploy              # CDK deploy (uses cdk.json context)
npm run lint                # ESLint
```

## License and contributing

This is an internal AWS tool. For questions, contact the WW Lead SA for Agentic and Conversational AI for Amazon Connect (current owner: trindfus).

---

**Where to next:** if you've never seen this platform before, start with the [user guide](docs/user-guide.md). If you're about to deploy it for a customer, start with [deployment](docs/deployment.md).
