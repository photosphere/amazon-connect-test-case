/**
 * Experiment Get Lambda — API Gateway handler for retrieving experiment state.
 *
 * Route:
 * - GET /runs/{runId}/experiments/{experimentId} → Full experiment record
 *
 * Returns the persisted experiment lifecycle state including status, variant
 * configurations, variant run IDs, tournament summary, and cleanup status.
 * Reads from DynamoDB at PK=RUN#{runId}, SK=EXPERIMENT#{experimentId}.
 *
 * @module experiment-get
 */

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { SFNClient, DescribeExecutionCommand } from "@aws-sdk/client-sfn";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import type { ExperimentRecord, ExperimentStatus } from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** API Gateway proxy event (subset relevant to this handler). */
export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  queryStringParameters?: Record<string, string> | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, unknown>;
    };
  };
}

/** Standard API Gateway proxy response. */
export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

// ---------------------------------------------------------------------------
// DynamoDB client
// ---------------------------------------------------------------------------

let ddbDocClient: DynamoDBDocumentClient | null = null;

function getDDBClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setDDBClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Response helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
};

function success(body: unknown): APIGatewayResponse {
  return { statusCode: 200, body: JSON.stringify(body), headers: CORS_HEADERS };
}

function notFound(message: string): APIGatewayResponse {
  return {
    statusCode: 404,
    body: JSON.stringify({ error: message }),
    headers: CORS_HEADERS,
  };
}

function badRequest(message: string): APIGatewayResponse {
  return {
    statusCode: 400,
    body: JSON.stringify({ error: message }),
    headers: CORS_HEADERS,
  };
}

function serverError(message: string): APIGatewayResponse {
  return {
    statusCode: 500,
    body: JSON.stringify({ error: message }),
    headers: CORS_HEADERS,
  };
}

function methodNotAllowed(): APIGatewayResponse {
  return {
    statusCode: 405,
    body: JSON.stringify({ error: "Method not allowed" }),
    headers: CORS_HEADERS,
  };
}

// ---------------------------------------------------------------------------
// SFN client (for status reconciliation)
// ---------------------------------------------------------------------------

let sfnClient: SFNClient | null = null;

function getSFNClient(): SFNClient {
  if (!sfnClient) {
    sfnClient = new SFNClient({ region: process.env.AWS_REGION ?? "us-east-1" });
  }
  return sfnClient;
}

/** Terminal experiment statuses — no reconciliation needed. */
const TERMINAL_STATUSES: ExperimentStatus[] = ["completed", "failed", "cleaned_up"];

/**
 * If the experiment DDB record shows a non-terminal status but the SFN
 * execution has failed/timed_out/aborted, update DDB to "failed" so the
 * frontend polling picks up the terminal state. Without this, a state
 * machine crash leaves the DDB record stuck at "generating_variants"
 * forever and the frontend spinner never resolves.
 */
async function reconcileWithSfnStatus(
  experiment: ExperimentRecord,
): Promise<ExperimentRecord> {
  // Already terminal — nothing to check
  if (TERMINAL_STATUSES.includes(experiment.status)) {
    return experiment;
  }

  // No SFN ARN — can't reconcile
  if (!experiment.sfnExecutionArn) {
    return experiment;
  }

  try {
    const sfn = getSFNClient();
    const execution = await sfn.send(
      new DescribeExecutionCommand({
        executionArn: experiment.sfnExecutionArn,
      }),
    );

    const sfnStatus = execution.status; // RUNNING | SUCCEEDED | FAILED | TIMED_OUT | ABORTED
    if (sfnStatus === "FAILED" || sfnStatus === "TIMED_OUT" || sfnStatus === "ABORTED") {
      // SFN is dead but DDB record wasn't updated — fix it now
      console.warn(
        `[experiment-get] Reconciling experiment ${experiment.experimentId}: ` +
          `DDB status=${experiment.status} but SFN status=${sfnStatus}. Marking as failed.`,
      );

      const client = getDDBClient();
      await client.send(
        new UpdateCommand({
          TableName: TABLE_NAME,
          Key: {
            PK: `${PK_PATTERNS.RUN}${experiment.runId}`,
            SK: `${SK_PATTERNS.EXPERIMENT}${experiment.experimentId}`,
          },
          UpdateExpression: "SET #s = :failed",
          ExpressionAttributeNames: { "#s": "status" },
          ExpressionAttributeValues: { ":failed": "failed" },
        }),
      );

      return { ...experiment, status: "failed" };
    }
  } catch (err) {
    // Non-fatal — if we can't describe the execution, just return as-is
    console.warn(
      `[experiment-get] SFN reconciliation failed for ${experiment.experimentId}:`,
      err instanceof Error ? err.message : err,
    );
  }

  return experiment;
}

// ---------------------------------------------------------------------------
// DynamoDB helpers
// ---------------------------------------------------------------------------

/**
 * Strip DynamoDB key attributes from an item.
 */
function stripKeys<T>(item: Record<string, unknown>): T {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { PK, SK, GSI1PK, GSI1SK, GSI2PK, GSI2SK, ...rest } = item;
  return rest as unknown as T;
}

/**
 * Retrieve an experiment record by runId and experimentId.
 */
async function getExperiment(
  runId: string,
  experimentId: string,
): Promise<ExperimentRecord | null> {
  const client = getDDBClient();
  const result = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `${SK_PATTERNS.EXPERIMENT}${experimentId}`,
      },
    }),
  );
  if (!result.Item) return null;
  return stripKeys<ExperimentRecord>(result.Item as Record<string, unknown>);
}

// ---------------------------------------------------------------------------
// Main handler — API Gateway proxy integration
// ---------------------------------------------------------------------------

/**
 * Lambda handler for GET /runs/{runId}/experiments/{experimentId}.
 * Returns the full experiment state including status, variant configs,
 * run IDs, and tournament summary.
 */
export async function handler(event: APIGatewayEvent): Promise<APIGatewayResponse> {
  const { httpMethod, pathParameters } = event;

  if (httpMethod !== "GET") {
    return methodNotAllowed();
  }

  try {
    const runId = pathParameters?.runId;
    const experimentId = pathParameters?.experimentId;

    if (!runId) {
      return badRequest("Missing runId path parameter");
    }
    if (!experimentId) {
      return badRequest("Missing experimentId path parameter");
    }

    const experiment = await getExperiment(runId, experimentId);

    if (!experiment) {
      return notFound("experiment_not_found");
    }

    // Reconcile: if the SFN execution died but DDB wasn't updated, fix it now
    const reconciled = await reconcileWithSfnStatus(experiment);

    return success(reconciled);
  } catch (error) {
    console.error(
      "[experiment-get] Handler error:",
      error instanceof Error ? error.message : error,
    );
    return serverError("Internal server error");
  }
}
