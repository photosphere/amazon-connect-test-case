/**
 * TournamentView — displays a 4-column comparison of baseline vs 3 variants
 * from a multi-variant experiment. Shows aggregate scores, per-case status
 * rows with change highlighting, a "Recommended" badge on the best variant,
 * an AI-generated summary, and "Apply to Agent" buttons per variant.
 *
 * Key requirements addressed:
 *   - R8.1: 4 columns — Baseline, Variant A, Variant B, Variant C
 *   - R8.2: Aggregate scores per column (pass rate, avg goal success,
 *     avg helpfulness, avg tool accuracy)
 *   - R8.3: Per-case rows with status change highlighting (green = improved,
 *     red = regressed)
 *   - R8.4: "Recommended" badge on best-performing variant
 *   - R8.5: AI-generated summary section
 *   - R8.6: Error state for failed variants
 *   - R8.7: Tournament View persists as a permanent view
 *   - R9.1: "Apply to Agent" button on each variant column
 *   - R17.1: Partial results shown when some variants errored
 *   - R17.4: "Retry summary" button if Bedrock summary call failed
 *
 * @module components/ImplementRecommendations/TournamentView
 */

import Badge from '@cloudscape-design/components/badge';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import Container from '@cloudscape-design/components/container';
import Header from '@cloudscape-design/components/header';
import SpaceBetween from '@cloudscape-design/components/space-between';
import StatusIndicator from '@cloudscape-design/components/status-indicator';
import Table from '@cloudscape-design/components/table';

import { CaseStatus } from '../../../../shared/enums';
import type { ExperimentRecord, TestCaseResult, TournamentSummary } from '../../../../shared/types';

// ---------------------------------------------------------------------------
// Public Props
// ---------------------------------------------------------------------------

export interface TournamentViewProps {
  experiment: ExperimentRecord;
  baselineResults: TestCaseResult[];
  variantResults: Record<'A' | 'B' | 'C', TestCaseResult[]>;
  onApplyVariant: (variant: 'A' | 'B' | 'C') => void;
  onRetrySummary?: () => void;
  /** When true, disable all "Apply to Agent" buttons (e.g. while an apply is in flight). */
  applyDisabled?: boolean;
}

// ---------------------------------------------------------------------------
// Internal Types
// ---------------------------------------------------------------------------

type VariantLetter = 'A' | 'B' | 'C';

const VARIANT_LETTERS: VariantLetter[] = ['A', 'B', 'C'];

interface AggregateScores {
  passRate: number;
  avgGoalSuccessScore: number;
  avgHelpfulnessScore: number;
  avgToolAccuracyScore: number;
}

interface CaseRow {
  caseId: string;
  baselineStatus: CaseStatus | undefined;
  variantStatuses: Record<VariantLetter, CaseStatus | undefined>;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Compute aggregate scores from an array of test case results. */
function computeAggregateScores(results: TestCaseResult[]): AggregateScores {
  if (results.length === 0) {
    return { passRate: 0, avgGoalSuccessScore: 0, avgHelpfulnessScore: 0, avgToolAccuracyScore: 0 };
  }

  const passedCount = results.filter((r) => r.status === CaseStatus.PASSED).length;
  const passRate = passedCount / results.length;

  const avgGoalSuccessScore = computeMean(results, (r) => r.goalSuccessScore);
  const avgHelpfulnessScore = computeMean(results, (r) => r.helpfulnessScore);
  const avgToolAccuracyScore = computeMean(results, (r) => r.toolAccuracyScore);

  return { passRate, avgGoalSuccessScore, avgHelpfulnessScore, avgToolAccuracyScore };
}

function computeMean(
  results: TestCaseResult[],
  extractor: (r: TestCaseResult) => number | undefined,
): number {
  let sum = 0;
  let count = 0;
  for (const result of results) {
    const value = extractor(result);
    if (value !== undefined) {
      sum += value;
      count++;
    }
  }
  return count === 0 ? 0 : sum / count;
}

/** Format a decimal as a percentage string (e.g. 0.85 → "85%"). */
function formatPercent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

/** Format a score as a 2-decimal string (e.g. 0.8567 → "0.86"). */
function formatScore(value: number): string {
  return value.toFixed(2);
}

/** Check if a variant errored (no results available). */
function isVariantErrored(
  variant: VariantLetter,
  variantResults: Record<VariantLetter, TestCaseResult[]>,
  experiment: ExperimentRecord,
): boolean {
  // A variant is considered errored if it has no results AND the experiment
  // is in a completed state (meaning it should have results but doesn't).
  const results = variantResults[variant];
  if (results.length === 0 && experiment.status === 'completed') {
    return true;
  }
  return false;
}

/**
 * Determine the background color for a status cell based on change from baseline.
 * Green = improved (baseline failed → variant passed)
 * Red = regressed (baseline passed → variant failed/error)
 */
function getStatusChangeColor(
  baselineStatus: CaseStatus | undefined,
  variantStatus: CaseStatus | undefined,
): string | undefined {
  if (!baselineStatus || !variantStatus) return undefined;

  const baselinePassed = baselineStatus === CaseStatus.PASSED;
  const variantPassed = variantStatus === CaseStatus.PASSED;

  if (!baselinePassed && variantPassed) return '#d1f7c4'; // green — improved
  if (baselinePassed && !variantPassed) return '#ffd6d6'; // red — regressed
  return undefined;
}

/** Map CaseStatus to StatusIndicator type. */
function statusToIndicatorType(status: CaseStatus | undefined): 'success' | 'error' | 'warning' | 'info' {
  switch (status) {
    case CaseStatus.PASSED:
      return 'success';
    case CaseStatus.FAILED:
      return 'error';
    case CaseStatus.ERROR:
      return 'error';
    case CaseStatus.TIMED_OUT:
      return 'warning';
    default:
      return 'info';
  }
}

/** Get all unique case IDs from baseline and variant results. */
function getAllCaseIds(
  baselineResults: TestCaseResult[],
  variantResults: Record<VariantLetter, TestCaseResult[]>,
): string[] {
  const caseIdSet = new Set<string>();
  for (const r of baselineResults) caseIdSet.add(r.caseId);
  for (const letter of VARIANT_LETTERS) {
    for (const r of variantResults[letter]) caseIdSet.add(r.caseId);
  }
  return Array.from(caseIdSet).sort();
}

/** Build per-case row data for the comparison table. */
function buildCaseRows(
  baselineResults: TestCaseResult[],
  variantResults: Record<VariantLetter, TestCaseResult[]>,
): CaseRow[] {
  const caseIds = getAllCaseIds(baselineResults, variantResults);

  const baselineMap = new Map<string, TestCaseResult>();
  for (const r of baselineResults) baselineMap.set(r.caseId, r);

  const variantMaps: Record<VariantLetter, Map<string, TestCaseResult>> = {
    A: new Map(),
    B: new Map(),
    C: new Map(),
  };
  for (const letter of VARIANT_LETTERS) {
    for (const r of variantResults[letter]) {
      variantMaps[letter].set(r.caseId, r);
    }
  }

  return caseIds.map((caseId) => ({
    caseId,
    baselineStatus: baselineMap.get(caseId)?.status,
    variantStatuses: {
      A: variantMaps.A.get(caseId)?.status,
      B: variantMaps.B.get(caseId)?.status,
      C: variantMaps.C.get(caseId)?.status,
    },
  }));
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

/** Renders the AI-generated summary section at the top. */
function SummarySection({
  tournamentSummary,
  onRetrySummary,
}: {
  tournamentSummary: TournamentSummary | undefined;
  onRetrySummary?: () => void;
}): JSX.Element {
  if (!tournamentSummary) {
    return (
      <Box padding="s">
        <SpaceBetween size="xs">
          <StatusIndicator type="warning">
            Summary not available
          </StatusIndicator>
          {onRetrySummary && (
            <Button onClick={onRetrySummary} iconName="refresh">
              Retry summary
            </Button>
          )}
        </SpaceBetween>
      </Box>
    );
  }

  const summaryFailed = tournamentSummary.summary.toLowerCase().includes('failed');

  return (
    <Box padding="s">
      <SpaceBetween size="s">
        <Box variant="p">{tournamentSummary.summary}</Box>
        {summaryFailed && onRetrySummary && (
          <Button onClick={onRetrySummary} iconName="refresh">
            Retry summary
          </Button>
        )}
      </SpaceBetween>
    </Box>
  );
}

/** Renders aggregate scores for a single column. */
function AggregateScoreColumn({
  scores,
  isErrored,
}: {
  scores: AggregateScores;
  isErrored: boolean;
}): JSX.Element {
  if (isErrored) {
    return (
      <Box textAlign="center">
        <StatusIndicator type="error">Variant failed</StatusIndicator>
      </Box>
    );
  }

  return (
    <SpaceBetween size="xxs">
      <Box>
        <Box variant="awsui-key-label">Pass Rate</Box>
        <Box variant="p" fontWeight="bold">{formatPercent(scores.passRate)}</Box>
      </Box>
      <Box>
        <Box variant="awsui-key-label">Avg Goal Success</Box>
        <Box variant="p">{formatScore(scores.avgGoalSuccessScore)}</Box>
      </Box>
      <Box>
        <Box variant="awsui-key-label">Avg Helpfulness</Box>
        <Box variant="p">{formatScore(scores.avgHelpfulnessScore)}</Box>
      </Box>
      <Box>
        <Box variant="awsui-key-label">Avg Tool Accuracy</Box>
        <Box variant="p">{formatScore(scores.avgToolAccuracyScore)}</Box>
      </Box>
    </SpaceBetween>
  );
}

// ---------------------------------------------------------------------------
// Main Component
// ---------------------------------------------------------------------------

/**
 * TournamentView renders a side-by-side comparison of baseline vs 3 variants
 * with aggregate scores, per-case status rows, and apply actions.
 */
export function TournamentView({
  experiment,
  baselineResults,
  variantResults,
  onApplyVariant,
  onRetrySummary,
  applyDisabled = false,
}: TournamentViewProps): JSX.Element {
  const tournamentSummary = experiment.tournamentSummary;
  const winningVariant = tournamentSummary?.winningVariant ?? null;

  // Compute aggregate scores
  const baselineScores = computeAggregateScores(baselineResults);
  const variantScores: Record<VariantLetter, AggregateScores> = {
    A: computeAggregateScores(variantResults.A),
    B: computeAggregateScores(variantResults.B),
    C: computeAggregateScores(variantResults.C),
  };

  // Determine errored variants
  const variantErrored: Record<VariantLetter, boolean> = {
    A: isVariantErrored('A', variantResults, experiment),
    B: isVariantErrored('B', variantResults, experiment),
    C: isVariantErrored('C', variantResults, experiment),
  };

  // Build per-case comparison rows
  const caseRows = buildCaseRows(baselineResults, variantResults);

  return (
    <Container
      header={
        <Header variant="h2">
          Tournament Results
        </Header>
      }
    >
      <SpaceBetween size="l">
        {/* AI-generated summary */}
        <Container header={<Header variant="h3">Summary</Header>}>
          <SummarySection
            tournamentSummary={tournamentSummary}
            onRetrySummary={onRetrySummary}
          />
        </Container>

        {/* Aggregate scores — 4 columns */}
        <Container header={<Header variant="h3">Aggregate Scores</Header>}>
          <ColumnLayout columns={4} variant="text-grid">
            {/* Baseline */}
            <SpaceBetween size="xs">
              <Box textAlign="center" fontWeight="bold">Baseline</Box>
              <AggregateScoreColumn scores={baselineScores} isErrored={false} />
            </SpaceBetween>

            {/* Variant columns */}
            {VARIANT_LETTERS.map((letter) => (
              <SpaceBetween size="xs" key={letter}>
                <Box textAlign="center">
                  <SpaceBetween size="xs" direction="horizontal" alignItems="center">
                    <Box fontWeight="bold">Variant {letter}</Box>
                    {winningVariant === letter && (
                      <Badge color="green">Recommended</Badge>
                    )}
                  </SpaceBetween>
                </Box>
                <AggregateScoreColumn
                  scores={variantScores[letter]}
                  isErrored={variantErrored[letter]}
                />
                {!variantErrored[letter] && (
                  <Box textAlign="center" padding={{ top: 's' }}>
                    <Button
                      variant={winningVariant === letter ? 'primary' : 'normal'}
                      onClick={() => onApplyVariant(letter)}
                      disabled={applyDisabled}
                    >
                      Apply to Agent
                    </Button>
                  </Box>
                )}
              </SpaceBetween>
            ))}
          </ColumnLayout>
        </Container>

        {/* Per-case comparison table */}
        <Container header={<Header variant="h3">Per-Case Results</Header>}>
          <Table
            columnDefinitions={[
              {
                id: 'caseId',
                header: 'Test Case',
                cell: (item: CaseRow) => (
                  <Box fontWeight="bold">{item.caseId}</Box>
                ),
                width: 200,
              },
              {
                id: 'baseline',
                header: 'Baseline',
                cell: (item: CaseRow) => (
                  <StatusIndicator type={statusToIndicatorType(item.baselineStatus)}>
                    {item.baselineStatus ?? 'N/A'}
                  </StatusIndicator>
                ),
              },
              ...VARIANT_LETTERS.map((letter) => ({
                id: `variant-${letter}`,
                header: `Variant ${letter}${winningVariant === letter ? ' ★' : ''}`,
                cell: (item: CaseRow) => {
                  if (variantErrored[letter]) {
                    return (
                      <StatusIndicator type="error">Error</StatusIndicator>
                    );
                  }
                  const variantStatus = item.variantStatuses[letter];
                  const bgColor = getStatusChangeColor(item.baselineStatus, variantStatus);
                  return (
                    <Box
                      padding="xxs"
                      {...(bgColor ? { color: undefined } : {})}
                    >
                      <span style={bgColor ? { backgroundColor: bgColor, padding: '2px 6px', borderRadius: '4px' } : undefined}>
                        <StatusIndicator type={statusToIndicatorType(variantStatus)}>
                          {variantStatus ?? 'N/A'}
                        </StatusIndicator>
                      </span>
                    </Box>
                  );
                },
              })),
            ]}
            items={caseRows}
            variant="embedded"
            wrapLines
            empty={
              <Box textAlign="center" color="text-status-inactive" padding="s">
                No test case results available.
              </Box>
            }
          />
        </Container>
      </SpaceBetween>
    </Container>
  );
}
