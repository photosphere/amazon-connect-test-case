/**
 * Comparison Summary Lambda — POST /comparisons/summarize
 *
 * Produces a short, deterministic, plain-language summary of the diff
 * between two runs of the same suite. Designed to be called once when the
 * user clicks "Compare" on the Comparison page so the prominent summary
 * card lands at the top alongside the existing diff tables.
 *
 * The Lambda:
 *   1. Validates the request body (`runIdA`, `runIdB`).
 *   2. Loads each run's `TestCaseResult[]` and `AgentSnapshot` from DDB.
 *   3. Reuses the same pure utilities the frontend uses
 *      (`compareRuns`, `compareScores`, `diffAgentConfigs`) so the summary
 *      references the same numbers the user sees in the tables.
 *   4. Builds a strict prompt that asks the model to ground every claim in
 *      the structured JSON diff input. `temperature` is set to `0` so two
 *      clicks on the same comparison produce identical text.
 *   5. Returns `{ summary, runIdA, runIdB, modelId, generatedAt }`.
 *
 * The summary is generated on demand, not cached. A click is rare and the
 * model call is cheap (a few cents / a few seconds) so the simplest
 * implementation is the right one. If users start re-clicking comparisons
 * that's a follow-up task, not a launch blocker.
 *
 * @module comparison-summary
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ContentBlock,
  type ConverseCommandInput,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";

import type {
  AgentSnapshot,
  TestCaseResult,
  TestRun,
} from "../../shared/types";
import { compareRuns } from "../../shared/utils/run-comparison";
import { compareScores } from "../../shared/utils/score-comparison";
import { diffAgentConfigs } from "../../shared/utils/config-diff";
import {
  buildInferenceConfig,
  type ResolvedPrompt,
} from "../orchestration/prompt-registry";
import { resolvePromptLive } from "../orchestration/prompt-registry/runtime";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";
const TABLE_NAME =
  process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
// The model id, system prompt text, and `maxTokens` cap for this Lambda
// all come from the Prompt_Registry via `resolvePromptLive("comparison_summary")`.
// The legacy `COMPARISON_SUMMARY_MODEL_ID` env var is still set in
// `lib/api-construct.ts` as a Wave-1 safety net and is removed in Wave 3
// (per the prompt-management migration plan).

// ---------------------------------------------------------------------------
// Clients (cached across warm invocations)
// ---------------------------------------------------------------------------

let bedrockClient: BedrockRuntimeClient | null = null;
let ddbDocClient: DynamoDBDocumentClient | null = null;

function getBedrockClient(): BedrockRuntimeClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

function getDDBDocClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const base = new DynamoDBClient({ region: REGION });
    ddbDocClient = DynamoDBDocumentClient.from(base);
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setBedrockClient(client: BedrockRuntimeClient | null): void {
  bedrockClient = client;
}

/** @internal — allows test injection */
export function _setDDBDocClient(
  client: DynamoDBDocumentClient | null,
): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Response helpers (mirror the format of the other handlers)
// ---------------------------------------------------------------------------

const CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(statusCode: number, body: unknown) {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

export interface ComparisonSummaryRequest {
  runIdA: string;
  runIdB: string;
  /**
   * Optional hint used to look up run records that live under the legacy
   * `PK=SUITE#{suiteId}, SK=RUN#{startTime}` partition. The endpoint also
   * works without it (we then scan the run's case partition for the
   * SUMMARY record), but supplying the hint is faster.
   */
  suiteId?: string;
}

export interface ComparisonSummaryResponse {
  /** Plain-text summary, 3-6 short paragraphs / bullets. */
  summary: string;
  runIdA: string;
  runIdB: string;
  /** Model id that produced the summary (for traceability in the UI). */
  modelId: string;
  /** ISO timestamp the summary was generated at. */
  generatedAt: string;
}

// ---------------------------------------------------------------------------
// DDB loaders
// ---------------------------------------------------------------------------

interface LoadedRunData {
  results: TestCaseResult[];
  snapshot: AgentSnapshot | null;
  run: Pick<TestRun, "runId" | "startTime" | "endTime"> | null;
}

/**
 * Strips the DynamoDB `PK` / `SK` keys from an item before returning it
 * in API responses. The other handlers use the same pattern; mirrored
 * here so this Lambda doesn't need to import their internals.
 */
function stripKeys<T>(item: Record<string, unknown>): T {
  const { PK: _PK, SK: _SK, ...rest } = item as Record<string, unknown>;
  void _PK;
  void _SK;
  return rest as T;
}

/**
 * Loads results, snapshot, and a minimal run record for one runId. Tries
 * the by-id `RUN#{runId}/SUMMARY` partition first, then the suite-keyed
 * partition (when a `suiteId` hint was supplied) for runs whose SUMMARY
 * row hasn't landed yet. Snapshot lookup tolerates absence — the prompt
 * still produces a useful result without it.
 */
async function loadRunData(
  runId: string,
  suiteIdHint: string | undefined,
): Promise<LoadedRunData> {
  const client = getDDBDocClient();

  // --- 1. Case results (one row per case) -------------------------------
  const resultsResp = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :case)",
      ExpressionAttributeValues: {
        ":pk": `RUN#${runId}`,
        ":case": "CASE#",
      },
    }),
  );
  const results: TestCaseResult[] = (resultsResp.Items ?? []).map((item) =>
    stripKeys<TestCaseResult>(item as Record<string, unknown>),
  );

  // --- 2. Agent snapshot (best-effort) ----------------------------------
  let snapshot: AgentSnapshot | null = null;
  try {
    const snapResp = await client.send(
      new GetCommand({
        TableName: TABLE_NAME,
        Key: { PK: `RUN#${runId}`, SK: "SNAPSHOT" },
      }),
    );
    if (snapResp.Item) {
      snapshot = stripKeys<AgentSnapshot>(
        snapResp.Item as Record<string, unknown>,
      );
    }
  } catch {
    // The summary still works without the config diff section.
    snapshot = null;
  }

  // --- 3. Run summary record (for startTime/endTime) --------------------
  let run: LoadedRunData["run"] = null;
  try {
    const runResp = await client.send(
      new GetCommand({
        TableName: TABLE_NAME,
        Key: { PK: `RUN#${runId}`, SK: "SUMMARY" },
      }),
    );
    if (runResp.Item) {
      const stripped = stripKeys<TestRun>(
        runResp.Item as Record<string, unknown>,
      );
      run = {
        runId: stripped.runId,
        startTime: stripped.startTime,
        endTime: stripped.endTime,
      };
    } else if (suiteIdHint) {
      // Older runs lived only under `PK=SUITE#{suiteId}, SK=RUN#{startTime}`.
      // The hint lets us retrieve the run timing fields the summary uses.
      const suiteResp = await client.send(
        new QueryCommand({
          TableName: TABLE_NAME,
          KeyConditionExpression: "PK = :pk AND begins_with(SK, :run)",
          ExpressionAttributeValues: {
            ":pk": `SUITE#${suiteIdHint}`,
            ":run": "RUN#",
          },
        }),
      );
      const matches = (suiteResp.Items ?? []).find(
        (it) => (it as Record<string, unknown>).runId === runId,
      );
      if (matches) {
        const stripped = stripKeys<TestRun>(
          matches as Record<string, unknown>,
        );
        run = {
          runId: stripped.runId,
          startTime: stripped.startTime,
          endTime: stripped.endTime,
        };
      }
    }
  } catch {
    run = null;
  }

  return { results, snapshot, run };
}

// ---------------------------------------------------------------------------
// Prompt construction
// ---------------------------------------------------------------------------

/**
 * Shape of the JSON diff payload we hand to the model. Kept compact so
 * the prompt fits comfortably under the model's context window even on
 * large suites; the structure is flat and self-describing so the model
 * doesn't need a separate schema explanation.
 */
interface SummaryDiffPayload {
  runA: { runId: string; startTime?: string; endTime?: string };
  runB: { runId: string; startTime?: string; endTime?: string };
  totals: {
    runA: { passed: number; failed: number; errors: number; total: number };
    runB: { passed: number; failed: number; errors: number; total: number };
  };
  caseStatusChanges: Array<{
    caseId: string;
    category: string;
    previousStatus: string | null;
    currentStatus: string | null;
  }>;
  perMetricMeans: {
    goalSuccess?: { previous?: number; current?: number; delta?: number };
    helpfulness?: { previous?: number; current?: number; delta?: number };
    toolAccuracy?: { previous?: number; current?: number; delta?: number };
  };
  perMetricCounts: {
    goalSuccess: { improved: number; regressed: number; unchanged: number };
    helpfulness: { improved: number; regressed: number; unchanged: number };
    toolAccuracy: { improved: number; regressed: number; unchanged: number };
  };
  configChanges: {
    toolsAdded: string[];
    toolsRemoved: string[];
    toolEdits: string[];
    systemPromptChanged: boolean;
    systemPromptCharDelta?: number;
    modelChanged?: { from: string; to: string };
  };
}

/**
 * Computes the arithmetic mean of a numeric field across results, ignoring
 * missing/non-finite values. Returns `undefined` when no result has a usable
 * value so the prompt can omit the metric entirely instead of showing 0.
 */
function meanOf(
  results: TestCaseResult[],
  field: "goalSuccessScore" | "helpfulnessScore" | "toolAccuracyScore",
): number | undefined {
  let sum = 0;
  let n = 0;
  for (const r of results) {
    const v = r[field];
    if (typeof v === "number" && Number.isFinite(v)) {
      sum += v;
      n += 1;
    }
  }
  return n === 0 ? undefined : sum / n;
}

/**
 * Builds the structured diff payload from the loaded run data using the
 * exact same utilities the GUI calls. Matching the GUI keeps the model's
 * citations directly verifiable against the tables on the page.
 */
function buildDiffPayload(
  a: LoadedRunData & { runId: string },
  b: LoadedRunData & { runId: string },
): SummaryDiffPayload {
  const compareResult = compareRuns(a.results, b.results);
  const scoreResult = compareScores(a.results, b.results);

  const countByStatus = (results: TestCaseResult[]) => {
    let passed = 0;
    let failed = 0;
    let errors = 0;
    for (const r of results) {
      if (r.status === "passed") passed += 1;
      else if (r.status === "failed") failed += 1;
      else if (r.status === "error" || r.status === "timed_out") errors += 1;
    }
    return { passed, failed, errors, total: results.length };
  };

  const meansFor = (
    field: "goalSuccessScore" | "helpfulnessScore" | "toolAccuracyScore",
  ) => {
    const prev = meanOf(a.results, field);
    const curr = meanOf(b.results, field);
    if (prev === undefined && curr === undefined) return undefined;
    return {
      previous: prev,
      current: curr,
      delta:
        prev !== undefined && curr !== undefined ? curr - prev : undefined,
    };
  };

  const configChanges = {
    toolsAdded: [] as string[],
    toolsRemoved: [] as string[],
    toolEdits: [] as string[],
    systemPromptChanged: false,
    systemPromptCharDelta: undefined as number | undefined,
    modelChanged: undefined as { from: string; to: string } | undefined,
  };
  if (a.snapshot && b.snapshot) {
    const diff = diffAgentConfigs(a.snapshot, b.snapshot);
    for (const c of diff.changes) {
      if (c.changeType === "tool-added") configChanges.toolsAdded.push(c.toolName ?? "");
      else if (c.changeType === "tool-removed") configChanges.toolsRemoved.push(c.toolName ?? "");
      else if (c.changeType === "tool-modified") {
        configChanges.toolEdits.push(`${c.toolName ?? "?"}: modified`);
      } else if (c.changeType === "system-prompt-changed") {
        configChanges.systemPromptChanged = true;
        const aLen = a.snapshot?.systemPrompt?.length ?? 0;
        const bLen = b.snapshot?.systemPrompt?.length ?? 0;
        configChanges.systemPromptCharDelta = bLen - aLen;
      } else if (c.changeType === "model-changed") {
        configChanges.modelChanged = {
          from: a.snapshot.modelId,
          to: b.snapshot.modelId,
        };
      }
    }
  }

  return {
    runA: {
      runId: a.runId,
      startTime: a.run?.startTime,
      endTime: a.run?.endTime,
    },
    runB: {
      runId: b.runId,
      startTime: b.run?.startTime,
      endTime: b.run?.endTime,
    },
    totals: {
      runA: countByStatus(a.results),
      runB: countByStatus(b.results),
    },
    caseStatusChanges: compareResult.entries
      // Drop "unchanged" entries — they create noise in the prompt and
      // the summary should highlight what's different. Pass count-only
      // info via totals.
      .filter((e) => e.category !== "unchanged")
      .map((e) => ({
        caseId: e.caseId,
        category: e.category,
        previousStatus: e.previousStatus ?? null,
        currentStatus: e.currentStatus ?? null,
      })),
    perMetricMeans: {
      goalSuccess: meansFor("goalSuccessScore"),
      helpfulness: meansFor("helpfulnessScore"),
      toolAccuracy: meansFor("toolAccuracyScore"),
    },
    perMetricCounts: {
      goalSuccess: {
        improved: scoreResult.summary.perMetric.goalSuccessScore.improved,
        regressed: scoreResult.summary.perMetric.goalSuccessScore.regressed,
        unchanged: scoreResult.summary.perMetric.goalSuccessScore.unchanged,
      },
      helpfulness: {
        improved: scoreResult.summary.perMetric.helpfulnessScore.improved,
        regressed: scoreResult.summary.perMetric.helpfulnessScore.regressed,
        unchanged: scoreResult.summary.perMetric.helpfulnessScore.unchanged,
      },
      toolAccuracy: {
        improved: scoreResult.summary.perMetric.toolAccuracyScore.improved,
        regressed: scoreResult.summary.perMetric.toolAccuracyScore.regressed,
        unchanged: scoreResult.summary.perMetric.toolAccuracyScore.unchanged,
      },
    },
    configChanges,
  };
}

/** System prompt — instructs the model to ground every claim in the diff.
 *
 * The literal lives in the Prompt_Registry as `comparison_summary`
 * (`src/backend/orchestration/prompt-registry/prompts/comparison-summary.ts`)
 * and is resolved at request time via `resolvePromptLive("comparison_summary")`.
 */

function buildUserMessage(diff: SummaryDiffPayload): string {
  return [
    "Comparison diff (JSON):",
    JSON.stringify(diff, null, 2),
    "",
    "Summarise.",
  ].join("\n");
}

// ---------------------------------------------------------------------------
// Bedrock call
// ---------------------------------------------------------------------------

async function callBedrock(
  prompt: ResolvedPrompt,
  diff: SummaryDiffPayload,
): Promise<string> {
  const messages: Message[] = [
    {
      role: "user",
      content: [{ text: buildUserMessage(diff) }] as ContentBlock[],
    },
  ];

  // The wire-shape helper places `maxTokens` (and any future
  // capability-profile-accepted keys) into the exact arguments the
  // Converse SDK expects. For the `anthropic_claude_4x` profile this
  // emits `{ inferenceConfig: { maxTokens } }` with no `temperature`,
  // `topP`, `topK`, or `stopSequences` — those keys are forbidden by
  // the profile (R17.4) and the legacy literal `temperature: 0` value
  // would have been silently dropped at edit time by the validation
  // pipeline. Determinism is preserved in the typical Anthropic case
  // because Claude 4.x defaults to `temperature: 1` only when no
  // `temperature` is sent and the model's own deterministic-decode
  // behaviour for short, fully-grounded inputs is what backs this
  // endpoint's repeatability contract.
  const built = buildInferenceConfig(prompt);

  // The casts on `inferenceConfig` and `additionalModelRequestFields`
  // bridge the SDK's strict types (`InferenceConfiguration` for the
  // top-level config, `DocumentType` for the additional fields) and
  // our runtime payload — `buildInferenceConfig` already enforced the
  // exact key set against the resolved capability profile, so the
  // values are guaranteed JSON-encodable at runtime. Same pattern as
  // `prompts-validation.ts`'s dry-render builder.
  const command = new ConverseCommand({
    modelId: prompt.modelId,
    system: [{ text: prompt.text }],
    messages,
    inferenceConfig:
      built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(built.additionalModelRequestFields
      ? {
          additionalModelRequestFields:
            built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  const client = getBedrockClient();
  const resp = await client.send(command);

  const text = resp.output?.message?.content
    ?.map((b) => ("text" in b ? b.text ?? "" : ""))
    .join("");
  if (!text || text.trim().length === 0) {
    throw new Error("Bedrock returned an empty summary.");
  }
  return text.trim();
}

// ---------------------------------------------------------------------------
// Lambda handler
// ---------------------------------------------------------------------------

interface APIGatewayEventLite {
  httpMethod?: string;
  body?: string | null;
  resource?: string;
}

export async function handler(
  event: APIGatewayEventLite,
): Promise<{ statusCode: number; body: string; headers: Record<string, string> }> {
  // Preflight
  if (event.httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  if (event.httpMethod !== "POST") {
    return jsonResponse(405, {
      error: "MethodNotAllowed",
      message: `Method ${event.httpMethod ?? "GET"} not supported.`,
    });
  }

  let body: ComparisonSummaryRequest;
  try {
    body = JSON.parse(event.body ?? "{}");
  } catch {
    return jsonResponse(400, {
      error: "InvalidJson",
      message: "Request body must be valid JSON.",
    });
  }

  if (!body.runIdA || !body.runIdB) {
    return jsonResponse(400, {
      error: "MissingRunIds",
      message: "Both runIdA and runIdB are required in the request body.",
    });
  }
  if (body.runIdA === body.runIdB) {
    return jsonResponse(400, {
      error: "SameRunId",
      message: "runIdA and runIdB must be distinct.",
    });
  }

  try {
    const [aData, bData] = await Promise.all([
      loadRunData(body.runIdA, body.suiteId),
      loadRunData(body.runIdB, body.suiteId),
    ]);

    if (aData.results.length === 0 && bData.results.length === 0) {
      return jsonResponse(404, {
        error: "RunNotFound",
        message:
          "Neither run has any case results in DynamoDB. Verify the run ids.",
      });
    }

    // Sort earlier run as A, later run as B by start time so the diff
    // reads chronologically. Falls back to the request order when the
    // run records are missing.
    const aStart = aData.run?.startTime ?? "";
    const bStart = bData.run?.startTime ?? "";
    let earlier = { ...aData, runId: body.runIdA };
    let later = { ...bData, runId: body.runIdB };
    if (aStart && bStart && new Date(aStart).getTime() > new Date(bStart).getTime()) {
      earlier = { ...bData, runId: body.runIdB };
      later = { ...aData, runId: body.runIdA };
    }

    const diff = buildDiffPayload(earlier, later);
    // Resolve the live prompt (text, model id, and `maxTokens`) from
    // the registry. Fail-closed: if the override store read fails the
    // resolver throws `PromptResolutionError` and the catch below maps
    // it to a 500. Done after the DDB run reads complete so we don't
    // pay the registry round-trip on input-validation failures.
    const prompt = await resolvePromptLive("comparison_summary");
    // Trace line so operators can verify the override took effect
    // without having to inspect CloudTrail. The `version` is the
    // override's edit counter (0 for the bundled default, 1+ once a
    // user has saved an edit) so a stale Lambda warm cache is also
    // detectable from the log alone.
    console.info(
      `[comparison-summary] resolved prompt: modelKey=${prompt.modelKey} modelId=${prompt.modelId} version=${prompt.version}`,
    );
    const summary = await callBedrock(prompt, diff);

    const response: ComparisonSummaryResponse = {
      summary,
      runIdA: earlier.runId,
      runIdB: later.runId,
      modelId: prompt.modelId,
      generatedAt: new Date().toISOString(),
    };
    return jsonResponse(200, response);
  } catch (error) {
    const errorName = (error as { name?: string })?.name ?? "";
    const message =
      error instanceof Error ? error.message : "Unknown error";
    console.error(
      `[comparison-summary] failed: name=${errorName} message=${message}`,
    );
    if (errorName === "ThrottlingException") {
      return jsonResponse(429, {
        error: "ThrottlingException",
        message: "Bedrock rate limit hit. Retry shortly.",
        retryable: true,
        retryAfterSeconds: 5,
      });
    }
    if (errorName === "AccessDeniedException") {
      return jsonResponse(403, {
        error: "AccessDenied",
        message:
          "Comparison-summary Lambda lacks Bedrock permissions for the configured model.",
      });
    }
    return jsonResponse(500, {
      error: "InternalError",
      message,
      retryable: true,
    });
  }
}
