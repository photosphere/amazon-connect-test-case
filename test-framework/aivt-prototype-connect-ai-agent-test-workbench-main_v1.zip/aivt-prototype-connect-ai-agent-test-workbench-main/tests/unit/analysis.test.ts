/**
 * Unit tests for the Analysis Lambda handler.
 *
 * Two layers of coverage:
 *   1. Pure exported helpers — `groupFailuresByRootCause`,
 *      `parseAnalysisResponse`, `buildAnalysisPrompt`. These run with no
 *      AWS clients wired.
 *   2. The full `handler` exercised end-to-end with the Bedrock + DDB
 *      clients injected through `_setBedrockClient` / `_setDDBClient` so
 *      we can assert the persistence-aware control flow added in task 6:
 *      persisted-read shortcut, `force: true` overwrite, pre-feature
 *      record stability, persistence-failure surfacing, malformed-record
 *      drops, snapshot-examples-malformed → HTTP 500, prompt extensions,
 *      and the `ThrottlingException` retry / HTTP 503 posture.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";
import {
  ConverseCommand,
  type BedrockRuntimeClient,
} from "@aws-sdk/client-bedrock-runtime";
import {
  groupFailuresByRootCause,
  parseAnalysisResponse,
  buildAnalysisPrompt,
  handler,
  _setBedrockClient,
  _setDDBClient,
  type FailureCaseAnalysis,
  type Recommendation,
  type AnalysisResponse,
} from "../../src/backend/handlers/analysis";
import {
  buildInferenceConfig,
  resolvePrompt,
} from "../../src/backend/orchestration/prompt-registry";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";
import type { ToolDefinition, ToolSurface } from "../../src/shared/types";
import { CaseStatus } from "../../src/shared/enums";
import { SK_PATTERNS } from "../../src/shared/constants";

describe("Analysis Lambda", () => {
  describe("groupFailuresByRootCause", () => {
    it("returns empty when no analyses provided", () => {
      const { individual, grouped } = groupFailuresByRootCause([]);
      expect(individual).toEqual([]);
      expect(grouped).toEqual([]);
    });

    it("keeps single-occurrence categories as individual", () => {
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "case-1",
          rootCauseCategory: "overlapping_tool_descriptions",
          explanation: "Tools A and B overlap",
          traceAvailable: true,
          recommendations: [makeRec("tool_description", "ToolA")],
        },
        {
          caseId: "case-2",
          rootCauseCategory: "system_prompt_gap",
          explanation: "System prompt missing X",
          traceAvailable: true,
          recommendations: [makeRec("system_prompt", "system_prompt")],
        },
      ];

      const { individual, grouped } = groupFailuresByRootCause(analyses);
      expect(individual).toHaveLength(2);
      expect(grouped).toHaveLength(0);
      expect(individual.map((a) => a.caseId)).toContain("case-1");
      expect(individual.map((a) => a.caseId)).toContain("case-2");
    });

    it("groups 2+ failures with the same root cause category", () => {
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "case-1",
          rootCauseCategory: "overlapping_tool_descriptions",
          explanation: "Overlap between ToolA and ToolB",
          traceAvailable: true,
          recommendations: [makeRec("tool_description", "ToolA")],
        },
        {
          caseId: "case-2",
          rootCauseCategory: "overlapping_tool_descriptions",
          explanation: "Overlap between ToolA and ToolC",
          traceAvailable: false,
          recommendations: [makeRec("tool_description", "ToolA")],
        },
        {
          caseId: "case-3",
          rootCauseCategory: "system_prompt_gap",
          explanation: "Unique failure",
          traceAvailable: true,
          recommendations: [makeRec("system_prompt", "system_prompt")],
        },
      ];

      const { individual, grouped } = groupFailuresByRootCause(analyses);
      expect(individual).toHaveLength(1);
      expect(individual[0].caseId).toBe("case-3");
      expect(grouped).toHaveLength(1);
      expect(grouped[0].rootCauseCategory).toBe("overlapping_tool_descriptions");
      expect(grouped[0].caseIds).toEqual(["case-1", "case-2"]);
    });

    it("deduplicates recommendations within a group by targetField+targetName", () => {
      const sharedRec = makeRec("tool_description", "ToolA");
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "case-1",
          rootCauseCategory: "same_category",
          explanation: "Explanation 1",
          traceAvailable: true,
          recommendations: [sharedRec, makeRec("system_prompt", "system_prompt")],
        },
        {
          caseId: "case-2",
          rootCauseCategory: "same_category",
          explanation: "Explanation 2",
          traceAvailable: true,
          recommendations: [sharedRec],
        },
      ];

      const { grouped } = groupFailuresByRootCause(analyses);
      expect(grouped).toHaveLength(1);
      // Should deduplicate the shared rec
      expect(grouped[0].recommendations).toHaveLength(2);
      expect(grouped[0].recommendations[0].targetName).toBe("ToolA");
      expect(grouped[0].recommendations[1].targetName).toBe("system_prompt");
    });

    it("caps recommendations at 5 per group", () => {
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "case-1",
          rootCauseCategory: "same",
          explanation: "...",
          traceAvailable: true,
          recommendations: [
            makeRec("tool_description", "T1"),
            makeRec("tool_description", "T2"),
            makeRec("tool_description", "T3"),
          ],
        },
        {
          caseId: "case-2",
          rootCauseCategory: "same",
          explanation: "...",
          traceAvailable: true,
          recommendations: [
            makeRec("tool_description", "T4"),
            makeRec("tool_description", "T5"),
            makeRec("tool_description", "T6"),
          ],
        },
      ];

      const { grouped } = groupFailuresByRootCause(analyses);
      expect(grouped[0].recommendations.length).toBeLessThanOrEqual(5);
    });
  });

  describe("parseAnalysisResponse", () => {
    it("parses valid JSON response", () => {
      const json = JSON.stringify({
        rootCauseCategory: "overlapping_tool_descriptions",
        explanation: "The tools have overlapping descriptions causing confusion.",
        recommendations: [
          {
            targetField: "tool_description",
            targetName: "TransferFunds",
            currentText: "Transfer money to another account",
            suggestedText: "Transfer money between your own accounts only",
            rationale: "Disambiguate from PayBill",
          },
        ],
      });

      const result = parseAnalysisResponse(json);
      expect(result).not.toBeNull();
      expect(result!.rootCauseCategory).toBe("overlapping_tool_descriptions");
      expect(result!.recommendations).toHaveLength(1);
      expect(result!.recommendations[0].targetField).toBe("tool_description");
    });

    it("handles markdown-fenced JSON", () => {
      const response = `\`\`\`json
{
  "rootCauseCategory": "system_prompt_gap",
  "explanation": "Missing disambiguation guidance.",
  "recommendations": [
    {
      "targetField": "system_prompt",
      "targetName": "system_prompt",
      "currentText": "Help users with banking.",
      "suggestedText": "Help users with banking. When both TransferFunds and PayBill could apply, prefer PayBill for recipient-based transfers.",
      "rationale": "Add disambiguation rule."
    }
  ]
}
\`\`\``;

      const result = parseAnalysisResponse(response);
      expect(result).not.toBeNull();
      expect(result!.rootCauseCategory).toBe("system_prompt_gap");
    });

    it("returns null for invalid JSON", () => {
      expect(parseAnalysisResponse("not json at all")).toBeNull();
    });

    it("returns null when required fields are missing", () => {
      const json = JSON.stringify({ foo: "bar" });
      expect(parseAnalysisResponse(json)).toBeNull();
    });

    it("clamps recommendations to max 5", () => {
      const recommendations = Array.from({ length: 8 }, (_, i) => ({
        targetField: "tool_description",
        targetName: `Tool${i}`,
        currentText: "old",
        suggestedText: "new",
        rationale: "reason",
      }));
      const json = JSON.stringify({
        rootCauseCategory: "test",
        explanation: "test",
        recommendations,
      });

      const result = parseAnalysisResponse(json);
      expect(result).not.toBeNull();
      expect(result!.recommendations).toHaveLength(5);
    });

    it("adds fallback recommendation when none provided", () => {
      const json = JSON.stringify({
        rootCauseCategory: "other",
        explanation: "Something went wrong.",
        recommendations: [],
      });

      const result = parseAnalysisResponse(json);
      expect(result).not.toBeNull();
      expect(result!.recommendations).toHaveLength(1);
      expect(result!.recommendations[0].targetField).toBe("system_prompt");
    });

    it("filters out malformed recommendations", () => {
      const json = JSON.stringify({
        rootCauseCategory: "test",
        explanation: "test",
        recommendations: [
          { targetField: "tool_description" }, // missing required fields
          {
            targetField: "tool_description",
            targetName: "ValidTool",
            currentText: "old",
            suggestedText: "new",
          },
        ],
      });

      const result = parseAnalysisResponse(json);
      expect(result).not.toBeNull();
      expect(result!.recommendations).toHaveLength(1);
      expect(result!.recommendations[0].targetName).toBe("ValidTool");
    });
  });

  describe("buildAnalysisPrompt", () => {
    it("includes transcript, expected tools, actual tools, and agent tools", () => {
      const prompt = buildAnalysisPrompt({
        caseId: "case-123",
        testCaseDefinition: null,
        transcript: [
          {
            turnNumber: 1,
            role: "customer",
            text: "I want to transfer money",
            timestamp: "2024-01-01T00:00:00Z",
            elapsedMs: 100,
          },
          {
            turnNumber: 2,
            role: "agent",
            text: "I can help with that.",
            toolSelected: "PayBill",
            timestamp: "2024-01-01T00:00:01Z",
            elapsedMs: 200,
          },
        ],
        reasoningTrace: {
          sessionId: "session-abc",
          aiAgentName: "TestBank",
          aiAgentType: "ORCHESTRATION",
          toolSequence: ["PayBill"],
          capturedAt: "2024-01-01T00:00:05Z",
          steps: [
            {
              index: 0,
              type: "inference",
              spanName: "inference",
              text: "The customer wants a transfer; PayBill also mentions transfers so I'll use it.",
            },
            {
              index: 1,
              type: "tool",
              spanName: "execute_tool",
              tool: {
                toolName: "PayBill",
                arguments: { recipient: "savings" },
                result: { status: "success" },
                success: true,
              },
            },
          ],
        },
        expectedTools: ["TransferFunds"],
        actualTools: ["PayBill"],
        agentTools: [
          {
            toolName: "TransferFunds",
            toolType: "FUNCTION",
            description: "Transfer money between accounts",
            inputSchema: {},
            examples: [],
          },
          {
            toolName: "PayBill",
            toolType: "FUNCTION",
            description: "Pay a bill or send money to a recipient",
            inputSchema: {},
            examples: [],
          },
        ],
        systemPrompt: "You are a banking assistant.",
      });

      expect(prompt).toContain("case-123");
      expect(prompt).toContain("I want to transfer money");
      expect(prompt).toContain("PayBill");
      expect(prompt).toContain("TransferFunds");
      expect(prompt).toContain("Transfer money between accounts");
      expect(prompt).toContain("PayBill also mentions transfers");
      expect(prompt).toContain("TestBank");
      expect(prompt).toContain("Expected Tool Sequence");
      expect(prompt).not.toContain("Reasoning trace is unavailable");
    });

    it("handles missing reasoning trace gracefully (Req 12.7)", () => {
      const prompt = buildAnalysisPrompt({
        caseId: "case-456",
        testCaseDefinition: null,
        transcript: [
          {
            turnNumber: 1,
            role: "customer",
            text: "Hello",
            timestamp: "2024-01-01T00:00:00Z",
            elapsedMs: 50,
          },
        ],
        reasoningTrace: null,
        expectedTools: ["ToolA"],
        actualTools: [],
        agentTools: [],
        systemPrompt: "Test prompt",
      });

      expect(prompt).toContain("Reasoning trace unavailable");
      expect(prompt).toContain("trace evidence was unavailable");
    });

    it("handles empty transcript", () => {
      const prompt = buildAnalysisPrompt({
        caseId: "case-789",
        testCaseDefinition: null,
        transcript: [],
        reasoningTrace: null,
        expectedTools: [],
        actualTools: [],
        agentTools: [],
        systemPrompt: "System prompt",
      });

      expect(prompt).toContain("(empty transcript)");
    });
  });
});

// Helper to create a recommendation fixture
function makeRec(targetField: ToolSurface, targetName: string): Recommendation {
  return {
    targetField,
    targetName,
    currentText: `current text for ${targetName}`,
    suggestedText: `suggested text for ${targetName}`,
    rationale: `Fix ${targetName}`,
  };
}

// ---------------------------------------------------------------------------
// Prompt extension tests (R14.1, R14.2, R14.3)
// ---------------------------------------------------------------------------

describe("buildAnalysisPrompt — Examples block & operations clause", () => {
  it("renders the literal 'Examples:' line for every tool (R14.1)", () => {
    const tools: ToolDefinition[] = [
      {
        toolName: "ToolA",
        toolType: "FUNCTION",
        description: "Does A",
        instruction: "Use A first",
        inputSchema: {},
        examples: ["call ToolA when X happens"],
      },
      {
        toolName: "ToolB",
        toolType: "FUNCTION",
        description: "Does B",
        // No instruction — Examples block must still render directly after Description.
        inputSchema: {},
        examples: ["call ToolB when Y", "or when Z"],
      },
    ];

    const prompt = buildAnalysisPrompt({
      caseId: "case-x",
      testCaseDefinition: null,
      transcript: [],
      reasoningTrace: null,
      expectedTools: [],
      actualTools: [],
      agentTools: tools,
      systemPrompt: "sp",
    });

    // Every tool gets an Examples: line. Two tools → two Examples: lines.
    const examplesLineCount = (prompt.match(/^\s*Examples:/gm) ?? []).length;
    expect(examplesLineCount).toBe(2);

    // Numbered example lines render verbatim with the leading "  1. " /
    // "  2. " formatting from formatTools.
    expect(prompt).toContain("    1. call ToolA when X happens");
    expect(prompt).toContain("    1. call ToolB when Y");
    expect(prompt).toContain("    2. or when Z");
  });

  it("renders 'Examples: (none)' for empty arrays (R14.2)", () => {
    const prompt = buildAnalysisPrompt({
      caseId: "case-empty",
      testCaseDefinition: null,
      transcript: [],
      reasoningTrace: null,
      expectedTools: [],
      actualTools: [],
      agentTools: [
        {
          toolName: "EmptyTool",
          toolType: "FUNCTION",
          description: "no examples configured",
          inputSchema: {},
          examples: [],
        },
      ],
      systemPrompt: "sp",
    });

    expect(prompt).toContain("Examples: (none)");
    // Sanity: no numbered example list for the empty tool.
    expect(prompt).not.toMatch(/^\s+1\. /m);
  });

  it("contains the three-operations clause for tool_examples (R14.3)", () => {
    const prompt = buildAnalysisPrompt({
      caseId: "case-ops",
      testCaseDefinition: null,
      transcript: [],
      reasoningTrace: null,
      expectedTools: [],
      actualTools: [],
      agentTools: [],
      systemPrompt: "sp",
    });

    // The instructions block enumerates all five valid targetField values.
    expect(prompt).toContain("`tool_description`");
    expect(prompt).toContain("`tool_instruction`");
    expect(prompt).toContain("`tool_examples`");
    expect(prompt).toContain("`system_prompt`");
    expect(prompt).toContain("`test_case`");

    // The three operations are explicitly listed: add, remove, replace.
    expect(prompt).toContain("three operations");
    expect(prompt).toMatch(/\(1\)\s*\*\*add\*\*/);
    expect(prompt).toMatch(/\(2\)\s*\*\*remove\*\*/);
    expect(prompt).toMatch(/\(3\)\s*\*\*replace\*\*/);

    // Exact-string-match rule for remove/replace is present.
    expect(prompt).toContain("character-for-character");
  });
});

// ---------------------------------------------------------------------------
// Handler-level integration with mocked Bedrock + DDB clients
// ---------------------------------------------------------------------------

/**
 * Build a {@link DynamoDBDocumentClient}-shaped mock that dispatches `send`
 * calls based on the AWS SDK command class and the partition/sort keys
 * carried on the command's `input`. Returns the mock plus the underlying
 * `vi.fn()` so tests can assert call counts and inspect the payloads
 * persisted via `PutCommand`.
 */
interface DDBMockState {
  failedResults: Record<string, unknown>[];
  snapshot: Record<string, unknown> | null;
  persistedAnalyses: Record<string, unknown>[];
  transcriptByCaseId: Record<string, Record<string, unknown>[]>;
  traceByCaseId: Record<string, Record<string, unknown> | null>;
  /** Fail every PutCommand when true (simulates DDB write failure). */
  putThrows?: boolean;
}

function makeDDBMock(state: DDBMockState): {
  client: DynamoDBDocumentClient;
  send: ReturnType<typeof vi.fn>;
  puts: Array<Record<string, unknown>>;
} {
  const puts: Array<Record<string, unknown>> = [];
  const send = vi.fn().mockImplementation(async (cmd: unknown) => {
    if (cmd instanceof QueryCommand) {
      const values = cmd.input.ExpressionAttributeValues ?? {};
      const pk = String(values[":pk"] ?? "");
      const skPrefix = String(values[":skPrefix"] ?? "");
      // Failed-results query: PK=RUN#<id>, SK begins_with CASE#
      if (skPrefix === "CASE#" && pk.startsWith("RUN#") && !pk.includes("#CASE#")) {
        return { Items: state.failedResults };
      }
      // Persisted per-case analyses query: PK=RUN#<id>, SK begins_with ANALYSIS#CASE#
      if (skPrefix === "ANALYSIS#CASE#") {
        return { Items: state.persistedAnalyses };
      }
      // Transcript query: PK=RUN#<id>#CASE#<caseId>, SK begins_with TURN#
      if (skPrefix === "TURN#") {
        const match = pk.match(/^RUN#[^#]+#CASE#(.+)$/);
        const caseId = match?.[1] ?? "";
        return { Items: state.transcriptByCaseId[caseId] ?? [] };
      }
      // Suite-cases query: PK=SUITE#<id> — not exercised by these tests
      // because we omit `suiteId` on the request body. Return empty for
      // safety so any future change does not throw.
      if (skPrefix === "CASE#" && pk.startsWith("SUITE#")) {
        return { Items: [] };
      }
      return { Items: [] };
    }
    if (cmd instanceof GetCommand) {
      const sk = String(cmd.input.Key?.SK ?? "");
      const pk = String(cmd.input.Key?.PK ?? "");
      if (sk === SK_PATTERNS.SNAPSHOT) {
        return state.snapshot ? { Item: state.snapshot } : { Item: undefined };
      }
      if (sk === SK_PATTERNS.TRACE) {
        const match = pk.match(/^RUN#[^#]+#CASE#(.+)$/);
        const caseId = match?.[1] ?? "";
        const trace = state.traceByCaseId[caseId];
        return trace ? { Item: trace } : { Item: undefined };
      }
      return { Item: undefined };
    }
    if (cmd instanceof PutCommand) {
      if (state.putThrows) {
        throw new Error("Simulated DDB write failure");
      }
      puts.push(cmd.input.Item as Record<string, unknown>);
      return {};
    }
    return {};
  });

  const client = { send } as unknown as DynamoDBDocumentClient;
  return { client, send, puts };
}

/**
 * Build a Bedrock mock whose `send` returns a ConverseCommand-shaped
 * response carrying the provided JSON body as the model's reply.
 */
function makeBedrockClient(
  responseProducer: (callIndex: number) => string | Error,
): {
  client: BedrockRuntimeClient;
  send: ReturnType<typeof vi.fn>;
} {
  let callIndex = 0;
  const send = vi.fn().mockImplementation(async () => {
    const next = responseProducer(callIndex);
    callIndex += 1;
    if (next instanceof Error) {
      throw next;
    }
    return {
      output: { message: { content: [{ text: next }] } },
    };
  });
  return {
    client: { send } as unknown as BedrockRuntimeClient,
    send,
  };
}

/** Build a failed-case row matching the shape `getFailedResults` returns. */
function failedCaseRow(caseId: string): Record<string, unknown> {
  return {
    PK: `RUN#run-1`,
    SK: `CASE#${caseId}`,
    runId: "run-1",
    caseId,
    status: CaseStatus.FAILED,
    toolsInvoked: ["WrongTool"],
    turnCount: 3,
    latencyMs: 1234,
  };
}

/** Build a snapshot row that the `getAgentSnapshot` helper accepts. */
function snapshotRow(
  tools: Array<Record<string, unknown>>,
): Record<string, unknown> {
  return {
    PK: `RUN#run-1`,
    SK: SK_PATTERNS.SNAPSHOT,
    tools,
    systemPrompt: "You are a banking assistant.",
    modelId: "anthropic.claude-sonnet-4-6",
    capturedAt: "2024-06-01T00:00:00Z",
  };
}

/** Build a persisted per-case analysis row (the shape DDB returns from Query). */
function persistedAnalysisRow(args: {
  caseId: string;
  generatedAt: string;
  recommendations?: Recommendation[];
  rootCauseCategory?: string;
}): Record<string, unknown> {
  return {
    PK: `RUN#run-1`,
    SK: `ANALYSIS#CASE#${args.caseId}`,
    caseId: args.caseId,
    rootCauseCategory: args.rootCauseCategory ?? "system_prompt_gap",
    explanation: `Persisted explanation for ${args.caseId}`,
    traceAvailable: true,
    recommendations: args.recommendations ?? [
      {
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "old prompt",
        suggestedText: "new prompt",
        rationale: "tighten the prompt",
      },
    ],
    generatedAt: args.generatedAt,
    modelId: "anthropic.claude-sonnet-4-6",
  };
}

/** Standard valid Bedrock JSON reply for one analysis. */
function freshAnalysisJson(args?: {
  rootCauseCategory?: string;
  recommendations?: Array<Record<string, unknown>>;
}): string {
  return JSON.stringify({
    rootCauseCategory: args?.rootCauseCategory ?? "system_prompt_gap",
    explanation: "Fresh explanation generated by Bedrock for this case.",
    recommendations: args?.recommendations ?? [
      {
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "old prompt",
        suggestedText: "new prompt",
        rationale: "tighten the prompt",
      },
    ],
  });
}

describe("Analysis Lambda handler — persistence & control flow", () => {
  // Pin Math.random so the throttle-retry backoff (`Math.random() * delay`)
  // resolves with zero delay. Keeps the throttle posture test fast and
  // deterministic; the calculation under test is the retry COUNT, not the
  // wall-clock backoff.
  beforeEach(() => {
    vi.spyOn(Math, "random").mockReturnValue(0);

    // Inject a stub Prompts_Store so `resolvePromptLive("failure_analysis")`
    // returns the registry's bundled default triple instead of attempting
    // a real DynamoDB read. The handler executes outside any run scope,
    // so only `listPromptOverrides` is consulted; `getSnapshot` is wired
    // for symmetry but never called on this path.
    _clearPromptRegistryCaches();
    const promptStore = {
      listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
      getSnapshot: vi.fn().mockResolvedValue(null),
    } as unknown as DynamoDBService;
    _setPromptRegistryStore(promptStore);
  });

  afterEach(() => {
    _setBedrockClient(null);
    _setDDBClient(null);
    _setPromptRegistryStore(null);
    _clearPromptRegistryCaches();
    vi.restoreAllMocks();
  });

  // -------------------------------------------------------------------------
  // R6.2 — Persisted-read shortcut
  // -------------------------------------------------------------------------

  it("returns persisted records without invoking Bedrock when count matches failed cases (R6.2)", async () => {
    const persistedAt = "2024-06-15T10:00:00Z";
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1"), failedCaseRow("case-2")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          examples: [],
        },
      ]),
      persistedAnalyses: [
        persistedAnalysisRow({ caseId: "case-1", generatedAt: persistedAt }),
        persistedAnalysisRow({ caseId: "case-2", generatedAt: persistedAt }),
      ],
      transcriptByCaseId: {},
      traceByCaseId: {},
    });
    const bedrock = makeBedrockClient(() => freshAnalysisJson());

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    const response = await handler({ pathParameters: { runId: "run-1" } });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body) as AnalysisResponse;
    expect(body.caseAnalyses).toHaveLength(2);
    // Original `generatedAt` is preserved verbatim.
    expect(body.caseAnalyses.map((c) => c.generatedAt)).toEqual([
      persistedAt,
      persistedAt,
    ]);
    expect(body.caseAnalyses.map((c) => c.caseId).sort()).toEqual([
      "case-1",
      "case-2",
    ]);
    // Bedrock is NOT invoked on the shortcut path.
    expect(bedrock.send).not.toHaveBeenCalled();
    // No new PutCommand is issued — the cached records are returned as-is.
    expect(ddb.puts).toHaveLength(0);
  });

  // -------------------------------------------------------------------------
  // R6.3 — `force: true` overwrites persisted records
  // -------------------------------------------------------------------------

  it("invokes Bedrock and overwrites persisted records when force=true (R6.3)", async () => {
    const oldGeneratedAt = "2024-06-15T10:00:00Z";
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          examples: [],
        },
      ]),
      persistedAnalyses: [
        persistedAnalysisRow({ caseId: "case-1", generatedAt: oldGeneratedAt }),
      ],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: {},
    });
    const bedrock = makeBedrockClient(() =>
      freshAnalysisJson({ rootCauseCategory: "incomplete_tool_description" }),
    );

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    const response = await handler({
      pathParameters: { runId: "run-1" },
      body: JSON.stringify({ force: true }),
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body) as AnalysisResponse;
    expect(body.caseAnalyses).toHaveLength(1);
    // Bedrock IS invoked despite the persisted record existing.
    expect(bedrock.send).toHaveBeenCalledTimes(1);
    // The fresh analysis carries the new root cause category, not the
    // persisted one ("system_prompt_gap").
    expect(body.caseAnalyses[0].rootCauseCategory).toBe(
      "incomplete_tool_description",
    );
    // generatedAt is updated — strictly newer than the persisted timestamp.
    expect(body.caseAnalyses[0].generatedAt > oldGeneratedAt).toBe(true);
    // The Put overwrite was issued for case-1.
    expect(ddb.puts).toHaveLength(1);
    expect(ddb.puts[0].SK).toBe("ANALYSIS#CASE#case-1");
  });

  // -------------------------------------------------------------------------
  // Converse wire-shape assertion (Wave 1 migration — Task 15.5)
  // -------------------------------------------------------------------------

  it("issues Converse with the inferenceConfig and modelId from the resolved failure_analysis prompt", async () => {
    // The handler must hand `ConverseCommand` exactly the wire shape
    // `buildInferenceConfig` produces for the resolved prompt — no
    // legacy `temperature: 0.2` literal, no missing `maxTokens` cap.
    // Compute the expected shape from the registry directly.
    const prompt = resolvePrompt("failure_analysis", new Map());
    const expected = buildInferenceConfig(prompt);

    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          examples: [],
        },
      ]),
      persistedAnalyses: [],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: {},
    });
    const bedrock = makeBedrockClient(() => freshAnalysisJson());

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    const response = await handler({ pathParameters: { runId: "run-1" } });
    expect(response.statusCode).toBe(200);

    expect(bedrock.send).toHaveBeenCalledTimes(1);
    const cmd = bedrock.send.mock.calls[0][0] as ConverseCommand;
    expect(cmd).toBeInstanceOf(ConverseCommand);
    expect(cmd.input.modelId).toBe(prompt.modelId);
    expect(cmd.input.inferenceConfig).toEqual(expected.inferenceConfig);
    // `anthropic_claude_4x` profile — no additional model request fields.
    expect(cmd.input.additionalModelRequestFields).toBeUndefined();
    // System prompt text comes from the registry — not a literal in the
    // handler.
    expect(cmd.input.system).toEqual([{ text: prompt.text }]);
  });

  // -------------------------------------------------------------------------
  // R6.4 — Pre-feature record (no tool_examples recommendations) is stable
  // -------------------------------------------------------------------------

  it("returns a pre-feature persisted record (no tool_examples recs) unchanged (R6.4)", async () => {
    const persistedAt = "2024-05-01T00:00:00Z";
    // A "pre-feature" persisted record: no `tool_examples` recommendation
    // among its recs (only the surfaces that existed before the feature).
    const preFeatureRecs: Recommendation[] = [
      {
        targetField: "tool_description",
        targetName: "ToolA",
        currentText: "old description",
        suggestedText: "new description",
        rationale: "clarify",
      },
      {
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "old prompt",
        suggestedText: "new prompt",
        rationale: "tighten",
      },
    ];

    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          examples: [],
        },
      ]),
      persistedAnalyses: [
        persistedAnalysisRow({
          caseId: "case-1",
          generatedAt: persistedAt,
          recommendations: preFeatureRecs,
        }),
      ],
      transcriptByCaseId: {},
      traceByCaseId: {},
    });
    const bedrock = makeBedrockClient(() => freshAnalysisJson());

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    const response = await handler({ pathParameters: { runId: "run-1" } });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body) as AnalysisResponse;
    expect(body.caseAnalyses).toHaveLength(1);
    // Recommendations returned verbatim — no silent regeneration.
    expect(body.caseAnalyses[0].recommendations).toEqual(preFeatureRecs);
    expect(body.caseAnalyses[0].generatedAt).toBe(persistedAt);
    // No Bedrock call, no Put.
    expect(bedrock.send).not.toHaveBeenCalled();
    expect(ddb.puts).toHaveLength(0);
  });

  // -------------------------------------------------------------------------
  // R6.6 — Persistence failure surfaces on partialFailures
  // -------------------------------------------------------------------------

  it("returns HTTP 200 with partialFailures when DDB write fails (R6.6)", async () => {
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          examples: [],
        },
      ]),
      persistedAnalyses: [],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: {},
      putThrows: true,
    });
    const bedrock = makeBedrockClient(() => freshAnalysisJson());

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    // Quiet the expected console.error from the persistence failure path.
    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    const response = await handler({ pathParameters: { runId: "run-1" } });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body) as AnalysisResponse;
    // The analysis content is still returned to the caller…
    expect(body.caseAnalyses).toHaveLength(1);
    expect(body.caseAnalyses[0].caseId).toBe("case-1");
    // …and the failed case ID surfaces on partialFailures.
    expect(body.partialFailures).toEqual(["case-1"]);

    errSpy.mockRestore();
  });

  // -------------------------------------------------------------------------
  // R5.9 / R13.3 — Drop malformed recommendations before persistence
  // -------------------------------------------------------------------------

  it("drops recommendations with invalid targetField, empty targetName, or both texts empty (R5.9, R13.3)", async () => {
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          examples: [],
        },
      ]),
      persistedAnalyses: [],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: {},
    });
    // Bedrock returns four recs: one valid, three malformed (one for each
    // drop rule). The malformed ones must NOT survive into the persisted
    // record or the response.
    const bedrock = makeBedrockClient(() =>
      freshAnalysisJson({
        recommendations: [
          {
            targetField: "tool_description",
            targetName: "ToolA",
            currentText: "old",
            suggestedText: "new",
            rationale: "valid",
          },
          {
            // R5.9: targetField is not one of the four ToolSurface values.
            targetField: "tool_definition",
            targetName: "ToolA",
            currentText: "old",
            suggestedText: "new",
            rationale: "invalid surface",
          },
          {
            // R13.3: empty targetName.
            targetField: "tool_description",
            targetName: "   ",
            currentText: "old",
            suggestedText: "new",
            rationale: "empty name",
          },
          {
            // R13.3: both currentText and suggestedText empty (no-op).
            targetField: "system_prompt",
            targetName: "system_prompt",
            currentText: "",
            suggestedText: "",
            rationale: "no-op",
          },
        ],
      }),
    );

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

    const response = await handler({ pathParameters: { runId: "run-1" } });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body) as AnalysisResponse;
    expect(body.caseAnalyses).toHaveLength(1);
    // Only the one valid recommendation survives.
    expect(body.caseAnalyses[0].recommendations).toHaveLength(1);
    expect(body.caseAnalyses[0].recommendations[0]).toMatchObject({
      targetField: "tool_description",
      targetName: "ToolA",
    });
    // The persisted record (PutCommand item) carries the same survivors.
    expect(ddb.puts).toHaveLength(1);
    const persistedRecs = (ddb.puts[0].recommendations ?? []) as Recommendation[];
    expect(persistedRecs).toHaveLength(1);
    expect(persistedRecs[0].targetName).toBe("ToolA");
    // Each dropped record is logged for diagnostics (3 drops → 3 warns).
    expect(warnSpy).toHaveBeenCalledTimes(3);

    warnSpy.mockRestore();
  });

  // -------------------------------------------------------------------------
  // R5.8 — Snapshot examples malformed
  // -------------------------------------------------------------------------

  it("returns HTTP 500 with snapshot_examples_malformed when a tool's examples is non-array (R5.8)", async () => {
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          // Malformed: present but not an array.
          examples: 42,
        },
      ]),
      persistedAnalyses: [],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: {},
    });
    const bedrock = makeBedrockClient(() => freshAnalysisJson());

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    const response = await handler({ pathParameters: { runId: "run-1" } });

    expect(response.statusCode).toBe(500);
    const body = JSON.parse(response.body);
    expect(body).toEqual({
      error: "snapshot_examples_malformed",
      toolName: "ToolA",
    });
    // Bedrock must NOT be invoked on a malformed-snapshot abort.
    expect(bedrock.send).not.toHaveBeenCalled();
  });

  // -------------------------------------------------------------------------
  // R12.1 / R12.2 — Throttle posture: retry then terminal
  // -------------------------------------------------------------------------

  it("retries ThrottlingException up to 2 times then succeeds (R12.1)", async () => {
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          examples: [],
        },
      ]),
      persistedAnalyses: [],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: {},
    });
    // First 2 calls throttle, third succeeds.
    const bedrock = makeBedrockClient((i) => {
      if (i < 2) {
        const err = new Error("rate limit") as Error & { name: string };
        err.name = "ThrottlingException";
        return err;
      }
      return freshAnalysisJson();
    });

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    const response = await handler({ pathParameters: { runId: "run-1" } });

    expect(response.statusCode).toBe(200);
    // 1 initial + 2 retries = 3 send calls before success.
    expect(bedrock.send).toHaveBeenCalledTimes(3);
    const body = JSON.parse(response.body) as AnalysisResponse;
    expect(body.caseAnalyses).toHaveLength(1);
  });

  it("returns HTTP 503 retryable=true on terminal ThrottlingException (R12.2)", async () => {
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          toolName: "ToolA",
          toolType: "FUNCTION",
          description: "Does A",
          inputSchema: {},
          examples: [],
        },
      ]),
      persistedAnalyses: [],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: {},
    });
    // Always throttle — terminal after 1 + 2 = 3 attempts.
    const bedrock = makeBedrockClient(() => {
      const err = new Error("rate limit") as Error & { name: string };
      err.name = "ThrottlingException";
      return err;
    });

    _setDDBClient(ddb.client);
    _setBedrockClient(bedrock.client);

    const errSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    const response = await handler({ pathParameters: { runId: "run-1" } });

    expect(response.statusCode).toBe(503);
    const body = JSON.parse(response.body);
    expect(body.error).toBe("ThrottlingException");
    expect(body.retryable).toBe(true);
    // 1 initial + 2 retries = 3 send calls; no further attempts.
    expect(bedrock.send).toHaveBeenCalledTimes(3);
    // Persistence is not attempted on terminal throttle.
    expect(ddb.puts).toHaveLength(0);

    errSpy.mockRestore();
  });

  // -------------------------------------------------------------------------
  // R10.1, R10.2, R10.4 — Persistence of testCaseField and testCaseDefect
  // -------------------------------------------------------------------------

  it("persists testCaseDefect: true and testCaseField on recommendations when rootCauseCategory is test_case_defect", async () => {
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          name: "TransferCall",
          description: "Transfers the call",
          instruction: "Use when caller requests transfer",
          examples: [],
        },
      ]),
      persistedAnalyses: [],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: { "case-1": null },
    });
    _setDDBClient(ddb.client);

    // Bedrock returns a test_case_defect analysis with a test_case rec
    const bedrock = makeBedrockClient(() =>
      JSON.stringify({
        rootCauseCategory: "test_case_defect",
        explanation:
          "The agent correctly refused to transfer without confirmation. Trace: 'I cannot transfer without user consent per my instructions.'",
        recommendations: [
          {
            targetField: "test_case",
            targetName: "case-1",
            currentText: "1. TransferCall (required: true)",
            suggestedText:
              "1. ConfirmTransfer (required: true)\n2. TransferCall (required: true)",
            rationale:
              "The success criteria should include a confirmation step before transfer.",
            testCaseField: "successCriteria",
          },
        ],
      }),
    );
    _setBedrockClient(bedrock.client);

    const response = await handler({
      pathParameters: { runId: "run-1" },
      body: JSON.stringify({ suiteId: "suite-1" }),
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body) as AnalysisResponse;
    expect(body.caseAnalyses).toHaveLength(1);

    const caseAnalysis = body.caseAnalyses[0];
    expect(caseAnalysis.rootCauseCategory).toBe("test_case_defect");
    expect(caseAnalysis.testCaseDefect).toBe(true);
    expect(caseAnalysis.recommendations).toHaveLength(1);
    expect(caseAnalysis.recommendations[0].targetField).toBe("test_case");
    expect(caseAnalysis.recommendations[0].testCaseField).toBe(
      "successCriteria",
    );

    // Verify the DDB PutCommand payload carries both testCaseDefect and testCaseField
    expect(ddb.puts).toHaveLength(1);
    const persistedItem = ddb.puts[0];
    expect(persistedItem.testCaseDefect).toBe(true);
    const persistedRecs = persistedItem.recommendations as Recommendation[];
    expect(persistedRecs).toHaveLength(1);
    expect(persistedRecs[0].targetField).toBe("test_case");
    expect(persistedRecs[0].testCaseField).toBe("successCriteria");
    expect(persistedRecs[0].targetName).toBe("case-1");
    expect(persistedRecs[0].currentText).toBe(
      "1. TransferCall (required: true)",
    );
    expect(persistedRecs[0].suggestedText).toBe(
      "1. ConfirmTransfer (required: true)\n2. TransferCall (required: true)",
    );
    expect(persistedRecs[0].rationale).toBe(
      "The success criteria should include a confirmation step before transfer.",
    );
  });

  it("does NOT persist testCaseDefect when rootCauseCategory is not test_case_defect", async () => {
    const ddb = makeDDBMock({
      failedResults: [failedCaseRow("case-1")],
      snapshot: snapshotRow([
        {
          name: "TransferCall",
          description: "Transfers the call",
          instruction: "Use when caller requests transfer",
          examples: [],
        },
      ]),
      persistedAnalyses: [],
      transcriptByCaseId: { "case-1": [] },
      traceByCaseId: { "case-1": null },
    });
    _setDDBClient(ddb.client);

    const bedrock = makeBedrockClient(() =>
      JSON.stringify({
        rootCauseCategory: "system_prompt_gap",
        explanation: "The system prompt lacks clarity about transfer policy.",
        recommendations: [
          {
            targetField: "system_prompt",
            targetName: "system_prompt",
            currentText: "old prompt",
            suggestedText: "new prompt with transfer policy",
            rationale: "Add explicit transfer policy to the system prompt.",
          },
        ],
      }),
    );
    _setBedrockClient(bedrock.client);

    const response = await handler({
      pathParameters: { runId: "run-1" },
      body: JSON.stringify({ suiteId: "suite-1" }),
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body) as AnalysisResponse;
    expect(body.caseAnalyses[0].rootCauseCategory).toBe("system_prompt_gap");
    expect(body.caseAnalyses[0].testCaseDefect).toBeUndefined();

    // DDB record should NOT have testCaseDefect field
    expect(ddb.puts).toHaveLength(1);
    expect(ddb.puts[0]).not.toHaveProperty("testCaseDefect");
  });
});
