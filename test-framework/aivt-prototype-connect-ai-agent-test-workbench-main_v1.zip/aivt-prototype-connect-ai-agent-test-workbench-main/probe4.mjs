// Option 1 test: bind a REAL (synthetic) Connect contact to the Q in Connect
// session via CreateSession.contactArn, then check whether verifyIdentity succeeds.
import {
  QConnectClient,
  CreateSessionCommand,
  SendMessageCommand,
  GetNextMessageCommand,
  ListSpansCommand,
  UpdateSessionDataCommand,
} from "@aws-sdk/client-qconnect";

const REGION = "us-east-1";
const ASSISTANT_ID = "5664eea5-381d-468e-bfba-302b69ae6dec";
const INSTANCE_ID = "46837cc7-8562-4b3f-92b2-1bae0ede624b";
const ANYBANK = "d54d3dee-b9ec-415a-9a4b-b4769426f365";

// Real contact ARN minted via StartChatContact.
const CONTACT_ID = process.argv[2];
if (!CONTACT_ID) {
  console.error("usage: node probe4.mjs <contactId>");
  process.exit(1);
}
const CONTACT_ARN = `arn:aws:connect:${REGION}:104220062740:instance/${INSTANCE_ID}/contact/${CONTACT_ID}`;

const UTTERANCE =
  "Hi, my phone number is 407 462 9069 and the last four of my SSN is 1234. Can you pull up my mortgage and tell me my interest rate?";

const client = new QConnectClient({ region: REGION });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function drive(sessionId, token) {
  let cur = token;
  const start = Date.now();
  while (Date.now() - start < 30000) {
    const r = await client.send(
      new GetNextMessageCommand({ assistantId: ASSISTANT_ID, sessionId, nextMessageToken: cur })
    );
    const status = r.conversationState?.status;
    const v = r.response?.value;
    const txt = v && "text" in v ? v.text?.value : "";
    if (txt && txt.trim() && !["...", "......", "\u2026"].includes(txt.trim()))
      console.log(`  [agent] ${txt.trim().slice(0, 100)}`);
    cur = r.nextMessageToken ?? cur;
    if (status === "CLOSED") break;
    await sleep(500);
  }
}

async function spanSummary(sessionId) {
  let nextToken;
  const tools = [];
  do {
    const resp = await client.send(
      new ListSpansCommand({ assistantId: ASSISTANT_ID, sessionId, nextToken, maxResults: 100 })
    );
    for (const s of resp.spans ?? []) {
      const a = s.attributes ?? {};
      if (s.spanName === "execute_tool") {
        let name = "?", result = "";
        for (const im of a.inputMessages ?? [])
          for (const v of im.values ?? []) if (v.toolUse) name = v.toolUse.name;
        for (const om of a.outputMessages ?? [])
          for (const v of om.values ?? [])
            if (v.toolResult) result = v.toolResult.values?.[0]?.text?.value ?? "";
        tools.push({ name, result });
      }
    }
    nextToken = resp.nextToken;
  } while (nextToken);
  return tools;
}

const name = `probe4-${Math.random().toString(16).slice(2, 10)}`;
console.log(`Using contactArn=${CONTACT_ARN}\n`);
try {
  const cs = await client.send(
    new CreateSessionCommand({ assistantId: ASSISTANT_ID, name, contactArn: CONTACT_ARN })
  );
  const sessionId = cs.session?.sessionId;
  console.log(`session=${sessionId}`);

  // Inject ANI into Custom namespace (mirrors our driver)
  await client.send(
    new UpdateSessionDataCommand({
      assistantId: ASSISTANT_ID,
      sessionId,
      data: [{ key: "ANI", value: { stringValue: "4074629069" } }],
    })
  );

  const sm = await client.send(
    new SendMessageCommand({
      assistantId: ASSISTANT_ID,
      sessionId,
      type: "TEXT",
      message: { value: { text: { value: UTTERANCE } } },
      aiAgentId: ANYBANK,
    })
  );
  await drive(sessionId, sm.nextMessageToken);
  await sleep(2000);

  const tools = await spanSummary(sessionId);
  console.log("\n=== TOOL CALLS ===");
  for (const t of tools) console.log(`- ${t.name}: ${t.result.replace(/\s+/g, " ").slice(0, 160)}`);
  console.log("\nDONE");
} catch (e) {
  console.log(`ERROR: ${e.name}: ${e.message}`);
}
