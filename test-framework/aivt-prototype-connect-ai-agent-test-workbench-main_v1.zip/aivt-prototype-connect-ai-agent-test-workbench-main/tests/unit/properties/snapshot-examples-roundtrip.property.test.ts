// Feature: actionable-recommendations, Property 5: Snapshot examples round-trip
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { marshall, unmarshall } from "@aws-sdk/util-dynamodb";
import type { AgentSnapshot, ToolDefinition } from "@shared/types";

/**
 * **Validates: Requirements 1.3, 1.4, 3.4, 15.5**
 *
 * Property 5: Snapshot examples round-trip
 * For any `AgentSnapshot` value whose `tools[].examples` arrays contain
 * arbitrary strings (including empty strings, strings with embedded
 * whitespace, strings with embedded newlines, and strings with embedded
 * quote characters), persisting the snapshot to DynamoDB at
 * `PK=RUN#{runId}, SK=SNAPSHOT` and reading it back SHALL produce a
 * snapshot whose `tools[].examples` arrays are element-wise equal to
 * the input — same length, same order, same string content.
 *
 * The serialization boundary the snapshot crosses on `db.writeSnapshot(...)`
 * and `db.getSnapshot(...)` is the `marshall` / `unmarshall` pair from
 * `@aws-sdk/util-dynamodb`, which is what `DynamoDBDocumentClient` uses
 * internally for every PutCommand / GetCommand. Exercising the same pair
 * directly gives the property test deterministic, hermetic coverage of
 * the same boundary at unit-test speed (DynamoDB Local is not required
 * to validate the marshalling contract; the platform's existing
 * `runs.test.ts` round-trip test uses the same approach).
 */

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/**
 * Unicode-aware string generator that emits the four classes of strings
 * R1.4 calls out: empty strings, strings with embedded whitespace,
 * strings with embedded newlines, and strings with embedded quote
 * characters. `fc.string({ unit: "binary" })` covers ASCII control
 * characters and high-codepoint Unicode while `fc.fullUnicodeString`
 * exercises surrogate-pair-safe codepoints; `oneof` mixes them with
 * targeted whitespace/newline/quote samples so the generator hits the
 * verbatim-preservation invariants directly.
 */
const exampleStringArb: fc.Arbitrary<string> = fc.oneof(
  fc.constant(""),
  fc.constant("   "),
  fc.constant("line1\nline2"),
  fc.constant('"quoted"'),
  fc.constant("'single-quoted'"),
  fc.constant("mixed: \"x\"\n\tafter-tab"),
  fc.constant("\\backslash\\and\\\"quote"),
  fc.fullUnicodeString({ maxLength: 80 }),
  fc.string({ maxLength: 80 }),
);

/**
 * Generates a `ToolDefinition` with a non-empty `toolName` (agents in
 * practice have non-empty tool names; the snapshot does not normalize
 * names so we don't rely on that here, only on the field being a string).
 * `examples` is drawn from {@link exampleStringArb} and may be empty.
 */
const toolDefinitionArb: fc.Arbitrary<ToolDefinition> = fc.record({
  toolName: fc
    .string({ minLength: 1, maxLength: 30 })
    .filter((s) => s.trim().length > 0),
  toolType: fc.constantFrom("LAMBDA", "function", "action", "query"),
  description: fc.string({ maxLength: 100 }),
  instruction: fc.option(fc.string({ maxLength: 100 }), { nil: undefined }),
  inputSchema: fc.constant({}),
  examples: fc.array(exampleStringArb, { minLength: 0, maxLength: 8 }),
});

/**
 * Generates an `AgentSnapshot` with a deduplicated `tools[]` (real
 * agents have unique tool names; preserving uniqueness avoids
 * accidentally exercising downstream collapse behavior the snapshot
 * itself does not perform). The top-level fields (`tools`,
 * `systemPrompt`, `modelId`, `capturedAt`) are exactly the four R3.2
 * mandates stay byte-for-byte identical after the round-trip.
 */
const agentSnapshotArb: fc.Arbitrary<AgentSnapshot> = fc
  .record({
    tools: fc.array(toolDefinitionArb, { minLength: 0, maxLength: 8 }),
    systemPrompt: fc.string({ maxLength: 200 }),
    modelId: fc.string({ minLength: 1, maxLength: 50 }),
    capturedAt: fc.constant("2024-01-01T00:00:00Z"),
  })
  .map((snapshot) => {
    const seen = new Set<string>();
    const uniqueTools = snapshot.tools.filter((t) => {
      if (seen.has(t.toolName)) return false;
      seen.add(t.toolName);
      return true;
    });
    return { ...snapshot, tools: uniqueTools };
  });

const runIdArb = fc
  .string({ minLength: 1, maxLength: 36 })
  .filter((s) => s.trim().length > 0);

// ---------------------------------------------------------------------------
// Round-trip helper
// ---------------------------------------------------------------------------

/**
 * Mirrors the persisted-item shape `DynamoDBService.writeSnapshot`
 * constructs (`{ PK, SK, ...snapshot }`), passes it through
 * `marshall` + `unmarshall` (the same pair `DynamoDBDocumentClient`
 * uses), and strips the DDB key attributes back out — equivalent to
 * the read path's `stripKeys` helper.
 */
function roundTripSnapshot(
  runId: string,
  snapshot: AgentSnapshot,
): AgentSnapshot {
  const persistedItem = {
    PK: `RUN#${runId}`,
    SK: "SNAPSHOT",
    ...snapshot,
  };
  const marshalled = marshall(persistedItem, {
    removeUndefinedValues: true,
  });
  const recovered = unmarshall(marshalled) as Record<string, unknown>;
  delete recovered.PK;
  delete recovered.SK;
  return recovered as unknown as AgentSnapshot;
}

// ---------------------------------------------------------------------------
// Property test
// ---------------------------------------------------------------------------

describe("Property 5: Snapshot examples round-trip", () => {
  it("preserves tools[].examples element-wise across the DDB marshalling boundary", () => {
    fc.assert(
      fc.property(runIdArb, agentSnapshotArb, (runId, snapshot) => {
        const recovered = roundTripSnapshot(runId, snapshot);

        // Same number of tools, in the same order.
        expect(recovered.tools).toHaveLength(snapshot.tools.length);

        recovered.tools.forEach((recoveredTool, i) => {
          const original = snapshot.tools[i];

          // Tool identity preserved (sanity — order must match).
          expect(recoveredTool.toolName).toBe(original.toolName);

          // Examples is still an array of the same length.
          expect(Array.isArray(recoveredTool.examples)).toBe(true);
          expect(recoveredTool.examples).toHaveLength(
            original.examples.length,
          );

          // Element-wise string equality: same length, same order,
          // same content. `toEqual` does a deep structural compare
          // which is exactly the element-wise predicate the property
          // requires.
          expect(recoveredTool.examples).toEqual(original.examples);
        });
      }),
      { numRuns: 100 },
    );
  });

  it("preserves the top-level snapshot shape (tools, systemPrompt, modelId, capturedAt) byte-for-byte (R3.2)", () => {
    fc.assert(
      fc.property(runIdArb, agentSnapshotArb, (runId, snapshot) => {
        const recovered = roundTripSnapshot(runId, snapshot);

        expect(recovered.systemPrompt).toBe(snapshot.systemPrompt);
        expect(recovered.modelId).toBe(snapshot.modelId);
        expect(recovered.capturedAt).toBe(snapshot.capturedAt);
        expect(recovered.tools.length).toBe(snapshot.tools.length);
      }),
      { numRuns: 100 },
    );
  });
});
