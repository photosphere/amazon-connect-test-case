/**
 * Tool extraction utility for Q in Connect conversationSessionData.
 *
 * Extracts the selected tool name from the conversationSessionData array
 * returned by GetNextMessage. The tool name is stored under the key "Tool"
 * with the value in the `stringValue` property.
 *
 * @module tool-extraction
 */

/**
 * A single entry in the conversationSessionData array from Q in Connect.
 */
export interface ConversationSessionDataEntry {
  key: string;
  value: { stringValue?: string };
}

/**
 * Extracts the tool name from a conversationSessionData array.
 *
 * Looks for an entry with `key === "Tool"` and returns its `value.stringValue`.
 * Returns null if the data is undefined/null, empty, or no matching entry exists.
 *
 * @param data - The conversationSessionData array from a GetNextMessage response
 * @returns The tool name string, or null if no tool was selected
 */
export function extractToolName(
  data: ConversationSessionDataEntry[] | undefined | null
): string | null {
  if (!data || !Array.isArray(data)) {
    return null;
  }

  const toolEntry = data.find((entry) => entry.key === "Tool");

  if (!toolEntry) {
    return null;
  }

  return toolEntry.value?.stringValue ?? null;
}
