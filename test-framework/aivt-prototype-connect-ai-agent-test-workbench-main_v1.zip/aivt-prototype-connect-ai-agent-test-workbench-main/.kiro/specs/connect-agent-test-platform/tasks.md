# Implementation Plan: Connect Agent Test Platform

## Overview

Implement an automated testing platform for Amazon Connect AI Agents as a serverless CDK TypeScript application. The platform uses a React + Cloudscape frontend, API Gateway + Lambda backend, Step Functions for test orchestration, DynamoDB for storage, and integrates with Q in Connect, Bedrock, and AgentCore Evaluations. Implementation proceeds bottom-up: shared utilities and data models first, then backend services, orchestration, frontend, and finally infrastructure wiring.

## Tasks

- [x] 1. Set up project structure, shared types, and utility functions
  - [x] 1.1 Initialize CDK TypeScript project with monorepo structure
    - Create CDK app scaffold with `cdk init app --language typescript`
    - Set up directory structure: `lib/` (CDK constructs), `src/backend/` (Lambda handlers), `src/frontend/` (React app), `src/shared/` (types/utils), `tests/` (unit/properties/integration/infrastructure)
    - Configure `tsconfig.json` with strict mode, path aliases for shared modules
    - Install core dependencies: `aws-cdk-lib`, `constructs`, `@aws-sdk/client-*` packages
    - Install test dependencies: `vitest`, `fast-check`, `@testing-library/react`
    - Install frontend dependencies: `react`, `react-dom`, `@cloudscape-design/components`, `react-router-dom`
    - _Requirements: 14.1_

  - [x] 1.2 Define shared TypeScript interfaces and data types
    - Create `src/shared/types.ts` with all interfaces: `TestSuite`, `TestCase`, `TestRun`, `TestCaseResult`, `TranscriptTurn`, `AgentSummary`, `AgentDetail`, `ToolDefinition`, `ToolStep`, `AgentSnapshot`
    - Create `src/shared/constants.ts` with DynamoDB key patterns, max limits, and configuration defaults (max turns 20, poll interval 300ms, poll timeout 60s, concurrency 9)
    - Create `src/shared/enums.ts` with `RunStatus`, `CaseStatus`, `CommunicationStyle` enums
    - _Requirements: 4.2, 5.1, 5.2, 7.1, 10.2_

  - [x] 1.3 Implement validation utility functions
    - Create `src/shared/validation.ts` with `validateTestSuite()` and `validateTestCase()` functions
    - Suite validation: name required (max 128 chars), agentId required non-empty
    - Case validation: name max 100 chars, description required max 2000 chars, initial utterance required max 1000 chars, customer knowledge max 20 pairs (key max 100, value max 500), success criteria 1–30 steps with max 10 parameter checks per step
    - Return structured error objects identifying all failing fields
    - _Requirements: 4.3, 5.1, 5.2, 5.4_

  - [x] 1.4 Write property test for entity field validation (Property 1)
    - **Property 1: Entity Field Validation**
    - Use fast-check to generate random strings of varying lengths and random collection sizes
    - Verify validation accepts all inputs within bounds and rejects inputs violating any constraint
    - **Validates: Requirements 4.1, 4.3, 4.5, 5.1, 5.2, 5.4**

  - [x] 1.5 Write property test for suite validation rejects invalid input (Property 18)
    - **Property 18: Suite validation rejects invalid input**
    - Generate test suite inputs with missing/empty names and null/empty agentIds
    - Verify validation returns errors identifying missing fields and never creates a record
    - **Validates: Requirements 4.3**

  - [x] 1.6 Implement core utility functions
    - Create `src/shared/utils/tool-extraction.ts` — `extractToolName(conversationSessionData)` returning tool name or null
    - Create `src/shared/utils/filler-detection.ts` — `isFillerResponse(text, tokenAdvanced)` returning boolean
    - Create `src/shared/utils/backoff.ts` — `calculateBackoffDelay(attempt)` with jitter, base 2s, cap 30s
    - Create `src/shared/utils/time-formatting.ts` — `formatElapsedTime(seconds)` producing MM:SS string
    - Create `src/shared/utils/accuracy.ts` — `calculateAccuracy(results)` returning percentage to one decimal
    - Create `src/shared/utils/session-name.ts` — `generateSessionName()` producing `test-{8 hex chars}`
    - _Requirements: 7.4, 7.7, 7.9, 10.1, 11.1, 7.2_

  - [x] 1.7 Write property tests for utility functions (Properties 1–6 from testing section)
    - **Property 1: Tool extraction from conversationSessionData** — verify correct extraction or null
    - **Property 2: Filler response detection** — verify classification logic
    - **Property 6: Exponential backoff with jitter bounds** — verify delay ranges
    - **Property 11: Accuracy percentage calculation** — verify rounding
    - **Property 12: Elapsed time MM:SS formatting** — verify format compliance
    - **Property 17: Session name format** — verify regex match `^test-[0-9a-f]{8}$`
    - **Validates: Requirements 7.7, 7.4, 7.9, 10.1, 11.1, 7.2**

- [x] 2. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Implement DynamoDB data layer and results logic
  - [x] 3.1 Create DynamoDB service layer
    - Create `src/backend/services/dynamodb.ts` with single-table access patterns
    - Implement CRUD for suites: `createSuite`, `getSuite`, `updateSuite`, `deleteSuite`, `listSuites`
    - Implement CRUD for test cases: `createCase`, `getCase`, `updateCase`, `deleteCase`, `listCases`
    - Implement run operations: `createRun`, `updateRun`, `getRun`, `listRuns`
    - Implement result operations: `writeResult`, `getResult`, `listResults`
    - Implement transcript operations: `writeTranscript`, `getTranscript`
    - Implement cascade delete (suite + all cases)
    - Use composite keys per design: PK/SK patterns from data model table
    - _Requirements: 4.2, 5.5, 10.8, 13.1_

  - [x] 3.2 Write property test for entity persistence round-trip (Property 2)
    - **Property 2: Entity Persistence Round-Trip**
    - Generate random valid entities, persist to DynamoDB Local, retrieve by key
    - Verify all fields preserved with no data loss or corruption
    - **Validates: Requirements 4.2, 5.5, 9.3, 10.8**

  - [x] 3.3 Write property test for cascade delete completeness (Property 3)
    - **Property 3: Cascade Delete Completeness**
    - Generate suites with 0–50 random cases, delete suite, verify N+1 records removed
    - **Validates: Requirements 4.6**

  - [x] 3.4 Implement results sorting and filtering functions
    - Create `src/shared/utils/results-sorting.ts` — `sortResults(results)` ordering by status priority (error > failed > passed), then alphabetical by name
    - Create `src/shared/utils/results-filtering.ts` — `filterResults(results, criteria)` filtering by status and/or tool invoked
    - _Requirements: 10.3, 10.5_

  - [x] 3.5 Write property tests for results sorting and filtering (Properties 9, 10)
    - **Property 9: Results sorting by status priority** — verify ordering invariant
    - **Property 10: Results filter correctness** — verify exact match semantics
    - **Validates: Requirements 10.3, 10.5**

  - [x] 3.6 Implement run comparison and config diff functions
    - Create `src/shared/utils/run-comparison.ts` — `compareRuns(runA, runB)` classifying cases as unchanged/status-changed/added/removed
    - Create `src/shared/utils/config-diff.ts` — `diffAgentConfigs(snapshotA, snapshotB)` identifying tool/prompt/model changes
    - _Requirements: 13.4, 13.6_

  - [x] 3.7 Write property tests for comparison and diff (Properties 14, 15)
    - **Property 14: Run comparison diff correctness** — verify classification of all cases
    - **Property 15: Agent configuration diff** — verify all differences detected, zero diff only when identical
    - **Validates: Requirements 13.4, 13.6**

- [x] 4. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Implement Conversation Driver and Customer Simulator
  - [x] 5.1 Implement Customer Simulator
    - Create `src/backend/orchestration/customer-simulator.ts`
    - Implement `flipConversationRoles(history)` — customer→assistant, agent→user
    - Implement `buildSimulatorPrompt(testCase)` — construct system prompt with goal, style instruction, customer knowledge
    - Implement `simulateCustomer(agentMessage, testCase, history)` — call Bedrock Converse (Claude Haiku), max 150 tokens
    - Implement style mapping: direct/indirect/colloquial/question/complaint → descriptive instructions
    - Fallback on error: return "Yes, please proceed", log error, do not fail test
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7_

  - [x] 5.2 Write property tests for Customer Simulator (Properties 3, 4)
    - **Property 3: Conversation role flipping** — verify role transformation and content preservation
    - **Property 4: Simulator system prompt construction** — verify all components present
    - **Validates: Requirements 8.2, 8.4, 8.6, 8.7**

  - [x] 5.3 Implement Conversation Driver core logic
    - Create `src/backend/orchestration/conversation-driver.ts`
    - Implement `executeTestCase(testCase, agentId, assistantId)` per design pseudocode
    - CreateSession with `generateSessionName()`, SendMessage with `aiAgentId` override
    - Poll loop: 300ms interval, 60s timeout, filler detection via `isFillerResponse`
    - Tool extraction via `extractToolName` from conversationSessionData
    - Tool sequence tracking: `accumulateToolSequence(turns)` preserving chronological order
    - Multi-turn logic: tool selection → record + continue; text → simulate customer + send response
    - Termination: no tool + no text, or max turns reached
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 7.7, 7.8, 7.10_

  - [x] 5.4 Write property test for tool sequence accumulation (Property 7)
    - **Property 7: Tool sequence accumulation preserves order**
    - Generate random multi-turn conversations with 0–20 tool selections
    - Verify sequence length equals tool-bearing turns and order is preserved
    - **Validates: Requirements 7.8**

  - [x] 5.5 Implement throttle retry and error handling in Conversation Driver
    - Implement exponential backoff with jitter for ThrottlingException/429/TooManyRequestsException
    - Base delay 2s, cap 30s, max 3 retries
    - Non-throttle errors: mark case as "error" with failure reason, continue suite
    - Poll timeout: mark case as "timed_out", continue suite
    - _Requirements: 7.9, 7.12, 7.13_

  - [x] 5.6 Implement tool selection accuracy scoring
    - Create `src/shared/utils/tool-accuracy.ts` — `calculateToolAccuracy(expected, actual)`
    - Ordered subsequence matching: score = matched required steps / total required steps
    - Optional steps don't affect denominator; count positively if present in order
    - _Requirements: 9.2, 9.6_

  - [x] 5.7 Write property test for tool selection accuracy (Property 5)
    - **Property 5: Tool selection accuracy — ordered subsequence matching**
    - Generate random expected sequences (required/optional) and actual invocation lists
    - Verify score is 1.0 iff all required tools present in order, proportional otherwise
    - **Validates: Requirements 9.2, 9.6**

- [x] 6. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Implement Backend Lambda Functions
  - [x] 7.1 Implement Discovery Lambda
    - Create `src/backend/handlers/discovery.ts`
    - `GET /agents`: Call ListAIAgents, **filter to type=ORCHESTRATION only**, map to AgentSummary[]
    - `GET /agents/{agentId}`: Call GetAIAgent, extract tools (name, description, inputSchema) and system prompt
    - Handle errors: return structured error responses with retry guidance
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

  - [x] 7.2 Implement Suite CRUD Lambda
    - Create `src/backend/handlers/suites.ts`
    - `POST /suites`: Validate input, create suite in DynamoDB
    - `GET /suites`: List suites for tenant (GSI1 query, sorted by updatedAt)
    - `GET /suites/{suiteId}`: Get suite with case count
    - `PUT /suites/{suiteId}`: Validate and update suite
    - `DELETE /suites/{suiteId}`: Cascade delete suite + all cases (with confirmation token)
    - `POST /suites/{suiteId}/cases`: Create test case with validation
    - `GET /suites/{suiteId}/cases`: List cases for suite
    - `PUT /suites/{suiteId}/cases/{caseId}`: Update test case
    - `DELETE /suites/{suiteId}/cases/{caseId}`: Delete single case
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 5.1, 5.2, 5.3, 5.4, 5.5_

  - [x] 7.3 Implement Run Trigger Lambda
    - Create `src/backend/handlers/runs.ts`
    - `POST /runs`: Snapshot agent config, create run record (status: running), start Step Functions execution
    - `POST /runs/{runId}/abort`: Call StopExecution on Step Functions, update run status to ABORTED
    - Return runId immediately (Step Functions execution ARN)
    - _Requirements: 7.1, 11.3, 11.4, 13.5_

  - [x] 7.4 Implement Results Lambda
    - Create `src/backend/handlers/results.ts`
    - `GET /runs/{runId}`: Return run metadata + progress (completed/total/pass/fail/error counts)
    - `GET /runs/{runId}/cases/{caseId}`: Return full result with transcript
    - `GET /suites/{suiteId}/runs`: List run history (paginated at 50, descending by timestamp)
    - Support partial results while run is in progress
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 10.7, 10.8, 11.1, 13.1, 13.3_

  - [x] 7.5 Implement Scaffold Lambda
    - Create `src/backend/handlers/scaffold.ts`
    - `POST /suites/{suiteId}/cases/scaffold`: Accept goalDescription + agentId
    - Call Bedrock to analyze agent tools against goal, infer tool chain with required/optional labels
    - Analyze tool input schemas, deduplicate parameters, generate customer knowledge template
    - Map parameter names to customer-facing labels via Bedrock
    - Return suggested tools and knowledge template
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

  - [x] 5.8 Write property test for knowledge template deduplication (Property 13)
    - **Property 13: Knowledge template parameter deduplication**
    - Generate random tool schemas with overlapping parameter names
    - Verify exactly one entry per unique parameter name, grouped under first tool
    - **Validates: Requirements 6.3**

  - [x] 7.6 Implement Analysis Lambda
    - Create `src/backend/handlers/analysis.ts`
    - `POST /runs/{runId}/analyze`: Gather failed cases, transcripts, reasoning traces, agent config
    - Call Bedrock for root cause analysis with evidence from reasoning traces
    - Generate 1–5 recommendations per failure as proposed edits (diff format)
    - Group failures sharing the same root cause category
    - Handle missing reasoning traces gracefully
    - _Requirements: 12.1, 12.2, 12.3, 12.4, 12.5, 12.6, 12.7_

  - [x] 7.7 Write property test for failure grouping (Property 16)
    - **Property 16: Failure grouping consolidation**
    - Generate random failure sets with 1–10 root cause categories
    - Verify 2+ failures with same category are consolidated into one group
    - **Validates: Requirements 12.6**

- [x] 8. Implement Step Functions State Machine and Evaluation
  - [x] 8.1 Implement Step Functions state machine definition
    - Create `src/backend/orchestration/state-machine.ts` (CDK construct or ASL definition)
    - PrepareRun → ParallelTestCases (Map, maxConcurrency=9) → EvaluateResults → WriteResults
    - Each map iteration: ConversationDriver → RecordTranscript → FetchReasoningTrace
    - Error handling: catch per-case errors, continue map iteration
    - _Requirements: 7.1, 7.12, 7.13_

  - [x] 8.2 Implement Evaluation Lambda
    - Create `src/backend/orchestration/evaluation.ts`
    - Submit transcripts to AgentCore with Builtin.GoalSuccessRate and Builtin.Helpfulness evaluators
    - Implement custom ToolSelectionAccuracy evaluation using `calculateToolAccuracy`
    - 60s timeout per case for AgentCore response
    - Fallback scoring: tool accuracy via local subsequence, leave goal/helpfulness empty with warning
    - Store scores in DynamoDB TestResult items
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6_

- [x] 9. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Implement React + Cloudscape Frontend
  - [x] 10.1 Set up React application shell with routing and auth
    - Create `src/frontend/` with React + TypeScript + Vite setup
    - Configure Cloudscape design tokens and app layout (side navigation, breadcrumbs)
    - Implement Cognito authentication flow: redirect to hosted UI, token storage, auto-refresh
    - Set up React Router routes: `/agents`, `/suites`, `/suites/:id`, `/runs/:id`, `/compare`
    - Implement API client with Cognito token injection and error interceptor (401 → redirect)
    - _Requirements: 1.1, 1.2, 1.4, 1.5, 1.6_

  - [x] 10.2 Implement Agent Browser page
    - Create Agent Browser component with Cloudscape Table
    - Display: agent name, ID, tool count, model ID
    - Agent detail panel: tools (name, description, input schema) and system prompt (read-only)
    - Empty state message when no agents discovered
    - Error state with retry button on API failure
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

  - [x] 10.3 Implement Test Suite Editor page
    - Suite form: name (max 128), description (max 500), agent selector from discovered agents
    - Suite list view with edit/delete actions (delete requires confirmation dialog)
    - Test case editor form: name, description, persona style selector, customer knowledge key-value editor, initial utterance, success criteria (ordered tool sequence builder with required/optional toggle, default required)
    - "Suggest Tools" button triggering scaffold Lambda
    - Inline validation errors preventing save on missing required fields
    - _Requirements: 4.1, 4.3, 4.4, 4.5, 4.6, 5.1, 5.2, 5.3, 5.4, 6.1, 6.2, 6.6_

  - [x] 10.4 Implement Run Dashboard page
    - Start run button triggering `POST /runs`
    - Progress display: progress bar, pass/fail/error counts, elapsed timer (MM:SS)
    - Poll `GET /runs/{runId}` every 3 seconds for updates
    - Abort button visible during active run
    - Stream completed test case results as they arrive
    - Final summary on completion/abort
    - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5_

  - [x] 10.5 Implement Results Viewer page
    - Results summary: total, passed, failed, errors, accuracy percentage
    - Results table sorted by status priority (errors → failed → passed), then alphabetical
    - Expandable rows with full transcript (role labels, text, tool selections, timestamps)
    - Filter controls: by status, by tool invoked
    - Score display: goal success, helpfulness, tool accuracy (0–1 each)
    - Warning indicator when managed scoring unavailable (fallback active)
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 10.7_

  - [x] 10.6 Implement Historical Comparison page
    - Run history list: descending by timestamp, paginated at 50/page
    - Side-by-side comparison view for two selected runs
    - Status change indicators (passed→failed, failed→passed, added, removed)
    - Configuration diff view highlighting tool/prompt/model changes
    - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5, 13.6_

  - [x] 10.7 Implement Failure Analysis panel
    - Per-failed-test-case root cause explanation with reasoning trace evidence
    - Recommendations as diff views (current text vs suggested replacement)
    - Grouped recommendations when multiple failures share root cause
    - Handle missing reasoning traces with informational message
    - _Requirements: 12.1, 12.2, 12.3, 12.4, 12.5, 12.6, 12.7_

  - [x] 10.8 Write property test for progress display computation (Property 17)
    - **Property 17: Progress Display Computation**
    - Generate random progress states with counts and elapsed seconds
    - Verify MM:SS formatting and count sums (pass + fail + error = completed)
    - **Validates: Requirements 11.1, 11.5**

- [x] 11. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 12. Implement CDK Infrastructure Stack
  - [x] 12.1 Implement Cognito authentication construct
    - Create Cognito User Pool with hosted UI configuration
    - Create Cognito Identity Pool linked to User Pool
    - Configure IAM role for authenticated users: Q in Connect session APIs + Bedrock Converse, scoped to instance ARN
    - Configure callback URLs from CDK context parameter
    - Create Resource Server with `test-platform` identifier and `run` scope
    - Create machine-to-machine App Client with `client_credentials` grant and `test-platform/run` scope
    - Store machine client secret in Secrets Manager
    - Output machine client ID, token endpoint URL, and secret ARN as CDK stack outputs
    - _Requirements: 1.1, 1.3, 1.4, 14.1, 15.1, 15.2, 15.6, 15.7_

  - [x] 12.2 Implement API Gateway and Lambda constructs
    - Create API Gateway REST API with Cognito authorizer (validates both user-pool and client-credentials tokens)
    - Create Lambda functions for each handler (Discovery, Suite CRUD, Run Trigger, Results, Scaffold, Analysis)
    - Create IAM roles per Lambda with least-privilege permissions (both `wisdom:` and `qconnect:` ARN prefixes)
    - Set Lambda environment variables: Connect instance ID, assistant ID, DynamoDB table name
    - Implement tenant ID extraction utility that derives tenant from `sub` (interactive users) or `client_id` (machine clients)
    - _Requirements: 1.4, 2.2, 2.3, 14.1, 14.3, 15.3, 15.4, 15.5_

  - [x] 12.3 Implement Step Functions and orchestration constructs
    - Create Step Functions state machine with Map state (maxConcurrency=9)
    - Create Conversation Driver Lambda with Q in Connect + Bedrock permissions
    - Create Evaluation Lambda with AgentCore permissions
    - Wire state machine: PrepareRun → Map(ConversationDriver → RecordTranscript → FetchReasoningTrace) → Evaluate → WriteResults
    - _Requirements: 7.1, 14.1_

  - [x] 12.4 Implement DynamoDB and storage constructs
    - Create DynamoDB table with composite PK/SK, billing mode PAY_PER_REQUEST
    - Create GSI1 (tenant + updatedAt) and GSI2 (agent + createdAt)
    - Enable TTL for transcript/trace cleanup (90+ day retention)
    - Create S3 bucket for frontend assets with CloudFront distribution
    - Configure CloudFront OAI for S3 access
    - _Requirements: 13.1, 14.1, 14.2_

  - [x] 12.5 Implement CDK context parameters and assistant discovery
    - Accept Connect instance ID as required CDK context parameter (validate UUID format)
    - Implement custom resource or deploy-time script to call ListAssistants and discover assistant ID
    - Store instance ID and assistant ID as environment variables on all Lambdas
    - Fail deployment if no assistant found for instance
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

  - [x] 12.6 Write CDK infrastructure tests
    - Snapshot test for CloudFormation output
    - Assertion: IAM policies include both `wisdom:` and `qconnect:` prefixes
    - Assertion: Lambda environment variables contain instance ID and assistant ID
    - Assertion: DynamoDB table has TTL enabled
    - Assertion: API Gateway has Cognito authorizer
    - Assertion: Each Lambda has its own role with scoped permissions
    - Assertion: Resource Server exists with `test-platform/run` scope
    - Assertion: Machine App Client has `client_credentials` grant type and correct scopes
    - Assertion: CDK outputs include machine client ID, token endpoint, and secret ARN
    - _Requirements: 14.1, 14.3, 14.4, 15.1, 15.2, 15.6, 15.7_

- [x] 13. Final integration wiring and end-to-end validation
  - [x] 13.1 Wire frontend to backend API endpoints
    - Configure API client base URL from CloudFront/API Gateway deployment outputs
    - Ensure all frontend pages use correct API routes with auth headers
    - Test error handling paths: 401 redirect, 5xx flash messages, network timeout retry
    - _Requirements: 1.2, 1.5_

  - [x] 13.2 Wire Step Functions output to Results Lambda
    - Ensure state machine writes results in correct DynamoDB format
    - Verify partial results are readable during execution
    - Verify run status transitions: running → completed/failed/aborted
    - _Requirements: 10.6, 10.8, 11.2_

  - [x] 13.3 Write integration tests for critical paths
    - Test: Discovery Lambda → ListAIAgents → filtered response
    - Test: Suite CRUD → DynamoDB read/write with correct keys
    - Test: Run Trigger → Step Functions execution start
    - Test: Conversation Driver → Q in Connect session lifecycle (mocked)
    - Test: Evaluation → AgentCore scoring + fallback path
    - _Requirements: 3.1, 4.2, 7.1, 9.1, 9.5_

- [x] 14. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document (21 properties)
- Unit tests validate specific examples and edge cases
- The design uses TypeScript throughout (CDK, Lambda handlers, frontend, tests)
- fast-check is the property-based testing library; Vitest is the test runner
- DynamoDB Local should be used for persistence tests in local/CI environments
- Both `wisdom:` and `qconnect:` ARN prefixes are required for IAM policies (proven by prototype)
- Only ORCHESTRATION-type agents are displayed (filtered by Discovery Lambda, not frontend)

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["1.2", "1.6"] },
    { "id": 2, "tasks": ["1.3", "1.4", "1.5", "1.7"] },
    { "id": 3, "tasks": ["3.1", "3.4", "3.6"] },
    { "id": 4, "tasks": ["3.2", "3.3", "3.5", "3.7", "5.1", "5.6"] },
    { "id": 5, "tasks": ["5.2", "5.3", "5.7", "5.8"] },
    { "id": 6, "tasks": ["5.4", "5.5"] },
    { "id": 7, "tasks": ["7.1", "7.2", "7.4", "7.5", "7.6"] },
    { "id": 8, "tasks": ["7.3", "7.7"] },
    { "id": 9, "tasks": ["8.1", "8.2"] },
    { "id": 10, "tasks": ["10.1"] },
    { "id": 11, "tasks": ["10.2", "10.3", "10.4", "10.5", "10.6", "10.7", "10.8"] },
    { "id": 12, "tasks": ["12.1", "12.4"] },
    { "id": 13, "tasks": ["12.2", "12.3", "12.5"] },
    { "id": 14, "tasks": ["12.6"] },
    { "id": 15, "tasks": ["13.1", "13.2"] },
    { "id": 16, "tasks": ["13.3"] }
  ]
}
```
