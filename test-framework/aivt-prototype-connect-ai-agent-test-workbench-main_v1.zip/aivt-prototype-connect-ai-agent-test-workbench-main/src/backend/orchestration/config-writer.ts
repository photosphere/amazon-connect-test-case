/**
 * Config Writer Module
 *
 * Builds UpdateAIAgent / UpdateAIPrompt payloads from the current agent config
 * plus a set of recommendations, then executes the writes via Q in Connect SDK.
 *
 * - All tool-surface changes (tool_description, tool_instruction, tool_examples)
 *   are applied in a single UpdateAIAgent call.
 * - All system_prompt changes are applied in a single UpdateAIPrompt call.
 * - The resulting payloads contain exactly the suggestedText values mapped to
 *   their correct fields — no other modifications (R18.2).
 *
 * @module config-writer
 */

import {
  QConnectClient,
  UpdateAIAgentCommand,
  UpdateAIPromptCommand,
  GetAIAgentCommand,
  GetAIPromptCommand,
} from "@aws-sdk/client-qconnect";
import type {
  AgentDetail,
  Recommendation,
  ToolDefinition,
  ToolSurface,
} from "../../shared/types";

// ---------------------------------------------------------------------------
// Public Interfaces
// ---------------------------------------------------------------------------

export interface WritePayload {
  agentId: string;
  assistantId: string;
  /** Recommendations to apply, grouped by target. */
  recommendations: Recommendation[];
  /** The current live agent config (already fetched for drift check). */
  currentConfig: AgentDetail;
}

export interface WriteResult {
  success: boolean;
  newAgentVersionId?: string;
  newPromptVersionId?: string;
  error?: string;
}

// ---------------------------------------------------------------------------
// Client management
// ---------------------------------------------------------------------------

function getRegion(): string {
  return process.env.AWS_REGION ?? "us-east-1";
}

let qconnectClient: QConnectClient | null = null;

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: getRegion() });
  }
  return qconnectClient;
}

/** @internal — allows test injection */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

// ---------------------------------------------------------------------------
// Payload Builders (pure functions)
// ---------------------------------------------------------------------------

/**
 * Determines the tool_examples operation based on currentText / suggestedText:
 *   - add:     currentText is empty, suggestedText is non-empty
 *   - remove:  currentText is non-empty, suggestedText is empty
 *   - replace: both are non-empty
 */
function getExamplesOperation(
  rec: Recommendation
): "add" | "remove" | "replace" {
  if (rec.currentText === "") return "add";
  if (rec.suggestedText === "") return "remove";
  return "replace";
}

/**
 * Applies tool-surface recommendations to a cloned tools array.
 * Returns the modified tools array ready for the UpdateAIAgent payload.
 *
 * Only modifies fields targeted by recommendations — all other fields
 * remain byte-for-byte identical (R18.2).
 */
export function buildUpdatedTools(
  currentTools: ToolDefinition[],
  recommendations: Recommendation[]
): ToolDefinition[] {
  // Deep clone the tools array so we don't mutate the input
  const tools: ToolDefinition[] = currentTools.map((t) => ({
    ...t,
    examples: [...t.examples],
  }));

  for (const rec of recommendations) {
    if (rec.targetField === "system_prompt") continue;

    const tool = tools.find((t) => t.toolName === rec.targetName);
    if (!tool) continue;

    switch (rec.targetField as ToolSurface) {
      case "tool_description":
        tool.description = rec.suggestedText;
        break;

      case "tool_instruction":
        tool.instruction = rec.suggestedText;
        break;

      case "tool_examples": {
        const operation = getExamplesOperation(rec);
        switch (operation) {
          case "add":
            tool.examples.push(rec.suggestedText);
            break;
          case "remove":
            tool.examples = tool.examples.filter(
              (ex) => ex !== rec.currentText
            );
            break;
          case "replace":
            tool.examples = tool.examples.map((ex) =>
              ex === rec.currentText ? rec.suggestedText : ex
            );
            break;
        }
        break;
      }
    }
  }

  return tools;
}

/**
 * Applies system_prompt recommendations to the current prompt text.
 *
 * Handles three operations:
 * 1. **Replace section** — currentText is a non-empty substring of the live
 *    prompt → find-and-replace that section with suggestedText.
 * 2. **Full replacement** — currentText matches the full prompt OR currentText
 *    is not found (fallback) → replace the entire prompt with suggestedText.
 * 3. **Add new section** — currentText is empty, suggestedText is non-empty →
 *    append suggestedText to the end of the existing prompt.
 *
 * When multiple system_prompt recommendations exist, they are applied
 * sequentially (each operates on the result of the previous).
 *
 * The result is the FULL updated prompt wrapped in the Q in Connect YAML
 * template envelope.
 */
export function buildUpdatedSystemPrompt(
  currentPrompt: string,
  recommendations: Recommendation[]
): string {
  const promptRecs = recommendations.filter(
    (r) => r.targetField === "system_prompt"
  );
  if (promptRecs.length === 0) return currentPrompt;

  // Apply each system_prompt recommendation sequentially
  let updatedContent = currentPrompt;

  for (const rec of promptRecs) {
    if (!rec.currentText && rec.suggestedText) {
      // ADD operation: currentText empty → append suggestedText as a new section
      updatedContent = updatedContent.trimEnd() + '\n\n' + rec.suggestedText;
    } else if (!rec.currentText && !rec.suggestedText) {
      // No-op: both empty — skip
      continue;
    } else if (rec.currentText && !rec.suggestedText) {
      // REMOVE operation: suggestedText empty → remove the section from the prompt
      updatedContent = updatedContent.replace(rec.currentText, '');
      // Clean up double newlines left from removal
      updatedContent = updatedContent.replace(/\n{3,}/g, '\n\n');
    } else if (rec.currentText === updatedContent) {
      // Full prompt replacement: currentText matches the full prompt
      updatedContent = rec.suggestedText;
    } else if (updatedContent.includes(rec.currentText)) {
      // Targeted section replacement: exact find-and-replace within the prompt
      updatedContent = updatedContent.replace(rec.currentText, rec.suggestedText);
    } else {
      // Try normalized match (ignoring leading whitespace differences from
      // YAML indent stripping) for the find-and-replace
      const normalize = (s: string) => s.split('\n').map(l => l.trimStart()).join('\n');
      const normalizedContent = normalize(updatedContent);
      const normalizedCurrent = normalize(rec.currentText);
      if (normalizedContent.includes(normalizedCurrent)) {
        // Found via normalized match — need to find the actual position.
        // Rebuild by splitting lines and finding the matching range.
        const contentLines = updatedContent.split('\n');
        const currentLines = rec.currentText.split('\n').map(l => l.trimStart());
        const firstLine = currentLines[0];
        
        // Find start line by matching first normalized line
        let startIdx = -1;
        for (let i = 0; i < contentLines.length; i++) {
          if (contentLines[i].trimStart() === firstLine) {
            // Check if the subsequent lines also match
            let match = true;
            for (let j = 1; j < currentLines.length && i + j < contentLines.length; j++) {
              if (contentLines[i + j].trimStart() !== currentLines[j]) {
                match = false;
                break;
              }
            }
            if (match) {
              startIdx = i;
              break;
            }
          }
        }
        
        if (startIdx >= 0) {
          // Replace the matched lines with suggestedText
          const before = contentLines.slice(0, startIdx).join('\n');
          const after = contentLines.slice(startIdx + currentLines.length).join('\n');
          updatedContent = [before, rec.suggestedText, after].filter(Boolean).join('\n');
        } else {
          // Normalized match found but line-level replacement failed — full replace
          updatedContent = rec.suggestedText;
        }
      } else {
        // Fallback: currentText not found — treat as full replacement
        updatedContent = rec.suggestedText;
      }
    }
  }

  return wrapInYamlEnvelope(updatedContent);
}

/**
 * Wraps inner system prompt content in the Q in Connect YAML template envelope.
 */
function wrapInYamlEnvelope(innerContent: string): string {
  const indentedContent = innerContent
    .split('\n')
    .map((line) => (line.length > 0 ? `  ${line}` : ''))
    .join('\n');

  return [
    'system: |',
    indentedContent,
    'messages:',
    '  - "{{$.conversationHistory}}"',
    '  - role: assistant',
    '    content: <message>',
    '',
  ].join('\n');
}

/**
 * Validates that a prompt template string conforms to the Q in Connect
 * YAML format before writing. Returns null if valid, or an error message
 * describing what's wrong.
 *
 * Expected structure:
 *   system: |
 *     <content lines indented 2 spaces>
 *   messages:
 *     - "{{$.conversationHistory}}"
 *     ...
 *
 * Validation rules:
 *   1. Must start with "system: |" or "system: |\n"
 *   2. Must contain a "messages:" line at the root level (no leading spaces)
 *   3. Content between "system: |" and "messages:" must be indented (2+ spaces)
 *      or empty lines
 *   4. Must contain the conversationHistory placeholder
 */
export function validatePromptYaml(text: string): string | null {
  if (!text || text.trim().length === 0) {
    return "Prompt template is empty";
  }

  // Rule 1: Must start with "system:"
  if (!text.startsWith('system:')) {
    return `Prompt must start with "system: |" but starts with "${text.substring(0, 20)}..."`;
  }

  // Check for the literal block scalar indicator
  const firstLine = text.split('\n')[0];
  if (!firstLine.includes('|')) {
    return `First line must be "system: |" but got "${firstLine}"`;
  }

  // Rule 2: Must contain "messages:" at root level
  const lines = text.split('\n');
  const messagesLineIdx = lines.findIndex(
    (l) => l === 'messages:' || l.startsWith('messages:')
  );
  if (messagesLineIdx < 0) {
    return 'Prompt template is missing the "messages:" section';
  }

  // Rule 3: Content between "system: |" and "messages:" should be
  // indented or empty. Check a sample of lines.
  const contentLines = lines.slice(1, messagesLineIdx);
  for (let i = 0; i < contentLines.length; i++) {
    const line = contentLines[i];
    // Empty lines are fine
    if (line.length === 0) continue;
    // Lines must start with at least 2 spaces (YAML block scalar indent)
    if (!line.startsWith('  ')) {
      return `Line ${i + 2} in system block is not properly indented (must start with 2 spaces): "${line.substring(0, 40)}..."`;
    }
  }

  // Rule 4: Must contain conversationHistory placeholder
  if (!text.includes('{{$.conversationHistory}}')) {
    return 'Prompt template is missing "{{$.conversationHistory}}" placeholder in messages section';
  }

  return null; // Valid
}

// ---------------------------------------------------------------------------
// Main Write Function
// ---------------------------------------------------------------------------

/**
 * Builds the UpdateAIAgent/UpdateAIPrompt payloads from
 * (currentConfig + recommendations), then executes the writes.
 *
 * Applies all tool-surface changes in a single UpdateAIAgent call.
 * Applies all system_prompt changes in a single UpdateAIPrompt call.
 * The resulting payload contains exactly the suggestedText values mapped to
 * their correct fields — no other modifications (R18.2).
 */
export async function writeConfig(payload: WritePayload): Promise<WriteResult> {
  const { agentId, assistantId, recommendations, currentConfig } = payload;
  const client = getQConnectClient();

  const toolRecs = recommendations.filter(
    (r) => r.targetField !== "system_prompt"
  );
  const promptRecs = recommendations.filter(
    (r) => r.targetField === "system_prompt"
  );

  let newAgentVersionId: string | undefined;
  let newPromptVersionId: string | undefined;

  try {
    // --- Apply tool-surface changes via UpdateAIAgent ---
    if (toolRecs.length > 0) {
      // Fetch the current agent to get the full orchestration config
      // (preserves orchestrationAIPromptId, guardrail, locale, etc.)
      const getAgentResp = await client.send(
        new GetAIAgentCommand({
          assistantId,
          aiAgentId: agentId,
        })
      );
      const currentAgent = getAgentResp.aiAgent;
      const orchestrationConfig = (currentAgent?.configuration as any)
        ?.orchestrationAIAgentConfiguration;
      const orchestrationAIPromptId =
        orchestrationConfig?.orchestrationAIPromptId ?? "";
      const visibilityStatus = (currentAgent as any)?.visibilityStatus ?? "PUBLISHED";

      // Apply tool-surface changes directly on the raw SDK toolConfigurations.
      // This preserves MCP tool shapes (including inputSchema) untouched —
      // only the specific fields targeted by recommendations are modified.
      const rawToolConfigs: any[] = [
        ...(orchestrationConfig?.toolConfigurations ?? []),
      ];
      for (const rec of toolRecs) {
        const tool = rawToolConfigs.find((t: any) => t.toolName === rec.targetName);
        if (!tool) continue;

        switch (rec.targetField) {
          case "tool_description":
            tool.description = rec.suggestedText;
            break;
          case "tool_instruction":
            // instruction is a nested object in the SDK format
            if (!tool.instruction) tool.instruction = {};
            tool.instruction.instruction = rec.suggestedText;
            break;
          case "tool_examples": {
            // instruction.examples is where examples live in the SDK format
            if (!tool.instruction) tool.instruction = {};
            const examples: string[] = tool.instruction.examples ?? tool.examples ?? [];
            const operation = rec.currentText === "" ? "add"
              : rec.suggestedText === "" ? "remove"
              : "replace";
            if (operation === "add") {
              examples.push(rec.suggestedText);
            } else if (operation === "remove") {
              const idx = examples.indexOf(rec.currentText);
              if (idx >= 0) examples.splice(idx, 1);
            } else {
              const idx = examples.indexOf(rec.currentText);
              if (idx >= 0) examples[idx] = rec.suggestedText;
            }
            tool.instruction.examples = examples;
            // Also update top-level examples for backward compat
            tool.examples = examples;
            break;
          }
        }
      }

      // Strip inputSchema from MCP-backed tools — Q in Connect rejects
      // schema overrides on MCP tools (the service derives schemas from
      // the MCP server definition). Regular tools keep their schemas.
      for (const tool of rawToolConfigs) {
        if (tool.toolType === 'MCP' || tool.toolType === 'mcp') {
          delete tool.inputSchema;
        }
      }

      const updateAgentResp = await client.send(
        new UpdateAIAgentCommand({
          assistantId,
          aiAgentId: agentId,
          visibilityStatus,
          configuration: {
            orchestrationAIAgentConfiguration: {
              orchestrationAIPromptId,
              toolConfigurations: rawToolConfigs as any,
              // Preserve existing fields from the current config
              ...(orchestrationConfig?.orchestrationAIGuardrailId && {
                orchestrationAIGuardrailId:
                  orchestrationConfig.orchestrationAIGuardrailId,
              }),
              ...(orchestrationConfig?.connectInstanceArn && {
                connectInstanceArn: orchestrationConfig.connectInstanceArn,
              }),
              ...(orchestrationConfig?.locale && {
                locale: orchestrationConfig.locale,
              }),
            },
          },
        })
      );

      newAgentVersionId = updateAgentResp.aiAgent?.aiAgentId;
    }

    // --- Apply system_prompt changes via UpdateAIPrompt, then re-point the agent ---
    if (promptRecs.length > 0) {
      const updatedPrompt = buildUpdatedSystemPrompt(
        currentConfig.systemPrompt,
        promptRecs
      );

      // Fetch the current agent to get the prompt ID and full config
      const getAgentResp = await client.send(
        new GetAIAgentCommand({
          assistantId,
          aiAgentId: agentId,
        })
      );
      const currentAgent = getAgentResp.aiAgent;
      const orchestrationConfig = (currentAgent?.configuration as any)
        ?.orchestrationAIAgentConfiguration;
      const promptId = orchestrationConfig?.orchestrationAIPromptId ?? "";

      if (!promptId) {
        return {
          success: false,
          error:
            "Cannot update system prompt: no orchestration AI prompt ID found on agent",
        };
      }

      // Strip version qualifier (e.g. ":2", ":$LATEST") — the Update/Get APIs
      // require the bare prompt UUID without qualifiers.
      const barePromptId = promptId.includes(':') ? promptId.split(':')[0] : promptId;

      // Fetch the current prompt to get the visibilityStatus
      const getPromptResp = await client.send(
        new GetAIPromptCommand({
          assistantId,
          aiPromptId: barePromptId,
        })
      );
      const currentPromptData = getPromptResp.aiPrompt;
      const promptVisibilityStatus =
        (currentPromptData as any)?.visibilityStatus ?? "PUBLISHED";

      // Step 1: Validate the generated YAML template before writing
      const yamlError = validatePromptYaml(updatedPrompt);
      if (yamlError) {
        return {
          success: false,
          error: `Prompt is not in expected YAML format. ${yamlError}`,
        };
      }

      // Step 2: UpdateAIPrompt — creates a new version with the updated text
      const updatePromptResp = await client.send(
        new UpdateAIPromptCommand({
          assistantId,
          aiPromptId: barePromptId,
          visibilityStatus: promptVisibilityStatus,
          templateConfiguration: {
            textFullAIPromptEditTemplateConfiguration: {
              text: updatedPrompt,
            },
          },
        })
      );

      // The response contains the new qualified prompt ID (e.g. "uuid:3")
      const newPromptQualifiedId = updatePromptResp.aiPrompt?.aiPromptId;
      newPromptVersionId = newPromptQualifiedId;

      // Step 3: UpdateAIAgent — re-point orchestrationAIPromptId to the new
      // prompt version so the agent uses the updated prompt immediately.
      // IMPORTANT: We MUST pass toolConfigurations here. UpdateAIAgent
      // without toolConfigurations WIPES them (the API does NOT preserve
      // them when omitted). MCP tools reject inputSchema/description/title
      // overrides, so we strip those fields while preserving the rest.
      if (newPromptQualifiedId) {
        const agentVisibilityStatus = (currentAgent as any)?.visibilityStatus ?? "PUBLISHED";

        // Sanitize tools: MCP tools reject certain fields on update.
        // Strip: inputSchema, description, title, outputSchema (server-owned).
        // Preserve: everything else (instruction, examples, overrideInputValues,
        //           userInteractionConfiguration, toolId, toolName, toolType).
        // RTC tools keep their full shape.
        const existingTools: any[] = orchestrationConfig?.toolConfigurations ?? [];
        const sanitizedTools = existingTools.map((t: any) => {
          if (t.toolType === "RETURN_TO_CONTROL") return t;
          // MCP: strip fields the API rejects on update
          const { inputSchema, description, title, outputSchema, ...rest } = t;
          return rest;
        });

        const updateAgentResp = await client.send(
          new UpdateAIAgentCommand({
            assistantId,
            aiAgentId: agentId,
            visibilityStatus: agentVisibilityStatus,
            configuration: {
              orchestrationAIAgentConfiguration: {
                orchestrationAIPromptId: newPromptQualifiedId,
                toolConfigurations: sanitizedTools,
                ...(orchestrationConfig?.orchestrationAIGuardrailId && {
                  orchestrationAIGuardrailId:
                    orchestrationConfig.orchestrationAIGuardrailId,
                }),
                ...(orchestrationConfig?.connectInstanceArn && {
                  connectInstanceArn: orchestrationConfig.connectInstanceArn,
                }),
                ...(orchestrationConfig?.locale && {
                  locale: orchestrationConfig.locale,
                }),
              },
            },
          })
        );

        // If the tool-surface path didn't already set newAgentVersionId,
        // capture it from the prompt-rebinding update.
        if (!newAgentVersionId) {
          newAgentVersionId = updateAgentResp.aiAgent?.aiAgentId;
        }
      }
    }

    return {
      success: true,
      ...(newAgentVersionId && { newAgentVersionId }),
      ...(newPromptVersionId && { newPromptVersionId }),
    };
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error during write";
    console.error("[config-writer] Write failed:", errorMessage);
    return {
      success: false,
      error: errorMessage,
      ...(newAgentVersionId && { newAgentVersionId }),
      ...(newPromptVersionId && { newPromptVersionId }),
    };
  }
}
