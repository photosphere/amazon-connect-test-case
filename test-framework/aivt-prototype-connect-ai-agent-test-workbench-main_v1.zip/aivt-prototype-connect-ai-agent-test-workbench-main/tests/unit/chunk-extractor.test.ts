/**
 * Unit tests for the chunk-extractor module.
 *
 * Covers:
 * - Single Retrieve span with two chunks → produces two RetrievedChunks in order
 * - Mixed span types (non-Retrieve spans ignored)
 * - Empty toolResult.values → produces zero chunks
 * - Multiple Retrieve spans → chunks ordered chronologically across spans
 * - Citation fields populated from SpanCitation when present, undefined when absent
 *
 * Requirements: 3.4, 11.3
 */

import { describe, it, expect } from "vitest";
import { extractRetrievedChunks } from "../../src/backend/orchestration/chunk-extractor";
import type { RawSpan } from "../../src/backend/orchestration/span-parser";

/** Helper to build an execute_tool span for the Retrieve tool with given chunks. */
function makeRetrieveSpan(
  timestamp: string,
  chunks: Array<{ text: string; citations?: Array<{ knowledgeBaseId?: string; contentId?: string; title?: string }> }>,
): RawSpan {
  return {
    spanName: "execute_tool",
    startTimestamp: timestamp,
    attributes: {
      inputMessages: [
        { values: [{ toolUse: { name: "Retrieve", arguments: "{}" } }] },
      ],
      outputMessages: [
        {
          values: [
            {
              toolResult: {
                values: chunks.map((c) => ({
                  text: {
                    value: c.text,
                    ...(c.citations ? { citations: c.citations } : {}),
                  },
                })),
              },
            },
          ],
        },
      ],
    },
  };
}

/** Helper to build a non-Retrieve execute_tool span. */
function makeOtherToolSpan(toolName: string, timestamp: string): RawSpan {
  return {
    spanName: "execute_tool",
    startTimestamp: timestamp,
    attributes: {
      inputMessages: [
        { values: [{ toolUse: { name: toolName, arguments: "{}" } }] },
      ],
      outputMessages: [
        {
          values: [
            {
              toolResult: {
                values: [{ text: { value: '{"status":"success"}' } }],
              },
            },
          ],
        },
      ],
    },
  };
}

describe("extractRetrievedChunks", () => {
  it("single Retrieve span with two chunks → produces two RetrievedChunks in order", () => {
    const spans: RawSpan[] = [
      makeRetrieveSpan("2024-01-01T00:00:01.000Z", [
        { text: "First chunk about account balances." },
        { text: "Second chunk about loan terms." },
      ]),
    ];

    const chunks = extractRetrievedChunks(spans, "Retrieve");

    expect(chunks).toHaveLength(2);
    expect(chunks[0].text).toBe("First chunk about account balances.");
    expect(chunks[0].index).toBe(0);
    expect(chunks[1].text).toBe("Second chunk about loan terms.");
    expect(chunks[1].index).toBe(1);
  });

  it("mixed span types — non-Retrieve spans are ignored", () => {
    const spans: RawSpan[] = [
      makeOtherToolSpan("verifyIdentity", "2024-01-01T00:00:00.500Z"),
      makeRetrieveSpan("2024-01-01T00:00:01.000Z", [
        { text: "Retrieved passage." },
      ]),
      makeOtherToolSpan("getLoanDetails", "2024-01-01T00:00:02.000Z"),
      {
        spanName: "inference",
        startTimestamp: "2024-01-01T00:00:03.000Z",
        attributes: {
          outputMessages: [{ values: [{ text: { value: "Agent reasoning." } }] }],
        },
      },
    ];

    const chunks = extractRetrievedChunks(spans, "Retrieve");

    expect(chunks).toHaveLength(1);
    expect(chunks[0].text).toBe("Retrieved passage.");
    expect(chunks[0].index).toBe(0);
  });

  it("empty toolResult.values → produces zero chunks", () => {
    const span: RawSpan = {
      spanName: "execute_tool",
      startTimestamp: "2024-01-01T00:00:01.000Z",
      attributes: {
        inputMessages: [
          { values: [{ toolUse: { name: "Retrieve", arguments: "{}" } }] },
        ],
        outputMessages: [
          {
            values: [
              {
                toolResult: {
                  values: [],
                },
              },
            ],
          },
        ],
      },
    };

    const chunks = extractRetrievedChunks([span], "Retrieve");

    expect(chunks).toHaveLength(0);
  });

  it("multiple Retrieve spans → chunks ordered chronologically across spans", () => {
    // Provide spans out of order to confirm sorting by startTimestamp
    const spans: RawSpan[] = [
      makeRetrieveSpan("2024-01-01T00:00:05.000Z", [
        { text: "Later chunk A." },
        { text: "Later chunk B." },
      ]),
      makeRetrieveSpan("2024-01-01T00:00:01.000Z", [
        { text: "Earlier chunk X." },
      ]),
    ];

    const chunks = extractRetrievedChunks(spans, "Retrieve");

    expect(chunks).toHaveLength(3);
    // Earlier span's chunk comes first
    expect(chunks[0].text).toBe("Earlier chunk X.");
    expect(chunks[0].index).toBe(0);
    // Later span's chunks follow in value order
    expect(chunks[1].text).toBe("Later chunk A.");
    expect(chunks[1].index).toBe(1);
    expect(chunks[2].text).toBe("Later chunk B.");
    expect(chunks[2].index).toBe(2);
  });

  it("citation fields populated from SpanCitation when present, undefined when absent", () => {
    const spans: RawSpan[] = [
      makeRetrieveSpan("2024-01-01T00:00:01.000Z", [
        {
          text: "Chunk with full citation.",
          citations: [{ knowledgeBaseId: "kb-123", contentId: "doc-456", title: "FAQ Page" }],
        },
        {
          text: "Chunk with partial citation.",
          citations: [{ knowledgeBaseId: "kb-789" }],
        },
        {
          text: "Chunk with no citation.",
        },
      ]),
    ];

    const chunks = extractRetrievedChunks(spans, "Retrieve");

    expect(chunks).toHaveLength(3);

    // Full citation
    expect(chunks[0].text).toBe("Chunk with full citation.");
    expect(chunks[0].knowledgeBaseId).toBe("kb-123");
    expect(chunks[0].contentId).toBe("doc-456");
    expect(chunks[0].title).toBe("FAQ Page");

    // Partial citation (only knowledgeBaseId)
    expect(chunks[1].text).toBe("Chunk with partial citation.");
    expect(chunks[1].knowledgeBaseId).toBe("kb-789");
    expect(chunks[1].contentId).toBeUndefined();
    expect(chunks[1].title).toBeUndefined();

    // No citation
    expect(chunks[2].text).toBe("Chunk with no citation.");
    expect(chunks[2].knowledgeBaseId).toBeUndefined();
    expect(chunks[2].contentId).toBeUndefined();
    expect(chunks[2].title).toBeUndefined();
  });
});
