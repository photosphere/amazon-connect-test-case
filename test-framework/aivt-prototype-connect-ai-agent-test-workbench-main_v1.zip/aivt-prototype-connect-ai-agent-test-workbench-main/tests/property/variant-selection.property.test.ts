// Feature: implement-recommendations, Property 4: Winner selection determinism and idempotence
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import { selectWinningVariant } from "@backend/orchestration/variant-selection";
import type { VariantScore } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** The three valid variant letters. */
const variantLetterArb: fc.Arbitrary<"A" | "B" | "C"> = fc.constantFrom(
  "A" as const,
  "B" as const,
  "C" as const,
);

/** Arbitrary score value in [0, 1]. */
const scoreArb = fc.double({ min: 0, max: 1, noNaN: true });

/** Arbitrary VariantScore with status "error". */
const erroredVariantScoreArb: fc.Arbitrary<VariantScore> = fc
  .tuple(variantLetterArb, scoreArb, scoreArb, scoreArb, scoreArb)
  .map(([variant, passRate, avgGoalSuccessScore, avgHelpfulnessScore, avgToolAccuracyScore]) => ({
    variant,
    passRate,
    avgGoalSuccessScore,
    avgHelpfulnessScore,
    avgToolAccuracyScore,
    status: "error" as const,
  }));

/**
 * Generate an array of 1-3 VariantScores with distinct variant letters.
 * This reflects real usage where each variant letter appears at most once.
 */
const distinctVariantScoresArb: fc.Arbitrary<VariantScore[]> = fc
  .shuffledSubarray(["A", "B", "C"] as const, { minLength: 1, maxLength: 3 })
  .chain((letters) =>
    fc.tuple(...letters.map((letter) =>
      fc.tuple(scoreArb, scoreArb, scoreArb, scoreArb, fc.constantFrom("completed" as const, "error" as const))
        .map(([passRate, avgGoalSuccessScore, avgHelpfulnessScore, avgToolAccuracyScore, status]) => ({
          variant: letter,
          passRate,
          avgGoalSuccessScore,
          avgHelpfulnessScore,
          avgToolAccuracyScore,
          status,
        }))
    )) as fc.Arbitrary<VariantScore[]>
  );

// ---------------------------------------------------------------------------
// Property 4: Winner selection determinism and idempotence
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 8.4, 18.5**
 *
 * Property 4: Winner selection determinism and idempotence
 * For any set of variant scores (with pass rates and average goal success
 * scores), the `selectWinningVariant` function SHALL always assign the
 * "Recommended" badge to the variant with the highest pass rate, with ties
 * broken by average goal success score (higher wins). The function is
 * deterministic (same input always produces same output) and idempotent
 * (calling it multiple times with the same input produces the same result).
 * Errored variants are excluded from selection.
 */
describe("Feature: implement-recommendations, Property 4: Winner selection determinism and idempotence", () => {
  it("determinism: calling with the same input always returns the same output", () => {
    fc.assert(
      fc.property(distinctVariantScoresArb, (scores) => {
        const result1 = selectWinningVariant(scores);
        const result2 = selectWinningVariant(scores);
        const result3 = selectWinningVariant(scores);

        expect(result1).toBe(result2);
        expect(result2).toBe(result3);
      }),
      { numRuns: 100 },
    );
  });

  it("idempotence: f(x) called N times always returns same result", () => {
    fc.assert(
      fc.property(
        distinctVariantScoresArb,
        fc.integer({ min: 2, max: 10 }),
        (scores, n) => {
          const results = Array.from({ length: n }, () => selectWinningVariant(scores));
          const allSame = results.every((r) => r === results[0]);
          expect(allSame).toBe(true);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("correctness: if one completed variant has strictly highest passRate, it is selected", () => {
    fc.assert(
      fc.property(distinctVariantScoresArb, (scores) => {
        const completed = scores.filter((s) => s.status === "completed");
        if (completed.length < 2) return; // need at least 2 completed to have a strict winner

        // Find the max passRate among completed variants
        const maxPassRate = Math.max(...completed.map((s) => s.passRate));
        const withMaxPassRate = completed.filter((s) => s.passRate === maxPassRate);

        // Only test strict case: exactly one variant with highest passRate
        if (withMaxPassRate.length !== 1) return;

        const result = selectWinningVariant(scores);
        expect(result).toBe(withMaxPassRate[0].variant);
      }),
      { numRuns: 100 },
    );
  });

  it("tiebreak: if two completed variants tie on passRate, the one with higher avgGoalSuccessScore wins", () => {
    fc.assert(
      fc.property(
        fc.constantFrom("A" as const, "B" as const, "C" as const),
        fc.constantFrom("A" as const, "B" as const, "C" as const),
        scoreArb,
        scoreArb,
        scoreArb,
        scoreArb,
        scoreArb,
        scoreArb,
        scoreArb,
        (letter1, letter2, sharedPassRate, goal1, goal2, h1, h2, t1, t2) => {
          // Ensure distinct variant letters
          if (letter1 === letter2) return;
          // Ensure strictly different goal scores so there's a clear tiebreak winner
          if (goal1 === goal2) return;

          const scores: VariantScore[] = [
            {
              variant: letter1,
              passRate: sharedPassRate,
              avgGoalSuccessScore: goal1,
              avgHelpfulnessScore: h1,
              avgToolAccuracyScore: t1,
              status: "completed",
            },
            {
              variant: letter2,
              passRate: sharedPassRate,
              avgGoalSuccessScore: goal2,
              avgHelpfulnessScore: h2,
              avgToolAccuracyScore: t2,
              status: "completed",
            },
          ];

          const result = selectWinningVariant(scores);
          const expectedWinner = goal1 > goal2 ? letter1 : letter2;
          expect(result).toBe(expectedWinner);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("errored exclusion: errored variants are never selected regardless of their scores", () => {
    fc.assert(
      fc.property(distinctVariantScoresArb, (scores) => {
        const result = selectWinningVariant(scores);
        if (result === null) {
          // All variants must be errored
          const allErrored = scores.every((s) => s.status === "error");
          expect(allErrored).toBe(true);
        } else {
          // The selected variant must have status "completed"
          const selected = scores.find((s) => s.variant === result);
          expect(selected).toBeDefined();
          expect(selected!.status).toBe("completed");
        }
      }),
      { numRuns: 100 },
    );
  });

  it("null case: empty input or all-errored input returns null", () => {
    // Empty array always returns null
    expect(selectWinningVariant([])).toBeNull();

    // All-errored arrays always return null
    fc.assert(
      fc.property(
        fc.array(erroredVariantScoreArb, { minLength: 1, maxLength: 3 }),
        (scores) => {
          const result = selectWinningVariant(scores);
          expect(result).toBeNull();
        },
      ),
      { numRuns: 100 },
    );
  });
});
