/**
 * Shared enumerations for the Connect Agent Test Platform.
 *
 * @module enums
 */

/** Status of a test run execution. */
export enum RunStatus {
  RUNNING = "running",
  COMPLETED = "completed",
  FAILED = "failed",
  ABORTED = "aborted",
}

/** Status of an individual test case result. */
export enum CaseStatus {
  PASSED = "passed",
  FAILED = "failed",
  ERROR = "error",
  TIMED_OUT = "timed_out",
  /** RAG cases pending Stage 2 evaluation — not yet scored. */
  PENDING_EVALUATION = "pending_evaluation",
}

/** Communication style for simulated customer persona. */
export enum CommunicationStyle {
  DIRECT = "direct",
  INDIRECT = "indirect",
  COLLOQUIAL = "colloquial",
  QUESTION = "question",
  COMPLAINT = "complaint",
}
