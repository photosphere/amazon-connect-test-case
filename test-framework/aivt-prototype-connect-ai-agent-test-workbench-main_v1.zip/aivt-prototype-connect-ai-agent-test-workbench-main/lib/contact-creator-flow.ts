import * as cdk from "aws-cdk-lib";
import * as connect from "aws-cdk-lib/aws-connect";
import { Construct } from "constructs";

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface ContactCreatorFlowProps {
  /** The Amazon Connect instance ARN. */
  connectInstanceArn: string;
}

// ---------------------------------------------------------------------------
// Construct
// ---------------------------------------------------------------------------

/**
 * Deploys a minimal Amazon Connect contact flow used solely to mint synthetic
 * contacts for the automated agent test platform.
 *
 * Why: Q in Connect ORCHESTRATION agent MCP tools read the bound contact's
 * ContactARN from the session runtime. A standalone CreateSession has no
 * contact, so those tools fail ("ContactARN not found in session") and the
 * agent escalates. The Conversation Driver mints a real contact against this
 * flow via StartChatContact, binds its ARN to the session, runs the test, then
 * stops the contact.
 *
 * The flow itself does nothing but disconnect — we never connect a participant;
 * we only need the contact to exist so its ARN is bindable.
 */
export class ContactCreatorFlow extends Construct {
  /** The deployed contact flow's ID (UUID), for StartChatContact. */
  public readonly contactFlowId: string;
  /** The deployed contact flow's ARN. */
  public readonly contactFlowArn: string;

  constructor(scope: Construct, id: string, props: ContactCreatorFlowProps) {
    super(scope, id);

    // Minimal flow: start → disconnect. Proven sufficient for session binding;
    // the contact ARN remains valid even after the participant disconnects.
    const flowContent = {
      Version: "2019-10-30",
      StartAction: "disconnect",
      Actions: [
        {
          Identifier: "disconnect",
          Type: "DisconnectParticipant",
          Parameters: {},
          Transitions: {},
        },
      ],
    };

    const flow = new connect.CfnContactFlow(this, "Flow", {
      instanceArn: props.connectInstanceArn,
      name: "AgentTestPlatform-ContactCreator",
      type: "CONTACT_FLOW",
      description:
        "Minimal flow that mints synthetic contacts for the automated agent test platform (binds ContactARN to Q in Connect sessions).",
      content: JSON.stringify(flowContent),
    });

    // CfnContactFlow.attrContactFlowArn is the full ARN; the ID is the last segment.
    this.contactFlowArn = flow.attrContactFlowArn;
    this.contactFlowId = cdk.Fn.select(
      1,
      cdk.Fn.split("/contact-flow/", flow.attrContactFlowArn)
    );
  }
}
