/**
 * Unit tests for the RAG Evaluate Lambda handler
 * (`src/backend/orchestration/rag-evaluate.ts`, task 8; Wave-2
 * migrated under Task 17.7 of the prompt-management spec).
 *
 * Tests exercise the full Stage 2 pipeline with injectable mock clients
 * via `_setS3Client`, `_setBedrockClient`, and `_setDocClient` test seams.
 * No real AWS SDK is invoked.
 *
 * Per the Wave-2 migration the handler resolves the
 * `rag_evaluation_job` prompt via `resolvePromptForRun(...)` and wires
 * `prompt.modelId` into `evaluatorModelConfig.bedrockEvaluatorModels[].
 * modelIdentifier`. Tests inject a stub Prompts_Store via
 * `_setPromptStore` so the resolver returns the registry's bundled
 * defaults (Claude Sonnet 4.6) without touching DynamoDB. Same pattern
 * as `tests/unit/variant-generator.test.ts` and
 * `tests/unit/tournament-summary.test.ts`.
 *
 * Validates:
 *   - Requirement 1.3 / 10.1: every Bedrock callsite resolves through
 *     the registry; no `process.env.*_MODEL_ID ?? "..."` fallback
 *     remains in the source.
 *   - Requirement 10.2: the resolved `prompt.modelId` populates
 *     `evaluatorModelConfig.bedrockEvaluatorModels[].modelIdentifier`
 *     on the `CreateEvaluationJob` request.
 *   - Requirement 11.2: the snapshot-pinned model id wins over the
 *     live override store when both are present.
 *   - Requirement 4.4: Stage 2 filters surviving RAG cases, serializes
 *     JSONL, uploads to S3, creates evaluation job, polls, reads results.
 *   - Requirement 4.5: Polls GetEvaluationJob with 30-minute hard cap.
 *   - Requirement 4.6: Zero surviving cases skips CreateEvaluationJob.
 *   - Requirement 8.1: RAG_JOB_FAILED error propagation.
 *   - Requirement 8.2: CreateEvaluationJob failure → RAG_JOB_FAILED on all cases.
 *   - Requirement 8.3: RAG_JOB_TIMEOUT on poll timeout.
 *   - Requirement 8.4: Malformed per-prompt output → MALFORMED_RESULT on single case.
 *   - Requirement 8.5: Missing per-prompt result → MISSING_EVALUATOR.
 *
 * @module tests/unit/rag-evaluate.test
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { RagThresholds } from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Mock the constants module so poll interval is instant and timeout is tiny
// ---------------------------------------------------------------------------

vi.mock("../../src/shared/constants", async (importOriginal) => {
  const original = await importOriginal<typeof import("../../src/shared/constants")>();
  return {
    ...original,
    RAG_JOB_POLL_INTERVAL_MS: 0, // no delay between polls
    RAG_JOB_TIMEOUT_MS: 50, // 50ms timeout for fast tests
  };
});

// Set env vars BEFORE importing the module (module reads them at load time).
// Wave 3 (Task 20.3) retired the `JUDGE_MODEL_ID` env var: `rag-evaluate.ts`
// resolves the evaluator model id through the Prompt_Registry rather than
// from an env var. We still pin RAG_JOB_BUCKET, TABLE_NAME, and AWS_REGION
// because the module reads those at load time.
process.env.RAG_JOB_BUCKET = "test-rag-bucket";
process.env.TABLE_NAME = "TestTable";
process.env.AWS_REGION = "us-east-1";

// ---------------------------------------------------------------------------
// Import the module under test and its injectable seams
// ---------------------------------------------------------------------------

import {
  handler,
  _setS3Client,
  _setBedrockClient,
  _setDocClient,
  type RagEvaluateInput,
  type RagCaseData,
} from "../../src/backend/orchestration/rag-evaluate";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import { PROMPT_REGISTRY, SUPPORTED_MODELS } from "../../src/backend/orchestration/prompt-registry";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";

// ---------------------------------------------------------------------------
// Resolved registry default — used to assert the modelId wired into the
// `CreateEvaluationJob` request matches what the registry resolves to
// when no override is set. After the evaluator-model mapping
// (`mapToEvaluatorModelId`), the inference-profile id is translated to
// the supported Bedrock evaluator model id (R10.2).
// ---------------------------------------------------------------------------

// mapToEvaluatorModelId maps "us.anthropic.claude-sonnet-4-6" →
// "us.anthropic.claude-sonnet-4-20250514-v1:0" (the CreateEvaluationJob-
// compatible cross-region inference profile ID).
const RAG_DEFAULT_MODEL_ID = "us.anthropic.claude-sonnet-4-20250514-v1:0";

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

const RUN_ID = "run-rag-test-1";
const SUITE_ID = "suite-rag-1";
const DEFAULT_THRESHOLDS: RagThresholds = {
  faithfulness: 0.7,
  correctness: 0.7,
  completeness: 0.7,
  helpfulness: 0.7,
};

function makeSurvivingCase(overrides: Partial<RagCaseData> = {}): RagCaseData {
  return {
    caseId: "case-rag-1",
    question: "What is the return policy?",
    groundTruthAnswer: "You can return items within 30 days.",
    agentResponse: "Our return policy allows returns within 30 days of purchase.",
    retrievedChunks: [
      { text: "Return policy: 30 days from purchase date.", index: 0 },
    ],
    status: "passed",
    ...overrides,
  };
}

function makeInput(overrides: Partial<RagEvaluateInput> = {}): RagEvaluateInput {
  return {
    runId: RUN_ID,
    suiteId: SUITE_ID,
    ragCases: [makeSurvivingCase()],
    agentSnapshot: { modelId: "us.anthropic.claude-sonnet-4-6" },
    ragThresholds: DEFAULT_THRESHOLDS,
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Mock clients
// ---------------------------------------------------------------------------

interface MockSendCall {
  commandName: string;
  input: Record<string, unknown>;
}

function createMockS3Client(options: {
  listObjectsResponse?: unknown;
  getObjectResponse?: unknown;
} = {}) {
  const calls: MockSendCall[] = [];
  const send = vi.fn().mockImplementation((command: unknown) => {
    const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
    const commandName = cmd.constructor.name;
    calls.push({ commandName, input: cmd.input });

    if (commandName === "PutObjectCommand") {
      return Promise.resolve({});
    }
    if (commandName === "ListObjectsV2Command") {
      return Promise.resolve(
        options.listObjectsResponse ?? {
          Contents: [{ Key: `${RUN_ID}/output/per_prompt_results.jsonl` }],
        },
      );
    }
    if (commandName === "GetObjectCommand") {
      return Promise.resolve(
        options.getObjectResponse ?? {
          Body: {
            transformToString: () => Promise.resolve(""),
          },
        },
      );
    }
    return Promise.resolve({});
  });
  return { send, calls, client: { send } as unknown };
}

function createMockBedrockClient(options: {
  createJobResponse?: unknown;
  createJobError?: Error;
  getJobResponses?: Array<{ status: string }>;
  stopJobResponse?: unknown;
} = {}) {
  const calls: MockSendCall[] = [];
  let getJobCallIndex = 0;

  const send = vi.fn().mockImplementation((command: unknown) => {
    const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
    const commandName = cmd.constructor.name;
    calls.push({ commandName, input: cmd.input });

    if (commandName === "CreateEvaluationJobCommand") {
      if (options.createJobError) {
        return Promise.reject(options.createJobError);
      }
      return Promise.resolve(
        options.createJobResponse ?? {
          jobArn: "arn:aws:bedrock:us-east-1:123456789012:evaluation-job/test-job-123",
        },
      );
    }
    if (commandName === "GetEvaluationJobCommand") {
      const responses = options.getJobResponses ?? [{ status: "Completed" }];
      const response = responses[Math.min(getJobCallIndex, responses.length - 1)];
      getJobCallIndex++;
      return Promise.resolve({
        status: response.status,
        outputDataConfig: { s3Uri: `s3://test-bucket/${RUN_ID}/output/` },
      });
    }
    if (commandName === "StopEvaluationJobCommand") {
      return Promise.resolve(options.stopJobResponse ?? {});
    }
    return Promise.resolve({});
  });
  return { send, calls, client: { send } as unknown };
}

function createMockDocClient() {
  const calls: MockSendCall[] = [];
  const written: Array<Record<string, unknown>> = [];

  const send = vi.fn().mockImplementation((command: unknown) => {
    const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
    const commandName = cmd.constructor.name;
    calls.push({ commandName, input: cmd.input });

    if (commandName === "PutCommand") {
      written.push((cmd.input as { Item: Record<string, unknown> }).Item);
    }
    return Promise.resolve({});
  });
  return { send, calls, written, client: { send } as unknown };
}

// ---------------------------------------------------------------------------
// Per-prompt result helper
// ---------------------------------------------------------------------------

function makePerPromptJsonl(
  results: Array<{
    faithfulness: number;
    correctness: number;
    completeness: number;
    helpfulness: number;
  }>,
): string {
  return results
    .map((r, i) => JSON.stringify({ promptIndex: i, scores: r }))
    .join("\n");
}

function makeS3BodyResponse(content: string) {
  return {
    Body: {
      transformToString: () => Promise.resolve(content),
    },
  };
}

// ---------------------------------------------------------------------------
// Setup / teardown
// ---------------------------------------------------------------------------

const _originalEnv = { ...process.env };
void _originalEnv; // preserved for potential afterAll restore

/**
 * Inject a stub Prompts_Store so `resolvePromptForRun("rag_evaluation_job", ...)`
 * returns the registry's bundled defaults without touching DynamoDB.
 *
 * The handler uses `resolvePromptForRun`, which reads the run snapshot
 * first and falls back to the live registry. We wire `getSnapshot` to
 * return null so the resolver always traverses the live-registry
 * fallback path, then return an empty overrides map so the resolver
 * yields the bundled `rag_evaluation_job` definition (Claude Sonnet 4.6).
 */
function injectDefaultPromptStore(): void {
  _clearPromptRegistryCaches();
  const store = {
    getSnapshot: vi.fn().mockResolvedValue(null),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  } as unknown as DynamoDBService;
  _setPromptRegistryStore(store);
}

beforeEach(() => {
  injectDefaultPromptStore();
});

afterEach(() => {
  _setS3Client(null);
  _setBedrockClient(null);
  _setDocClient(null);
  _setPromptRegistryStore(null);
  _clearPromptRegistryCaches();
});

// ---------------------------------------------------------------------------
// Successful flow: create job → poll → read → write metrics (R4.4, R4.5)
// ---------------------------------------------------------------------------

describe("rag-evaluate handler — successful flow", () => {
  it("creates job, polls until completed, reads per-prompt output, writes metrics to DDB", async () => {
    const perPromptContent = makePerPromptJsonl([
      { faithfulness: 0.9, correctness: 0.85, completeness: 0.8, helpfulness: 0.95 },
    ]);

    const s3Mock = createMockS3Client({
      getObjectResponse: makeS3BodyResponse(perPromptContent),
    });
    const bedrockMock = createMockBedrockClient({
      getJobResponses: [{ status: "InProgress" }, { status: "Completed" }],
    });
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const input = makeInput();

    const result = await handler(input);

    // Verify output shape
    expect(result.runId).toBe(RUN_ID);
    expect(result.status).toBe("COMPLETED");
    expect(result.evaluatedCount).toBe(1);
    expect(result.errorCount).toBe(0);
    expect(result.jobArn).toContain("evaluation-job");

    // Verify S3 upload was called (PutObjectCommand)
    const putCalls = s3Mock.calls.filter((c) => c.commandName === "PutObjectCommand");
    expect(putCalls).toHaveLength(1);
    expect(putCalls[0].input.Key).toBe(`${RUN_ID}/input.jsonl`);
    expect(putCalls[0].input.ContentType).toBe("application/jsonl");
    // Body should be non-empty JSONL
    expect(putCalls[0].input.Body).toBeDefined();
    expect((putCalls[0].input.Body as string).length).toBeGreaterThan(0);

    // Verify CreateEvaluationJob was called
    const createCalls = bedrockMock.calls.filter(
      (c) => c.commandName === "CreateEvaluationJobCommand",
    );
    expect(createCalls).toHaveLength(1);

    // R10.2 — the resolved `prompt.modelId` populates
    // `evaluatorModelConfig.bedrockEvaluatorModels[0].modelIdentifier`
    // on the CreateEvaluationJob request. With the default Prompts_Store
    // (no overrides, no snapshot) the resolver returns the bundled
    // `rag_evaluation_job` default, whose modelKey resolves to
    // `RAG_DEFAULT_MODEL_ID`.
    const createInput = createCalls[0].input as {
      evaluationConfig: {
        automated: {
          evaluatorModelConfig: {
            bedrockEvaluatorModels: Array<{ modelIdentifier: string }>;
          };
        };
      };
    };
    expect(
      createInput.evaluationConfig.automated.evaluatorModelConfig
        .bedrockEvaluatorModels,
    ).toHaveLength(1);
    expect(
      createInput.evaluationConfig.automated.evaluatorModelConfig
        .bedrockEvaluatorModels[0].modelIdentifier,
    ).toBe(RAG_DEFAULT_MODEL_ID);

    // Verify GetEvaluationJob was polled (InProgress → Completed = 2 calls)
    const getCalls = bedrockMock.calls.filter(
      (c) => c.commandName === "GetEvaluationJobCommand",
    );
    expect(getCalls).toHaveLength(2);

    // Verify DDB writes: UpdateCommand for metrics + PutCommand for RAGJOB record
    const updateCalls = docMock.calls.filter((c) => c.commandName === "UpdateCommand");
    expect(updateCalls.length).toBeGreaterThanOrEqual(1);

    const putDocCalls = docMock.calls.filter((c) => c.commandName === "PutCommand");
    expect(putDocCalls).toHaveLength(1);

    // Verify the RAGJOB record persisted correctly
    const ragJobRecord = docMock.written[0];
    expect(ragJobRecord.PK).toBe(`RUN#${RUN_ID}`);
    expect(ragJobRecord.SK).toBe("RAGJOB");
    expect(ragJobRecord.status).toBe("COMPLETED");
    expect(ragJobRecord.submittedCaseCount).toBe(1);
    // R10.2 — RAGJOB observability record carries the same registry-
    // resolved model id wired into the CreateEvaluationJob request.
    expect(ragJobRecord.judgeModelId).toBe(RAG_DEFAULT_MODEL_ID);
  });

  it("handles multiple cases with all metrics passing thresholds → status passed", async () => {
    const cases: RagCaseData[] = [
      makeSurvivingCase({ caseId: "case-1" }),
      makeSurvivingCase({ caseId: "case-2", question: "How do I contact support?" }),
    ];

    const perPromptContent = makePerPromptJsonl([
      { faithfulness: 0.9, correctness: 0.85, completeness: 0.8, helpfulness: 0.95 },
      { faithfulness: 0.8, correctness: 0.9, completeness: 0.75, helpfulness: 0.85 },
    ]);

    const s3Mock = createMockS3Client({
      getObjectResponse: makeS3BodyResponse(perPromptContent),
    });
    const bedrockMock = createMockBedrockClient({
      getJobResponses: [{ status: "Completed" }],
    });
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const input = makeInput({ ragCases: cases });
    const result = await handler(input);

    expect(result.evaluatedCount).toBe(2);
    expect(result.errorCount).toBe(0);
    expect(result.status).toBe("COMPLETED");

    // Verify both cases got UpdateCommand with metrics
    const updateCalls = docMock.calls.filter((c) => c.commandName === "UpdateCommand");
    expect(updateCalls).toHaveLength(2);
  });
});

// ---------------------------------------------------------------------------
// Job fails → all cases get RAG_JOB_FAILED (R8.1, R8.2)
// ---------------------------------------------------------------------------

describe("rag-evaluate handler — job failure", () => {
  it("writes RAG_JOB_FAILED to all cases when CreateEvaluationJob throws", async () => {
    const s3Mock = createMockS3Client();
    const bedrockMock = createMockBedrockClient({
      createJobError: new Error("Access denied: insufficient permissions"),
    });
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const cases: RagCaseData[] = [
      makeSurvivingCase({ caseId: "case-1" }),
      makeSurvivingCase({ caseId: "case-2" }),
    ];
    const input = makeInput({ ragCases: cases });

    const result = await handler(input);

    expect(result.status).toBe("FAILED");
    expect(result.evaluatedCount).toBe(0);
    expect(result.errorCount).toBe(2);

    // Both cases should get UpdateCommand with RAG_JOB_FAILED
    const updateCalls = docMock.calls.filter((c) => c.commandName === "UpdateCommand");
    expect(updateCalls).toHaveLength(2);

    for (const call of updateCalls) {
      const exprValues = (call.input as any).ExpressionAttributeValues;
      expect(exprValues[":ee"].code).toBe("RAG_JOB_FAILED");
      expect(exprValues[":st"]).toBe("error");
    }

    // RAGJOB record persisted with FAILED status
    const ragJobRecord = docMock.written[0];
    expect(ragJobRecord.status).toBe("FAILED");
  });

  it("writes RAG_JOB_FAILED to all cases when GetEvaluationJob returns Failed status", async () => {
    const s3Mock = createMockS3Client();
    const bedrockMock = createMockBedrockClient({
      getJobResponses: [{ status: "InProgress" }, { status: "Failed" }],
    });
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const cases: RagCaseData[] = [
      makeSurvivingCase({ caseId: "case-1" }),
      makeSurvivingCase({ caseId: "case-2" }),
      makeSurvivingCase({ caseId: "case-3" }),
    ];
    const input = makeInput({ ragCases: cases });

    const result = await handler(input);

    expect(result.status).toBe("FAILED");
    expect(result.evaluatedCount).toBe(0);
    expect(result.errorCount).toBe(3);

    // All 3 cases should get RAG_JOB_FAILED
    const updateCalls = docMock.calls.filter((c) => c.commandName === "UpdateCommand");
    expect(updateCalls).toHaveLength(3);

    for (const call of updateCalls) {
      const exprValues = (call.input as any).ExpressionAttributeValues;
      expect(exprValues[":ee"].code).toBe("RAG_JOB_FAILED");
    }
  });
});

// ---------------------------------------------------------------------------
// Poll timeout → all cases get RAG_JOB_TIMEOUT (R8.3)
// ---------------------------------------------------------------------------

describe("rag-evaluate handler — poll timeout", () => {
  it("writes RAG_JOB_TIMEOUT to all cases when poll exceeds hard cap", async () => {
    const s3Mock = createMockS3Client();
    // Always return InProgress — never completes
    const bedrockMock = createMockBedrockClient({
      getJobResponses: Array(100).fill({ status: "InProgress" }),
    });
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const cases: RagCaseData[] = [
      makeSurvivingCase({ caseId: "case-1" }),
      makeSurvivingCase({ caseId: "case-2" }),
    ];
    const input = makeInput({ ragCases: cases });

    const result = await handler(input);

    expect(result.status).toBe("TIMEOUT");
    expect(result.evaluatedCount).toBe(0);
    expect(result.errorCount).toBe(2);

    // Both cases should get RAG_JOB_TIMEOUT
    const updateCalls = docMock.calls.filter((c) => c.commandName === "UpdateCommand");
    expect(updateCalls).toHaveLength(2);

    for (const call of updateCalls) {
      const exprValues = (call.input as any).ExpressionAttributeValues;
      expect(exprValues[":ee"].code).toBe("RAG_JOB_TIMEOUT");
      expect(exprValues[":ee"].reason).toContain("30 minutes");
      expect(exprValues[":st"]).toBe("error");
    }

    // StopEvaluationJob should have been called (best-effort)
    const stopCalls = bedrockMock.calls.filter(
      (c) => c.commandName === "StopEvaluationJobCommand",
    );
    expect(stopCalls).toHaveLength(1);

    // RAGJOB record persisted with TIMEOUT status
    const ragJobRecord = docMock.written[0];
    expect(ragJobRecord.status).toBe("TIMEOUT");
  });
});

// ---------------------------------------------------------------------------
// Malformed per-prompt output → single case gets MALFORMED_RESULT (R8.4)
// ---------------------------------------------------------------------------

describe("rag-evaluate handler — malformed per-prompt output", () => {
  it("writes MALFORMED_RESULT to case with incomplete metrics while scoring others normally", async () => {
    // Line 0 has valid metrics, line 1 is missing faithfulness
    const perPromptContent = [
      JSON.stringify({ promptIndex: 0, scores: { faithfulness: 0.9, correctness: 0.8, completeness: 0.85, helpfulness: 0.9 } }),
      JSON.stringify({ promptIndex: 1, scores: { correctness: 0.8, completeness: 0.7, helpfulness: 0.8 } }), // missing faithfulness
    ].join("\n");

    const s3Mock = createMockS3Client({
      getObjectResponse: makeS3BodyResponse(perPromptContent),
    });
    const bedrockMock = createMockBedrockClient({
      getJobResponses: [{ status: "Completed" }],
    });
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const cases: RagCaseData[] = [
      makeSurvivingCase({ caseId: "case-good" }),
      makeSurvivingCase({ caseId: "case-malformed", question: "What is X?" }),
    ];
    const input = makeInput({ ragCases: cases });

    const result = await handler(input);

    expect(result.status).toBe("COMPLETED");
    expect(result.evaluatedCount).toBe(1); // Only case-good scored
    expect(result.errorCount).toBe(1); // case-malformed errored

    // Verify the UpdateCommand calls
    const updateCalls = docMock.calls.filter((c) => c.commandName === "UpdateCommand");
    expect(updateCalls).toHaveLength(2);

    // Find the calls by SK (caseId)
    const goodCaseUpdate = updateCalls.find(
      (c) => (c.input as any).Key.SK === "CASE#case-good",
    );
    const malformedCaseUpdate = updateCalls.find(
      (c) => (c.input as any).Key.SK === "CASE#case-malformed",
    );

    // Good case got ragMetrics written
    expect(goodCaseUpdate).toBeDefined();
    expect((goodCaseUpdate!.input as any).ExpressionAttributeValues[":rm"]).toEqual({
      faithfulness: 0.9,
      correctness: 0.8,
      completeness: 0.85,
      helpfulness: 0.9,
    });

    // Malformed case got MALFORMED_RESULT error
    expect(malformedCaseUpdate).toBeDefined();
    expect((malformedCaseUpdate!.input as any).ExpressionAttributeValues[":ee"].code).toBe(
      "MALFORMED_RESULT",
    );
    expect((malformedCaseUpdate!.input as any).ExpressionAttributeValues[":st"]).toBe("error");
  });

  it("writes MALFORMED_RESULT when metric values are non-numeric (NaN)", async () => {
    const perPromptContent = JSON.stringify({
      promptIndex: 0,
      scores: { faithfulness: "not-a-number", correctness: 0.8, completeness: 0.7, helpfulness: 0.9 },
    });

    const s3Mock = createMockS3Client({
      getObjectResponse: makeS3BodyResponse(perPromptContent),
    });
    const bedrockMock = createMockBedrockClient({
      getJobResponses: [{ status: "Completed" }],
    });
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const input = makeInput();
    const result = await handler(input);

    expect(result.status).toBe("COMPLETED");
    expect(result.errorCount).toBe(1);

    const updateCalls = docMock.calls.filter((c) => c.commandName === "UpdateCommand");
    const errorUpdate = updateCalls.find(
      (c) => (c.input as any).ExpressionAttributeValues[":ee"],
    );
    expect(errorUpdate).toBeDefined();
    expect((errorUpdate!.input as any).ExpressionAttributeValues[":ee"].code).toBe("MALFORMED_RESULT");
  });
});

// ---------------------------------------------------------------------------
// Zero surviving cases → skips CreateEvaluationJob (R4.6)
// ---------------------------------------------------------------------------

describe("rag-evaluate handler — zero surviving cases", () => {
  it("returns SKIPPED without calling CreateEvaluationJob when all cases are in error", async () => {
    const s3Mock = createMockS3Client();
    const bedrockMock = createMockBedrockClient();
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const cases: RagCaseData[] = [
      makeSurvivingCase({ caseId: "case-err-1", status: "error", agentResponse: undefined }),
      makeSurvivingCase({ caseId: "case-err-2", status: "error", agentResponse: undefined }),
    ];
    const input = makeInput({ ragCases: cases });

    const result = await handler(input);

    expect(result.status).toBe("SKIPPED");
    expect(result.evaluatedCount).toBe(0);
    expect(result.errorCount).toBe(0);
    expect(result.jobArn).toBeUndefined();

    // No S3 upload, no Bedrock calls, no DDB writes
    expect(s3Mock.calls).toHaveLength(0);
    expect(bedrockMock.calls).toHaveLength(0);
    expect(docMock.calls).toHaveLength(0);
  });

  it("returns SKIPPED when ragCases array is empty", async () => {
    const s3Mock = createMockS3Client();
    const bedrockMock = createMockBedrockClient();
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const input = makeInput({ ragCases: [] });
    const result = await handler(input);

    expect(result.status).toBe("SKIPPED");
    expect(result.evaluatedCount).toBe(0);
    expect(result.errorCount).toBe(0);

    // No AWS calls at all
    expect(s3Mock.calls).toHaveLength(0);
    expect(bedrockMock.calls).toHaveLength(0);
    expect(docMock.calls).toHaveLength(0);
  });

  it("returns SKIPPED when cases have no agentResponse (undefined)", async () => {
    const s3Mock = createMockS3Client();
    const bedrockMock = createMockBedrockClient();
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const cases: RagCaseData[] = [
      { caseId: "case-1", question: "Q1", groundTruthAnswer: "A1", agentResponse: undefined, status: "passed" },
    ];
    const input = makeInput({ ragCases: cases });

    const result = await handler(input);

    expect(result.status).toBe("SKIPPED");
    expect(bedrockMock.calls).toHaveLength(0);
  });
});

// ---------------------------------------------------------------------------
// Registry-only resolution — snapshot path wins over live store (R11.2)
// ---------------------------------------------------------------------------

describe("rag-evaluate handler — registry-only resolution", () => {
  it("uses the run-pinned snapshot's modelId when AgentSnapshot.prompts pins rag_evaluation_job (R11.2)", async () => {
    // Pin a non-default model on the run snapshot to prove the snapshot
    // path takes precedence over the live store. We pick `nova_pro` so
    // the assertion can distinguish it unambiguously from the registry's
    // bundled default (Claude Sonnet 4.6).
    const pinnedModelKey = "nova_pro" as const;
    const pinnedModel = SUPPORTED_MODELS[pinnedModelKey];
    const definition = PROMPT_REGISTRY.rag_evaluation_job;

    _clearPromptRegistryCaches();
    const getSnapshot = vi.fn().mockResolvedValue({
      prompts: {
        rag_evaluation_job: {
          text: definition.defaultText,
          modelKey: pinnedModelKey,
          modelId: pinnedModel.inferenceProfileId,
          inferenceParameters: definition.defaultInferenceValues,
          version: 0,
          capabilityProfileKey: pinnedModel.capabilityProfileKey,
        },
      },
    });
    const listPromptOverrides = vi.fn();
    const store = {
      getSnapshot,
      listPromptOverrides,
    } as unknown as DynamoDBService;
    _setPromptRegistryStore(store);

    const perPromptContent = makePerPromptJsonl([
      { faithfulness: 0.9, correctness: 0.85, completeness: 0.8, helpfulness: 0.95 },
    ]);
    const s3Mock = createMockS3Client({
      getObjectResponse: makeS3BodyResponse(perPromptContent),
    });
    const bedrockMock = createMockBedrockClient({
      getJobResponses: [{ status: "Completed" }],
    });
    const docMock = createMockDocClient();

    _setS3Client(s3Mock.client as any);
    _setBedrockClient(bedrockMock.client as any);
    _setDocClient(docMock.client as any);

    const result = await handler(makeInput());

    expect(result.status).toBe("COMPLETED");

    // R11.2 — snapshot consulted with the supplied runId; live store
    // never queried because the snapshot pinned the prompt.
    expect(getSnapshot).toHaveBeenCalledWith(RUN_ID);
    expect(listPromptOverrides).not.toHaveBeenCalled();

    // R10.2 — the snapshot-pinned modelId is the modelIdentifier wired
    // into CreateEvaluationJob, not the registry default.
    const createCalls = bedrockMock.calls.filter(
      (c) => c.commandName === "CreateEvaluationJobCommand",
    );
    expect(createCalls).toHaveLength(1);
    const createInput = createCalls[0].input as {
      evaluationConfig: {
        automated: {
          evaluatorModelConfig: {
            bedrockEvaluatorModels: Array<{ modelIdentifier: string }>;
          };
        };
      };
    };
    expect(
      createInput.evaluationConfig.automated.evaluatorModelConfig
        .bedrockEvaluatorModels[0].modelIdentifier,
    ).toBe(pinnedModel.inferenceProfileId);

    // RAGJOB observability record records the same pinned model id.
    const ragJobRecord = docMock.written[0];
    expect(ragJobRecord.judgeModelId).toBe(pinnedModel.inferenceProfileId);
  });

  it("does not read process.env.JUDGE_MODEL_ID (registry is the source of truth)", () => {
    // The Wave-2 migration (Task 17.7) removed the
    // `process.env.*_MODEL_ID ?? "..."` fallback from the source. The
    // static AST allow-list test
    // (`tests/properties/prompts-registry-only-resolution.property.test.ts`)
    // pins this at the source-tree level, but we also assert it here
    // as a fast feedback signal — same regression-guard pattern as
    // `tests/unit/tournament-summary.test.ts` and
    // `tests/unit/variant-generator.test.ts`.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const fs = require("node:fs");
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const path = require("node:path");
    const sourcePath = path.resolve(
      __dirname,
      "..",
      "..",
      "src/backend/orchestration/rag-evaluate.ts",
    );
    const source = fs.readFileSync(sourcePath, "utf8");
    expect(source).not.toMatch(
      /process\.env\.[A-Z][A-Z0-9_]*_MODEL_ID\s*\?\?/,
    );
  });
});
