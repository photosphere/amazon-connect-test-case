/**
 * Property 4: Registry-only resolution rule (static).
 *
 * The architectural invariant the prompt-management feature pins is:
 * **every Bedrock_Callsite resolves its prompt body and target model
 * through the Prompt_Registry.** No Bedrock-calling file under
 * `src/backend/handlers/` or `src/backend/orchestration/` is allowed
 * to (a) carry its own top-level `SYSTEM_PROMPT` literal, (b) wire a
 * `process.env.*_MODEL_ID ?? "..."` fallback for the resolved model
 * id, or (c) issue a Bedrock call without first resolving the prompt
 * via `resolvePromptForRun` / `resolvePromptLive` from the registry's
 * runtime helper module. R1.3 and R15.4 commit to this rule and the
 * design's Testing Strategy section names it "Property 4 — Registry-
 * only resolution rule (static)".
 *
 * Unlike the other four wave-3 properties (round-trip, idempotence,
 * placeholder preservation, capability-profile compliance) this is a
 * **static** invariant on the source tree itself, not a runtime
 * property over generated inputs. The check therefore walks the file
 * system rather than calling fast-check: we read every `.ts` file
 * under the two scoped roots, decide which files are Bedrock callsites
 * by a small set of trigger patterns (Bedrock SDK class imports +
 * `CreateEvaluationJob` substring), and assert each callsite either
 * complies with the rule or appears on a documented allow-list of
 * files awaiting migration.
 *
 * The allow-list is the migration ledger. Entries are removed in lock-
 * step with the Wave 1 / Wave 2 callsite migrations (Tasks 15.1–15.4
 * and Tasks 17.3–17.7 of the implementation plan); each migration's
 * sub-task explicitly says "remove from the allow-list in
 * `tests/properties/prompts-registry-only-resolution.property.test.ts`".
 * When the last entry leaves, the rule is enforced for the entire
 * source tree and any future file that imports a Bedrock SDK trigger
 * without going through the registry fails this test on the first CI
 * run.
 *
 * The test fails closed in three additional ways so the allow-list can
 * never silently drift away from the source tree:
 *
 *   1. **Allow-list integrity.** Every allow-list entry must exist on
 *      disk. A typo or a renamed file would otherwise cause the entry
 *      to be skipped silently.
 *   2. **Allow-list relevance.** Every allow-list entry must trigger
 *      the rule today (the file must contain at least one of the
 *      Bedrock trigger patterns). An allow-list entry for a file that
 *      no longer triggers the rule signals a stale ledger.
 *   3. **Allow-list necessity.** Every allow-list entry must in fact
 *      violate at least one of the three sub-rules today. If a file
 *      on the allow-list silently became compliant (e.g., a developer
 *      migrated a callsite without removing the ledger entry) the
 *      test surfaces it so the entry can be retired.
 *
 * The combined effect: an entry can be on the allow-list IFF the file
 * is currently a Bedrock callsite that violates the rule. Migrating a
 * callsite forces removing the ledger entry, and adding a ledger entry
 * for a file that has no business being there fails immediately.
 *
 * **Validates: Requirements 1.3, 15.4**
 */

import { readFileSync, statSync, readdirSync } from "node:fs";
import * as path from "node:path";

import { describe, expect, it } from "vitest";

// ---------------------------------------------------------------------------
// Scope of the static walk.
//
// The repo root is two levels up from this test file
// (`tests/properties/<this>.test.ts` → `<repo>/`). The two scoped roots
// are the Lambda handler tree (interactive HTTP endpoints) and the
// orchestration tree (Step Functions Lambdas + helper modules). The
// prompt-registry sub-tree under orchestration is excluded because it
// IS the registry — the file-level violation rule does not apply to
// the source of truth itself, and several registry files contain the
// trigger substrings (e.g. `CreateEvaluationJob` in JSDoc on the
// `rag_evaluation_job` definition, `ConverseCommand` in capability-
// profile module headers) which would otherwise cause false positives.
// Test files (`*.test.ts`) and `__tests__/` directories are also
// excluded for the same reason: they often reference the trigger
// symbols without being callsites themselves.
// ---------------------------------------------------------------------------

const REPO_ROOT = path.resolve(__dirname, "..", "..");

const SCOPED_ROOTS: readonly string[] = [
  path.join(REPO_ROOT, "src", "backend", "handlers"),
  path.join(REPO_ROOT, "src", "backend", "orchestration"),
];

const EXCLUDED_DIR_PREFIXES: readonly string[] = [
  // The registry itself is the source of truth, not a callsite. Files
  // under it legitimately reference the Bedrock SDK class names in
  // documentation and capability profiles.
  path.join(REPO_ROOT, "src", "backend", "orchestration", "prompt-registry"),
];

// Specific files that legitimately reference the Bedrock SDK trigger
// symbols but are NOT Bedrock callsites — they are part of the registry's
// own enforcement infrastructure. Files listed here are excluded from the
// callsite scan entirely (they are not callsites and therefore not subject
// to the registry-only resolution rule).
//
// Currently:
//   - `prompts-validation.ts` constructs a `ConverseCommand` for the
//     dry-render validator (R4.10) but never sends it. The validator IS
//     part of the registry's gate, not a consumer of it, so requiring it
//     to import `resolvePromptLive` would create a circular dependency.
const EXCLUDED_FILE_PATHS: readonly string[] = [
  path.join(REPO_ROOT, "src", "backend", "handlers", "prompts-validation.ts"),
];

// ---------------------------------------------------------------------------
// Allow-list — files awaiting migration to the registry.
//
// Each entry comments the migration task that owns its removal. When
// the corresponding callsite is migrated to `resolvePromptForRun` /
// `resolvePromptLive`, the migration sub-task removes the legacy
// `const SYSTEM_PROMPT = ...` literal and the `process.env.*_MODEL_ID`
// fallback, and the same commit deletes that entry from this list.
// The test's "Allow-list necessity" check (below) ensures the entry
// cannot remain after the file becomes compliant.
//
// Paths are repo-relative with forward slashes so the list reads the
// same on macOS, Linux, and Windows. They are normalised to absolute
// paths before comparison against the file walker output.
// ---------------------------------------------------------------------------

const MIGRATION_ALLOW_LIST: readonly string[] = [
  // Wave 1 — interactive HTTP callsites (Tasks 15.1–15.4): all migrated.
  // Wave 2 — in-run callsites (Tasks 17.3–17.7): all migrated.
  //
  // The allow-list is now empty. The headline rule below is enforced
  // for every Bedrock callsite under `src/backend/handlers/` and
  // `src/backend/orchestration/` (excluding the registry itself and
  // the prompts-validation dry-render gate). Adding a new Bedrock
  // callsite that does not resolve via `resolvePromptForRun` /
  // `resolvePromptLive` fails this test on the first CI run.
];

const MIGRATION_ALLOW_LIST_ABS: readonly string[] =
  MIGRATION_ALLOW_LIST.map((relPath) => path.join(REPO_ROOT, relPath));

// ---------------------------------------------------------------------------
// Trigger detection — "is this file a Bedrock callsite?"
//
// A file is treated as a Bedrock callsite if its source contains any
// of the four trigger patterns the design names. Word-boundary regex
// is used so the match cannot land on an unrelated identifier that
// happens to share a substring (`BedrockRuntimeClientFactory` would
// match `BedrockRuntimeClient` without the boundary). Matching the
// raw source text (rather than parsed import bindings) is intentional
// — the `CreateEvaluationJob` trigger is a method/command call, not
// an import binding, so the same regex strategy covers all four.
// ---------------------------------------------------------------------------

const BEDROCK_CALLSITE_TRIGGERS: readonly RegExp[] = [
  /\bBedrockRuntimeClient\b/,
  /\bConverseCommand\b/,
  /\bBedrockAgentCoreClient\b/,
  /\bCreateEvaluationJob\b/,
];

// ---------------------------------------------------------------------------
// Sub-rule regexes.
//
// **Registry import (positive rule).** The file must import at least
// one of `resolvePromptForRun` / `resolvePromptLive` from a module
// path containing `prompt-registry`. The registry's public surface
// re-exports both, so the path may be the package index, the runtime
// sub-module, or a deep relative path — all are accepted. The regex
// matches the named-import binding inside the same `import { ... }`
// block whose module specifier contains `prompt-registry`.
//
// **No top-level SYSTEM_PROMPT (negative rule).** The legacy callsites
// declare `const SYSTEM_PROMPT = ...` at module scope (column 0). The
// regex anchors to start-of-line so a `system_prompt` field name
// inside a JSON body or a nested function-scope declaration cannot
// trip it. Multiline mode (`m` flag) is on so `^` matches every line.
//
// **No `*_MODEL_ID ?? "..."` fallback (negative rule).** The legacy
// callsites read the resolved model id via
// `process.env.SOME_MODEL_ID ?? "us.anthropic..."`; the rule is
// equally violated by `||` so we accept either operator. The capture
// group is unused — the predicate is just "does this pattern appear
// anywhere in the source?".
// ---------------------------------------------------------------------------

const REGISTRY_IMPORT_REGEX =
  /import\s*\{[^}]*\b(?:resolvePromptForRun|resolvePromptLive)\b[^}]*\}\s*from\s*["'][^"']*prompt-registry[^"']*["']/;

const TOP_LEVEL_SYSTEM_PROMPT_REGEX = /^const\s+SYSTEM_PROMPT\s*=/m;

const ENV_MODEL_ID_FALLBACK_REGEX =
  /process\.env\.[A-Z][A-Z0-9_]*_MODEL_ID\s*(?:\?\?|\|\|)\s*["'`]/;

// ---------------------------------------------------------------------------
// Filesystem walk.
//
// Recursive directory listing rooted at each scoped root, filtered to
// `.ts` files (skipping `.d.ts` declaration files and `*.test.ts`
// peers — neither category contains runtime code so neither is a
// callsite). Excluded directory prefixes are skipped wholesale rather
// than per-file to keep the walk cheap and the diagnostics clear when
// a future contributor adds a sibling under `prompt-registry/`.
// ---------------------------------------------------------------------------

interface CallsiteAnalysis {
  readonly filePath: string;
  readonly relativePath: string;
  readonly isCallsite: boolean;
  readonly importsRegistryRuntime: boolean;
  readonly hasTopLevelSystemPrompt: boolean;
  readonly hasEnvModelIdFallback: boolean;
}

function analyseFile(filePath: string): CallsiteAnalysis {
  const source = readFileSync(filePath, "utf8");
  const isCallsite = BEDROCK_CALLSITE_TRIGGERS.some((rx) => rx.test(source));
  return {
    filePath,
    relativePath: path.relative(REPO_ROOT, filePath),
    isCallsite,
    importsRegistryRuntime: REGISTRY_IMPORT_REGEX.test(source),
    hasTopLevelSystemPrompt: TOP_LEVEL_SYSTEM_PROMPT_REGEX.test(source),
    hasEnvModelIdFallback: ENV_MODEL_ID_FALLBACK_REGEX.test(source),
  };
}

/**
 * A callsite complies with the rule iff all three sub-rules hold:
 *   1. It imports `resolvePromptForRun` / `resolvePromptLive` from
 *      a `prompt-registry` module.
 *   2. It does NOT carry a top-level `const SYSTEM_PROMPT = ` literal.
 *   3. It does NOT carry a `process.env.*_MODEL_ID ?? "..."` fallback.
 */
function isCompliant(analysis: CallsiteAnalysis): boolean {
  return (
    analysis.importsRegistryRuntime &&
    !analysis.hasTopLevelSystemPrompt &&
    !analysis.hasEnvModelIdFallback
  );
}

function describeViolations(analysis: CallsiteAnalysis): string[] {
  const reasons: string[] = [];
  if (!analysis.importsRegistryRuntime) {
    reasons.push(
      "missing `resolvePromptForRun`/`resolvePromptLive` import from prompt-registry",
    );
  }
  if (analysis.hasTopLevelSystemPrompt) {
    reasons.push("contains a top-level `const SYSTEM_PROMPT = ` literal");
  }
  if (analysis.hasEnvModelIdFallback) {
    reasons.push("contains a `process.env.*_MODEL_ID ?? \"...\"` fallback");
  }
  return reasons;
}

// ---------------------------------------------------------------------------
// Eager scan — performed once at module load so every test below sees
// the same snapshot of the source tree. Deferring the scan to a
// `beforeAll` hook would work too, but Vitest's `it.each` (used for
// the per-allow-list-entry assertions) only enumerates table rows at
// describe-block evaluation, so the scan must happen synchronously
// before the describe blocks register.
//
// The walker is sync (`readdirSync`) so we avoid top-level `await`,
// which the root tsconfig's `module: "commonjs"` does not permit
// (and which we cannot bump without breaking ts-node's CDK app
// loader). The recursive walker is in-memory only and the scoped
// roots are small (a few dozen `.ts` files) so the wall-clock cost
// of the I/O is negligible.
// ---------------------------------------------------------------------------

function scanScopedRoots(): CallsiteAnalysis[] {
  const allFiles: string[] = [];
  for (const root of SCOPED_ROOTS) {
    const fileList = walkTypeScriptFilesSync(root);
    for (const f of fileList) allFiles.push(f);
  }
  return allFiles.map(analyseFile);
}

function walkTypeScriptFilesSync(rootDir: string): string[] {
  const out: string[] = [];

  function visit(dir: string): void {
    if (EXCLUDED_DIR_PREFIXES.some((prefix) => dir === prefix || dir.startsWith(prefix + path.sep))) {
      return;
    }

    let entries: Array<{ name: string; isDirectory: () => boolean; isFile: () => boolean }>;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch (err) {
      throw new Error(
        `Failed to read directory ${dir}: ${err instanceof Error ? err.message : String(err)}`,
      );
    }

    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        visit(full);
        continue;
      }
      if (!entry.isFile()) continue;
      if (!entry.name.endsWith(".ts")) continue;
      if (entry.name.endsWith(".d.ts")) continue;
      if (entry.name.endsWith(".test.ts")) continue;
      if (EXCLUDED_FILE_PATHS.includes(full)) continue;
      out.push(full);
    }
  }

  visit(rootDir);
  return out;
}

const ALL_ANALYSES: readonly CallsiteAnalysis[] = scanScopedRoots();

const CALLSITE_ANALYSES: readonly CallsiteAnalysis[] = ALL_ANALYSES.filter(
  (a) => a.isCallsite,
);

const ALLOW_LIST_SET = new Set<string>(MIGRATION_ALLOW_LIST_ABS);

// ---------------------------------------------------------------------------
// 1. Allow-list integrity — every entry must exist on disk.
//
// A typo or renamed file would otherwise cause an entry to be silently
// skipped, hiding a missed migration. We `statSync` each entry rather
// than checking against the walker output so a file outside the
// scoped roots (e.g., moved to `src/frontend/`) also surfaces.
// ---------------------------------------------------------------------------

describe("Property 4 — Allow-list integrity (every entry exists on disk)", () => {
  if (MIGRATION_ALLOW_LIST.length === 0) {
    // Vitest's `it.each` errors out with "No test found in suite" when
    // its table is empty; emit a single placeholder test so the suite
    // is still discovered after every callsite has been migrated.
    it("allow-list is empty — every Bedrock callsite is migrated", () => {
      expect(MIGRATION_ALLOW_LIST).toEqual([]);
    });
  } else {
    it.each(MIGRATION_ALLOW_LIST)("[%s] is a real file under the repo", (relPath) => {
      const abs = path.join(REPO_ROOT, relPath);
      let exists = false;
      try {
        exists = statSync(abs).isFile();
      } catch {
        exists = false;
      }
      expect(
        exists,
        `Allow-list entry ${relPath} does not exist as a regular file. Did the path change in a recent commit?`,
      ).toBe(true);
    });
  }
});

// ---------------------------------------------------------------------------
// 2. Allow-list relevance — every entry must trigger the rule today.
//
// An allow-list entry that no longer matches a Bedrock trigger pattern
// (e.g., the file was rewritten not to use the SDK) is stale. The
// ledger should be tightened so the next reader can trust it.
// ---------------------------------------------------------------------------

describe("Property 4 — Allow-list relevance (every entry is a current Bedrock callsite)", () => {
  if (MIGRATION_ALLOW_LIST.length === 0) {
    it("allow-list is empty — relevance check trivially passes", () => {
      expect(MIGRATION_ALLOW_LIST).toEqual([]);
    });
  } else {
    it.each(MIGRATION_ALLOW_LIST)(
      "[%s] still matches at least one Bedrock callsite trigger",
      (relPath) => {
        const abs = path.join(REPO_ROOT, relPath);
        const analysis = ALL_ANALYSES.find((a) => a.filePath === abs);
        expect(
          analysis,
          `Allow-list entry ${relPath} was not visited by the walker. Either the path is outside the scoped roots or the walker excludes it. Either fix the entry or expand the walker scope.`,
        ).toBeDefined();
        expect(
          analysis!.isCallsite,
          `Allow-list entry ${relPath} no longer matches any Bedrock trigger pattern. The entry is stale — remove it from MIGRATION_ALLOW_LIST.`,
        ).toBe(true);
      },
    );
  }
});

// ---------------------------------------------------------------------------
// 3. Allow-list necessity — every entry must currently violate the rule.
//
// If a file on the allow-list silently became compliant (e.g., a
// developer migrated the callsite without removing the ledger entry)
// the test surfaces it. Without this check the ledger would
// monotonically grow stale as migrations land.
// ---------------------------------------------------------------------------

describe("Property 4 — Allow-list necessity (every entry currently violates ≥1 sub-rule)", () => {
  if (MIGRATION_ALLOW_LIST.length === 0) {
    it("allow-list is empty — necessity check trivially passes", () => {
      expect(MIGRATION_ALLOW_LIST).toEqual([]);
    });
  } else {
    it.each(MIGRATION_ALLOW_LIST)(
      "[%s] violates at least one sub-rule (registry import / no SYSTEM_PROMPT / no MODEL_ID fallback)",
      (relPath) => {
        const abs = path.join(REPO_ROOT, relPath);
        const analysis = ALL_ANALYSES.find((a) => a.filePath === abs)!;
        expect(
          isCompliant(analysis),
          `Allow-list entry ${relPath} now satisfies all three sub-rules. The file appears to have been migrated — remove it from MIGRATION_ALLOW_LIST so the rule starts being enforced for it.`,
        ).toBe(false);
      },
    );
  }
});

// ---------------------------------------------------------------------------
// 4. The headline rule — every Bedrock callsite either complies or is
//    on the allow-list.
//
// This is the assertion that matters for the build. Today every
// triggered file is on the allow-list, so the test passes. Each
// migration sub-task in Wave 1 / Wave 2 brings exactly one file into
// compliance and removes its allow-list entry — at which point this
// assertion would surface the rule for that file. After the last
// migration the allow-list is empty and the rule is enforced for the
// entire scoped tree.
//
// Per-file `it.each` rather than a single aggregate assertion so the
// CI report names exactly which file violates exactly which sub-rule
// when the rule fails.
// ---------------------------------------------------------------------------

describe("Property 4 — Registry-only resolution rule (every callsite either complies or is allow-listed)", () => {
  // Sort by relative path for stable test report ordering across runs.
  const callsites = [...CALLSITE_ANALYSES].sort((a, b) =>
    a.relativePath.localeCompare(b.relativePath),
  );

  // Sanity check: the walk must have found at least one Bedrock
  // callsite. A zero count would mean the trigger regexes are wrong
  // or the walker has the wrong scope, either of which would silently
  // disable the rule.
  it("found at least one Bedrock callsite to enforce against", () => {
    expect(
      callsites.length,
      "No files matched the Bedrock callsite triggers. The trigger regexes or the walker scope is broken.",
    ).toBeGreaterThan(0);
  });

  it.each(callsites.map((a) => [a.relativePath, a] as const))(
    "[%s] either resolves through the registry or is on the migration allow-list",
    (_relativePath, analysis) => {
      if (ALLOW_LIST_SET.has(analysis.filePath)) {
        // Allow-listed callsites are exempt from the rule until their
        // owning migration sub-task lands. The "Allow-list necessity"
        // describe block above already pinned that they currently
        // violate ≥1 sub-rule, so there is nothing more to check here.
        return;
      }

      const compliant = isCompliant(analysis);
      const violations = describeViolations(analysis);
      expect(
        compliant,
        `${analysis.relativePath} is a Bedrock callsite but violates the registry-only resolution rule:\n  - ${violations.join("\n  - ")}\n\nResolve via \`resolvePromptForRun\` (run-pinned) or \`resolvePromptLive\` (interactive) from \`prompt-registry/runtime\`, drop any top-level SYSTEM_PROMPT literal, and remove the \`process.env.*_MODEL_ID ?? "..."\` fallback. If the migration is intentional and pending, add the file to MIGRATION_ALLOW_LIST.`,
      ).toBe(true);
    },
  );
});
