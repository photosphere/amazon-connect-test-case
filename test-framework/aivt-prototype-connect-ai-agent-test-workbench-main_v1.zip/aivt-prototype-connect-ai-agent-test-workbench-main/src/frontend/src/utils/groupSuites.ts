/**
 * Utility for grouping enriched test suites by their resolved agent name.
 *
 * Powers the agent-grouped layout on the Test Suites page: suites are
 * bucketed under one group per distinct `agentName`, groups are ordered
 * alphabetically, and suite order within each group is preserved.
 *
 * @module groupSuites
 */

import type { EnrichedTestSuite } from '../../../shared/types';

/** A set of suites that all belong to the same agent. */
export interface AgentGroup {
  agentName: string;
  suites: EnrichedTestSuite[];
}

/**
 * Groups suites by `agentName` and returns groups sorted alphabetically
 * (ascending lexicographic order) by agent name. Suites within each group
 * preserve their original input order.
 *
 * @param suites - The enriched suites to group.
 * @returns One {@link AgentGroup} per distinct `agentName`, alphabetically ordered.
 */
export function groupSuitesByAgent(suites: EnrichedTestSuite[]): AgentGroup[] {
  const map = new Map<string, EnrichedTestSuite[]>();

  for (const suite of suites) {
    const group = map.get(suite.agentName) ?? [];
    group.push(suite);
    map.set(suite.agentName, group);
  }

  return Array.from(map.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([agentName, groupSuites]) => ({ agentName, suites: groupSuites }));
}
