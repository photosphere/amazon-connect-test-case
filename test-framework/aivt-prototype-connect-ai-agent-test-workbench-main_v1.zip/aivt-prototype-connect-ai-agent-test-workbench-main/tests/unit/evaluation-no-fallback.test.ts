// Feature: bedrock-judge-evaluations, Property 7: No local-scoring fallback path
/**
 * Static guard — the rewritten Evaluation Lambda
 * (`src/backend/orchestration/evaluation.ts`) MUST never import any
 * local-scoring helper or any AgentCore-era module, and MUST always
 * import the two pure modules that compose the Bedrock-judge pipeline.
 *
 * **Property 7: No local-scoring fallback path**
 *
 * **Validates: Requirements 8.5, 8.8**
 *
 * Requirement 8.5 forbids the Platform from substituting any local
 * value (zero, the local `calculateToolAccuracy` helper, the mean of
 * the scale, or any other default) when an `Evaluation_Error_State` is
 * set. Requirement 8.8 forbids the Lambda from computing or persisting
 * `toolAccuracyScore` from the local `calculateToolAccuracy` logic.
 * Together they require the Evaluation Lambda to be wired exclusively
 * to the Bedrock-judge composition: the pure prompt-rendering module
 * (`judge-prompt-rendering`) and the thin Converse seam
 * (`bedrock-judge-client`).
 *
 * Structurally enforcing this at the import level makes a future
 * regression (a stray `import { calculateToolAccuracy } from
 * "../../shared/utils/tool-accuracy"`, a resurrected
 * `agentcore-client`, or a leaked `trace-to-otel` translator) caught
 * before any runtime test, and before the Lambda is even bundled.
 *
 * The check has two halves:
 *
 *   1. **Forbidden import specifiers.** No `import` (or re-export)
 *      statement in the source resolves to a module path containing
 *      any of: `calculateToolAccuracy`, `tool-accuracy`, `accuracy`,
 *      `trace-to-otel`, or `agentcore-client`. The first is caught
 *      both as an import specifier and as a bare symbol reference,
 *      since the symbol could in principle be re-imported under an
 *      alias from a wrapper module.
 *   2. **Required import specifiers.** At least one `import` statement
 *      resolves to a module path ending in `bedrock-judge-client`, and
 *      at least one resolves to a path ending in
 *      `judge-prompt-rendering`. The Lambda is meaningless without
 *      these two seams.
 *
 * The test is intentionally a plain Vitest assertion over the source
 * bytes — it costs nothing and does not require the Lambda runtime,
 * esbuild, or the AWS SDK.
 */

import { readFileSync } from "node:fs";
import * as path from "node:path";
import { describe, expect, it } from "vitest";

describe("Evaluation Lambda — no local-scoring fallback (Property 7, Reqs 8.5, 8.8)", () => {
  const modulePath = path.resolve(
    __dirname,
    "../../src/backend/orchestration/evaluation.ts"
  );

  // Cache the file read once — every assertion below operates on the
  // same source body.
  const source = readFileSync(modulePath, "utf8");

  // Strip both `/* ... */` block comments and `// ...` line comments so
  // the rewrite's JSDoc — which legitimately documents the no-fallback
  // rule and uses the forbidden symbol names in commentary (e.g.
  // "the local `calculateToolAccuracy` helper" or "every reference to
  // `trace-to-otel`, `agentcore-client`, `callAgentCoreEvaluation`,
  // `computeFallbackScores`") — cannot trip the assertions. The line-
  // comment pattern preserves a leading non-`/` character so URLs
  // (e.g. `https://...`) are unaffected.
  const stripped = source
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/(^|[^:])\/\/[^\n]*/g, "$1");

  // -------------------------------------------------------------------------
  // 1. Forbidden import specifiers
  //
  // Each blacklist entry is matched against `from '<specifier>'` /
  // `from "<specifier>"` AND bare `import '<specifier>'` /
  // `import "<specifier>"` side-effect imports, so the test catches
  // relative paths (`'../../shared/utils/tool-accuracy'`), alias paths
  // (`'@shared/utils/tool-accuracy'`), sub-path imports
  // (`'.../tool-accuracy/index'`), and side-effect imports.
  // -------------------------------------------------------------------------

  const FORBIDDEN_IMPORT_SUBSTRINGS = [
    "calculateToolAccuracy",
    "tool-accuracy",
    "trace-to-otel",
    "agentcore-client",
    // `accuracy` is intentionally listed last and matched after the
    // more-specific `tool-accuracy` so a failure pinpoints the
    // narrower violation first when both apply. Note: this also
    // catches a hypothetical `../../shared/utils/accuracy` import
    // (the run-level percentage helper) being pulled into the
    // Evaluation Lambda — also forbidden, since the Lambda must not
    // compute scores locally under any name.
    "accuracy",
  ] as const;

  for (const forbidden of FORBIDDEN_IMPORT_SUBSTRINGS) {
    it(`does not import any module whose path contains '${forbidden}'`, () => {
      // `from '...'` / `from "..."` import or re-export.
      const fromRe = new RegExp(
        `from\\s+['\"][^'\"]*${forbidden}(?:['\"]|\\/)`
      );
      // Bare side-effect import (`import '...'`).
      const sideEffectRe = new RegExp(
        `import\\s+['\"][^'\"]*${forbidden}(?:['\"]|\\/)`
      );

      expect(stripped).not.toMatch(fromRe);
      expect(stripped).not.toMatch(sideEffectRe);
    });
  }

  it("does not reference the `calculateToolAccuracy` symbol anywhere in code", () => {
    // The token is rejected as a whole identifier — `calculateToolAccuracyV2`
    // would still match `\bcalculateToolAccuracy` so we anchor with a
    // word boundary on each side. After comment stripping above, any
    // surviving occurrence is a real code-level reference (an alias
    // import from a wrapper module would still bind to this symbol
    // name in code).
    expect(stripped).not.toMatch(/\bcalculateToolAccuracy\b/);
  });

  // -------------------------------------------------------------------------
  // 2. Required import specifiers
  //
  // The Lambda's whole purpose is to compose `bedrock-judge-client`
  // (the Converse seam) with `judge-prompt-rendering` (the pure
  // prompt-rendering module). Either being absent indicates the
  // module has been gutted or rewired around the supported pipeline,
  // which is the precondition every other test in this file assumes.
  // -------------------------------------------------------------------------

  const REQUIRED_IMPORT_SUBSTRINGS = [
    "bedrock-judge-client",
    "judge-prompt-rendering",
  ] as const;

  for (const required of REQUIRED_IMPORT_SUBSTRINGS) {
    it(`imports a module whose path ends in '${required}'`, () => {
      // Match either `from '...<required>'` or
      // `from '...<required>/<sub>'` so a barrel re-export still counts.
      const re = new RegExp(
        `from\\s+['\"][^'\"]*${required}(?:['\"]|\\/[^'\"]*['\"])`
      );
      expect(stripped).toMatch(re);
    });
  }
});
