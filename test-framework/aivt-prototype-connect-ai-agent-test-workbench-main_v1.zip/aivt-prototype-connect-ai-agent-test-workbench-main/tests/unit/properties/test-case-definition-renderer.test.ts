// Feature: test-case-validity-analysis, Properties 1 & 2: Test case definition renderer
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import {
  renderTestCaseDefinition,
  buildAnalysisPrompt,
} from "@backend/handlers/analysis";
import type { ToolSequenceTestCase, ToolDefinition, TranscriptTurn } from "@shared/types";
import { CommunicationStyle } from "@shared/enums";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Non-empty trimmed string for required text fields. */
const nonEmptyStringArb = fc
  .string({ minLength: 1, maxLength: 100 })
  .filter((s) => s.trim().length > 0);

/** Communication style enum value. */
const styleArb: fc.Arbitrary<CommunicationStyle> = fc.constantFrom(
  CommunicationStyle.DIRECT,
  CommunicationStyle.INDIRECT,
  CommunicationStyle.COLLOQUIAL,
  CommunicationStyle.QUESTION,
  CommunicationStyle.COMPLAINT,
);

/** Arbitrary parameter check for a tool step. */
const parameterCheckArb = fc.record({
  paramName: nonEmptyStringArb,
  expectedValue: nonEmptyStringArb,
});

/** Arbitrary tool step with at least a tool name. */
const toolStepArb = fc.record({
  toolName: nonEmptyStringArb,
  required: fc.boolean(),
  parameterChecks: fc.option(
    fc.array(parameterCheckArb, { minLength: 0, maxLength: 3 }),
    { nil: undefined },
  ),
});

/** Arbitrary customerKnowledge map (0 to 5 entries). */
const customerKnowledgeArb: fc.Arbitrary<Record<string, string>> = fc
  .array(
    fc.tuple(nonEmptyStringArb, nonEmptyStringArb),
    { minLength: 0, maxLength: 5 },
  )
  .map((pairs) => Object.fromEntries(pairs));

/** Arbitrary goalDescription — either present, whitespace-only, or absent. */
const goalDescriptionArb: fc.Arbitrary<string | undefined> = fc.oneof(
  fc.constant(undefined),
  fc.constant(""),
  fc.constant("   "),
  nonEmptyStringArb,
);

/**
 * Arbitrary valid ToolSequenceTestCase with non-empty name, description,
 * persona, initialUtterance, and at least one entry in successCriteria.
 */
const validTestCaseArb: fc.Arbitrary<ToolSequenceTestCase> = fc.record({
  suiteId: nonEmptyStringArb,
  caseId: nonEmptyStringArb,
  name: nonEmptyStringArb,
  description: nonEmptyStringArb,
  type: fc.constant("tool_sequence" as const),
  persona: nonEmptyStringArb,
  style: styleArb,
  customerKnowledge: customerKnowledgeArb,
  initialUtterance: nonEmptyStringArb,
  successCriteria: fc.array(toolStepArb, { minLength: 1, maxLength: 10 }),
  goalDescription: goalDescriptionArb,
});

// ---------------------------------------------------------------------------
// Property 1: Test case definition renderer completeness
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 1.1, 1.3, 1.4, 1.5, 11.5**
 *
 * Property 1: Test case definition renderer completeness
 *
 * For any valid ToolSequenceTestCase with non-empty name, description, persona,
 * initialUtterance, and at least one entry in successCriteria, the rendered
 * `## Test Case Definition` string SHALL contain:
 *   - the literal "## Test Case Definition"
 *   - the test case's name, description, persona, style, initialUtterance
 *   - every toolName from successCriteria
 *   - either each key from customerKnowledge or "(none)" when the map is empty
 *   - when goalDescription is absent or whitespace-only, "Goal: (not specified)"
 */
describe("Feature: test-case-validity-analysis, Property 1: Test case definition renderer completeness", () => {
  it("rendered output contains '## Test Case Definition' header", () => {
    fc.assert(
      fc.property(validTestCaseArb, (testCase) => {
        const output = renderTestCaseDefinition(testCase);
        expect(output).toContain("## Test Case Definition");
      }),
      { numRuns: 100 },
    );
  });

  it("rendered output contains the test case's name, description, persona, style, and initialUtterance", () => {
    fc.assert(
      fc.property(validTestCaseArb, (testCase) => {
        const output = renderTestCaseDefinition(testCase);
        expect(output).toContain(testCase.name);
        expect(output).toContain(testCase.description);
        expect(output).toContain(testCase.persona);
        expect(output).toContain(testCase.style);
        expect(output).toContain(testCase.initialUtterance);
      }),
      { numRuns: 100 },
    );
  });

  it("rendered output contains every toolName from successCriteria", () => {
    fc.assert(
      fc.property(validTestCaseArb, (testCase) => {
        const output = renderTestCaseDefinition(testCase);
        for (const step of testCase.successCriteria) {
          expect(output).toContain(step.toolName);
        }
      }),
      { numRuns: 100 },
    );
  });

  it("rendered output contains each customerKnowledge key or '(none)' when empty", () => {
    fc.assert(
      fc.property(validTestCaseArb, (testCase) => {
        const output = renderTestCaseDefinition(testCase);
        const entries = Object.entries(testCase.customerKnowledge);
        if (entries.length === 0) {
          expect(output).toContain("(none)");
        } else {
          for (const [key] of entries) {
            expect(output).toContain(key);
          }
        }
      }),
      { numRuns: 100 },
    );
  });

  it("renders 'Goal: (not specified)' when goalDescription is absent or whitespace-only", () => {
    fc.assert(
      fc.property(validTestCaseArb, (testCase) => {
        const output = renderTestCaseDefinition(testCase);
        const trimmed = testCase.goalDescription?.trim();
        if (!trimmed) {
          expect(output).toContain("Goal: (not specified)");
        } else {
          expect(output).toContain(`Goal: ${trimmed}`);
          expect(output).not.toContain("Goal: (not specified)");
        }
      }),
      { numRuns: 100 },
    );
  });

  it("renders null test case with fallback message", () => {
    const output = renderTestCaseDefinition(null);
    expect(output).toContain("## Test Case Definition");
    expect(output).toContain("Test case record not found");
  });
});

// ---------------------------------------------------------------------------
// Property 2: Prompt section ordering
// ---------------------------------------------------------------------------

/** Minimal ToolDefinition for prompt construction. */
const toolDefinitionArb: fc.Arbitrary<ToolDefinition> = fc.record({
  toolName: nonEmptyStringArb,
  toolType: fc.constant("TOOL"),
  description: nonEmptyStringArb,
  instruction: fc.option(nonEmptyStringArb, { nil: undefined }),
  inputSchema: fc.constant({}),
  examples: fc.array(fc.string({ minLength: 1, maxLength: 50 }), { minLength: 0, maxLength: 2 }),
});

/** Minimal TranscriptTurn. */
const transcriptTurnArb: fc.Arbitrary<TranscriptTurn> = fc.record({
  turnNumber: fc.nat({ max: 20 }),
  role: fc.constantFrom("customer" as const, "agent" as const),
  text: nonEmptyStringArb,
  timestamp: fc.date({ min: new Date("2024-01-01"), max: new Date("2026-01-01") }).map((d) => d.toISOString()),
  elapsedMs: fc.nat({ max: 30000 }),
});

/**
 * **Validates: Requirements 1.2**
 *
 * Property 2: Prompt section ordering
 *
 * For any non-null test case, the rendered prompt (when placed in context)
 * has "## Test Case Definition" at an index after "## Test Case:" and before
 * "## Conversation Transcript". Now that buildAnalysisPrompt accepts
 * testCaseDefinition (task 3.1), we verify the ordering directly on the
 * actual prompt output.
 */
describe("Feature: test-case-validity-analysis, Property 2: Prompt section ordering", () => {
  it("'## Test Case Definition' appears after '## Test Case:' and before '## Conversation Transcript' in constructed prompt", () => {
    fc.assert(
      fc.property(
        validTestCaseArb,
        nonEmptyStringArb, // caseId
        fc.array(transcriptTurnArb, { minLength: 1, maxLength: 5 }),
        fc.array(toolDefinitionArb, { minLength: 1, maxLength: 3 }),
        nonEmptyStringArb, // systemPrompt
        (testCase, caseId, transcript, agentTools, systemPrompt) => {
          const prompt = buildAnalysisPrompt({
            caseId,
            testCaseDefinition: testCase,
            transcript,
            reasoningTrace: null,
            expectedTools: [],
            actualTools: [],
            agentTools,
            systemPrompt,
          });

          const testCaseHeaderIdx = prompt.indexOf("## Test Case:");
          const testCaseDefIdx = prompt.indexOf("## Test Case Definition");
          const transcriptIdx = prompt.indexOf("## Conversation Transcript");

          // All three sections must be present
          expect(testCaseHeaderIdx).toBeGreaterThanOrEqual(0);
          expect(testCaseDefIdx).toBeGreaterThanOrEqual(0);
          expect(transcriptIdx).toBeGreaterThanOrEqual(0);

          // Correct ordering: Test Case: < Test Case Definition < Conversation Transcript
          expect(testCaseDefIdx).toBeGreaterThan(testCaseHeaderIdx);
          expect(transcriptIdx).toBeGreaterThan(testCaseDefIdx);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("buildAnalysisPrompt output contains '## Test Case:' and '## Conversation Transcript' in correct order", () => {
    fc.assert(
      fc.property(
        nonEmptyStringArb, // caseId
        fc.array(transcriptTurnArb, { minLength: 1, maxLength: 3 }),
        fc.array(nonEmptyStringArb, { minLength: 0, maxLength: 3 }), // expectedTools
        fc.array(nonEmptyStringArb, { minLength: 0, maxLength: 3 }), // actualTools
        fc.array(toolDefinitionArb, { minLength: 1, maxLength: 3 }),
        nonEmptyStringArb, // systemPrompt
        (caseId, transcript, expectedTools, actualTools, agentTools, systemPrompt) => {
          const prompt = buildAnalysisPrompt({
            caseId,
            testCaseDefinition: null,
            transcript,
            reasoningTrace: null,
            expectedTools,
            actualTools,
            agentTools,
            systemPrompt,
          });

          const testCaseHeaderIdx = prompt.indexOf("## Test Case:");
          const transcriptIdx = prompt.indexOf("## Conversation Transcript");

          // Both sections must be present
          expect(testCaseHeaderIdx).toBeGreaterThanOrEqual(0);
          expect(transcriptIdx).toBeGreaterThanOrEqual(0);

          // Test Case: header comes before Conversation Transcript
          expect(transcriptIdx).toBeGreaterThan(testCaseHeaderIdx);
        },
      ),
      { numRuns: 100 },
    );
  });
});
