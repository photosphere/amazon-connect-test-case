// Feature: bedrock-judge-evaluations, Property 6: An evaluation error state leaves all three scores unset
// Feature: bedrock-judge-evaluations, Property 7: Tool accuracy originates only from the Bedrock judge, never from local scoring
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import {
  assembleCaseEvaluation,
  type FailureContext,
} from '../../../src/shared/utils/evaluation-result';
import {
  REQUESTED_EVALUATOR_IDS,
  aggregateScores,
  type AggregatedScores,
  type EvaluationResultContent,
  type EvaluatorOutcome,
} from '../../../src/shared/utils/evaluation-scoring';

/**
 * Property tests for the evaluation-result assembly module
 * (`src/shared/utils/evaluation-result.ts`).
 *
 * Property 6 lives in this file. Property 7 (task 5.3) will also be
 * exercised in a separate static-check file.
 *
 * The module under test is pure and has no AWS imports, so this test
 * exercises its real behaviour without any mocking.
 */

// ---------------------------------------------------------------------------
// Shared arbitraries
// ---------------------------------------------------------------------------

const REQUESTED_IDS = [...REQUESTED_EVALUATOR_IDS];

/** A non-finite numeric value: NaN, +Infinity, or -Infinity. */
const nonFiniteNumberArb: fc.Arbitrary<number> = fc.constantFrom(
  Number.NaN,
  Number.POSITIVE_INFINITY,
  Number.NEGATIVE_INFINITY
);

/** A finite value — possibly out of [0,1]. Exercises the clamp path. */
const anyFiniteValueArb: fc.Arbitrary<number> = fc.double({
  min: -1_000,
  max: 1_000,
  noNaN: true,
  noDefaultInfinity: true,
});

/**
 * A result whose `value` is a usable finite number. Used to construct
 * outcomes that should produce a defined score.
 */
const usableResultArb: fc.Arbitrary<EvaluationResultContent> = fc.record({
  value: anyFiniteValueArb,
  label: fc.option(fc.string({ maxLength: 8 }), { nil: undefined }),
  explanation: fc.option(fc.string({ maxLength: 16 }), { nil: undefined }),
});

/**
 * A result whose `value` is "unusable": either non-finite, missing, or a
 * non-numeric type. These cause the evaluator to be flagged as missing
 * by `aggregateScores`.
 */
const unusableResultArb: fc.Arbitrary<EvaluationResultContent> = fc.oneof(
  nonFiniteNumberArb.map((value) => ({ value }) as EvaluationResultContent),
  fc.constant({} as EvaluationResultContent),
  fc.string({ maxLength: 5 }).map(
    (s) => ({ value: s as unknown as number }) as EvaluationResultContent
  )
);

/** Free-form result: usable, non-finite, or absent. */
const anyResultArb: fc.Arbitrary<EvaluationResultContent> = fc.oneof(
  { weight: 3, arbitrary: usableResultArb },
  { weight: 2, arbitrary: unusableResultArb }
);

/**
 * An arbitrary evaluator outcome. The id is sometimes one of the three
 * requested ids (so it influences the aggregated scores) and sometimes a
 * free string (so it should be silently ignored). Result lists may be
 * empty, mixed, or all-unusable.
 */
const evaluatorOutcomeArb: fc.Arbitrary<EvaluatorOutcome> = fc.record({
  evaluatorId: fc.oneof(
    { weight: 4, arbitrary: fc.constantFrom(...REQUESTED_IDS) },
    {
      weight: 1,
      arbitrary: fc
        .string({ minLength: 1, maxLength: 12 })
        .filter(
          (s) => !REQUESTED_IDS.includes(s as (typeof REQUESTED_IDS)[number])
        ),
    }
  ),
  results: fc.array(anyResultArb, { minLength: 0, maxLength: 6 }),
});

/**
 * A list of evaluator outcomes covering the whole input space — including
 * empty, partial (only one or two of the three requested ids present),
 * fully-populated, and lists with extra non-requested ids.
 */
const evaluatorOutcomesArb: fc.Arbitrary<EvaluatorOutcome[]> = fc.array(
  evaluatorOutcomeArb,
  { minLength: 0, maxLength: 6 }
);

/**
 * An arbitrary `FailureContext`. Covers all four discriminator variants
 * with both the default-reason path (no `message`) and the explicit-reason
 * path. The two "error" variants require a `message` per the type, so we
 * always supply one for them.
 */
const failureContextArb: fc.Arbitrary<FailureContext> = fc.oneof(
  fc.record({
    kind: fc.constant('insufficient-trace' as const),
    message: fc.option(fc.string({ maxLength: 32 }), { nil: undefined }),
  }),
  fc.record({
    kind: fc.constant('timeout' as const),
    message: fc.option(fc.string({ maxLength: 32 }), { nil: undefined }),
  }),
  fc.record({
    kind: fc.constant('agentcore-error' as const),
    message: fc.string({ minLength: 1, maxLength: 32 }),
  }),
  fc.record({
    kind: fc.constant('unmappable-result' as const),
    message: fc.string({ minLength: 1, maxLength: 32 }),
  })
);

/** A `FailureContext` or `undefined` — the second arg is optional. */
const optionalFailureArb: fc.Arbitrary<FailureContext | undefined> = fc.option(
  failureContextArb,
  { nil: undefined }
);

/**
 * An arbitrary `AggregatedScores | null | undefined`. We construct most
 * inputs from real `aggregateScores` output (so the relationship between
 * `missingEvaluators` and the score fields is faithful), but also inject
 * the `null` / `undefined` cases occasionally to cover the defensive
 * branch in `assembleCaseEvaluation`.
 */
const aggregatedScoresArb: fc.Arbitrary<AggregatedScores | null | undefined> =
  fc.oneof(
    { weight: 8, arbitrary: evaluatorOutcomesArb.map(aggregateScores) },
    { weight: 1, arbitrary: fc.constant(null) },
    { weight: 1, arbitrary: fc.constant(undefined) }
  );

// ---------------------------------------------------------------------------
// Property 6
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 1.9, 8.4, 8.5**
 *
 * Property 6: An evaluation error state leaves all three scores unset
 *
 * For any combination of `AggregatedScores` (including `null` /
 * `undefined`, fully-populated, and partially-populated) and any
 * `FailureContext` (or none), the result of `assembleCaseEvaluation`
 * satisfies the structural invariant:
 *
 *   When `evaluationError` is set on the returned `CaseEvaluation`, then
 *   `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` are
 *   ALL `undefined`.
 *
 * The property covers every documented path that produces an error
 * state:
 *  - explicit `FailureContext` (all four `kind` variants);
 *  - `aggregated.missingEvaluators` non-empty;
 *  - `aggregated` is `null` or `undefined` (defensive branch).
 *
 * As a corollary the property also asserts the two output shapes are
 * mutually exclusive: when `evaluationError` is unset, all three scores
 * are present. This is a structural co-property and keeps the error and
 * scored shapes from ever overlapping.
 */
describe('Property 6: An evaluation error state leaves all three scores unset', () => {
  it('when evaluationError is set, all three score fields are undefined', () => {
    fc.assert(
      fc.property(
        aggregatedScoresArb,
        optionalFailureArb,
        (aggregated, failure) => {
          const result = assembleCaseEvaluation(aggregated, failure);

          if (result.evaluationError !== undefined) {
            // Core invariant (Property 6).
            expect(result.goalSuccessScore).toBeUndefined();
            expect(result.helpfulnessScore).toBeUndefined();
            expect(result.toolAccuracyScore).toBeUndefined();
          } else {
            // Co-property: the two output shapes are disjoint. When no
            // error state is recorded, all three scores must be defined.
            expect(result.goalSuccessScore).toBeDefined();
            expect(result.helpfulnessScore).toBeDefined();
            expect(result.toolAccuracyScore).toBeDefined();
          }
        }
      ),
      { numRuns: 100 }
    );
  });
});

// ---------------------------------------------------------------------------
// Property 7
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 8.5, 8.8**
 *
 * Property 7: Tool accuracy originates only from the Bedrock judge, never
 * from local scoring.
 *
 * The platform forbids substituting the local `calculateToolAccuracy` helper
 * for a `Builtin.ToolSelectionAccuracy` result returned by the Bedrock
 * judge. `assembleCaseEvaluation` is the single mapping point at which a
 * `toolAccuracyScore` value can land on a `TestCaseResult`, so locking down
 * its behaviour locks down the platform's persisted output.
 *
 * The property is enforced two complementary ways:
 *
 *  1. **Functional / structural property (run with `numRuns: 100`).**
 *     For every `AggregatedScores` × `FailureContext` input, the resulting
 *     `toolAccuracyScore` is either `undefined` (the error / missing-evaluator
 *     path) or strictly equal to `aggregated.toolAccuracyScore`. There is
 *     no other path through `assembleCaseEvaluation` that can produce a
 *     `toolAccuracyScore`, so any future code change that derived the score
 *     from anywhere else (a transcript, a local helper, a constant) would
 *     break this equality and fail the test.
 *
 *  2. **Static structural guard (runs once).** Reads the source of
 *     `src/shared/utils/evaluation-result.ts` and asserts the file contains
 *     no `import` from `tool-accuracy` and no code-level reference to the
 *     `calculateToolAccuracy` symbol. The module's own JSDoc explicitly
 *     documents the no-fallback rule and uses both names in commentary, so
 *     the check strips comments before scanning. This is a belt-and-braces
 *     guard that catches a future refactor that reintroduces the local
 *     helper even if (1) still happens to pass through clamping coincidence.
 */
describe('Property 7: Tool accuracy originates only from the Bedrock judge, never from local scoring', () => {
  it('toolAccuracyScore is either undefined or strictly equal to aggregated.toolAccuracyScore', () => {
    fc.assert(
      fc.property(
        aggregatedScoresArb,
        optionalFailureArb,
        (aggregated, failure) => {
          const result = assembleCaseEvaluation(aggregated, failure);

          if (result.toolAccuracyScore === undefined) {
            // Error / missing-evaluator path: nothing to compare against.
            return;
          }

          // The only path that produces a defined toolAccuracyScore is the
          // fully-scored branch, which sources the value verbatim from the
          // aggregator. `aggregated` must therefore be a real
          // `AggregatedScores` (not null/undefined) and its
          // `toolAccuracyScore` must be the exact same value.
          expect(aggregated).not.toBeNull();
          expect(aggregated).not.toBeUndefined();
          expect(result.toolAccuracyScore).toBe(
            (aggregated as NonNullable<typeof aggregated>).toolAccuracyScore
          );
        }
      ),
      { numRuns: 100 }
    );
  });

  it('source of evaluation-result.ts contains no import or reference to local tool-accuracy scoring', () => {
    // Resolve from the test file location to the module under test. We use
    // an explicit relative path so the test does not depend on Vitest path
    // aliases or on cwd.
    const modulePath = path.resolve(
      __dirname,
      '../../../src/shared/utils/evaluation-result.ts'
    );
    const source = readFileSync(modulePath, 'utf8');

    // The module legitimately documents the no-fallback rule in its JSDoc
    // (see the module-level comment and the `assembleCaseEvaluation` doc
    // block). Strip both block comments and line comments before scanning
    // so the documentation does not produce a false positive.
    const stripped = source
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/(^|[^:])\/\/[^\n]*/g, '$1');

    // No import of the local tool-accuracy module under any path style
    // (relative, alias, or sub-path). Use a generic regex that fires on any
    // module specifier ending in `tool-accuracy`.
    expect(stripped).not.toMatch(
      /from\s+['"][^'"]*tool-accuracy(?:['"]|\/)/
    );

    // No code-level reference to the `calculateToolAccuracy` symbol —
    // imported, called, aliased, or otherwise.
    expect(stripped).not.toMatch(/\bcalculateToolAccuracy\b/);
  });
});
