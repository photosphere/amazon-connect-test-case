import { describe, it, expect } from "vitest";
import { sortResults } from "../../src/shared/utils/results-sorting";
import { CaseStatus } from "../../src/shared/enums";

describe("sortResults", () => {
  it("returns empty array for empty input", () => {
    expect(sortResults([])).toEqual([]);
  });

  it("does not mutate the original array", () => {
    const original = [
      { status: CaseStatus.PASSED, name: "B" },
      { status: CaseStatus.ERROR, name: "A" },
    ];
    const copy = [...original];
    sortResults(original);
    expect(original).toEqual(copy);
  });

  it("sorts errors before failed, failed before passed", () => {
    const results = [
      { status: CaseStatus.PASSED, name: "Test1" },
      { status: CaseStatus.FAILED, name: "Test2" },
      { status: CaseStatus.ERROR, name: "Test3" },
    ];
    const sorted = sortResults(results);
    expect(sorted[0].status).toBe(CaseStatus.ERROR);
    expect(sorted[1].status).toBe(CaseStatus.FAILED);
    expect(sorted[2].status).toBe(CaseStatus.PASSED);
  });

  it("places timed_out between error and failed", () => {
    const results = [
      { status: CaseStatus.PASSED, name: "A" },
      { status: CaseStatus.TIMED_OUT, name: "B" },
      { status: CaseStatus.FAILED, name: "C" },
      { status: CaseStatus.ERROR, name: "D" },
    ];
    const sorted = sortResults(results);
    expect(sorted.map((r) => r.status)).toEqual([
      CaseStatus.ERROR,
      CaseStatus.TIMED_OUT,
      CaseStatus.FAILED,
      CaseStatus.PASSED,
    ]);
  });

  it("sorts alphabetically within the same status group (case-insensitive)", () => {
    const results = [
      { status: CaseStatus.FAILED, name: "charlie" },
      { status: CaseStatus.FAILED, name: "Alpha" },
      { status: CaseStatus.FAILED, name: "Bravo" },
    ];
    const sorted = sortResults(results);
    expect(sorted.map((r) => r.name)).toEqual(["Alpha", "Bravo", "charlie"]);
  });

  it("handles single element array", () => {
    const results = [{ status: CaseStatus.PASSED, name: "Solo" }];
    const sorted = sortResults(results);
    expect(sorted).toEqual([{ status: CaseStatus.PASSED, name: "Solo" }]);
  });

  it("handles all same status sorted alphabetically", () => {
    const results = [
      { status: CaseStatus.PASSED, name: "Zulu" },
      { status: CaseStatus.PASSED, name: "Alpha" },
      { status: CaseStatus.PASSED, name: "Mike" },
    ];
    const sorted = sortResults(results);
    expect(sorted.map((r) => r.name)).toEqual(["Alpha", "Mike", "Zulu"]);
  });

  it("preserves additional properties on result objects", () => {
    const results = [
      { status: CaseStatus.PASSED, name: "B", extra: 42 },
      { status: CaseStatus.ERROR, name: "A", extra: 7 },
    ];
    const sorted = sortResults(results);
    expect(sorted[0]).toEqual({ status: CaseStatus.ERROR, name: "A", extra: 7 });
    expect(sorted[1]).toEqual({ status: CaseStatus.PASSED, name: "B", extra: 42 });
  });
});
