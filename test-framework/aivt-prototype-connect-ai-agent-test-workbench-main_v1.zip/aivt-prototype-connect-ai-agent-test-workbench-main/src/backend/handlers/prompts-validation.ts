/**
 * Validation pipeline for `PUT /prompts/{promptKey}` and adjacent routes.
 *
 * Each stage is exported as a separate pure function returning a
 * {@link ValidationResult} so the Prompts Lambda handler can compose them
 * in the strict order required by the design's "Validation pipeline"
 * section, and so the property-based / unit tests can hammer each stage
 * in isolation. The first failure short-circuits the pipeline and is
 * mapped by the handler to an HTTP 400 (or 404 for `PROMPT_NOT_FOUND`)
 * carrying the structured `code` from the Error Handling table.
 *
 * Every function here is pure:
 *
 *   - No DynamoDB reads or writes.
 *   - No Bedrock requests are *sent*. The dry-render stage constructs a
 *     `ConverseCommand` to surface SDK-side validation errors (R4.10),
 *     but never calls `client.send`.
 *   - No environment variable reads. The handler injects everything the
 *     stage needs as a parameter.
 *
 * The functions intentionally use the ordering from the design — text
 * size before placeholder shape before model membership before capability
 * compliance before numeric bounds before dry-render — but each function
 * is self-contained: passing a `text` whose placeholders are missing to
 * `validateNoUnknownPlaceholders` is well-defined, it just may surface a
 * different error than a complete pipeline run would.
 *
 * Structured error codes returned here match the Error Handling table in
 * the design's `## Error Handling` section. The codes are stable wire
 * contract — frontend code switches on them — so reordering or renaming
 * a code is a breaking change.
 *
 * @module backend/handlers/prompts-validation
 */

import { ConverseCommand } from "@aws-sdk/client-bedrock-runtime";
import type { ConverseCommandInput } from "@aws-sdk/client-bedrock-runtime";
import { PROMPT_TEXT_DEFAULT_MAX_BYTES } from "../../shared/constants";
import {
  CAPABILITY_PROFILES,
  PROMPT_REGISTRY,
  SUPPORTED_MODELS,
  buildInferenceConfig,
} from "../orchestration/prompt-registry";
import type {
  ModelKey,
  PromptDefinition,
  PromptKey,
  ResolvedPrompt,
} from "../orchestration/prompt-registry";

// ---------------------------------------------------------------------------
// Result shape
// ---------------------------------------------------------------------------

/** Successful validation outcome. */
export interface ValidationOk {
  ok: true;
}

/** Failed validation outcome carrying a structured error code. */
export interface ValidationError {
  ok: false;
  code: string;
  details?: Record<string, unknown>;
}

/** Either a passing or a failing validation result. */
export type ValidationResult = ValidationOk | ValidationError;

const OK: ValidationOk = { ok: true };

/** Build a typed validation failure with optional structured details. */
function fail(
  code: string,
  details?: Record<string, unknown>,
): ValidationError {
  return details === undefined
    ? { ok: false, code }
    : { ok: false, code, details };
}

// ---------------------------------------------------------------------------
// Stage 1 — promptKey existence
// ---------------------------------------------------------------------------

/**
 * Verify that `promptKey` is a registered key in the {@link
 * PROMPT_REGISTRY}. Returns a `PROMPT_NOT_FOUND` failure when the key is
 * unknown — mapped by the handler to HTTP 404 per the design's Error
 * Handling table. Treats the key as a free-form string so the handler can
 * dispatch this stage on the unvalidated path parameter.
 *
 * @param promptKey  — path parameter from the request, treated as opaque.
 */
export function validatePromptKeyExists(
  promptKey: string,
): ValidationResult {
  if (
    !Object.prototype.hasOwnProperty.call(PROMPT_REGISTRY, promptKey as PromptKey)
  ) {
    return fail("PROMPT_NOT_FOUND", { promptKey });
  }
  return OK;
}

// ---------------------------------------------------------------------------
// Stage 2 — text size
// ---------------------------------------------------------------------------

/**
 * Verify that `text` (when present in the request body) does not exceed
 * the prompt's UTF-8 byte cap (`prompt.maxTextBytes ?? PROMPT_TEXT_DEFAULT_MAX_BYTES`,
 * R12.1). The byte length is computed via `Buffer.byteLength(text, "utf8")`
 * so the cap is enforced on actual UTF-8 bytes — not on character count,
 * which would silently let multi-byte sequences exceed the limit.
 *
 * Skips the check when `text` is `undefined`; an absent text field means
 * the override is sparse and falls back to the bundled default at resolve
 * time, so there is nothing to size-check.
 *
 * @param text   — proposed prompt text from the request body, or
 *                 `undefined` when the caller did not change it.
 * @param prompt — registry definition for the prompt being edited.
 */
export function validateTextSize(
  text: string | undefined,
  prompt: PromptDefinition,
): ValidationResult {
  if (text === undefined) {
    return OK;
  }
  const limitBytes = prompt.maxTextBytes ?? PROMPT_TEXT_DEFAULT_MAX_BYTES;
  const observedBytes = Buffer.byteLength(text, "utf8");
  if (observedBytes > limitBytes) {
    return fail("PROMPT_TEXT_TOO_LARGE", {
      observedBytes,
      limitBytes,
    });
  }
  return OK;
}

// ---------------------------------------------------------------------------
// Stage 3 — placeholder presence
// ---------------------------------------------------------------------------

/**
 * Verify that every `Placeholder` declared in the registry appears at
 * least once in `text` as the literal token `{name}`. R4.5 / R12.2.
 *
 * Detection uses literal substring search rather than a regex so that a
 * placeholder name containing regex meta-characters (none today, but the
 * field is free-form) cannot short-circuit detection.
 *
 * Returns OK when `text` is `undefined` (sparse override) or when the
 * prompt declares no placeholders. The error's `details.missing[]` lists
 * every placeholder name that did not appear so the frontend can render
 * an inline error citing the missing names directly.
 *
 * @param text   — proposed prompt text from the request body, or
 *                 `undefined` when the caller did not change it.
 * @param prompt — registry definition for the prompt being edited.
 */
export function validatePlaceholdersPresent(
  text: string | undefined,
  prompt: PromptDefinition,
): ValidationResult {
  if (text === undefined) {
    return OK;
  }
  const missing: string[] = [];
  for (const placeholder of prompt.placeholders) {
    if (!text.includes(`{${placeholder.name}}`)) {
      missing.push(placeholder.name);
    }
  }
  if (missing.length > 0) {
    return fail("PLACEHOLDERS_MISSING", { missing });
  }
  return OK;
}

// ---------------------------------------------------------------------------
// Stage 4 — placeholder occurrence cap
// ---------------------------------------------------------------------------

/**
 * Count occurrences of `needle` in `haystack` without using a regex —
 * keeps the count exact when `needle` would have escaping concerns. Used
 * by both the occurrence-cap stage below and the unknown-placeholder
 * scanner so the two stages count consistently.
 */
function countOccurrences(haystack: string, needle: string): number {
  if (needle.length === 0) return 0;
  let count = 0;
  let cursor = 0;
  for (;;) {
    const index = haystack.indexOf(needle, cursor);
    if (index === -1) return count;
    count += 1;
    cursor = index + needle.length;
  }
}

/**
 * Verify that no declared placeholder appears more times than its
 * `maxOccurrences` cap. R12.3.
 *
 * Placeholders that omit `maxOccurrences` are unbounded (the field is
 * documented in `Placeholder` to default to "unlimited") and skipped.
 * The first placeholder that exceeds its cap short-circuits and is
 * reported on `details.placeholder` along with the observed count and
 * the declared maximum.
 *
 * @param text   — proposed prompt text from the request body, or
 *                 `undefined` when the caller did not change it.
 * @param prompt — registry definition for the prompt being edited.
 */
export function validatePlaceholderOccurrenceCap(
  text: string | undefined,
  prompt: PromptDefinition,
): ValidationResult {
  if (text === undefined) {
    return OK;
  }
  for (const placeholder of prompt.placeholders) {
    if (placeholder.maxOccurrences === undefined) {
      continue;
    }
    const observed = countOccurrences(text, `{${placeholder.name}}`);
    if (observed > placeholder.maxOccurrences) {
      return fail("PLACEHOLDER_COUNT_EXCEEDED", {
        placeholder: placeholder.name,
        observed,
        max: placeholder.maxOccurrences,
      });
    }
  }
  return OK;
}

// ---------------------------------------------------------------------------
// Stage 5 — unknown placeholder detection
// ---------------------------------------------------------------------------

/**
 * Compute the half-open `[start, end)` byte ranges of every literal-brace
 * region declared on the prompt. The validator skips `{name}` tokens
 * whose offset falls inside any of these ranges so that JSON-schema
 * fragments embedded in judge templates (e.g. `{"properties": {…}}`) are
 * not mistaken for stray placeholders. R12.4.
 *
 * A region whose `start` or `end` substring cannot be found in the text
 * is silently skipped — the caller should not be punished for an
 * out-of-date region declaration when the registry default text changes;
 * the registry's own invariant tests catch that case.
 */
function computeLiteralRegions(
  text: string,
  prompt: PromptDefinition,
): ReadonlyArray<{ start: number; end: number }> {
  if (!prompt.literalBraceRegions || prompt.literalBraceRegions.length === 0) {
    return [];
  }
  const regions: { start: number; end: number }[] = [];
  for (const region of prompt.literalBraceRegions) {
    const start = text.indexOf(region.start);
    if (start < 0) continue;
    const endMatch = text.indexOf(region.end, start + region.start.length);
    if (endMatch < 0) continue;
    regions.push({ start, end: endMatch + region.end.length });
  }
  return regions;
}

/**
 * Match every `{identifier}` token in `text` and yield it together with
 * its byte offset. The identifier grammar matches a JavaScript-flavoured
 * identifier (`[A-Za-z_][A-Za-z0-9_]*`) so legitimate placeholder names
 * are accepted while raw JSON object literals (`{"foo":1}`) and
 * structural braces (`{`, `}`) are not picked up.
 */
const PLACEHOLDER_TOKEN_RE = /\{([A-Za-z_][A-Za-z0-9_]*)\}/g;

/**
 * Verify that every `{name}` token in `text` either names a declared
 * placeholder OR lies entirely within one of the prompt's
 * `literalBraceRegions[]`. Tokens that satisfy neither condition fail
 * with `UNKNOWN_PLACEHOLDER` and the offending token is reported on
 * `details.token` along with its character offset. R4.6 / R12.4.
 *
 * The check uses a regex that matches identifier-shaped tokens only, so
 * structural braces (`{`, `}`) and JSON object literals (`{"foo": 1}`)
 * are ignored — only well-formed placeholder shapes can be flagged.
 *
 * @param text   — proposed prompt text from the request body, or
 *                 `undefined` when the caller did not change it.
 * @param prompt — registry definition for the prompt being edited.
 */
export function validateNoUnknownPlaceholders(
  text: string | undefined,
  prompt: PromptDefinition,
): ValidationResult {
  if (text === undefined) {
    return OK;
  }
  const declaredNames = new Set(prompt.placeholders.map((p) => p.name));
  const literalRegions = computeLiteralRegions(text, prompt);

  PLACEHOLDER_TOKEN_RE.lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = PLACEHOLDER_TOKEN_RE.exec(text)) !== null) {
    const name = match[1];
    const offset = match.index;
    if (declaredNames.has(name)) {
      continue;
    }
    const tokenEnd = offset + match[0].length;
    const insideLiteral = literalRegions.some(
      (region) => offset >= region.start && tokenEnd <= region.end,
    );
    if (insideLiteral) {
      continue;
    }
    return fail("UNKNOWN_PLACEHOLDER", {
      token: match[0],
      offset,
    });
  }
  return OK;
}

// ---------------------------------------------------------------------------
// Stage 6 — model membership
// ---------------------------------------------------------------------------

/**
 * Verify that `modelKey` (when supplied in the request body) appears in
 * the prompt's `allowedModels[]` allow-list. R4.7 / R5.1.
 *
 * Returns OK when `modelKey` is `undefined` — a sparse override that
 * does not change the model is accepted by this stage. The error's
 * `details.requested` carries the supplied modelKey and `details.allowed[]`
 * carries the allow-list so the frontend can render an inline error
 * citing both directly.
 *
 * @param modelKey — proposed model key from the request body, or
 *                   `undefined` when the caller did not change it.
 * @param prompt   — registry definition for the prompt being edited.
 */
export function validateModelMembership(
  modelKey: ModelKey | undefined,
  prompt: PromptDefinition,
): ValidationResult {
  if (modelKey === undefined) {
    return OK;
  }
  if (!prompt.allowedModels.includes(modelKey)) {
    return fail("MODEL_NOT_ALLOWED", {
      requested: modelKey,
      allowed: [...prompt.allowedModels],
    });
  }
  return OK;
}

// ---------------------------------------------------------------------------
// Stage 7 — capability-profile compliance
// ---------------------------------------------------------------------------

/**
 * Verify that every key in `inferenceParameters` (a) is declared in the
 * resolved model's capability profile (`acceptsTopLevel ∪ acceptsAdditional`)
 * and (b) is not on the profile's `forbids[]` list. R4.8 / R10.4 / R17.4.
 *
 * The first offending key short-circuits and is reported on `details.key`
 * along with the profile name. The structured code is `MODEL_FORBIDS_KEY`,
 * a generic emitted whenever a parameter conflicts with the resolved
 * model's capability profile (today: `anthropic_claude_4x` forbidding
 * `temperature`, `topP`, `topK`, and `stopSequences`). New forbidden
 * keys surface the same code with the new key name on `details.key`.
 *
 * Returns OK when `inferenceParameters` is `undefined` — a sparse override
 * that does not change inference parameters is accepted here.
 *
 * @param inferenceParameters — proposed parameter map from the request
 *                              body, or `undefined` when the caller did
 *                              not change it.
 * @param modelKey            — the resolved model the parameters will be
 *                              sent against (override or default).
 */
export function validateCapabilityProfileCompliance(
  inferenceParameters: Readonly<Record<string, unknown>> | undefined,
  modelKey: ModelKey,
): ValidationResult {
  if (inferenceParameters === undefined) {
    return OK;
  }
  const supportedModel = SUPPORTED_MODELS[modelKey];
  if (supportedModel === undefined) {
    // Defensive — should never happen because Stage 6 caught it. If it
    // does, surface as MODEL_NOT_ALLOWED rather than synthesise a profile.
    return fail("MODEL_NOT_ALLOWED", {
      requested: modelKey,
      allowed: Object.keys(SUPPORTED_MODELS),
    });
  }
  const profile = CAPABILITY_PROFILES[supportedModel.capabilityProfileKey];
  const accepts = new Set<string>([
    ...profile.acceptsTopLevel,
    ...profile.acceptsAdditional,
  ]);
  const forbids = new Set<string>(profile.forbids);

  for (const key of Object.keys(inferenceParameters)) {
    if (forbids.has(key) || !accepts.has(key)) {
      return fail("MODEL_FORBIDS_KEY", {
        key,
        profile: profile.key,
      });
    }
  }
  return OK;
}

// ---------------------------------------------------------------------------
// Stage 8 — numeric bounds
// ---------------------------------------------------------------------------

/**
 * Verify that every numeric value in `inferenceParameters` lies within
 * the closed interval that is the intersection of (a) the prompt's
 * declared schema range and (b) the resolved model's capability-profile
 * range, plus the `maxOutputTokens` ceiling specifically for the
 * `maxTokens` key. R4.9 / R12.5 / R5.1.
 *
 * Non-numeric keys (e.g. `stopSequences: string[]`) are skipped here —
 * they are validated by the schema's `kind: "stringArray"` length cap
 * elsewhere in the pipeline; the numeric-bounds stage only enforces the
 * `kind: "number" | "integer"` constraint.
 *
 * The stage returns the FIRST offending key (rather than aggregating)
 * so the frontend's inline error is unambiguous; subsequent edits can
 * surface the next failure on the next save.
 *
 * Returns OK when `inferenceParameters` is `undefined`.
 *
 * @param inferenceParameters — proposed parameter map from the request
 *                              body, or `undefined`.
 * @param prompt              — registry definition for the prompt being
 *                              edited.
 * @param modelKey            — the resolved model the parameters will be
 *                              sent against.
 */
export function validateNumericBounds(
  inferenceParameters: Readonly<Record<string, unknown>> | undefined,
  prompt: PromptDefinition,
  modelKey: ModelKey,
): ValidationResult {
  if (inferenceParameters === undefined) {
    return OK;
  }
  const supportedModel = SUPPORTED_MODELS[modelKey];
  if (supportedModel === undefined) {
    return fail("MODEL_NOT_ALLOWED", {
      requested: modelKey,
      allowed: Object.keys(SUPPORTED_MODELS),
    });
  }
  const profile = CAPABILITY_PROFILES[supportedModel.capabilityProfileKey];

  for (const [key, rawValue] of Object.entries(inferenceParameters)) {
    const schema = prompt.inferenceParameters[key];
    // Non-numeric schemas are skipped here — they have their own checks
    // (length caps for stringArray, etc.). The capability-compliance
    // stage already rejected keys that are not declared anywhere.
    if (
      schema !== undefined &&
      schema.kind !== "number" &&
      schema.kind !== "integer"
    ) {
      continue;
    }
    if (typeof rawValue !== "number" || !Number.isFinite(rawValue)) {
      // A non-numeric value where a numeric one is expected is out of
      // bounds; emit a single, well-defined failure rather than letting
      // the dry-render stage produce an opaque error.
      return fail("INFERENCE_PARAMETER_OUT_OF_BOUNDS", {
        key,
        value: rawValue,
        range: schema !== undefined && (schema.kind === "number" || schema.kind === "integer")
          ? { min: schema.min, max: schema.max }
          : profile.numericRanges[key],
      });
    }

    // Compute the effective interval as the intersection of (a) the
    // prompt schema, (b) the profile range, and (c) the per-model ceiling
    // for `maxTokens`. Use Number.MAX_SAFE_INTEGER as the open default.
    let min = Number.NEGATIVE_INFINITY;
    let max = Number.POSITIVE_INFINITY;
    if (schema !== undefined && (schema.kind === "number" || schema.kind === "integer")) {
      min = Math.max(min, schema.min);
      max = Math.min(max, schema.max);
    }
    const profileRange = profile.numericRanges[key];
    if (profileRange !== undefined) {
      min = Math.max(min, profileRange.min);
      max = Math.min(max, profileRange.max);
    }
    if (key === "maxTokens") {
      max = Math.min(max, supportedModel.maxOutputTokens);
    }
    if (rawValue < min || rawValue > max) {
      return fail("INFERENCE_PARAMETER_OUT_OF_BOUNDS", {
        key,
        value: rawValue,
        range: { min, max },
      });
    }
    if (
      schema !== undefined &&
      schema.kind === "integer" &&
      !Number.isInteger(rawValue)
    ) {
      return fail("INFERENCE_PARAMETER_OUT_OF_BOUNDS", {
        key,
        value: rawValue,
        range: { min, max },
      });
    }
  }
  return OK;
}

// ---------------------------------------------------------------------------
// Stage 9 — dry-render
// ---------------------------------------------------------------------------

/**
 * Final pipeline stage. Builds a Bedrock `ConverseCommand` against the
 * resolved model and inference parameters and asserts the SDK
 * constructor accepts the request shape. The command is **never sent** —
 * the dry-render is purely a constructor-level check that catches
 * SDK-side validation errors (mis-shaped `inferenceConfig`, malformed
 * `additionalModelRequestFields`, etc.) before the override is persisted.
 * R4.10.
 *
 * Surfacing strategy:
 *
 *   - If `buildInferenceConfig` throws, return `DRY_RENDER_FAILED` with
 *     `details.step = "buildInferenceConfig"` and the throw message.
 *   - If the `ConverseCommand` constructor throws, return
 *     `DRY_RENDER_FAILED` with `details.step = "ConverseCommand"` and the
 *     throw message.
 *
 * The handler maps either to HTTP 400 per the design's Error Handling
 * table.
 *
 * The `text` argument is expected to be the already-rendered prompt
 * (placeholders substituted with synthetic values, e.g. `{name}` →
 * `[name]`); the caller is responsible for the substitution because the
 * placeholder schema lives on the {@link PromptDefinition} the caller
 * already has in hand. The user message is a fixed synthetic string so
 * the constructor sees a well-formed Converse request shape.
 *
 * @param text                  — the resolved, already-rendered prompt
 *                                text the dry-render places on the
 *                                Converse `system` block.
 * @param modelKey              — the resolved model the dry-render
 *                                targets.
 * @param inferenceParameters   — the resolved inference parameters the
 *                                dry-render emits on the constructed
 *                                Converse request.
 */
export function validateDryRender(
  text: string,
  modelKey: ModelKey,
  inferenceParameters: Readonly<Record<string, unknown>>,
): ValidationResult {
  const supportedModel = SUPPORTED_MODELS[modelKey];
  if (supportedModel === undefined) {
    return fail("MODEL_NOT_ALLOWED", {
      requested: modelKey,
      allowed: Object.keys(SUPPORTED_MODELS),
    });
  }
  const profile = CAPABILITY_PROFILES[supportedModel.capabilityProfileKey];

  // Synthesise a `ResolvedPrompt` from the validator inputs so we can
  // call `buildInferenceConfig` directly. The `promptKey` field is set
  // to a registered key purely to satisfy the type — `buildInferenceConfig`
  // only consults `inferenceParameters` and `capabilityProfile`.
  const synthesisedResolved: ResolvedPrompt = {
    promptKey: "failure_analysis",
    text,
    modelKey,
    modelId: supportedModel.inferenceProfileId,
    inferenceParameters,
    version: 0,
    capabilityProfile: profile,
  };

  let inferenceConfig: Record<string, unknown>;
  let additionalModelRequestFields:
    | { inferenceConfig: Record<string, unknown> }
    | undefined;
  try {
    const built = buildInferenceConfig(synthesisedResolved);
    inferenceConfig = built.inferenceConfig;
    additionalModelRequestFields = built.additionalModelRequestFields;
  } catch (error) {
    return fail("DRY_RENDER_FAILED", {
      step: "buildInferenceConfig",
      message: error instanceof Error ? error.message : String(error),
    });
  }

  try {
    // Construct the command but do NOT send it. Construction alone runs
    // the SDK's request validation (Smithy's input shape coercion) which
    // is what we are looking for at this stage.
    //
    // The casts on `inferenceConfig` and `additionalModelRequestFields`
    // bridge the SDK's strict types (`InferenceConfiguration` for the
    // top-level config, `DocumentType` for the additional fields) and
    // our runtime payload — `buildInferenceConfig` already enforces the
    // exact key set against the resolved capability profile, so the
    // values are guaranteed JSON-encodable at runtime.
    new ConverseCommand({
      modelId: supportedModel.inferenceProfileId,
      system: [{ text }],
      messages: [{ role: "user", content: [{ text: "validate" }] }],
      inferenceConfig:
        inferenceConfig as ConverseCommandInput["inferenceConfig"],
      ...(additionalModelRequestFields
        ? {
            additionalModelRequestFields:
              additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
          }
        : {}),
    });
  } catch (error) {
    return fail("DRY_RENDER_FAILED", {
      step: "ConverseCommand",
      message: error instanceof Error ? error.message : String(error),
    });
  }

  return OK;
}
