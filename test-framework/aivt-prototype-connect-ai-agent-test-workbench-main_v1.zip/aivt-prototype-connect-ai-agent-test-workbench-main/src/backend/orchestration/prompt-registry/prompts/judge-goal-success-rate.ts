/**
 * `judge_goal_success_rate` — verbatim AgentCore-template prompt for the
 * `Builtin.GoalSuccessRate` judge. The default text re-exports the
 * `GOAL_SUCCESS_RATE_TEMPLATE` constant from
 * `src/backend/orchestration/judge-prompt-templates.ts` so the byte-for-
 * byte copy from the AWS docs (and the steering doc that records the
 * source URL plus copy date) stays exactly where it is — the judge
 * templates module remains the registry's source for the four judge
 * `defaultText` values rather than being duplicated.
 *
 * Placeholders are the AgentCore-defined tokens substituted by
 * `bedrock-judge-client.ts`'s `fillTemplate`:
 *
 *   - `{available_tools}` — formatted catalog of the agent's tools
 *   - `{context}` — full conversation record (User/Assistant/Action/Tool
 *     turns)
 *
 * All other `{...}` braces inside the embedded JSON-schema block are part
 * of the schema and pass through to the judge as literal text. The
 * registry's validation pipeline declares them as
 * {@link PromptDefinition.literalBraceRegions} so the unknown-placeholder
 * detector does not flag them as edits.
 *
 * @module backend/orchestration/prompt-registry/prompts/judge-goal-success-rate
 */

import { GOAL_SUCCESS_RATE_TEMPLATE } from "../../judge-prompt-templates";
import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

export const judgeGoalSuccessRatePrompt: PromptDefinition = {
  promptKey: "judge_goal_success_rate",
  name: "Judge — Goal Success Rate",
  description:
    "Verbatim AWS-published Builtin.GoalSuccessRate judge prompt. Scores whether all user goals were achieved across a multi-turn conversation.",
  category: "evaluation",
  defaultText: GOAL_SUCCESS_RATE_TEMPLATE,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [
    {
      name: "available_tools",
      description:
        "Formatted catalog of the agent's tools (name, description, instruction) injected by the judge client.",
      maxOccurrences: 1,
    },
    {
      name: "context",
      description:
        "Full conversation record — User, Assistant, Action (tool selected), Tool (output) turns.",
      maxOccurrences: 1,
    },
  ],
  // The embedded JSON-schema block uses `{...}` braces that are NOT
  // placeholders. Declared here so the validation pipeline's unknown-
  // placeholder detector does not flag them as edits to the prompt.
  literalBraceRegions: [
    {
      start:
        '{"properties": {"reasoning": ',
      end: '"required": ["reasoning", "score"]}',
    },
  ],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 2_048 },
  },
  defaultInferenceValues: {
    maxTokens: 2_048,
  },
};
