/**
 * CDK assertion tests for the registry-derived Bedrock IAM grants and the
 * Prompts API authorization wiring (Task 10.6 of the prompt-management
 * spec).
 *
 * **Wave 3 (Task 20.5) — single-grant posture.**
 * Tightened from the original Wave 0 posture, which permitted EITHER one
 * (registry-derived) OR two (registry-derived + a parallel inline
 * `bedrock:InvokeModel` / `bedrock:Converse` block) statements per
 * Bedrock-calling Lambda. The "two" branch was deliberate during the
 * dual-grant safety overlap so a regression in `computeBedrockGrants`
 * could not silently 403 a Lambda while Waves 0–2 burned in. Tasks 20.1
 * and 20.2 retired the legacy inline blocks across `lib/api-construct.ts`
 * and `lib/orchestration-construct.ts`, so the registry-derived statement
 * is now the *only* `bedrock:InvokeModel` / `bedrock:Converse` grant on
 * each role. This test enforces that posture: exactly one statement per
 * Lambda whose Action set includes `bedrock:InvokeModel` and/or
 * `bedrock:Converse`, no more and no less. Reintroducing a parallel
 * inline grant fails the build before deploy, which is the whole point
 * of the dual-grant retirement.
 *
 * Note: the assertion filters specifically for `InvokeModel` / `Converse`
 * — *not* every `bedrock:*` statement. The RAG Evaluate Lambda still
 * carries a separate `BedrockRagEvaluation` statement covering
 * `bedrock:CreateEvaluationJob` / `GetEvaluationJob` / `StopEvaluationJob`
 * (evaluation-job lifecycle APIs that are outside the helper's scope and
 * are not subject to this single-grant invariant).
 *
 * Validates:
 *   - **Requirement 19.2 / 19.3**: every Bedrock-calling Lambda's role
 *     policy carries EXACTLY ONE statement whose Action set includes
 *     `bedrock:InvokeModel` and/or `bedrock:Converse`, whose Action list
 *     is the literal pair `[bedrock:InvokeModel, bedrock:Converse]`, and
 *     whose `Resource` list is set-equal — neither wider nor narrower —
 *     to the union of inference-profile + routing-region foundation-model
 *     wildcard ARNs reachable from that Lambda's `promptKey` set,
 *     computed by re-running `computeBedrockGrants` from the test against
 *     the same registry the constructs consume. A drift in either
 *     direction (a hand-edited ARN, a forgotten `routingRegions[]`
 *     Region, an extra resource the registry doesn't justify, OR a
 *     reintroduced inline grant alongside the registry-derived one)
 *     trips the assertion.
 *   - **Requirement 19.6**: the three `*BedrockGrantSummary` CFN outputs
 *     (one per construct that owns Bedrock-calling Lambdas) exist on the
 *     synthesised template, parse as JSON maps, and carry one entry per
 *     Bedrock-calling Lambda the construct provisions, with the Lambda
 *     logical-id key (the second argument to `new NodejsFunction(...)`)
 *     matching the synthesised role policy.
 *   - **Requirement 8.1**: every API Gateway method whose path begins
 *     with `/prompts` carries `authorizationScopes: ['test-platform/run']`
 *     (regression guard for the implement-recommendations bug fixed
 *     earlier — dropping the scope flips the authorizer back to ID-token
 *     mode and 401s the frontend).
 */
import * as path from "path";
import { describe, it, expect, vi } from "vitest";
import * as cdk from "aws-cdk-lib";
import { Template } from "aws-cdk-lib/assertions";

// Mirror the existing CDK assertion tests: stub `NodejsFunction` so esbuild
// bundling does not run during synth. The test exercises CFN-template shape
// (role policies, method options, CFN outputs), not the Lambda code itself.
vi.mock("aws-cdk-lib/aws-lambda-nodejs", () => {
  const lambda = require("aws-cdk-lib/aws-lambda");

  class NodejsFunction extends lambda.Function {
    constructor(scope: any, id: string, props: any) {
      super(scope, id, {
        ...props,
        code: lambda.Code.fromInline("exports.handler = async () => {}"),
        handler: "index.handler",
        runtime: props?.runtime ?? lambda.Runtime.NODEJS_20_X,
      });
    }
  }

  return { NodejsFunction };
});

import { ConnectAgentTestPlatformStack } from "../../lib/connect-agent-test-platform-stack";
import { computeBedrockGrants } from "../../lib/bedrock-grants";
import { PROMPT_REGISTRY } from "../../src/backend/orchestration/prompt-registry";
import type {
  ModelKey,
  PromptKey,
} from "../../src/backend/orchestration/prompt-registry";

// ---------------------------------------------------------------------------
// Fixtures and synth helpers
// ---------------------------------------------------------------------------

const MOCK_CONNECT_INSTANCE_ID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890";
const FIXTURE_BUILD_DIR = path.resolve(
  __dirname,
  "../infrastructure/fixtures/frontend-dist",
);
const TEST_ACCOUNT = "123456789012";
const TEST_REGION = "us-east-1";

/**
 * Synthesize the platform stack and return both the underlying
 * `cdk.Stack` (so the test can re-run `computeBedrockGrants` against it
 * for the expected-resources comparison) and the CFN `Template` (so the
 * test can walk role policies, methods, and outputs).
 *
 * Mirrors `tests/infrastructure/cdk-stack.test.ts` for inputs and
 * fixtures so this file inherits the same synth posture as the other
 * CDK assertion tests in the repo.
 */
function synth(): { stack: cdk.Stack; template: Template } {
  const app = new cdk.App();
  const stack = new ConnectAgentTestPlatformStack(app, "TestStack", {
    connectInstanceId: MOCK_CONNECT_INSTANCE_ID,
    callbackUrls: ["http://localhost:5173"],
    frontendBuildDir: FIXTURE_BUILD_DIR,
    env: { account: TEST_ACCOUNT, region: TEST_REGION },
  });
  return { stack, template: Template.fromStack(stack) };
}

// ---------------------------------------------------------------------------
// Lambda → promptKey mapping
// ---------------------------------------------------------------------------

/**
 * The exact mapping the constructs encode in `lib/api-construct.ts`,
 * `lib/orchestration-construct.ts`, and
 * `lib/implement-recommendations-construct.ts`. The test re-encodes it
 * here verbatim — when a future task migrates a Lambda to a different
 * `promptKey` set this table moves with it, and any drift between the
 * test's expectation and the construct's input fails the
 * set-equality assertion.
 *
 * The Lambda's "construct id" is the second argument to
 * `new NodejsFunction(this, ...)`. The synth-time Lambda logical id
 * lives at `${ConstructPathPrefix}${ConstructId}${HashSuffix}` (e.g.
 * `ApiScaffoldLambda9E6F9C55`). The test resolves a Lambda's role from
 * its construct id by matching the role-policy logical id, which CDK
 * derives as `${ConstructPathPrefix}${ConstructId}ServiceRoleDefaultPolicy${HashSuffix}`.
 */
/**
 * The three per-construct CFN outputs each construct emits. Each output's
 * synthesised logical id is `${ConstructPathPrefix}${OutputId}${HashSuffix}`,
 * so we identify them by the construct-path-anchored prefix that uniquely
 * matches one and only one output.
 *
 * - `api-construct.ts`           → output id `BedrockGrantSummary`
 *   → logical id starts with    `ApiBedrockGrantSummary`
 * - `orchestration-construct.ts` → output id `OrchestrationBedrockGrantSummary`
 *   → logical id starts with    `OrchestrationOrchestrationBedrockGrantSummary`
 *   (the construct's path prefix `Orchestration` doubles up because the
 *    output id itself begins with `Orchestration`)
 * - `implement-recommendations-construct.ts` → output id `ExperimentBedrockGrantSummary`
 *   → logical id starts with    `ImplementRecommendationsExperimentBedrockGrantSummary`
 *
 * Plain substring match of `BedrockGrantSummary` matches all three (it's a
 * substring of every output id), so we anchor against the construct-path
 * prefix to disambiguate.
 */
const SUMMARY_OUTPUT_LOGICAL_ID_PREFIX = {
  api: "ApiBedrockGrantSummary",
  orchestration: "OrchestrationOrchestrationBedrockGrantSummary",
  experiment: "ImplementRecommendationsExperimentBedrockGrantSummary",
} as const;

type SummaryOutputKind = keyof typeof SUMMARY_OUTPUT_LOGICAL_ID_PREFIX;

interface BedrockLambdaSpec {
  /** Construct id passed to `new NodejsFunction(this, ...)`. */
  readonly constructId: string;
  /** Substring uniquely identifying the role-policy logical id. */
  readonly rolePolicyLogicalIdSubstring: string;
  /** Closed list of `promptKey` values the Lambda invokes. */
  readonly promptKeys: readonly PromptKey[];
  /** Which CFN output's grant summary should carry this Lambda. */
  readonly summaryOutputKind: SummaryOutputKind;
}

/**
 * The complete list of every Bedrock-calling Lambda the platform
 * provisions today. Adding a new Bedrock-calling Lambda is a change to
 * this list followed by its construct wiring — the test forces both
 * halves to land in the same diff.
 *
 * `PromptsLambda` covers every prompt key (the dry-render validator
 * needs to construct a Converse for any model the user can pick), so
 * its `promptKeys` is the closed `PromptKey` union from
 * {@link PROMPT_REGISTRY}.
 */
const ALL_PROMPT_KEYS = Object.keys(PROMPT_REGISTRY) as PromptKey[];

const BEDROCK_LAMBDAS: readonly BedrockLambdaSpec[] = [
  // api-construct.ts
  {
    constructId: "ScaffoldLambda",
    rolePolicyLogicalIdSubstring: "ApiScaffoldLambdaServiceRoleDefaultPolicy",
    promptKeys: ["suite_scaffold", "case_scaffold"],
    summaryOutputKind: "api",
  },
  {
    constructId: "AnalysisLambda",
    rolePolicyLogicalIdSubstring: "ApiAnalysisLambdaServiceRoleDefaultPolicy",
    promptKeys: ["failure_analysis"],
    summaryOutputKind: "api",
  },
  {
    constructId: "ComparisonSummaryLambda",
    rolePolicyLogicalIdSubstring:
      "ApiComparisonSummaryLambdaServiceRoleDefaultPolicy",
    promptKeys: ["comparison_summary"],
    summaryOutputKind: "api",
  },
  {
    constructId: "SuiteRecommendLambda",
    rolePolicyLogicalIdSubstring:
      "ApiSuiteRecommendLambdaServiceRoleDefaultPolicy",
    promptKeys: ["suite_recommendation"],
    summaryOutputKind: "api",
  },
  {
    constructId: "PromptsLambda",
    rolePolicyLogicalIdSubstring: "ApiPromptsLambdaServiceRoleDefaultPolicy",
    promptKeys: ALL_PROMPT_KEYS,
    summaryOutputKind: "api",
  },
  // orchestration-construct.ts
  {
    constructId: "ConversationDriverFn",
    rolePolicyLogicalIdSubstring:
      "OrchestrationConversationDriverFnServiceRoleDefaultPolicy",
    promptKeys: ["customer_simulator", "judge_opportunistic_faithfulness"],
    summaryOutputKind: "orchestration",
  },
  {
    constructId: "EvaluationFn",
    rolePolicyLogicalIdSubstring:
      "OrchestrationEvaluationFnServiceRoleDefaultPolicy",
    promptKeys: [
      "judge_goal_success_rate",
      "judge_helpfulness",
      "judge_tool_selection",
      "judge_opportunistic_faithfulness",
    ],
    summaryOutputKind: "orchestration",
  },
  {
    constructId: "SubmitRagJobFn",
    rolePolicyLogicalIdSubstring:
      "OrchestrationSubmitRagJobFnServiceRoleDefaultPolicy",
    promptKeys: ["rag_evaluation_job"],
    summaryOutputKind: "orchestration",
  },
  // implement-recommendations-construct.ts
  {
    constructId: "ExperimentCreateFn",
    rolePolicyLogicalIdSubstring:
      "ImplementRecommendationsExperimentCreateFnServiceRoleDefaultPolicy",
    promptKeys: ["variant_generation"],
    summaryOutputKind: "experiment",
  },
  {
    constructId: "ExperimentGetFn",
    rolePolicyLogicalIdSubstring:
      "ImplementRecommendationsExperimentGetFnServiceRoleDefaultPolicy",
    promptKeys: ["tournament_summary"],
    summaryOutputKind: "experiment",
  },
];

// ---------------------------------------------------------------------------
// Helpers — walk role policies + outputs
// ---------------------------------------------------------------------------

/**
 * Find the unique `AWS::IAM::Policy` resource whose logical id contains
 * `substring`. Throws when zero or multiple match — both indicate the
 * test's mapping table has drifted from the synthesised template.
 */
function findRolePolicyDocument(
  template: Template,
  substring: string,
): { logicalId: string; statements: readonly any[] } {
  const policies = template.findResources("AWS::IAM::Policy");
  const matches = Object.entries(policies).filter(([logicalId]) =>
    logicalId.includes(substring),
  );
  expect(
    matches.length,
    `expected exactly one AWS::IAM::Policy whose logical id contains "${substring}", got ${matches.length}`,
  ).toBe(1);
  const [logicalId, resource] = matches[0];
  const statements = (resource as any).Properties?.PolicyDocument?.Statement;
  expect(Array.isArray(statements)).toBe(true);
  return { logicalId, statements };
}

/**
 * Find the single output whose logical id starts with `prefix`. Mirrors
 * `findRolePolicyDocument`'s diagnostic shape: a missing or duplicated
 * output names the offending prefix in the failure message.
 *
 * Uses prefix-match rather than substring-match because the three
 * `*BedrockGrantSummary` output names share `BedrockGrantSummary` as a
 * common substring — a substring lookup would non-deterministically
 * match all three.
 */
function findOutputByLogicalIdPrefix(
  template: Template,
  prefix: string,
): { logicalId: string; value: string } {
  const outputs = template.findOutputs("*");
  const matches = Object.entries(outputs).filter(([logicalId]) =>
    logicalId.startsWith(prefix),
  );
  expect(
    matches.length,
    `expected exactly one CFN output whose logical id starts with "${prefix}", got ${matches.length}`,
  ).toBe(1);
  const [logicalId, output] = matches[0];
  return { logicalId, value: (output as any).Value };
}

/**
 * Normalise a resource-list value (string or string[]) into a sorted,
 * deduplicated array of strings. The IAM engine treats `Resource` as a
 * set, so set-equality is the correct comparison rather than array
 * equality. Sorting the inputs identically lets us compare the two
 * lists with `toEqual` for a precise mismatch diagnostic.
 */
function normaliseResourceList(value: unknown): string[] {
  const arr = Array.isArray(value) ? value : [value];
  for (const item of arr) {
    if (typeof item !== "string") {
      throw new Error(
        `Resource list entry is not a literal string: ${JSON.stringify(item)}. ` +
          "computeBedrockGrants emits literal ARN strings (the helper interpolates stack.region/account at synth time), so any non-string entry indicates a hand-rolled statement that drifted.",
      );
    }
  }
  return Array.from(new Set(arr as string[])).sort();
}

/**
 * Pull every statement on `statements` whose Action set includes
 * `bedrock:InvokeModel` and/or `bedrock:Converse`. Wave 3 (Task 20.5)
 * narrowed the canonical posture to exactly one such statement per
 * Lambda — the one `computeBedrockGrants` produces. The filter is
 * deliberately tighter than "any `bedrock:*` statement" because the RAG
 * Evaluate Lambda still carries a parallel `BedrockRagEvaluation`
 * statement covering evaluation-job lifecycle APIs (`CreateEvaluationJob`
 * / `GetEvaluationJob` / `StopEvaluationJob`) that are outside the
 * helper's `InvokeModel` / `Converse` scope and intentionally NOT subject
 * to the single-grant invariant.
 *
 * Returns the matching statements as `{ actions, resources }` pairs so
 * the caller can assert (a) exactly one match exists and (b) that match's
 * Resource set is set-equal to the helper's output.
 */
function findInvokeModelConverseStatements(
  statements: readonly any[],
): Array<{ actions: string[]; resources: string[] }> {
  const matches: Array<{ actions: string[]; resources: string[] }> = [];
  for (const statement of statements) {
    const actions: string[] = Array.isArray(statement.Action)
      ? statement.Action
      : [statement.Action];
    const includesInvokeOrConverse = actions.some(
      (a) =>
        typeof a === "string" &&
        (a === "bedrock:InvokeModel" || a === "bedrock:Converse"),
    );
    if (!includesInvokeOrConverse) continue;
    matches.push({
      actions,
      resources: normaliseResourceList(statement.Resource),
    });
  }
  return matches;
}

// ---------------------------------------------------------------------------
// Resource → method-path resolution (for the Prompts API auth-scope test)
// ---------------------------------------------------------------------------

/**
 * Build a map from API Gateway resource logical id to its full path
 * starting from `/`. The synthesised template represents the resource
 * tree as a forest of `AWS::ApiGateway::Resource` rows linked by
 * `ParentId` (`Ref` to a sibling Resource, or `Fn::GetAtt` to the API's
 * root id). The function walks each resource up to its root and joins
 * the `PathPart` segments.
 *
 * Resources whose `ParentId` references the root API resource (via
 * `Fn::GetAtt: [ <ApiId>, "RootResourceId" ]`) are anchored at `/`. All
 * other roots are unreachable and indicate a malformed template.
 */
function buildResourcePathMap(template: Template): Map<string, string> {
  const resources = template.findResources("AWS::ApiGateway::Resource");
  // First pass: index every resource by logical id, capturing its
  // `PathPart` and parent reference.
  const nodes = new Map<
    string,
    { pathPart: string; parentRef: string | null }
  >();
  for (const [logicalId, resource] of Object.entries(resources)) {
    const props = (resource as any).Properties ?? {};
    const pathPart = props.PathPart;
    const parentId = props.ParentId;
    const parentRef =
      typeof parentId === "object" &&
      parentId !== null &&
      typeof parentId.Ref === "string"
        ? parentId.Ref
        : // Anchored at the API root via `Fn::GetAtt: [ <ApiId>,
          // "RootResourceId" ]`. We don't need to identify which API,
          // only that the parent is "root" so the walker stops here.
          null;
    nodes.set(logicalId, { pathPart, parentRef });
  }

  // Second pass: walk each resource to the root and assemble its path.
  // Each call memoises into `paths` so deeper subtrees don't re-walk.
  const paths = new Map<string, string>();
  function pathFor(logicalId: string): string {
    const cached = paths.get(logicalId);
    if (cached !== undefined) return cached;
    const node = nodes.get(logicalId);
    if (node === undefined) {
      // Resource referenced by Method.ResourceId but missing from
      // Resources map — should not happen on a valid template.
      throw new Error(
        `API Gateway Resource "${logicalId}" not found in synthesized template`,
      );
    }
    const parentPath =
      node.parentRef === null ? "" : pathFor(node.parentRef);
    const fullPath = `${parentPath}/${node.pathPart}`;
    paths.set(logicalId, fullPath);
    return fullPath;
  }
  for (const logicalId of nodes.keys()) {
    pathFor(logicalId);
  }
  return paths;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("Bedrock IAM grants — set-equality with computeBedrockGrants (R19.2, R19.3)", () => {
  // Synth once for every assertion: synth is expensive enough that
  // re-running it per test inflates the suite runtime, and the
  // assertions are independent reads against the same template.
  const { stack, template } = synth();

  for (const spec of BEDROCK_LAMBDAS) {
    it(`${spec.constructId} role policy carries EXACTLY ONE Bedrock InvokeModel/Converse statement set-equal to the helper's expected union`, () => {
      // Compute the expected Resource list by re-running the helper
      // against the same registry the constructs consume. Sorting the
      // result is redundant (the helper sorts internally) but mirrors
      // the IAM engine's set semantics and lets the comparison below
      // use plain string equality.
      const expected = computeBedrockGrants({
        promptKeys: spec.promptKeys,
        stack,
      });
      const expectedResources = normaliseResourceList(
        expected.statement.toJSON().Resource,
      );

      // Pull the Lambda's role policy and find every statement whose
      // Action set includes `bedrock:InvokeModel` and/or
      // `bedrock:Converse`. Wave 3 (Task 20.5) narrowed the posture to
      // exactly one such statement per Lambda — the registry-derived
      // one. Two statements indicates a regression: a legacy inline
      // `bedrock:InvokeModel` / `bedrock:Converse` block was
      // reintroduced alongside the helper's grant (the dual-grant
      // posture from Wave 0, retired in Tasks 20.1 and 20.2). Zero
      // statements indicates the construct never wired the helper.
      const policy = findRolePolicyDocument(
        template,
        spec.rolePolicyLogicalIdSubstring,
      );
      const invokeConverseStatements = findInvokeModelConverseStatements(
        policy.statements,
      );

      expect(
        invokeConverseStatements.length,
        `${spec.constructId} role policy must carry EXACTLY ONE statement whose Action set includes bedrock:InvokeModel and/or bedrock:Converse (Wave 3 single-grant posture, Task 20.5). Got ${invokeConverseStatements.length}: ${JSON.stringify(invokeConverseStatements, null, 2)}`,
      ).toBe(1);

      const [matched] = invokeConverseStatements;

      // The helper-derived statement carries exactly these two actions
      // per R19.1 — assert it so a future helper change that widens the
      // action list (e.g. adds `bedrock:ConverseStream`) updates the
      // test in lockstep, and so a hand-rolled inline statement that
      // happens to use only one of the two actions still trips the
      // single-grant guard above.
      expect(matched.actions.sort()).toEqual(
        ["bedrock:Converse", "bedrock:InvokeModel"].sort(),
      );

      // The single statement's Resource set must be set-equal to the
      // helper-derived union for the Lambda's `promptKey` set. A miss
      // flags the policy as either wider (extra ARNs not justified by
      // any registered promptKey) or narrower (helper produced an ARN
      // absent from the role) — both fail the build with a concrete
      // symmetric-difference diff.
      if (
        JSON.stringify(matched.resources) !== JSON.stringify(expectedResources)
      ) {
        const expectedSet = new Set(expectedResources);
        const actualSet = new Set(matched.resources);
        const missing = [...expectedSet].filter((r) => !actualSet.has(r));
        const extra = matched.resources.filter((r) => !expectedSet.has(r));
        throw new Error(
          `${spec.constructId} role policy's Bedrock InvokeModel/Converse statement Resource set does not match the helper-derived union for promptKeys=${JSON.stringify(spec.promptKeys)}.\n` +
            `Expected resources (${expectedResources.length}): ${JSON.stringify(expectedResources, null, 2)}\n` +
            `Actual resources (${matched.resources.length}): ${JSON.stringify(matched.resources, null, 2)}\n` +
            `Missing from role (registry has, role lacks): ${JSON.stringify(missing, null, 2)}\n` +
            `Extra on role (role has, registry doesn't justify): ${JSON.stringify(extra, null, 2)}`,
        );
      }
    });
  }
});

describe("BedrockGrantSummary CFN outputs (R19.6)", () => {
  const { stack, template } = synth();

  // Group the Lambdas by which CFN output should carry them so each
  // assertion can verify (a) the output exists and (b) the JSON map's
  // keys are the exact set of construct ids we expect.
  const lambdasByOutput = new Map<SummaryOutputKind, BedrockLambdaSpec[]>();
  for (const spec of BEDROCK_LAMBDAS) {
    const list = lambdasByOutput.get(spec.summaryOutputKind) ?? [];
    list.push(spec);
    lambdasByOutput.set(spec.summaryOutputKind, list);
  }

  for (const [kind, specs] of lambdasByOutput) {
    const prefix = SUMMARY_OUTPUT_LOGICAL_ID_PREFIX[kind];
    it(`${prefix} CFN output exists, parses as JSON, and carries one entry per Bedrock-calling Lambda`, () => {
      const output = findOutputByLogicalIdPrefix(template, prefix);
      let parsed: Record<string, readonly ModelKey[]>;
      try {
        parsed = JSON.parse(output.value);
      } catch (err) {
        throw new Error(
          `${prefix} CFN output value is not valid JSON: ${output.value}`,
        );
      }
      expect(typeof parsed).toBe("object");
      expect(parsed).not.toBeNull();
      // The keys are the construct ids — match exactly the expected
      // set so a forgotten-to-record Lambda or a stray entry fails.
      const expectedKeys = specs.map((s) => s.constructId).sort();
      const actualKeys = Object.keys(parsed).sort();
      expect(actualKeys).toEqual(expectedKeys);

      // Each entry's value should be the exact same `modelKeys[]` the
      // helper returns for that Lambda — independently verifies that
      // the on-template summary mirrors the registry, complementing
      // the role-policy assertion above.
      for (const spec of specs) {
        const expected = computeBedrockGrants({
          promptKeys: spec.promptKeys,
          stack,
        });
        expect(parsed[spec.constructId]).toEqual([...expected.modelKeys]);
      }
    });
  }
});

describe("Prompts API authorization scopes (R8.1)", () => {
  const { template } = synth();

  it("every method whose path begins with /prompts has authorizationScopes: ['test-platform/run']", () => {
    const pathByResource = buildResourcePathMap(template);
    const methods = template.findResources("AWS::ApiGateway::Method");

    // Find every method whose `ResourceId` references a resource whose
    // path starts with `/prompts` (covers `/prompts`,
    // `/prompts/{promptKey}`, `/prompts/{promptKey}/reset`,
    // `/prompts/{promptKey}/history`, and `/prompts/active-runs`).
    const promptMethods: Array<{
      logicalId: string;
      httpMethod: string;
      path: string;
      authorizationScopes: unknown;
    }> = [];

    for (const [logicalId, resource] of Object.entries(methods)) {
      const props = (resource as any).Properties ?? {};
      const resourceIdRef = props.ResourceId?.Ref;
      if (typeof resourceIdRef !== "string") continue;
      const resourcePath = pathByResource.get(resourceIdRef);
      if (resourcePath === undefined) continue;
      if (!resourcePath.startsWith("/prompts")) continue;
      // Skip CORS preflight OPTIONS methods — those are auto-generated
      // by `defaultCorsPreflightOptions` and intentionally unauthed.
      if (props.HttpMethod === "OPTIONS") continue;
      promptMethods.push({
        logicalId,
        httpMethod: props.HttpMethod,
        path: resourcePath,
        authorizationScopes: props.AuthorizationScopes,
      });
    }

    // Sanity-check that the synth produced the six routes the
    // dispatcher expects (R8.1 + the `/prompts/active-runs` endpoint
    // from R16.5). Missing one indicates the route wiring regressed.
    const expectedRouteCount = 6;
    expect(
      promptMethods.length,
      `expected ${expectedRouteCount} non-OPTIONS methods under /prompts (one per Prompts API endpoint), got ${promptMethods.length}: ${JSON.stringify(
        promptMethods.map((m) => `${m.httpMethod} ${m.path}`),
        null,
        2,
      )}`,
    ).toBe(expectedRouteCount);

    // Every method MUST carry the access-token scope. The
    // implement-recommendations regression that prompted this guard
    // was specifically a method whose `MethodOptions` was constructed
    // without `authorizationScopes`, which silently flipped the
    // authorizer back to ID-token mode. The `toEqual` check fails on
    // both `undefined` and the wrong scope.
    for (const method of promptMethods) {
      expect(
        method.authorizationScopes,
        `${method.httpMethod} ${method.path} (${method.logicalId}) is missing or has wrong AuthorizationScopes; expected ['test-platform/run']`,
      ).toEqual(["test-platform/run"]);
    }
  });
});
