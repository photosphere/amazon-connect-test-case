/**
 * Pure prompt-rendering module — produces the four context strings the three
 * AWS-published Bedrock-judge prompt templates expect (`{context}`,
 * `{available_tools}`, `{assistant_turn}`, `{tool_turn}`) from a single test
 * case's `ExecutionTrace`, `TranscriptTurn[]`, `AgentSnapshot`, and the test
 * case's `expectedToolNames`.
 *
 * No AWS SDK imports — exclusively pure functions over the in-memory data
 * shapes defined in `src/shared/types.ts`. Unit- and property-testable
 * without a deploy.
 *
 * The per-step rendering format is **byte-compatible** with the validated
 * reference implementation in `scripts/bedrock-judge-probe.ts`. The probe's
 * inline helpers (`groupTraceIntoTurns`, `renderFullContext`,
 * `renderContextBefore`, `renderAvailableTools`) are reorganised here without
 * a behavioural change so the production module and the probe produce
 * identical conversation/tool/available-tools text for the two committed
 * Span_Fixtures (`tests/fixtures/spans/multi-tool-success.json`,
 * `tests/fixtures/spans/failure-escalation.json`).
 *
 * The new aggregator `renderJudgePromptContext` adds the per-test-case
 * expected-tools annotation that the platform's GoalSuccessRate and
 * ToolSelectionAccuracy templates need (Requirement 2.6). The annotation is
 * **never** added to the per-assistant-turn Helpfulness context — the
 * Helpfulness rubric in `.kiro/steering/bedrock-judge-prompts.md` evaluates
 * from the user's perspective and does not reference expected tools.
 *
 * @module judge-prompt-rendering
 */

import type {
  AgentSnapshot,
  ExecutionStep,
  ExecutionTrace,
  ToolDefinition,
  ToolInvocation,
  TranscriptTurn,
} from "../types";

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/**
 * One tool call recorded on a {@link ConversationTurn}. `isSynthetic` is
 * `true` when the tool step was injected by
 * `augmentTraceWithControlTools` to surface a RETURN_TO_CONTROL tool
 * (e.g. `Escalate`, `Complete`, custom control tools) that ListSpans
 * does not expose as a regular `execute_tool` span. Synthetic entries
 * carry empty `arguments` and `result` because Q in Connect consumes the
 * agent's actual call payload upstream and never emits it on the
 * `escalate_agent` / `complete_agent` span attributes.
 *
 * The flag is consulted by the two prefix-context renderers so the
 * judge sees an explanatory parenthetical instead of a misleading
 * `Action: <Tool>({})` line, and by the `toolTurns` builder in
 * `renderJudgePromptContext` so the ToolSelectionAccuracy judge is
 * never asked to score call quality on data the platform does not
 * have.
 */
export interface ConversationTurnToolCall {
  toolInvocation: ToolInvocation;
  /**
   * `true` iff the source step's `spanName === "synthetic_control_tool"`
   * (i.e. the entry was injected by `augmentTraceWithControlTools`).
   */
  isSynthetic: boolean;
}

/**
 * One assistant-turn unit of conversation, paired with the customer text (if
 * any) that immediately preceded it and the chronological list of tool calls
 * the agent issued during that turn. This is the unit `groupTraceIntoTurns`
 * emits so per-turn / per-tool-call context windows can be rendered as
 * prefixes without re-walking the whole trace.
 */
export interface ConversationTurn {
  /** Customer utterance that opened this turn (if any). */
  customerText?: string;
  /** Agent reasoning / customer-facing text emitted during this turn (if any). */
  assistantText?: string;
  /**
   * Tool invocations the agent issued during this turn, in chronological
   * order. Each entry carries an `isSynthetic` flag distinguishing real
   * `execute_tool` spans (whose arguments and results were observed on the
   * wire) from synthesised RETURN_TO_CONTROL entries (whose arguments and
   * results were NOT surfaced by ListSpans). See
   * {@link ConversationTurnToolCall} for the contract.
   */
  toolCalls: ConversationTurnToolCall[];
  /** Index of the inference span in `trace.steps` this turn was anchored on. */
  inferenceStepIndex?: number;
}

/** Output of `renderJudgePromptContext` — everything the Lambda needs to drive the three templates for one test case. */
export interface JudgePromptContext {
  /**
   * Session-level conversation context for the GoalSuccessRate template.
   * Always includes the `Expected tools:` annotation when `expectedToolNames`
   * is non-empty (Requirement 2.6).
   */
  context: string;
  /**
   * Numbered list of every tool in the AgentSnapshot — name, description,
   * and input schema (Requirement 2.3).
   */
  availableTools: string;
  /**
   * One entry per assistant turn in the Execution_Trace. The `context`
   * string is **prefix-only** (steps strictly before this turn) and does
   * NOT include the expected-tools annotation (Helpfulness evaluates from
   * the user's perspective).
   */
  assistantTurns: Array<{
    /** 0-based index of this assistant turn among assistant turns. */
    index: number;
    /** Prefix-only conversation context to substitute into `{context}`. */
    context: string;
    /** Per-turn assistant utterance to substitute into `{assistant_turn}`. */
    assistantTurn: string;
  }>;
  /**
   * One entry per `execute_tool` step in the Execution_Trace. The `context`
   * string is prefix-only (steps strictly before this tool call, including
   * any same-turn elements that came earlier) and DOES include the
   * expected-tools annotation when `expectedToolNames` is non-empty.
   */
  toolTurns: Array<{
    /** 0-based index of this tool call among tool calls. */
    index: number;
    /** Prefix-only conversation context to substitute into `{context}`. */
    context: string;
    /** Per-tool-call summary to substitute into `{tool_turn}`. */
    toolTurn: string;
  }>;
}

/** Input bundle for `renderJudgePromptContext`. */
export interface RenderJudgePromptContextInput {
  trace: ExecutionTrace;
  transcript: TranscriptTurn[];
  snapshot: AgentSnapshot;
  /** The test case's expected tool names (from `successCriteria`). */
  expectedToolNames: readonly string[];
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/**
 * Sentinel string emitted in place of an empty prefix context, matching the
 * probe's behaviour at the per-unit call sites. The Helpfulness and
 * ToolSelectionAccuracy templates assume a non-empty `{context}`; this gives
 * the judge a clean signal that the unit is at the start of the conversation
 * rather than a prompt with a blank section.
 */
export const BEGINNING_OF_CONVERSATION = "(beginning of conversation)";

/** Sentinel emitted by `renderAvailableTools` when the snapshot lists no tools. */
export const NO_AVAILABLE_TOOLS = "(no available tools)";

// ---------------------------------------------------------------------------
// Turn grouping
// ---------------------------------------------------------------------------

/**
 * One customer-side utterance plus the wall-clock timestamp it was
 * delivered at. Used by {@link groupTraceIntoTurns} to align each
 * inference step with the most recent customer utterance whose timestamp
 * is `<=` the inference's own start timestamp.
 */
export interface CustomerTurnWithTimestamp {
  /** The customer's text. Empty / whitespace-only entries are skipped before pairing. */
  text: string;
  /** Epoch milliseconds the customer turn was emitted at. Use `0` when unknown. */
  timestampMs: number;
}

/**
 * Groups the `ExecutionTrace`'s steps into per-assistant-turn windows.
 *
 * Q in Connect traces alternate `inference` (assistant text) with
 * `execute_tool` (tool calls) plus optional `invoke_agent` / `other` markers.
 * Each `inference` step starts a new assistant turn; subsequent
 * `execute_tool` steps are attached to the current turn until the next
 * `inference`.
 *
 * Customer-to-assistant pairing is **timestamp-driven**, not positional:
 * each inference step claims the *next-unconsumed* customer turn whose
 * `timestampMs <= step.timestamp`. Inference steps whose start timestamp
 * precedes every remaining customer turn (i.e. the agent emitted multiple
 * inference / tool steps in succession without the customer speaking in
 * between) get `customerText: undefined`. This stops the renderer from
 * silently shifting later customer messages onto earlier assistant turns
 * — the bug that caused the Bedrock judge to score Helpfulness and
 * ToolSelectionAccuracy from the wrong customer prompt when the agent
 * chained multiple inference / tool calls per customer message.
 *
 * Inference steps with no recoverable timestamp are treated as occurring
 * "later than every customer turn" so that legacy callers (e.g. the
 * property-test arbitrary, which never sets step timestamps) keep the
 * one-customer-per-inference pairing they previously relied on.
 *
 * Tool steps that appear before the first `inference` (no current turn
 * yet) are dropped — they cannot be attached to a non-existent turn. In
 * well-formed Q in Connect traces the first inference span always
 * precedes the first execute_tool span, so this is a defensive guard
 * rather than a common case.
 *
 * @param trace - The structured execution trace
 * @param customerTurns - Customer utterances in chronological order with timestamps
 * @returns One `ConversationTurn` per assistant turn, in chronological order
 */
export function groupTraceIntoTurns(
  trace: ExecutionTrace,
  customerTurns: readonly CustomerTurnWithTimestamp[],
): ConversationTurn[] {
  const turns: ConversationTurn[] = [];
  let nextCustomerIdx = 0;
  let current: ConversationTurn | null = null;

  for (const step of trace.steps) {
    if (step.type === "inference") {
      if (current) turns.push(current);

      // Treat a missing inference timestamp as "later than every customer
      // turn" so legacy callers that don't set step timestamps keep the
      // one-customer-per-inference behaviour the property tests rely on.
      const stepMs =
        step.timestamp != null ? Date.parse(step.timestamp) : Number.POSITIVE_INFINITY;
      const stepTimeMs = Number.isFinite(stepMs) ? stepMs : Number.POSITIVE_INFINITY;

      let customerText: string | undefined;
      if (
        nextCustomerIdx < customerTurns.length &&
        customerTurns[nextCustomerIdx].timestampMs <= stepTimeMs
      ) {
        customerText = customerTurns[nextCustomerIdx].text;
        nextCustomerIdx += 1;
      }

      current = {
        customerText,
        assistantText: step.text,
        toolCalls: [],
        inferenceStepIndex: step.index,
      };
      continue;
    }
    if (step.type === "tool" && step.tool && current) {
      current.toolCalls.push({
        toolInvocation: step.tool,
        isSynthetic: step.spanName === "synthetic_control_tool",
      });
    }
  }
  if (current) turns.push(current);
  return turns;
}

// ---------------------------------------------------------------------------
// Per-step line renderers
// ---------------------------------------------------------------------------

/**
 * Explanatory parenthetical appended to a synthetic control tool's
 * `Action:` line. RETURN_TO_CONTROL tools (Complete, Escalate, custom
 * control tools) are reported by Q in Connect via
 * `conversationSessionData["Tool"]` and surfaced in ListSpans as a
 * non-`execute_tool` span (`escalate_agent`, `complete_agent`, …) with
 * no toolUse attributes. The `augmentTraceWithControlTools` augmenter
 * synthesises a `type: "tool"` step for each so the judge sees the
 * tool fired, but its `arguments` and `result` are necessarily empty —
 * the actual payload is consumed by the RETURN_TO_CONTROL handler
 * upstream and never lands on a span attribute the parser can read.
 *
 * Without the explanatory parenthetical the GoalSuccessRate judge
 * reads the empty payload as "the agent failed to populate required
 * parameters" and scores 0. The parenthetical reframes the empty
 * payload as a platform observability limitation so the judge can
 * focus on whether the tool *choice* was correct.
 */
const SYNTHETIC_CONTROL_TOOL_NOTE =
  "RETURN_TO_CONTROL — call arguments and result not surfaced by ListSpans";

/**
 * Renders the two-line `Action:` / `Tool:` block for a single tool call
 * recorded on a {@link ConversationTurn}. Real tool calls render with
 * the full argument JSON and result; synthetic RETURN_TO_CONTROL calls
 * render with the explanatory parenthetical and a `(not captured)`
 * placeholder so the judge does not interpret the empty payload as an
 * agent defect.
 *
 * @param tc - One tool call from a `ConversationTurn.toolCalls` entry
 * @returns The rendered lines (always exactly two: `Action:` then `Tool:`)
 */
function renderToolCallLines(tc: ConversationTurnToolCall): string[] {
  if (tc.isSynthetic) {
    return [
      `Action: ${tc.toolInvocation.toolName} (${SYNTHETIC_CONTROL_TOOL_NOTE})`,
      `Tool: (not captured)`,
    ];
  }
  return [
    `Action: ${renderToolTurn(tc.toolInvocation)}`,
    `Tool: ${JSON.stringify(tc.toolInvocation.result ?? null)}`,
  ];
}

/**
 * Renders one chronological turn as the `User:` / `Assistant:` /
 * `Action:` / `Tool:` lines the prompt templates expect. Empty utterances
 * are skipped (no blank lines emitted), and tool calls follow their assistant
 * text within the same turn.
 *
 * @param turn - The conversation turn to render
 * @returns The rendered lines (one per element); join with `\n` to get a single string
 */
function renderTurnLines(turn: ConversationTurn): string[] {
  const lines: string[] = [];
  if (turn.customerText) lines.push(`User: ${turn.customerText}`);
  if (turn.assistantText) lines.push(`Assistant: ${turn.assistantText}`);
  for (const tc of turn.toolCalls) {
    lines.push(...renderToolCallLines(tc));
  }
  return lines;
}

/**
 * Renders a complete sequence of conversation turns as `User:` / `Assistant:`
 * / `Action:` / `Tool:` lines preserving chronological order, one line per
 * source step, no omissions and no duplications (Requirement 2.2).
 *
 * The output is byte-compatible with the probe's `renderFullContext`.
 *
 * @param turns - The conversation turns in chronological order
 * @returns The rendered conversation as a single multi-line string (`""` when `turns` is empty)
 */
export function renderContext(turns: readonly ConversationTurn[]): string {
  const lines: string[] = [];
  for (const turn of turns) {
    lines.push(...renderTurnLines(turn));
  }
  return lines.join("\n");
}

/**
 * Renders only the conversation turns strictly before `targetIndex` — the
 * prefix of the conversation up to but not including the unit at
 * `targetIndex`. Used to build the per-assistant-turn Helpfulness context
 * (Requirement 2.4).
 *
 * `targetIndex` values outside `[0, turns.length]` are clamped to that range
 * so the function is total: a negative index renders the empty string and
 * an index past the end renders the full conversation.
 *
 * @param turns - The full sequence of conversation turns
 * @param targetIndex - The 0-based assistant-turn index whose prefix to render
 * @returns The rendered prefix (`""` when no preceding turns exist)
 */
export function renderContextBefore(
  turns: readonly ConversationTurn[],
  targetIndex: number,
): string {
  const clamped = Math.max(0, Math.min(targetIndex, turns.length));
  return renderContext(turns.slice(0, clamped));
}

/**
 * Renders the `{available_tools}` section as a numbered list of every tool
 * in the AgentSnapshot — name, description, and input schema per entry
 * (Requirement 2.3). The numbering is 1-based and the schema is serialised
 * via `JSON.stringify` so it survives the template substitution unchanged.
 *
 * The output is byte-compatible with the probe's `renderAvailableTools`.
 *
 * @param tools - The tool list from `AgentSnapshot.tools`
 * @returns The numbered list, or the `(no available tools)` sentinel when the snapshot has zero tools
 */
export function renderAvailableTools(tools: readonly ToolDefinition[]): string {
  if (!tools.length) return NO_AVAILABLE_TOOLS;
  return tools
    .map((t, i) => {
      const desc = t.description ?? "(no description)";
      const schema = t.inputSchema ? JSON.stringify(t.inputSchema) : "{}";
      return `${i + 1}. ${t.toolName}\n   description: ${desc}\n   inputSchema: ${schema}`;
    })
    .join("\n");
}

/**
 * Renders the `{assistant_turn}` substitution for one Helpfulness evaluator
 * unit — the agent's customer-facing text from a single inference step. An
 * inference step without recoverable text yields the empty string; the caller
 * may treat that as a non-submittable turn.
 *
 * @param step - The execution step (must be of type `"inference"`)
 * @returns The assistant utterance, or `""` when no text was captured
 */
export function renderAssistantTurn(step: ExecutionStep): string {
  return step.text ?? "";
}

/**
 * Renders the `{tool_turn}` substitution for one ToolSelectionAccuracy
 * evaluator unit — the tool name followed by its arguments serialised as
 * JSON in parentheses (Requirement 2.5). Missing or non-object arguments are
 * rendered as `{}` so the format stays consistent across well-typed and
 * malformed tool invocations.
 *
 * The output is byte-compatible with the `Action:` payload format used by
 * the probe's `renderFullContext`.
 *
 * @param toolInvocation - The captured `ToolInvocation` from an `execute_tool` step
 * @returns The rendered tool call summary, e.g. `"verifyIdentity({\"ani\":\"+15555550100\"})"`
 */
export function renderToolTurn(toolInvocation: ToolInvocation): string {
  return `${toolInvocation.toolName}(${JSON.stringify(toolInvocation.arguments ?? {})})`;
}

/**
 * Render a tool-turn substitution for the ToolSelectionAccuracy
 * `{tool_turn}` placeholder. Real `execute_tool` steps render as
 * `${toolName}(${JSON.stringify(args)})`, byte-compatible with the
 * existing format produced by {@link renderToolTurn}. Synthetic
 * RETURN_TO_CONTROL steps render with an explanatory parenthetical so
 * the judge can recognise the arguments-not-observable case and grade
 * only on tool-choice quality.
 *
 * Both real and synthetic control tools carry descriptions in the
 * AgentSnapshot's tool list, so both can be evaluated for tool-choice
 * accuracy. The judge sees the full available_tools catalogue, the
 * conversation prefix that motivated the choice, and a `tool_turn`
 * value that either includes the chosen arguments (real tools) or
 * notes that the platform never observed them (synthetic tools).
 *
 * @param call - One tool call from a `ConversationTurn.toolCalls` entry
 * @returns The rendered tool-turn string for substitution into the prompt
 */
export function renderToolTurnForToolCall(
  call: ConversationTurnToolCall,
): string {
  if (call.isSynthetic) {
    return `${call.toolInvocation.toolName} (RETURN_TO_CONTROL — call arguments not surfaced by ListSpans)`;
  }
  return renderToolTurn(call.toolInvocation);
}

// ---------------------------------------------------------------------------
// Aggregator
// ---------------------------------------------------------------------------

/**
 * Extracts the customer-side utterances from a `TranscriptTurn[]` in
 * chronological order, paired with their wall-clock timestamps. Used to
 * align the transcript with the trace's assistant turns:
 * {@link groupTraceIntoTurns} pairs each inference step with the
 * next-unconsumed customer turn whose `timestampMs <= step.timestamp`.
 *
 * Empty / whitespace-only customer texts are dropped — there is no
 * positional placeholder to maintain because pairing is timestamp-driven
 * rather than positional. Customer turns with an unparseable timestamp
 * fall back to `0` so they are still pairable with any inference step.
 */
function extractCustomerTurns(
  transcript: readonly TranscriptTurn[],
): CustomerTurnWithTimestamp[] {
  const out: CustomerTurnWithTimestamp[] = [];
  for (const t of transcript) {
    if (t.role !== "customer") continue;
    const trimmed = t.text?.trim();
    if (!trimmed || trimmed.length === 0) continue;
    const parsed = t.timestamp ? Date.parse(t.timestamp) : 0;
    const timestampMs = Number.isFinite(parsed) ? parsed : 0;
    out.push({ text: t.text, timestampMs });
  }
  return out;
}

/**
 * Renders the prefix-only conversation context for one Helpfulness
 * evaluator unit. Includes:
 *   - Every preceding turn rendered via {@link renderContext}.
 *   - The current turn's `User:` line (the customer message that triggered
 *     this assistant reply) — the Helpfulness template's `{context}` is
 *     captioned "Previous turns" and the user's prompt that prompted the
 *     assistant's reply is, by definition, a previous turn relative to
 *     the assistant's response. Without this line the judge for the very
 *     first inference always sees `(beginning of conversation)` and
 *     concludes "no prior user message visible" — exactly the failure
 *     mode that motivated the Task 10 fix.
 *   - The current turn's same-turn tool calls rendered as `Action:` /
 *     `Tool:` line pairs (Requirement 14.1). These are included so the
 *     Helpfulness judge sees that an assistant reply like "Let me transfer
 *     you" was actually followed by an `Escalate` tool call — without
 *     these lines the judge scores the reply as an unfulfilled promise.
 *
 * The current turn's `Assistant:` line is intentionally NOT included in
 * the context — it is what the rubric is asking the judge to score and
 * is substituted into `{assistant_turn}` separately.
 *
 * @param turns - The full sequence of conversation turns
 * @param turnIndex - 0-based index of the assistant turn being scored
 * @returns The rendered context (`""` when nothing precedes this turn)
 */
function renderContextForAssistantTurn(
  turns: readonly ConversationTurn[],
  turnIndex: number,
): string {
  const lines: string[] = [];
  const before = renderContext(turns.slice(0, turnIndex));
  if (before.length > 0) lines.push(before);
  const turn = turns[turnIndex];
  if (turn.customerText) lines.push(`User: ${turn.customerText}`);
  // Include same-turn tool calls so the Helpfulness judge sees tool actions
  // that accompanied this assistant reply (Requirement 14.1, 14.2).
  for (const tc of turn.toolCalls) {
    lines.push(...renderToolCallLines(tc));
  }
  return lines.join("\n");
}

/**
 * Renders the prefix-only conversation context for a single tool call,
 * including same-turn elements (customer text, assistant utterance, and any
 * tool calls within the same turn that came strictly earlier). This matches
 * the probe's per-tool-call context construction byte-for-byte for the two
 * committed Span_Fixtures.
 *
 * @param turns - The full sequence of conversation turns
 * @param turnIndex - 0-based index of the assistant turn this tool call belongs to
 * @param toolCallIndex - 0-based index of this tool call within its turn
 * @returns The rendered prefix (`""` when nothing precedes this tool call)
 */
function renderContextBeforeToolCall(
  turns: readonly ConversationTurn[],
  turnIndex: number,
  toolCallIndex: number,
): string {
  const lines: string[] = [];
  const before = renderContext(turns.slice(0, turnIndex));
  if (before.length > 0) lines.push(before);
  const turn = turns[turnIndex];
  if (turn.customerText) lines.push(`User: ${turn.customerText}`);
  if (turn.assistantText) lines.push(`Assistant: ${turn.assistantText}`);
  for (let i = 0; i < toolCallIndex; i++) {
    lines.push(...renderToolCallLines(turn.toolCalls[i]));
  }
  return lines.join("\n");
}

/**
 * Appends the `Expected tools:` annotation to a rendered context. The
 * annotation is appended to the **end** of the context with a blank line
 * separator so it never disturbs the chronological conversation lines that
 * precede it. Empty `expectedToolNames` lists short-circuit to the unmodified
 * context (no trailing whitespace, no empty annotation), keeping the output
 * byte-compatible with the probe when the test case has no expected tools.
 */
function appendExpectedToolsAnnotation(
  context: string,
  expectedToolNames: readonly string[],
): string {
  if (expectedToolNames.length === 0) return context;
  const annotation = `Expected tools: ${expectedToolNames.join(", ")}`;
  if (context.length === 0) return annotation;
  return `${context}\n\n${annotation}`;
}

/**
 * Replaces an empty rendered context with the `(beginning of conversation)`
 * sentinel so the per-unit Helpfulness and ToolSelectionAccuracy prompts
 * never carry a blank `{context}` block.
 */
function withFallback(context: string): string {
  return context.length > 0 ? context : BEGINNING_OF_CONVERSATION;
}

/**
 * Aggregator that produces every prompt-context string the three Bedrock-
 * judge templates need for a single test case (Requirement 2.1).
 *
 * Output structure:
 * - `context` — full conversation rendered for the GoalSuccessRate template,
 *   with the `Expected tools:` annotation appended (Requirement 2.6).
 * - `availableTools` — numbered tool list from the AgentSnapshot.
 * - `assistantTurns[i]` — one entry per assistant turn in the trace. The
 *   `context` field is the **prefix** of all steps strictly before this
 *   turn, with the `(beginning of conversation)` sentinel substituted when
 *   the prefix is empty. Helpfulness evaluates from the user's perspective
 *   so the expected-tools annotation is intentionally **not** appended here.
 * - `toolTurns[i]` — one entry per `execute_tool` step in the trace. The
 *   `context` field is the prefix of all steps strictly before this tool
 *   call (including same-turn elements that came earlier), with the
 *   `(beginning of conversation)` sentinel applied to an empty prefix and
 *   the `Expected tools:` annotation appended.
 *
 * Index semantics: `assistantTurns[i].index` and `toolTurns[i].index` are
 * the 0-based ordinals of the unit among same-kind units in the trace,
 * matching the array position. The aggregator preserves chronological
 * order across both arrays.
 *
 * @param input - Trace, transcript, snapshot, and expected tool names for one test case
 * @returns The four prompt-context surfaces required by the three templates
 */
export function renderJudgePromptContext(
  input: RenderJudgePromptContextInput,
): JudgePromptContext {
  const { trace, transcript, snapshot, expectedToolNames } = input;

  const customerTurns = extractCustomerTurns(transcript);
  const turns = groupTraceIntoTurns(trace, customerTurns);

  const availableTools = renderAvailableTools(snapshot.tools);
  const sessionContextRaw = renderContext(turns);
  const context = appendExpectedToolsAnnotation(sessionContextRaw, expectedToolNames);

  // Helpfulness — one entry per assistant turn (skip turns whose inference
  // span carried no recoverable text; those cannot be evaluated by the
  // Helpfulness rubric and the Lambda will not emit a Converse call for them).
  // Per-turn context includes every preceding turn AND the current turn's
  // customer message (the user prompt that triggered this assistant reply
  // is, semantically, a "previous turn" relative to the assistant text the
  // judge is scoring; see `renderContextForAssistantTurn`).
  const assistantTurns: JudgePromptContext["assistantTurns"] = [];
  for (let i = 0; i < turns.length; i++) {
    const turn = turns[i];
    if (!turn.assistantText) continue;
    const prefix = renderContextForAssistantTurn(turns, i);
    assistantTurns.push({
      index: assistantTurns.length,
      context: withFallback(prefix),
      assistantTurn: turn.assistantText,
    });
  }

  // ToolSelectionAccuracy — one entry per tool call across all turns,
  // in chronological order. Both real `execute_tool` calls and synthetic
  // RETURN_TO_CONTROL entries are surfaced: the judge has two evaluation
  // surfaces ("was this the right tool to pick?" and "were the arguments
  // justified?"), and the tool-choice surface is gradeable for any tool
  // whose description appears in the AgentSnapshot — RETURN_TO_CONTROL
  // tools (Escalate, Complete, custom control tools) carry descriptions
  // just like MCP tools. Real entries render with the full
  // `${toolName}(${JSON.stringify(args)})` form. Synthetic entries
  // render with the explanatory parenthetical (see
  // {@link renderToolTurnForToolCall}) so the judge recognises the
  // arguments-not-observable case and grades only on tool choice rather
  // than penalising on the platform's empty payload.
  //
  // The prefix context for each tool call includes same-turn elements
  // that occurred strictly before the tool call (including any
  // synthetic entries earlier in the turn, rendered with the
  // explanatory parenthetical via `renderToolCallLines`).
  const toolTurns: JudgePromptContext["toolTurns"] = [];
  for (let ti = 0; ti < turns.length; ti++) {
    const turn = turns[ti];
    for (let tci = 0; tci < turn.toolCalls.length; tci++) {
      const prefix = renderContextBeforeToolCall(turns, ti, tci);
      const toolTurn = renderToolTurnForToolCall(turn.toolCalls[tci]);
      toolTurns.push({
        index: toolTurns.length,
        context: appendExpectedToolsAnnotation(withFallback(prefix), expectedToolNames),
        toolTurn,
      });
    }
  }

  return { context, availableTools, assistantTurns, toolTurns };
}
