/**
 * Pure, deploy-time Cognito callback/logout URL validator.
 *
 * The stack composes the Web_Client callback/logout URL list as
 * `validateCallbackUrls([...contextUrls, cloudFrontUrl], cloudFrontUrl)`. This
 * helper trims each entry, throws at synth on empty or non-absolute-URL entries
 * (so an invalid `callbackUrls` context parameter fails the deploy and registers
 * nothing), guarantees the CloudFront URL is always present, and returns a
 * deduplicated, insertion-order-preserving list (each unique URL exactly once).
 *
 * This module has NO AWS imports and is fully unit-testable without a deploy.
 *
 * Requirements: 4.4, 4.6
 */

/**
 * Returns true if `value` is a well-formed absolute URL (parseable with a
 * scheme/protocol and no base). Relative paths and malformed strings are not
 * absolute URLs.
 */
function isAbsoluteUrl(value: string): boolean {
  try {
    // The single-arg URL constructor requires an absolute URL; relative
    // references throw. This is the "well-formed absolute URL" check (Req 4.6).
    // eslint-disable-next-line no-new
    new URL(value);
    return true;
  } catch {
    return false;
  }
}

/**
 * Validate, dedupe, and order the Cognito callback (or logout) URL list.
 *
 * Each entry is trimmed; an entry that is empty/whitespace-only or not a
 * well-formed absolute URL causes a throw at synth (Requirement 4.6) so that no
 * URL from an invalid `callbackUrls` parameter is registered. The result is
 * deduplicated on the trimmed value, preserving first-seen (insertion) order so
 * each unique URL is registered exactly once (Requirement 4.4).
 *
 * When `cloudFrontUrl` is supplied, it is validated like any other entry and is
 * guaranteed to be included in the result; the returned list is then non-empty
 * and always contains the CloudFront URL (Requirements 4.1/4.2 inclusion). The
 * canonical caller passes the CloudFront URL both inside `urls` and as
 * `cloudFrontUrl`, which is idempotent under deduplication.
 *
 * @param urls Candidate callback/logout URLs (e.g. context-provided URLs plus
 *   the CloudFront URL).
 * @param cloudFrontUrl Optional CloudFront URL that must always be present in
 *   the result.
 * @returns Trimmed, validated, deduplicated, insertion-order-preserving URLs.
 * @throws Error if any entry (or `cloudFrontUrl`) is empty or not an absolute URL.
 */
export function validateCallbackUrls(
  urls: string[],
  cloudFrontUrl?: string
): string[] {
  const candidates = cloudFrontUrl === undefined ? urls : [...urls, cloudFrontUrl];

  const seen = new Set<string>();
  const result: string[] = [];

  for (const raw of candidates) {
    const trimmed = typeof raw === 'string' ? raw.trim() : '';
    if (trimmed.length === 0) {
      throw new Error(
        'Invalid callback URL: entries must be non-empty. Refusing to register any callback URLs from this parameter.'
      );
    }
    if (!isAbsoluteUrl(trimmed)) {
      throw new Error(
        `Invalid callback URL: "${trimmed}" is not a well-formed absolute URL. Refusing to register any callback URLs from this parameter.`
      );
    }
    if (seen.has(trimmed)) {
      continue;
    }
    seen.add(trimmed);
    result.push(trimmed);
  }

  if (cloudFrontUrl !== undefined) {
    // Defensive guarantee: the CloudFront URL is always part of the result.
    const trimmedCloudFront = cloudFrontUrl.trim();
    if (!seen.has(trimmedCloudFront)) {
      result.push(trimmedCloudFront);
    }
  }

  return result;
}
