// @vitest-environment jsdom
/**
 * Component tests for runtime-config loading and auth flows (task 7.2).
 *
 * Covers the behavior hardened in task 7.1 of `lib/runtime-config` plus
 * `src/frontend/src/api/config.ts`, `src/frontend/src/api/client.ts`
 * (`getBaseUrl`), `src/frontend/src/auth/cognito.ts` (`redirectToLogin`),
 * and the `RuntimeConfigError` UI surface.
 *
 * Validates:
 *  - **Requirement 5.4** — A network failure, non-OK response, or malformed
 *    `/config.json` MUST produce a visible "runtime configuration unavailable"
 *    error state, retain the user on the current page, and SHALL NOT issue any
 *    API request against an undefined `apiEndpoint`.
 *  - **Requirement 5.5** — An unauthenticated load of the hosted UI MUST
 *    redirect the user to the Cognito hosted UI sign-in page.
 *  - **Requirement 5.6** — A 401/403 from an authenticated API request MUST
 *    surface an error and prompt the user to re-authenticate via the Cognito
 *    hosted UI.
 *
 * The tests exercise the real exported symbols so they target the actual
 * implementation, not a re-implementation of it. The only mocked seam is the
 * global `fetch` (and `window.location`, observed for redirect URLs).
 */

import React from 'react';
import {
  describe,
  it,
  expect,
  beforeAll,
  beforeEach,
  afterEach,
  vi,
} from 'vitest';
import { render, screen, waitFor, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

import {
  loadConfig,
  __resetConfigForTests,
  type RuntimeConfigStatus,
} from '../../../src/frontend/src/api/config';
import {
  apiClient,
  ApiClientError,
  RuntimeConfigUnavailableError,
} from '../../../src/frontend/src/api/client';
import {
  subscribeToNotifications,
  type ApiNotification,
} from '../../../src/frontend/src/api/notifications';
import { RuntimeConfigError } from '../../../src/frontend/src/RuntimeConfigError';
import { AuthProvider } from '../../../src/frontend/src/auth/AuthContext';
import { ProtectedRoute } from '../../../src/frontend/src/auth/ProtectedRoute';

// ---------------------------------------------------------------------------
// Test fixtures and helpers
// ---------------------------------------------------------------------------

const VALID_CONFIG = {
  apiEndpoint: 'https://api.example.com/prod',
  cognitoUserPoolId: 'us-east-1_TEST123',
  cognitoClientId: 'web-client-id',
  cognitoDomain: 'test-domain.auth.us-east-1.amazoncognito.com',
  region: 'us-east-1',
  instanceMode: 'development',
} as const;

interface LocationMock {
  href: string;
  pathname: string;
  search: string;
  origin: string;
  reload: () => void;
}

let locationMock: LocationMock;

/**
 * Replace `window.location` with a plain object so we can observe the URL
 * `redirectToLogin()` writes via `window.location.href = ...` without
 * triggering jsdom's "navigation not implemented" behavior.
 */
function installLocationMock(): void {
  locationMock = {
    href: '',
    pathname: '/agents',
    search: '',
    origin: 'https://platform.example.com',
    reload: () => {
      /* noop */
    },
  };
  Object.defineProperty(window, 'location', {
    writable: true,
    configurable: true,
    value: locationMock,
  });
}

/** Build a minimal `Response`-shaped object that satisfies the loader's reads. */
function fakeResponse(init: {
  ok: boolean;
  status: number;
  statusText?: string;
  json?: () => Promise<unknown>;
}): Response {
  return {
    ok: init.ok,
    status: init.status,
    statusText: init.statusText ?? '',
    json: init.json ?? (async () => ({})),
  } as unknown as Response;
}

/**
 * Cloudscape components rely on browser observers that jsdom does not provide.
 * Stub the bare minimum so the `RuntimeConfigError` Alert renders cleanly.
 */
beforeAll(() => {
  const g = globalThis as unknown as {
    ResizeObserver?: unknown;
    IntersectionObserver?: unknown;
  };
  if (typeof g.ResizeObserver === 'undefined') {
    g.ResizeObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
    };
  }
  if (typeof g.IntersectionObserver === 'undefined') {
    g.IntersectionObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
      takeRecords(): unknown[] {
        return [];
      }
      readonly root = null;
      readonly rootMargin = '';
      readonly thresholds: ReadonlyArray<number> = [];
    };
  }
  if (typeof window.matchMedia !== 'function') {
    window.matchMedia = (query: string) =>
      ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => {},
        removeListener: () => {},
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => false,
      }) as MediaQueryList;
  }
});

beforeEach(() => {
  __resetConfigForTests();
  sessionStorage.clear();
  installLocationMock();
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

// ---------------------------------------------------------------------------
// Requirement 5.4 — runtime configuration unavailable
// ---------------------------------------------------------------------------

describe('Requirement 5.4: runtime configuration unavailable', () => {
  type Scenario = {
    label: string;
    arrange: () => void;
    expectedCode:
      | 'NETWORK_FAILURE'
      | 'UNSUCCESSFUL_RESPONSE'
      | 'MALFORMED_DOCUMENT';
  };

  const scenarios: Scenario[] = [
    {
      label: 'network failure',
      arrange: () => {
        vi.stubGlobal(
          'fetch',
          vi.fn().mockRejectedValueOnce(new TypeError('Failed to fetch')),
        );
      },
      expectedCode: 'NETWORK_FAILURE',
    },
    {
      label: 'non-OK HTTP response',
      arrange: () => {
        vi.stubGlobal(
          'fetch',
          vi.fn().mockResolvedValueOnce(
            fakeResponse({ ok: false, status: 503, statusText: 'Service Unavailable' }),
          ),
        );
      },
      expectedCode: 'UNSUCCESSFUL_RESPONSE',
    },
    {
      label: 'malformed JSON document',
      arrange: () => {
        vi.stubGlobal(
          'fetch',
          vi.fn().mockResolvedValueOnce(
            fakeResponse({
              ok: true,
              status: 200,
              statusText: 'OK',
              json: async () => {
                throw new SyntaxError('Unexpected token < in JSON at position 0');
              },
            }),
          ),
        );
      },
      expectedCode: 'MALFORMED_DOCUMENT',
    },
  ];

  it.each(scenarios)(
    'shows the error UI, keeps the user on the page, and suppresses API calls — $label',
    async ({ arrange, expectedCode }) => {
      arrange();

      const status = await loadConfig();
      expect(status.status).toBe('error');
      if (status.status !== 'error') throw new Error('expected error status');
      expect(status.error.code).toBe(expectedCode);

      // Render the visible "runtime configuration unavailable" error state.
      render(<RuntimeConfigError error={status.error} />);
      const alert = await screen.findByTestId('runtime-config-error');
      expect(alert).toBeInTheDocument();
      expect(alert).toHaveTextContent(/runtime configuration unavailable/i);

      // The user remains on the page — no redirect was triggered.
      expect(locationMock.href).toBe('');

      // API calls are suppressed: any apiClient request short-circuits with a
      // typed error before issuing fetch (Req 5.4 — never call against an
      // undefined apiEndpoint).
      const apiFetchSpy = vi.fn();
      vi.stubGlobal('fetch', apiFetchSpy);

      await expect(apiClient.get('/agents')).rejects.toBeInstanceOf(
        RuntimeConfigUnavailableError,
      );
      expect(apiFetchSpy).not.toHaveBeenCalled();
    },
  );
});

// ---------------------------------------------------------------------------
// Requirement 5.5 — unauthenticated load redirects to hosted UI
// ---------------------------------------------------------------------------

describe('Requirement 5.5: unauthenticated load redirects to hosted UI', () => {
  beforeEach(async () => {
    // Provide a valid runtime config so cognito.ts can build the login URL.
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValueOnce(
        fakeResponse({
          ok: true,
          status: 200,
          statusText: 'OK',
          json: async () => ({ ...VALID_CONFIG }),
        }),
      ),
    );
    const status: RuntimeConfigStatus = await loadConfig();
    expect(status.status).toBe('ready');
  });

  it('redirects to the Cognito hosted UI when no session is present', async () => {
    // Confirm the user is unauthenticated.
    expect(sessionStorage.getItem('catp_auth_tokens')).toBeNull();

    render(
      <AuthProvider>
        <ProtectedRoute>
          <div>protected content</div>
        </ProtectedRoute>
      </AuthProvider>,
    );

    await waitFor(() => {
      expect(locationMock.href).toMatch(
        /^https:\/\/test-domain\.auth\.us-east-1\.amazoncognito\.com\/login\?/,
      );
    });

    expect(locationMock.href).toContain(
      `client_id=${VALID_CONFIG.cognitoClientId}`,
    );
    expect(locationMock.href).toContain('response_type=code');
    expect(locationMock.href).toContain('scope=openid+email+profile');
    // The `state` param preserves the original path so the user lands back
    // here after sign-in.
    expect(locationMock.href).toContain('state=%2Fagents');

    // Protected children are NOT rendered while the user is being redirected.
    expect(screen.queryByText('protected content')).not.toBeInTheDocument();
  });
});

// ---------------------------------------------------------------------------
// Requirement 5.6 — 401/403 prompts re-authentication
// ---------------------------------------------------------------------------

describe('Requirement 5.6: 401/403 from API prompts re-authentication', () => {
  let notifications: ApiNotification[];
  let unsubscribe: (() => void) | undefined;

  beforeEach(async () => {
    notifications = [];
    unsubscribe = subscribeToNotifications((n) => {
      notifications.push(n);
    });

    // Load valid runtime config so apiClient can resolve the base URL.
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValueOnce(
        fakeResponse({
          ok: true,
          status: 200,
          statusText: 'OK',
          json: async () => ({ ...VALID_CONFIG }),
        }),
      ),
    );
    const status: RuntimeConfigStatus = await loadConfig();
    expect(status.status).toBe('ready');

    // Plant a non-expired Cognito token so getAccessToken() returns it and we
    // exercise the real 401/403 branch (not the missing-token short-circuit).
    sessionStorage.setItem(
      'catp_auth_tokens',
      JSON.stringify({
        idToken: 'id-token',
        accessToken: 'access-token',
        refreshToken: 'refresh-token',
        expiresAt: Date.now() + 60 * 60 * 1000,
      }),
    );
  });

  afterEach(() => {
    unsubscribe?.();
  });

  it.each([
    {
      httpStatus: 401,
      statusText: 'Unauthorized',
      reasonRegex: /session has expired/i,
    },
    {
      httpStatus: 403,
      statusText: 'Forbidden',
      reasonRegex: /not authorized/i,
    },
  ])(
    'surfaces an error and redirects to the hosted UI on HTTP $httpStatus',
    async ({ httpStatus, statusText, reasonRegex }) => {
      const apiFetchSpy = vi.fn().mockResolvedValueOnce(
        fakeResponse({
          ok: false,
          status: httpStatus,
          statusText,
          json: async () => ({ message: `${statusText} body` }),
        }),
      );
      vi.stubGlobal('fetch', apiFetchSpy);

      const error = await apiClient.get('/agents').catch((e) => e);
      expect(error).toBeInstanceOf(ApiClientError);
      expect((error as ApiClientError).status).toBe(httpStatus);

      // Exactly one upstream call was made — no retry on 401/403.
      expect(apiFetchSpy).toHaveBeenCalledTimes(1);

      // The user-visible error state was raised through the notification bus
      // with a message that prompts re-authentication.
      const notice = notifications.find((n) => reasonRegex.test(n.message));
      expect(notice, 'expected a re-auth notification to be dispatched').toBeDefined();
      expect(notice?.type).toBe('error');
      expect(notice?.message).toMatch(/sign in again/i);

      // The user is sent to the Cognito hosted UI for re-authentication.
      expect(locationMock.href).toMatch(
        /^https:\/\/test-domain\.auth\.us-east-1\.amazoncognito\.com\/login\?/,
      );
      expect(locationMock.href).toContain(
        `client_id=${VALID_CONFIG.cognitoClientId}`,
      );
    },
  );
});
