/**
 * backup-agent-state.ts — Snapshot all Q in Connect AI agents and AI prompts
 * for an assistant using the project's pinned @aws-sdk/client-qconnect, which
 * models the full `orchestrationAIAgentConfiguration` shape (the AWS CLI v2.27
 * collapses it to SDK_UNKNOWN_MEMBER and loses tool configs).
 *
 * Read-only: uses only List/Get APIs. Writes JSON snapshots under
 * backups/agent-state/<timestamp>/ so apply-recommendations / experiment
 * changes can be rolled back.
 *
 * Usage: ASSISTANT_ID=<uuid> npx tsx scripts/backup-agent-state.ts
 */
import * as fs from 'fs';
import * as path from 'path';
import {
  QConnectClient,
  ListAIAgentsCommand,
  GetAIAgentCommand,
  ListAIPromptsCommand,
  GetAIPromptCommand,
} from '@aws-sdk/client-qconnect';

const ASSISTANT_ID = process.env.ASSISTANT_ID;
if (!ASSISTANT_ID) {
  throw new Error('Set ASSISTANT_ID to the Q in Connect assistant UUID');
}
const REGION = process.env.AWS_REGION ?? 'us-east-1';

const client = new QConnectClient({ region: REGION });

function ts(): string {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

async function listAllAgents(): Promise<{ id: string; name: string; status?: string }[]> {
  const out: { id: string; name: string; status?: string }[] = [];
  let nextToken: string | undefined;
  do {
    const resp = await client.send(
      new ListAIAgentsCommand({ assistantId: ASSISTANT_ID, maxResults: 100, nextToken }),
    );
    for (const a of resp.aiAgentSummaries ?? []) {
      out.push({ id: a.aiAgentId!, name: a.name!, status: a.visibilityStatus });
    }
    nextToken = resp.nextToken;
  } while (nextToken);
  return out;
}

async function listAllPrompts(): Promise<{ id: string; name: string }[]> {
  const out: { id: string; name: string }[] = [];
  let nextToken: string | undefined;
  do {
    const resp = await client.send(
      new ListAIPromptsCommand({ assistantId: ASSISTANT_ID, maxResults: 100, nextToken }),
    );
    for (const p of resp.aiPromptSummaries ?? []) {
      out.push({ id: p.aiPromptId!, name: p.name! });
    }
    nextToken = resp.nextToken;
  } while (nextToken);
  return out;
}

async function main() {
  const outDir = path.join('backups', 'agent-state', ts());
  fs.mkdirSync(path.join(outDir, 'agents'), { recursive: true });
  fs.mkdirSync(path.join(outDir, 'prompts'), { recursive: true });
  console.log(`Backing up assistant ${ASSISTANT_ID} -> ${outDir}`);

  const agents = await listAllAgents();
  fs.writeFileSync(path.join(outDir, 'agents-manifest.json'), JSON.stringify(agents, null, 2));

  const agentResults: Record<string, string> = {};
  for (const a of agents) {
    try {
      const resp = await client.send(
        new GetAIAgentCommand({ assistantId: ASSISTANT_ID, aiAgentId: a.id }),
      );
      fs.writeFileSync(
        path.join(outDir, 'agents', `${a.id}.json`),
        JSON.stringify(resp.aiAgent, null, 2),
      );
      agentResults[a.id] = 'ok';
      console.log(`  agent ${a.name} (${a.id}) ok`);
    } catch (err) {
      agentResults[a.id] = `ERROR: ${(err as Error).message}`;
      console.log(`  agent ${a.name} (${a.id}) WARN: ${(err as Error).message}`);
    }
  }

  const prompts = await listAllPrompts();
  fs.writeFileSync(path.join(outDir, 'prompts-manifest.json'), JSON.stringify(prompts, null, 2));

  const promptResults: Record<string, string> = {};
  for (const p of prompts) {
    try {
      const resp = await client.send(
        new GetAIPromptCommand({ assistantId: ASSISTANT_ID, aiPromptId: p.id }),
      );
      fs.writeFileSync(
        path.join(outDir, 'prompts', `${p.id}.json`),
        JSON.stringify(resp.aiPrompt, null, 2),
      );
      promptResults[p.id] = 'ok';
      console.log(`  prompt ${p.name} (${p.id}) ok`);
    } catch (err) {
      promptResults[p.id] = `ERROR: ${(err as Error).message}`;
      console.log(`  prompt ${p.name} (${p.id}) WARN: ${(err as Error).message}`);
    }
  }

  fs.writeFileSync(
    path.join(outDir, 'backup-summary.json'),
    JSON.stringify(
      {
        assistantId: ASSISTANT_ID,
        region: REGION,
        capturedAt: new Date().toISOString(),
        agents: agentResults,
        prompts: promptResults,
      },
      null,
      2,
    ),
  );

  const agentOk = Object.values(agentResults).filter((v) => v === 'ok').length;
  const promptOk = Object.values(promptResults).filter((v) => v === 'ok').length;
  console.log(
    `Done. ${agentOk}/${agents.length} agents, ${promptOk}/${prompts.length} prompts captured.`,
  );
  console.log(`Backup at ${outDir}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
