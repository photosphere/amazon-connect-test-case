/**
 * Property-based tests for useImplementRecommendations state machine.
 *
 * Tests the pure state logic of the implement-recommendations orchestrator
 * hook by testing the reducer and transition map directly as pure functions.
 * This avoids React lifecycle complexities and isolates the state machine
 * correctness properties.
 *
 * Properties 1–8, 10 are covered here. Property 9 (banner resilience)
 * lives in a separate file alongside useExperimentBanner tests.
 *
 * @module frontend/hooks/__tests__/useImplementRecommendations.property
 */

import fc from 'fast-check';
import { describe, it, expect } from 'vitest';

import {
  VALID_TRANSITIONS,
  INITIAL_CONTEXT,
  reducer,
  type ImplementState,
  type ImplementContext,
  type ReducerState,
  type ReducerAction,
} from '../useImplementRecommendations';

// ---------------------------------------------------------------------------
// Generators
// ---------------------------------------------------------------------------

const ALL_STATES: ImplementState[] = [
  'idle',
  'loading_recommendations',
  'confirming',
  'applying',
  'conflict',
  'success',
  'experiment_starting',
  'experiment_polling',
  'experiment_completed',
  'experiment_failed',
  'error',
];

const stateArb: fc.Arbitrary<ImplementState> = fc.constantFrom(...ALL_STATES);

const nonEmptyIndicesArb: fc.Arbitrary<number[]> = fc
  .array(fc.nat({ max: 20 }), { minLength: 1, maxLength: 10 })
  .map((arr) => [...new Set(arr)]);

const agentIdArb: fc.Arbitrary<string> = fc
  .string({ minLength: 1, maxLength: 30 })
  .filter((s) => s.trim().length > 0);

const newVersionIdArb: fc.Arbitrary<string> = fc.uuid();

const driftedFieldArb = fc.record({
  targetField: fc.constantFrom(
    'tool_description' as const,
    'tool_instruction' as const,
    'tool_examples' as const,
    'system_prompt' as const,
  ),
  targetName: fc.string({ minLength: 1, maxLength: 20 }),
  expectedText: fc.string({ minLength: 1, maxLength: 50 }),
  actualText: fc.string({ minLength: 1, maxLength: 50 }),
});

const driftedFieldsArb = fc.array(driftedFieldArb, { minLength: 1, maxLength: 5 });

const variantArb: fc.Arbitrary<'A' | 'B' | 'C'> = fc.constantFrom('A', 'B', 'C');

const recommendationArb = fc.record({
  targetField: fc.constantFrom(
    'tool_description' as const,
    'tool_instruction' as const,
    'tool_examples' as const,
    'system_prompt' as const,
  ),
  targetName: fc.string({ minLength: 1, maxLength: 20 }),
  currentText: fc.string({ minLength: 0, maxLength: 50 }),
  suggestedText: fc.string({ minLength: 1, maxLength: 50 }),
  rationale: fc.string({ maxLength: 50 }),
});

const recommendationsArrayArb = fc.array(recommendationArb, { minLength: 1, maxLength: 5 });

const experimentIdArb: fc.Arbitrary<string> = fc.uuid();

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makePerSuiteRecommendation(index: number) {
  return {
    targetField: 'system_prompt' as const,
    targetName: 'system_prompt',
    currentText: `old-${index}`,
    suggestedText: `new-${index}`,
    rationale: `reason-${index}`,
    priority: index + 1,
    predictedImpact: { liftedCaseIds: [] as string[], rationale: '' },
  };
}

function makeState(state: ImplementState, contextOverrides?: Partial<ImplementContext>): ReducerState {
  return {
    state,
    context: { ...INITIAL_CONTEXT, ...contextOverrides },
  };
}

// ---------------------------------------------------------------------------
// Property 1: State transition validity
// Feature: implement-recommendations-frontend, Property 1: State transition validity
// ---------------------------------------------------------------------------

describe('Property 1: State transition validity', () => {
  it('the state machine accepts a transition iff the target appears in VALID_TRANSITIONS for the current state', () => {
    // **Validates: Requirements 7.3, 7.4**
    fc.assert(
      fc.property(stateArb, stateArb, (fromState, toState) => {
        const currentState = makeState(fromState);
        const action: ReducerAction = { type: 'TRANSITION', to: toState };
        const result = reducer(currentState, action);

        const shouldAccept = VALID_TRANSITIONS[fromState].includes(toState);

        if (shouldAccept) {
          // Transition accepted: state changes to the target
          expect(result.state).toBe(toState);
        } else {
          // Transition rejected: state remains unchanged
          expect(result.state).toBe(fromState);
          expect(result.context).toBe(currentState.context);
        }
      }),
      { numRuns: 200 },
    );
  });

  it('every state has a defined non-undefined array of valid targets', () => {
    // **Validates: Requirements 7.3, 7.4**
    fc.assert(
      fc.property(stateArb, (state) => {
        expect(VALID_TRANSITIONS[state]).toBeDefined();
        expect(Array.isArray(VALID_TRANSITIONS[state])).toBe(true);
        // Every target in the valid transitions array is a known state
        for (const target of VALID_TRANSITIONS[state]) {
          expect(ALL_STATES).toContain(target);
        }
      }),
      { numRuns: 100 },
    );
  });

  it('invalid transitions produce no side effects (state reference unchanged)', () => {
    // **Validates: Requirements 7.3, 7.4**
    fc.assert(
      fc.property(stateArb, stateArb, (fromState, toState) => {
        if (VALID_TRANSITIONS[fromState].includes(toState)) return; // skip valid transitions

        const currentState = makeState(fromState, {
          recommendations: [makePerSuiteRecommendation(0)],
          errorMessage: 'some error',
        });
        const action: ReducerAction = {
          type: 'TRANSITION',
          to: toState,
          context: { errorMessage: 'should not be applied' },
        };
        const result = reducer(currentState, action);

        // Exact same reference returned (no mutation)
        expect(result).toBe(currentState);
      }),
      { numRuns: 200 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 2: Direct apply payload correctness
// Feature: implement-recommendations-frontend, Property 2: Direct apply payload correctness
// ---------------------------------------------------------------------------

describe('Property 2: Direct apply payload correctness', () => {
  it('confirmApply from confirming state dispatches with mode "direct", exact indices, and exact agentId', () => {
    // **Validates: Requirements 1.2**
    //
    // The reducer's role in confirmApply: the hook calls confirmApply which
    // (1) checks selectedIndices is non-empty, then (2) dispatches TRANSITION
    // to 'applying'. The actual API call with the payload is in the hook's
    // async action, not the reducer. What the reducer guarantees is:
    //   - The transition confirming -> applying is valid and accepted
    //   - The context (selectedIndices, agentId) is preserved through the transition
    //
    // We test that the reducer preserves the indices and that the transition is accepted.
    fc.assert(
      fc.property(nonEmptyIndicesArb, agentIdArb, (indices, _agentId) => {
        const currentState = makeState('confirming', {
          selectedIndices: indices,
          recommendations: indices.map((_, i) => makePerSuiteRecommendation(i)),
        });

        // Transition to applying (simulates confirmApply dispatch)
        const action: ReducerAction = { type: 'TRANSITION', to: 'applying' };
        const result = reducer(currentState, action);

        // Transition is accepted
        expect(result.state).toBe('applying');
        // Indices are preserved through the transition
        expect(result.context.selectedIndices).toEqual(indices);
        // Recommendations are preserved
        expect(result.context.recommendations.length).toBe(indices.length);
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 3: Success transition populates newVersionId
// Feature: implement-recommendations-frontend, Property 3: Success transition populates newVersionId
// ---------------------------------------------------------------------------

describe('Property 3: Success transition populates newVersionId', () => {
  it('for any successful apply response with newVersionId, transitions to success with that value', () => {
    // **Validates: Requirements 1.3**
    fc.assert(
      fc.property(newVersionIdArb, (newVersionId) => {
        const currentState = makeState('applying', {
          recommendations: [makePerSuiteRecommendation(0)],
          selectedIndices: [0],
        });

        // Simulate the hook's success dispatch
        const action: ReducerAction = {
          type: 'TRANSITION',
          to: 'success',
          context: { newVersionId },
        };
        const result = reducer(currentState, action);

        expect(result.state).toBe('success');
        expect(result.context.newVersionId).toBe(newVersionId);
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 4: Conflict transition populates driftedFields
// Feature: implement-recommendations-frontend, Property 4: Conflict transition populates driftedFields
// ---------------------------------------------------------------------------

describe('Property 4: Conflict transition populates driftedFields', () => {
  it('for any 409 response with driftedFields, transitions to conflict with exactly those fields', () => {
    // **Validates: Requirements 1.4**
    fc.assert(
      fc.property(driftedFieldsArb, (driftedFields) => {
        const currentState = makeState('applying', {
          recommendations: [makePerSuiteRecommendation(0)],
          selectedIndices: [0],
        });

        // Simulate the hook's conflict dispatch
        const action: ReducerAction = {
          type: 'TRANSITION',
          to: 'conflict',
          context: { driftedFields: driftedFields as any },
        };
        const result = reducer(currentState, action);

        expect(result.state).toBe('conflict');
        expect(result.context.driftedFields).toEqual(driftedFields);
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 5: Error recovery preserves loaded data
// Feature: implement-recommendations-frontend, Property 5: Error recovery preserves loaded data
// ---------------------------------------------------------------------------

describe('Property 5: Error recovery preserves loaded data', () => {
  it('non-409 error preserves the recommendations array that was loaded', () => {
    // **Validates: Requirements 1.5, 8.2**
    fc.assert(
      fc.property(
        fc.integer({ min: 1, max: 10 }),
        fc.string({ minLength: 1, maxLength: 50 }),
        (recCount, errorMessage) => {
          const recommendations = Array.from({ length: recCount }, (_, i) =>
            makePerSuiteRecommendation(i),
          );

          const currentState = makeState('applying', {
            recommendations: recommendations as any,
            selectedIndices: recommendations.map((_, i) => i),
          });

          // Simulate error transition (non-409)
          const action: ReducerAction = {
            type: 'TRANSITION',
            to: 'error',
            context: { errorMessage },
          };
          const result = reducer(currentState, action);

          expect(result.state).toBe('error');
          // Recommendations array is preserved (not cleared)
          expect(result.context.recommendations).toEqual(recommendations);
          expect(result.context.recommendations.length).toBe(recCount);
          // Error message is set
          expect(result.context.errorMessage).toBe(errorMessage);
        },
      ),
      { numRuns: 100 },
    );
  });

  it('error from loading_recommendations preserves any previously loaded recommendations', () => {
    // **Validates: Requirements 1.5, 8.2**
    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 5 }),
        fc.string({ minLength: 1, maxLength: 50 }),
        (recCount, errorMessage) => {
          const recommendations = Array.from({ length: recCount }, (_, i) =>
            makePerSuiteRecommendation(i),
          );

          const currentState = makeState('loading_recommendations', {
            recommendations: recommendations as any,
          });

          const action: ReducerAction = {
            type: 'TRANSITION',
            to: 'error',
            context: { errorMessage },
          };
          const result = reducer(currentState, action);

          expect(result.state).toBe('error');
          expect(result.context.recommendations).toEqual(recommendations);
        },
      ),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 6: Force apply includes force flag
// Feature: implement-recommendations-frontend, Property 6: Force apply includes force flag
// ---------------------------------------------------------------------------

describe('Property 6: Force apply includes force flag', () => {
  it('from conflict state, forceApply transitions to applying preserving indices for the force call', () => {
    // **Validates: Requirements 2.1**
    //
    // The reducer's role: accept conflict -> applying transition and preserve
    // the selectedIndices so the hook's forceApply can pass them with force: true.
    // The hook logic passes force: true to the API; the reducer preserves the data.
    fc.assert(
      fc.property(nonEmptyIndicesArb, driftedFieldsArb, (indices, driftedFields) => {
        const currentState = makeState('conflict', {
          selectedIndices: indices,
          driftedFields: driftedFields as any,
          recommendations: indices.map((_, i) => makePerSuiteRecommendation(i)),
        });

        // forceApply dispatches TRANSITION to 'applying'
        const action: ReducerAction = { type: 'TRANSITION', to: 'applying' };
        const result = reducer(currentState, action);

        // Transition accepted
        expect(result.state).toBe('applying');
        // selectedIndices preserved for the force-apply API call
        expect(result.context.selectedIndices).toEqual(indices);
        // recommendations preserved
        expect(result.context.recommendations.length).toBe(indices.length);
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 7: Dismiss clears transient context
// Feature: implement-recommendations-frontend, Property 7: Dismiss clears transient context
// ---------------------------------------------------------------------------

describe('Property 7: Dismiss clears transient context', () => {
  it('from any dismissable state, cancel/dismiss resets all transient context fields to initial values', () => {
    // **Validates: Requirements 7.5**
    //
    // Dismissable states: conflict, success, error, experiment_failed, confirming
    // All of these have 'idle' in their valid transitions.
    const dismissableStates: ImplementState[] = [
      'conflict',
      'success',
      'error',
      'experiment_failed',
      'confirming',
    ];

    fc.assert(
      fc.property(
        fc.constantFrom(...dismissableStates),
        driftedFieldsArb,
        newVersionIdArb,
        experimentIdArb,
        (fromState, driftedFields, newVersionId, experimentId) => {
          // Start with a state that has transient data populated
          const currentState = makeState(fromState, {
            recommendations: [makePerSuiteRecommendation(0)] as any,
            driftedFields: driftedFields as any,
            experimentId,
            experimentStatus: 'running',
            newVersionId,
            errorMessage: 'some error',
            applyingVariant: 'A',
            variantRecommendations: [{ targetField: 'system_prompt', targetName: 'x', currentText: 'a', suggestedText: 'b', rationale: 'c' }] as any,
          });

          // cancelDialog dispatches TRANSITION to 'idle' with INITIAL_CONTEXT
          const action: ReducerAction = {
            type: 'TRANSITION',
            to: 'idle',
            context: INITIAL_CONTEXT,
          };
          const result = reducer(currentState, action);

          expect(result.state).toBe('idle');
          // All transient fields reset to initial values
          expect(result.context.recommendations).toEqual(INITIAL_CONTEXT.recommendations);
          expect(result.context.driftedFields).toEqual(INITIAL_CONTEXT.driftedFields);
          expect(result.context.experimentId).toEqual(INITIAL_CONTEXT.experimentId);
          expect(result.context.experimentStatus).toEqual(INITIAL_CONTEXT.experimentStatus);
          expect(result.context.newVersionId).toEqual(INITIAL_CONTEXT.newVersionId);
          expect(result.context.errorMessage).toEqual(INITIAL_CONTEXT.errorMessage);
          expect(result.context.applyingVariant).toEqual(INITIAL_CONTEXT.applyingVariant);
          expect(result.context.variantRecommendations).toEqual(INITIAL_CONTEXT.variantRecommendations);
        },
      ),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 8: Experiment creation transitions to polling
// Feature: implement-recommendations-frontend, Property 8: Experiment creation transitions to polling
// ---------------------------------------------------------------------------

describe('Property 8: Experiment creation transitions to polling', () => {
  it('successful createExperiment transitions from experiment_starting to experiment_polling with experimentId', () => {
    // **Validates: Requirements 4.1**
    fc.assert(
      fc.property(experimentIdArb, (experimentId) => {
        const currentState = makeState('experiment_starting');

        // Simulate the hook's success dispatch after createExperiment resolves
        const action: ReducerAction = {
          type: 'TRANSITION',
          to: 'experiment_polling',
          context: {
            experimentId,
            experimentStatus: 'generating_variants',
            pollingStartedAt: Date.now(),
          },
        };
        const result = reducer(currentState, action);

        expect(result.state).toBe('experiment_polling');
        expect(result.context.experimentId).toBe(experimentId);
        expect(result.context.experimentStatus).toBe('generating_variants');
        expect(result.context.pollingStartedAt).not.toBeNull();
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 10: Variant apply populates correct recommendations
// Feature: implement-recommendations-frontend, Property 10: Variant apply populates correct recommendations
// ---------------------------------------------------------------------------

describe('Property 10: Variant apply populates correct recommendations', () => {
  it('applyVariant sets variantRecommendations and applyingVariant correctly', () => {
    // **Validates: Requirements 6.1, 6.2**
    //
    // The hook's applyVariant action:
    //   1. Dispatches TRANSITION to 'loading_recommendations' with variant context
    //   2. Immediately dispatches TRANSITION to 'confirming' with full variant data
    // We test both transitions sequentially to verify the final state.
    fc.assert(
      fc.property(variantArb, recommendationsArrayArb, (variant, recommendations) => {
        const currentState = makeState('idle');

        // Step 1: idle -> loading_recommendations with variant context
        const action1: ReducerAction = {
          type: 'TRANSITION',
          to: 'loading_recommendations',
          context: {
            applyingVariant: variant,
            variantRecommendations: recommendations as any,
          },
        };
        const intermediateState = reducer(currentState, action1);

        expect(intermediateState.state).toBe('loading_recommendations');
        expect(intermediateState.context.applyingVariant).toBe(variant);
        expect(intermediateState.context.variantRecommendations).toEqual(recommendations);

        // Step 2: loading_recommendations -> confirming with full variant data
        const action2: ReducerAction = {
          type: 'TRANSITION',
          to: 'confirming',
          context: {
            applyingVariant: variant,
            variantRecommendations: recommendations as any,
            selectedIndices: recommendations.map((_, i) => i),
          },
        };
        const finalState = reducer(intermediateState, action2);

        expect(finalState.state).toBe('confirming');
        expect(finalState.context.applyingVariant).toBe(variant);
        expect(finalState.context.variantRecommendations).toEqual(recommendations);
        expect(finalState.context.selectedIndices).toEqual(
          recommendations.map((_, i) => i),
        );
      }),
      { numRuns: 100 },
    );
  });
});
