# Design Document: RAG Test Cases

## Overview

This feature extends the Connect Agent Test Platform with a second test case type — `rag` — alongside the existing `tool_sequence` type. A RAG case carries a `question` and a `groundTruthAnswer`; at runtime the platform sends the question in a single-turn conversation, captures the agent's response and retrieved chunks from ListSpans, packages everything into Amazon Bedrock RAG Evaluation's BYOI (bring-your-own-inference-responses) JSONL format, submits a batched evaluation job, and persists per-metric scores (Faithfulness, Correctness, Completeness, Helpfulness) back to each case result.

The design introduces a Two-Stage pipeline extension to the existing Step Functions state machine: Stage 1 drives all cases (both types) through the Conversation_Driver; Stage 2 conditionally submits the Bedrock RAG Evaluation batch job for runs containing RAG cases. An opportunistic Faithfulness check on tool-sequence cases that happen to invoke the Retrieve tool runs inline via Bedrock Converse during Stage 1 — fast, best-effort, no batch job dependency.

### Design Rationale Summary

- **Why Bedrock RAG Evaluation (batch) for RAG cases**: The official service scores four metrics with a calibrated judge model and produces per-prompt explanations. Rolling our own judge prompt for all four metrics would be fragile and diverge from the Bedrock-documented rubric. The batch job adds ~2–5 min latency per run but is acceptable because RAG evaluation is not on the interactive path.
- **Why inline Converse for the opportunistic Faithfulness check on tool-sequence cases**: These cases already have a tight ~3–5s budget per case in Stage 1. A single Converse call with a focused Faithfulness prompt fits in that window. Routing them through the batch job would delay all tool-sequence results by the batch job latency.
- **Why a new S3 bucket (RAG_Job_Bucket)**: Bedrock RAG Evaluation reads input from S3 and writes output to S3. A dedicated bucket scopes IAM to the minimum necessary and avoids mixing evaluation artifacts with any future user-uploaded data.
- **Why the line-index → caseId mapping on the run record**: Bedrock returns per-prompt results indexed by position in the JSONL file, not by any user-supplied ID. The mapping is the join key that connects output rows back to platform case IDs.

## Architecture

```mermaid
graph TB
    subgraph Frontend["Frontend (React + Cloudscape)"]
        SF[Suite Detail<br/>Test Type Dropdown]
        CD[Case Detail<br/>RAG Render Surface]
        SE[Suite Edit<br/>RAG Thresholds]
    end

    subgraph StepFunctions["Step Functions State Machine"]
        PR[PrepareRun]
        S1[Stage 1: ExecuteCases<br/>Map — ConvDriver → Record → Write]
        CHK{Has RAG cases<br/>that survived?}
        S2[Stage 2: RAG_Evaluate<br/>Build JSONL → CreateEvalJob → Poll → Read Results]
        EV[EvaluateResults<br/>tool-sequence scoring]
        WR[WriteResults]
    end

    subgraph Backend["Backend Lambdas"]
        ConvD[Conversation Driver<br/>single-turn RAG mode]
        ChunkEx[Chunk Extractor<br/>from ListSpans]
        OpFaith[Opportunistic Faithfulness<br/>inline Converse]
        JSONL[JSONL Serializer<br/>BYOI format]
        RAGEval[RAG Evaluate Lambda<br/>CreateEvalJob + Poll + Read]
        Decision[Pass/Fail Decision<br/>threshold logic]
    end

    subgraph AWS["AWS Services"]
        QiC[Q in Connect<br/>CreateSession/SendMessage/ListSpans]
        BRE[Bedrock RAG Evaluation<br/>CreateEvaluationJob]
        BRC[Bedrock Converse<br/>Faithfulness judge]
        S3[RAG_Job_Bucket<br/>input.jsonl / output/]
    end

    subgraph Storage["DynamoDB"]
        Cases[("PK=SUITE#id SK=CASE#id<br/>type: rag | tool_sequence")]
        Results[("PK=RUN#id SK=CASE#id<br/>ragMetrics, retrievedChunks")]
        RagJob[("PK=RUN#id SK=RAGJOB<br/>jobArn, mapping, status")]
    end

    SF --> Cases
    PR --> S1
    S1 --> ConvD
    ConvD --> QiC
    ConvD --> ChunkEx
    ChunkEx --> OpFaith
    OpFaith --> BRC
    S1 --> CHK
    CHK -- yes --> S2
    CHK -- no --> EV
    S2 --> JSONL
    JSONL --> S3
    S2 --> RAGEval
    RAGEval --> BRE
    BRE --> S3
    RAGEval --> Decision
    Decision --> Results
    S2 --> WR
    EV --> WR
    RagJob --> RAGEval
    CD --> Results
    SE --> Cases
```

## Reuse Map

| Module | Change Scope |
|--------|-------------|
| `src/shared/types.ts` | Add `type` discriminator to `TestCase`. Add `RagTestCase` type. Extend `TestCaseResult` with `caseType`, `ragMetrics`, `retrievedChunks`. Extend `TestSuite` with `ragThresholds`. Extend `EvaluationErrorCode` union. Add `RetrievedChunk` interface. |
| `src/shared/enums.ts` | No changes — `CaseStatus` already has `passed`, `failed`, `error`. |
| `src/shared/constants.ts` | Add `RAG_QUESTION_MAX`, `RAG_GROUND_TRUTH_MAX`, `RAG_JOB_POLL_INTERVAL_MS`, `RAG_JOB_TIMEOUT_MS`. |
| `src/backend/orchestration/conversation-driver.ts` | Add single-turn RAG mode branch: skip Customer_Simulator, single SendMessage, single poll, ListSpans, chunk extraction. |
| `src/backend/orchestration/span-parser.ts` | No changes — reuse `parseSpansToTrace`. New `extractRetrievedChunks` function added as a sibling module. |
| `src/backend/orchestration/chunk-extractor.ts` **(NEW)** | Pure function: `ListSpans execute_tool spans → RetrievedChunk[]`. |
| `src/backend/orchestration/evaluation.ts` | No changes for RAG — RAG scoring goes through the batch job path. |
| `src/backend/orchestration/opportunistic-faithfulness.ts` **(NEW)** | Inline Converse-based Faithfulness evaluator for tool-sequence cases with retrieved chunks. |
| `src/backend/orchestration/rag-evaluate.ts` **(NEW)** | Stage 2 handler: build JSONL, CreateEvaluationJob, poll, read results, apply thresholds. |
| `src/backend/orchestration/jsonl-serializer.ts` **(NEW)** | Pure function: RAG case data → BYOI JSONL line. |
| `src/backend/orchestration/rag-decision.ts` **(NEW)** | Pure function: four scores + four thresholds → `"passed"` \| `"failed"`. |
| `src/backend/orchestration/state-machine.ts` | Extend definition: add conditional Stage 2 branch after Map. |
| `src/backend/handlers/cases.ts` | Add type-discriminator validation. Conditional field requirements per type. Content tag filter validation (R13). |
| `lib/orchestration-construct.ts` | Add RAG_Evaluate Lambda, S3 bucket, Bedrock RAG Evaluation IAM grants. |
| `lib/api-construct.ts` | Wire RAG-related Lambda permissions if needed. |
| `src/frontend/src/pages/SuiteDetail.tsx` | Add Test Type dropdown to case editor modal. Conditional form fields. Type badge column. RAG thresholds editor on suite form. |
| `src/frontend/src/pages/CaseDetail.tsx` | Add RAG render surface: Question, Agent's Answer, Ground Truth, Metrics, Retrieved Chunks. Conditional on `caseType === "rag"`. Opportunistic Faithfulness row for tool-sequence cases. |

## Components and Interfaces

### Backend — New Modules

#### `src/backend/orchestration/chunk-extractor.ts`

```typescript
import type { RawSpan } from "./span-parser";

export interface RetrievedChunk {
  text: string;
  knowledgeBaseId?: string;
  contentId?: string;
  title?: string;
  index: number;
}

/**
 * Extracts retrieved chunks from ListSpans execute_tool spans.
 * 
 * Algorithm:
 * 1. Filter spans to execute_tool spans whose tool name matches retrieveToolName
 * 2. For each matching span, iterate toolResult.values[]
 * 3. For each value, extract text.value as the chunk text
 * 4. Extract citation fields (knowledgeBaseId, contentId, title) from SpanCitation
 * 5. Return ordered RetrievedChunk[] preserving span order and value order within spans
 */
export function extractRetrievedChunks(
  rawSpans: RawSpan[],
  retrieveToolName: string,
): RetrievedChunk[];
```

#### `src/backend/orchestration/jsonl-serializer.ts`

```typescript
export interface RagCaseInput {
  question: string;
  groundTruthAnswer: string;
  agentResponse: string;
  retrievedChunks: RetrievedChunk[];
  knowledgeBaseId: string | undefined;
  modelIdentifier: string;
}

/**
 * Serializes a single RAG case into a BYOI retrieve-and-generate JSONL line.
 * Returns a single-line valid JSON string (no trailing newline).
 */
export function serializeRagCaseToJsonl(input: RagCaseInput): string;

/**
 * Assembles multiple JSONL lines into a complete file body.
 * Returns the joined string with \n separators, no leading/trailing blank lines.
 * Also returns the line-index → caseId mapping.
 */
export function assembleJsonlFile(
  cases: Array<{ caseId: string; line: string }>,
): { body: string; indexMap: Record<number, string> };
```

#### `src/backend/orchestration/rag-decision.ts`

```typescript
export interface RagMetrics {
  faithfulness: number;
  correctness: number;
  completeness: number;
  helpfulness: number;
}

export interface RagThresholds {
  faithfulness: number;
  correctness: number;
  completeness: number;
  helpfulness: number;
}

export const DEFAULT_RAG_THRESHOLDS: RagThresholds = {
  faithfulness: 0.7,
  correctness: 0.7,
  completeness: 0.7,
  helpfulness: 0.7,
};

/**
 * Pure, total decision function.
 * 
 * Rules (R6.3):
 * 1. If faithfulness < threshold.faithfulness → "failed" (hard gate)
 * 2. If correctness >= threshold AND completeness >= threshold AND helpfulness >= threshold → "passed"
 * 3. Otherwise → "failed"
 */
export function computeRagCaseStatus(
  metrics: RagMetrics,
  thresholds: RagThresholds,
): "passed" | "failed";
```

#### `src/backend/orchestration/opportunistic-faithfulness.ts`

```typescript
/**
 * Inline Converse-based Faithfulness evaluator for tool-sequence cases.
 * 
 * Uses the same judge model, retry posture, and temperature=0 as analysis.ts.
 * Sends a structured prompt with the agent's response and retrieved chunks,
 * instructs the judge to score groundedness on [0,1].
 * 
 * Returns undefined on failure (best-effort, never throws).
 */
export async function evaluateOpportunisticFaithfulness(
  agentResponse: string,
  chunks: RetrievedChunk[],
  judgeModelId: string,
): Promise<number | undefined>;
```

#### `src/backend/orchestration/rag-evaluate.ts`

```typescript
/**
 * Stage 2 handler — Lambda invoked by Step Functions after Stage 1 completes.
 * 
 * Input: { runId, suiteId, ragCases: Array<{caseId, question, groundTruthAnswer, agentResponse, retrievedChunks}>, agentSnapshot, ragThresholds }
 * 
 * Steps:
 * 1. Serialize each case to JSONL line
 * 2. Upload to s3://{RAG_Job_Bucket}/{runId}/input.jsonl
 * 3. Call bedrock:CreateEvaluationJob with BYOI dataset
 * 4. Poll bedrock:GetEvaluationJob every 30s, hard cap 30 min
 * 5. On COMPLETED: read per-prompt output from S3, join by index, write ragMetrics to DDB
 * 6. On FAILED/STOPPED/timeout: write error codes to each case
 * 7. Apply thresholds via computeRagCaseStatus, set case.status
 * 8. Persist RAGJOB record for observability
 */
export async function handler(event: RagEvaluateInput): Promise<RagEvaluateOutput>;
```

### Backend — Type Extensions

#### Extended `TestCase` (discriminated union)

```typescript
// Base fields shared by both types
interface TestCaseBase {
  suiteId: string;
  caseId: string;
  name: string;
  description: string;
  type: "tool_sequence" | "rag";
}

// Tool-sequence shape (existing fields, unchanged)
interface ToolSequenceTestCase extends TestCaseBase {
  type: "tool_sequence";
  goalDescription?: string;
  persona: string;
  style: CommunicationStyle;
  customerKnowledge: Record<string, string>;
  initialUtterance: string;
  successCriteria: ToolStep[];
  sessionData?: Record<string, string>;
  primingMessage?: string;
}

// RAG shape (new)
interface RagTestCase extends TestCaseBase {
  type: "rag";
  question: string;           // 1..1000 chars, trimmed-non-empty
  groundTruthAnswer: string;  // 1..4000 chars, trimmed-non-empty
  sessionData?: Record<string, string>; // optional, max 20 pairs
}

export type TestCase = ToolSequenceTestCase | RagTestCase;
```

#### Extended `TestCaseResult`

```typescript
// Added fields:
interface TestCaseResult {
  // ... existing fields ...
  caseType?: "tool_sequence" | "rag";
  ragMetrics?: {
    faithfulness?: number;
    correctness?: number;
    completeness?: number;
    helpfulness?: number;
  };
  retrievedChunks?: RetrievedChunk[];
}
```

#### Extended `TestSuite`

```typescript
interface TestSuite {
  // ... existing fields ...
  ragThresholds?: RagThresholds;
}
```

#### Extended `EvaluationErrorCode`

```typescript
code:
  | "INSUFFICIENT_TRACE"
  | "TIMEOUT"
  | "JUDGE_ERROR"
  | "UNMAPPABLE_RESULT"
  | "MISSING_EVALUATOR"
  | "RAG_JOB_FAILED"      // NEW
  | "RAG_JOB_TIMEOUT"     // NEW
  | "INSUFFICIENT_RAG_DATA" // NEW
  | "MALFORMED_RESULT";   // NEW
```

### CDK Infrastructure

#### New Resources in `orchestration-construct.ts`

```typescript
// RAG_Job_Bucket — stores input JSONL and output metric reports
const ragJobBucket = new s3.Bucket(this, "RagJobBucket", {
  bucketName: `${stack.stackName.toLowerCase()}-rag-eval`,
  encryption: s3.BucketEncryption.S3_MANAGED,
  blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
  removalPolicy: cdk.RemovalPolicy.RETAIN,
  lifecycleRules: [{ expiration: cdk.Duration.days(90) }],
});

// RAG Evaluate Lambda
const ragEvaluateFn = new NodejsFunction(this, "RagEvaluateFn", {
  entry: "src/backend/orchestration/rag-evaluate.ts",
  handler: "handler",
  timeout: cdk.Duration.minutes(15), // accounts for 30-min poll with Step Functions task token
  memorySize: 1024,
  environment: {
    ...commonEnv,
    RAG_JOB_BUCKET: ragJobBucket.bucketName,
    JUDGE_MODEL_ID: judgeModelId,
  },
});

// IAM: S3 read/write for JSONL and output
ragJobBucket.grantReadWrite(ragEvaluateFn);

// IAM: Bedrock RAG Evaluation APIs
ragEvaluateFn.addToRolePolicy(new iam.PolicyStatement({
  sid: "BedrockRagEvaluation",
  effect: iam.Effect.ALLOW,
  actions: [
    "bedrock:CreateEvaluationJob",
    "bedrock:GetEvaluationJob",
    "bedrock:StopEvaluationJob",
  ],
  resources: ["*"], // eval jobs are account-scoped, no resource ARN available
}));

// IAM: Bedrock Converse for opportunistic Faithfulness (on ConversationDriver)
// Already granted via existing BedrockConverse policy statement
```

### Frontend Components

#### Test Type Dropdown (SuiteDetail.tsx — TestCaseEditorModal)

```
┌─────────────────────────────────────────┐
│ Test Type: [Tool Use ▼]                 │  ← First field, default "Tool Use"
├─────────────────────────────────────────┤
│ Name: [________________]                │
│ Description: [_________________________]│
│ (remaining fields conditional on type)  │
│                                         │
│ IF "Tool Use": existing fields          │
│ IF "RAG":                               │
│   Question: [__________________________]│  ← max 1000
│   Ground Truth Answer: [_______________]│  ← max 4000
│   ▶ Session Data (optional, collapsible)│
└─────────────────────────────────────────┘
```

#### RAG Case Detail Page (CaseDetail.tsx)

```
┌─────────────────────────────────────────┐
│ [Failed Faithfulness gate] badge (R6.4) │  ← conditional
├─────────────────────────────────────────┤
│ Question                                │
│ ┌─────────────────────────────────────┐ │
│ │ (case.question, verbatim)           │ │
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│ Agent's Answer                          │
│ ┌─────────────────────────────────────┐ │
│ │ (agentResponse, verbatim)           │ │
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│ Ground Truth                            │
│ ┌─────────────────────────────────────┐ │
│ │ (case.groundTruthAnswer, verbatim)  │ │
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│ Metrics                                 │
│ ┌────────────────┬───────┬──────┬────┐  │
│ │ Metric         │ Score │Thresh│P/F │  │
│ ├────────────────┼───────┼──────┼────┤  │
│ │ Faithfulness   │ 0.850 │ 0.70 │ ✓  │  │
│ │ Correctness    │ 0.920 │ 0.70 │ ✓  │  │
│ │ Completeness   │ 0.610 │ 0.70 │ ✗  │  │
│ │ Helpfulness    │ 0.780 │ 0.70 │ ✓  │  │
│ └────────────────┴───────┴──────┴────┘  │
├─────────────────────────────────────────┤
│ ▶ Retrieved Chunks (collapsible)        │
│   Chunk 1: [preformatted text...]       │
│     title: "FAQ page", kbId: "kb-123"   │
│   Chunk 2: [preformatted text...]       │
│   (or: "No chunks were retrieved...")   │
└─────────────────────────────────────────┘
```

## Data Models

### DynamoDB Records

#### TestCase Record (extended)

```
PK: SUITE#{suiteId}
SK: CASE#{caseId}
type: "rag" | "tool_sequence"   ← NEW (absent on legacy = "tool_sequence")
// For type="rag":
question: string
groundTruthAnswer: string
sessionData?: Record<string,string>
// For type="tool_sequence": existing fields unchanged
```

#### TestCaseResult Record (extended)

```
PK: RUN#{runId}
SK: CASE#{caseId}
caseType: "rag" | "tool_sequence"   ← NEW
ragMetrics?: {                       ← NEW (RAG cases after Stage 2, or tool-sequence with opportunistic)
  faithfulness?: number
  correctness?: number
  completeness?: number
  helpfulness?: number
}
retrievedChunks?: RetrievedChunk[]   ← NEW
// existing fields preserved
```

#### RAGJOB Record (new)

```
PK: RUN#{runId}
SK: RAGJOB
jobArn: string
judgeModelId: string
inputS3Uri: string
outputS3Uri: string
submittedCaseCount: number
indexMap: Record<number, string>   ← line-index → caseId
status: "IN_PROGRESS" | "COMPLETED" | "FAILED" | "STOPPED" | "TIMEOUT"
startedAt: string (ISO 8601)
completedAt?: string (ISO 8601)
```

#### TestSuite Record (extended)

```
PK: TENANT#{tenantId}
SK: SUITE#{suiteId}
ragThresholds?: {                 ← NEW (absent = defaults)
  faithfulness: number
  correctness: number
  completeness: number
  helpfulness: number
}
// existing fields preserved
```

### S3 Objects (RAG_Job_Bucket)

```
s3://{bucket}/{runId}/input.jsonl          ← BYOI dataset
s3://{bucket}/{runId}/output/              ← Bedrock writes per-prompt + summary here
```

### BYOI JSONL Schema (per line)

```json
{
  "conversationTurns": [{
    "prompt": {
      "content": [{ "text": "<question>" }]
    },
    "referenceResponses": [{
      "content": [{ "text": "<groundTruthAnswer>" }]
    }],
    "output": {
      "text": "<agentResponse>",
      "knowledgeBaseIdentifier": "<kbId or sentinel>",
      "modelIdentifier": "<modelId from AgentSnapshot>",
      "retrievedPassages": {
        "retrievalResults": [
          {
            "content": { "text": "<chunk text>" },
            "name": "<chunk title, optional>",
            "metadata": { "contentId": "...", "knowledgeBaseId": "..." }
          }
        ]
      }
    }
  }]
}
```

## Two-Stage Pipeline Flow

### Step Functions Extension

The state machine gains a conditional branch after the existing Map state:

```mermaid
graph LR
    PR[PrepareRun] --> MAP[ParallelTestCases<br/>Map maxConcurrency=9]
    MAP --> CHOICE{Run has<br/>surviving RAG cases?}
    CHOICE -- yes --> S2[RAG_Evaluate Lambda]
    CHOICE -- no --> EVAL[EvaluateResults<br/>tool-sequence scoring]
    S2 --> WR[WriteResults]
    EVAL --> WR
```

**PrepareRun** is extended to detect whether the suite contains RAG cases and pass a `hasRagCases: boolean` flag.

**Choice state** uses `$.hasRagCases` combined with a count of surviving RAG cases from the Map output.

**Stage 2 (RAG_Evaluate)** receives the runId, filters to RAG cases with captured responses, builds the JSONL, submits the job, polls, reads results, applies thresholds, and writes back to DDB.

**EvaluateResults** (existing) continues to score tool-sequence cases with the Bedrock judge. It now skips cases where `caseType === "rag"`.

### Stage 1 Per-Case Flow (RAG mode)

```
1. CreateSession (suite's assistant, bound to minted contact)
2. IF case.sessionData → UpdateSessionData
3. SendMessage(question) — single message, no simulator
4. PollForResponse — capture agent's terminal text
5. ListSpans → extractRetrievedChunks(spans, retrieveToolName)
6. IF suite has ragThresholds AND chunks.length > 0 AND case.type === "tool_sequence":
     → evaluateOpportunisticFaithfulness(agentResponse, chunks) [inline, ~3-5s]
7. Persist: transcript, retrievedChunks, (opportunistic ragMetrics if applicable)
8. StopContact (cleanup)
```

## Opportunistic Faithfulness Evaluator (Inline Converse)

### Judge Prompt

```
You are an expert evaluator assessing whether an AI assistant's response is grounded in the provided reference passages.

## Retrieved Passages
{chunks formatted as numbered list}

## Assistant's Response
{agentResponse}

## Task
Score the faithfulness of the assistant's response on a scale from 0.0 to 1.0, where:
- 1.0 = every claim in the response is directly supported by the retrieved passages
- 0.0 = no claims in the response are supported by the retrieved passages

Respond with ONLY a JSON object: {"score": <number between 0.0 and 1.0>}
```

### Configuration

- Model: Same `JUDGE_MODEL_ID` as evaluation.ts (default `us.anthropic.claude-sonnet-4-6`)
- Temperature: 0
- Max tokens: 50
- Retry: `baseMs: 1000, capMs: 10000, maxRetries: 2` on ThrottlingException
- Timeout: 15s per call
- Failure mode: return `undefined`, log warning, do not block case

## Chunk Extraction Algorithm

```typescript
function extractRetrievedChunks(rawSpans: RawSpan[], retrieveToolName: string): RetrievedChunk[] {
  const chunks: RetrievedChunk[] = [];
  let globalIndex = 0;

  // Sort spans chronologically
  const sorted = rawSpans.slice().sort((a, b) =>
    (a.startTimestamp ?? "").localeCompare(b.startTimestamp ?? "")
  );

  for (const span of sorted) {
    if (span.spanName !== "execute_tool") continue;

    // Check if this span's tool name matches the Retrieve tool
    const toolName = extractToolNameFromSpan(span);
    if (toolName !== retrieveToolName) continue;

    // Iterate output messages → toolResult.values[]
    for (const msg of span.attributes?.outputMessages ?? []) {
      for (const value of msg.values ?? []) {
        if (!value.toolResult?.values) continue;
        for (const tv of value.toolResult.values) {
          const text = tv.text?.value;
          if (text === undefined) continue;

          // Extract citation fields from SpanCitation objects on this span
          const citation = extractCitationForChunk(span, globalIndex);

          chunks.push({
            text,
            knowledgeBaseId: citation?.knowledgeBaseId,
            contentId: citation?.contentId,
            title: citation?.title,
            index: globalIndex,
          });
          globalIndex++;
        }
      }
    }
  }

  return chunks;
}
```

## BYOI JSONL Serialization

```typescript
function serializeRagCaseToJsonl(input: RagCaseInput): string {
  const knowledgeBaseId = input.knowledgeBaseId
    ?? (input.retrievedChunks.find(c => c.knowledgeBaseId)?.knowledgeBaseId)
    ?? "connect-orchestration-retrieve";

  const line = {
    conversationTurns: [{
      prompt: { content: [{ text: input.question }] },
      referenceResponses: [{ content: [{ text: input.groundTruthAnswer }] }],
      output: {
        text: input.agentResponse,
        knowledgeBaseIdentifier: knowledgeBaseId,
        modelIdentifier: input.modelIdentifier,
        retrievedPassages: {
          retrievalResults: input.retrievedChunks.map(chunk => ({
            content: { text: chunk.text },
            ...(chunk.title ? { name: chunk.title } : {}),
            ...(chunk.contentId || chunk.knowledgeBaseId ? {
              metadata: {
                ...(chunk.contentId ? { contentId: chunk.contentId } : {}),
                ...(chunk.knowledgeBaseId ? { knowledgeBaseId: chunk.knowledgeBaseId } : {}),
              }
            } : {}),
          })),
        },
      },
    }],
  };

  return JSON.stringify(line);
}
```

## Pass/Fail Decision Logic

```typescript
function computeRagCaseStatus(
  metrics: RagMetrics,
  thresholds: RagThresholds,
): "passed" | "failed" {
  // Rule 1: Faithfulness hard gate (dominant)
  if (metrics.faithfulness < thresholds.faithfulness) {
    return "failed";
  }
  // Rule 2: AND semantics — all remaining thresholds must be met
  if (
    metrics.correctness >= thresholds.correctness &&
    metrics.completeness >= thresholds.completeness &&
    metrics.helpfulness >= thresholds.helpfulness
  ) {
    return "passed";
  }
  // Rule 3: At least one non-faithfulness threshold not met
  return "failed";
}
```

## Content Tag Filter Validation Logic

At case save time (R13):

```typescript
async function validateContentTagFilters(
  sessionData: Record<string, string> | undefined,
  agentSnapshot: AgentSnapshot,
): Promise<ValidationWarning[]> {
  if (!sessionData || Object.keys(sessionData).length === 0) return [];

  const warnings: ValidationWarning[] = [];
  const retrieveTools = agentSnapshot.tools.filter(t => t.toolType === "RETRIEVE");

  // Check if any Retrieve tool has dynamic filter placeholders
  const placeholderKeys: string[] = [];
  for (const tool of retrieveTools) {
    const filterConfig = extractFilterConfig(tool.inputSchema);
    if (filterConfig) {
      const matches = filterConfig.match(/\{\{\$\.Custom\.(\w+)\}\}/g);
      if (matches) {
        placeholderKeys.push(...matches.map(m => m.replace(/\{\{\$\.Custom\.|\}\}/g, "")));
      }
    }
  }

  if (placeholderKeys.length === 0) {
    // R13.3: No dynamic filter configured — informational tooltip
    warnings.push({
      type: "info",
      message: "This agent's Retrieve tool does not appear to have a dynamic content tag filter configured...",
    });
  } else {
    // R13.2: Check if session data keys match placeholder keys
    for (const key of Object.keys(sessionData)) {
      if (!placeholderKeys.includes(key)) {
        warnings.push({
          type: "warning",
          key,
          message: `Session data key "${key}" does not appear to be referenced by any Retrieve tool's content tag filter.`,
        });
      }
    }
  }

  return warnings;
}
```

## Backward Compatibility Handling

All backward compatibility is handled at **read time** — no existing records are mutated.

| Record | Missing Field | Read Normalization |
|--------|--------------|-------------------|
| `TestCase` | `type` absent | Treat as `"tool_sequence"` |
| `TestSuite` | `ragThresholds` absent | Apply `DEFAULT_RAG_THRESHOLDS` (all 0.7) |
| `TestCaseResult` | `caseType` absent | Treat as `"tool_sequence"` |
| `TestCaseResult` | `ragMetrics` absent | `undefined` (no scores) |
| `TestCaseResult` | `retrievedChunks` absent | `undefined` (not captured) |

The type-discriminator validator normalizes on read:

```typescript
function normalizeTestCase(raw: Record<string, unknown>): TestCase {
  const type = (raw.type as string) ?? "tool_sequence";
  if (type === "rag") {
    return { ...raw, type: "rag" } as RagTestCase;
  }
  return { ...raw, type: "tool_sequence" } as ToolSequenceTestCase;
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: JSONL Serialization Round-Trip

*For any* valid RAG case input (arbitrary question string 1..1000 chars, arbitrary groundTruthAnswer 1..4000 chars, arbitrary agentResponse string, and zero or more RetrievedChunks with arbitrary text content), the JSONL serializer SHALL produce a single-line valid JSON object whose `conversationTurns[0].prompt.content[0].text` equals the input question byte-for-byte, whose `conversationTurns[0].referenceResponses[0].content[0].text` equals the input groundTruthAnswer byte-for-byte, whose `conversationTurns[0].output.text` equals the input agentResponse byte-for-byte, and whose `conversationTurns[0].output.retrievedPassages.retrievalResults[i].content.text` equals the i-th chunk's text byte-for-byte.

**Validates: Requirements 11.1, 5.1, 5.2, 5.3, 5.4, 5.7**

### Property 2: Pass/Fail Decision Function is Pure and Total

*For any* four numeric values in `[0,1]` (faithfulness, correctness, completeness, helpfulness scores) and any four numeric values in `[0,1]` (faithfulness, correctness, completeness, helpfulness thresholds), the `computeRagCaseStatus` function SHALL return `"failed"` if faithfulness < faithfulnessThreshold, SHALL return `"passed"` if faithfulness >= faithfulnessThreshold AND correctness >= correctnessThreshold AND completeness >= completenessThreshold AND helpfulness >= helpfulnessThreshold, and SHALL return `"failed"` otherwise — the function never throws and always returns one of exactly two values.

**Validates: Requirements 11.2, 6.3, 6.4**

### Property 3: Chunk Extraction Preserves Order and Text

*For any* ListSpans payload containing zero or more `execute_tool` spans matching the Retrieve tool name (each with an arbitrary number of `toolResult.values[]` entries carrying arbitrary text content), the `extractRetrievedChunks` function SHALL produce a `RetrievedChunk[]` whose length equals the total count of `toolResult.values[]` entries across all matching spans, in the same chronological and positional order, with each chunk's `text` field equal to the corresponding `text.value` byte-for-byte.

**Validates: Requirements 11.3, 3.4**

### Property 4: Type-Discriminator Validator Accepts Exactly Valid Shapes

*For any* record object, the type-discriminator validator SHALL accept the record if and only if it satisfies one of exactly two valid shapes: (a) `type === "tool_sequence"` with all existing tool-sequence fields preserved and no RAG-specific fields present, or (b) `type === "rag"` with `question` (1..1000 trimmed-non-empty) and `groundTruthAnswer` (1..4000 trimmed-non-empty) present, no simulator fields (persona, style, customerKnowledge, initialUtterance, goalDescription, primingMessage, successCriteria) present, and optional `sessionData`. There is no third valid shape — records violating both shapes are rejected.

**Validates: Requirements 11.4, 1.3, 1.4, 1.5**

### Property 5: Read Normalization Preserves Backward Compatibility

*For any* persisted record that lacks the `type` field (TestCase), the `ragThresholds` field (TestSuite), or the `caseType` field (TestCaseResult), the read normalizer SHALL produce a valid typed object with `type = "tool_sequence"`, `ragThresholds = DEFAULT_RAG_THRESHOLDS`, or `caseType = "tool_sequence"` respectively, without mutating the original record and without failing the read operation.

**Validates: Requirements 10.1, 10.2, 10.3, 10.4, 1.2, 6.2**

## Error Handling

| Error Condition | Code | User-Facing Message | Recovery |
|----------------|------|--------------------| ---------|
| CreateEvaluationJob returns non-2xx | `RAG_JOB_FAILED` | "RAG evaluation failed. Re-run the suite or contact support." | Retry the run |
| Poll exceeds 30 min | `RAG_JOB_TIMEOUT` | "RAG evaluation timed out after 30 minutes. Re-run the suite." | Retry; escalate if persistent |
| Per-prompt output malformed | `MALFORMED_RESULT` | "Bedrock returned an unparseable result for this case." | Other cases still scored |
| Missing prompt in output | `MISSING_EVALUATOR` | "Bedrock did not return a result for this case." | Re-run |
| All RAG cases errored in Stage 1 | `INSUFFICIENT_RAG_DATA` | "All RAG cases errored before evaluation could be submitted" | Fix case definitions |
| Opportunistic Faithfulness fails | (no error code) | Score simply not shown | Best-effort, no user action needed |
| RAG case extraneous field on save | HTTP 400 | `{ error: "rag_case_extraneous_field", field: "<name>" }` | Remove the field |

## Testing Strategy

### Property-Based Tests (fast-check, minimum 100 iterations each)

| Test | Target Module | Property |
|------|--------------|----------|
| JSONL round-trip | `jsonl-serializer.ts` | Property 1 |
| Pass/fail decision | `rag-decision.ts` | Property 2 |
| Chunk extraction | `chunk-extractor.ts` | Property 3 |
| Type-discriminator | `cases.ts` validator | Property 4 |
| Read normalization | type normalizers | Property 5 |

Library: **fast-check** (already available in the project's test dependencies).

Each test tagged: `// Feature: rag-test-cases, Property N: <property text>`

### Unit Tests (example-based)

- JSONL serializer: empty chunks → `retrievalResults: []`; knowledgeBaseId derivation with sentinel fallback
- Decision function: exact boundary cases (score === threshold → pass)
- Chunk extractor: mixed span types (non-Retrieve spans ignored); empty toolResult.values
- Opportunistic evaluator: mock Converse success/failure; threshold opt-in logic
- Content tag filter validator: agent with/without dynamic filter; session data key mismatch

### Integration Tests

- Conversation Driver RAG mode: mocked QConnect client, single-turn flow, no simulator invocation
- Stage 2 pipeline: mocked Bedrock RAG Evaluation APIs, poll → read → write flow
- Step Functions conditional branch: suite with/without RAG cases
- Error code propagation: each failure mode produces the correct DDB record

### Frontend Component Tests

- TestCaseEditorModal: type dropdown changes field visibility
- CaseDetail RAG surface: renders all four sections correctly
- Threshold editor: validation of [0,1] range
- Type badge column: correct badge for each type
