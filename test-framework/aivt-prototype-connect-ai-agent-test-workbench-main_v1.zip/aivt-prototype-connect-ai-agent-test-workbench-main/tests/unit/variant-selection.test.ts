import { describe, it, expect } from "vitest";
import { selectWinningVariant } from "@backend/orchestration/variant-selection";
import type { VariantScore } from "@shared/types";

describe("selectWinningVariant", () => {
  it("returns the variant with the highest pass rate", () => {
    const scores: VariantScore[] = [
      { variant: "A", passRate: 0.6, avgGoalSuccessScore: 0.7, avgHelpfulnessScore: 0.5, avgToolAccuracyScore: 0.5, status: "completed" },
      { variant: "B", passRate: 0.9, avgGoalSuccessScore: 0.8, avgHelpfulnessScore: 0.6, avgToolAccuracyScore: 0.7, status: "completed" },
      { variant: "C", passRate: 0.75, avgGoalSuccessScore: 0.85, avgHelpfulnessScore: 0.7, avgToolAccuracyScore: 0.6, status: "completed" },
    ];
    expect(selectWinningVariant(scores)).toBe("B");
  });

  it("breaks ties by avg goal success score", () => {
    const scores: VariantScore[] = [
      { variant: "A", passRate: 0.8, avgGoalSuccessScore: 0.7, avgHelpfulnessScore: 0.5, avgToolAccuracyScore: 0.5, status: "completed" },
      { variant: "B", passRate: 0.8, avgGoalSuccessScore: 0.9, avgHelpfulnessScore: 0.6, avgToolAccuracyScore: 0.7, status: "completed" },
      { variant: "C", passRate: 0.8, avgGoalSuccessScore: 0.85, avgHelpfulnessScore: 0.7, avgToolAccuracyScore: 0.6, status: "completed" },
    ];
    expect(selectWinningVariant(scores)).toBe("B");
  });

  it("excludes errored variants from selection", () => {
    const scores: VariantScore[] = [
      { variant: "A", passRate: 0.95, avgGoalSuccessScore: 0.9, avgHelpfulnessScore: 0.8, avgToolAccuracyScore: 0.8, status: "error" },
      { variant: "B", passRate: 0.7, avgGoalSuccessScore: 0.6, avgHelpfulnessScore: 0.5, avgToolAccuracyScore: 0.5, status: "completed" },
      { variant: "C", passRate: 0.6, avgGoalSuccessScore: 0.5, avgHelpfulnessScore: 0.4, avgToolAccuracyScore: 0.4, status: "completed" },
    ];
    expect(selectWinningVariant(scores)).toBe("B");
  });

  it("returns null if all variants errored", () => {
    const scores: VariantScore[] = [
      { variant: "A", passRate: 0.9, avgGoalSuccessScore: 0.8, avgHelpfulnessScore: 0.7, avgToolAccuracyScore: 0.6, status: "error" },
      { variant: "B", passRate: 0.85, avgGoalSuccessScore: 0.75, avgHelpfulnessScore: 0.6, avgToolAccuracyScore: 0.5, status: "error" },
      { variant: "C", passRate: 0.8, avgGoalSuccessScore: 0.7, avgHelpfulnessScore: 0.5, avgToolAccuracyScore: 0.4, status: "error" },
    ];
    expect(selectWinningVariant(scores)).toBeNull();
  });

  it("returns null for an empty array", () => {
    expect(selectWinningVariant([])).toBeNull();
  });

  it("returns the single completed variant when others error", () => {
    const scores: VariantScore[] = [
      { variant: "A", passRate: 0.5, avgGoalSuccessScore: 0.4, avgHelpfulnessScore: 0.3, avgToolAccuracyScore: 0.3, status: "error" },
      { variant: "B", passRate: 0.5, avgGoalSuccessScore: 0.4, avgHelpfulnessScore: 0.3, avgToolAccuracyScore: 0.3, status: "error" },
      { variant: "C", passRate: 0.6, avgGoalSuccessScore: 0.5, avgHelpfulnessScore: 0.4, avgToolAccuracyScore: 0.4, status: "completed" },
    ];
    expect(selectWinningVariant(scores)).toBe("C");
  });
});
