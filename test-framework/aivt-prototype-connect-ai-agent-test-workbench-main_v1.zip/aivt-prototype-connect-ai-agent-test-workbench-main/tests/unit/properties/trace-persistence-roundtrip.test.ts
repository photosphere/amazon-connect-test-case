// Feature: trace-reasoning-and-latency, Property 10: Persistence round-trip
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { createDynamoDBService } from "@backend/services/dynamodb";
import { ExecutionStep, ExecutionTrace, InferenceMetadata } from "@shared/types";

/**
 * **Validates: Requirements 4.3**
 *
 * Property 10: Persistence round-trip
 *
 * For any valid ExecutionTrace whose steps carry arbitrary combinations of
 * `durationMs`, `reasoning`, and `inferenceMetadata` (including undefined
 * values), writing via `writeExecutionTrace` and reading back via
 * `getExecutionTrace` SHALL produce an ExecutionTrace whose every step is
 * deep-equal to the input on those three fields.
 *
 * Note: `undefined` fields are dropped by JSON.stringify, so after parse they
 * won't exist on the object. The test verifies that fields that were undefined
 * before are also not present (or undefined) after parse.
 */

// ---------------------------------------------------------------------------
// In-memory mock DynamoDBDocumentClient
// ---------------------------------------------------------------------------

function createMockDocClient(): {
  client: DynamoDBDocumentClient;
  store: Map<string, Record<string, unknown>>;
} {
  const store = new Map<string, Record<string, unknown>>();

  const client = {
    send: async (command: unknown) => {
      const cmd = command as {
        input: Record<string, unknown>;
        constructor: { name: string };
      };
      const commandName = cmd.constructor.name;

      if (commandName === "PutCommand") {
        const item = cmd.input.Item as Record<string, unknown>;
        const key = `${item.PK}#${item.SK}`;
        // Simulate DynamoDB marshalling by deep-cloning via JSON (removes undefined)
        store.set(key, JSON.parse(JSON.stringify(item)));
        return {};
      }

      if (commandName === "GetCommand") {
        const keyObj = cmd.input.Key as Record<string, string>;
        const key = `${keyObj.PK}#${keyObj.SK}`;
        const item = store.get(key);
        return { Item: item ? JSON.parse(JSON.stringify(item)) : undefined };
      }

      return {};
    },
  } as unknown as DynamoDBDocumentClient;

  return { client, store };
}

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Non-empty string with potential unicode, newlines, tabs. */
const unicodeStringArb = fc.string({ minLength: 1, maxLength: 200 }).filter(
  (s) => s.trim().length > 0
);

/** Arbitrary for InferenceMetadata with random subset of valid fields. */
const inferenceMetadataArb: fc.Arbitrary<InferenceMetadata> = fc
  .record(
    {
      usageInputTokens: fc.option(fc.nat({ max: 100000 }), { nil: undefined }),
      usageOutputTokens: fc.option(fc.nat({ max: 100000 }), { nil: undefined }),
      usageTotalTokens: fc.option(fc.nat({ max: 200000 }), { nil: undefined }),
      requestModel: fc.option(unicodeStringArb, { nil: undefined }),
      requestMaxTokens: fc.option(fc.nat({ max: 100000 }), { nil: undefined }),
      temperature: fc.option(
        fc.double({ min: 0, max: 2, noNaN: true, noDefaultInfinity: true }),
        { nil: undefined }
      ),
      timeToFirstTokenMs: fc.option(fc.nat({ max: 600000 }), { nil: undefined }),
      responseFinishReasons: fc.option(
        fc.array(fc.string({ minLength: 1, maxLength: 30 }), {
          minLength: 1,
          maxLength: 3,
        }),
        { nil: undefined }
      ),
      promptArn: fc.option(unicodeStringArb, { nil: undefined }),
      promptId: fc.option(unicodeStringArb, { nil: undefined }),
      promptName: fc.option(unicodeStringArb, { nil: undefined }),
      promptVersion: fc.option(fc.nat({ max: 1000 }), { nil: undefined }),
      aiAgentVersion: fc.option(fc.nat({ max: 1000 }), { nil: undefined }),
      systemInstructions: fc.option(
        fc.string({ minLength: 1, maxLength: 500 }),
        { nil: undefined }
      ),
    },
    { requiredKeys: [] }
  )
  .map((obj) => {
    // Remove undefined keys so the object only has defined fields
    const result: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj)) {
      if (v !== undefined) {
        result[k] = v;
      }
    }
    return result as InferenceMetadata;
  })
  .filter((obj) => Object.keys(obj).length > 0);

/** Arbitrary for an ExecutionStep with random combinations of the three new fields. */
const executionStepArb: fc.Arbitrary<ExecutionStep> = fc.record({
  index: fc.nat({ max: 100 }),
  type: fc.constantFrom("inference" as const, "tool" as const, "agent" as const, "other" as const),
  spanName: fc.constantFrom("inference", "execute_tool", "agent_step", "other_span"),
  text: fc.option(unicodeStringArb, { nil: undefined }),
  timestamp: fc.option(
    fc.date({ min: new Date("2024-01-01"), max: new Date("2026-01-01") }).map((d) =>
      d.toISOString()
    ),
    { nil: undefined }
  ),
  durationMs: fc.option(fc.nat({ max: 86400000 }), { nil: undefined }),
  reasoning: fc.option(
    fc.string({ minLength: 1, maxLength: 300 }).filter((s) => s.trim().length > 0),
    { nil: undefined }
  ),
  inferenceMetadata: fc.option(inferenceMetadataArb, { nil: undefined }),
});

/** Arbitrary for an ExecutionTrace. */
const executionTraceArb: fc.Arbitrary<ExecutionTrace> = fc.record({
  sessionId: fc.string({ minLength: 1, maxLength: 50 }).filter((s) => s.trim().length > 0),
  steps: fc.array(executionStepArb, { minLength: 1, maxLength: 10 }),
  toolSequence: fc.array(
    fc.string({ minLength: 1, maxLength: 30 }).filter((s) => s.trim().length > 0),
    { minLength: 0, maxLength: 5 }
  ),
  aiAgentName: fc.option(unicodeStringArb, { nil: undefined }),
  aiAgentType: fc.option(unicodeStringArb, { nil: undefined }),
  capturedAt: fc.date({ min: new Date("2024-01-01"), max: new Date("2026-01-01") }).map((d) =>
    d.toISOString()
  ),
});

// ---------------------------------------------------------------------------
// Helper: normalize for comparison
// ---------------------------------------------------------------------------

/**
 * Normalizes a value through JSON round-trip to match what DynamoDB + JSON
 * serialization does. `undefined` fields are dropped by JSON.stringify.
 */
function jsonNormalize<T>(value: T): T {
  return JSON.parse(JSON.stringify(value));
}

// ---------------------------------------------------------------------------
// Property test
// ---------------------------------------------------------------------------

describe("Feature: trace-reasoning-and-latency, Property 10: Persistence round-trip", () => {
  it("write + read produces deep-equal durationMs, reasoning, inferenceMetadata on every step", async () => {
    await fc.assert(
      fc.asyncProperty(executionTraceArb, async (trace) => {
        const { client } = createMockDocClient();
        const service = createDynamoDBService("TestTable", client);

        const runId = "test-run-001";
        const caseId = "test-case-001";

        // Write the trace
        await service.writeExecutionTrace(runId, caseId, trace);

        // Read it back
        const retrieved = await service.getExecutionTrace(runId, caseId);

        expect(retrieved).not.toBeNull();
        expect(retrieved!.steps.length).toBe(trace.steps.length);

        // For each step, verify the three new fields are deep-equal after round-trip.
        // JSON.stringify drops undefined fields, so we normalize the input through
        // JSON round-trip before comparing.
        for (let i = 0; i < trace.steps.length; i++) {
          const inputStep = trace.steps[i];
          const outputStep = retrieved!.steps[i];

          // durationMs
          const expectedDurationMs = jsonNormalize(inputStep).durationMs;
          if (expectedDurationMs === undefined) {
            expect(outputStep.durationMs).toBeUndefined();
          } else {
            expect(outputStep.durationMs).toEqual(expectedDurationMs);
          }

          // reasoning
          const expectedReasoning = jsonNormalize(inputStep).reasoning;
          if (expectedReasoning === undefined) {
            expect(outputStep.reasoning).toBeUndefined();
          } else {
            expect(outputStep.reasoning).toEqual(expectedReasoning);
          }

          // inferenceMetadata
          const expectedMetadata = jsonNormalize(inputStep).inferenceMetadata;
          if (expectedMetadata === undefined) {
            expect(outputStep.inferenceMetadata).toBeUndefined();
          } else {
            expect(outputStep.inferenceMetadata).toEqual(expectedMetadata);
          }
        }
      }),
      { numRuns: 100 }
    );
  });
});
