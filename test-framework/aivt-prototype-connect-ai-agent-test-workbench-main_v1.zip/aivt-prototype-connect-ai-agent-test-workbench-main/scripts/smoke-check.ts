#!/usr/bin/env node
/**
 * Post-deploy smoke check for the Connect Agent Test Platform hosting layer.
 *
 * Run via: `npx tsx scripts/smoke-check.ts` (or `npx ts-node scripts/smoke-check.ts`)
 *
 * Validates the externally-observable behavior of a freshly-deployed stack:
 *
 *   1. GET CloudFront root             -> 200 + an `index.html` document
 *      (Reqs 1.3, 2.2, 12.2)
 *   2. GET /config.json                -> 200 + valid JSON whose `apiEndpoint`
 *                                          equals the prod-stage invoke URL
 *                                          and `region` equals the deploy region
 *      (Req 3.4)
 *   3. GET a client-side route         -> 200 via the SPA 403/404 -> /index.html
 *                                          fallback
 *      (Req 1.5)
 *   4. Reports the no-op redeploy expectation as informational
 *      (Reqs 12.1, 12.2)
 *
 * Inputs are sourced (in priority order) from CLI args, then environment
 * variables, then resolved automatically from CloudFormation stack outputs:
 *
 *   --cloudfront-url   | CLOUDFRONT_URL           CloudFront distribution URL
 *   --api-endpoint     | API_ENDPOINT             API Gateway prod invoke URL
 *   --region           | AWS_REGION / CDK_DEFAULT_REGION
 *   --stack            | STACK_NAME               CloudFormation stack name
 *                                                  (default: ConnectAgentTestPlatformStack)
 *   --route            | SMOKE_ROUTE              Client-side route to GET
 *                                                  (default: /runs)
 *
 * Exits 0 on success and a non-zero status on any failed check, with a
 * human-readable error message naming the failing check.
 */

const DEFAULT_STACK_NAME = 'ConnectAgentTestPlatformStack';
const DEFAULT_CLIENT_ROUTE = '/runs';
const HTTP_TIMEOUT_MS = 15_000;

type Inputs = {
  cloudFrontUrl: string;
  apiEndpoint: string;
  region: string;
  clientRoute: string;
  stackName: string;
};

type CliArgs = {
  cloudFrontUrl?: string;
  apiEndpoint?: string;
  region?: string;
  stackName?: string;
  clientRoute?: string;
  help?: boolean;
};

class CheckError extends Error {
  constructor(public readonly check: string, message: string) {
    super(`[${check}] ${message}`);
    this.name = 'CheckError';
  }
}

function parseArgs(argv: string[]): CliArgs {
  const args: CliArgs = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = argv[i + 1];
    const take = (assign: (v: string) => void): void => {
      if (next === undefined) {
        throw new Error(`Missing value for argument ${a}`);
      }
      assign(next);
      i++;
    };
    switch (a) {
      case '-h':
      case '--help':
        args.help = true;
        break;
      case '--cloudfront-url':
        take((v) => (args.cloudFrontUrl = v));
        break;
      case '--api-endpoint':
        take((v) => (args.apiEndpoint = v));
        break;
      case '--region':
        take((v) => (args.region = v));
        break;
      case '--stack':
      case '--stack-name':
        take((v) => (args.stackName = v));
        break;
      case '--route':
        take((v) => (args.clientRoute = v));
        break;
      default:
        if (a.startsWith('--')) {
          const eq = a.indexOf('=');
          if (eq > 0) {
            const key = a.slice(2, eq);
            const value = a.slice(eq + 1);
            switch (key) {
              case 'cloudfront-url':
                args.cloudFrontUrl = value;
                break;
              case 'api-endpoint':
                args.apiEndpoint = value;
                break;
              case 'region':
                args.region = value;
                break;
              case 'stack':
              case 'stack-name':
                args.stackName = value;
                break;
              case 'route':
                args.clientRoute = value;
                break;
              default:
                throw new Error(`Unknown argument: --${key}`);
            }
            break;
          }
          throw new Error(`Unknown argument: ${a}`);
        }
        throw new Error(`Unexpected positional argument: ${a}`);
    }
  }
  return args;
}

function printUsage(): void {
  // eslint-disable-next-line no-console
  console.log(`Usage: npx tsx scripts/smoke-check.ts [options]

Options:
  --cloudfront-url <url>   CloudFront distribution URL (env: CLOUDFRONT_URL)
  --api-endpoint <url>     API Gateway prod invoke URL (env: API_ENDPOINT)
  --region <region>        AWS region the stack is deployed in
                            (env: AWS_REGION / CDK_DEFAULT_REGION)
  --stack <name>           CloudFormation stack name to read outputs from
                            (env: STACK_NAME, default: ${DEFAULT_STACK_NAME})
  --route <path>           Client-side route to verify SPA fallback for
                            (env: SMOKE_ROUTE, default: ${DEFAULT_CLIENT_ROUTE})
  -h, --help               Print this help message

If --cloudfront-url, --api-endpoint, or --region are not supplied (and not in
the environment), the script attempts to read them from the named
CloudFormation stack's outputs (CloudFrontUrl, ApiUrl, and Stack region) using
the default AWS credential chain.`);
}

/**
 * Resolve missing inputs by reading CloudFormation stack outputs. The
 * @aws-sdk/client-cloudformation dependency is loaded dynamically so the
 * script still runs when callers supply every input on the CLI/env (the SDK
 * is not declared in package.json).
 */
async function resolveFromStackOutputs(
  partial: CliArgs,
): Promise<Partial<Inputs>> {
  const needsAny =
    !partial.cloudFrontUrl ||
    !partial.apiEndpoint ||
    !partial.region;
  if (!needsAny) return {};

  const stackName =
    partial.stackName ?? process.env.STACK_NAME ?? DEFAULT_STACK_NAME;
  const region =
    partial.region ??
    process.env.AWS_REGION ??
    process.env.CDK_DEFAULT_REGION;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let mod: any;
  try {
    // Indirect specifier so TypeScript does not statically resolve the module
    // (the SDK is optional — the script also works with explicit CLI/env inputs).
    const cfnModuleId = '@aws-sdk/client-cloudformation';
    mod = await import(cfnModuleId);
  } catch {
    throw new CheckError(
      'inputs',
      'Could not resolve inputs from CloudFormation: @aws-sdk/client-cloudformation is not installed. ' +
        'Provide --cloudfront-url, --api-endpoint, and --region explicitly, or install the SDK.',
    );
  }

  const client = new mod.CloudFormationClient({ region });
  let resp;
  try {
    resp = await client.send(
      new mod.DescribeStacksCommand({ StackName: stackName }),
    );
  } catch (err) {
    throw new CheckError(
      'inputs',
      `Failed to DescribeStacks for "${stackName}": ${(err as Error).message}`,
    );
  }
  const stack = resp.Stacks?.[0];
  if (!stack) {
    throw new CheckError(
      'inputs',
      `Stack "${stackName}" not found in region "${region ?? '(default)'}"`,
    );
  }

  const outputs = new Map<string, string>();
  for (const o of stack.Outputs ?? []) {
    if (o.OutputKey && o.OutputValue) outputs.set(o.OutputKey, o.OutputValue);
  }

  const resolved: Partial<Inputs> = {};
  if (!partial.cloudFrontUrl) {
    const v = outputs.get('CloudFrontUrl');
    if (v) resolved.cloudFrontUrl = v;
  }
  if (!partial.apiEndpoint) {
    const v = outputs.get('ApiUrl');
    if (v) resolved.apiEndpoint = v;
  }
  if (!partial.region) {
    // The stack ARN encodes its region: arn:aws:cloudformation:<region>:...
    const arn = stack.StackId as string | undefined;
    if (arn) {
      const parts = arn.split(':');
      if (parts.length >= 4 && parts[3]) resolved.region = parts[3];
    } else if (region) {
      resolved.region = region;
    }
  }
  return resolved;
}

function resolveInputs(partial: CliArgs, fromStack: Partial<Inputs>): Inputs {
  const cloudFrontUrl =
    partial.cloudFrontUrl ?? process.env.CLOUDFRONT_URL ?? fromStack.cloudFrontUrl;
  const apiEndpoint =
    partial.apiEndpoint ?? process.env.API_ENDPOINT ?? fromStack.apiEndpoint;
  const region =
    partial.region ??
    process.env.AWS_REGION ??
    process.env.CDK_DEFAULT_REGION ??
    fromStack.region;
  const clientRoute =
    partial.clientRoute ?? process.env.SMOKE_ROUTE ?? DEFAULT_CLIENT_ROUTE;
  const stackName =
    partial.stackName ?? process.env.STACK_NAME ?? DEFAULT_STACK_NAME;

  const missing: string[] = [];
  if (!cloudFrontUrl) missing.push('cloudFrontUrl');
  if (!apiEndpoint) missing.push('apiEndpoint');
  if (!region) missing.push('region');
  if (missing.length > 0) {
    throw new CheckError(
      'inputs',
      `Missing required inputs: ${missing.join(', ')}. Pass via CLI flags, env vars, or ensure stack "${stackName}" exposes the corresponding outputs.`,
    );
  }

  return {
    cloudFrontUrl: stripTrailingSlash(cloudFrontUrl as string),
    apiEndpoint: apiEndpoint as string,
    region: region as string,
    clientRoute: ensureLeadingSlash(clientRoute),
    stackName,
  };
}

function stripTrailingSlash(u: string): string {
  return u.endsWith('/') ? u.slice(0, -1) : u;
}

function ensureLeadingSlash(p: string): string {
  return p.startsWith('/') ? p : `/${p}`;
}

/**
 * Compare two URLs ignoring a trailing slash. Used to assert
 * `apiEndpoint === prod invoke URL` regardless of whether either side carries
 * the trailing `/` API Gateway emits on its stage URL.
 */
function urlsEqual(a: string, b: string): boolean {
  return stripTrailingSlash(a) === stripTrailingSlash(b);
}

async function fetchWithTimeout(
  url: string,
  init?: RequestInit,
): Promise<Response> {
  if (typeof fetch !== 'function') {
    throw new Error(
      'Global fetch is not available — Node.js 18+ is required to run this script.',
    );
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function safeFetch(
  check: string,
  url: string,
  init?: RequestInit,
): Promise<Response> {
  try {
    return await fetchWithTimeout(url, init);
  } catch (err) {
    const reason =
      err instanceof Error && err.name === 'AbortError'
        ? `request timed out after ${HTTP_TIMEOUT_MS}ms`
        : (err as Error).message;
    throw new CheckError(check, `GET ${url} failed: ${reason}`);
  }
}

async function checkRoot(inputs: Inputs): Promise<void> {
  const url = `${inputs.cloudFrontUrl}/`;
  const resp = await safeFetch('cloudfront-root', url);
  if (resp.status !== 200) {
    throw new CheckError(
      'cloudfront-root',
      `GET ${url} returned ${resp.status} ${resp.statusText}; expected 200.`,
    );
  }
  const contentType = resp.headers.get('content-type') ?? '';
  if (!/text\/html/i.test(contentType)) {
    throw new CheckError(
      'cloudfront-root',
      `GET ${url} returned content-type "${contentType}"; expected an HTML document.`,
    );
  }
  const body = await resp.text();
  if (!isLikelyIndexHtml(body)) {
    throw new CheckError(
      'cloudfront-root',
      `GET ${url} returned 200 but the body does not look like an index.html document (no <!DOCTYPE html> or root mount element).`,
    );
  }
  // eslint-disable-next-line no-console
  console.log(`  ✓ GET ${url} -> 200 (index.html)`);
}

async function checkConfigJson(inputs: Inputs): Promise<void> {
  const url = `${inputs.cloudFrontUrl}/config.json`;
  const resp = await safeFetch('config-json', url);
  if (resp.status !== 200) {
    throw new CheckError(
      'config-json',
      `GET ${url} returned ${resp.status} ${resp.statusText}; expected 200.`,
    );
  }
  let parsed: unknown;
  const raw = await resp.text();
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new CheckError(
      'config-json',
      `GET ${url} returned 200 but the body is not valid JSON: ${(err as Error).message}`,
    );
  }
  if (!parsed || typeof parsed !== 'object') {
    throw new CheckError(
      'config-json',
      `GET ${url} returned a JSON value that is not an object.`,
    );
  }
  const cfg = parsed as Record<string, unknown>;

  const requiredKeys = [
    'apiEndpoint',
    'cognitoUserPoolId',
    'cognitoClientId',
    'cognitoDomain',
    'region',
    'instanceMode',
  ] as const;
  for (const key of requiredKeys) {
    const v = cfg[key];
    if (typeof v !== 'string' || v.trim() === '') {
      throw new CheckError(
        'config-json',
        `Field "${key}" in /config.json is missing or not a non-empty string.`,
      );
    }
  }

  if (!urlsEqual(cfg.apiEndpoint as string, inputs.apiEndpoint)) {
    throw new CheckError(
      'config-json',
      `Field "apiEndpoint" is "${cfg.apiEndpoint}" but expected the prod invoke URL "${inputs.apiEndpoint}".`,
    );
  }

  if (cfg.region !== inputs.region) {
    throw new CheckError(
      'config-json',
      `Field "region" is "${cfg.region}" but expected the deploy region "${inputs.region}".`,
    );
  }
  // eslint-disable-next-line no-console
  console.log(
    `  ✓ GET ${url} -> 200, apiEndpoint and region match deploy outputs`,
  );
}

async function checkSpaFallback(inputs: Inputs): Promise<void> {
  const url = `${inputs.cloudFrontUrl}${inputs.clientRoute}`;
  const resp = await safeFetch('spa-fallback', url);
  if (resp.status !== 200) {
    throw new CheckError(
      'spa-fallback',
      `GET ${url} returned ${resp.status} ${resp.statusText}; expected 200 via SPA fallback.`,
    );
  }
  const contentType = resp.headers.get('content-type') ?? '';
  if (!/text\/html/i.test(contentType)) {
    throw new CheckError(
      'spa-fallback',
      `GET ${url} returned content-type "${contentType}"; expected an HTML document via SPA fallback.`,
    );
  }
  const body = await resp.text();
  if (!isLikelyIndexHtml(body)) {
    throw new CheckError(
      'spa-fallback',
      `GET ${url} returned 200 but the body does not look like the SPA index.html (no <!DOCTYPE html> or root mount element).`,
    );
  }
  // eslint-disable-next-line no-console
  console.log(`  ✓ GET ${url} -> 200 (SPA fallback to index.html)`);
}

function isLikelyIndexHtml(body: string): boolean {
  // Accept either a doctype declaration or a typical Vite/React root mount
  // element. Either signal is a strong indicator that the body is the SPA's
  // index.html rather than an XML S3 error document.
  if (/<!doctype html>/i.test(body)) return true;
  if (/<div\s+id=["']root["']/i.test(body)) return true;
  return false;
}

function reportNoOpRedeployExpectation(): void {
  // eslint-disable-next-line no-console
  console.log(
    '  ℹ A subsequent `cdk deploy` with identical context, props, and frontend ' +
      'build is expected to be a no-op (zero resource additions/replacements/' +
      'deletions; existing index.html and /config.json retained). This script ' +
      'does NOT invoke `cdk diff`/`cdk deploy`; verify externally via ' +
      '`cdk diff` or by running deploy a second time. (Reqs 12.1, 12.2)',
  );
}

async function main(): Promise<void> {
  let cli: CliArgs;
  try {
    cli = parseArgs(process.argv.slice(2));
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(`Argument error: ${(err as Error).message}`);
    printUsage();
    process.exit(2);
    return;
  }
  if (cli.help) {
    printUsage();
    process.exit(0);
    return;
  }

  let inputs: Inputs;
  try {
    const fromStack = await resolveFromStackOutputs(cli);
    inputs = resolveInputs(cli, fromStack);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(`SMOKE CHECK FAILED: ${(err as Error).message}`);
    process.exit(1);
    return;
  }

  // eslint-disable-next-line no-console
  console.log(
    `Running smoke checks against:\n  CloudFront URL: ${inputs.cloudFrontUrl}\n  API endpoint:   ${inputs.apiEndpoint}\n  Region:         ${inputs.region}\n  Client route:   ${inputs.clientRoute}\n`,
  );

  type Check = { name: string; run: () => Promise<void> };
  const checks: Check[] = [
    { name: 'CloudFront root returns index.html', run: () => checkRoot(inputs) },
    {
      name: '/config.json matches deploy outputs',
      run: () => checkConfigJson(inputs),
    },
    {
      name: `Client-side route ${inputs.clientRoute} via SPA fallback`,
      run: () => checkSpaFallback(inputs),
    },
  ];

  const failures: Error[] = [];
  for (const c of checks) {
    // eslint-disable-next-line no-console
    console.log(`Running check: ${c.name}`);
    try {
      await c.run();
    } catch (err) {
      const e = err instanceof Error ? err : new Error(String(err));
      failures.push(e);
      // eslint-disable-next-line no-console
      console.error(`  ✗ ${e.message}`);
    }
  }

  // eslint-disable-next-line no-console
  console.log('\nReporting:');
  reportNoOpRedeployExpectation();

  if (failures.length > 0) {
    // eslint-disable-next-line no-console
    console.error(`\nSMOKE CHECK FAILED: ${failures.length} check(s) failed.`);
    process.exit(1);
    return;
  }

  // eslint-disable-next-line no-console
  console.log('\nSMOKE CHECK PASSED: all hosting checks succeeded.');
  process.exit(0);
}

void main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(`SMOKE CHECK FAILED (unexpected): ${(err as Error).stack ?? err}`);
  process.exit(1);
});
