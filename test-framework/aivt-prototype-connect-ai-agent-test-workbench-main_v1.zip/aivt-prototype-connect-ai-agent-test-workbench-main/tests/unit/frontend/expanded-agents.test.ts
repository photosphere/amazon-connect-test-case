/**
 * Tests for the Test Suites page expand/collapse reducer
 * (`mergeExpandedAgents`) — agent-grouped-suites Task 6.2.
 *
 * The Suites page keeps a `Record<agentName, boolean>` of which agent
 * sections are expanded and reconciles it against every fetch via
 * `mergeExpandedAgents`. The component's post-fetch `useEffect` calls this
 * exact reducer, so exercising it here covers the real code path that
 * implements Requirements 5.2 and 5.3.
 *
 * Property 7 (initial render): for a fresh page (empty prior state), the
 * reduced map sets every distinct agent name to `true` — every section
 * starts expanded. **Validates: Requirements 5.2**
 *
 * Property 8 (collapse preserved across refresh): any agent the user has
 * collapsed (`false`) stays `false` after a re-fetch, as long as the agent
 * still appears in the new data. **Validates: Requirements 5.3**
 *
 * Example-based unit tests pin the concrete behaviours the properties
 * generalise (new agents added expanded, existing states preserved,
 * purity / no mutation of the prior state).
 */

import fc from 'fast-check';
import { describe, expect, it } from 'vitest';

import {
  mergeExpandedAgents,
  type ExpandedAgentsState,
} from '../../../src/frontend/src/utils/expandedAgents';
import { groupSuitesByAgent } from '../../../src/frontend/src/utils/groupSuites';
import type { EnrichedTestSuite } from '../../../src/shared/types';

// ---------------------------------------------------------------------------
// Fixture builder
// ---------------------------------------------------------------------------

function buildSuite(
  suiteId: string,
  agentName: string,
): EnrichedTestSuite {
  return {
    tenantId: 'tenant-1',
    suiteId,
    name: `suite-${suiteId}`,
    agentId: `agent-id-${suiteId}`,
    agentName,
    assistantId: 'assistant-1',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  };
}

// ---------------------------------------------------------------------------
// Generators
// ---------------------------------------------------------------------------

// Small pool so multiple suites collapse under the same agent frequently.
const AGENT_NAME_POOL: readonly string[] = [
  'Alpha',
  'Beta',
  'Gamma',
  'Delta',
  'Écho',
  'zulu',
  'agent-007',
];

const agentNameArb: fc.Arbitrary<string> = fc.constantFrom(...AGENT_NAME_POOL);

const suitesArb: fc.Arbitrary<EnrichedTestSuite[]> = fc
  .integer({ min: 0, max: 20 })
  .chain((count) =>
    fc.tuple(
      ...Array.from({ length: count }, (_unused, i) =>
        agentNameArb.map((agentName) => buildSuite(String(i), agentName)),
      ),
    ),
  )
  .map((suites) => [...suites]);

// ---------------------------------------------------------------------------
// Property 7: All sections expanded on initial render
// ---------------------------------------------------------------------------

describe('mergeExpandedAgents — Property 7: all sections expanded on initial render', () => {
  it('maps every distinct agent name to true when prior state is empty', () => {
    fc.assert(
      fc.property(suitesArb, (suites) => {
        const next = mergeExpandedAgents({}, suites);
        const distinctNames = new Set(suites.map((s) => s.agentName));

        // Exactly one entry per distinct agent name, and every one expanded.
        expect(Object.keys(next).length).toBe(distinctNames.size);
        for (const name of distinctNames) {
          expect(next[name]).toBe(true);
        }
        // No stray keys beyond the agents present in the data.
        for (const key of Object.keys(next)) {
          expect(distinctNames.has(key)).toBe(true);
        }
      }),
      { numRuns: 200 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 8: Collapse state preserved across refresh
// ---------------------------------------------------------------------------

describe('mergeExpandedAgents — Property 8: collapse state preserved across refresh', () => {
  it('keeps collapsed agents collapsed after a re-fetch when they still appear', () => {
    // Model a full first-render-then-collapse-then-refresh lifecycle:
    //   1. initial fetch → all expanded
    //   2. user collapses an arbitrary subset of the present agents
    //   3. refresh re-fetches a (possibly different) suite list
    // Any agent the user collapsed that STILL appears in the refreshed data
    // must remain collapsed; agents new to the refresh must arrive expanded.
    fc.assert(
      fc.property(
        suitesArb,
        suitesArb,
        fc.array(fc.boolean(), { minLength: 0, maxLength: 20 }),
        (firstSuites, refreshedSuites, collapseFlags) => {
          // 1. initial render
          const initial = mergeExpandedAgents({}, firstSuites);

          // 2. user collapses a subset of the agents currently shown
          const firstAgentNames = groupSuitesByAgent(firstSuites).map(
            (g) => g.agentName,
          );
          const afterCollapse: ExpandedAgentsState = { ...initial };
          const collapsed = new Set<string>();
          firstAgentNames.forEach((name, idx) => {
            if (collapseFlags[idx]) {
              afterCollapse[name] = false;
              collapsed.add(name);
            }
          });

          // 3. refresh
          const afterRefresh = mergeExpandedAgents(afterCollapse, refreshedSuites);

          const refreshedNames = new Set(
            refreshedSuites.map((s) => s.agentName),
          );

          // Collapsed agents that still appear stay collapsed.
          for (const name of collapsed) {
            expect(afterRefresh[name]).toBe(false);
          }

          // Agents new in the refresh (not seen before) arrive expanded.
          const knownBefore = new Set(Object.keys(afterCollapse));
          for (const name of refreshedNames) {
            if (!knownBefore.has(name)) {
              expect(afterRefresh[name]).toBe(true);
            }
          }
        },
      ),
      { numRuns: 200 },
    );
  });
});

// ---------------------------------------------------------------------------
// Example-based unit tests
// ---------------------------------------------------------------------------

describe('mergeExpandedAgents — examples', () => {
  it('adds newly discovered agents as expanded', () => {
    const suites = [
      buildSuite('1', 'Billing'),
      buildSuite('2', 'Support'),
      buildSuite('3', 'Billing'),
    ];
    expect(mergeExpandedAgents({}, suites)).toEqual({
      Billing: true,
      Support: true,
    });
  });

  it('preserves an existing collapsed state while adding new agents', () => {
    const prev: ExpandedAgentsState = { Billing: false };
    const suites = [buildSuite('1', 'Billing'), buildSuite('2', 'Support')];
    expect(mergeExpandedAgents(prev, suites)).toEqual({
      Billing: false, // user's collapse choice preserved
      Support: true, // newly discovered → expanded
    });
  });

  it('preserves an existing expanded state without overwriting it', () => {
    const prev: ExpandedAgentsState = { Billing: true };
    const suites = [buildSuite('1', 'Billing')];
    expect(mergeExpandedAgents(prev, suites)).toEqual({ Billing: true });
  });

  it('does not mutate the previous state object', () => {
    const prev: ExpandedAgentsState = { Billing: false };
    const frozen = Object.freeze({ ...prev });
    const suites = [buildSuite('1', 'Support')];
    const next = mergeExpandedAgents(frozen, suites);
    expect(next).not.toBe(frozen);
    expect(frozen).toEqual({ Billing: false });
    expect(next).toEqual({ Billing: false, Support: true });
  });

  it('returns the prior state unchanged for an empty suites list', () => {
    const prev: ExpandedAgentsState = { Billing: false, Support: true };
    expect(mergeExpandedAgents(prev, [])).toEqual({
      Billing: false,
      Support: true,
    });
  });

  it('retains keys for agents that disappear from a later fetch', () => {
    const prev: ExpandedAgentsState = { Billing: false };
    // Billing no longer present, only Support is.
    const next = mergeExpandedAgents(prev, [buildSuite('1', 'Support')]);
    expect(next).toEqual({ Billing: false, Support: true });
  });
});
