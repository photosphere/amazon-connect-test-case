/**
 * Results Lambda — API Gateway handler for test run results.
 *
 * Routes:
 * - GET /runs/{runId}           → Run metadata + progress counts
 * - GET /runs/{runId}/cases/{caseId} → Full result with transcript
 * - GET /suites/{suiteId}/runs  → Run history (paginated at 50, descending)
 *
 * Supports partial results: returns completed case results even while run
 * status is RUNNING.
 *
 * @module results
 */

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";
import {
  QConnectClient,
  ListSpansCommand,
} from "@aws-sdk/client-qconnect";
import { CONCURRENCY, PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import { CaseStatus, RunStatus } from "../../shared/enums";
import type {
  TestCaseResult,
  TestRun,
  TranscriptTurn,
  ExecutionTrace,
  ExecutionStep,
  ExperimentRecord,
} from "../../shared/types";
import { calculateAccuracy } from "../../shared/utils/accuracy";
import { parseSpansToTrace, type RawSpan } from "../orchestration/span-parser";
import { sortResults } from "../../shared/utils/results-sorting";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
const PAGE_SIZE = 50;

// ---------------------------------------------------------------------------
// Lazy re-fetch configuration
// ---------------------------------------------------------------------------

/** Status of a lazy trace re-fetch attempt. */
export type TraceRefetchStatus =
  | "refreshed"
  | "refreshed_memory_only"
  | "skipped_expired"
  | "skipped_no_session";

/**
 * Retention window (in days) for Q in Connect ListSpans data.
 * Configurable via the LISTSPANS_RETENTION_DAYS environment variable.
 */
const LISTSPANS_RETENTION_DAYS = parseInt(
  process.env.LISTSPANS_RETENTION_DAYS ?? "7",
  10,
);

const REGION = process.env.AWS_REGION ?? "us-east-1";
const ASSISTANT_ID = process.env.ASSISTANT_ID ?? "";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** API Gateway proxy event (subset relevant to this handler). */
export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  queryStringParameters?: Record<string, string> | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, unknown>;
    };
  };
}

/** Standard API Gateway proxy response. */
export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

/** Progress summary for a run. */
export interface RunProgress {
  totalCases: number;
  completed: number;
  passed: number;
  failed: number;
  errors: number;
  accuracy: number;
}

/** Response shape for GET /runs/{runId}. */
export interface RunDetailResponse {
  run: TestRun;
  progress: RunProgress;
  results: TestCaseResult[];
}

/** Response shape for GET /runs/{runId}/cases/{caseId}. */
export interface CaseDetailResponse {
  result: TestCaseResult;
  transcript: TranscriptTurn[];
  /**
   * Structured execution trace (parsed from Q in Connect ListSpans) for
   * this case, when one is persisted at `PK=RUN#{runId}#CASE#{caseId},
   * SK=TRACE`. Carries the agent's per-step reasoning text and every
   * `execute_tool` invocation's args/results in chronological order —
   * the raw material for the case-detail page's "Reasoning" section.
   * Optional: cases that errored before any spans were captured don't
   * have a trace; the GUI shows a neutral empty state.
   */
  executionTrace?: ExecutionTrace;
  /**
   * Status of the lazy trace re-fetch attempt, when applicable:
   * - undefined: normal case (trace was already enriched or no re-fetch attempted)
   * - "refreshed": re-fetch succeeded and DDB was updated
   * - "refreshed_memory_only": re-fetch succeeded but DDB write failed; serving from memory
   * - "skipped_expired": run is outside retention window
   * - "skipped_no_session": no sessionId available
   */
  traceRefetchStatus?: TraceRefetchStatus;
}

/** Response shape for GET /suites/{suiteId}/runs. */
export interface RunHistoryResponse {
  runs: TestRun[];
  nextToken?: string;
}

/**
 * Response shape for GET /runs/{runId}/experiments.
 *
 * Returns every experiment associated with a run. Each experiment record
 * carries the variant configs, temporary agent IDs, variant run IDs,
 * tournament summary, and lifecycle status — the same shape as
 * `GET /runs/{runId}/experiments/{experimentId}` returns for a single one.
 *
 * Sort order is reverse chronological (newest first) — most recent
 * experiment surfaces at the top of the Run Dashboard's "Experiment Results"
 * panel.
 *
 * The list is allowed to be empty: a run that has never had an experiment
 * triggered returns `{ experiments: [] }` with HTTP 200, NOT a 404. This
 * lets the Run Dashboard's mount-time fetch silently no-op rather than
 * surfacing an error to the user.
 */
export interface RunExperimentsResponse {
  experiments: ExperimentRecord[];
}

// ---------------------------------------------------------------------------
// DynamoDB client
// ---------------------------------------------------------------------------

let ddbDocClient: DynamoDBDocumentClient | null = null;

function getDDBClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setDDBClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Q in Connect client (for lazy re-fetch)
// ---------------------------------------------------------------------------

let qconnectClient: QConnectClient | null = null;

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: REGION });
  }
  return qconnectClient;
}

/** @internal — allows test injection */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

// ---------------------------------------------------------------------------
// Lazy re-fetch helpers
// ---------------------------------------------------------------------------

/**
 * Detects whether a trace is a pre-feature TRACE (written before the
 * reasoning/latency feature shipped). A pre-feature trace is one where
 * NO step has `durationMs`, `reasoning`, or `inferenceMetadata` defined.
 */
export function isPreFeatureTrace(trace: ExecutionTrace): boolean {
  return trace.steps.every(
    (step: ExecutionStep) =>
      step.durationMs === undefined &&
      step.reasoning === undefined &&
      step.inferenceMetadata === undefined,
  );
}

/**
 * Determines whether a run is within the ListSpans retention window.
 * Returns true if the run is recent enough that spans may still be available.
 */
function isWithinRetentionWindow(runStartTime: string): boolean {
  if (!runStartTime) return false;
  const startMs = Date.parse(runStartTime);
  if (Number.isNaN(startMs)) return false;
  const retentionMs = LISTSPANS_RETENTION_DAYS * 24 * 60 * 60 * 1000;
  return (Date.now() - startMs) <= retentionMs;
}

/**
 * Checks whether a re-parsed trace contains new enrichment data that the
 * stored trace lacks. Returns true if the re-parsed trace has at least one
 * step with `durationMs`, `reasoning`, or `inferenceMetadata` defined.
 */
function hasEnrichedData(trace: ExecutionTrace): boolean {
  return trace.steps.some(
    (step: ExecutionStep) =>
      step.durationMs !== undefined ||
      step.reasoning !== undefined ||
      step.inferenceMetadata !== undefined,
  );
}

/**
 * Fetches spans from ListSpans for a session and parses them into an
 * ExecutionTrace. Returns null if no spans are returned or on error.
 * Never throws — errors are logged and null is returned.
 */
async function fetchAndParseSpans(
  sessionId: string,
): Promise<ExecutionTrace | null> {
  if (!ASSISTANT_ID) {
    console.warn("[results] lazy re-fetch skipped: ASSISTANT_ID not configured");
    return null;
  }

  const client = getQConnectClient();
  const rawSpans: RawSpan[] = [];
  let nextToken: string | undefined;

  do {
    const resp = await client.send(
      new ListSpansCommand({
        assistantId: ASSISTANT_ID,
        sessionId,
        nextToken,
        maxResults: 100,
      }),
    );
    for (const s of resp.spans ?? []) {
      rawSpans.push(s as RawSpan);
    }
    nextToken = resp.nextToken;
  } while (nextToken);

  if (rawSpans.length === 0) {
    console.info(
      `[results] lazy re-fetch returned 0 spans for session ${sessionId}`,
    );
    return null;
  }

  return parseSpansToTrace(sessionId, rawSpans);
}

/**
 * Attempts to overwrite the DDB TRACE row with the enriched trace.
 * Retries once on failure. Returns true if the write succeeded, false
 * if both attempts failed.
 */
async function persistEnrichedTrace(
  runId: string,
  caseId: string,
  trace: ExecutionTrace,
): Promise<boolean> {
  const client = getDDBClient();
  const item = {
    PK: `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
    SK: SK_PATTERNS.TRACE,
    sessionId: trace.sessionId,
    aiAgentName: trace.aiAgentName,
    aiAgentType: trace.aiAgentType,
    toolSequence: trace.toolSequence,
    steps: JSON.stringify(trace.steps),
    capturedAt: trace.capturedAt,
  };

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      await client.send(new PutCommand({ TableName: TABLE_NAME, Item: item }));
      return true;
    } catch (error) {
      console.warn(
        `[results] lazy re-fetch DDB write attempt ${attempt + 1} failed for ` +
          `run=${runId}, case=${caseId}: ${
            error instanceof Error ? error.message : String(error)
          }`,
      );
      // Brief delay before retry (simple exponential backoff: 100ms then skip)
      if (attempt === 0) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
    }
  }
  return false;
}

/**
 * Result of the lazy re-fetch attempt.
 */
interface LazyRefetchResult {
  /** The (potentially enriched) trace to serve. */
  trace: ExecutionTrace;
  /** Status indicator for the response. */
  status?: TraceRefetchStatus;
}

/**
 * Attempts a lazy re-fetch for a pre-feature trace:
 * 1. Checks retention window
 * 2. Checks sessionId presence
 * 3. Calls ListSpans
 * 4. Compares and persists if enriched
 *
 * Never throws — all failures are logged and the existing trace is returned.
 */
async function attemptLazyRefetch(
  runId: string,
  caseId: string,
  existingTrace: ExecutionTrace,
  runStartTime: string,
): Promise<LazyRefetchResult> {
  // Check retention window
  if (!isWithinRetentionWindow(runStartTime)) {
    return { trace: existingTrace, status: "skipped_expired" };
  }

  // Check sessionId
  if (!existingTrace.sessionId) {
    return { trace: existingTrace, status: "skipped_no_session" };
  }

  // Attempt ListSpans fetch
  let reParsedTrace: ExecutionTrace | null;
  try {
    reParsedTrace = await fetchAndParseSpans(existingTrace.sessionId);
  } catch (error) {
    // fetchAndParseSpans should not throw, but defensive handling
    console.warn(
      `[results] lazy re-fetch unexpected error for session ${existingTrace.sessionId}: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
    return { trace: existingTrace };
  }

  // If 0 spans or error: leave existing trace unchanged
  if (!reParsedTrace) {
    return { trace: existingTrace };
  }

  // Check if re-parsed trace has new data
  if (!hasEnrichedData(reParsedTrace)) {
    // Re-fetch yielded same data — no write needed
    return { trace: existingTrace };
  }

  // Re-parsed trace has new data — attempt to persist
  const writeSucceeded = await persistEnrichedTrace(runId, caseId, reParsedTrace);

  if (writeSucceeded) {
    return { trace: reParsedTrace, status: "refreshed" };
  }

  // DDB write failed after retry — serve from memory with notice
  return { trace: reParsedTrace, status: "refreshed_memory_only" };
}

// ---------------------------------------------------------------------------
// Response helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
};

function success(body: unknown): APIGatewayResponse {
  return { statusCode: 200, body: JSON.stringify(body), headers: CORS_HEADERS };
}

function notFound(message: string): APIGatewayResponse {
  return {
    statusCode: 404,
    body: JSON.stringify({ error: message }),
    headers: CORS_HEADERS,
  };
}

function badRequest(message: string): APIGatewayResponse {
  return {
    statusCode: 400,
    body: JSON.stringify({ error: message }),
    headers: CORS_HEADERS,
  };
}

function serverError(message: string): APIGatewayResponse {
  return {
    statusCode: 500,
    body: JSON.stringify({ error: message }),
    headers: CORS_HEADERS,
  };
}

function methodNotAllowed(): APIGatewayResponse {
  return {
    statusCode: 405,
    body: JSON.stringify({ error: "Method not allowed" }),
    headers: CORS_HEADERS,
  };
}

// ---------------------------------------------------------------------------
// DynamoDB helpers
// ---------------------------------------------------------------------------

/**
 * Strip DynamoDB key attributes from an item.
 */
function stripKeys<T>(item: Record<string, unknown>): T {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { PK, SK, GSI1PK, GSI1SK, GSI2PK, GSI2SK, ...rest } = item;
  return rest as unknown as T;
}

/**
 * Find a run record by runId. The lookup proceeds in three stages so the
 * GET /runs/{runId} endpoint resolves an in-progress run regardless of
 * whether the caller supplies a `?suiteId=` hint.
 *
 * Stage 1 — SUMMARY by id. WriteResults stamps a single-key
 *   `PK=RUN#{runId}, SK=SUMMARY` record at run completion. When that record
 *   is present (a finished run), we return it directly.
 *
 * Stage 2 — query by hint. When the caller supplied `?suiteId=` (the
 *   common case from the Run Dashboard, the Suites list "View" link, and
 *   the active-runs banner), we query the legacy
 *   `PK=SUITE#{suiteId}, SK=RUN#{startTime}` partition the run record
 *   actually lives in and find the matching `runId` attribute.
 *
 * Stage 3 — tenant-wide scan. When no hint was supplied (a hard-reload of
 *   `/runs/{id}`, a typed deep-link, or a stale tab whose URL lost its
 *   query string), list the tenant's suites and scan each suite's
 *   `RUN#` partition for the runId. Linear in the number of suites + runs
 *   per suite for the user, but bounded by the per-tenant scale (small)
 *   and only paid on the no-hint code path. Mirrors the same pattern
 *   `abortRun` uses in `runs.ts`.
 *
 * Stage 4 (existing) — partial-results probe. When the tenant scan also
 *   misses, check whether any case results have been written under
 *   `PK=RUN#{runId}` and synthesize a minimal RUNNING placeholder.
 */
async function getRunByRunId(
  runId: string,
  suiteIdHint?: string,
  tenantId?: string,
): Promise<TestRun | null> {
  const client = getDDBClient();

  // Check for SUMMARY record (exists after run completes)
  const summaryResult = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: "SUMMARY",
      },
    })
  );

  if (summaryResult.Item) {
    const summary = summaryResult.Item as Record<string, unknown>;
    // Reconstruct a TestRun-compatible object from the summary
    return {
      suiteId: (summary.suiteId as string) ?? "",
      runId: (summary.runId as string) ?? runId,
      status: (summary.status as RunStatus) ?? RunStatus.COMPLETED,
      totalCases: (summary.totalCases as number) ?? 0,
      passed: (summary.passed as number) ?? 0,
      failed: (summary.failed as number) ?? 0,
      errors: (summary.errors as number) ?? 0,
      concurrency: (summary.concurrency as number) ?? CONCURRENCY,
      startTime: (summary.startTime as string) ?? "",
      endTime: (summary.endTime as string) ?? undefined,
      sfnExecutionArn: (summary.sfnExecutionArn as string) ?? "",
    } as TestRun;
  }

  // If suiteId is provided, query directly for the run record
  if (suiteIdHint) {
    const runsResult = await client.send(
      new QueryCommand({
        TableName: TABLE_NAME,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.SUITE}${suiteIdHint}`,
          ":skPrefix": SK_PATTERNS.RUN,
        },
        ScanIndexForward: false,
      })
    );

    const runs = (runsResult.Items || []).map(
      (item) => stripKeys<TestRun>(item as Record<string, unknown>)
    );
    const matchingRun = runs.find((r) => r.runId === runId);
    if (matchingRun) return matchingRun;
  }

  // Stage 3 — tenant-wide scan when no hint was supplied. Mirrors the
  // pattern abortRun uses in runs.ts: list the tenant's suites, scan each
  // suite's RUN# partition, return the first match. Linear in the
  // tenant's run count but only paid on the no-hint code path.
  if (!suiteIdHint && tenantId) {
    const suitesResult = await client.send(
      new QueryCommand({
        TableName: TABLE_NAME,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
        ExpressionAttributeValues: {
          ":pk": `${PK_PATTERNS.TENANT}${tenantId}`,
          ":skPrefix": PK_PATTERNS.SUITE,
        },
      })
    );
    const suiteRows = (suitesResult.Items || []).map(
      (item) => stripKeys<{ suiteId: string }>(item as Record<string, unknown>),
    );
    for (const suiteRow of suiteRows) {
      const runsResult = await client.send(
        new QueryCommand({
          TableName: TABLE_NAME,
          KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
          ExpressionAttributeValues: {
            ":pk": `${PK_PATTERNS.SUITE}${suiteRow.suiteId}`,
            ":skPrefix": SK_PATTERNS.RUN,
          },
          ScanIndexForward: false,
        }),
      );
      const runs = (runsResult.Items || []).map(
        (item) => stripKeys<TestRun>(item as Record<string, unknown>),
      );
      const match = runs.find((r) => r.runId === runId);
      if (match) return match;
    }
  }

  // Stage 4 — partial-results probe. Lets the dashboard surface in-flight
  // case rows even on the rare path where stages 1–3 all missed. We count
  // ALL case rows under the run partition so the progress denominator
  // (`totalCases`) is never smaller than the number of completed cases —
  // otherwise the UI shows nonsense like "5 of 0 completed". This count is
  // the floor for the true total (the run may still have pending cases),
  // but it is always correct relative to what has been written so far.
  const resultsQuery = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}`,
        ":skPrefix": SK_PATTERNS.CASE,
      },
    })
  );

  if (resultsQuery.Items && resultsQuery.Items.length > 0) {
    // Run exists and has partial results, but we don't know the full run
    // metadata (stages 1–3 missed). Synthesize a minimal RUNNING placeholder
    // and use the observed case-row count as the totalCases floor so the
    // progress fraction is coherent (never "N of 0").
    const caseCount = resultsQuery.Items.length;
    return {
      suiteId: "",
      runId,
      status: RunStatus.RUNNING,
      totalCases: caseCount,
      passed: 0,
      failed: 0,
      errors: 0,
      concurrency: CONCURRENCY,
      startTime: "",
      sfnExecutionArn: "",
    } as TestRun;
  }

  return null;
}

/**
 * Get all results for a run (supports partial results while running).
 */
async function getRunResults(runId: string): Promise<TestCaseResult[]> {
  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}`,
        ":skPrefix": SK_PATTERNS.CASE,
      },
    })
  );
  return (result.Items || []).map(
    (item) => stripKeys<TestCaseResult>(item as Record<string, unknown>)
  );
}

/**
 * Get a single case result.
 */
async function getCaseResult(
  runId: string,
  caseId: string
): Promise<TestCaseResult | null> {
  const client = getDDBClient();
  const result = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `${SK_PATTERNS.CASE}${caseId}`,
      },
    })
  );
  if (!result.Item) return null;
  return stripKeys<TestCaseResult>(result.Item as Record<string, unknown>);
}

/**
 * Get the transcript for a case.
 */
async function getTranscript(
  runId: string,
  caseId: string
): Promise<TranscriptTurn[]> {
  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
        ":skPrefix": SK_PATTERNS.TURN,
      },
      ScanIndexForward: true,
    })
  );
  return (result.Items || []).map(
    (item) => stripKeys<TranscriptTurn>(item as Record<string, unknown>)
  );
}

/**
 * List run history for a suite, paginated at 50, descending by timestamp.
 */
async function listRunHistory(
  suiteId: string,
  exclusiveStartKey?: Record<string, unknown>
): Promise<{ runs: TestRun[]; lastEvaluatedKey?: Record<string, unknown> }> {
  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.SUITE}${suiteId}`,
        ":skPrefix": SK_PATTERNS.RUN,
      },
      ScanIndexForward: false, // descending by timestamp
      Limit: PAGE_SIZE,
      ...(exclusiveStartKey && { ExclusiveStartKey: exclusiveStartKey }),
    })
  );

  const runs = (result.Items || []).map(
    (item) => stripKeys<TestRun>(item as Record<string, unknown>)
  );

  return { runs, lastEvaluatedKey: result.LastEvaluatedKey };
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------

/**
 * GET /runs/{runId}
 * Returns run metadata + progress (completed/total/pass/fail/error counts)
 * Supports partial results while run is in progress.
 */
async function handleGetRun(
  runId: string,
  suiteId?: string,
  tenantId?: string,
): Promise<APIGatewayResponse> {
  // Get the run record. Pass tenantId through so the no-hint fallback
  // can scan the user's suites instead of returning a misleading 404 for
  // a freshly launched (but legitimate) in-progress run.
  const run = await getRunByRunId(runId, suiteId, tenantId);
  if (!run) {
    return notFound(`Run '${runId}' not found`);
  }

  // Get all results (partial results supported — returns whatever is completed)
  const results = await getRunResults(runId);

  // Calculate progress
  const completed = results.length;
  const passed = results.filter((r) => r.status === CaseStatus.PASSED).length;
  const failed = results.filter((r) => r.status === CaseStatus.FAILED).length;
  const errors = results.filter(
    (r) => r.status === CaseStatus.ERROR || r.status === CaseStatus.TIMED_OUT
  ).length;
  const accuracy = calculateAccuracy(results);

  const progress: RunProgress = {
    // Guard against a stale/synthesized run record reporting a totalCases
    // smaller than the number of case rows already written (which produced
    // the "N of 0 completed" display). The displayed total can never be
    // less than the number of completed cases.
    totalCases: Math.max(run.totalCases, completed),
    completed,
    passed,
    failed,
    errors,
    accuracy,
  };

  // Sort results for display (errors first, then failed, then passed)
  // Add a name field for sorting — use caseId as fallback name
  const sortableResults = results.map((r) => ({
    ...r,
    name: r.caseId,
  }));
  const sorted = sortResults(sortableResults);

  const response: RunDetailResponse = {
    run,
    progress,
    results: sorted,
  };

  return success(response);
}

/**
 * GET /runs/{runId}/cases/{caseId}
 * Returns full result with transcript.
 */
async function handleGetCaseResult(
  runId: string,
  caseId: string
): Promise<APIGatewayResponse> {
  const [result, transcript, executionTrace] = await Promise.all([
    getCaseResult(runId, caseId),
    getTranscript(runId, caseId),
    getCaseExecutionTrace(runId, caseId),
  ]);

  if (!result) {
    return notFound(`Result for case '${caseId}' in run '${runId}' not found`);
  }

  let finalTrace = executionTrace;
  let traceRefetchStatus: TraceRefetchStatus | undefined;

  // Lazy re-fetch: if the trace is a pre-feature trace, attempt to re-fetch
  // enriched data from ListSpans.
  if (finalTrace && isPreFeatureTrace(finalTrace)) {
    // We need the run's startTime to check the retention window.
    // The result row has a `startTime` via the run; we look it up via the
    // SUMMARY record (lightweight GetItem, usually cached by DDB).
    const runStartTime = await getRunStartTime(runId);
    if (runStartTime) {
      const refetchResult = await attemptLazyRefetch(
        runId,
        caseId,
        finalTrace,
        runStartTime,
      );
      finalTrace = refetchResult.trace;
      traceRefetchStatus = refetchResult.status;
    }
  }

  const response: CaseDetailResponse = {
    result,
    transcript,
    ...(finalTrace ? { executionTrace: finalTrace } : {}),
    ...(traceRefetchStatus ? { traceRefetchStatus } : {}),
  };

  return success(response);
}

/**
 * Read the per-case ExecutionTrace persisted at
 * `PK=RUN#{runId}#CASE#{caseId}, SK=TRACE`. The shape mirrors what
 * `analysis.ts` does — `steps` is stored as a JSON string to keep the
 * DDB item under nested-attribute limits, so we re-parse it here.
 *
 * Missing trace returns `null` rather than throwing; the case-detail
 * GET still succeeds (transcript-only) and the GUI renders a "no
 * reasoning trace was captured" empty state.
 */
async function getCaseExecutionTrace(
  runId: string,
  caseId: string,
): Promise<ExecutionTrace | null> {
  const client = getDDBClient();
  try {
    const result = await client.send(
      new GetCommand({
        TableName: TABLE_NAME,
        Key: {
          PK: `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
          SK: SK_PATTERNS.TRACE,
        },
      }),
    );
    if (!result.Item) return null;
    const data = stripKeys<Record<string, unknown>>(
      result.Item as Record<string, unknown>,
    );
    const steps =
      typeof data.steps === "string"
        ? (JSON.parse(data.steps) as ExecutionTrace["steps"])
        : ((data.steps as ExecutionTrace["steps"]) ?? []);
    return {
      sessionId: (data.sessionId as string) ?? "",
      steps,
      toolSequence: (data.toolSequence as string[]) ?? [],
      aiAgentName: data.aiAgentName as string | undefined,
      aiAgentType: data.aiAgentType as string | undefined,
      capturedAt: (data.capturedAt as string) ?? "",
    };
  } catch {
    // Soft-fail per analysis.ts convention — the case-detail page is
    // useful even without a reasoning trace.
    return null;
  }
}

/**
 * Retrieves the run's startTime from the SUMMARY record.
 * Returns the ISO 8601 startTime string, or null if not found.
 * Used by lazy re-fetch to determine whether the run is within
 * the ListSpans retention window.
 */
async function getRunStartTime(runId: string): Promise<string | null> {
  const client = getDDBClient();
  try {
    const result = await client.send(
      new GetCommand({
        TableName: TABLE_NAME,
        Key: {
          PK: `${PK_PATTERNS.RUN}${runId}`,
          SK: "SUMMARY",
        },
        ProjectionExpression: "startTime",
      }),
    );
    if (result.Item?.startTime) {
      return result.Item.startTime as string;
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * GET /runs/{runId}/snapshot
 * Returns the AgentSnapshot persisted at run start. Used by the Compare
 * Runs page to diff agent configurations across two runs.
 */
async function handleGetRunSnapshot(runId: string): Promise<APIGatewayResponse> {
  const client = getDDBClient();
  const result = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: SK_PATTERNS.SNAPSHOT,
      },
    }),
  );
  if (!result.Item) {
    return notFound(`Snapshot for run '${runId}' not found`);
  }
  // Strip the PK/SK keys and return the snapshot fields verbatim. The
  // shape matches AgentSnapshot from shared/types.ts.
  const snapshot = stripKeys<Record<string, unknown>>(
    result.Item as Record<string, unknown>,
  );
  return success({ snapshot });
}

/**
 * GET /suites/{suiteId}/runs
 * Lists run history, paginated at 50, descending by timestamp.
 */
async function handleListRunHistory(
  suiteId: string,
  nextToken?: string
): Promise<APIGatewayResponse> {
  // Decode pagination token if provided
  let exclusiveStartKey: Record<string, unknown> | undefined;
  if (nextToken) {
    try {
      exclusiveStartKey = JSON.parse(
        Buffer.from(nextToken, "base64").toString("utf-8")
      );
    } catch {
      return badRequest("Invalid nextToken");
    }
  }

  const { runs, lastEvaluatedKey } = await listRunHistory(
    suiteId,
    exclusiveStartKey
  );

  const response: RunHistoryResponse = {
    runs,
  };

  // Encode pagination token if there are more results
  if (lastEvaluatedKey) {
    response.nextToken = Buffer.from(
      JSON.stringify(lastEvaluatedKey)
    ).toString("base64");
  }

  return success(response);
}

/**
 * Query every experiment record for a run.
 *
 * Experiments live at PK=RUN#{runId}, SK=EXPERIMENT#{experimentId} per the
 * implement-recommendations spec. We query that partition with a
 * begins_with(SK, "EXPERIMENT#") condition and return the records in
 * reverse chronological order (newest first).
 *
 * The SK is `EXPERIMENT#{experimentId}` where experimentId is a UUID v4 —
 * not a sortable timestamp. We sort the returned records by `createdAt`
 * (ISO 8601) descending after the query so the newest experiment shows
 * first regardless of UUID ordering.
 */
async function getRunExperiments(runId: string): Promise<ExperimentRecord[]> {
  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}`,
        ":skPrefix": SK_PATTERNS.EXPERIMENT,
      },
    })
  );

  const items = result.Items ?? [];
  const experiments = items.map(
    (item) => stripKeys<ExperimentRecord>(item as Record<string, unknown>)
  );

  // Sort by createdAt descending (newest first). Records without
  // createdAt sort to the end — defensive against any malformed
  // pre-feature record.
  experiments.sort((a, b) => {
    const aTime = a.createdAt ?? "";
    const bTime = b.createdAt ?? "";
    if (aTime === bTime) return 0;
    return aTime > bTime ? -1 : 1;
  });

  return experiments;
}

/**
 * GET /runs/{runId}/experiments
 *
 * Returns every experiment associated with a run, newest first. Empty
 * list (rather than 404) when no experiments exist — this lets the Run
 * Dashboard's mount-time fetch no-op silently.
 */
async function handleListRunExperiments(
  runId: string
): Promise<APIGatewayResponse> {
  const experiments = await getRunExperiments(runId);
  const response: RunExperimentsResponse = { experiments };
  return success(response);
}

// ---------------------------------------------------------------------------
// Main handler — API Gateway proxy integration routing
// ---------------------------------------------------------------------------

/**
 * Lambda handler for Results API.
 * Routes based on httpMethod + resource path.
 */
export async function handler(event: APIGatewayEvent): Promise<APIGatewayResponse> {
  const { httpMethod, resource, pathParameters, queryStringParameters } = event;

  if (httpMethod !== "GET") {
    return methodNotAllowed();
  }

  try {
    // Route: GET /runs/{runId}
    if (resource === "/runs/{runId}") {
      const runId = pathParameters?.runId;
      if (!runId) {
        return badRequest("Missing runId path parameter");
      }
      const suiteId = queryStringParameters?.suiteId;
      // Extract the tenantId from the JWT claims so the no-hint fallback
      // in getRunByRunId can scan the caller's suites. Cognito puts the
      // user's sub claim under requestContext.authorizer.claims.sub —
      // matches the convention used by suites.ts and runs.ts. We treat
      // the field as opaque here; lower layers compose it into a PK.
      const tenantId =
        (event.requestContext?.authorizer?.claims?.sub as string | undefined) ??
        undefined;
      return await handleGetRun(runId, suiteId, tenantId);
    }

    // Route: GET /runs/{runId}/cases/{caseId}
    if (resource === "/runs/{runId}/cases/{caseId}") {
      const runId = pathParameters?.runId;
      const caseId = pathParameters?.caseId;
      if (!runId || !caseId) {
        return badRequest("Missing runId or caseId path parameter");
      }
      return await handleGetCaseResult(runId, caseId);
    }

    // Route: GET /runs/{runId}/snapshot
    // Returns the AgentSnapshot the orchestration pipeline persisted at
    // run start (PK=RUN#{runId}, SK=SNAPSHOT). Used by the Compare Runs
    // page to diff agent configuration across two runs.
    if (resource === "/runs/{runId}/snapshot") {
      const runId = pathParameters?.runId;
      if (!runId) {
        return badRequest("Missing runId path parameter");
      }
      return await handleGetRunSnapshot(runId);
    }

    // Route: GET /runs/{runId}/experiments
    // Lists every experiment associated with a run, newest first.
    // Returns `{ experiments: [] }` (HTTP 200) when no experiments
    // exist — the Run Dashboard's mount-time fetch needs a non-error
    // empty result so it can no-op silently for runs that haven't had
    // any experiments triggered.
    if (resource === "/runs/{runId}/experiments") {
      const runId = pathParameters?.runId;
      if (!runId) {
        return badRequest("Missing runId path parameter");
      }
      return await handleListRunExperiments(runId);
    }

    // Route: GET /suites/{suiteId}/runs
    if (resource === "/suites/{suiteId}/runs") {
      const suiteId = pathParameters?.suiteId;
      if (!suiteId) {
        return badRequest("Missing suiteId path parameter");
      }
      const nextToken = queryStringParameters?.nextToken;
      return await handleListRunHistory(suiteId, nextToken);
    }

    return notFound(`Unknown route: ${httpMethod} ${resource}`);
  } catch (error) {
    console.error(
      "[results] Handler error:",
      error instanceof Error ? error.message : error
    );
    return serverError("Internal server error");
  }
}
