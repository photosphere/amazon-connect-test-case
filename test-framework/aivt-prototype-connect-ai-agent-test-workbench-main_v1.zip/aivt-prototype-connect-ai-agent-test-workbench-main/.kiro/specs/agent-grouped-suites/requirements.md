# Requirements Document

## Introduction

The Test Suites page currently renders suites in a flat table. This feature replaces the flat list with an agent-grouped layout: agents appear as expandable section headers, and expanding an agent reveals its suites inline. The backend GET /suites endpoint is enriched to include the resolved agent name alongside each suite's agentId, eliminating client-side agent-name resolution.

## Glossary

- **Suites_Page**: The React page component (TestSuites.tsx) responsible for rendering the test suites listing at the `/suites` route.
- **Suites_API**: The backend Lambda handler that serves `GET /suites` and returns the list of test suites for the authenticated tenant.
- **Agent_Section**: A Cloudscape ExpandableSection on the Suites_Page that groups all suites belonging to a single agent under a collapsible header displaying the agent name.
- **TestSuite**: A persisted record representing a collection of test cases targeting a specific agent, identified by `suiteId` and associated with an `agentId`.
- **AgentSummary**: A lightweight agent descriptor containing `agentId`, `name`, `type`, `toolCount`, and `modelId`, sourced from the Connect Q ListAIAgents API.

## Requirements

### Requirement 1: Backend Agent-Name Enrichment

**User Story:** As a frontend consumer, I want the GET /suites response to include the agent's display name on each suite record, so that the UI can group and label suites by agent without making separate API calls.

#### Acceptance Criteria

1. WHEN a client sends a GET request to `/suites`, THE Suites_API SHALL return each TestSuite object with an `agentName` string field containing the resolved human-readable name of the agent identified by `agentId`.
2. IF the Suites_API cannot resolve the agent name for a given `agentId` (agent deleted, API error), THEN THE Suites_API SHALL set `agentName` to the literal `agentId` value as a fallback.
3. THE Suites_API SHALL resolve agent names by calling the existing agent-listing logic (Connect Q ListAIAgents API or cached agent list) within the same request lifecycle.
4. THE Suites_API SHALL NOT persist `agentName` to DynamoDB; the field is computed at read time only.

### Requirement 2: Agent-Grouped Layout on Suites Page

**User Story:** As a platform user, I want test suites grouped by agent on the Suites page, so that I can quickly locate suites for the agent I am working with.

#### Acceptance Criteria

1. THE Suites_Page SHALL display agents as expandable section headers, with each Agent_Section header showing the agent name.
2. WHEN the Suites_Page loads suite data, THE Suites_Page SHALL group suites by their `agentName` field and render one Agent_Section per distinct agent.
3. WHEN a user clicks an Agent_Section header, THE Suites_Page SHALL expand or collapse the section inline without navigating to a different page.
4. THE Suites_Page SHALL display the count of suites belonging to each agent in the Agent_Section header (e.g., "AgentName (3 suites)").
5. THE Suites_Page SHALL render each expanded Agent_Section's suites in a table with columns: Suite Name, Description, Last Run, Last Updated.
6. THE Suites_Page SHALL NOT display an "Agent ID" column within the per-agent suite table, since the grouping already conveys agent association.

### Requirement 3: Suite Interactions Within Grouped Layout

**User Story:** As a platform user, I want to retain all existing suite actions (view, run, delete, create) within the new grouped layout, so that I lose no functionality.

#### Acceptance Criteria

1. WHEN a user clicks a suite name link inside an Agent_Section, THE Suites_Page SHALL navigate to the suite detail page at `/suites/{suiteId}`.
2. THE Suites_Page SHALL retain the "Create suite" button in the page header with the same navigation behavior (route to `/suites/create`).
3. WHEN a user selects a suite row and clicks "Run suite", THE Suites_Page SHALL launch a run for that suite using the existing POST /runs flow.
4. WHEN a user selects a suite row and clicks "Delete", THE Suites_Page SHALL display the existing confirmation modal and cascade-delete on confirmation.
5. WHEN a user clicks "Refresh", THE Suites_Page SHALL re-fetch the suites list and re-render the grouped layout with updated data.

### Requirement 4: Empty and Loading States

**User Story:** As a platform user, I want clear feedback when the page is loading or when no suites exist, so that I understand the current state.

#### Acceptance Criteria

1. WHILE the Suites_Page is fetching suite data, THE Suites_Page SHALL display a loading indicator.
2. WHEN the Suites_Page receives an empty suites list, THE Suites_Page SHALL display an empty state message with a "Create suite" call to action.
3. IF the Suites_Page fetch fails, THEN THE Suites_Page SHALL display an error alert with a "Retry" action.
4. WHEN an Agent_Section contains suites with pending last-run data, THE Suites_Page SHALL display a spinner in the Last Run column for those suites.

### Requirement 5: Agent Section Ordering and Default State

**User Story:** As a platform user, I want agents ordered predictably and sections expanded by default, so that I can scan all suites without extra clicks on first load.

#### Acceptance Criteria

1. THE Suites_Page SHALL order Agent_Sections alphabetically by agent name.
2. THE Suites_Page SHALL render all Agent_Sections in the expanded state on initial page load.
3. WHEN a user collapses an Agent_Section and later triggers a Refresh, THE Suites_Page SHALL preserve the user's expand/collapse state for that section.
