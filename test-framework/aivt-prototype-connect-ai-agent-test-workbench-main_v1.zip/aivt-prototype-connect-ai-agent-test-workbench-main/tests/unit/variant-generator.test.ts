/**
 * Unit tests for the Variant Generator module.
 *
 * Tests the core logic of variant generation including:
 * - Bedrock response parsing
 * - Variant validation (structural, scope containment, system prompt safety)
 * - Retry behavior for failed variants
 * - Correct Bedrock Converse configuration sourced from the
 *   `variant_generation` registry entry (Wave 2 — Task 17.4)
 *
 * The variant generator resolves its prompt via `resolvePromptForRun(...)`
 * per the Wave-2 migration of the prompt-management spec. These tests
 * inject a stub Prompts_Store via `_setPromptStore` so the resolver
 * returns the registry's bundled defaults without touching DynamoDB.
 * Same pattern as `tests/unit/customer-simulator.test.ts`.
 */

import { describe, it, expect, vi, afterEach, beforeEach } from "vitest";

import {
  generateVariants,
  _setBedrockClient,
  type VariantGenerationInput,
} from "@backend/orchestration/variant-generator";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "@backend/orchestration/prompt-registry/runtime";
import { PROMPT_REGISTRY } from "@backend/orchestration/prompt-registry";
import type { DynamoDBService } from "@backend/services/dynamodb";
import type {
  PerSuiteRecommendation,
  AgentSnapshot,
  ToolSurface,
} from "@shared/types";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const RUN_ID = "run-variant-generator-test";

function makeRecommendation(
  overrides: Partial<PerSuiteRecommendation> = {}
): PerSuiteRecommendation {
  return {
    targetField: "tool_instruction" as ToolSurface,
    targetName: "verifyIdentity",
    currentText: "Verify the customer identity.",
    suggestedText: "Verify the customer identity before proceeding.",
    rationale: "More explicit instruction improves accuracy.",
    priority: 1,
    predictedImpact: {
      liftedCaseIds: ["case-1"],
      rationale: "Expected to fix identity verification failures.",
    },
    ...overrides,
  };
}

function makeAgentSnapshot(
  overrides: Partial<AgentSnapshot> = {}
): AgentSnapshot {
  return {
    tools: [
      {
        toolName: "verifyIdentity",
        toolType: "KNOWLEDGE_BASE",
        description: "Verifies the customer's identity",
        instruction: "Verify the customer identity.",
        inputSchema: {},
        examples: ["Example: Customer says 'my account number is 123'"],
      },
    ],
    systemPrompt: "You are a helpful assistant.\n\n{{$.Custom.Greeting}}",
    modelId: "us.anthropic.claude-sonnet-4-20250514-v1:0",
    capturedAt: "2025-01-15T10:00:00Z",
    ...overrides,
  };
}

function makeInput(
  overrides: Partial<VariantGenerationInput> = {}
): VariantGenerationInput {
  return {
    sourceRecommendations: [makeRecommendation()],
    agentSnapshot: makeAgentSnapshot(),
    agentId: "agent-123",
    runId: RUN_ID,
    ...overrides,
  };
}

/**
 * Creates a valid Bedrock response with 3 variants.
 */
function makeValidBedrockResponse(
  sourceRecs: PerSuiteRecommendation[] = [makeRecommendation()]
) {
  return JSON.stringify({
    variants: [
      {
        variantLetter: "A",
        strategy: "conciseness",
        recommendations: sourceRecs.map((r) => ({
          targetField: r.targetField,
          targetName: r.targetName,
          currentText: r.currentText,
          suggestedText: "Verify identity first.",
          rationale: "Shorter instruction.",
        })),
      },
      {
        variantLetter: "B",
        strategy: "example-heavy",
        recommendations: sourceRecs.map((r) => ({
          targetField: r.targetField,
          targetName: r.targetName,
          currentText: r.currentText,
          suggestedText:
            "Verify the customer identity. Ask for account number or SSN last 4.",
          rationale: "Added specifics.",
        })),
      },
      {
        variantLetter: "C",
        strategy: "restructured",
        recommendations: sourceRecs.map((r) => ({
          targetField: r.targetField,
          targetName: r.targetName,
          currentText: r.currentText,
          suggestedText:
            "Before any action: 1. Greet customer 2. Verify identity 3. Proceed",
          rationale: "Step-based format.",
        })),
      },
    ],
  });
}

function makeBedrockMock(responseText: string | (() => string)) {
  return {
    send: vi.fn().mockImplementation(() => {
      const text =
        typeof responseText === "function" ? responseText() : responseText;
      return Promise.resolve({
        output: {
          message: {
            content: [{ text }],
          },
        },
      });
    }),
  };
}

/**
 * Inject a stub Prompts_Store so `resolvePromptForRun("variant_generation", ...)`
 * returns the registry's bundled defaults without touching DynamoDB.
 *
 * The variant generator uses `resolvePromptForRun`, which reads the run
 * snapshot first and falls back to the live registry. We wire
 * `getSnapshot` to return null so the resolver always traverses the
 * live-registry fallback path, then return an empty overrides map so
 * the resolver yields the bundled `variant_generation` definition
 * (Claude Sonnet 4.6, default text, default inference values).
 */
function injectDefaultPromptStore(): void {
  _clearPromptRegistryCaches();
  const store = {
    getSnapshot: vi.fn().mockResolvedValue(null),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  } as unknown as DynamoDBService;
  _setPromptRegistryStore(store);
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("variant-generator", () => {
  beforeEach(() => {
    _setBedrockClient(null);
    injectDefaultPromptStore();
  });

  afterEach(() => {
    _setBedrockClient(null);
    _setPromptRegistryStore(null);
    _clearPromptRegistryCaches();
  });

  describe("generateVariants — happy path", () => {
    it("returns 3 valid variants when all pass validation", async () => {
      const input = makeInput();
      const mock = makeBedrockMock(makeValidBedrockResponse());
      _setBedrockClient(mock);

      const result = await generateVariants(input);

      expect(result.variants).toHaveLength(3);
      expect(result.failedVariants).toHaveLength(0);
      expect(result.variants[0].variantLetter).toBe("A");
      expect(result.variants[0].strategy).toBe("conciseness");
      expect(result.variants[1].variantLetter).toBe("B");
      expect(result.variants[2].variantLetter).toBe("C");
    });

    it("calls Bedrock with the registry-resolved Converse shape (Anthropic 4.x: maxTokens only, no temperature)", async () => {
      const input = makeInput();
      const mock = makeBedrockMock(makeValidBedrockResponse());
      _setBedrockClient(mock);

      await generateVariants(input);

      const command = mock.send.mock.calls[0][0];
      const cmdInput = command.input;

      // The registry's bundled `variant_generation` default points at
      // the `claude_sonnet_4_6` model whose capability profile is
      // `anthropic_claude_4x` — so `buildInferenceConfig` emits exactly
      // `{ inferenceConfig: { maxTokens: <default> } }` with no
      // `temperature`, `topP`, `topK`, or `stopSequences`. The 0.7
      // `temperature` value declared in the registry's
      // `defaultInferenceValues` is silently dropped per R17.4 (the
      // Anthropic 4.x profile forbids it). This explicit assertion
      // catches any future regression that silently switches the
      // default model and lets `temperature` slip onto the wire.
      const definition = PROMPT_REGISTRY.variant_generation;
      expect(cmdInput.inferenceConfig.maxTokens).toBe(
        definition.defaultInferenceValues.maxTokens,
      );
      expect(cmdInput.inferenceConfig.temperature).toBeUndefined();
      expect(cmdInput.inferenceConfig.topP).toBeUndefined();
      expect(cmdInput.additionalModelRequestFields).toBeUndefined();

      // Verify the modelId comes from the registry's resolved
      // SupportedModel entry, not from a hard-coded literal or env var.
      expect(cmdInput.modelId).toMatch(/^us\.anthropic\.claude-sonnet/);

      // Verify the system prompt was rendered from the registry's
      // bundled default text.
      const systemText = cmdInput.system?.[0]?.text ?? "";
      expect(systemText).toContain("expert AI agent prompt engineer");
      expect(systemText).toBe(definition.defaultText);
    });

    it("each variant contains recommendations with correct structure", async () => {
      const input = makeInput();
      const mock = makeBedrockMock(makeValidBedrockResponse());
      _setBedrockClient(mock);

      const result = await generateVariants(input);

      for (const variant of result.variants) {
        expect(variant.recommendations.length).toBeGreaterThan(0);
        for (const rec of variant.recommendations) {
          expect(rec.targetField).toBe("tool_instruction");
          expect(rec.targetName).toBe("verifyIdentity");
          expect(rec.suggestedText.length).toBeGreaterThan(0);
        }
      }
    });

    it("does not read process.env.VARIANT_GENERATOR_MODEL_ID (registry is the source of truth)", () => {
      // The Wave-2 migration removed the `process.env.*_MODEL_ID ?? "..."`
      // fallback from the source. The static AST allow-list test
      // (`tests/properties/prompts-registry-only-resolution.property.test.ts`)
      // pins this at the source-tree level, but we also assert it here
      // as a fast feedback signal.
      const fs = require("node:fs");
      const path = require("node:path");
      const sourcePath = path.resolve(
        __dirname,
        "..",
        "..",
        "src/backend/orchestration/variant-generator.ts",
      );
      const source = fs.readFileSync(sourcePath, "utf8");
      expect(source).not.toMatch(
        /process\.env\.[A-Z][A-Z0-9_]*_MODEL_ID\s*\?\?/,
      );
    });
  });

  describe("generateVariants — validation failures and retry", () => {
    it("retries a variant that fails scope containment and succeeds on retry", async () => {
      // First call returns a variant A with an out-of-scope surface
      const badResponse = JSON.stringify({
        variants: [
          {
            variantLetter: "A",
            strategy: "conciseness",
            recommendations: [
              {
                targetField: "system_prompt", // not in source!
                targetName: "system_prompt",
                currentText: "You are a helpful assistant.",
                suggestedText: "You help customers.",
                rationale: "Shorter.",
              },
            ],
          },
          {
            variantLetter: "B",
            strategy: "example-heavy",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Verify identity with examples.",
                rationale: "Added examples.",
              },
            ],
          },
          {
            variantLetter: "C",
            strategy: "restructured",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Step 1: Verify. Step 2: Proceed.",
                rationale: "Restructured.",
              },
            ],
          },
        ],
      });

      // Retry response fixes the issue
      const fixedResponse = JSON.stringify({
        variants: [
          {
            variantLetter: "A",
            strategy: "conciseness",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Verify identity.",
                rationale: "Concise.",
              },
            ],
          },
        ],
      });

      let callCount = 0;
      const mock = {
        send: vi.fn().mockImplementation(() => {
          callCount++;
          const text = callCount === 1 ? badResponse : fixedResponse;
          return Promise.resolve({
            output: { message: { content: [{ text }] } },
          });
        }),
      };
      _setBedrockClient(mock);

      const input = makeInput();
      const result = await generateVariants(input);

      // All 3 should pass (B and C from first call, A from retry)
      expect(result.variants).toHaveLength(3);
      expect(result.failedVariants).toHaveLength(0);
      expect(mock.send).toHaveBeenCalledTimes(2);
    });

    it("marks variant as failed when retry also fails validation", async () => {
      // Both initial and retry have invalid surface
      const badResponse = JSON.stringify({
        variants: [
          {
            variantLetter: "A",
            strategy: "conciseness",
            recommendations: [
              {
                targetField: "system_prompt",
                targetName: "system_prompt",
                currentText: "original",
                suggestedText: "changed",
                rationale: "Shorter.",
              },
            ],
          },
          {
            variantLetter: "B",
            strategy: "example-heavy",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Verify with examples.",
                rationale: "Better.",
              },
            ],
          },
          {
            variantLetter: "C",
            strategy: "restructured",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Steps: verify then proceed.",
                rationale: "Restructured.",
              },
            ],
          },
        ],
      });

      // Retry still returns out-of-scope
      const stillBadResponse = JSON.stringify({
        variants: [
          {
            variantLetter: "A",
            strategy: "conciseness",
            recommendations: [
              {
                targetField: "system_prompt",
                targetName: "system_prompt",
                currentText: "original",
                suggestedText: "still bad",
                rationale: "Still out of scope.",
              },
            ],
          },
        ],
      });

      let callCount = 0;
      const mock = {
        send: vi.fn().mockImplementation(() => {
          callCount++;
          const text = callCount === 1 ? badResponse : stillBadResponse;
          return Promise.resolve({
            output: { message: { content: [{ text }] } },
          });
        }),
      };
      _setBedrockClient(mock);

      const input = makeInput();
      const result = await generateVariants(input);

      expect(result.variants).toHaveLength(2); // B and C pass
      expect(result.failedVariants).toEqual(["A"]);
    });

    it("marks variant as failed when retry Bedrock call throws", async () => {
      const badResponse = JSON.stringify({
        variants: [
          {
            variantLetter: "A",
            strategy: "conciseness",
            recommendations: [
              {
                targetField: "tool_description", // not in source
                targetName: "verifyIdentity",
                currentText: "Verifies customer identity.",
                suggestedText: "Identity check.",
                rationale: "Shorter.",
              },
            ],
          },
          {
            variantLetter: "B",
            strategy: "example-heavy",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Verify with examples.",
                rationale: "Better.",
              },
            ],
          },
          {
            variantLetter: "C",
            strategy: "restructured",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Steps: verify then proceed.",
                rationale: "Restructured.",
              },
            ],
          },
        ],
      });

      let callCount = 0;
      const mock = {
        send: vi.fn().mockImplementation(() => {
          callCount++;
          if (callCount === 1) {
            return Promise.resolve({
              output: { message: { content: [{ text: badResponse }] } },
            });
          }
          return Promise.reject(new Error("Bedrock unavailable"));
        }),
      };
      _setBedrockClient(mock);

      const input = makeInput();
      const result = await generateVariants(input);

      expect(result.variants).toHaveLength(2);
      expect(result.failedVariants).toEqual(["A"]);
    });
  });

  describe("generateVariants — structural validation", () => {
    it("rejects variant with empty targetName", async () => {
      const response = JSON.stringify({
        variants: [
          {
            variantLetter: "A",
            strategy: "conciseness",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "", // invalid
                currentText: "Something",
                suggestedText: "Shorter",
                rationale: "Concise.",
              },
            ],
          },
          {
            variantLetter: "B",
            strategy: "example-heavy",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Verify with examples.",
                rationale: "Better.",
              },
            ],
          },
          {
            variantLetter: "C",
            strategy: "restructured",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "verifyIdentity",
                currentText: "Verify the customer identity.",
                suggestedText: "Steps.",
                rationale: "Restructured.",
              },
            ],
          },
        ],
      });

      // Retry also has empty targetName
      const retryResponse = JSON.stringify({
        variants: [
          {
            variantLetter: "A",
            strategy: "conciseness",
            recommendations: [
              {
                targetField: "tool_instruction",
                targetName: "",
                currentText: "Something",
                suggestedText: "Shorter",
                rationale: "Still bad.",
              },
            ],
          },
        ],
      });

      let callCount = 0;
      const mock = {
        send: vi.fn().mockImplementation(() => {
          callCount++;
          const text = callCount === 1 ? response : retryResponse;
          return Promise.resolve({
            output: { message: { content: [{ text }] } },
          });
        }),
      };
      _setBedrockClient(mock);

      const input = makeInput();
      const result = await generateVariants(input);

      expect(result.variants).toHaveLength(2);
      expect(result.failedVariants).toEqual(["A"]);
    });
  });

  describe("generateVariants — JSON parsing", () => {
    it("handles response wrapped in code fences", async () => {
      const jsonContent = makeValidBedrockResponse();
      const wrappedResponse = "```json\n" + jsonContent + "\n```";

      const mock = makeBedrockMock(wrappedResponse);
      _setBedrockClient(mock);

      const input = makeInput();
      const result = await generateVariants(input);

      expect(result.variants).toHaveLength(3);
      expect(result.failedVariants).toHaveLength(0);
    });

    it("throws when response is not valid JSON", async () => {
      const mock = makeBedrockMock("This is not JSON at all");
      _setBedrockClient(mock);

      const input = makeInput();
      await expect(generateVariants(input)).rejects.toThrow(
        /Failed to parse Bedrock variant generation response as JSON/
      );
    });

    it("throws when response is empty", async () => {
      const mock = {
        send: vi.fn().mockResolvedValue({
          output: { message: { content: [{ text: "" }] } },
        }),
      };
      _setBedrockClient(mock);

      const input = makeInput();
      await expect(generateVariants(input)).rejects.toThrow(
        /Bedrock returned an empty variant generation response/
      );
    });
  });

  describe("generateVariants — throttle retry", () => {
    it("retries on ThrottlingException and succeeds", async () => {
      const validResponse = makeValidBedrockResponse();
      let callCount = 0;

      const mock = {
        send: vi.fn().mockImplementation(() => {
          callCount++;
          if (callCount === 1) {
            const err = new Error("Rate exceeded");
            (err as { name: string }).name = "ThrottlingException";
            return Promise.reject(err);
          }
          return Promise.resolve({
            output: { message: { content: [{ text: validResponse }] } },
          });
        }),
      };
      _setBedrockClient(mock);

      const input = makeInput();
      const result = await generateVariants(input);

      expect(result.variants).toHaveLength(3);
      expect(mock.send).toHaveBeenCalledTimes(2);
    });

    it("propagates non-throttling errors immediately", async () => {
      const mock = {
        send: vi.fn().mockImplementation(() => {
          const err = new Error("Access denied");
          (err as { name: string }).name = "AccessDeniedException";
          return Promise.reject(err);
        }),
      };
      _setBedrockClient(mock);

      const input = makeInput();
      await expect(generateVariants(input)).rejects.toThrow("Access denied");
      expect(mock.send).toHaveBeenCalledTimes(1);
    });
  });

  describe("generateVariants — registry resolution", () => {
    it("calls resolvePromptForRun with variant_generation and the supplied runId (snapshot path)", async () => {
      // Inject a snapshot that pins variant_generation so the resolver
      // takes the snapshot-first path. Verifies the runId is plumbed
      // through to the resolver and the snapshot triple wins.
      _clearPromptRegistryCaches();
      const definition = PROMPT_REGISTRY.variant_generation;
      const snapshotPrompts = {
        variant_generation: {
          text: definition.defaultText,
          modelKey: definition.defaultModelKey,
          modelId: "us.anthropic.claude-sonnet-4-6",
          inferenceParameters: definition.defaultInferenceValues,
          version: 0,
          capabilityProfileKey: "anthropic_claude_4x_lax" as const,
        },
      };
      const getSnapshot = vi.fn().mockResolvedValue({
        prompts: snapshotPrompts,
      });
      const listPromptOverrides = vi.fn();
      const store = {
        getSnapshot,
        listPromptOverrides,
      } as unknown as DynamoDBService;
      _setPromptRegistryStore(store);

      const mock = makeBedrockMock(makeValidBedrockResponse());
      _setBedrockClient(mock);

      const customRunId = "run-snapshot-path-1";
      const input = makeInput({ runId: customRunId });
      const result = await generateVariants(input);

      expect(result.variants).toHaveLength(3);
      // Snapshot path consulted with the supplied runId.
      expect(getSnapshot).toHaveBeenCalledWith(customRunId);
      // Live store NOT consulted because the snapshot pinned the prompt.
      expect(listPromptOverrides).not.toHaveBeenCalled();
    });
  });
});
