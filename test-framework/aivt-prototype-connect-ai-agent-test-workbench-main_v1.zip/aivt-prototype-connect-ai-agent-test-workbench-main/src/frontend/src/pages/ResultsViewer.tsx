import { useCallback, useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import Container from '@cloudscape-design/components/container';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Box from '@cloudscape-design/components/box';
import Alert from '@cloudscape-design/components/alert';
import StatusIndicator from '@cloudscape-design/components/status-indicator';
import Table, { type TableProps } from '@cloudscape-design/components/table';
import Spinner from '@cloudscape-design/components/spinner';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import Multiselect, { type MultiselectProps } from '@cloudscape-design/components/multiselect';
import Input from '@cloudscape-design/components/input';
import ProgressBar from '@cloudscape-design/components/progress-bar';
import { apiClient, ApiClientError } from '../api';
import type {
  TestRun,
  TestCaseResult,
  TranscriptTurn,
  ExecutionTrace,
} from '../../../shared/types';
import { RunStatus, CaseStatus } from '../../../shared/enums';
import { formatDurationMs } from '../../../shared/utils/time-formatting';
import { TimelineTranscript } from '../components/Transcript/TimelineTranscript';
import { FailureAnalysis } from './FailureAnalysis';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface RunProgress {
  totalCases: number;
  completed: number;
  passed: number;
  failed: number;
  errors: number;
  accuracy: number;
}

interface RunDetailResponse {
  run: TestRun;
  progress: RunProgress;
  results: TestCaseResult[];
}

interface CaseDetailResponse {
  result: TestCaseResult;
  transcript: TranscriptTurn[];
  /**
   * Structured turn-by-turn reasoning trace derived from the session's
   * ListSpans data. Optional because cases that errored before the
   * agent emitted any spans have no trace to persist (see
   * `ExecutionTrace` in `src/shared/types.ts`). The case-detail
   * endpoint already returns this field; the type just needs to know
   * about it so the rich-timeline render path compiles.
   */
  executionTrace?: ExecutionTrace;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const POLL_INTERVAL_MS = 3000;

const STATUS_PRIORITY: Record<string, number> = {
  [CaseStatus.ERROR]: 0,
  [CaseStatus.TIMED_OUT]: 1,
  [CaseStatus.FAILED]: 2,
  [CaseStatus.PASSED]: 3,
};

const STATUS_OPTIONS: MultiselectProps.Option[] = [
  { value: CaseStatus.PASSED, label: 'Passed' },
  { value: CaseStatus.FAILED, label: 'Failed' },
  { value: CaseStatus.ERROR, label: 'Error' },
  { value: CaseStatus.TIMED_OUT, label: 'Timed Out' },
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function caseStatusIndicator(status: CaseStatus) {
  switch (status) {
    case CaseStatus.PASSED:
      return <StatusIndicator type="success">Passed</StatusIndicator>;
    case CaseStatus.FAILED:
      return <StatusIndicator type="error">Failed</StatusIndicator>;
    case CaseStatus.ERROR:
      return <StatusIndicator type="warning">Error</StatusIndicator>;
    case CaseStatus.TIMED_OUT:
      return <StatusIndicator type="warning">Timed out</StatusIndicator>;
    default:
      return <StatusIndicator type="info">{status}</StatusIndicator>;
  }
}

function formatScore(score: number | undefined | null): string {
  if (score == null) return '—';
  return score.toFixed(2);
}

function sortResults(results: TestCaseResult[]): TestCaseResult[] {
  return [...results].sort((a, b) => {
    const priorityA = STATUS_PRIORITY[a.status] ?? 99;
    const priorityB = STATUS_PRIORITY[b.status] ?? 99;
    if (priorityA !== priorityB) return priorityA - priorityB;
    return a.caseId.localeCompare(b.caseId);
  });
}

/**
 * The Evaluation_Error_State (set by the Evaluation Lambda when AgentCore
 * Evaluate cannot produce a complete, mappable result) is the structural
 * signal that scores are unavailable for this case (Req 10.3 — error state
 * leaves all three score fields unset). The frontend renders the recorded
 * reason in place of scores when this is present (Reqs 10.4, 15.5),
 * replacing the previous "Fallback" badge heuristic which inferred a
 * fallback from the score shape.
 */
function hasEvaluationError(result: TestCaseResult): boolean {
  return result.evaluationError != null;
}

/**
 * Short label for the inline status indicator next to the case id. Surfaces
 * the failure category at a glance; the full reason is displayed in the
 * expandable section below the row. When the failure category is
 * `MISSING_EVALUATOR`, the names of the omitted evaluators are appended so
 * a reader can see which evaluator is missing without expanding the row.
 */
function evaluationErrorBadgeLabel(
  evaluationError: NonNullable<TestCaseResult['evaluationError']>
): string {
  if (
    evaluationError.code === 'MISSING_EVALUATOR' &&
    evaluationError.missingEvaluators &&
    evaluationError.missingEvaluators.length > 0
  ) {
    return `Missing evaluator: ${evaluationError.missingEvaluators.join(', ')}`;
  }
  switch (evaluationError.code) {
    case 'INSUFFICIENT_TRACE':
      return 'Insufficient trace';
    case 'TIMEOUT':
      return 'Evaluation timed out';
    case 'JUDGE_ERROR':
      return 'Judge error';
    case 'UNMAPPABLE_RESULT':
      return 'Unmappable result';
    case 'MISSING_EVALUATOR':
      return 'Missing evaluator';
    default:
      return 'Evaluation error';
  }
}

// ---------------------------------------------------------------------------
// Transcript Display Component
// ---------------------------------------------------------------------------

/**
 * Per-row transcript view rendered inside each expandable row in the run
 * dashboard's results table. Fetches the same `/runs/{runId}/cases/{caseId}`
 * payload the per-case detail page consumes and delegates rendering to the
 * shared {@link TimelineTranscript} component so both surfaces stay
 * structurally identical — same dedup rule (transcript agent turns
 * skipped when a trace is present), same noise-span filter, same
 * args / result / synthetic-control-tool rendering. The previous
 * minimal renderer that consumed only `TranscriptTurn[]` could not
 * surface tool arguments, tool results, agent reasoning, or
 * distinguish synthetic control-tool markers from real tool calls.
 */
function TranscriptView({
  runId,
  caseId,
}: {
  runId: string;
  caseId: string;
}) {
  const [transcript, setTranscript] = useState<TranscriptTurn[] | null>(null);
  const [executionTrace, setExecutionTrace] = useState<ExecutionTrace | null>(
    null
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    apiClient
      .get<CaseDetailResponse>(`/runs/${runId}/cases/${caseId}`)
      .then((response) => {
        if (!cancelled) {
          setTranscript(response.transcript);
          setExecutionTrace(response.executionTrace ?? null);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setError(
            err instanceof ApiClientError
              ? err.message
              : 'Failed to load transcript.'
          );
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [runId, caseId]);

  if (loading) {
    return (
      <Box padding="s">
        <Spinner /> Loading transcript...
      </Box>
    );
  }

  if (error) {
    return (
      <Alert type="error" statusIconAriaLabel="Error">
        {error}
      </Alert>
    );
  }

  // The shared component handles the (empty transcript ∧ no trace)
  // empty-state itself, but we keep the historic copy ("No transcript
  // available.") for parity with the surrounding dashboard chrome
  // when we have neither.
  if ((!transcript || transcript.length === 0) && !executionTrace) {
    return (
      <Box padding="s" color="text-status-inactive">
        No transcript available.
      </Box>
    );
  }

  return (
    <div style={{ padding: '8px 0' }}>
      <TimelineTranscript
        transcript={transcript ?? []}
        executionTrace={executionTrace}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main Component
// ---------------------------------------------------------------------------

export function ResultsViewer() {
  const { runId } = useParams<{ runId: string }>();

  // State
  const [run, setRun] = useState<TestRun | null>(null);
  const [progress, setProgress] = useState<RunProgress | null>(null);
  const [results, setResults] = useState<TestCaseResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filter state
  const [statusFilter, setStatusFilter] = useState<MultiselectProps.Option[]>([]);
  const [toolFilter, setToolFilter] = useState('');

  // Expanded rows
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  // Polling ref
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ---------------------------------------------------------------------------
  // Fetch run details
  // ---------------------------------------------------------------------------

  const fetchRunDetails = useCallback(async () => {
    if (!runId) return null;
    try {
      const response = await apiClient.get<RunDetailResponse>(`/runs/${runId}`);
      setRun(response.run);
      setProgress(response.progress);
      setResults(response.results);
      setError(null);
      return response.run;
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to fetch run details.');
      }
      return null;
    }
  }, [runId]);

  // ---------------------------------------------------------------------------
  // Initial fetch
  // ---------------------------------------------------------------------------

  useEffect(() => {
    setLoading(true);
    fetchRunDetails().finally(() => setLoading(false));
  }, [fetchRunDetails]);

  // ---------------------------------------------------------------------------
  // Polling while running
  // ---------------------------------------------------------------------------

  const isRunActive = run?.status === RunStatus.RUNNING;

  useEffect(() => {
    if (isRunActive) {
      pollRef.current = setInterval(async () => {
        const updatedRun = await fetchRunDetails();
        if (updatedRun && updatedRun.status !== RunStatus.RUNNING) {
          if (pollRef.current) {
            clearInterval(pollRef.current);
            pollRef.current = null;
          }
        }
      }, POLL_INTERVAL_MS);

      return () => {
        if (pollRef.current) {
          clearInterval(pollRef.current);
          pollRef.current = null;
        }
      };
    }
  }, [isRunActive, fetchRunDetails]);

  // ---------------------------------------------------------------------------
  // Filtering & sorting
  // ---------------------------------------------------------------------------

  const filteredResults = (() => {
    let filtered = results;

    // Status filter
    if (statusFilter.length > 0) {
      const selectedStatuses = new Set(statusFilter.map((o) => o.value));
      filtered = filtered.filter((r) => selectedStatuses.has(r.status));
    }

    // Tool filter
    if (toolFilter.trim()) {
      const term = toolFilter.trim().toLowerCase();
      filtered = filtered.filter((r) =>
        r.toolsInvoked.some((t) => t.toLowerCase().includes(term))
      );
    }

    return sortResults(filtered);
  })();

  // ---------------------------------------------------------------------------
  // Expand/collapse
  // ---------------------------------------------------------------------------

  const toggleRow = (caseId: string) => {
    setExpandedRows((prev) => {
      const next = new Set(prev);
      if (next.has(caseId)) {
        next.delete(caseId);
      } else {
        next.add(caseId);
      }
      return next;
    });
  };

  // ---------------------------------------------------------------------------
  // Summary calculations
  // ---------------------------------------------------------------------------

  const totalCases = progress?.totalCases ?? 0;
  const passedCount = progress?.passed ?? 0;
  const failedCount = progress?.failed ?? 0;
  const errorCount = progress?.errors ?? 0;
  const accuracy =
    totalCases > 0
      ? ((passedCount / totalCases) * 100).toFixed(1)
      : '0.0';

  // ---------------------------------------------------------------------------
  // Column definitions
  // ---------------------------------------------------------------------------

  const columnDefinitions: TableProps.ColumnDefinition<TestCaseResult>[] = [
    {
      id: 'caseId',
      header: 'Test Case',
      cell: (item) => (
        <SpaceBetween direction="horizontal" size="xs">
          <Box
            variant="code"
            fontSize="body-s"
          >
            {item.caseId}
          </Box>
          {hasEvaluationError(item) && item.evaluationError && (
            <StatusIndicator type="warning">
              {evaluationErrorBadgeLabel(item.evaluationError)}
            </StatusIndicator>
          )}
        </SpaceBetween>
      ),
      sortingField: 'caseId',
    },
    {
      id: 'status',
      header: 'Status',
      cell: (item) => caseStatusIndicator(item.status),
      sortingField: 'status',
    },
    {
      id: 'toolsInvoked',
      header: 'Tools Invoked',
      cell: (item) => item.toolsInvoked.join(' → ') || '—',
    },
    {
      id: 'turnCount',
      header: 'Turns',
      cell: (item) => item.turnCount,
      sortingField: 'turnCount',
    },
    {
      id: 'latencyMs',
      header: 'Duration',
      cell: (item) => formatDurationMs(item.latencyMs),
      sortingField: 'latencyMs',
    },
    {
      id: 'goalSuccess',
      header: 'Goal Success',
      cell: (item) => formatScore(item.goalSuccessScore),
    },
    {
      id: 'helpfulness',
      header: 'Helpfulness',
      cell: (item) => formatScore(item.helpfulnessScore),
    },
    {
      id: 'toolAccuracy',
      header: 'Tool Accuracy',
      cell: (item) => formatScore(item.toolAccuracyScore),
    },
  ];

  // ---------------------------------------------------------------------------
  // Render: Loading
  // ---------------------------------------------------------------------------

  if (loading) {
    return (
      <ContentLayout header={<Header variant="h1">Results Viewer</Header>}>
        <Box textAlign="center" padding="l">
          <Spinner size="large" />
        </Box>
      </ContentLayout>
    );
  }

  // ---------------------------------------------------------------------------
  // Render: Main
  // ---------------------------------------------------------------------------

  const progressPercentage =
    progress && progress.totalCases > 0
      ? Math.round((progress.completed / progress.totalCases) * 100)
      : 0;

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description={`Run: ${runId}`}
        >
          Results Viewer
        </Header>
      }
    >
      <SpaceBetween size="l">
        {error && (
          <Alert type="error" dismissible onDismiss={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* Progress indicator while running */}
        {isRunActive && (
          <ProgressBar
            value={progressPercentage}
            label="Test execution in progress"
            description={`${progress?.completed ?? 0} of ${totalCases} cases completed`}
            status="in-progress"
          />
        )}

        {/* Results Summary */}
        <Container header={<Header variant="h2">Results Summary</Header>}>
          <ColumnLayout columns={5} variant="text-grid">
            <div>
              <Box variant="awsui-key-label">Total</Box>
              <Box variant="p" fontSize="heading-l">
                {totalCases}
              </Box>
            </div>
            <div>
              <Box variant="awsui-key-label">Passed</Box>
              <Box variant="p" fontSize="heading-l" color="text-status-success">
                {passedCount}
              </Box>
            </div>
            <div>
              <Box variant="awsui-key-label">Failed</Box>
              <Box variant="p" fontSize="heading-l" color="text-status-error">
                {failedCount}
              </Box>
            </div>
            <div>
              <Box variant="awsui-key-label">Errors</Box>
              <Box variant="p" fontSize="heading-l" color="text-status-warning">
                {errorCount}
              </Box>
            </div>
            <div>
              <Box variant="awsui-key-label">Accuracy</Box>
              <Box variant="p" fontSize="heading-l">
                {accuracy}%
              </Box>
            </div>
          </ColumnLayout>
        </Container>

        {/* Filter Controls */}
        <Container header={<Header variant="h2">Filters</Header>}>
          <ColumnLayout columns={2}>
            <div>
              <Box variant="awsui-key-label">Status</Box>
              <Multiselect
                selectedOptions={statusFilter}
                onChange={({ detail }) =>
                  setStatusFilter(detail.selectedOptions as MultiselectProps.Option[])
                }
                options={STATUS_OPTIONS}
                placeholder="All statuses"
                hideTokens={false}
              />
            </div>
            <div>
              <Box variant="awsui-key-label">Tool Invoked</Box>
              <Input
                value={toolFilter}
                onChange={({ detail }) => setToolFilter(detail.value)}
                placeholder="Filter by tool name..."
                type="search"
              />
            </div>
          </ColumnLayout>
        </Container>

        {/* Results Table */}
        <Container header={<Header variant="h2">Test Case Results</Header>}>
          <Table
            columnDefinitions={columnDefinitions}
            items={filteredResults}
            loading={loading}
            loadingText="Loading results..."
            trackBy="caseId"
            variant="embedded"
            empty={
              <Box textAlign="center" padding="l">
                <SpaceBetween size="m">
                  <b>No results</b>
                  <Box variant="p" color="inherit">
                    {isRunActive
                      ? 'Results will appear as test cases complete.'
                      : 'No test case results match the current filters.'}
                  </Box>
                </SpaceBetween>
              </Box>
            }
            header={
              <Header counter={`(${filteredResults.length})`}>
                Results
              </Header>
            }
          />

          {/* Expandable rows rendered below each row */}
          {filteredResults.map((result) => (
            <div key={result.caseId} style={{ marginTop: '4px' }}>
              <ExpandableSection
                headerText={`${result.caseId} — Transcript`}
                expanded={expandedRows.has(result.caseId)}
                onChange={() => toggleRow(result.caseId)}
                variant="footer"
              >
                {hasEvaluationError(result) && result.evaluationError && (
                  <Alert
                    type="warning"
                    statusIconAriaLabel="Warning"
                    header={`Evaluation unavailable (${result.evaluationError.code})`}
                  >
                    <SpaceBetween size="xs">
                      <Box>{result.evaluationError.reason}</Box>
                      {result.evaluationError.code === 'MISSING_EVALUATOR' &&
                        result.evaluationError.missingEvaluators &&
                        result.evaluationError.missingEvaluators.length > 0 && (
                          <Box variant="small">
                            Missing evaluators:{' '}
                            {result.evaluationError.missingEvaluators.join(', ')}
                          </Box>
                        )}
                    </SpaceBetween>
                  </Alert>
                )}
                {runId && (
                  <TranscriptView runId={runId} caseId={result.caseId} />
                )}
              </ExpandableSection>
            </div>
          ))}
        </Container>

        {/* Failure Analysis Panel — shown when run is complete and has failures */}
        {!isRunActive && failedCount > 0 && runId && (
          <FailureAnalysis runId={runId} suiteId={run?.suiteId} />
        )}
      </SpaceBetween>
    </ContentLayout>
  );
}
