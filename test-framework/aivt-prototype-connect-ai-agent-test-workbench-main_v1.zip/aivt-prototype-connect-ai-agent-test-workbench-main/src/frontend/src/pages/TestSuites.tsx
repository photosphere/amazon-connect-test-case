import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import Table, { type TableProps } from '@cloudscape-design/components/table';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Alert from '@cloudscape-design/components/alert';
import Modal from '@cloudscape-design/components/modal';
import StatusIndicator, {
  type StatusIndicatorProps,
} from '@cloudscape-design/components/status-indicator';
import Spinner from '@cloudscape-design/components/spinner';
import Link from '@cloudscape-design/components/link';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import { apiClient, ApiClientError } from '../api';
import { RunStatus } from '../../../shared/enums';
import type { TestRun, EnrichedTestSuite } from '../../../shared/types';
import { useActiveRunsContext } from '../hooks/ActiveRunsContext';
import { groupSuitesByAgent, type AgentGroup } from '../utils/groupSuites';
import { mergeExpandedAgents } from '../utils/expandedAgents';

interface ListSuitesResponse {
  suites: EnrichedTestSuite[];
}

interface ListRunsResponse {
  runs: TestRun[];
}

/** Live-updating status the Suites list shows in the "Last Run" column. */
interface LastRunInfo {
  /** The most-recent run's id, or `undefined` if the suite has never run. */
  runId?: string;
  /** Run status from the persisted `TestRun.status` field, or `undefined`. */
  status?: RunStatus;
  /** Pass/fail summary on the most recent run, when available. */
  passed?: number;
  totalCases?: number;
  /** ISO timestamp of the most recent run's start time, when available. */
  startTime?: string;
}

/** Per-suite last-run cache keyed by suiteId. */
type LastRunMap = Record<string, LastRunInfo | undefined>;

/**
 * Renders a colored Cloudscape status badge for the given run status. Mirrors
 * the visual conventions used on the Run Dashboard so users see consistent
 * iconography between the Suites list and the run detail page.
 */
function runStatusIndicator(status: RunStatus | undefined): JSX.Element {
  if (!status) {
    return <StatusIndicator type="info">Never run</StatusIndicator>;
  }
  const map: Record<RunStatus, StatusIndicatorProps.Type> = {
    [RunStatus.RUNNING]: 'in-progress',
    [RunStatus.COMPLETED]: 'success',
    [RunStatus.FAILED]: 'error',
    [RunStatus.ABORTED]: 'stopped',
  };
  const label: Record<RunStatus, string> = {
    [RunStatus.RUNNING]: 'Running',
    [RunStatus.COMPLETED]: 'Completed',
    [RunStatus.FAILED]: 'Failed',
    [RunStatus.ABORTED]: 'Aborted',
  };
  return <StatusIndicator type={map[status]}>{label[status]}</StatusIndicator>;
}

export function TestSuites() {
  const navigate = useNavigate();
  const [suites, setSuites] = useState<EnrichedTestSuite[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedSuite, setSelectedSuite] = useState<EnrichedTestSuite | null>(null);
  // Controlled expand/collapse state per agent, keyed by agentName. New agents
  // default to expanded (true); a user's collapse choice survives refreshes
  // because the post-fetch effect below only *adds* newly discovered agents
  // and never overwrites an existing entry.
  const [expandedAgents, setExpandedAgents] = useState<Record<string, boolean>>({});
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [deleting, setDeleting] = useState(false);
  // Per-suite last-run cache. Populated lazily after the suites list lands.
  // Stays in state (rather than being recomputed on every render) so partial
  // failures (e.g. a single suite's history endpoint times out) don't blank
  // out the column for the rest of the table.
  const [lastRuns, setLastRuns] = useState<LastRunMap>({});
  const lastRunsLoadingRef = useRef(false);
  // Tracks the suite whose "Run suite" launch is currently in flight so the
  // button shows a loading spinner without disabling the rest of the page.
  const [runningSuiteId, setRunningSuiteId] = useState<string | null>(null);
  const { trackRun } = useActiveRunsContext();

  const fetchSuites = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await apiClient.get<ListSuitesResponse>('/suites');
      setSuites(response.suites);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred while loading test suites.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Fetch the most-recent run for each visible suite in parallel and update
   * the `lastRuns` map. The history endpoint already orders by timestamp
   * descending and is paginated, so a `limit=1` query gives us exactly the
   * latest run with a single round-trip per suite. Suites that have never
   * been run resolve to `{}` (rendered as "Never run") rather than an
   * error — a 404 or empty `runs[]` is a normal state, not a failure.
   */
  const fetchLastRuns = useCallback(async (visible: readonly EnrichedTestSuite[]) => {
    if (visible.length === 0) return;
    if (lastRunsLoadingRef.current) return; // coalesce overlapping refresh requests
    lastRunsLoadingRef.current = true;
    try {
      const updates = await Promise.all(
        visible.map(async (s): Promise<[string, LastRunInfo]> => {
          try {
            const r = await apiClient.get<ListRunsResponse>(
              `/suites/${s.suiteId}/runs?limit=1`,
            );
            const latest = r.runs[0];
            if (!latest) return [s.suiteId, {}];
            return [
              s.suiteId,
              {
                runId: latest.runId,
                status: latest.status,
                passed: latest.passed,
                totalCases: latest.totalCases,
                startTime: latest.startTime,
              },
            ];
          } catch {
            // A single-suite history failure must not blank the column for
            // every other suite; surface it as "Unknown".
            return [s.suiteId, {}];
          }
        }),
      );
      setLastRuns((prev) => {
        const next = { ...prev };
        for (const [suiteId, info] of updates) next[suiteId] = info;
        return next;
      });
    } finally {
      lastRunsLoadingRef.current = false;
    }
  }, []);

  useEffect(() => {
    fetchSuites();
  }, [fetchSuites]);

  // Initialise expand state for any newly discovered agents as expanded
  // (true) while preserving the user's existing collapse choices. Because we
  // only set names that aren't already present in the map, a section the user
  // collapsed stays collapsed across refreshes (Requirement 5.3), and on first
  // load every agent starts expanded (Requirement 5.2).
  useEffect(() => {
    setExpandedAgents((prev) => mergeExpandedAgents(prev, suites));
  }, [suites]);

  // After the suites list lands, fetch the latest run for each suite. Runs
  // again whenever the suites list changes (refresh, create, delete).
  useEffect(() => {
    if (suites.length > 0) {
      fetchLastRuns(suites);
    } else {
      setLastRuns({});
    }
  }, [suites, fetchLastRuns]);

  // Live-poll the last-run status while any visible suite has a RUNNING
  // most-recent run. Stops automatically once every visible suite has
  // settled into a terminal state, so we don't burn API calls on idle
  // suites.
  useEffect(() => {
    const anyRunning = Object.values(lastRuns).some(
      (info) => info?.status === RunStatus.RUNNING,
    );
    if (!anyRunning) return;
    const id = setInterval(() => {
      fetchLastRuns(suites);
    }, 5_000);
    return () => clearInterval(id);
  }, [lastRuns, suites, fetchLastRuns]);

  const handleSelectionChange: TableProps['onSelectionChange'] = (event) => {
    const selected = (event.detail.selectedItems[0] as EnrichedTestSuite) || null;
    setSelectedSuite(selected);
  };

  /**
   * Launch a full-suite run via POST /runs (no caseIds → backend runs every
   * case). On success, register the run with the active-runs tracker so the
   * persistent banner follows the user across pages, then navigate to the
   * run dashboard. Errors surface in the existing alert area at the top of
   * the page, with a Retry action — the suite list itself is unaffected.
   */
  const handleRunSuite = async (suite: EnrichedTestSuite) => {
    setRunningSuiteId(suite.suiteId);
    setError(null);
    try {
      const response = await apiClient.post<{ runId: string; sfnExecutionArn: string }>(
        '/runs',
        { suiteId: suite.suiteId },
      );
      trackRun(response.runId, suite.suiteId, suite.name);
      navigate(`/runs/${response.runId}?suiteId=${suite.suiteId}`);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError(`Failed to start run for suite "${suite.name}".`);
      }
    } finally {
      setRunningSuiteId(null);
    }
  };

  const handleDelete = async () => {
    if (!selectedSuite) return;
    setDeleting(true);
    try {
      // Backend requires the suiteId echoed back as `confirmationToken`
      // to guard against accidental cascade deletes — see deleteSuite() in
      // src/backend/handlers/suites.ts. The Cloudscape confirm modal
      // already gates the call from the user side, so we can safely echo
      // the id here without prompting the user to type it.
      await apiClient.delete(`/suites/${selectedSuite.suiteId}`, {
        confirmationToken: selectedSuite.suiteId,
      });
      setDeleteModalVisible(false);
      setSelectedSuite(null);
      await fetchSuites();
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to delete the test suite.');
      }
    } finally {
      setDeleting(false);
    }
  };

  const columnDefinitions: TableProps.ColumnDefinition<EnrichedTestSuite>[] = [
    {
      id: 'name',
      header: 'Suite Name',
      // The name is a click-through into the suite's detail page, so a
      // user can drill in (Test Cases, Run History, etc.) without having
      // to first select the row and then hit Edit. Selection still works
      // for the row-level actions in the table header (Run / Delete).
      cell: (item) => (
        <Link
          onFollow={(e) => {
            e.preventDefault();
            navigate(`/suites/${item.suiteId}`);
          }}
          href={`/suites/${item.suiteId}`}
        >
          {item.name}
        </Link>
      ),
      sortingField: 'name',
    },
    {
      id: 'description',
      header: 'Description',
      cell: (item) => item.description || '—',
    },
    {
      // "Last Run" column — shows the suite's most-recent run status as a
      // colored badge with a click-through link to that run's dashboard. A
      // suite that has never run shows "Never run"; while a fetch is in
      // flight (no entry yet) we render a small spinner so the column never
      // looks empty during the initial load.
      id: 'lastRun',
      header: 'Last Run',
      cell: (item) => {
        const info = lastRuns[item.suiteId];
        if (!info) {
          return <Spinner size="normal" />;
        }
        if (!info.runId) {
          return <StatusIndicator type="info">Never run</StatusIndicator>;
        }
        const summary =
          info.status === RunStatus.COMPLETED &&
          info.totalCases != null &&
          info.passed != null
            ? ` · ${info.passed}/${info.totalCases} passed`
            : '';
        return (
          <SpaceBetween direction="horizontal" size="xs">
            {runStatusIndicator(info.status)}
            <Link
              onFollow={(e) => {
                e.preventDefault();
                // Always pass `?suiteId=` on the deep-link so the Run
                // Dashboard's GET /runs/{runId} call can find an
                // in-progress run that lives at
                // PK=SUITE#{suiteId}, SK=RUN#{startTime}.
                navigate(`/runs/${info.runId}?suiteId=${item.suiteId}`);
              }}
              href={`/runs/${info.runId}?suiteId=${item.suiteId}`}
            >
              View
            </Link>
            {summary && (
              <Box variant="small" color="text-status-inactive">
                {summary}
              </Box>
            )}
          </SpaceBetween>
        );
      },
    },
    {
      id: 'updatedAt',
      header: 'Last Updated',
      cell: (item) => new Date(item.updatedAt).toLocaleString(),
      sortingField: 'updatedAt',
    },
  ];

  const groups = groupSuitesByAgent(suites);

  /**
   * Row actions header reused inside each per-agent section. Because only one
   * suite is selected across the whole page (the shared `selectedSuite`), the
   * actions are only enabled in the section that actually owns the selected
   * row — gated by `group.suites` membership. This keeps the affordance
   * unambiguous: a user never sees an enabled "Run suite" in an agent section
   * whose table shows no selection.
   */
  const renderTableActions = (group: AgentGroup) => {
    const selectionInGroup =
      !!selectedSuite &&
      group.suites.some((s) => s.suiteId === selectedSuite.suiteId);
    return (
      <SpaceBetween direction="horizontal" size="xs">
        <Button
          disabled={!selectionInGroup}
          onClick={() =>
            selectionInGroup && navigate(`/suites/${selectedSuite!.suiteId}`)
          }
        >
          Edit
        </Button>
        <Button
          disabled={!selectionInGroup}
          onClick={() => setDeleteModalVisible(true)}
        >
          Delete
        </Button>
        {/*
          "Run suite" — primary action on the selected row. Disabled until a
          suite is selected in this section; while a launch is in flight the
          matched row shows a loading spinner. We deliberately keep the button
          enabled-but-loading (rather than swapping in a disabled variant) so
          the user can see exactly which suite is being launched.
        */}
        <Button
          variant="primary"
          disabled={!selectionInGroup}
          loading={selectionInGroup && runningSuiteId === selectedSuite!.suiteId}
          onClick={() => selectionInGroup && handleRunSuite(selectedSuite!)}
        >
          Run suite
        </Button>
      </SpaceBetween>
    );
  };

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description="Create and manage test suites for your AI Agents"
          actions={
            <SpaceBetween direction="horizontal" size="xs">
              <Button iconName="refresh" onClick={fetchSuites} loading={loading}>
                Refresh
              </Button>
              <Button
                variant="primary"
                onClick={() => navigate('/suites/create')}
              >
                Create suite
              </Button>
            </SpaceBetween>
          }
        >
          Test Suites
        </Header>
      }
    >
      <SpaceBetween size="l">
        {error && (
          <Alert
            type="error"
            dismissible
            onDismiss={() => setError(null)}
            header="Error"
            action={<Button onClick={fetchSuites}>Retry</Button>}
          >
            {error}
          </Alert>
        )}

        {/*
          Loading and empty states. These are mutually exclusive with each
          other and with the error alert above: `fetchSuites` clears `error`
          before setting `loading`, so loading never co-occurs with an error;
          and the empty state is gated on `!error` so a failed fetch shows the
          error alert with Retry rather than a misleading "No test suites"
          message.
        */}
        {loading && (
          <Box textAlign="center" padding="l">
            <Spinner size="large" /> Loading test suites...
          </Box>
        )}

        {!loading && !error && groups.length === 0 && (
          <Box textAlign="center" color="inherit" padding="l">
            <SpaceBetween size="m">
              <b>No test suites</b>
              <Box variant="p" color="inherit">
                Create a test suite to start testing your AI Agents.
              </Box>
              <Button onClick={() => navigate('/suites/create')}>Create suite</Button>
            </SpaceBetween>
          </Box>
        )}

        {/*
          One ExpandableSection per agent group. The header shows the agent
          name and its suite count ("AgentName (N suites)", singular for one).
          Each section contains a per-agent table sharing the same columns
          and row actions. Sections are hidden while the error alert is shown
          so a stale grouped layout doesn't sit beneath a fetch failure.
        */}
        {!loading &&
          !error &&
          groups.map((group) => (
            <ExpandableSection
              key={group.agentName}
              expanded={expandedAgents[group.agentName] ?? true}
              onChange={({ detail }) =>
                setExpandedAgents((prev) => ({
                  ...prev,
                  [group.agentName]: detail.expanded,
                }))
              }
              variant="container"
              headerText={`${group.agentName} (${group.suites.length} suite${
                group.suites.length !== 1 ? 's' : ''
              })`}
              headerActions={renderTableActions(group)}
            >
              <Table
                columnDefinitions={columnDefinitions}
                items={group.suites}
                selectionType="single"
                selectedItems={
                  selectedSuite &&
                  group.suites.some((s) => s.suiteId === selectedSuite.suiteId)
                    ? [selectedSuite]
                    : []
                }
                onSelectionChange={handleSelectionChange}
                trackBy="suiteId"
              />
            </ExpandableSection>
          ))}

        <Modal
          visible={deleteModalVisible}
          onDismiss={() => setDeleteModalVisible(false)}
          header="Delete test suite"
          footer={
            <Box float="right">
              <SpaceBetween direction="horizontal" size="xs">
                <Button
                  variant="link"
                  onClick={() => setDeleteModalVisible(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  onClick={handleDelete}
                  loading={deleting}
                >
                  Delete
                </Button>
              </SpaceBetween>
            </Box>
          }
        >
          <Box>
            Are you sure you want to delete the test suite{' '}
            <strong>{selectedSuite?.name}</strong>? This will permanently remove the
            suite and all its test cases. This action cannot be undone.
          </Box>
        </Modal>
      </SpaceBetween>
    </ContentLayout>
  );
}
