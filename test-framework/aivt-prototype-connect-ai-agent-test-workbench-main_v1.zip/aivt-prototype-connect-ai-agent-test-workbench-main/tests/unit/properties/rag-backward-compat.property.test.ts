// Feature: rag-test-cases, Property 5: Read Normalization Preserves Backward Compatibility
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { normalizeTestCase } from "@backend/handlers/cases";
import { DEFAULT_RAG_THRESHOLDS } from "@shared/types";
import type { TestSuite, TestCaseResult } from "@shared/types";

/**
 * **Validates: Requirements 10.1, 10.2, 10.3, 10.4, 1.2, 6.2**
 *
 * Property 5: Read Normalization Preserves Backward Compatibility
 *
 * Generator: random persisted records missing `type` (TestCase),
 * `ragThresholds` (TestSuite), or `caseType` (TestCaseResult).
 *
 * Property: the normalizer produces a valid typed object with defaults
 * (`type = "tool_sequence"`, `ragThresholds = DEFAULT_RAG_THRESHOLDS`,
 * `caseType = "tool_sequence"`) without mutating the original and without
 * throwing.
 *
 * Minimum 100 fast-check iterations.
 */

// ---------------------------------------------------------------------------
// Suite normalization (mirrors normalizeSuiteOnRead from suites.ts)
// ---------------------------------------------------------------------------

/**
 * Replicates the read-time normalization logic from suites.ts:
 * absent ragThresholds → DEFAULT_RAG_THRESHOLDS, without mutating original.
 */
function normalizeSuiteOnRead(suite: Record<string, unknown>): TestSuite {
  if (!suite.ragThresholds) {
    return { ...suite, ragThresholds: DEFAULT_RAG_THRESHOLDS } as unknown as TestSuite;
  }
  return suite as unknown as TestSuite;
}

// ---------------------------------------------------------------------------
// TestCaseResult normalization (mirrors read-time normalization)
// ---------------------------------------------------------------------------

/**
 * Replicates the read-time normalization for TestCaseResult:
 * absent caseType → "tool_sequence", without mutating original.
 */
function normalizeTestCaseResult(
  raw: Record<string, unknown>,
): TestCaseResult & { caseType: "tool_sequence" | "rag" } {
  const caseType = (raw.caseType as string) ?? "tool_sequence";
  return { ...raw, caseType } as unknown as TestCaseResult & {
    caseType: "tool_sequence" | "rag";
  };
}

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Generates a legacy TestCase record missing the `type` field (pre-feature). */
const legacyTestCaseRecordArb: fc.Arbitrary<Record<string, unknown>> = fc.record({
  suiteId: fc.string({ minLength: 1, maxLength: 24 }),
  caseId: fc.string({ minLength: 1, maxLength: 24 }),
  name: fc.string({ minLength: 0, maxLength: 100 }),
  description: fc.string({ minLength: 1, maxLength: 200 }),
  persona: fc.string({ minLength: 0, maxLength: 50 }),
  style: fc.constantFrom("direct", "friendly", "confused", "impatient"),
  customerKnowledge: fc.dictionary(
    fc.string({ minLength: 1, maxLength: 10 }),
    fc.string({ minLength: 1, maxLength: 50 }),
    { minKeys: 0, maxKeys: 3 },
  ),
  initialUtterance: fc.string({ minLength: 1, maxLength: 100 }),
  successCriteria: fc.array(
    fc.record({
      toolName: fc.string({ minLength: 1, maxLength: 30 }),
      required: fc.boolean(),
    }),
    { minLength: 1, maxLength: 5 },
  ),
});
// Note: `type` is intentionally absent to simulate a legacy record.

/** Generates a legacy TestSuite record missing `ragThresholds` (pre-feature). */
const legacySuiteRecordArb: fc.Arbitrary<Record<string, unknown>> = fc.record({
  tenantId: fc.string({ minLength: 1, maxLength: 24 }),
  suiteId: fc.string({ minLength: 1, maxLength: 24 }),
  name: fc.string({ minLength: 1, maxLength: 128 }),
  description: fc.option(fc.string({ maxLength: 200 }), { nil: undefined }),
  agentId: fc.string({ minLength: 1, maxLength: 50 }),
  assistantId: fc.string({ minLength: 1, maxLength: 50 }),
  createdAt: fc.constant("2024-01-01T00:00:00Z"),
  updatedAt: fc.constant("2024-06-01T00:00:00Z"),
});
// Note: `ragThresholds` is intentionally absent to simulate a legacy record.

/** Generates a legacy TestCaseResult record missing `caseType` (pre-feature). */
const legacyResultRecordArb: fc.Arbitrary<Record<string, unknown>> = fc.record({
  runId: fc.string({ minLength: 1, maxLength: 24 }),
  caseId: fc.string({ minLength: 1, maxLength: 24 }),
  status: fc.constantFrom("passed", "failed", "error"),
  toolsInvoked: fc.array(fc.string({ minLength: 1, maxLength: 20 }), {
    minLength: 0,
    maxLength: 5,
  }),
  turnCount: fc.integer({ min: 1, max: 20 }),
  latencyMs: fc.integer({ min: 100, max: 30000 }),
  goalSuccessScore: fc.option(fc.double({ min: 0, max: 1, noNaN: true }), {
    nil: undefined,
  }),
  helpfulnessScore: fc.option(fc.double({ min: 0, max: 1, noNaN: true }), {
    nil: undefined,
  }),
  toolAccuracyScore: fc.option(fc.double({ min: 0, max: 1, noNaN: true }), {
    nil: undefined,
  }),
});
// Note: `caseType` is intentionally absent to simulate a legacy record.

// ---------------------------------------------------------------------------
// Property tests
// ---------------------------------------------------------------------------

describe("Property 5: Read Normalization Preserves Backward Compatibility", () => {
  it("normalizeTestCase produces type='tool_sequence' for records missing `type` without mutating the original", () => {
    fc.assert(
      fc.property(legacyTestCaseRecordArb, (raw) => {
        // Snapshot the original to verify no mutation
        const originalSnapshot = JSON.parse(JSON.stringify(raw));

        // Act
        const normalized = normalizeTestCase(raw);

        // The normalizer must not throw (implicit by reaching here)

        // Property: type defaults to "tool_sequence"
        expect(normalized.type).toBe("tool_sequence");

        // Property: original record is not mutated
        expect(raw).toEqual(originalSnapshot);
        expect(raw).not.toHaveProperty("type");

        // Property: all original fields are preserved on the output
        expect(normalized.suiteId).toBe(raw.suiteId);
        expect(normalized.caseId).toBe(raw.caseId);
        expect(normalized.name).toBe(raw.name);
        expect(normalized.description).toBe(raw.description);
      }),
      { numRuns: 100 },
    );
  });

  it("normalizeSuiteOnRead produces ragThresholds=DEFAULT_RAG_THRESHOLDS for records missing `ragThresholds` without mutating the original", () => {
    fc.assert(
      fc.property(legacySuiteRecordArb, (raw) => {
        // Snapshot the original to verify no mutation
        const originalSnapshot = JSON.parse(JSON.stringify(raw));

        // Act
        const normalized = normalizeSuiteOnRead(raw);

        // The normalizer must not throw (implicit by reaching here)

        // Property: ragThresholds defaults to DEFAULT_RAG_THRESHOLDS
        expect(normalized.ragThresholds).toEqual(DEFAULT_RAG_THRESHOLDS);
        expect(normalized.ragThresholds).toEqual({
          faithfulness: 0.7,
          correctness: 0.7,
          completeness: 0.7,
          helpfulness: 0.7,
        });

        // Property: original record is not mutated
        expect(raw).toEqual(originalSnapshot);
        expect(raw).not.toHaveProperty("ragThresholds");

        // Property: all original fields are preserved on the output
        expect(normalized.tenantId).toBe(raw.tenantId);
        expect(normalized.suiteId).toBe(raw.suiteId);
        expect(normalized.name).toBe(raw.name);
      }),
      { numRuns: 100 },
    );
  });

  it("normalizeTestCaseResult produces caseType='tool_sequence' for records missing `caseType` without mutating the original", () => {
    fc.assert(
      fc.property(legacyResultRecordArb, (raw) => {
        // Snapshot the original to verify no mutation
        const originalSnapshot = JSON.parse(JSON.stringify(raw));

        // Act
        const normalized = normalizeTestCaseResult(raw);

        // The normalizer must not throw (implicit by reaching here)

        // Property: caseType defaults to "tool_sequence"
        expect(normalized.caseType).toBe("tool_sequence");

        // Property: original record is not mutated
        expect(raw).toEqual(originalSnapshot);
        expect(raw).not.toHaveProperty("caseType");

        // Property: all original fields are preserved on the output
        expect(normalized.runId).toBe(raw.runId);
        expect(normalized.caseId).toBe(raw.caseId);
        expect(normalized.status).toBe(raw.status);
      }),
      { numRuns: 100 },
    );
  });

  it("normalizeTestCase is a pure function (same input → same output, no side effects)", () => {
    fc.assert(
      fc.property(legacyTestCaseRecordArb, (raw) => {
        const result1 = normalizeTestCase(raw);
        const result2 = normalizeTestCase(raw);

        // Deterministic: same input produces structurally equal output
        expect(result1).toEqual(result2);

        // Both reference-distinct from input (spread creates a new object)
        expect(result1).not.toBe(raw);
        expect(result2).not.toBe(raw);
      }),
      { numRuns: 100 },
    );
  });
});
