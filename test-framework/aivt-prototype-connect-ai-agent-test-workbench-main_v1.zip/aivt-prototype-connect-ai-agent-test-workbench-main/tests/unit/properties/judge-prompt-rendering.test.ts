import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import {
  renderJudgePromptContext,
  BEGINNING_OF_CONVERSATION,
  NO_AVAILABLE_TOOLS,
} from '../../../src/shared/utils/judge-prompt-rendering';
import type {
  AgentSnapshot,
  ExecutionStep,
  ExecutionTrace,
  ToolDefinition,
  TranscriptTurn,
} from '../../../src/shared/types';

/**
 * Properties 1 and 2 for the pure prompt-rendering module
 * (`src/shared/utils/judge-prompt-rendering.ts`).
 *
 * The arbitrary builders below seed every trace inference, every trace tool
 * call, every snapshot tool, every transcript customer turn, and every
 * expected tool name with a UNIQUE sentinel (`__TURN_{i}__`,
 * `__TOOL_{i}__`, `__SNAP_{i}__`, `__USER_{i}__`, `__EXPECTED_{i}__`) so
 * substring-based assertions about per-turn windowing cannot match the
 * wrong unit. The five sentinel namespaces are disjoint so a snapshot
 * tool name cannot collide with a trace tool call, etc.
 */

// ---------------------------------------------------------------------------
// Arbitraries (shared by Property 1 and Property 2)
// ---------------------------------------------------------------------------

type StepKind =
  | { kind: 'inference'; hasText: boolean }
  | { kind: 'tool-with-payload' }
  | { kind: 'tool-empty' }
  | { kind: 'agent' }
  | { kind: 'other' };

const stepKindArb: fc.Arbitrary<StepKind> = fc.oneof(
  {
    weight: 5,
    arbitrary: fc.record({
      kind: fc.constant('inference' as const),
      hasText: fc.boolean(),
    }),
  },
  { weight: 4, arbitrary: fc.constant({ kind: 'tool-with-payload' as const }) },
  { weight: 1, arbitrary: fc.constant({ kind: 'tool-empty' as const }) },
  { weight: 1, arbitrary: fc.constant({ kind: 'agent' as const }) },
  { weight: 1, arbitrary: fc.constant({ kind: 'other' as const }) },
);

/**
 * Builds an `ExecutionTrace` from a step-kind list. Each generated inference
 * step gets a unique `__TURN_{globalInferenceIdx}__` sentinel in its `text`
 * (when `hasText` is true). Each generated tool-with-payload step gets a
 * unique `__TOOL_{globalToolIdx}__` sentinel in its `toolName`. Step indices
 * are sequential. Empty traces are reachable so the renderer's boundary
 * behaviour is exercised.
 */
const traceArb: fc.Arbitrary<ExecutionTrace> = fc
  .array(stepKindArb, { minLength: 0, maxLength: 8 })
  .map((kinds): ExecutionTrace => {
    const steps: ExecutionStep[] = [];
    let inferenceIdx = 0;
    let toolIdx = 0;
    for (let i = 0; i < kinds.length; i++) {
      const k = kinds[i];
      if (k.kind === 'inference') {
        const idx = inferenceIdx++;
        steps.push({
          index: i,
          type: 'inference',
          spanName: 'inference',
          text: k.hasText ? `__TURN_${idx}__ assistant utterance` : undefined,
        });
      } else if (k.kind === 'tool-with-payload') {
        const idx = toolIdx++;
        steps.push({
          index: i,
          type: 'tool',
          spanName: 'execute_tool',
          tool: {
            toolName: `__TOOL_${idx}__`,
            arguments: { v: idx },
            result: { ok: idx },
            success: true,
          },
        });
      } else if (k.kind === 'tool-empty') {
        // Tool step with no `tool` payload — silently dropped by the renderer.
        steps.push({
          index: i,
          type: 'tool',
          spanName: 'execute_tool',
        });
      } else if (k.kind === 'agent') {
        steps.push({ index: i, type: 'agent', spanName: 'agent' });
      } else {
        steps.push({ index: i, type: 'other', spanName: 'other' });
      }
    }
    const toolSequence = steps
      .filter((s) => s.type === 'tool' && s.tool != null)
      .map((s) => s.tool!.toolName);
    return {
      sessionId: 'test-session',
      steps,
      toolSequence,
      capturedAt: '2024-01-01T00:00:00Z',
    };
  });

/**
 * Generates a `TranscriptTurn[]` where each customer turn has either a
 * unique `__USER_{idx}__` sentinel or an empty string (so the renderer's
 * trim-then-skip path is exercised). Agent turns are filler — the renderer
 * does not consume them, but they exist in real transcripts so we keep them.
 */
const transcriptArb: fc.Arbitrary<TranscriptTurn[]> = fc
  .array(
    fc.record({
      role: fc.constantFrom<'customer' | 'agent'>('customer', 'agent'),
      hasText: fc.boolean(),
    }),
    { minLength: 0, maxLength: 6 },
  )
  .map((entries) => {
    let userIdx = 0;
    return entries.map((e, i): TranscriptTurn => {
      let text: string;
      if (e.role === 'customer') {
        text = e.hasText ? `__USER_${userIdx++}__ hello` : '';
      } else {
        text = e.hasText ? 'agent reply' : '';
      }
      return {
        turnNumber: i,
        role: e.role,
        text,
        timestamp: '2024-01-01T00:00:00Z',
        elapsedMs: 0,
      };
    });
  });

/**
 * Snapshot with N tools, each named `__SNAP_{i}__`. Names are unique so
 * Property 1's "exactly one occurrence per name" assertion is unambiguous.
 */
const snapshotArb: fc.Arbitrary<AgentSnapshot> = fc.nat({ max: 5 }).map((n): AgentSnapshot => {
  const tools: ToolDefinition[] = [];
  for (let i = 0; i < n; i++) {
    tools.push({
      toolName: `__SNAP_${i}__`,
      toolType: 'ACTION',
      description: `desc ${i}`,
      inputSchema: { i },
      examples: [],
    });
  }
  return {
    tools,
    systemPrompt: 'system prompt',
    modelId: 'model-id',
    capturedAt: '2024-01-01T00:00:00Z',
  };
});

/**
 * Expected tool names with a disjoint namespace so they cannot collide with
 * trace tool calls or snapshot tools.
 */
const expectedToolNamesArb: fc.Arbitrary<string[]> = fc
  .nat({ max: 5 })
  .map((n) => Array.from({ length: n }, (_, i) => `__EXPECTED_${i}__`));

const inputArb = fc.record({
  trace: traceArb,
  transcript: transcriptArb,
  snapshot: snapshotArb,
  expectedToolNames: expectedToolNamesArb,
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const LINE_PREFIXES = ['User: ', 'Assistant: ', 'Action: ', 'Tool: '] as const;
type LineKind = 'User' | 'Assistant' | 'Action' | 'Tool' | null;

function classifyLine(line: string): LineKind {
  if (line.startsWith('User: ')) return 'User';
  if (line.startsWith('Assistant: ')) return 'Assistant';
  if (line.startsWith('Action: ')) return 'Action';
  if (line.startsWith('Tool: ')) return 'Tool';
  return null;
}

function hasUserOrAssistantLine(context: string): boolean {
  return context
    .split('\n')
    .some((l) => l.startsWith('User: ') || l.startsWith('Assistant: '));
}

// ---------------------------------------------------------------------------
// Property 1
// ---------------------------------------------------------------------------

// Feature: bedrock-judge-evaluations, Property 1: Prompt rendering is deterministic and complete

/**
 * **Validates: Requirements 2.1, 2.2, 11.3**
 *
 * Property 1: Prompt rendering is deterministic and complete
 *
 * For arbitrary `(ExecutionTrace, TranscriptTurn[], AgentSnapshot,
 * expectedToolNames)` inputs, `renderJudgePromptContext`:
 *
 *  (1) is deterministic — same input produces structurally equal output
 *      across two invocations,
 *  (2) emits one `assistantTurns` entry per inference step with non-empty
 *      `text` (matching the renderer's skip-when-no-text behaviour),
 *  (3) emits one `toolTurns` entry per `execute_tool` step with a
 *      non-undefined `tool` payload that occurs AFTER at least one
 *      inference step has been seen (the renderer drops tool steps that
 *      occur before the first inference because they have no current turn
 *      to attach to),
 *  (4) renders `availableTools` containing every snapshot tool's
 *      `toolName` exactly once, in the same order as the input array,
 *  (5) preserves chronological line order in the session-level `context`
 *      — every `Action:` line is immediately followed by a `Tool:` line
 *      (each tool call is paired with its result), and the order of
 *      `Assistant:` lines matches the order of inference text in the
 *      trace.
 */
describe('Property 1: Prompt rendering is deterministic and complete', () => {
  it('determinism + completeness + tools order + chronological line order', () => {
    fc.assert(
      fc.property(inputArb, (input) => {
        const a = renderJudgePromptContext(input);
        const b = renderJudgePromptContext(input);

        // ---- (1) Determinism --------------------------------------------------
        expect(a).toEqual(b);

        // ---- (2) Completeness — assistant turns -------------------------------
        const inferenceWithText = input.trace.steps.filter(
          (s) =>
            s.type === 'inference' &&
            typeof s.text === 'string' &&
            s.text.length > 0,
        );
        expect(a.assistantTurns).toHaveLength(inferenceWithText.length);

        // ---- (3) Completeness — tool turns ------------------------------------
        // Tool steps are attached to the "current" turn only after the first
        // inference is seen; tool steps before any inference are dropped.
        let seenInference = false;
        let expectedToolCount = 0;
        for (const step of input.trace.steps) {
          if (step.type === 'inference') {
            seenInference = true;
            continue;
          }
          if (step.type === 'tool' && step.tool != null && seenInference) {
            expectedToolCount += 1;
          }
        }
        expect(a.toolTurns).toHaveLength(expectedToolCount);

        // ---- (4) Available tools order and content ----------------------------
        const snapTools = input.snapshot.tools;
        if (snapTools.length === 0) {
          // The renderer emits the no-tools sentinel for an empty list.
          expect(a.availableTools).toBe(NO_AVAILABLE_TOOLS);
        } else {
          let lastIdx = -1;
          for (const t of snapTools) {
            const occurrences = a.availableTools.split(t.toolName).length - 1;
            expect(occurrences).toBe(1);
            const idx = a.availableTools.indexOf(t.toolName);
            expect(idx).toBeGreaterThan(lastIdx);
            lastIdx = idx;
          }
        }

        // ---- (5) Chronological line order in session-level context -----------
        const lines = a.context.split('\n');
        const lineKinds = lines.map(classifyLine);

        // Action: always immediately precedes Tool:
        for (let i = 0; i < lineKinds.length; i++) {
          if (lineKinds[i] === 'Action') {
            expect(lineKinds[i + 1]).toBe('Tool');
          }
        }

        // Assistant: line order matches inference-text order in the trace.
        const assistantLines = lines.filter((l) => l.startsWith('Assistant: '));
        expect(assistantLines).toHaveLength(inferenceWithText.length);
        for (let i = 0; i < assistantLines.length; i++) {
          const stripped = assistantLines[i].slice('Assistant: '.length);
          expect(stripped).toBe(inferenceWithText[i].text as string);
        }

        // Sanity: every classified line uses one of the four expected prefixes
        // (other than blank lines and the optional `Expected tools:` annotation).
        for (let i = 0; i < lines.length; i++) {
          const l = lines[i];
          if (l.length === 0) continue;
          if (l.startsWith('Expected tools:')) continue;
          const matches = LINE_PREFIXES.some((p) => l.startsWith(p));
          expect(matches).toBe(true);
        }
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 2
// ---------------------------------------------------------------------------

// Feature: bedrock-judge-evaluations, Property 2: Per-turn windowing is prefix-only

/**
 * **Validates: Requirement 2.4**
 *
 * Property 2: Per-turn windowing is prefix-only
 *
 * For arbitrary inputs, the per-unit `{context}` strings emitted by
 * `renderJudgePromptContext`:
 *
 *  (1) For each `assistantTurns[i]`: the `context` contains no `assistantText`
 *      of any later assistant turn (j > i in the chronological assistant-turn
 *      ordering). Each generated assistant utterance is seeded with a unique
 *      `__TURN_{idx}__` sentinel so substring matches are unambiguous.
 *  (2) For each `toolTurns[i]`: the `context` contains no rendered
 *      `tool_turn` of any later tool call (j > i). Each generated tool name
 *      is seeded with a unique `__TOOL_{idx}__` sentinel.
 *  (3) For each `assistantTurns[i]` where i > 0: the `context` contains at
 *      least one `User:` or `Assistant:` line. For i === 0 the `context`
 *      may instead be the `(beginning of conversation)` sentinel.
 *  (4) For each `toolTurns[i].context`: when `expectedToolNames` is
 *      non-empty, the last non-empty line begins with `Expected tools:`.
 *      When `expectedToolNames` is empty, no `Expected tools:` substring
 *      appears.
 *  (5) Helpfulness contexts (`assistantTurns[i].context`) NEVER contain
 *      `Expected tools:` — Helpfulness is user-perspective only per the
 *      steering doc.
 */
describe('Property 2: Per-turn windowing is prefix-only', () => {
  it('per-unit contexts are prefixes only and respect the Expected-tools annotation contract', () => {
    fc.assert(
      fc.property(inputArb, (input) => {
        const r = renderJudgePromptContext(input);

        // ---- (1) Later assistant text never appears in earlier per-turn context ----
        for (let i = 0; i < r.assistantTurns.length; i++) {
          for (let j = i + 1; j < r.assistantTurns.length; j++) {
            const laterText = r.assistantTurns[j].assistantTurn;
            expect(r.assistantTurns[i].context.includes(laterText)).toBe(false);
          }
        }

        // ---- (2) Later tool turn never appears in earlier per-tool-call context ----
        for (let i = 0; i < r.toolTurns.length; i++) {
          for (let j = i + 1; j < r.toolTurns.length; j++) {
            const laterTool = r.toolTurns[j].toolTurn;
            expect(r.toolTurns[i].context.includes(laterTool)).toBe(false);
          }
        }

        // ---- (3) assistantTurns[i].context content gating ----
        // For every non-first assistant turn there is at least one earlier
        // text-bearing assistant turn whose `Assistant: ...` line appears in
        // the prefix; the BEGINNING-of-conversation sentinel may ONLY appear
        // at index 0 (the prefix can never collapse to empty for i > 0).
        for (let i = 0; i < r.assistantTurns.length; i++) {
          const ctx = r.assistantTurns[i].context;
          if (i > 0) {
            expect(hasUserOrAssistantLine(ctx)).toBe(true);
            expect(ctx).not.toBe(BEGINNING_OF_CONVERSATION);
          }
          // Note: at i === 0 the prefix may be the BEGINNING sentinel, or any
          // combination of `User:` / `Assistant:` / `Action:` / `Tool:` lines
          // from earlier non-text turns (turns whose inference span carried
          // no text are still rendered when they have customer text or tool
          // calls). Requirement 2.4 only mandates "prefix-only", so this
          // case has no positive content constraint.
        }

        // ---- (4) Expected-tools annotation contract on toolTurns ----
        for (const tt of r.toolTurns) {
          if (input.expectedToolNames.length > 0) {
            const lastNonBlank = tt.context
              .split('\n')
              .filter((l) => l.length > 0)
              .pop();
            expect(lastNonBlank).toBeDefined();
            expect(lastNonBlank!.startsWith('Expected tools:')).toBe(true);
          } else {
            expect(tt.context.includes('Expected tools:')).toBe(false);
          }
        }

        // ---- (5) Helpfulness contexts never carry Expected-tools annotation ----
        for (const at of r.assistantTurns) {
          expect(at.context.includes('Expected tools:')).toBe(false);
        }
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 3 — Timestamp-driven customer/assistant pairing
// ---------------------------------------------------------------------------

// Feature: bedrock-judge-evaluations, Property 3: Customer turns pair with assistant turns by timestamp, not position

/**
 * **Validates: Requirement 2.4** (regression guard for the "wrong customer
 * turn next to each assistant turn" bug observed in
 * `RUN#fa39abf7b743a03ce1bae93d`).
 *
 * Property 3: Customer-to-assistant pairing is timestamp-driven, not positional
 *
 * For an arbitrary linear sequence of `(customer | assistant)` events with
 * strictly increasing timestamps, `renderJudgePromptContext` emits per-turn
 * `assistantTurns[i].context` strings whose `User:` lines, when read in
 * chronological order across the entire output, are exactly the customer
 * texts that occurred BEFORE the corresponding assistant turn — never a
 * customer text that arrived AFTER it. This is the invariant that broke in
 * production when multiple chained inference steps each consumed a
 * positional customer slot, causing the judge to score Helpfulness against
 * the next customer message in the suite rather than the one the assistant
 * was actually responding to.
 *
 * The arbitrary models the production failure mode directly: a single
 * customer turn followed by N consecutive assistant inferences (the agent
 * does multi-step reasoning + tool calls without the customer speaking) is
 * a valid generated input.
 */
describe('Property 3: Customer-to-assistant pairing is timestamp-driven', () => {
  it('emits each User: line strictly before the assistant turn whose timestamp follows it', () => {
    type EventKind = 'customer' | 'assistant';
    const eventArb: fc.Arbitrary<EventKind> = fc.constantFrom<EventKind>(
      'customer',
      'assistant',
    );

    const sequenceArb = fc
      .array(eventArb, { minLength: 1, maxLength: 8 })
      // Filter sequences with no assistant turn — nothing to assert on.
      .filter((s) => s.includes('assistant'));

    fc.assert(
      fc.property(sequenceArb, (sequence) => {
        // Build a trace whose i-th inference span has timestamp T0+i*1000ms,
        // and a transcript whose customer turns are stamped in the same
        // monotone sequence so each customer should pair with the FIRST
        // assistant turn that follows it (the same wall-clock the agent
        // emitted its inference at).
        const T0 = Date.parse('2024-06-01T15:00:00.000Z');
        const stepMs = 1000;

        const traceSteps: ExecutionStep[] = [];
        const transcript: TranscriptTurn[] = [];

        let customerIdx = 0;
        let assistantIdx = 0;
        for (let i = 0; i < sequence.length; i++) {
          const ts = new Date(T0 + i * stepMs).toISOString();
          if (sequence[i] === 'customer') {
            transcript.push({
              turnNumber: i,
              role: 'customer',
              text: `__USER_${customerIdx}__ msg`,
              timestamp: ts,
              elapsedMs: 0,
            });
            customerIdx += 1;
          } else {
            traceSteps.push({
              index: traceSteps.length,
              type: 'inference',
              spanName: 'inference',
              text: `__TURN_${assistantIdx}__ utterance`,
              timestamp: ts,
            });
            assistantIdx += 1;
          }
        }

        const trace: ExecutionTrace = {
          sessionId: 'prop3-session',
          steps: traceSteps,
          toolSequence: [],
          capturedAt: '2024-06-01T15:00:00.000Z',
        };
        const snapshot: AgentSnapshot = {
          tools: [],
          systemPrompt: '',
          modelId: '',
          capturedAt: '2024-06-01T15:00:00.000Z',
        };

        const rendered = renderJudgePromptContext({
          trace,
          transcript,
          snapshot,
          expectedToolNames: [],
        });

        // For each rendered assistant turn, every `User:` line in its
        // prefix-only context must correspond to a customer event that
        // appeared BEFORE this turn's inference in the input sequence.
        // Equivalently: the customer index `k` extracted from
        // `__USER_{k}__` must be < the count of customers preceding
        // this turn's assistant index in `sequence`.
        for (let i = 0; i < rendered.assistantTurns.length; i++) {
          const ctx = rendered.assistantTurns[i].context;

          // Find the position of the i-th assistant event in `sequence`.
          let seenAssistants = -1;
          let assistantPos = -1;
          for (let j = 0; j < sequence.length; j++) {
            if (sequence[j] === 'assistant') {
              seenAssistants += 1;
              if (seenAssistants === i) {
                assistantPos = j;
                break;
              }
            }
          }
          // Count how many customers strictly preceded that assistant.
          let priorCustomerCount = 0;
          for (let j = 0; j < assistantPos; j++) {
            if (sequence[j] === 'customer') priorCustomerCount += 1;
          }

          // Every `User: __USER_{k}__` line in the prefix must have
          // k < priorCustomerCount.
          const userLines = ctx
            .split('\n')
            .filter((l) => l.startsWith('User: __USER_'));
          for (const line of userLines) {
            const m = line.match(/__USER_(\d+)__/);
            expect(m).not.toBeNull();
            const k = parseInt(m![1], 10);
            expect(k).toBeLessThan(priorCustomerCount);
          }
        }
      }),
      { numRuns: 100 },
    );
  });

  it('does not silently shift a later customer message onto an earlier assistant turn (concrete regression case)', () => {
    // Mirrors the production failure shape from RUN#fa39abf7…: customer
    // says one thing, agent does FIVE chained inferences (interleaved with
    // tool calls) before the customer speaks again, then a closing
    // exchange. Pre-fix the positional pairing would consume the second
    // customer's text on inference #2 of the chain, so the judge would see
    // the wrong customer message preceding most of the agent reasoning.
    // Post-fix only the first inference of the chain pairs with the first
    // customer; the chained inferences carry no `User:` line; and the
    // closing-exchange inference pairs with the closing customer.
    const T0 = Date.parse('2024-06-01T15:00:00.000Z');

    const transcript: TranscriptTurn[] = [
      {
        turnNumber: 1,
        role: 'customer',
        text: '__OPEN__ Check my loan balance.',
        timestamp: new Date(T0).toISOString(),
        elapsedMs: 0,
      },
      {
        turnNumber: 2,
        role: 'customer',
        text: '__CLOSE__ Got it, thanks.',
        timestamp: new Date(T0 + 30_000).toISOString(),
        elapsedMs: 30_000,
      },
    ];

    // Five chained inferences fire BEFORE the customer speaks again, then
    // one closing inference fires AFTER the second customer message.
    const traceSteps: ExecutionStep[] = [];
    for (let i = 0; i < 5; i++) {
      traceSteps.push({
        index: i,
        type: 'inference',
        spanName: 'inference',
        text: `__CHAIN_${i}__ chained reasoning`,
        timestamp: new Date(T0 + 1000 + i * 1000).toISOString(),
      });
    }
    traceSteps.push({
      index: 5,
      type: 'inference',
      spanName: 'inference',
      text: `__CLOSE_REPLY__ You're welcome.`,
      timestamp: new Date(T0 + 31_000).toISOString(),
    });

    const trace: ExecutionTrace = {
      sessionId: 'prop3-regression',
      steps: traceSteps,
      toolSequence: [],
      capturedAt: '2024-06-01T15:00:00.000Z',
    };
    const snapshot: AgentSnapshot = {
      tools: [],
      systemPrompt: '',
      modelId: '',
      capturedAt: '2024-06-01T15:00:00.000Z',
    };

    const rendered = renderJudgePromptContext({
      trace,
      transcript,
      snapshot,
      expectedToolNames: [],
    });

    // Both customer messages must appear in the session-level context.
    expect(rendered.context).toContain('User: __OPEN__');
    expect(rendered.context).toContain('User: __CLOSE__');
    // All six assistant inferences must appear in the session-level context.
    for (let i = 0; i < 5; i++) {
      expect(rendered.context).toContain(`Assistant: __CHAIN_${i}__`);
    }
    expect(rendered.context).toContain('Assistant: __CLOSE_REPLY__');

    // Per-turn invariant: NONE of the chained inferences (assistant turns
    // 1 through 4 — those after the first inference of the chain) may have
    // __CLOSE__ in their prefix-only context. This is the exact bug the
    // pre-fix positional pairing exhibited: the second customer message
    // would be silently shifted onto the second chained inference's prefix
    // even though it arrived later in wall-clock time.
    for (let i = 0; i < rendered.assistantTurns.length; i++) {
      const at = rendered.assistantTurns[i];
      // The closing-reply inference is the only turn whose context could
      // legitimately mention __CLOSE__ at all (and even then the renderer's
      // prefix-only contract puts the triggering customer text on the
      // turn itself, not in its prefix). The chained inferences must
      // never see the later customer message.
      if (at.assistantTurn.includes('__CLOSE_REPLY__')) continue;
      expect(at.context).not.toContain('__CLOSE__');
    }
  });
});
