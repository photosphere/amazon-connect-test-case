/**
 * Progress display computation utility.
 *
 * Takes in-progress run state (pass/fail/error counts and elapsed seconds)
 * and produces a formatted progress display object with elapsed time in MM:SS
 * and validated count invariants.
 *
 * @module progress-display
 */

import { formatElapsedTime } from "./time-formatting";

/**
 * Input for computing a progress display.
 */
export interface ProgressState {
  passed: number;
  failed: number;
  errors: number;
  totalCases: number;
  elapsedSeconds: number;
}

/**
 * Computed progress display output.
 */
export interface ProgressDisplay {
  formattedElapsedTime: string;
  completed: number;
  passed: number;
  failed: number;
  errors: number;
  totalCases: number;
}

/**
 * Computes a progress display from raw run state.
 *
 * - `completed` is always the sum of passed + failed + errors
 * - `formattedElapsedTime` is the elapsed seconds in MM:SS format (via formatElapsedTime)
 *
 * @param state - The current progress state with counts and elapsed time
 * @returns A progress display object with formatted time and validated counts
 *
 * @example
 * computeProgressDisplay({ passed: 3, failed: 1, errors: 0, totalCases: 10, elapsedSeconds: 125 })
 * // { formattedElapsedTime: "02:05", completed: 4, passed: 3, failed: 1, errors: 0, totalCases: 10 }
 */
export function computeProgressDisplay(state: ProgressState): ProgressDisplay {
  const passed = Math.max(0, Math.floor(state.passed));
  const failed = Math.max(0, Math.floor(state.failed));
  const errors = Math.max(0, Math.floor(state.errors));
  const completed = passed + failed + errors;

  return {
    formattedElapsedTime: formatElapsedTime(state.elapsedSeconds),
    completed,
    passed,
    failed,
    errors,
    totalCases: Math.max(0, Math.floor(state.totalCases)),
  };
}
