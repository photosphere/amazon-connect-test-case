// Feature: implement-recommendations, Property 7: Recommendation structural validation
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import {
  validateRecommendation,
  validateRecommendations,
} from "@backend/orchestration/validation";
import type { Recommendation, ToolSurface } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** The four valid ToolSurface values. */
const validToolSurfaceArb: fc.Arbitrary<ToolSurface> =
  fc.constantFrom<ToolSurface>(
    "tool_description",
    "tool_instruction",
    "tool_examples",
    "system_prompt",
  );

/** Non-empty string (after trimming) for targetName. */
const nonEmptyTargetNameArb: fc.Arbitrary<string> = fc
  .string({ minLength: 1, maxLength: 50 })
  .filter((s) => s.trim().length > 0);

/** Non-empty text for currentText/suggestedText. */
const nonEmptyTextArb: fc.Arbitrary<string> = fc.string({
  minLength: 1,
  maxLength: 100,
});

/** Arbitrary rationale (may be empty). */
const rationaleArb: fc.Arbitrary<string> = fc.string({
  minLength: 0,
  maxLength: 80,
});

/**
 * Generates a currentText/suggestedText pair where at least one is non-empty.
 * This satisfies rule 3 of validation.
 */
const atLeastOneNonEmptyTextPairArb: fc.Arbitrary<{
  currentText: string;
  suggestedText: string;
}> = fc.oneof(
  // Only currentText non-empty
  fc.record({
    currentText: nonEmptyTextArb,
    suggestedText: fc.constant(""),
  }),
  // Only suggestedText non-empty
  fc.record({
    currentText: fc.constant(""),
    suggestedText: nonEmptyTextArb,
  }),
  // Both non-empty
  fc.record({
    currentText: nonEmptyTextArb,
    suggestedText: nonEmptyTextArb,
  }),
);

/**
 * Generates a fully valid Recommendation: valid targetField, non-empty
 * targetName, and at least one of currentText/suggestedText non-empty.
 */
const validRecommendationArb: fc.Arbitrary<Recommendation> = fc
  .tuple(
    validToolSurfaceArb,
    nonEmptyTargetNameArb,
    atLeastOneNonEmptyTextPairArb,
    rationaleArb,
  )
  .map(([targetField, targetName, texts, rationale]) => ({
    targetField,
    targetName,
    currentText: texts.currentText,
    suggestedText: texts.suggestedText,
    rationale,
  }));

/**
 * Generates a string that is NOT one of the four valid ToolSurface values.
 * Uses arbitrary strings and filters out the valid ones.
 */
const invalidToolSurfaceArb: fc.Arbitrary<string> = fc
  .string({ minLength: 1, maxLength: 30 })
  .filter(
    (s) =>
      s !== "tool_description" &&
      s !== "tool_instruction" &&
      s !== "tool_examples" &&
      s !== "system_prompt",
  );

/**
 * Generates a targetName that is empty or whitespace-only after trimming.
 */
const emptyTargetNameArb: fc.Arbitrary<string> = fc.oneof(
  fc.constant(""),
  fc.stringOf(fc.constantFrom(" ", "\t", "\n", "\r"), {
    minLength: 1,
    maxLength: 10,
  }),
);

// ---------------------------------------------------------------------------
// Property 7: Recommendation structural validation
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 5.4, 13.1**
 *
 * Property 7: Recommendation structural validation
 * The validation function rejects all structurally invalid recommendations
 * and accepts all valid ones. A recommendation is valid iff:
 * (a) targetField ∈ {tool_description, tool_instruction, tool_examples, system_prompt}
 * (b) targetName is non-empty after trimming
 * (c) at least one of currentText/suggestedText is non-empty
 */
describe("Feature: implement-recommendations, Property 7: Recommendation structural validation", () => {
  it("valid recommendations always pass validation", () => {
    fc.assert(
      fc.property(validRecommendationArb, (rec) => {
        const result = validateRecommendation(rec);
        expect(result.valid).toBe(true);
        expect(result.errors).toHaveLength(0);
      }),
      { numRuns: 100 },
    );
  });

  it("invalid targetField always fails validation", () => {
    fc.assert(
      fc.property(
        invalidToolSurfaceArb,
        nonEmptyTargetNameArb,
        atLeastOneNonEmptyTextPairArb,
        rationaleArb,
        (targetField, targetName, texts, rationale) => {
          const rec: Recommendation = {
            targetField: targetField as ToolSurface,
            targetName,
            currentText: texts.currentText,
            suggestedText: texts.suggestedText,
            rationale,
          };
          const result = validateRecommendation(rec);
          expect(result.valid).toBe(false);
          expect(
            result.errors.some((e) => e.includes("targetField")),
          ).toBe(true);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("empty targetName always fails validation", () => {
    fc.assert(
      fc.property(
        validToolSurfaceArb,
        emptyTargetNameArb,
        atLeastOneNonEmptyTextPairArb,
        rationaleArb,
        (targetField, targetName, texts, rationale) => {
          const rec: Recommendation = {
            targetField,
            targetName,
            currentText: texts.currentText,
            suggestedText: texts.suggestedText,
            rationale,
          };
          const result = validateRecommendation(rec);
          expect(result.valid).toBe(false);
          expect(
            result.errors.some((e) => e.includes("targetName")),
          ).toBe(true);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("both texts empty always fails validation", () => {
    fc.assert(
      fc.property(
        validToolSurfaceArb,
        nonEmptyTargetNameArb,
        rationaleArb,
        (targetField, targetName, rationale) => {
          const rec: Recommendation = {
            targetField,
            targetName,
            currentText: "",
            suggestedText: "",
            rationale,
          };
          const result = validateRecommendation(rec);
          expect(result.valid).toBe(false);
          expect(
            result.errors.some(
              (e) =>
                e.includes("currentText") || e.includes("suggestedText"),
            ),
          ).toBe(true);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("validateRecommendations returns valid iff ALL individual recommendations are valid", () => {
    // Generate an array of valid recommendations — batch should be valid
    fc.assert(
      fc.property(
        fc.array(validRecommendationArb, { minLength: 0, maxLength: 10 }),
        (recs) => {
          const batchResult = validateRecommendations(recs);
          const individualResults = recs.map((r) => validateRecommendation(r));
          const allIndividuallyValid = individualResults.every((r) => r.valid);

          expect(batchResult.valid).toBe(allIndividuallyValid);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("validateRecommendations returns invalid when ANY recommendation is invalid", () => {
    // Mix valid recommendations with at least one invalid one
    fc.assert(
      fc.property(
        fc.array(validRecommendationArb, { minLength: 0, maxLength: 5 }),
        fc.nat({ max: 2 }),
        (validRecs, invalidKind) => {
          // Create an invalid recommendation based on the invalidKind selector
          let invalidRec: Recommendation;
          if (invalidKind === 0) {
            // Invalid targetField
            invalidRec = {
              targetField: "invalid_surface" as ToolSurface,
              targetName: "someTool",
              currentText: "text",
              suggestedText: "new text",
              rationale: "",
            };
          } else if (invalidKind === 1) {
            // Empty targetName
            invalidRec = {
              targetField: "tool_description",
              targetName: "   ",
              currentText: "text",
              suggestedText: "new text",
              rationale: "",
            };
          } else {
            // Both texts empty
            invalidRec = {
              targetField: "tool_instruction",
              targetName: "someTool",
              currentText: "",
              suggestedText: "",
              rationale: "",
            };
          }

          const mixed = [...validRecs, invalidRec];
          const batchResult = validateRecommendations(mixed);

          expect(batchResult.valid).toBe(false);
          expect(batchResult.errors.length).toBeGreaterThan(0);
        },
      ),
      { numRuns: 100 },
    );
  });
});
