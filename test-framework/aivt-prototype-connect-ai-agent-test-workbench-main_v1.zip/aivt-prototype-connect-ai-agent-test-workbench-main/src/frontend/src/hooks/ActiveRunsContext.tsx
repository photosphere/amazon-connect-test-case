/**
 * ActiveRunsContext — single instance of {@link useActiveRuns} hoisted into
 * a React context so the polling cycle is shared across the AppLayout
 * banner and the run-launching buttons. Without this, each consumer of
 * `useActiveRuns()` would mount its own polling timer; with it, there is
 * exactly one polling source per browser tab.
 */
import React, { createContext, useContext } from "react";
import { useActiveRuns, type ActiveRunView } from "./useActiveRuns";

interface ActiveRunsContextValue {
  runs: ActiveRunView[];
  trackRun: (runId: string, suiteId: string, suiteName?: string) => void;
  dismissRun: (runId: string) => void;
  dismissAll: () => void;
}

const ActiveRunsContext = createContext<ActiveRunsContextValue | null>(null);

export function ActiveRunsProvider({ children }: { children: React.ReactNode }) {
  const value = useActiveRuns();
  return (
    <ActiveRunsContext.Provider value={value}>
      {children}
    </ActiveRunsContext.Provider>
  );
}

/**
 * Read the shared active-runs view-model. Throws if used outside the
 * provider — that's a programming error, not a runtime condition.
 */
export function useActiveRunsContext(): ActiveRunsContextValue {
  const ctx = useContext(ActiveRunsContext);
  if (!ctx) {
    throw new Error(
      "useActiveRunsContext must be used inside <ActiveRunsProvider>",
    );
  }
  return ctx;
}
