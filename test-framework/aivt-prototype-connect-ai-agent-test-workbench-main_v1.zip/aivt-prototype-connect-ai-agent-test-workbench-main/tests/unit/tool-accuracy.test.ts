import { describe, it, expect } from "vitest";
import { calculateToolAccuracy } from "../../src/shared/utils/tool-accuracy";
import { ToolStep } from "../../src/shared/types";

describe("calculateToolAccuracy", () => {
  describe("basic scoring", () => {
    it("returns 1.0 when all required tools appear in order", () => {
      const expected: ToolStep[] = [
        { toolName: "A", required: true },
        { toolName: "B", required: true },
        { toolName: "C", required: true },
      ];
      const actual = ["A", "B", "C"];
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(1.0);
    });

    it("returns 1.0 when required tools appear in order with extras between", () => {
      const expected: ToolStep[] = [
        { toolName: "A", required: true },
        { toolName: "B", required: true },
      ];
      const actual = ["X", "A", "Y", "Z", "B", "W"];
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(1.0);
    });

    it("returns 0.0 when no required tools match", () => {
      const expected: ToolStep[] = [
        { toolName: "A", required: true },
        { toolName: "B", required: true },
      ];
      const actual = ["X", "Y", "Z"];
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(0.0);
    });

    it("returns partial score when some required tools match in order", () => {
      const expected: ToolStep[] = [
        { toolName: "A", required: true },
        { toolName: "B", required: true },
        { toolName: "C", required: true },
      ];
      const actual = ["A", "C"]; // B missing, but A and C are in order
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBeCloseTo(2 / 3, 3);
    });

    it("handles out-of-order required tools (only matches subsequence)", () => {
      const expected: ToolStep[] = [
        { toolName: "A", required: true },
        { toolName: "B", required: true },
        { toolName: "C", required: true },
      ];
      const actual = ["C", "B", "A"]; // Reversed — only first match (C? No, A not found after C)
      // A is not before B, B is not before C in actual. Only C matches at position 0.
      // Actually: searching for A from 0 → found at 2, then B from 3 → not found, then C from 3 → not found
      // Wait: A is at index 2, so search for B from index 3 — not found. Search for C from index 3 — not found.
      // So only A matches = 1/3
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBeCloseTo(1 / 3, 3);
    });
  });

  describe("optional steps", () => {
    it("optional steps don't affect denominator", () => {
      const expected: ToolStep[] = [
        { toolName: "A", required: true },
        { toolName: "OPT", required: false },
        { toolName: "B", required: true },
      ];
      const actual = ["A", "B"]; // OPT missing but it's optional
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(1.0);
      expect(result.optionalMatched).toBe(0);
      expect(result.optionalTotal).toBe(1);
    });

    it("optional steps count positively when present in order", () => {
      const expected: ToolStep[] = [
        { toolName: "A", required: true },
        { toolName: "OPT", required: false },
        { toolName: "B", required: true },
      ];
      const actual = ["A", "OPT", "B"];
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(1.0);
      expect(result.optionalMatched).toBe(1);
      expect(result.optionalTotal).toBe(1);
    });

    it("only optional steps yields score 1.0", () => {
      const expected: ToolStep[] = [
        { toolName: "OPT1", required: false },
        { toolName: "OPT2", required: false },
      ];
      const actual = ["OPT1"];
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(1.0);
      expect(result.optionalMatched).toBe(1);
      expect(result.optionalTotal).toBe(2);
    });
  });

  describe("edge cases", () => {
    it("returns 1.0 for empty expected list", () => {
      const result = calculateToolAccuracy([], ["A", "B"]);
      expect(result.score).toBe(1.0);
    });

    it("returns 0.0 when actual is empty but expected has required steps", () => {
      const expected: ToolStep[] = [{ toolName: "A", required: true }];
      const result = calculateToolAccuracy(expected, []);
      expect(result.score).toBe(0.0);
    });

    it("handles duplicate tool names in actual list", () => {
      const expected: ToolStep[] = [
        { toolName: "A", required: true },
        { toolName: "A", required: true },
      ];
      const actual = ["A", "B", "A"];
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(1.0);
    });

    it("handles single required step present", () => {
      const expected: ToolStep[] = [{ toolName: "A", required: true }];
      const actual = ["A"];
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(1.0);
    });

    it("handles single required step absent", () => {
      const expected: ToolStep[] = [{ toolName: "A", required: true }];
      const actual = ["B", "C"];
      const result = calculateToolAccuracy(expected, actual);
      expect(result.score).toBe(0.0);
    });
  });
});
