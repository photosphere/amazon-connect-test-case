/**
 * InstanceModeBadge — renders a visual badge in the application header
 * indicating whether the deployment is in "production" (read-only) or
 * "development" mode.
 *
 * Requirements addressed:
 *   - R19.5: WHEN INSTANCE_MODE === "production", render a visible
 *     "Production (read-only)" badge in the application header.
 *   - R19.6: WHEN INSTANCE_MODE === "development", render a "Development"
 *     badge in the application header.
 *
 * @module components/ImplementRecommendations/InstanceModeBadge
 */

import Badge from '@cloudscape-design/components/badge';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface InstanceModeBadgeProps {
  /** The current deployment instance mode. */
  instanceMode: 'production' | 'development';
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * Renders a color-coded Cloudscape Badge communicating the deployment mode.
 *
 * - "production" → red badge reading "Production (read-only)"
 * - "development" → green badge reading "Development"
 */
export function InstanceModeBadge({
  instanceMode,
}: InstanceModeBadgeProps): JSX.Element {
  if (instanceMode === 'production') {
    return <Badge color="red">Production (read-only)</Badge>;
  }

  return <Badge color="green">Development</Badge>;
}
