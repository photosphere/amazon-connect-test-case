/**
 * Recommendation structural validation.
 *
 * Validates that Recommendation objects conform to the platform's structural
 * rules before persistence or use in variant generation / apply flows.
 *
 * Requirements: 5.4, 13.1, 13.3
 *
 * @module validation
 */

import { Recommendation, ToolSurface } from "../../shared/types";

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/**
 * The four valid ToolSurface values. Used for O(1) membership checks.
 */
const VALID_TOOL_SURFACES: ReadonlySet<string> = new Set<ToolSurface>([
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
]);

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Validates a single Recommendation against structural rules:
 *
 * 1. `targetField` must be one of the four ToolSurface values.
 * 2. `targetName` must be a non-empty string (after trimming).
 * 3. At least one of `currentText` or `suggestedText` must be non-empty
 *    (no-op recommendations are rejected).
 *
 * For `tool_examples` operations, the combination of currentText/suggestedText
 * encodes the operation semantics (add/remove/replace). All three are valid
 * as long as rule 3 is satisfied — which it always is for valid operations:
 *   - "add": currentText empty, suggestedText non-empty ✓
 *   - "remove": currentText non-empty, suggestedText empty ✓
 *   - "replace": both non-empty ✓
 */
export function validateRecommendation(rec: Recommendation): ValidationResult {
  const errors: string[] = [];

  // Rule 1: targetField must be a valid ToolSurface value
  if (!VALID_TOOL_SURFACES.has(rec.targetField)) {
    errors.push(
      `Invalid targetField "${rec.targetField}". Must be one of: tool_description, tool_instruction, tool_examples, system_prompt.`
    );
  }

  // Rule 2: targetName must be non-empty after trimming
  if (!rec.targetName || rec.targetName.trim().length === 0) {
    errors.push("targetName must be a non-empty string.");
  }

  // Rule 3: At least one of currentText or suggestedText must be non-empty
  const hasCurrentText = rec.currentText != null && rec.currentText.length > 0;
  const hasSuggestedText =
    rec.suggestedText != null && rec.suggestedText.length > 0;

  if (!hasCurrentText && !hasSuggestedText) {
    errors.push(
      "At least one of currentText or suggestedText must be non-empty (no-op recommendations are not allowed)."
    );
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validates an array of Recommendation objects. Returns a single
 * ValidationResult aggregating all errors across all recommendations.
 * Each error is prefixed with its recommendation index for traceability.
 *
 * An empty array is considered valid (no recommendations to validate).
 */
export function validateRecommendations(
  recs: Recommendation[]
): ValidationResult {
  const errors: string[] = [];

  for (let i = 0; i < recs.length; i++) {
    const result = validateRecommendation(recs[i]);
    for (const error of result.errors) {
      errors.push(`Recommendation[${i}]: ${error}`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
