import * as cdk from "aws-cdk-lib";
import * as apigateway from "aws-cdk-lib/aws-apigateway";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as iam from "aws-cdk-lib/aws-iam";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { NodejsFunction } from "aws-cdk-lib/aws-lambda-nodejs";
import { Construct } from "constructs";
import { ExperimentStateMachine } from "../src/backend/orchestration/experiment-state-machine";
import { computeBedrockGrants } from "./bedrock-grants";
import type { ModelKey } from "../src/backend/orchestration/prompt-registry";

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface ImplementRecommendationsConstructProps {
  /** DynamoDB table (single-table design). */
  table: dynamodb.ITable;
  /** The Amazon Connect instance ID (UUID). */
  connectInstanceId: string;
  /** The Q in Connect assistant ID. */
  assistantId: string;
  /** Deploy-time mode controlling whether write operations are permitted. */
  instanceMode: "production" | "development";
  /** ARN of the existing TestRun state machine (used by experiment run triggers). */
  existingStateMachineArn: string;
  /** The shared API Gateway REST API. */
  api: apigateway.RestApi;
  /** Cognito authorizer for protecting endpoints. */
  authorizer: apigateway.IAuthorizer;
  /**
   * The shared Results Lambda (provisioned by ApiConstruct). The
   * Implement Recommendations construct mounts a single read-only
   * GET /runs/{runId}/experiments route on this Lambda so the Run
   * Dashboard can list a run's experiments without a separate handler.
   * The Lambda already has DynamoDB read access to the table, so no
   * additional IAM grant is needed.
   */
  resultsLambda: lambda.IFunction;
}

// ---------------------------------------------------------------------------
// Construct
// ---------------------------------------------------------------------------

/**
 * CDK construct that provisions the Implement Recommendations infrastructure:
 * - Lambda handlers: apply-recommendations, experiment-create, experiment-get,
 *   experiment-apply, experiment-cleanup, audit
 * - API Gateway routes with Cognito authorization
 * - Experiment State Machine (Step Functions)
 * - IAM roles scoped to the assistant ARN (no wildcard resources for writes)
 * - Conditional omission of write IAM actions when instanceMode === "production"
 *
 * Requirements: 16.1, 16.2, 16.3, 16.4, 19.7
 */
export class ImplementRecommendationsConstruct extends Construct {
  /** The Experiment State Machine. */
  public readonly experimentStateMachine: sfn.StateMachine;
  /** The apply-recommendations Lambda. */
  public readonly applyRecommendationsFn: lambda.Function;
  /** The experiment-create Lambda. */
  public readonly experimentCreateFn: lambda.Function;
  /** The experiment-get Lambda. */
  public readonly experimentGetFn: lambda.Function;
  /** The experiment-apply Lambda. */
  public readonly experimentApplyFn: lambda.Function;
  /** The experiment-cleanup Lambda. */
  public readonly experimentCleanupFn: lambda.Function;
  /** The audit Lambda. */
  public readonly auditFn: lambda.Function;
  /**
   * The shared Results Lambda passed in via props. Stored so
   * `configureRoutes` can mount the GET /runs/{runId}/experiments
   * route on it.
   */
  private readonly resultsLambda: lambda.IFunction;

  constructor(
    scope: Construct,
    id: string,
    props: ImplementRecommendationsConstructProps,
  ) {
    super(scope, id);

    const { table, assistantId, instanceMode, api, authorizer, resultsLambda } = props;
    // Store the results lambda so configureRoutes can mount the
    // GET /runs/{runId}/experiments method on it.
    this.resultsLambda = resultsLambda;

    const stack = cdk.Stack.of(this);
    const region = stack.region;
    const account = stack.account;

    // -------------------------------------------------------------------
    // Shared environment variables
    // -------------------------------------------------------------------
    const sharedEnv: Record<string, string> = {
      TABLE_NAME: table.tableName,
      INSTANCE_MODE: instanceMode,
      ASSISTANT_ID: assistantId,
    };

    // -------------------------------------------------------------------
    // Common Lambda configuration (matches project conventions)
    // -------------------------------------------------------------------
    const commonLambdaProps = {
      runtime: lambda.Runtime.NODEJS_24_X,
      architecture: lambda.Architecture.ARM_64,
      tracing: lambda.Tracing.ACTIVE,
      environment: sharedEnv,
      bundling: {
        // Include @aws-sdk/client-qconnect in the bundle rather than using the
        // Lambda runtime's built-in version, which lacks newer API fields.
        externalModules: [
          "@aws-sdk/client-dynamodb",
          "@aws-sdk/lib-dynamodb",
          "@aws-sdk/client-sfn",
          "@aws-sdk/client-bedrock-runtime",
          // Deliberately NOT excluding @aws-sdk/client-qconnect
        ],
      },
    };

    // -------------------------------------------------------------------
    // Q in Connect IAM resource ARNs scoped to the assistant (Req 16.2)
    // No wildcard resources for write operations.
    // -------------------------------------------------------------------
    const assistantScopedResources = [
      `arn:aws:wisdom:${region}:${account}:assistant/${assistantId}/*`,
      `arn:aws:qconnect:${region}:${account}:assistant/${assistantId}/*`,
      // AI agents and prompts live under their own resource-type namespace
      // (not under assistant/*), e.g. arn:aws:wisdom:...:ai-agent/{assistantId}/{agentId}
      `arn:aws:wisdom:${region}:${account}:ai-agent/${assistantId}/*`,
      `arn:aws:wisdom:${region}:${account}:ai-prompt/${assistantId}/*`,
      `arn:aws:qconnect:${region}:${account}:ai-agent/${assistantId}/*`,
      `arn:aws:qconnect:${region}:${account}:ai-prompt/${assistantId}/*`,
    ];

    // Read actions always granted (needed for drift detection, get operations)
    const qconnectReadActions = [
      "wisdom:GetAIAgent",
      "wisdom:GetAIPrompt",
      "qconnect:GetAIAgent",
      "qconnect:GetAIPrompt",
    ];

    // Write actions conditionally granted based on instanceMode (Req 16.1, 19.7)
    const qconnectWriteActions = [
      "wisdom:UpdateAIAgent",
      "wisdom:UpdateAIPrompt",
      "wisdom:CreateAIAgent",
      "wisdom:DeleteAIAgent",
      "qconnect:UpdateAIAgent",
      "qconnect:UpdateAIPrompt",
      "qconnect:CreateAIAgent",
      "qconnect:DeleteAIAgent",
    ];

    // -------------------------------------------------------------------
    // Bedrock grant summary — populated as each Bedrock-calling Lambda
    // is wired below via `computeBedrockGrants`. Surfaced on the
    // `ExperimentBedrockGrantSummary` CFN output (R19.6) so a deployment
    // review can read off which models each Lambda is permitted to
    // invoke without parsing the synthesised IAM JSON. Keyed by the
    // Lambda construct's logical id (the second argument to
    // `new NodejsFunction(this, ...)`) so the output's keys match what
    // shows up in the CFN template.
    //
    // Wave 0 posture (Task 10.3): the helper-derived
    // `iam.PolicyStatement` from `computeBedrockGrants` is attached
    // here for the experiment Lambdas that the Experiment State
    // Machine wires to the variant-generation and tournament-summary
    // promptKeys (`variantGeneratorFn: this.experimentCreateFn` and
    // `tournamentSummaryFn: this.experimentGetFn` in the SM
    // construction below). Today there is no inline `bedrock:*`
    // statement on either Lambda — Wave 2 (Tasks 17.4 / 17.5) wires
    // the actual Bedrock calls into the handlers, so attaching the
    // helper-derived grant now lets the registry control IAM at synth
    // time without a follow-up diff.
    const bedrockGrantSummary: Record<string, readonly ModelKey[]> = {};

    // -------------------------------------------------------------------
    // Lambda: Apply Recommendations
    // POST /runs/{runId}/apply-recommendations
    // -------------------------------------------------------------------
    this.applyRecommendationsFn = new NodejsFunction(
      this,
      "ApplyRecommendationsFn",
      {
        ...commonLambdaProps,
        entry: "src/backend/handlers/apply-recommendations.ts",
        handler: "handler",
        functionName: `${stack.stackName}-ApplyRecommendations`,
        description:
          "Applies recommended changes to the live agent config via Q in Connect APIs",
        timeout: cdk.Duration.seconds(30),
        memorySize: 256,
      },
    );

    table.grantReadWriteData(this.applyRecommendationsFn);
    this.applyRecommendationsFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "QConnectRead",
        effect: iam.Effect.ALLOW,
        actions: qconnectReadActions,
        resources: assistantScopedResources,
      }),
    );
    if (instanceMode !== "production") {
      this.applyRecommendationsFn.addToRolePolicy(
        new iam.PolicyStatement({
          sid: "QConnectWrite",
          effect: iam.Effect.ALLOW,
          actions: qconnectWriteActions,
          resources: assistantScopedResources,
        }),
      );
    }

    // -------------------------------------------------------------------
    // Lambda: Experiment Create
    // POST /runs/{runId}/experiments
    // -------------------------------------------------------------------
    this.experimentCreateFn = new NodejsFunction(
      this,
      "ExperimentCreateFn",
      {
        ...commonLambdaProps,
        entry: "src/backend/handlers/experiment-create.ts",
        handler: "handler",
        functionName: `${stack.stackName}-ExperimentCreate`,
        description:
          "Creates a multi-variant experiment: generates variants and starts the experiment state machine",
        timeout: cdk.Duration.seconds(30),
        memorySize: 256,
        environment: {
          ...sharedEnv,
          // Will be overridden below once the state machine is created
          EXPERIMENT_STATE_MACHINE_ARN: "",
        },
      },
    );

    table.grantReadWriteData(this.experimentCreateFn);

    // Wave 0 dual grant (R19.2): registry-derived statement for the
    // variant-generation Bedrock call. The Experiment State Machine
    // wires `variantGeneratorFn: this.experimentCreateFn`, so this
    // Lambda is the variant-generator runtime; `variant-generator.ts`
    // calls Bedrock Converse to produce three diverse rewrites of the
    // source recommendations.
    {
      const grant = computeBedrockGrants({
        promptKeys: ["variant_generation"],
        stack,
      });
      this.experimentCreateFn.addToRolePolicy(grant.statement);
      bedrockGrantSummary.ExperimentCreateFn = grant.modelKeys;
    }

    // -------------------------------------------------------------------
    // Lambda: Experiment Get
    // GET /runs/{runId}/experiments/{experimentId}
    // -------------------------------------------------------------------
    this.experimentGetFn = new NodejsFunction(this, "ExperimentGetFn", {
      ...commonLambdaProps,
      entry: "src/backend/handlers/experiment-get.ts",
      handler: "handler",
      functionName: `${stack.stackName}-ExperimentGet`,
      description: "Returns the full experiment state from DynamoDB",
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
    });

    table.grantReadWriteData(this.experimentGetFn);

    // Permission to describe SFN executions for status reconciliation —
    // if the state machine fails without updating DDB, the get handler
    // detects this by checking the execution status and self-heals.
    this.experimentGetFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "DescribeExperimentExecution",
        effect: iam.Effect.ALLOW,
        actions: ["states:DescribeExecution"],
        resources: ["*"],
      }),
    );

    // Wave 0 dual grant (R19.2): registry-derived statement for the
    // tournament-summary Bedrock call. The Experiment State Machine
    // wires `tournamentSummaryFn: this.experimentGetFn`, so this
    // Lambda is the tournament-summary runtime;
    // `tournament-summary.ts` calls Bedrock Converse to explain the
    // deterministic baseline-vs-variant tournament outcome in plain
    // language.
    {
      const grant = computeBedrockGrants({
        promptKeys: ["tournament_summary"],
        stack,
      });
      this.experimentGetFn.addToRolePolicy(grant.statement);
      bedrockGrantSummary.ExperimentGetFn = grant.modelKeys;
    }

    // -------------------------------------------------------------------
    // Lambda: Experiment Apply
    // POST /runs/{runId}/experiments/{experimentId}/apply
    // -------------------------------------------------------------------
    this.experimentApplyFn = new NodejsFunction(
      this,
      "ExperimentApplyFn",
      {
        ...commonLambdaProps,
        entry: "src/backend/handlers/experiment-apply.ts",
        handler: "handler",
        functionName: `${stack.stackName}-ExperimentApply`,
        description:
          "Applies a winning experiment variant to the live agent config",
        timeout: cdk.Duration.seconds(30),
        memorySize: 256,
      },
    );

    table.grantReadWriteData(this.experimentApplyFn);
    this.experimentApplyFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "QConnectRead",
        effect: iam.Effect.ALLOW,
        actions: qconnectReadActions,
        resources: assistantScopedResources,
      }),
    );
    if (instanceMode !== "production") {
      this.experimentApplyFn.addToRolePolicy(
        new iam.PolicyStatement({
          sid: "QConnectWrite",
          effect: iam.Effect.ALLOW,
          actions: qconnectWriteActions,
          resources: assistantScopedResources,
        }),
      );
    }

    // -------------------------------------------------------------------
    // Lambda: Experiment Cleanup
    // Invoked by the Experiment State Machine (not directly by API Gateway)
    // -------------------------------------------------------------------
    this.experimentCleanupFn = new NodejsFunction(
      this,
      "ExperimentCleanupFn",
      {
        ...commonLambdaProps,
        entry: "src/backend/handlers/experiment-cleanup.ts",
        handler: "handler",
        functionName: `${stack.stackName}-ExperimentCleanup`,
        description:
          "Deletes temporary agents after experiment completes (same IAM as creation, Req 16.4)",
        timeout: cdk.Duration.seconds(60),
        memorySize: 256,
      },
    );

    table.grantReadWriteData(this.experimentCleanupFn);
    // Cleanup uses the same scoped permissions as creation (Req 16.4)
    this.experimentCleanupFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "QConnectRead",
        effect: iam.Effect.ALLOW,
        actions: qconnectReadActions,
        resources: assistantScopedResources,
      }),
    );
    if (instanceMode !== "production") {
      this.experimentCleanupFn.addToRolePolicy(
        new iam.PolicyStatement({
          sid: "QConnectWrite",
          effect: iam.Effect.ALLOW,
          actions: qconnectWriteActions,
          resources: assistantScopedResources,
        }),
      );
    }

    // -------------------------------------------------------------------
    // Lambda: Audit
    // GET /audit
    // -------------------------------------------------------------------
    this.auditFn = new NodejsFunction(this, "AuditFn", {
      ...commonLambdaProps,
      entry: "src/backend/handlers/audit.ts",
      handler: "handler",
      functionName: `${stack.stackName}-Audit`,
      description:
        "Returns the authenticated user's audit records in reverse chronological order",
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
    });

    table.grantReadData(this.auditFn);

    // -------------------------------------------------------------------
    // Experiment State Machine
    // -------------------------------------------------------------------
    // The Experiment State Machine reuses the cleanup Lambda for both the
    // cleanup step and the rollback-on-creation-failure step.
    // The experiment-create handler also doubles as the run trigger, status
    // updater, and variant generator within the state machine context.
    // For MVP, we pass the same Lambdas for multiple roles — the state
    // machine steps differentiate by payload content.
    const experimentStateMachineConstruct = new ExperimentStateMachine(
      this,
      "ExperimentSM",
      {
        variantGeneratorFn: this.experimentCreateFn,
        agentCreatorFn: this.experimentCreateFn,
        runTriggerFn: this.experimentCreateFn,
        pollRunStatusFn: this.experimentGetFn,
        tournamentSummaryFn: this.experimentGetFn,
        cleanupFn: this.experimentCleanupFn,
        statusUpdaterFn: this.experimentCreateFn,
      },
    );

    this.experimentStateMachine =
      experimentStateMachineConstruct.stateMachine;

    // Wire the state machine ARN back into experiment-create Lambda.
    // IMPORTANT: A direct reference to `stateMachineArn` or `stateMachineName`
    // in the Lambda's environment creates a CloudFormation dependency cycle:
    //   ApiDeployment → ExperimentCreateFn → StateMachine → StateMachineRole → ExperimentCreateFn
    // The SM definition invokes this Lambda (so SM depends on Lambda).
    // Fix: Give the SM a deterministic physical name and construct the ARN
    // from it without any CloudFormation Ref/GetAtt to the SM resource.
    const experimentSmName = `${stack.stackName}-ExperimentSM`;
    const cfnStateMachine = this.experimentStateMachine.node
      .defaultChild as sfn.CfnStateMachine;
    cfnStateMachine.stateMachineName = experimentSmName;

    // Now set the env var using a literal string ARN (no Ref to the SM).
    const cfnExperimentCreateFn = this.experimentCreateFn.node
      .defaultChild as cdk.CfnResource;
    cfnExperimentCreateFn.addPropertyOverride(
      "Environment.Variables.EXPERIMENT_STATE_MACHINE_ARN",
      `arn:aws:states:${region}:${account}:stateMachine:${experimentSmName}`,
    );

    // Grant experiment-create the ability to start the state machine (Req 16.1).
    // Use the deterministic ARN constructed above.
    this.experimentCreateFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "StartExperimentStateMachine",
        effect: iam.Effect.ALLOW,
        actions: ["states:StartExecution"],
        resources: [
          `arn:aws:states:${region}:${account}:stateMachine:${experimentSmName}`,
        ],
      }),
    );

    // -------------------------------------------------------------------
    // API Gateway Routes
    // -------------------------------------------------------------------
    // IMPORTANT: every method in this construct MUST set authorizationScopes
    // to include the `test-platform/run` custom scope, exactly as
    // ApiConstruct does. With `authorizationScopes` UNSET, API Gateway's
    // Cognito authorizer falls back to validating ID tokens — but the
    // frontend (and any machine-client integration) sends ACCESS tokens.
    // The mismatch surfaces as a 401 "Unauthorized" from the authorizer
    // before the request ever reaches the Lambda. The 401 has no CORS
    // headers either, so browsers report it as a CORS failure. (We
    // discovered this on the first request from the Run Dashboard's
    // mount-time GET /runs/{runId}/experiments fetch; every other route
    // in this construct had the same bug but had never been exercised
    // because their UI entry-points are gated on having recommendations.)
    const authOptions: apigateway.MethodOptions = {
      authorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
      authorizationScopes: ["test-platform/run"],
    };

    this.configureRoutes(api, authOptions);

    // -------------------------------------------------------------------
    // Outputs
    // -------------------------------------------------------------------
    new cdk.CfnOutput(this, "ExperimentStateMachineArn", {
      value: this.experimentStateMachine.stateMachineArn,
      description: "Experiment State Machine ARN",
    });

    // R19.6: surface the helper-derived Bedrock grant summary for the
    // experiment Lambdas (variant generator + tournament summary) on
    // the CFN template as a single JSON map keyed by Lambda logical
    // id with the alphabetically-sorted `modelKeys[]` each Lambda is
    // permitted to invoke.
    //
    // Named `ExperimentBedrockGrantSummary` (not `BedrockGrantSummary`)
    // so it does not collide with the same output emitted by
    // `api-construct.ts` (`BedrockGrantSummary`) or
    // `orchestration-construct.ts` (`OrchestrationBedrockGrantSummary`).
    // Each construct emits its own per-construct summary — there can
    // only be one CFN output per logical id per stack.
    new cdk.CfnOutput(this, "ExperimentBedrockGrantSummary", {
      value: JSON.stringify(bedrockGrantSummary),
      description:
        "Map of implement-recommendations Bedrock-calling Lambda logical id -> readonly ModelKey[] derived from computeBedrockGrants (R19.6).",
    });
  }

  /**
   * Configure API Gateway routes for the implement-recommendations feature.
   */
  private configureRoutes(
    api: apigateway.RestApi,
    authOptions: apigateway.MethodOptions,
  ): void {
    // Find or create the /runs resource
    const runs = this.findOrCreateResource(api.root, "runs");

    // /runs/{runId}
    const runById = this.findOrCreateResource(runs, "{runId}");

    // --- POST /runs/{runId}/apply-recommendations ---
    const applyRecommendations = runById.addResource(
      "apply-recommendations",
    );
    applyRecommendations.addMethod(
      "POST",
      new apigateway.LambdaIntegration(this.applyRecommendationsFn),
      authOptions,
    );

    // --- POST /runs/{runId}/revert-apply ---
    const revertApply = runById.addResource("revert-apply");
    revertApply.addMethod(
      "POST",
      new apigateway.LambdaIntegration(this.applyRecommendationsFn),
      authOptions,
    );

    // --- GET /runs/{runId}/apply-status ---
    const applyStatus = runById.addResource("apply-status");
    applyStatus.addMethod(
      "GET",
      new apigateway.LambdaIntegration(this.applyRecommendationsFn),
      authOptions,
    );

    // --- /runs/{runId}/experiments ---
    const experiments = runById.addResource("experiments");
    experiments.addMethod(
      "POST",
      new apigateway.LambdaIntegration(this.experimentCreateFn),
      authOptions,
    );
    // GET on the same resource lists every experiment associated with the
    // run. Routed to the shared Results Lambda (read-only, already has the
    // DynamoDB read grant). Without this route the Run Dashboard's
    // mount-time list call would hit an unconfigured method on the
    // experiments resource and API Gateway would respond with 403, which
    // the frontend's auth-aware client treats as a session expiry.
    experiments.addMethod(
      "GET",
      new apigateway.LambdaIntegration(this.resultsLambda),
      authOptions,
    );

    // --- /runs/{runId}/experiments/{experimentId} ---
    const experimentById = experiments.addResource("{experimentId}");
    experimentById.addMethod(
      "GET",
      new apigateway.LambdaIntegration(this.experimentGetFn),
      authOptions,
    );

    // --- /runs/{runId}/experiments/{experimentId}/apply ---
    const experimentApply = experimentById.addResource("apply");
    experimentApply.addMethod(
      "POST",
      new apigateway.LambdaIntegration(this.experimentApplyFn),
      authOptions,
    );

    // --- GET /audit ---
    const audit = api.root.addResource("audit");
    audit.addMethod(
      "GET",
      new apigateway.LambdaIntegration(this.auditFn),
      authOptions,
    );
  }

  /**
   * Helper to find an existing API Gateway resource child by path part,
   * or create it if it doesn't exist. This avoids conflicts when the
   * resource has already been created by another construct (e.g. ApiConstruct).
   */
  private findOrCreateResource(
    parent: apigateway.IResource,
    pathPart: string,
  ): apigateway.Resource {
    // Check if the resource already exists among the children
    const existing = parent.getResource(pathPart);
    if (existing) {
      return existing as apigateway.Resource;
    }
    return parent.addResource(pathPart);
  }
}
