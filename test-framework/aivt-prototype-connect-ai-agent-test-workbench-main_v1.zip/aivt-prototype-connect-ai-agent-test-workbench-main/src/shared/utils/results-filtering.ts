/**
 * Results filtering utility for the test results display.
 *
 * Filters test case results by status and/or by tool invoked.
 * When multiple criteria are provided, all must match (AND logic).
 *
 * @module results-filtering
 */

import { CaseStatus } from "../enums";

/** Minimum shape required for filtering — a result with status and toolsInvoked. */
export interface FilterableResult {
  status: CaseStatus;
  toolsInvoked: string[];
}

/** Criteria for filtering results. All provided fields must match (AND). */
export interface FilterCriteria {
  /** Filter to results matching one of these statuses. */
  status?: CaseStatus[];
  /** Filter to results that include this tool in their toolsInvoked array. */
  toolInvoked?: string;
}

/**
 * Filters test case results by the given criteria.
 *
 * - If `criteria.status` is provided, only results whose status is in the
 *   array are included.
 * - If `criteria.toolInvoked` is provided, only results whose `toolsInvoked`
 *   array contains that tool name (case-insensitive) are included.
 * - When both filters are provided, a result must satisfy both (AND logic).
 * - If criteria is empty or undefined, all results are returned.
 *
 * Returns a new array — does not mutate the input.
 *
 * @param results - Array of filterable results
 * @param criteria - Filter criteria to apply
 * @returns A new filtered array
 *
 * @example
 * filterResults(results, { status: [CaseStatus.FAILED, CaseStatus.ERROR] })
 * // Returns only failed and error results
 *
 * @example
 * filterResults(results, { toolInvoked: "SearchFlights" })
 * // Returns only results where SearchFlights was invoked
 *
 * @example
 * filterResults(results, { status: [CaseStatus.PASSED], toolInvoked: "BookFlight" })
 * // Returns only passed results where BookFlight was invoked
 */
export function filterResults<T extends FilterableResult>(
  results: T[],
  criteria?: FilterCriteria,
): T[] {
  if (!results || results.length === 0) {
    return [];
  }

  if (!criteria || (!criteria.status && !criteria.toolInvoked)) {
    return [...results];
  }

  return results.filter((result) => {
    // Status filter
    if (criteria.status && criteria.status.length > 0) {
      if (!criteria.status.includes(result.status)) {
        return false;
      }
    }

    // Tool invoked filter (case-insensitive)
    if (criteria.toolInvoked) {
      const toolLower = criteria.toolInvoked.toLowerCase();
      const hasMatchingTool = result.toolsInvoked.some(
        (t) => t.toLowerCase() === toolLower,
      );
      if (!hasMatchingTool) {
        return false;
      }
    }

    return true;
  });
}
