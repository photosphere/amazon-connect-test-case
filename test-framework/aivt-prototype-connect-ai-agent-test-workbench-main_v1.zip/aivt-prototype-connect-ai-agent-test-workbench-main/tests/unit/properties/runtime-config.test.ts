// Feature: platform-hosting-and-evaluations, Property 1: Runtime config is complete-or-rejected
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { buildRuntimeConfig } from '../../../lib/runtime-config';

/**
 * **Validates: Requirements 3.2, 3.6, 13.1, 13.2**
 *
 * Property 1: Runtime config is complete-or-rejected
 * For any set of resolved outputs, `buildRuntimeConfig` either returns an object
 * whose keys are EXACTLY the five non-secret runtime-config fields (each a
 * non-empty string equal to its input) when all five are present and non-blank,
 * or throws when any field is missing/empty/whitespace. It never emits any other
 * key (no M2M secret, no Secrets Manager values).
 */

const FIELDS = [
  'apiEndpoint',
  'cognitoUserPoolId',
  'cognitoClientId',
  'cognitoDomain',
  'region',
  'instanceMode',
] as const;

type Field = (typeof FIELDS)[number];

/** A non-blank string: contains at least one non-whitespace character. */
const nonBlankString = fc
  .string({ minLength: 1, maxLength: 60 })
  .filter((s) => s.trim().length > 0);

/** A blank value: undefined, empty, or whitespace-only. */
const blankValue = fc.oneof(
  fc.constant(undefined),
  fc.constant(''),
  fc.constantFrom(' ', '   ', '\t', '\n', ' \t\n ')
);

/** A complete, all-valid input record. */
const completeInputArb = fc.record({
  apiEndpoint: nonBlankString,
  cognitoUserPoolId: nonBlankString,
  cognitoClientId: nonBlankString,
  cognitoDomain: nonBlankString,
  region: nonBlankString,
  instanceMode: nonBlankString,
});

describe('Property 1: Runtime config is complete-or-rejected', () => {
  it('returns exactly the five fields with matching values when all are non-blank', () => {
    fc.assert(
      fc.property(completeInputArb, (input) => {
        const result = buildRuntimeConfig(input);

        // Keys are exactly the five expected fields — no extra (secret) keys.
        expect(Object.keys(result).sort()).toEqual([...FIELDS].sort());

        // Every value is preserved verbatim.
        for (const field of FIELDS) {
          expect(result[field]).toBe(input[field]);
        }
      }),
      { numRuns: 100 }
    );
  });

  it('never emits a key outside the five non-secret fields, even when extra keys are present in input', () => {
    // Sentinel-prefixed arbitraries: keep secret material disjoint from any
    // legitimate field value (which is an arbitrary non-blank string), so a
    // by-coincidence string equality cannot masquerade as a leak.
    const secretSentinel = 'SECRET_DO_NOT_LEAK::';
    const arnSentinel = 'arn:aws:secretsmanager:DO_NOT_LEAK::';
    const secretValueArb = nonBlankString.map((s) => `${secretSentinel}${s}`);
    const secretArnArb = nonBlankString.map((s) => `${arnSentinel}${s}`);

    fc.assert(
      fc.property(
        completeInputArb,
        secretValueArb,
        secretArnArb,
        (input, secretValue, secretArn) => {
          // Simulate accidental extra/secret inputs being passed in.
          const polluted = {
            ...input,
            machineClientSecret: secretValue,
            machineClientSecretArn: secretArn,
          } as Record<string, string>;

          const result = buildRuntimeConfig(polluted);

          expect(Object.keys(result).sort()).toEqual([...FIELDS].sort());
          // Ensure no value leaked the secret material — checked both as a
          // direct membership test and by sentinel substring, so any future
          // partial-leak (e.g. concatenation) would also be caught.
          const values = Object.values(result);
          expect(values).not.toContain(secretValue);
          expect(values).not.toContain(secretArn);
          for (const value of values) {
            expect(value.includes(secretSentinel)).toBe(false);
            expect(value.includes(arnSentinel)).toBe(false);
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  it('throws when any single required field is blank/missing', () => {
    const fieldArb = fc.constantFrom<Field>(...FIELDS);
    fc.assert(
      fc.property(completeInputArb, fieldArb, blankValue, (input, field, blank) => {
        const broken: Record<string, string | undefined> = { ...input };
        broken[field] = blank;
        expect(() => buildRuntimeConfig(broken)).toThrow();
      }),
      { numRuns: 100 }
    );
  });

  it('throws when an arbitrary non-empty subset of fields is blank', () => {
    fc.assert(
      fc.property(
        completeInputArb,
        fc
          .subarray([...FIELDS], { minLength: 1 })
          .map((arr) => arr as Field[]),
        blankValue,
        (input, fieldsToBreak, blank) => {
          const broken: Record<string, string | undefined> = { ...input };
          for (const field of fieldsToBreak) {
            broken[field] = blank;
          }
          expect(() => buildRuntimeConfig(broken)).toThrow();
        }
      ),
      { numRuns: 100 }
    );
  });
});
