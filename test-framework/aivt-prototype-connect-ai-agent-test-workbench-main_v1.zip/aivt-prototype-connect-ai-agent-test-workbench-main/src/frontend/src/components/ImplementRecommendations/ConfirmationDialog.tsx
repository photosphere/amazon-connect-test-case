/**
 * ConfirmationDialog — Modal showing a side-by-side diff of all changes that
 * will be written to the agent configuration when the user confirms a Direct
 * Apply (or Apply Winning Variant) operation.
 *
 * Layout:
 *   - Header: "Confirm Changes to {agentName}"
 *   - Agent ID displayed below header
 *   - Warning banner (Alert)
 *   - Changes grouped by Tool_Surface and tool name
 *   - Each recommendation rendered as a side-by-side diff:
 *       - Add (empty currentText): left empty, right green
 *       - Remove (empty suggestedText): left red, right empty
 *       - Replace: left red, right green
 *   - Footer: Cancel + Confirm and Apply (primary, loading state)
 *
 * Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7
 *
 * @module components/ImplementRecommendations/ConfirmationDialog
 */

import Modal from '@cloudscape-design/components/modal';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Box from '@cloudscape-design/components/box';
import Alert from '@cloudscape-design/components/alert';
import Button from '@cloudscape-design/components/button';
import Container from '@cloudscape-design/components/container';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import Header from '@cloudscape-design/components/header';
import type { Recommendation } from '../../../../shared/types';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface ConfirmationDialogProps {
  visible: boolean;
  agentName: string;
  agentId: string;
  recommendations: Recommendation[];
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Group key for a recommendation — combines targetField and targetName. */
function groupKey(rec: Recommendation): string {
  return `${rec.targetField}::${rec.targetName}`;
}

/** Human-readable group header from targetField and targetName. */
function groupLabel(targetField: string, targetName: string): string {
  if (targetField === 'system_prompt') {
    return 'system_prompt';
  }
  return `${targetField} — ${targetName}`;
}

/**
 * Determine the operation type from a recommendation's currentText/suggestedText.
 * - add: currentText is empty
 * - remove: suggestedText is empty
 * - replace: both are non-empty
 */
function getOperation(rec: Recommendation): 'add' | 'remove' | 'replace' {
  if (!rec.currentText) return 'add';
  if (!rec.suggestedText) return 'remove';
  return 'replace';
}

/** CSS styles for diff highlighting. */
const diffStyles = {
  added: {
    backgroundColor: 'rgba(0, 161, 0, 0.1)',
    borderLeft: '3px solid #0d8a0d',
    padding: '8px 12px',
    borderRadius: '4px',
    whiteSpace: 'pre-wrap' as const,
    wordBreak: 'break-word' as const,
    fontFamily: 'monospace',
    fontSize: '13px',
    lineHeight: '1.5',
  },
  removed: {
    backgroundColor: 'rgba(214, 39, 39, 0.08)',
    borderLeft: '3px solid #d13212',
    padding: '8px 12px',
    borderRadius: '4px',
    whiteSpace: 'pre-wrap' as const,
    wordBreak: 'break-word' as const,
    fontFamily: 'monospace',
    fontSize: '13px',
    lineHeight: '1.5',
  },
  empty: {
    backgroundColor: '#f2f3f3',
    padding: '8px 12px',
    borderRadius: '4px',
    minHeight: '40px',
    display: 'flex' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    color: '#5f6b7a',
    fontStyle: 'italic' as const,
  },
};

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

interface DiffPaneProps {
  text: string;
  variant: 'added' | 'removed' | 'empty';
  label: string;
}

function DiffPane({ text, variant, label }: DiffPaneProps): JSX.Element {
  if (variant === 'empty') {
    return (
      <div style={diffStyles.empty} aria-label={`${label}: empty`}>
        (empty)
      </div>
    );
  }

  const style = variant === 'added' ? diffStyles.added : diffStyles.removed;

  return (
    <div style={style} aria-label={`${label}: ${text}`}>
      {text}
    </div>
  );
}

interface RecommendationDiffProps {
  recommendation: Recommendation;
}

function RecommendationDiff({ recommendation }: RecommendationDiffProps): JSX.Element {
  const operation = getOperation(recommendation);

  return (
    <ColumnLayout columns={2}>
      <div>
        <Box variant="awsui-key-label" margin={{ bottom: 'xxs' }}>
          Current
        </Box>
        {operation === 'add' ? (
          <DiffPane text="" variant="empty" label="Current text" />
        ) : (
          <DiffPane text={recommendation.currentText} variant="removed" label="Current text" />
        )}
      </div>
      <div>
        <Box variant="awsui-key-label" margin={{ bottom: 'xxs' }}>
          Suggested
        </Box>
        {operation === 'remove' ? (
          <DiffPane text="" variant="empty" label="Suggested text" />
        ) : (
          <DiffPane text={recommendation.suggestedText} variant="added" label="Suggested text" />
        )}
      </div>
    </ColumnLayout>
  );
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function ConfirmationDialog({
  visible,
  agentName,
  agentId,
  recommendations,
  onConfirm,
  onCancel,
  loading = false,
}: ConfirmationDialogProps): JSX.Element {
  // Group recommendations by targetField + targetName
  const groups = new Map<string, Recommendation[]>();
  for (const rec of recommendations) {
    const key = groupKey(rec);
    const existing = groups.get(key);
    if (existing) {
      existing.push(rec);
    } else {
      groups.set(key, [rec]);
    }
  }

  return (
    <Modal
      visible={visible}
      onDismiss={onCancel}
      header={`Confirm Changes to ${agentName}`}
      size="max"
      footer={
        <Box float="right">
          <SpaceBetween direction="horizontal" size="xs">
            <Button variant="link" onClick={onCancel} disabled={loading}>
              Cancel
            </Button>
            <Button variant="primary" onClick={onConfirm} loading={loading}>
              Confirm and Apply
            </Button>
          </SpaceBetween>
        </Box>
      }
    >
      <SpaceBetween size="l">
        {/* Agent identifier (R2.3) */}
        <Box variant="small" color="text-body-secondary">
          Agent ID: {agentId}
        </Box>

        {/* Warning banner (R2.4) */}
        <Alert type="warning" statusIconAriaLabel="Warning">
          This will make changes to your configured agent. Do you want to proceed?
        </Alert>

        {/* Grouped diffs (R2.2) */}
        {Array.from(groups.entries()).map(([key, recs]) => {
          const [targetField, targetName] = key.split('::');
          return (
            <Container
              key={key}
              header={
                <Header variant="h3">
                  {groupLabel(targetField, targetName)}
                </Header>
              }
            >
              <SpaceBetween size="m">
                {recs.map((rec, idx) => (
                  <div key={idx}>
                    {rec.rationale && (
                      <Box variant="small" color="text-body-secondary" margin={{ bottom: 'xs' }}>
                        {rec.rationale}
                      </Box>
                    )}
                    <RecommendationDiff recommendation={rec} />
                  </div>
                ))}
              </SpaceBetween>
            </Container>
          );
        })}
      </SpaceBetween>
    </Modal>
  );
}
