/**
 * Step Functions state machine definition for Multi-Variant Experiment orchestration.
 *
 * Defines the CDK construct for the experiment state machine:
 *   GenerateVariants → ValidateVariants → CreateTempAgents
 *     → Parallel(TriggerRunA, TriggerRunB, TriggerRunC)
 *     → GenerateSummary → Cleanup → MarkCompleted
 *
 * Error handling:
 *   - Variant generation failure: mark experiment as failed, no cleanup needed
 *   - Agent creation failure: rollback any created agents, mark failed
 *   - Single variant run failure: continue others, mark variant as error
 *   - Cleanup failure: mark partial_failure, log orphaned IDs
 *
 * @module experiment-state-machine
 */

import * as cdk from "aws-cdk-lib";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import * as tasks from "aws-cdk-lib/aws-stepfunctions-tasks";
import * as lambda from "aws-cdk-lib/aws-lambda";
import { Construct } from "constructs";

// ---------------------------------------------------------------------------
// Construct Props
// ---------------------------------------------------------------------------

export interface ExperimentStateMachineProps {
  /** Lambda that generates 3 diverse variant configurations via Bedrock. */
  variantGeneratorFn: lambda.IFunction;
  /** Lambda that creates temporary agents via CreateAIAgent for each variant. */
  agentCreatorFn: lambda.IFunction;
  /** Lambda that triggers existing TestRun SM per variant. */
  runTriggerFn: lambda.IFunction;
  /** Lambda that polls variant run completion status. */
  pollRunStatusFn: lambda.IFunction;
  /** Lambda that generates AI tournament summary via Bedrock. */
  tournamentSummaryFn: lambda.IFunction;
  /** Lambda that deletes temporary agents after experiment completes. */
  cleanupFn: lambda.IFunction;
  /** Lambda that updates the experiment DynamoDB record status. */
  statusUpdaterFn: lambda.IFunction;
}

// ---------------------------------------------------------------------------
// Construct
// ---------------------------------------------------------------------------

/**
 * CDK construct that creates a Step Functions state machine for multi-variant
 * experiment orchestration.
 *
 * Flow:
 *   GenerateVariants → ValidateVariants → CreateTempAgents
 *     → Parallel(RunVariantA, RunVariantB, RunVariantC)
 *     → GenerateSummary → Cleanup → MarkCompleted
 *
 * The Parallel state runs 3 variant test suites concurrently, each with an
 * individual Catch handler that marks the variant as errored without aborting
 * the other branches.
 *
 * Cleanup runs unconditionally after the parallel stage completes — regardless
 * of whether individual variants succeeded or failed — ensuring temporary
 * agents are always deleted (R10.4).
 *
 * Error isolation:
 *   - Agent creation failure triggers a RollbackAgents step that deletes any
 *     already-created agents before marking the experiment as failed.
 *   - A single variant run failure does not abort siblings — the parallel state
 *     catches per-branch errors and marks variants as "error" individually.
 */
export class ExperimentStateMachine extends Construct {
  /** The Step Functions state machine. */
  public readonly stateMachine: sfn.StateMachine;

  constructor(
    scope: Construct,
    id: string,
    props: ExperimentStateMachineProps,
  ) {
    super(scope, id);

    // -------------------------------------------------------------------
    // Step 1: GenerateVariants
    // Calls Bedrock to produce 3 diverse variant configurations from
    // the source recommendations.
    // Input: { runId, experimentId, agentId, recommendations, agentSnapshot }
    // Output: { ...input, variantConfigs: VariantConfig[] }
    // -------------------------------------------------------------------
    const generateVariants = new tasks.LambdaInvoke(
      this,
      "GenerateVariants",
      {
        lambdaFunction: props.variantGeneratorFn,
        outputPath: "$.Payload",
        retryOnServiceExceptions: true,
      },
    );

    // -------------------------------------------------------------------
    // Step 2: ValidateVariants
    // Updates experiment status to "creating_agents" if variants are valid.
    // The variant generator already validates internally; this step persists
    // the status transition and checks that at least 2 variants were produced.
    // -------------------------------------------------------------------
    const validateVariants = new tasks.LambdaInvoke(
      this,
      "ValidateVariants",
      {
        lambdaFunction: props.statusUpdaterFn,
        payload: sfn.TaskInput.fromObject({
          "experimentId.$": "$.experimentId",
          "runId.$": "$.runId",
          status: "creating_agents",
          "variantConfigs.$": "$.variantConfigs",
        }),
        outputPath: "$.Payload",
        retryOnServiceExceptions: true,
      },
    );

    // -------------------------------------------------------------------
    // Step 3: CreateTempAgents
    // Creates 3 temporary agents (one per variant) via CreateAIAgent,
    // cloning the target agent config with variant changes applied.
    // Output: { ...input, temporaryAgentIds: Record<"A"|"B"|"C", string> }
    // -------------------------------------------------------------------
    const createTempAgents = new tasks.LambdaInvoke(
      this,
      "CreateTempAgents",
      {
        lambdaFunction: props.agentCreatorFn,
        outputPath: "$.Payload",
        retryOnServiceExceptions: true,
      },
    );

    // -------------------------------------------------------------------
    // Rollback step: Delete any already-created agents on creation failure
    // -------------------------------------------------------------------
    const rollbackAgents = new tasks.LambdaInvoke(this, "RollbackAgents", {
      lambdaFunction: props.cleanupFn,
      payload: sfn.TaskInput.fromObject({
        "experimentId.$": "$.experimentId",
        "runId.$": "$.runId",
        "temporaryAgentIds.$": "$.temporaryAgentIds",
        "assistantId.$": "$.assistantId",
      }),
      resultPath: "$.rollbackResult",
      retryOnServiceExceptions: true,
    });

    // Mark experiment as failed after rollback
    const markFailedAfterRollback = new tasks.LambdaInvoke(
      this,
      "MarkFailedAfterRollback",
      {
        lambdaFunction: props.statusUpdaterFn,
        payload: sfn.TaskInput.fromObject({
          "experimentId.$": "$.experimentId",
          "runId.$": "$.runId",
          status: "failed",
          "error.$": "$.error",
        }),
        outputPath: "$.Payload",
        retryOnServiceExceptions: true,
      },
    );

    rollbackAgents.next(markFailedAfterRollback);

    // Add catch to CreateTempAgents: on failure, rollback created agents
    createTempAgents.addCatch(rollbackAgents, {
      errors: ["States.ALL"],
      resultPath: "$.error",
    });

    // -------------------------------------------------------------------
    // Step 4: Update status to "running"
    // -------------------------------------------------------------------
    const markRunning = new tasks.LambdaInvoke(this, "MarkRunning", {
      lambdaFunction: props.statusUpdaterFn,
      payload: sfn.TaskInput.fromObject({
        "experimentId.$": "$.experimentId",
        "runId.$": "$.runId",
        status: "running",
        "temporaryAgentIds.$": "$.temporaryAgentIds",
      }),
      resultPath: "$.statusUpdate",
      retryOnServiceExceptions: true,
    });

    // -------------------------------------------------------------------
    // Step 5: Parallel variant runs
    // Each branch triggers a test run against one variant's temporary agent,
    // then polls until completion. Individual catch handlers mark the variant
    // as errored without aborting siblings.
    // -------------------------------------------------------------------

    // Helper to create a single variant run branch
    const createVariantBranch = (
      variantLetter: "A" | "B" | "C",
    ): sfn.IChainable => {
      // Trigger the test run for this variant
      const triggerRun = new tasks.LambdaInvoke(
        this,
        `TriggerRun${variantLetter}`,
        {
          lambdaFunction: props.runTriggerFn,
          payload: sfn.TaskInput.fromObject({
            "experimentId.$": "$.experimentId",
            "runId.$": "$.runId",
            variantLetter,
            "agentId.$": `$.temporaryAgentIds.${variantLetter}`,
            "suiteId.$": "$.suiteId",
            "assistantId.$": "$.assistantId",
          }),
          outputPath: "$.Payload",
          retryOnServiceExceptions: true,
        },
      );

      // Poll until the variant run completes
      const pollStatus = new tasks.LambdaInvoke(
        this,
        `PollStatus${variantLetter}`,
        {
          lambdaFunction: props.pollRunStatusFn,
          outputPath: "$.Payload",
          retryOnServiceExceptions: true,
        },
      );

      // Wait state for polling interval (30 seconds between polls)
      const waitForPoll = new sfn.Wait(
        this,
        `WaitForPoll${variantLetter}`,
        {
          time: sfn.WaitTime.duration(cdk.Duration.seconds(30)),
        },
      );

      // Choice: is the variant run complete?
      const isComplete = new sfn.Choice(
        this,
        `IsComplete${variantLetter}`,
      );

      // Terminal pass state for completed variant
      const variantDone = new sfn.Pass(
        this,
        `VariantDone${variantLetter}`,
      );

      // Polling loop: poll → check → (wait → poll) or done
      isComplete
        .when(
          sfn.Condition.stringEquals("$.status", "completed"),
          variantDone,
        )
        .when(
          sfn.Condition.stringEquals("$.status", "failed"),
          variantDone,
        )
        .otherwise(waitForPoll.next(pollStatus));

      // Chain: Trigger → Poll → Choice loop
      const branchChain = triggerRun.next(pollStatus).next(isComplete);

      return branchChain;
    };

    // Create the parallel state with 3 variant branches
    const parallelRuns = new sfn.Parallel(this, "RunVariantsParallel", {
      resultPath: "$.variantResults",
    });

    parallelRuns.branch(createVariantBranch("A"));
    parallelRuns.branch(createVariantBranch("B"));
    parallelRuns.branch(createVariantBranch("C"));

    // Individual variant errors are caught at the branch level.
    // Each branch's catch marks the variant as errored but does not abort
    // sibling branches. The Parallel state catches to allow continuation.
    const markVariantError = new sfn.Pass(this, "MarkVariantError", {
      parameters: {
        status: "error",
        "error.$": "$.error",
      },
    });

    parallelRuns.addCatch(markVariantError, {
      errors: ["States.ALL"],
      resultPath: "$.parallelError",
    });

    // -------------------------------------------------------------------
    // Step 6: GenerateSummary
    // Calls Bedrock to produce tournament summary comparing baseline vs variants.
    // -------------------------------------------------------------------
    const generateSummary = new tasks.LambdaInvoke(
      this,
      "GenerateSummary",
      {
        lambdaFunction: props.tournamentSummaryFn,
        resultPath: "$.summaryResult",
        retryOnServiceExceptions: true,
      },
    );

    // If summary generation fails, continue to cleanup (non-fatal)
    const summaryCatchPass = new sfn.Pass(this, "SummaryCatchPass", {
      parameters: {
        summaryError: "Tournament summary generation failed",
        "error.$": "$.error",
      },
      resultPath: "$.summaryResult",
    });

    generateSummary.addCatch(summaryCatchPass, {
      errors: ["States.ALL"],
      resultPath: "$.error",
    });

    // -------------------------------------------------------------------
    // Step 7: Cleanup
    // Deletes all temporary agents. Runs UNCONDITIONALLY regardless of
    // variant success/failure (R10.4). Uses resultPath to capture any
    // cleanup errors without stopping execution.
    // -------------------------------------------------------------------
    const cleanup = new tasks.LambdaInvoke(this, "Cleanup", {
      lambdaFunction: props.cleanupFn,
      payload: sfn.TaskInput.fromObject({
        "experimentId.$": "$.experimentId",
        "runId.$": "$.runId",
        "temporaryAgentIds.$": "$.temporaryAgentIdsList",
        "assistantId.$": "$.assistantId",
      }),
      resultPath: "$.cleanupResult",
      retryOnServiceExceptions: true,
    });

    // Even if cleanup fails, proceed to mark completed
    const cleanupCatchPass = new sfn.Pass(this, "CleanupCatchPass", {
      parameters: {
        cleanupStatus: "partial_failure",
        "error.$": "$.error",
      },
      resultPath: "$.cleanupResult",
    });

    cleanup.addCatch(cleanupCatchPass, {
      errors: ["States.ALL"],
      resultPath: "$.error",
    });

    // -------------------------------------------------------------------
    // Step 8: MarkCompleted
    // Updates experiment status to "completed" in DynamoDB.
    // -------------------------------------------------------------------
    const markCompleted = new tasks.LambdaInvoke(this, "MarkCompleted", {
      lambdaFunction: props.statusUpdaterFn,
      payload: sfn.TaskInput.fromObject({
        "experimentId.$": "$.experimentId",
        "runId.$": "$.runId",
        status: "completed",
        "variantResults.$": "$.variantResults",
        "summaryResult.$": "$.summaryResult",
        "cleanupResult.$": "$.cleanupResult",
      }),
      outputPath: "$.Payload",
      retryOnServiceExceptions: true,
    });

    // -------------------------------------------------------------------
    // Step: Mark failed on variant generation error
    // -------------------------------------------------------------------
    const markFailedGeneration = new tasks.LambdaInvoke(
      this,
      "MarkFailedGeneration",
      {
        lambdaFunction: props.statusUpdaterFn,
        payload: sfn.TaskInput.fromObject({
          "experimentId.$": "$.experimentId",
          "runId.$": "$.runId",
          status: "failed",
          "error.$": "$.error",
        }),
        outputPath: "$.Payload",
        retryOnServiceExceptions: true,
      },
    );

    // Add catch to GenerateVariants: on failure, mark experiment as failed
    generateVariants.addCatch(markFailedGeneration, {
      errors: ["States.ALL"],
      resultPath: "$.error",
    });

    // Add catch to ValidateVariants: on failure, mark experiment as failed
    validateVariants.addCatch(markFailedGeneration, {
      errors: ["States.ALL"],
      resultPath: "$.error",
    });

    // -------------------------------------------------------------------
    // Wire the happy path chain
    // -------------------------------------------------------------------

    // After parallel catches all-branch error, continue to summary (partial results)
    markVariantError.next(generateSummary);

    // After summaryCatchPass, continue to cleanup
    summaryCatchPass.next(cleanup);

    // After cleanupCatchPass, continue to markCompleted
    cleanupCatchPass.next(markCompleted);

    // Main chain: happy path flows through all steps sequentially.
    // generateSummary → cleanup → markCompleted is wired here.
    generateSummary.next(cleanup).next(markCompleted);

    const definition = generateVariants
      .next(validateVariants)
      .next(createTempAgents)
      .next(markRunning)
      .next(parallelRuns)
      .next(generateSummary);

    // -------------------------------------------------------------------
    // Create the state machine
    // -------------------------------------------------------------------
    this.stateMachine = new sfn.StateMachine(this, "ExperimentStateMachine", {
      definitionBody: sfn.DefinitionBody.fromChainable(definition),
      timeout: cdk.Duration.hours(3),
      tracingEnabled: true,
      comment:
        "Orchestrates multi-variant experiment: GenerateVariants → ValidateVariants → CreateTempAgents → Parallel(3×RunVariant) → GenerateSummary → Cleanup → MarkCompleted",
    });
  }
}
