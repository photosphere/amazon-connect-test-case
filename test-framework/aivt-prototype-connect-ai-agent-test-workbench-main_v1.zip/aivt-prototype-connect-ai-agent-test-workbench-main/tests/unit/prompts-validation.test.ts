/**
 * Unit tests for the validation pipeline functions in
 * `src/backend/handlers/prompts-validation.ts`.
 *
 * The pipeline is the gate that the `PUT /prompts/{promptKey}` handler
 * runs before persisting any override (R4.5–R4.10, R12.3–R12.5). This
 * file covers each stage in isolation with two test shapes:
 *
 *   1. A passing case (`{ ok: true }`) that confirms the stage accepts a
 *      well-formed input.
 *   2. One failing case per distinct structured error code the stage
 *      returns. Each failing case is its own `it()` so a regression in
 *      one stage cannot accidentally re-test the wrong code.
 *
 * The error codes covered, mapped to their owning stage:
 *
 *   - `validateTextSize`                    →  `PROMPT_TEXT_TOO_LARGE`
 *   - `validatePlaceholdersPresent`         →  `PLACEHOLDERS_MISSING`
 *   - `validatePlaceholderOccurrenceCap`    →  `PLACEHOLDER_COUNT_EXCEEDED`
 *   - `validateNoUnknownPlaceholders`       →  `UNKNOWN_PLACEHOLDER`
 *   - `validateModelMembership`             →  `MODEL_NOT_ALLOWED`
 *   - `validateCapabilityProfileCompliance` →  `MODEL_FORBIDS_KEY`
 *   - `validateNumericBounds`               →  `INFERENCE_PARAMETER_OUT_OF_BOUNDS`
 *   - `validateDryRender`                   →  `DRY_RENDER_FAILED`
 *
 * Wherever practical the tests use real prompts from `PROMPT_REGISTRY`
 * (`judge_helpfulness` for placeholder-rich cases, `failure_analysis`
 * for placeholder-free cases). Synthetic `PromptDefinition` fixtures are
 * used only where the real registry has no natural fit — for example
 * to drive a 10-byte size cap or a `maxOccurrences=1` placeholder cap.
 *
 * _Validates: Requirements 4.5, 4.6, 4.7, 4.8, 4.9, 4.10, 12.3, 12.4, 12.5_
 */

import { describe, expect, it } from "vitest";

import {
  validateCapabilityProfileCompliance,
  validateDryRender,
  validateModelMembership,
  validateNoUnknownPlaceholders,
  validateNumericBounds,
  validatePlaceholderOccurrenceCap,
  validatePlaceholdersPresent,
  validateTextSize,
} from "../../src/backend/handlers/prompts-validation";
import { PROMPT_REGISTRY } from "../../src/backend/orchestration/prompt-registry";
import type {
  ModelKey,
  PromptDefinition,
} from "../../src/backend/orchestration/prompt-registry";
import { PROMPT_TEXT_DEFAULT_MAX_BYTES } from "../../src/shared/constants";

// ---------------------------------------------------------------------------
// Helpers — narrow type guards for the result discriminator. Using these
// keeps each `expect()` line short and lets TypeScript narrow `result.code`
// inside an `if (result.ok === false)` branch.
// ---------------------------------------------------------------------------

/** Assert a `ValidationResult` carries an `ok: false` outcome with a code. */
function expectFailure(
  result: { ok: true } | { ok: false; code: string; details?: unknown },
  code: string,
): asserts result is { ok: false; code: string; details?: unknown } {
  expect(result.ok).toBe(false);
  if (!result.ok) {
    expect(result.code).toBe(code);
  }
}

// ---------------------------------------------------------------------------
// Synthetic prompt fixtures
//
// These are small, focused PromptDefinitions used by tests where no
// natural registry fit exists — for example, a 10-byte size cap to make
// PROMPT_TEXT_TOO_LARGE trivial to trigger, or a maxOccurrences=1 cap
// for the occurrence-cap stage. Each fixture is intentionally minimal:
// only the fields the stage actually reads are populated meaningfully.
// ---------------------------------------------------------------------------

/**
 * A synthetic prompt with a 10-byte text cap. Drives the
 * `PROMPT_TEXT_TOO_LARGE` failing case without requiring us to construct
 * a 64+ KiB string in the test file.
 */
const TINY_CAP_PROMPT: PromptDefinition = {
  promptKey: "failure_analysis",
  name: "Tiny-cap synthetic",
  description: "Synthetic prompt used by the size-cap test",
  category: "analysis",
  defaultText: "ok",
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ["claude_sonnet_4_6"],
  placeholders: [],
  maxTextBytes: 10,
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 1_024 },
  },
  defaultInferenceValues: { maxTokens: 1_024 },
};

/**
 * A synthetic prompt that declares a single placeholder capped at one
 * occurrence. Drives the `PLACEHOLDER_COUNT_EXCEEDED` failing case.
 */
const SINGLE_OCCURRENCE_PROMPT: PromptDefinition = {
  promptKey: "failure_analysis",
  name: "Single-occurrence synthetic",
  description: "Synthetic prompt used by the occurrence-cap test",
  category: "analysis",
  defaultText: "Hello {context}",
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ["claude_sonnet_4_6"],
  placeholders: [
    {
      name: "context",
      description: "single-occurrence placeholder",
      maxOccurrences: 1,
    },
  ],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 1_024 },
  },
  defaultInferenceValues: { maxTokens: 1_024 },
};

// Pull the real registry definitions used by several stages so the tests
// stay aligned with what production code actually executes.
const FAILURE_ANALYSIS = PROMPT_REGISTRY.failure_analysis;
const JUDGE_HELPFULNESS = PROMPT_REGISTRY.judge_helpfulness;

// ---------------------------------------------------------------------------
// validateTextSize — PROMPT_TEXT_TOO_LARGE
// ---------------------------------------------------------------------------

describe("validateTextSize — PROMPT_TEXT_TOO_LARGE", () => {
  it("returns ok for text within the size cap", () => {
    const result = validateTextSize("short text", FAILURE_ANALYSIS);
    expect(result).toEqual({ ok: true });
  });

  it("returns ok when text is undefined (sparse override)", () => {
    const result = validateTextSize(undefined, FAILURE_ANALYSIS);
    expect(result).toEqual({ ok: true });
  });

  it("returns PROMPT_TEXT_TOO_LARGE when text exceeds the prompt's per-prompt cap", () => {
    // Synthetic prompt with maxTextBytes=10; "exceeds-the-cap" is 16 bytes.
    const oversize = "exceeds-the-cap!";
    const result = validateTextSize(oversize, TINY_CAP_PROMPT);

    expectFailure(result, "PROMPT_TEXT_TOO_LARGE");
    expect(result.details).toMatchObject({
      observedBytes: Buffer.byteLength(oversize, "utf8"),
      limitBytes: 10,
    });
  });

  it("returns PROMPT_TEXT_TOO_LARGE when text exceeds the default 64 KiB cap", () => {
    // A registry prompt without `maxTextBytes` falls back to the default
    // PROMPT_TEXT_DEFAULT_MAX_BYTES; assemble a string one byte over.
    const oversize = "a".repeat(PROMPT_TEXT_DEFAULT_MAX_BYTES + 1);
    const result = validateTextSize(oversize, FAILURE_ANALYSIS);

    expectFailure(result, "PROMPT_TEXT_TOO_LARGE");
    expect(result.details).toMatchObject({
      observedBytes: PROMPT_TEXT_DEFAULT_MAX_BYTES + 1,
      limitBytes: PROMPT_TEXT_DEFAULT_MAX_BYTES,
    });
  });
});

// ---------------------------------------------------------------------------
// validatePlaceholdersPresent — PLACEHOLDERS_MISSING
// ---------------------------------------------------------------------------

describe("validatePlaceholdersPresent — PLACEHOLDERS_MISSING", () => {
  it("returns ok when every declared placeholder appears at least once", () => {
    const text =
      "Score this turn.\nContext: {context}\nAssistant turn: {assistant_turn}";
    const result = validatePlaceholdersPresent(text, JUDGE_HELPFULNESS);
    expect(result).toEqual({ ok: true });
  });

  it("returns ok when text is undefined (sparse override)", () => {
    const result = validatePlaceholdersPresent(undefined, JUDGE_HELPFULNESS);
    expect(result).toEqual({ ok: true });
  });

  it("returns PLACEHOLDERS_MISSING when {context} is absent from a judge_helpfulness edit", () => {
    // judge_helpfulness declares {context} and {assistant_turn}; this
    // candidate text only includes {assistant_turn}.
    const text = "Helpfulness check for {assistant_turn} — no context block.";
    const result = validatePlaceholdersPresent(text, JUDGE_HELPFULNESS);

    expectFailure(result, "PLACEHOLDERS_MISSING");
    expect(result.details).toMatchObject({ missing: ["context"] });
  });
});

// ---------------------------------------------------------------------------
// validatePlaceholderOccurrenceCap — PLACEHOLDER_COUNT_EXCEEDED
// ---------------------------------------------------------------------------

describe("validatePlaceholderOccurrenceCap — PLACEHOLDER_COUNT_EXCEEDED", () => {
  it("returns ok when every declared placeholder is within its cap", () => {
    const text = "Hello {context}";
    const result = validatePlaceholderOccurrenceCap(
      text,
      SINGLE_OCCURRENCE_PROMPT,
    );
    expect(result).toEqual({ ok: true });
  });

  it("returns ok when text is undefined (sparse override)", () => {
    const result = validatePlaceholderOccurrenceCap(
      undefined,
      SINGLE_OCCURRENCE_PROMPT,
    );
    expect(result).toEqual({ ok: true });
  });

  it("returns PLACEHOLDER_COUNT_EXCEEDED when {context} appears twice but the cap is one", () => {
    // Synthetic prompt declares {context} with maxOccurrences=1.
    const text = "First: {context}, second: {context}";
    const result = validatePlaceholderOccurrenceCap(
      text,
      SINGLE_OCCURRENCE_PROMPT,
    );

    expectFailure(result, "PLACEHOLDER_COUNT_EXCEEDED");
    expect(result.details).toMatchObject({
      placeholder: "context",
      observed: 2,
      max: 1,
    });
  });
});

// ---------------------------------------------------------------------------
// validateNoUnknownPlaceholders — UNKNOWN_PLACEHOLDER
// ---------------------------------------------------------------------------

describe("validateNoUnknownPlaceholders — UNKNOWN_PLACEHOLDER", () => {
  it("returns ok when every {name} token names a declared placeholder", () => {
    const text =
      "Context: {context}\nAssistant turn: {assistant_turn}\nNo undeclared tokens.";
    const result = validateNoUnknownPlaceholders(text, JUDGE_HELPFULNESS);
    expect(result).toEqual({ ok: true });
  });

  it("returns ok when text is undefined (sparse override)", () => {
    const result = validateNoUnknownPlaceholders(undefined, JUDGE_HELPFULNESS);
    expect(result).toEqual({ ok: true });
  });

  it("returns UNKNOWN_PLACEHOLDER when text contains a {undeclared} token", () => {
    // judge_helpfulness declares {context} and {assistant_turn}.
    // {undeclared} is not declared and not inside any literalBraceRegions.
    const text =
      "Context: {context}\nAssistant turn: {assistant_turn}\nExtra: {undeclared}";
    const result = validateNoUnknownPlaceholders(text, JUDGE_HELPFULNESS);

    expectFailure(result, "UNKNOWN_PLACEHOLDER");
    expect(result.details).toMatchObject({
      token: "{undeclared}",
    });
    // Sanity-check that the offset points at the token start in the text.
    if (!result.ok && result.details) {
      const offset = (result.details as { offset: number }).offset;
      expect(text.slice(offset, offset + "{undeclared}".length)).toBe(
        "{undeclared}",
      );
    }
  });
});

// ---------------------------------------------------------------------------
// validateModelMembership — MODEL_NOT_ALLOWED
// ---------------------------------------------------------------------------

describe("validateModelMembership — MODEL_NOT_ALLOWED", () => {
  it("returns ok when the supplied modelKey is in allowedModels[]", () => {
    const result = validateModelMembership(
      "claude_sonnet_4_6",
      FAILURE_ANALYSIS,
    );
    expect(result).toEqual({ ok: true });
  });

  it("returns ok when modelKey is undefined (sparse override)", () => {
    const result = validateModelMembership(undefined, FAILURE_ANALYSIS);
    expect(result).toEqual({ ok: true });
  });

  it("returns MODEL_NOT_ALLOWED when the supplied modelKey is not in allowedModels[]", () => {
    // Use a synthetic prompt whose allowedModels[] is restricted to a
    // single entry — `failure_analysis`'s real registry definition
    // accepts every supported model, so a real ModelKey wouldn't be
    // enough to trigger this stage on it.
    const restrictedPrompt: PromptDefinition = {
      ...FAILURE_ANALYSIS,
      allowedModels: ["claude_sonnet_4_6"],
    };
    const result = validateModelMembership("nova_pro", restrictedPrompt);

    expectFailure(result, "MODEL_NOT_ALLOWED");
    expect(result.details).toMatchObject({
      requested: "nova_pro",
      allowed: ["claude_sonnet_4_6"],
    });
  });
});

// ---------------------------------------------------------------------------
// validateCapabilityProfileCompliance — MODEL_FORBIDS_KEY
// ---------------------------------------------------------------------------

describe("validateCapabilityProfileCompliance — MODEL_FORBIDS_KEY", () => {
  it("returns ok when every key is accepted by the resolved capability profile", () => {
    // Anthropic 4.x family accepts only `maxTokens`.
    const result = validateCapabilityProfileCompliance(
      { maxTokens: 1024 },
      "claude_sonnet_4_6",
    );
    expect(result).toEqual({ ok: true });
  });

  it("returns ok when inferenceParameters is undefined (sparse override)", () => {
    const result = validateCapabilityProfileCompliance(
      undefined,
      "claude_sonnet_4_6",
    );
    expect(result).toEqual({ ok: true });
  });

  it("returns MODEL_FORBIDS_KEY for `temperature` against an Anthropic 4.x model", () => {
    // The `anthropic_claude_4x_lax` profile (Sonnet 4.6, Haiku 4.5)
    // does not include `temperature` in its accept lists, so the
    // validator emits MODEL_FORBIDS_KEY when it appears in the
    // override. The same MODEL_FORBIDS_KEY code is emitted for keys
    // outside `acceptsTopLevel ∪ acceptsAdditional` and for keys on
    // `forbids[]` — see `validateCapabilityProfileCompliance` for the
    // structural-equivalence rationale.
    const result = validateCapabilityProfileCompliance(
      { temperature: 0.5 },
      "claude_sonnet_4_6",
    );

    expectFailure(result, "MODEL_FORBIDS_KEY");
    expect(result.details).toMatchObject({
      key: "temperature",
      profile: "anthropic_claude_4x_lax",
    });
  });

  it("returns MODEL_FORBIDS_KEY for `temperature` against the strict anthropic_claude_4x profile (Opus 4.8)", () => {
    // The `anthropic_claude_4x` strict profile lists `temperature` in
    // `forbids[]`. Same MODEL_FORBIDS_KEY code as the lax-profile case
    // above; the only structural difference is the profile name on the
    // `details.profile` field.
    const result = validateCapabilityProfileCompliance(
      { temperature: 0.5 },
      "claude_opus_4_8",
    );

    expectFailure(result, "MODEL_FORBIDS_KEY");
    expect(result.details).toMatchObject({
      key: "temperature",
      profile: "anthropic_claude_4x",
    });
  });
});

// ---------------------------------------------------------------------------
// validateNumericBounds — INFERENCE_PARAMETER_OUT_OF_BOUNDS
// ---------------------------------------------------------------------------

describe("validateNumericBounds — INFERENCE_PARAMETER_OUT_OF_BOUNDS", () => {
  it("returns ok when every numeric parameter lies inside its effective range", () => {
    // failure_analysis declares maxTokens with min=1, max=64_000; 4_096 is
    // well within the closed interval and within Sonnet 4.6's 64k ceiling.
    const result = validateNumericBounds(
      { maxTokens: 4_096 },
      FAILURE_ANALYSIS,
      "claude_sonnet_4_6",
    );
    expect(result).toEqual({ ok: true });
  });

  it("returns ok when inferenceParameters is undefined (sparse override)", () => {
    const result = validateNumericBounds(
      undefined,
      FAILURE_ANALYSIS,
      "claude_sonnet_4_6",
    );
    expect(result).toEqual({ ok: true });
  });

  it("returns INFERENCE_PARAMETER_OUT_OF_BOUNDS for maxTokens=-1 (below the schema min)", () => {
    const result = validateNumericBounds(
      { maxTokens: -1 },
      FAILURE_ANALYSIS,
      "claude_sonnet_4_6",
    );

    expectFailure(result, "INFERENCE_PARAMETER_OUT_OF_BOUNDS");
    expect(result.details).toMatchObject({
      key: "maxTokens",
      value: -1,
    });
    if (!result.ok && result.details) {
      const range = (result.details as {
        range: { min: number; max: number };
      }).range;
      expect(range.min).toBeGreaterThanOrEqual(1);
    }
  });

  it("returns INFERENCE_PARAMETER_OUT_OF_BOUNDS for maxTokens above the model's maxOutputTokens cap", () => {
    // Sonnet 4.6 has maxOutputTokens=64_000; 200_000 is over the
    // intersection cap even though `Number.MAX_SAFE_INTEGER` is the
    // capability-profile ceiling.
    const result = validateNumericBounds(
      { maxTokens: 200_000 },
      FAILURE_ANALYSIS,
      "claude_sonnet_4_6",
    );

    expectFailure(result, "INFERENCE_PARAMETER_OUT_OF_BOUNDS");
    expect(result.details).toMatchObject({
      key: "maxTokens",
      value: 200_000,
    });
  });
});

// ---------------------------------------------------------------------------
// validateDryRender — DRY_RENDER_FAILED
//
// This stage builds a `ConverseCommand` (without sending it) so any
// SDK-side validation throw or `buildInferenceConfig` throw surfaces as
// `DRY_RENDER_FAILED`. Forcing a real SDK throw is brittle because the
// SDK constructor is permissive on most fields — instead, we wedge the
// failure on `buildInferenceConfig` by handing it an unknown modelKey
// (which it cannot resolve in `SUPPORTED_MODELS`). That path returns the
// `MODEL_NOT_ALLOWED` short-circuit, so for the DRY_RENDER_FAILED
// surface we exercise the `step: "ConverseCommand"` branch by
// constructing a synthetic profile-mismatch scenario: pass a non-Bedrock
// shape for `inferenceConfig` keys (e.g. an integer `maxTokens` that the
// SDK doesn't choke on directly, but the `system` block to include a
// non-string entry that the SDK rejects synchronously).
//
// Easier path: SDK-level validation rejects a non-string `text` field on
// the `system` block at construction time.
// ---------------------------------------------------------------------------

describe("validateDryRender — DRY_RENDER_FAILED", () => {
  it("returns ok for a well-formed (text, modelKey, inferenceParameters) triple", () => {
    const result = validateDryRender(
      "validate this synthetic prompt",
      "claude_sonnet_4_6",
      { maxTokens: 1024 },
    );
    expect(result).toEqual({ ok: true });
  });

  it("returns DRY_RENDER_FAILED when buildInferenceConfig throws", () => {
    // Force `buildInferenceConfig` to throw by using a Proxy on the
    // inferenceParameters that surfaces `Object.prototype.hasOwnProperty`
    // as a thrower. The helper guards each accepted key with
    // `Object.prototype.hasOwnProperty.call(inferenceParameters, key)`,
    // so a `getOwnPropertyDescriptor` trap that throws cascades into
    // `hasOwnProperty.call` for an `in`-style check via the trap chain.
    //
    // Implementation: reading any `[Symbol.iterator]` key on an object
    // that has had its `Object.prototype.hasOwnProperty` poisoned is too
    // invasive. Use a simpler trick: pass a Proxy as
    // `inferenceParameters` whose `getOwnPropertyDescriptor` trap
    // throws. `hasOwnProperty.call(proxy, "maxTokens")` consults the
    // proxy's `[[GetOwnProperty]]` internal slot which routes through
    // the `getOwnPropertyDescriptor` trap.
    const throwingParams = new Proxy(
      { maxTokens: 1024 },
      {
        getOwnPropertyDescriptor() {
          throw new Error("synthetic getOwnPropertyDescriptor failure");
        },
      },
    ) as unknown as Readonly<Record<string, unknown>>;

    const result = validateDryRender(
      "validate this synthetic prompt",
      "claude_sonnet_4_6",
      throwingParams,
    );

    expectFailure(result, "DRY_RENDER_FAILED");
    expect(result.details).toMatchObject({
      step: "buildInferenceConfig",
    });
    if (!result.ok && result.details) {
      const message = (result.details as { message: string }).message;
      expect(message).toContain("synthetic getOwnPropertyDescriptor failure");
    }
  });

  it("returns MODEL_NOT_ALLOWED short-circuit when handed an unknown modelKey", () => {
    // Defensive guard: the dry-render stage refuses to construct a
    // ConverseCommand against a model that is not in SUPPORTED_MODELS.
    // This isn't a DRY_RENDER_FAILED case but it exercises the
    // dry-render function's pre-flight check that the design enumerates
    // alongside the dry-render contract.
    const result = validateDryRender(
      "validate this synthetic prompt",
      "not_a_real_model" as unknown as ModelKey,
      { maxTokens: 1024 },
    );

    expectFailure(result, "MODEL_NOT_ALLOWED");
  });
});
