/**
 * Unit tests for the Bedrock Conformance_Probe builders (Task 11.3).
 *
 * Validates: Requirements 18.7.
 *
 * The probe runner exposes pure builders — `buildPositiveProbe`,
 * `buildNegativeProbe`, `buildRagJobProbe` — and a `runProbe` driver that
 * is `--dry-run`-aware. These tests pin the wire shapes the builders emit
 * for each Model_Capability_Profile so a registry edit that drifts the
 * profile away from what Bedrock actually accepts surfaces here BEFORE
 * the live conformance run is attempted (and BEFORE the probe spends
 * Bedrock tokens chasing the regression).
 *
 * Coverage:
 *
 *   1. Positive probe shape — Anthropic 4.x: `inferenceConfig` contains
 *      exactly `{ maxTokens: 32 }` (the R18.8 cost cap), no
 *      `additionalModelRequestFields`, `modelId` equals the model's
 *      `inferenceProfileId`, and the synthetic "ping" message is carried.
 *
 *   2. Positive probe shape — Nova: `inferenceConfig` carries all four
 *      profile-level keys (`maxTokens=32`, `temperature`, `topP`,
 *      `stopSequences`), `topK` is nested under
 *      `additionalModelRequestFields.inferenceConfig.topK` (R17.4) and
 *      never bubbled to the top-level config.
 *
 *   3. Negative probe shape — Anthropic 4.x: exactly one forbidden key
 *      is injected (`temperature=0.5`) on top of the accepted keys, and
 *      `expectedNegativeKey` is set to `"temperature"`.
 *
 *   4. Negative probe — Nova: returns `null` because the `amazon_nova`
 *      profile's `forbids[]` is empty.
 *
 *   5. RAG-job probe: with the three required env vars set, the
 *      `CreateEvaluationJobCommand` carries the resolved evaluator model
 *      id under
 *      `evaluationConfig.automated.evaluatorModelConfig.bedrockEvaluatorModels[].modelIdentifier`.
 *      Without the env vars, the builder returns `null` so the runner can
 *      report the RAG-job probe as skipped.
 *
 *   6. `runProbe` in dry-run mode returns the synthetic-success outcome
 *      and never calls the underlying client's `send`.
 *
 * @module tests/unit/bedrock-probe-dry-run
 */

import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import {
  ConverseCommand,
  type BedrockRuntimeClient,
} from "@aws-sdk/client-bedrock-runtime";
import {
  CreateEvaluationJobCommand,
  type BedrockClient,
} from "@aws-sdk/client-bedrock";

import {
  buildNegativeProbe,
  buildPositiveProbe,
  buildRagJobProbe,
  runProbe,
} from "../../scripts/bedrock-probe";
import {
  CAPABILITY_PROFILES,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";

// ---------------------------------------------------------------------------
// Helpers — mock SDK clients
// ---------------------------------------------------------------------------

/**
 * Build a duck-typed `BedrockRuntimeClient` whose `.send` is a vitest
 * mock. The cast through `unknown` mirrors the
 * `tests/unit/bedrock-judge-client.test.ts` pattern: the test never
 * instantiates a real client, and the probe's `--dry-run` path never
 * touches `.send` anyway, so the mock just needs the right method
 * signature for the cast to succeed.
 */
function makeMockRuntimeClient(): {
  client: BedrockRuntimeClient;
  send: ReturnType<typeof vi.fn>;
} {
  const send = vi.fn();
  return {
    client: { send } as unknown as BedrockRuntimeClient,
    send,
  };
}

/** Same shape, for the `BedrockClient` (control-plane) used by the RAG-job probe. */
function makeMockBedrockClient(): {
  client: BedrockClient;
  send: ReturnType<typeof vi.fn>;
} {
  const send = vi.fn();
  return {
    client: { send } as unknown as BedrockClient,
    send,
  };
}

// ---------------------------------------------------------------------------
// Positive probe — Anthropic 4.x (strict + lax profiles share the same
// positive-probe shape because both have `acceptsTopLevel = ["maxTokens"]`)
// ---------------------------------------------------------------------------

const ANTHROPIC_MODEL_KEYS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
] as const;

/**
 * The strict-profile subset of Anthropic models — Opus 4.8 is the only
 * model that wire-rejects `temperature` (`temperature is deprecated for
 * this model`), so it's the only one whose negative probe runs.
 */
const ANTHROPIC_STRICT_MODEL_KEYS = ["claude_opus_4_8"] as const;

/**
 * The lax-profile subset of Anthropic models — Sonnet 4.6 and Haiku 4.5
 * silently accept and drop the legacy sampling keys at the wire, so the
 * negative probe is a doc-lag sentinel that doesn't apply here. The lax
 * profile carries an empty `forbids[]` and the runner reports the
 * negative probe as `skipped: true` with the standard reason.
 */
const ANTHROPIC_LAX_MODEL_KEYS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
] as const;

describe("buildPositiveProbe — Anthropic 4.x profile", () => {
  it.each(ANTHROPIC_MODEL_KEYS)(
    "[%s] inferenceConfig contains exactly { maxTokens: 32 } and no additionalModelRequestFields",
    (modelKey) => {
      const model = SUPPORTED_MODELS[modelKey];
      const probe = buildPositiveProbe(model);

      expect(probe.kind).toBe("positive");
      expect(probe.modelKey).toBe(modelKey);
      expect(probe.command).toBeInstanceOf(ConverseCommand);

      const input = (probe.command as ConverseCommand).input;

      // Anthropic 4.x profile only accepts `maxTokens` top-level. The probe
      // also pins `maxTokens=32` per R18.8's cost cap.
      expect(input.inferenceConfig).toEqual({ maxTokens: 32 });
      expect(Object.keys(input.inferenceConfig ?? {})).toEqual(["maxTokens"]);

      // `acceptsAdditional` is empty for this profile, so the spread that
      // attaches `additionalModelRequestFields` should be omitted entirely.
      expect(input.additionalModelRequestFields).toBeUndefined();

      // `modelId` is the canonical cross-region inference profile id.
      expect(input.modelId).toBe(model.inferenceProfileId);

      // Messages carry the synthetic "ping" user turn.
      expect(input.messages).toEqual([
        { role: "user", content: [{ text: "ping" }] },
      ]);
    },
  );
});

// ---------------------------------------------------------------------------
// Positive probe — Amazon Nova
// ---------------------------------------------------------------------------

const NOVA_MODEL_KEYS = ["nova_lite", "nova_pro"] as const;

describe("buildPositiveProbe — Amazon Nova profile", () => {
  it.each(NOVA_MODEL_KEYS)(
    "[%s] inferenceConfig carries the four top-level keys; topK lives under additionalModelRequestFields.inferenceConfig",
    (modelKey) => {
      const model = SUPPORTED_MODELS[modelKey];
      const probe = buildPositiveProbe(model);

      expect(probe.kind).toBe("positive");
      expect(probe.modelKey).toBe(modelKey);
      expect(probe.command).toBeInstanceOf(ConverseCommand);

      const input = (probe.command as ConverseCommand).input;
      const inferenceConfig = input.inferenceConfig as
        | Record<string, unknown>
        | undefined;
      expect(inferenceConfig).toBeDefined();

      // Nova accepts maxTokens, temperature, topP, stopSequences top-level.
      // The probe pins maxTokens=32; the other three carry profile defaults.
      expect(Object.keys(inferenceConfig!).sort()).toEqual(
        ["maxTokens", "stopSequences", "temperature", "topP"].sort(),
      );
      expect(inferenceConfig!.maxTokens).toBe(32);
      // `topK` MUST NOT appear top-level (R17.4).
      expect(inferenceConfig).not.toHaveProperty("topK");

      // `topK` MUST appear under additionalModelRequestFields.inferenceConfig
      // and equal the profile-default value the probe injects.
      const additional = input.additionalModelRequestFields as
        | { inferenceConfig?: Record<string, unknown> }
        | undefined;
      expect(additional).toBeDefined();
      expect(additional!.inferenceConfig).toBeDefined();
      expect(additional!.inferenceConfig!.topK).toBe(50);

      // `modelId` is the canonical cross-region inference profile id.
      expect(input.modelId).toBe(model.inferenceProfileId);
    },
  );
});

// ---------------------------------------------------------------------------
// Negative probe — Anthropic 4.x strict profile (Opus 4.8 only)
// ---------------------------------------------------------------------------

describe("buildNegativeProbe — anthropic_claude_4x (strict) profile", () => {
  it.each(ANTHROPIC_STRICT_MODEL_KEYS)(
    "[%s] injects exactly one forbidden key (temperature=0.5) and tags expectedNegativeKey",
    (modelKey) => {
      const model = SUPPORTED_MODELS[modelKey];
      const probe = buildNegativeProbe(model);

      expect(probe).not.toBeNull();
      expect(probe!.kind).toBe("negative");
      expect(probe!.modelKey).toBe(modelKey);
      expect(probe!.expectedNegativeKey).toBe("temperature");
      expect(probe!.command).toBeInstanceOf(ConverseCommand);

      const input = (probe!.command as ConverseCommand).input;
      const inferenceConfig = input.inferenceConfig as Record<string, unknown>;
      expect(inferenceConfig).toBeDefined();

      // The forbidden key was injected at its profile-default value.
      expect(inferenceConfig.temperature).toBe(0.5);

      // The accepted top-level key is also present (so the API rejection
      // is unambiguously about the forbidden field, not a missing field).
      expect(inferenceConfig.maxTokens).toBe(32);

      // Exactly ONE key from the profile's forbids[] is present in the
      // negative probe's inferenceConfig — the doc-lag sentinel relies on
      // a unique forbidden field per probe so the 4xx error message
      // points unambiguously at the regression.
      const forbidsSet = new Set(
        CAPABILITY_PROFILES.anthropic_claude_4x.forbids,
      );
      const forbiddenKeysPresent = Object.keys(inferenceConfig).filter(
        (k) => forbidsSet.has(k as never),
      );
      expect(forbiddenKeysPresent).toEqual(["temperature"]);

      // `modelId` still points at the model under test.
      expect(input.modelId).toBe(model.inferenceProfileId);
    },
  );
});

// ---------------------------------------------------------------------------
// Negative probe — Anthropic 4.x lax profile (Sonnet 4.6 / Haiku 4.5)
// returns null because forbids[] is empty
// ---------------------------------------------------------------------------

describe("buildNegativeProbe — anthropic_claude_4x_lax profile", () => {
  it.each(ANTHROPIC_LAX_MODEL_KEYS)(
    "[%s] returns null because anthropic_claude_4x_lax profile.forbids[] is empty",
    (modelKey) => {
      const model = SUPPORTED_MODELS[modelKey];
      const probe = buildNegativeProbe(model);

      expect(probe).toBeNull();
      // Belt-and-braces: if Sonnet 4.6 or Haiku 4.5 ever start
      // wire-rejecting the legacy sampling keys, the lax profile will
      // need a non-empty forbids[] and this assertion turns red so we
      // re-pin the expectation deliberately.
      expect(CAPABILITY_PROFILES.anthropic_claude_4x_lax.forbids).toHaveLength(
        0,
      );
    },
  );
});

// ---------------------------------------------------------------------------
// Negative probe — Amazon Nova (no forbids → null)
// ---------------------------------------------------------------------------

describe("buildNegativeProbe — Amazon Nova profile", () => {
  it.each(NOVA_MODEL_KEYS)(
    "[%s] returns null because amazon_nova profile.forbids[] is empty",
    (modelKey) => {
      const model = SUPPORTED_MODELS[modelKey];
      const probe = buildNegativeProbe(model);

      expect(probe).toBeNull();
      // Belt-and-braces sanity check on the catalog itself: if the profile
      // ever grows a non-empty forbids[], the negative probe will start
      // firing and this test SHOULD turn red so we re-pin the expectation.
      expect(CAPABILITY_PROFILES.amazon_nova.forbids).toHaveLength(0);
    },
  );
});

// ---------------------------------------------------------------------------
// RAG-job probe
// ---------------------------------------------------------------------------

describe("buildRagJobProbe", () => {
  // The probe reads three env vars at call time. We snapshot whatever the
  // host environment has set and restore it after the suite so we don't
  // leak state into the rest of the test run.
  const ORIGINAL_ROLE_ARN = process.env.BEDROCK_EVAL_ROLE_ARN;
  const ORIGINAL_BUCKET = process.env.RAG_PROBE_BUCKET;
  const ORIGINAL_INPUT_S3_URI = process.env.RAG_PROBE_INPUT_S3_URI;

  afterAll(() => {
    if (ORIGINAL_ROLE_ARN === undefined) {
      delete process.env.BEDROCK_EVAL_ROLE_ARN;
    } else {
      process.env.BEDROCK_EVAL_ROLE_ARN = ORIGINAL_ROLE_ARN;
    }
    if (ORIGINAL_BUCKET === undefined) {
      delete process.env.RAG_PROBE_BUCKET;
    } else {
      process.env.RAG_PROBE_BUCKET = ORIGINAL_BUCKET;
    }
    if (ORIGINAL_INPUT_S3_URI === undefined) {
      delete process.env.RAG_PROBE_INPUT_S3_URI;
    } else {
      process.env.RAG_PROBE_INPUT_S3_URI = ORIGINAL_INPUT_S3_URI;
    }
  });

  describe("with required env vars set", () => {
    beforeAll(() => {
      process.env.BEDROCK_EVAL_ROLE_ARN =
        "arn:aws:iam::123456789012:role/test-bedrock-eval-role";
      process.env.RAG_PROBE_BUCKET = "test-rag-probe-bucket";
      process.env.RAG_PROBE_INPUT_S3_URI =
        "s3://test-rag-probe-bucket/probe-input/probe-input.jsonl";
    });

    it("sets evaluatorModelConfig.bedrockEvaluatorModels[].modelIdentifier to the resolved evaluator model id", () => {
      const built = buildRagJobProbe();
      expect(built).not.toBeNull();
      expect(built!.probe.kind).toBe("ragJob");
      expect(built!.probe.modelKey).toBeNull();
      expect(built!.probe.command).toBeInstanceOf(CreateEvaluationJobCommand);
      expect(built!.jobName).toMatch(/^rag-probe-\d+$/);

      const input = (built!.probe.command as CreateEvaluationJobCommand).input;
      const automated = input.evaluationConfig?.automated as
        | {
            evaluatorModelConfig?: {
              bedrockEvaluatorModels?: Array<{ modelIdentifier?: string }>;
            };
          }
        | undefined;
      const evaluators =
        automated?.evaluatorModelConfig?.bedrockEvaluatorModels;
      expect(evaluators).toBeDefined();
      expect(evaluators).toHaveLength(1);
      expect(evaluators![0].modelIdentifier).toBe(
        SUPPORTED_MODELS.claude_sonnet_4_6.inferenceProfileId,
      );

      // Spot-check the surrounding shape: the role ARN, the dataset
      // location, and the output S3 URI all come from the env vars.
      expect(input.roleArn).toBe(
        "arn:aws:iam::123456789012:role/test-bedrock-eval-role",
      );
      expect(input.applicationType).toBe("RagEvaluation");
      expect(input.outputDataConfig?.s3Uri).toBe(
        "s3://test-rag-probe-bucket/probe-output/",
      );
    });
  });

  describe("with required env vars missing", () => {
    beforeAll(() => {
      delete process.env.BEDROCK_EVAL_ROLE_ARN;
      delete process.env.RAG_PROBE_BUCKET;
      delete process.env.RAG_PROBE_INPUT_S3_URI;
    });

    it("returns null so the runner can report the probe as skipped", () => {
      const built = buildRagJobProbe();
      expect(built).toBeNull();
    });
  });
});

// ---------------------------------------------------------------------------
// runProbe — dry-run mode
// ---------------------------------------------------------------------------

describe("runProbe (dry-run)", () => {
  it("returns synthetic success and never calls the runtime client", async () => {
    const model = SUPPORTED_MODELS.claude_sonnet_4_6;
    const probe = buildPositiveProbe(model);

    const runtime = makeMockRuntimeClient();
    const bedrock = makeMockBedrockClient();

    const outcome = await runProbe(probe, {
      dryRun: true,
      runtimeClient: runtime.client,
      bedrockClient: bedrock.client,
    });

    expect(outcome).toEqual({ ok: true, elapsedMs: 0, skipped: false });
    expect(runtime.send).not.toHaveBeenCalled();
    expect(bedrock.send).not.toHaveBeenCalled();
  });
});
