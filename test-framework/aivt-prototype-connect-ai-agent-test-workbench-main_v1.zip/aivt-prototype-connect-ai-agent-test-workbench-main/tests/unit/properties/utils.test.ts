import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { extractToolName } from "@shared/utils/tool-extraction";
import { isFillerResponse } from "@shared/utils/filler-detection";
import { calculateBackoffDelay } from "@shared/utils/backoff";
import { formatElapsedTime } from "@shared/utils/time-formatting";
import { calculateAccuracy } from "@shared/utils/accuracy";
import { generateSessionName } from "@shared/utils/session-name";

describe("Property Tests: Utility Functions", () => {
  // Feature: connect-agent-test-platform, Property 7: Tool extraction from conversationSessionData
  describe("Property 7: Tool extraction from conversationSessionData", () => {
    /**
     * Validates: Requirements 7.7
     */

    it("extracts the tool name when a Tool entry exists in the data array", () => {
      fc.assert(
        fc.property(
          fc.array(
            fc.record({
              key: fc.string({ minLength: 1, maxLength: 20 }).filter((k) => k !== "Tool"),
              value: fc.record({ stringValue: fc.string() }),
            }),
            { minLength: 0, maxLength: 10 }
          ),
          fc.string({ minLength: 1, maxLength: 50 }),
          fc.nat(10),
          (otherEntries, toolValue, insertIndex) => {
            const toolEntry = { key: "Tool", value: { stringValue: toolValue } };
            const data = [...otherEntries];
            const idx = Math.min(insertIndex, data.length);
            data.splice(idx, 0, toolEntry);

            expect(extractToolName(data)).toBe(toolValue);
          }
        ),
        { numRuns: 100 }
      );
    });

    it("returns null when no Tool entry exists in the data array", () => {
      fc.assert(
        fc.property(
          fc.array(
            fc.record({
              key: fc.string({ minLength: 1, maxLength: 20 }).filter((k) => k !== "Tool"),
              value: fc.record({ stringValue: fc.string() }),
            }),
            { minLength: 0, maxLength: 10 }
          ),
          (entries) => {
            expect(extractToolName(entries)).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });

    it("returns null for null or undefined input", () => {
      expect(extractToolName(null)).toBeNull();
      expect(extractToolName(undefined)).toBeNull();
    });
  });

  // Feature: connect-agent-test-platform, Property 5: Filler response detection
  describe("Property 5: Filler response detection", () => {
    /**
     * Validates: Requirements 7.4
     */

    const FILLER_TEXTS = ["...", "......", "\u2026"];

    it("returns true for known fillers when tokenAdvanced is false", () => {
      fc.assert(
        fc.property(
          fc.constantFrom(...FILLER_TEXTS),
          (fillerText) => {
            expect(isFillerResponse(fillerText, false)).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });

    it("returns false for known fillers when tokenAdvanced is true", () => {
      fc.assert(
        fc.property(
          fc.constantFrom(...FILLER_TEXTS),
          (fillerText) => {
            expect(isFillerResponse(fillerText, true)).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it("returns false for non-filler text regardless of tokenAdvanced", () => {
      fc.assert(
        fc.property(
          fc.string({ minLength: 1, maxLength: 200 }).filter(
            (s) => s !== "..." && s !== "......" && s !== "\u2026"
          ),
          fc.boolean(),
          (text, tokenAdvanced) => {
            expect(isFillerResponse(text, tokenAdvanced)).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it("returns false for null/undefined text regardless of tokenAdvanced", () => {
      fc.assert(
        fc.property(fc.boolean(), (tokenAdvanced) => {
          expect(isFillerResponse(null, tokenAdvanced)).toBe(false);
          expect(isFillerResponse(undefined, tokenAdvanced)).toBe(false);
        }),
        { numRuns: 100 }
      );
    });
  });

  // Feature: connect-agent-test-platform, Property 9: Exponential backoff with jitter bounds
  describe("Property 9: Exponential backoff with jitter bounds", () => {
    /**
     * Validates: Requirements 7.9
     */

    it("delay is within [0, min(2000 * 2^n, 30000)] for attempts 0–10", () => {
      fc.assert(
        fc.property(fc.integer({ min: 0, max: 10 }), (attempt) => {
          const delay = calculateBackoffDelay(attempt);
          const maxExpected = Math.min(2000 * Math.pow(2, attempt), 30000);
          expect(delay).toBeGreaterThanOrEqual(0);
          expect(delay).toBeLessThanOrEqual(maxExpected);
        }),
        { numRuns: 100 }
      );
    });

    it("delay never exceeds 30000ms cap for large attempt values", () => {
      fc.assert(
        fc.property(fc.integer({ min: 11, max: 100 }), (attempt) => {
          const delay = calculateBackoffDelay(attempt);
          expect(delay).toBeGreaterThanOrEqual(0);
          expect(delay).toBeLessThanOrEqual(30000);
        }),
        { numRuns: 100 }
      );
    });

    it("negative attempts are treated as attempt 0 (delay <= 2000)", () => {
      fc.assert(
        fc.property(fc.integer({ min: -100, max: -1 }), (attempt) => {
          const delay = calculateBackoffDelay(attempt);
          expect(delay).toBeGreaterThanOrEqual(0);
          expect(delay).toBeLessThanOrEqual(2000);
        }),
        { numRuns: 100 }
      );
    });
  });

  // Feature: connect-agent-test-platform, Property 14: Accuracy percentage calculation
  describe("Property 14: Accuracy percentage calculation", () => {
    /**
     * Validates: Requirements 10.1
     */

    it("computes accuracy as round((passed / total) * 100, 1 decimal)", () => {
      fc.assert(
        fc.property(
          fc.array(
            fc.record({
              status: fc.constantFrom("passed", "failed", "error"),
            }),
            { minLength: 1, maxLength: 50 }
          ),
          (results) => {
            const passedCount = results.filter((r) => r.status === "passed").length;
            const expected = Math.round((passedCount / results.length) * 100 * 10) / 10;
            expect(calculateAccuracy(results)).toBe(expected);
          }
        ),
        { numRuns: 100 }
      );
    });

    it("returns 0 for empty array", () => {
      expect(calculateAccuracy([])).toBe(0);
    });

    it("returns 100 when all results are passed", () => {
      fc.assert(
        fc.property(fc.integer({ min: 1, max: 50 }), (count) => {
          const results = Array.from({ length: count }, () => ({ status: "passed" }));
          expect(calculateAccuracy(results)).toBe(100);
        }),
        { numRuns: 100 }
      );
    });

    it("returns 0 when no results are passed", () => {
      fc.assert(
        fc.property(
          fc.array(
            fc.record({ status: fc.constantFrom("failed", "error") }),
            { minLength: 1, maxLength: 50 }
          ),
          (results) => {
            expect(calculateAccuracy(results)).toBe(0);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // Feature: connect-agent-test-platform, Property 12: Elapsed time MM:SS formatting
  describe("Property 12: Elapsed time MM:SS formatting", () => {
    /**
     * Validates: Requirements 11.1
     */

    it("output matches /^\\d{2,}:\\d{2}$/ for any non-negative integer seconds", () => {
      fc.assert(
        fc.property(fc.integer({ min: 0, max: 100000 }), (seconds) => {
          const result = formatElapsedTime(seconds);
          expect(result).toMatch(/^\d{2,}:\d{2}$/);
        }),
        { numRuns: 100 }
      );
    });

    it("seconds part is always 00–59", () => {
      fc.assert(
        fc.property(fc.integer({ min: 0, max: 100000 }), (seconds) => {
          const result = formatElapsedTime(seconds);
          const ssPart = parseInt(result.split(":")[1], 10);
          expect(ssPart).toBeGreaterThanOrEqual(0);
          expect(ssPart).toBeLessThanOrEqual(59);
        }),
        { numRuns: 100 }
      );
    });

    it("parsing back: minutes*60 + seconds === original input", () => {
      fc.assert(
        fc.property(fc.integer({ min: 0, max: 100000 }), (seconds) => {
          const result = formatElapsedTime(seconds);
          const [mmStr, ssStr] = result.split(":");
          const reconstructed = parseInt(mmStr, 10) * 60 + parseInt(ssStr, 10);
          expect(reconstructed).toBe(seconds);
        }),
        { numRuns: 100 }
      );
    });

    it("negative values produce 00:00", () => {
      fc.assert(
        fc.property(fc.integer({ min: -100000, max: -1 }), (seconds) => {
          expect(formatElapsedTime(seconds)).toBe("00:00");
        }),
        { numRuns: 100 }
      );
    });

    it("fractional values are floored before formatting", () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 0, max: 100000 }),
          fc.double({ min: 0, max: 0.999, noNaN: true }),
          (intPart, fracPart) => {
            const input = intPart + fracPart;
            const result = formatElapsedTime(input);
            const expected = formatElapsedTime(intPart);
            expect(result).toBe(expected);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // Feature: connect-agent-test-platform, Property 17: Session name format
  describe("Property 17: Session name format", () => {
    /**
     * Validates: Requirements 7.2
     */

    it("every generated name matches /^test-[0-9a-f]{8}$/", () => {
      fc.assert(
        fc.property(fc.constant(null), () => {
          const name = generateSessionName();
          expect(name).toMatch(/^test-[0-9a-f]{8}$/);
        }),
        { numRuns: 100 }
      );
    });

    it("every generated name has exactly 13 characters", () => {
      fc.assert(
        fc.property(fc.constant(null), () => {
          const name = generateSessionName();
          expect(name).toHaveLength(13);
        }),
        { numRuns: 100 }
      );
    });
  });
});
