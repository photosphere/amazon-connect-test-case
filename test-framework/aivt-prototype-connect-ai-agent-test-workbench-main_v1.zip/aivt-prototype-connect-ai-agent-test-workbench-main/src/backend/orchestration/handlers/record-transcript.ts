/**
 * RecordTranscript Lambda handler — persists conversation transcript AND the
 * structured execution trace (turn-by-turn reasoning + tool calls from ListSpans)
 * to DynamoDB.
 *
 * Called after ConversationDriver completes for each test case in the Map state.
 * - Transcript turns: stored as separate items (SK=TURN#{n}) for efficient reads.
 * - Execution trace: stored as a single item (SK=TRACE) for debugging failed
 *   tests and feeding the failure-analysis recommendation engine.
 *
 * @module record-transcript
 */

import { DynamoDBService } from "../../services/dynamodb";
import type { TranscriptTurn, ExecutionTrace } from "../../../shared/types";

export interface RecordTranscriptInput {
  runId: string;
  caseId: string;
  status: string;
  toolsInvoked: string[];
  turnCount: number;
  latencyMs: number;
  transcript?: TranscriptTurn[];
  executionTrace?: ExecutionTrace;
  sessionId?: string;
  errorMessage?: string;
  /** Pass-through: agent's terminal response for RAG cases (persisted by WriteCaseResult). */
  agentResponse?: string;
  /** Pass-through: retrieved chunks for RAG cases (persisted by WriteCaseResult). */
  retrievedChunks?: unknown[];
  /** Pass-through: case type discriminator (persisted by WriteCaseResult). */
  caseType?: string;
  /** Pass-through: goal success score from evaluation. */
  goalSuccessScore?: number;
  /** Pass-through: helpfulness score from evaluation. */
  helpfulnessScore?: number;
  /** Pass-through: tool accuracy score from evaluation. */
  toolAccuracyScore?: number;
}

export interface RecordTranscriptOutput {
  runId: string;
  caseId: string;
  status: string;
  toolsInvoked: string[];
  turnCount: number;
  latencyMs: number;
  transcriptRecorded: boolean;
  traceRecorded: boolean;
  /** Pass-through: agent's terminal response for RAG cases. */
  agentResponse?: string;
  /** Pass-through: retrieved chunks for RAG cases. */
  retrievedChunks?: unknown[];
  /** Pass-through: case type discriminator. */
  caseType?: string;
  /** Pass-through: goal success score from evaluation. */
  goalSuccessScore?: number;
  /** Pass-through: helpfulness score from evaluation. */
  helpfulnessScore?: number;
  /** Pass-through: tool accuracy score from evaluation. */
  toolAccuracyScore?: number;
}

let dynamoService: DynamoDBService | null = null;

function getDynamoService(): DynamoDBService {
  if (!dynamoService) {
    dynamoService = new DynamoDBService();
  }
  return dynamoService;
}

/** @internal — allows test injection */
export function _setDynamoService(service: DynamoDBService | null): void {
  dynamoService = service;
}

export async function handler(event: RecordTranscriptInput): Promise<RecordTranscriptOutput> {
  const db = getDynamoService();
  const { runId, caseId, transcript, executionTrace } = event;

  if (transcript && transcript.length > 0) {
    await db.writeTranscript(runId, caseId, transcript);
  }

  let traceRecorded = false;
  if (executionTrace && executionTrace.steps.length > 0) {
    await db.writeExecutionTrace(runId, caseId, executionTrace);
    traceRecorded = true;
  }

  return {
    runId: event.runId,
    caseId: event.caseId,
    status: event.status,
    toolsInvoked: event.toolsInvoked,
    turnCount: event.turnCount,
    latencyMs: event.latencyMs,
    transcriptRecorded: (transcript?.length ?? 0) > 0,
    traceRecorded,
    // Pass through fields needed by WriteCaseResult for DDB persistence
    ...(event.agentResponse !== undefined && { agentResponse: event.agentResponse }),
    ...(event.retrievedChunks !== undefined && { retrievedChunks: event.retrievedChunks }),
    ...(event.caseType !== undefined && { caseType: event.caseType }),
    ...(event.goalSuccessScore !== undefined && { goalSuccessScore: event.goalSuccessScore }),
    ...(event.helpfulnessScore !== undefined && { helpfulnessScore: event.helpfulnessScore }),
    ...(event.toolAccuracyScore !== undefined && { toolAccuracyScore: event.toolAccuracyScore }),
  };
}
