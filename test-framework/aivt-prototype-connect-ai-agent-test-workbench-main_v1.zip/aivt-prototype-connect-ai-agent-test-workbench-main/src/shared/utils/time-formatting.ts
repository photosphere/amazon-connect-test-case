/**
 * Time formatting utility for elapsed time display.
 *
 * Converts a number of seconds into a zero-padded MM:SS string for
 * the run progress display. Minutes are not capped at 59 — a 2-hour
 * run will show "120:00".
 *
 * @module time-formatting
 */

/**
 * Formats elapsed seconds as a MM:SS string.
 *
 * @param seconds - The number of elapsed seconds. Negative values are treated as 0.
 *                  Non-integer values are floored.
 * @returns A string in MM:SS format, zero-padded (e.g., "01:05", "60:00")
 *
 * @example
 * formatElapsedTime(0)    // "00:00"
 * formatElapsedTime(65)   // "01:05"
 * formatElapsedTime(3600) // "60:00"
 */
export function formatElapsedTime(seconds: number): string {
  const totalSeconds = Math.max(0, Math.floor(seconds));
  const minutes = Math.floor(totalSeconds / 60);
  const remainingSeconds = totalSeconds % 60;

  const mm = String(minutes).padStart(2, "0");
  const ss = String(remainingSeconds).padStart(2, "0");

  return `${mm}:${ss}`;
}

/**
 * Format a millisecond duration for human reading. Used for case-level
 * "Duration" columns and labels (the time a test case took to run end-
 * to-end), where raw `34281ms` is harder to scan than `34.3s` or
 * `5m 12s`.
 *
 * Resolution choices follow the natural reading granularity at each
 * scale:
 *
 *   - `<1s`        → exact `123ms` so sub-second tool calls keep
 *                    millisecond precision without forcing the eye to
 *                    parse trailing zeros.
 *   - `<60s`       → one decimal `12.3s` — small enough to compare
 *                    cases at a glance, precise enough to spot
 *                    regressions.
 *   - `≥60s`       → `Xm Ys` — minutes and whole seconds; sub-second
 *                    precision is irrelevant once a case has stretched
 *                    into multiple minutes.
 *
 * Negative or non-finite inputs collapse to `0ms` rather than throwing,
 * so a partially-populated record never crashes the renderer.
 *
 * @example
 *   formatDurationMs(0)        // "0ms"
 *   formatDurationMs(450)      // "450ms"
 *   formatDurationMs(2_500)    // "2.5s"
 *   formatDurationMs(34_281)   // "34.3s"
 *   formatDurationMs(120_000)  // "2m 0s"
 *   formatDurationMs(312_500)  // "5m 13s"
 */
export function formatDurationMs(ms: number): string {
  if (!Number.isFinite(ms) || ms <= 0) return "0ms";
  if (ms < 1_000) return `${Math.round(ms)}ms`;
  if (ms < 60_000) return `${(ms / 1_000).toFixed(1)}s`;
  const totalSeconds = Math.floor(ms / 1_000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}m ${seconds}s`;
}
