/**
 * `tournament_summary` — system prompt for the Bedrock Converse call
 * inside `src/backend/orchestration/tournament-summary.ts` that explains
 * the deterministic baseline-vs-variant tournament outcome in plain
 * language. The user message (variant scores, highlights, winner line) is
 * built locally by `buildUserMessage`; the registered prompt is the
 * literal `SYSTEM_PROMPT` constant lifted byte-for-byte from
 * `tournament-summary.ts`.
 *
 * @module backend/orchestration/prompt-registry/prompts/tournament-summary
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

/**
 * Byte-for-byte equivalent of the `SYSTEM_PROMPT` template literal in
 * `tournament-summary.ts`. The legacy literal contains three paragraphs
 * separated by blank lines.
 */
const DEFAULT_TEXT = `You are an expert test results analyst. You produce concise, clear natural-language summaries comparing baseline test results against experimental variant results for an Amazon Q in Connect agent.

Your job is to EXPLAIN the quantitative results — you do NOT determine the winner. The winning variant has already been computed deterministically. You describe WHY it won and what specifically improved or regressed.

Keep the summary to 2-4 sentences. Be specific about which test cases changed and by how much. Use a professional, direct tone.`;

export const tournamentSummaryPrompt: PromptDefinition = {
  promptKey: "tournament_summary",
  name: "Tournament Summary — Variant Outcome Explainer",
  description:
    "System prompt for the Converse call that produces a 2-4 sentence natural-language explanation of the deterministic tournament outcome (baseline vs three variants).",
  category: "experiment",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 4_096 },
  },
  defaultInferenceValues: {
    maxTokens: 4_096,
  },
};
