// @vitest-environment jsdom
/**
 * Unit tests for the ImplementButton and ModeSelector components.
 *
 * Validates:
 *  - Requirement 1.1, 1.2: Button renders when recommendations exist
 *  - Requirement 1.3: Clicking opens ModeSelector with two options
 *  - Requirement 1.4: Button hidden when no recommendations
 *  - Requirement 1.5: Button not rendered when run still running
 *  - Requirement 19.2: Button hidden in production mode
 */

import React from 'react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

import { ImplementButton } from '../../../src/frontend/src/components/ImplementRecommendations/ImplementButton';
import { ModeSelector } from '../../../src/frontend/src/components/ImplementRecommendations/ModeSelector';
import { RunStatus } from '../../../src/shared/enums';

afterEach(() => {
  cleanup();
});

// ---------------------------------------------------------------------------
// ImplementButton tests
// ---------------------------------------------------------------------------

describe('ImplementButton', () => {
  const defaultProps = {
    runId: 'run-123',
    suiteId: 'suite-456',
    agentId: 'agent-789',
    hasRecommendations: true,
    runStatus: RunStatus.COMPLETED,
    instanceMode: 'development' as const,
  };

  it('renders the button when conditions are met (development mode, has recommendations, run completed)', () => {
    render(<ImplementButton {...defaultProps} />);
    expect(screen.getByRole('button', { name: /implement recommendations/i })).toBeInTheDocument();
  });

  it('renders nothing when instanceMode is production (R19.2)', () => {
    const { container } = render(
      <ImplementButton {...defaultProps} instanceMode="production" />
    );
    expect(container).toBeEmptyDOMElement();
  });

  it('renders nothing when hasRecommendations is false (R1.4)', () => {
    const { container } = render(
      <ImplementButton {...defaultProps} hasRecommendations={false} />
    );
    expect(container).toBeEmptyDOMElement();
  });

  it('renders nothing when runStatus is RUNNING (R1.5)', () => {
    const { container } = render(
      <ImplementButton {...defaultProps} runStatus={RunStatus.RUNNING} />
    );
    expect(container).toBeEmptyDOMElement();
  });

  it('renders the button when runStatus is FAILED (recommendations may still exist)', () => {
    render(<ImplementButton {...defaultProps} runStatus={RunStatus.FAILED} />);
    expect(screen.getByRole('button', { name: /implement recommendations/i })).toBeInTheDocument();
  });

  it('opens ModeSelector dialog when clicked (R1.3)', () => {
    render(<ImplementButton {...defaultProps} />);
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));
    // The modal dialog should now be visible with both mode options
    expect(screen.getByRole('dialog')).toBeInTheDocument();
    expect(screen.getByText('Apply directly')).toBeInTheDocument();
    expect(screen.getByText('Advanced: Multi-variant experiment')).toBeInTheDocument();
  });

  it('calls onDirectApply when "Apply directly" is selected and confirmed', () => {
    const onDirectApply = vi.fn();
    render(<ImplementButton {...defaultProps} onDirectApply={onDirectApply} />);

    // Open the mode selector
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));

    // "Apply directly" is selected by default — click Continue
    fireEvent.click(screen.getByRole('button', { name: /continue/i }));

    expect(onDirectApply).toHaveBeenCalledTimes(1);
  });

  it('calls onExperiment when "Advanced: Multi-variant experiment" is selected and confirmed', () => {
    const onExperiment = vi.fn();
    render(<ImplementButton {...defaultProps} onExperiment={onExperiment} />);

    // Open the mode selector
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));

    // Select the experiment option
    const experimentRadio = screen.getByLabelText(/advanced: multi-variant experiment/i);
    fireEvent.click(experimentRadio);

    // Click Continue
    fireEvent.click(screen.getByRole('button', { name: /continue/i }));

    expect(onExperiment).toHaveBeenCalledTimes(1);
  });
});

// ---------------------------------------------------------------------------
// ModeSelector tests
// ---------------------------------------------------------------------------

describe('ModeSelector', () => {
  const defaultProps = {
    visible: true,
    onDismiss: vi.fn(),
    onDirectApply: vi.fn(),
    onExperiment: vi.fn(),
  };

  it('renders the two mode options when visible', () => {
    render(<ModeSelector {...defaultProps} />);
    expect(screen.getByText('Apply directly')).toBeInTheDocument();
    expect(screen.getByText('Advanced: Multi-variant experiment')).toBeInTheDocument();
  });

  it('renders dialog as hidden when visible is false', () => {
    render(<ModeSelector {...defaultProps} visible={false} />);
    // Cloudscape Modal renders DOM content even when not visible but adds a
    // hidden class. Verify the dialog element has the hidden class applied.
    const dialog = screen.queryByRole('dialog');
    if (dialog) {
      expect(dialog.className).toContain('hidden');
    }
    // Either way, the dialog should not be accessible to the user
  });

  it('calls onDismiss when Cancel is clicked', () => {
    const onDismiss = vi.fn();
    render(<ModeSelector {...defaultProps} onDismiss={onDismiss} />);
    fireEvent.click(screen.getByRole('button', { name: /cancel/i }));
    expect(onDismiss).toHaveBeenCalledTimes(1);
  });

  it('calls onDirectApply when "Apply directly" is selected and Continue is clicked', () => {
    const onDirectApply = vi.fn();
    render(<ModeSelector {...defaultProps} onDirectApply={onDirectApply} />);

    // "Apply directly" is the default selection
    fireEvent.click(screen.getByRole('button', { name: /continue/i }));
    expect(onDirectApply).toHaveBeenCalledTimes(1);
  });

  it('calls onExperiment when experiment mode is selected and Continue is clicked', () => {
    const onExperiment = vi.fn();
    render(<ModeSelector {...defaultProps} onExperiment={onExperiment} />);

    // Select experiment option
    const experimentRadio = screen.getByLabelText(/advanced: multi-variant experiment/i);
    fireEvent.click(experimentRadio);

    fireEvent.click(screen.getByRole('button', { name: /continue/i }));
    expect(onExperiment).toHaveBeenCalledTimes(1);
  });

  it('renders descriptions for both options', () => {
    render(<ModeSelector {...defaultProps} />);
    expect(
      screen.getByText(/write the recommended changes to your agent configuration immediately/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(/generate 3 diverse prompt variants/i)
    ).toBeInTheDocument();
  });
});
