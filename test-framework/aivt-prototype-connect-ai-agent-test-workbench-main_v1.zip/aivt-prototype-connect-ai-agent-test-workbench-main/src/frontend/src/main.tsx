import React from 'react';
import ReactDOM from 'react-dom/client';
import '@cloudscape-design/global-styles/index.css';
import { App } from './App';
import { loadConfig } from './api';
import { RuntimeConfigError } from './RuntimeConfigError';

/**
 * Bootstrap the application.
 *
 * Loads runtime config (from `/config.json` injected at deploy time) before
 * rendering. On a network failure, non-OK response, or malformed document,
 * the user is kept on the page and a "runtime configuration unavailable"
 * error state is rendered (Requirement 5.4). API calls are suppressed by
 * the API client itself when the configuration is not ready.
 */
loadConfig().then((status) => {
  const root = ReactDOM.createRoot(document.getElementById('root')!);
  if (status.status === 'ready') {
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
  } else if (status.status === 'error') {
    root.render(
      <React.StrictMode>
        <RuntimeConfigError error={status.error} />
      </React.StrictMode>
    );
  }
});
