import { describe, it, expect } from "vitest";
import { extractToolName } from "@shared/utils/tool-extraction";
import { isFillerResponse } from "@shared/utils/filler-detection";
import { calculateBackoffDelay } from "@shared/utils/backoff";
import { formatElapsedTime } from "@shared/utils/time-formatting";
import { calculateAccuracy } from "@shared/utils/accuracy";
import { generateSessionName } from "@shared/utils/session-name";

describe("extractToolName", () => {
  it("returns tool name when Tool entry exists", () => {
    const data = [
      { key: "SessionId", value: { stringValue: "abc" } },
      { key: "Tool", value: { stringValue: "TransferFunds" } },
    ];
    expect(extractToolName(data)).toBe("TransferFunds");
  });

  it("returns null when no Tool entry exists", () => {
    const data = [
      { key: "SessionId", value: { stringValue: "abc" } },
      { key: "Status", value: { stringValue: "active" } },
    ];
    expect(extractToolName(data)).toBeNull();
  });

  it("returns null for null input", () => {
    expect(extractToolName(null)).toBeNull();
  });

  it("returns null for undefined input", () => {
    expect(extractToolName(undefined)).toBeNull();
  });

  it("returns null for empty array", () => {
    expect(extractToolName([])).toBeNull();
  });

  it("returns null when Tool entry has no stringValue", () => {
    const data = [{ key: "Tool", value: {} }];
    expect(extractToolName(data)).toBeNull();
  });
});

describe("isFillerResponse", () => {
  it('returns true for "..." when token has not advanced', () => {
    expect(isFillerResponse("...", false)).toBe(true);
  });

  it('returns true for "......" when token has not advanced', () => {
    expect(isFillerResponse("......", false)).toBe(true);
  });

  it('returns true for "…" (ellipsis char) when token has not advanced', () => {
    expect(isFillerResponse("\u2026", false)).toBe(true);
  });

  it('returns false for "..." when token HAS advanced', () => {
    expect(isFillerResponse("...", true)).toBe(false);
  });

  it("returns false for regular text", () => {
    expect(isFillerResponse("Hello, how can I help?", false)).toBe(false);
  });

  it("returns false for null text", () => {
    expect(isFillerResponse(null, false)).toBe(false);
  });

  it("returns false for undefined text", () => {
    expect(isFillerResponse(undefined, false)).toBe(false);
  });

  it("returns false for empty string", () => {
    expect(isFillerResponse("", false)).toBe(false);
  });
});

describe("calculateBackoffDelay", () => {
  it("returns a value in [0, 2000] for attempt 0", () => {
    for (let i = 0; i < 50; i++) {
      const delay = calculateBackoffDelay(0);
      expect(delay).toBeGreaterThanOrEqual(0);
      expect(delay).toBeLessThanOrEqual(2000);
    }
  });

  it("returns a value in [0, 4000] for attempt 1", () => {
    for (let i = 0; i < 50; i++) {
      const delay = calculateBackoffDelay(1);
      expect(delay).toBeGreaterThanOrEqual(0);
      expect(delay).toBeLessThanOrEqual(4000);
    }
  });

  it("returns a value in [0, 8000] for attempt 2", () => {
    for (let i = 0; i < 50; i++) {
      const delay = calculateBackoffDelay(2);
      expect(delay).toBeGreaterThanOrEqual(0);
      expect(delay).toBeLessThanOrEqual(8000);
    }
  });

  it("caps at 30000ms for large attempt values", () => {
    for (let i = 0; i < 50; i++) {
      const delay = calculateBackoffDelay(10);
      expect(delay).toBeGreaterThanOrEqual(0);
      expect(delay).toBeLessThanOrEqual(30000);
    }
  });

  it("treats negative attempts as 0", () => {
    for (let i = 0; i < 50; i++) {
      const delay = calculateBackoffDelay(-5);
      expect(delay).toBeGreaterThanOrEqual(0);
      expect(delay).toBeLessThanOrEqual(2000);
    }
  });
});

describe("formatElapsedTime", () => {
  it('formats 0 seconds as "00:00"', () => {
    expect(formatElapsedTime(0)).toBe("00:00");
  });

  it('formats 65 seconds as "01:05"', () => {
    expect(formatElapsedTime(65)).toBe("01:05");
  });

  it('formats 3600 seconds as "60:00"', () => {
    expect(formatElapsedTime(3600)).toBe("60:00");
  });

  it('formats 59 seconds as "00:59"', () => {
    expect(formatElapsedTime(59)).toBe("00:59");
  });

  it("treats negative seconds as 0", () => {
    expect(formatElapsedTime(-10)).toBe("00:00");
  });

  it("floors fractional seconds", () => {
    expect(formatElapsedTime(65.9)).toBe("01:05");
  });
});

describe("calculateAccuracy", () => {
  it("returns 0 for empty results", () => {
    expect(calculateAccuracy([])).toBe(0);
  });

  it("returns 100.0 when all pass", () => {
    const results = [
      { status: "passed" },
      { status: "passed" },
      { status: "passed" },
    ];
    expect(calculateAccuracy(results)).toBe(100);
  });

  it("returns 0 when none pass", () => {
    const results = [
      { status: "failed" },
      { status: "error" },
    ];
    expect(calculateAccuracy(results)).toBe(0);
  });

  it("returns 66.7 for 2 passed out of 3", () => {
    const results = [
      { status: "passed" },
      { status: "failed" },
      { status: "passed" },
    ];
    expect(calculateAccuracy(results)).toBe(66.7);
  });

  it("returns 33.3 for 1 passed out of 3", () => {
    const results = [
      { status: "passed" },
      { status: "failed" },
      { status: "error" },
    ];
    expect(calculateAccuracy(results)).toBe(33.3);
  });
});

describe("generateSessionName", () => {
  it("matches the format test-{8 hex chars}", () => {
    const name = generateSessionName();
    expect(name).toMatch(/^test-[0-9a-f]{8}$/);
  });

  it("generates unique names on successive calls", () => {
    const names = new Set<string>();
    for (let i = 0; i < 100; i++) {
      names.add(generateSessionName());
    }
    // With 4 bytes of randomness, collisions in 100 calls are extremely unlikely
    expect(names.size).toBe(100);
  });

  it("always produces exactly 13 characters", () => {
    for (let i = 0; i < 20; i++) {
      expect(generateSessionName()).toHaveLength(13);
    }
  });
});
