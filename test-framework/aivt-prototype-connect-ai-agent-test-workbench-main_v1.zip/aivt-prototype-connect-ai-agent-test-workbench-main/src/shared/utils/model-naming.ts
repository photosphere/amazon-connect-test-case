/**
 * Friendly-name lookup for Bedrock / Anthropic model identifiers.
 *
 * The platform persists raw `modelId` strings (e.g. `us.anthropic.claude-sonnet-4-6`)
 * because that's what the Q in Connect / Bedrock APIs round-trip. The GUI
 * shows them in a few places — Agent Browser table, agent detail panel,
 * snapshot comparison panes — and a raw inference profile id is hard to
 * read at a glance. This module maps known ids to a vendor-friendly
 * display name like "Claude Sonnet 4.6 (US, Anthropic)" and falls back to
 * the raw id when the model isn't in the table so unknown models still
 * surface their identifier rather than render blank.
 *
 * The table is intentionally small — adding a new entry is a one-line
 * change and unrecognized ids degrade gracefully. We also expose
 * {@link extractFriendlyModelName} as a pure helper so the same logic
 * runs in CDK tests, GUI components, and the failure-analysis prompt
 * builder without duplication.
 *
 * @module model-naming
 */

/**
 * Curated id → friendly-name map. Entries are matched by EXACT id first,
 * then by `endsWith` of the bare model component (so cross-region
 * inference profile prefixes like `us.` / `eu.` / `apac.` still resolve
 * to the same friendly name).
 *
 * Keep this list ordered roughly newest-first within each vendor so a
 * grep/diff is easy to read on review.
 */
const MODEL_FRIENDLY_NAMES: ReadonlyArray<readonly [string, string]> = [
  // Claude — Anthropic on Bedrock
  ["anthropic.claude-sonnet-4-6", "Claude Sonnet 4.6"],
  ["anthropic.claude-sonnet-4-5", "Claude Sonnet 4.5"],
  ["anthropic.claude-sonnet-4", "Claude Sonnet 4"],
  ["anthropic.claude-opus-4-1", "Claude Opus 4.1"],
  ["anthropic.claude-opus-4", "Claude Opus 4"],
  ["anthropic.claude-3-7-sonnet-20250219-v1:0", "Claude 3.7 Sonnet"],
  ["anthropic.claude-3-5-sonnet-20241022-v2:0", "Claude 3.5 Sonnet v2"],
  ["anthropic.claude-3-5-sonnet-20240620-v1:0", "Claude 3.5 Sonnet"],
  ["anthropic.claude-3-5-haiku-20241022-v1:0", "Claude 3.5 Haiku"],
  ["anthropic.claude-3-opus-20240229-v1:0", "Claude 3 Opus"],
  ["anthropic.claude-3-sonnet-20240229-v1:0", "Claude 3 Sonnet"],
  ["anthropic.claude-3-haiku-20240307-v1:0", "Claude 3 Haiku"],
];

/**
 * Strips a cross-region inference profile prefix (`us.`, `eu.`, `apac.`,
 * `apne1.`, etc.) from the start of a model id so the friendly-name
 * lookup matches the underlying base model. Returns the input
 * unchanged when no prefix is recognised.
 *
 * Cross-region inference profile ids look like:
 *   `us.anthropic.claude-sonnet-4-6`
 *   `eu.anthropic.claude-sonnet-4`
 *   `apac.anthropic.claude-3-5-sonnet-20241022-v2:0`
 *
 * The prefix is metadata about routing, not the model identity, so we
 * keep it for context but treat the bare `anthropic...` portion as the
 * key for friendly-name matching.
 */
function stripRegionPrefix(modelId: string): { region?: string; baseId: string } {
  const m = modelId.match(/^([a-z]+(?:-[a-z0-9]+)?)\.(anthropic\..+)$/i);
  if (m) {
    return { region: m[1].toLowerCase(), baseId: m[2] };
  }
  return { baseId: modelId };
}

/**
 * Returns a friendly display name for a Bedrock / Anthropic model id, or
 * the raw id when the model is unknown. The raw id is preserved as a
 * trailing parenthetical so the caller can render a single human-readable
 * label like `"Claude Sonnet 4.6 (us)"` and an unknown id just renders
 * `"us.foo.bar"` rather than blank.
 *
 * Examples:
 *   `extractFriendlyModelName("us.anthropic.claude-sonnet-4-6")`
 *     → `"Claude Sonnet 4.6 (us)"`
 *   `extractFriendlyModelName("anthropic.claude-3-5-sonnet-20241022-v2:0")`
 *     → `"Claude 3.5 Sonnet v2"`
 *   `extractFriendlyModelName("foo")`
 *     → `"foo"` (unchanged)
 *
 * @param modelId The raw modelId persisted by the platform.
 * @returns A user-friendly display label.
 */
export function extractFriendlyModelName(modelId: string | undefined | null): string {
  if (modelId == null || modelId.trim().length === 0) return "";
  const trimmed = modelId.trim();
  const { region, baseId } = stripRegionPrefix(trimmed);

  // Exact match first.
  for (const [id, friendly] of MODEL_FRIENDLY_NAMES) {
    if (id === baseId) {
      return region ? `${friendly} (${region})` : friendly;
    }
  }

  // Fallback: prefix match for forward-compat with ids that gain a
  // version suffix (e.g. `:1`, `-v2:0`) we haven't enumerated yet.
  for (const [id, friendly] of MODEL_FRIENDLY_NAMES) {
    if (baseId.startsWith(`${id}-`) || baseId.startsWith(`${id}:`)) {
      return region ? `${friendly} (${region})` : friendly;
    }
  }

  // Unknown model — surface the raw id so the user can still grep
  // CloudWatch / docs for it.
  return trimmed;
}
