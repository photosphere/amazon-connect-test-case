/**
 * Unit tests for Run Trigger Lambda handler.
 *
 * Tests the POST /runs and POST /runs/{runId}/abort endpoints,
 * including agent snapshot, Step Functions integration, and error handling.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { QConnectClient } from "@aws-sdk/client-qconnect";
import { SFNClient } from "@aws-sdk/client-sfn";
import {
  handler,
  _setQConnectClient,
  _setSFNClient,
  _setDBService,
} from "../../src/backend/handlers/runs";
import { DynamoDBService } from "../../src/backend/services/dynamodb";
import { RunStatus } from "../../src/shared/enums";
import type { TestRun, TestSuite, TestCase } from "../../src/shared/types";
import { CommunicationStyle } from "../../src/shared/enums";

// ---------------------------------------------------------------------------
// Mock setup
// ---------------------------------------------------------------------------

function createMockQConnectClient(
  sendFn: (command: unknown) => Promise<unknown>
) {
  return { send: sendFn } as unknown as QConnectClient;
}

function createMockSFNClient(
  sendFn: (command: unknown) => Promise<unknown>
) {
  return { send: sendFn } as unknown as SFNClient;
}

function createMockDBService(overrides: Partial<DynamoDBService> = {}): DynamoDBService {
  return {
    getSuite: vi.fn().mockResolvedValue(null),
    listCases: vi.fn().mockResolvedValue([]),
    listSuites: vi.fn().mockResolvedValue([]),
    listRuns: vi.fn().mockResolvedValue([]),
    createRun: vi.fn().mockResolvedValue(undefined),
    updateRun: vi.fn().mockResolvedValue(undefined),
    writeSnapshot: vi.fn().mockResolvedValue(undefined),
    ...overrides,
  } as unknown as DynamoDBService;
}

// Save and restore env
const originalEnv = { ...process.env };

beforeEach(() => {
  process.env.TABLE_NAME = "TestTable";
  process.env.ASSISTANT_ID = "test-assistant-id";
  process.env.AWS_REGION = "us-east-1";
  process.env.STATE_MACHINE_ARN =
    "arn:aws:states:us-east-1:123456789012:stateMachine:TestRunner";
});

afterEach(() => {
  _setQConnectClient(null);
  _setSFNClient(null);
  _setDBService(null);
  process.env = { ...originalEnv };
});

// ---------------------------------------------------------------------------
// Helper data
// ---------------------------------------------------------------------------

const TENANT_ID = "tenant-abc-123";

function makeEvent(overrides: Record<string, unknown> = {}) {
  return {
    httpMethod: "POST",
    resource: "/runs",
    body: null,
    pathParameters: null,
    requestContext: {
      authorizer: {
        claims: { sub: TENANT_ID },
      },
    },
    ...overrides,
  };
}

function makeSuite(): TestSuite {
  return {
    tenantId: TENANT_ID,
    suiteId: "suite-001",
    name: "Booking Test Suite",
    agentId: "agent-booking-1",
    assistantId: "test-assistant-id",
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  };
}

function makeTestCase(id: string): TestCase {
  return {
    type: "tool_sequence",
    suiteId: "suite-001",
    caseId: id,
    name: `Test Case ${id}`,
    description: "A test case",
    persona: "Customer wants to book a flight",
    style: CommunicationStyle.DIRECT,
    customerKnowledge: { destination: "Seattle" },
    initialUtterance: "I want to book a flight to Seattle",
    successCriteria: [
      { toolName: "SearchFlights", required: true },
      { toolName: "BookFlight", required: true },
    ],
  };
}

function makeAgentResponse() {
  return {
    aiAgent: {
      aiAgentId: "agent-booking-1",
      name: "Booking Agent",
      type: "ORCHESTRATION",
      configuration: {
        orchestrationAIAgentConfiguration: {
          orchestrationAIPromptId: "prompt-model-123",
          toolConfigurations: [
            {
              toolName: "SearchFlights",
              toolType: "LAMBDA",
              description: "Search available flights",
              instruction: { instruction: "Use for flight searches" },
              inputSchema: {
                type: "object",
                properties: { origin: { type: "string" } },
              },
            },
            {
              toolName: "BookFlight",
              toolType: "LAMBDA",
              description: "Book a flight",
              inputSchema: {
                type: "object",
                properties: { flightId: { type: "string" } },
              },
            },
          ],
        },
      },
    },
  };
}

function makeRunRecord(overrides: Partial<TestRun> = {}): TestRun {
  return {
    suiteId: "suite-001",
    runId: "run-001",
    status: RunStatus.RUNNING,
    totalCases: 2,
    passed: 0,
    failed: 0,
    errors: 0,
    concurrency: 9,
    startTime: "2024-01-01T12:00:00.000Z",
    sfnExecutionArn:
      "arn:aws:states:us-east-1:123456789012:execution:TestRunner:run-001",
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Tests: POST /runs
// ---------------------------------------------------------------------------

describe("Run Trigger Lambda - POST /runs", () => {
  it("creates a run, snapshots agent, starts Step Functions, returns runId", async () => {
    const suite = makeSuite();
    const testCases = [makeTestCase("case-1"), makeTestCase("case-2")];

    const mockDB = createMockDBService({
      getSuite: vi.fn().mockResolvedValue(suite),
      listCases: vi.fn().mockResolvedValue(testCases),
    });
    _setDBService(mockDB);

    const mockQConnect = vi.fn().mockResolvedValue(makeAgentResponse());
    _setQConnectClient(createMockQConnectClient(mockQConnect));

    const mockSFN = vi.fn().mockResolvedValue({
      executionArn:
        "arn:aws:states:us-east-1:123456789012:execution:TestRunner:run-xyz",
    });
    _setSFNClient(createMockSFNClient(mockSFN));

    const event = makeEvent({
      body: JSON.stringify({ suiteId: "suite-001", concurrency: 5 }),
    });

    const result = await handler(event);

    expect(result.statusCode).toBe(201);
    const body = JSON.parse(result.body);
    expect(body.runId).toBeDefined();
    expect(body.sfnExecutionArn).toBe(
      "arn:aws:states:us-east-1:123456789012:execution:TestRunner:run-xyz"
    );
    expect(body.status).toBe("running");

    // Verify GetAIAgent was called once, and GetAIPrompt was called once
    // immediately after to resolve the orchestration prompt id into the
    // YAML body the snapshot now persists.
    expect(mockQConnect).toHaveBeenCalledTimes(2);

    // Verify Step Functions was started
    expect(mockSFN).toHaveBeenCalledTimes(1);

    // Verify DDB writes happened
    expect(mockDB.createRun).toHaveBeenCalled();
    expect(mockDB.writeSnapshot).toHaveBeenCalledTimes(1);
  });

  it("uses default concurrency of 9 when not specified", async () => {
    const suite = makeSuite();
    const testCases = [makeTestCase("case-1")];

    const mockDB = createMockDBService({
      getSuite: vi.fn().mockResolvedValue(suite),
      listCases: vi.fn().mockResolvedValue(testCases),
    });
    _setDBService(mockDB);

    _setQConnectClient(
      createMockQConnectClient(vi.fn().mockResolvedValue(makeAgentResponse()))
    );

    const mockSFN = vi.fn().mockResolvedValue({
      executionArn: "arn:aws:states:us-east-1:123456789012:execution:TestRunner:run-abc",
    });
    _setSFNClient(createMockSFNClient(mockSFN));

    const event = makeEvent({
      body: JSON.stringify({ suiteId: "suite-001" }),
    });

    const result = await handler(event);

    expect(result.statusCode).toBe(201);

    // Check the SFN input includes concurrency=9
    const sfnCallArgs = mockSFN.mock.calls[0][0];
    const sfnInput = JSON.parse(sfnCallArgs.input.input);
    expect(sfnInput.concurrency).toBe(9);
  });

  it("returns 400 when body is missing", async () => {
    const event = makeEvent({ body: null });
    const result = await handler(event);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toContain("Request body is required");
  });

  it("returns 400 when suiteId is missing", async () => {
    const event = makeEvent({ body: JSON.stringify({}) });
    const result = await handler(event);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toContain("suiteId is required");
  });

  it("returns 400 when body is invalid JSON", async () => {
    const event = makeEvent({ body: "not-json" });
    const result = await handler(event);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toContain("Invalid JSON");
  });

  it("returns 404 when suite does not exist", async () => {
    const mockDB = createMockDBService({
      getSuite: vi.fn().mockResolvedValue(null),
    });
    _setDBService(mockDB);

    const event = makeEvent({
      body: JSON.stringify({ suiteId: "nonexistent" }),
    });
    const result = await handler(event);

    expect(result.statusCode).toBe(404);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("Suite not found");
  });

  it("returns 400 when suite has no test cases", async () => {
    const mockDB = createMockDBService({
      getSuite: vi.fn().mockResolvedValue(makeSuite()),
      listCases: vi.fn().mockResolvedValue([]),
    });
    _setDBService(mockDB);

    const event = makeEvent({
      body: JSON.stringify({ suiteId: "suite-001" }),
    });
    const result = await handler(event);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toContain("no test cases");
  });

  it("returns 500 when STATE_MACHINE_ARN is not configured", async () => {
    process.env.STATE_MACHINE_ARN = "";

    const event = makeEvent({
      body: JSON.stringify({ suiteId: "suite-001" }),
    });
    const result = await handler(event);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("ConfigurationError");
  });

  it("returns 500 when ASSISTANT_ID is not configured", async () => {
    process.env.ASSISTANT_ID = "";
    process.env.STATE_MACHINE_ARN =
      "arn:aws:states:us-east-1:123456789012:stateMachine:TestRunner";

    const event = makeEvent({
      body: JSON.stringify({ suiteId: "suite-001" }),
    });
    const result = await handler(event);

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("ConfigurationError");
  });

  it("returns 401 when tenant ID is missing", async () => {
    const event = makeEvent({
      requestContext: { authorizer: { claims: {} } },
      body: JSON.stringify({ suiteId: "suite-001" }),
    });
    const result = await handler(event);

    expect(result.statusCode).toBe(401);
  });
});

// ---------------------------------------------------------------------------
// Tests: POST /runs/{runId}/abort
// ---------------------------------------------------------------------------

describe("Run Trigger Lambda - POST /runs/{runId}/abort", () => {
  it("stops execution and updates status to ABORTED", async () => {
    const suite = makeSuite();
    const run = makeRunRecord();

    const mockDB = createMockDBService({
      listSuites: vi.fn().mockResolvedValue([suite]),
      listRuns: vi.fn().mockResolvedValue([run]),
    });
    _setDBService(mockDB);

    const mockSFN = vi.fn().mockResolvedValue({});
    _setSFNClient(createMockSFNClient(mockSFN));

    const event = makeEvent({
      resource: "/runs/{runId}/abort",
      pathParameters: { runId: "run-001" },
    });

    const result = await handler(event);

    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body);
    expect(body.message).toBe("Run aborted");
    expect(body.runId).toBe("run-001");

    // Verify StopExecution was called
    expect(mockSFN).toHaveBeenCalledTimes(1);

    // Verify status update
    expect(mockDB.updateRun).toHaveBeenCalledWith(
      expect.objectContaining({
        suiteId: "suite-001",
        startTime: "2024-01-01T12:00:00.000Z",
        status: RunStatus.ABORTED,
      })
    );
  });

  it("returns 404 when run is not found", async () => {
    const mockDB = createMockDBService({
      listSuites: vi.fn().mockResolvedValue([makeSuite()]),
      listRuns: vi.fn().mockResolvedValue([]),
    });
    _setDBService(mockDB);

    const event = makeEvent({
      resource: "/runs/{runId}/abort",
      pathParameters: { runId: "nonexistent-run" },
    });

    const result = await handler(event);

    expect(result.statusCode).toBe(404);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("Run not found");
  });

  it("returns 400 when run is already completed", async () => {
    const suite = makeSuite();
    const run = makeRunRecord({ status: RunStatus.COMPLETED });

    const mockDB = createMockDBService({
      listSuites: vi.fn().mockResolvedValue([suite]),
      listRuns: vi.fn().mockResolvedValue([run]),
    });
    _setDBService(mockDB);

    const event = makeEvent({
      resource: "/runs/{runId}/abort",
      pathParameters: { runId: "run-001" },
    });

    const result = await handler(event);

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toContain("Cannot abort");
  });

  it("returns 401 when tenant ID is missing", async () => {
    const event = makeEvent({
      resource: "/runs/{runId}/abort",
      pathParameters: { runId: "run-001" },
      requestContext: { authorizer: { claims: {} } },
    });

    const result = await handler(event);
    expect(result.statusCode).toBe(401);
  });
});

// ---------------------------------------------------------------------------
// Tests: Error handling
// ---------------------------------------------------------------------------

describe("Run Trigger Lambda - Error handling", () => {
  it("returns 429 on ThrottlingException", async () => {
    const mockDB = createMockDBService({
      getSuite: vi.fn().mockImplementation(() => {
        const error = new Error("Rate exceeded");
        (error as { name: string }).name = "ThrottlingException";
        throw error;
      }),
    });
    _setDBService(mockDB);

    const event = makeEvent({
      body: JSON.stringify({ suiteId: "suite-001" }),
    });
    const result = await handler(event);

    expect(result.statusCode).toBe(429);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("ThrottlingException");
    expect(body.retryable).toBe(true);
  });

  it("returns 409 on ExecutionAlreadyExists", async () => {
    const suite = makeSuite();
    const testCases = [makeTestCase("case-1")];

    const mockDB = createMockDBService({
      getSuite: vi.fn().mockResolvedValue(suite),
      listCases: vi.fn().mockResolvedValue(testCases),
    });
    _setDBService(mockDB);

    _setQConnectClient(
      createMockQConnectClient(vi.fn().mockResolvedValue(makeAgentResponse()))
    );

    const sfnError = new Error("Execution already exists");
    (sfnError as { name: string }).name = "ExecutionAlreadyExists";
    _setSFNClient(createMockSFNClient(vi.fn().mockRejectedValue(sfnError)));

    const event = makeEvent({
      body: JSON.stringify({ suiteId: "suite-001" }),
    });
    const result = await handler(event);

    expect(result.statusCode).toBe(409);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("ExecutionAlreadyExists");
  });

  it("handles OPTIONS preflight requests", async () => {
    const event = makeEvent({ httpMethod: "OPTIONS" });
    const result = await handler(event);

    expect(result.statusCode).toBe(200);
    expect(result.headers["Access-Control-Allow-Origin"]).toBe("*");
  });

  it("returns 404 for unknown routes", async () => {
    const event = makeEvent({
      httpMethod: "GET",
      resource: "/runs",
    });
    const result = await handler(event);

    expect(result.statusCode).toBe(404);
  });
});

// ---------------------------------------------------------------------------
// Tests: snapshotAgent — Tool examples capture
// ---------------------------------------------------------------------------
//
// These tests cover task 12.2 of the actionable-recommendations spec. They
// confirm that the snapshot persisted at run start carries the per-tool
// `examples` array exactly as it appeared on the upstream Q in Connect
// payload, with absent / null / non-array values defensively coerced to
// `[]` (R3.1, R3.2). They also round-trip the persisted snapshot through
// the DDB document marshaller to confirm the new field survives the
// serialization boundary the platform uses for every DDB write.

import { marshall, unmarshall } from "@aws-sdk/util-dynamodb";
import type { AgentSnapshot, ToolDefinition } from "../../src/shared/types";

/**
 * Wraps the captured snapshot mock so each test can read back the exact
 * `AgentSnapshot` `snapshotAgent` produced for the run.
 */
function captureSnapshot(): {
  mockDB: DynamoDBService;
  getSnapshot: () => AgentSnapshot;
  getRunId: () => string;
} {
  let captured: AgentSnapshot | null = null;
  let capturedRunId: string | null = null;
  const writeSnapshot = vi
    .fn()
    .mockImplementation(async (runId: string, snapshot: AgentSnapshot) => {
      capturedRunId = runId;
      captured = snapshot;
    });

  const mockDB = createMockDBService({
    getSuite: vi.fn().mockResolvedValue(makeSuite()),
    listCases: vi.fn().mockResolvedValue([makeTestCase("case-1")]),
    writeSnapshot,
  });

  return {
    mockDB,
    getSnapshot: () => {
      if (!captured) throw new Error("snapshot was not captured");
      return captured;
    },
    getRunId: () => {
      if (!capturedRunId) throw new Error("runId was not captured");
      return capturedRunId;
    },
  };
}

/**
 * Builds an aiAgent response whose orchestration tool configurations are
 * provided verbatim by the caller. The shape mirrors what the SDK returns
 * for `GetAIAgentCommand` — the upstream `examples` field is widened to
 * `unknown` so each test can drive the malformed-payload branch without
 * fighting the SDK typings.
 */
function makeAgentResponseWithTools(
  toolConfigurations: Array<Record<string, unknown>>,
) {
  return {
    aiAgent: {
      aiAgentId: "agent-booking-1",
      name: "Booking Agent",
      type: "ORCHESTRATION",
      configuration: {
        orchestrationAIAgentConfiguration: {
          orchestrationAIPromptId: "prompt-model-123",
          toolConfigurations,
        },
      },
    },
  };
}

/**
 * QConnect mock that dispatches on command class name so `GetAIAgent` and
 * `GetAIPrompt` can return distinct payloads. The prompt response is the
 * same shape across all examples-capture tests — the focus of this suite
 * is the per-tool `examples` mapping, not the prompt resolution path.
 */
function createDispatchingQConnectClient(
  agentResponse: ReturnType<typeof makeAgentResponseWithTools>,
) {
  return createMockQConnectClient(async (command: unknown) => {
    const name = (command as { constructor?: { name?: string } }).constructor
      ?.name;
    if (name === "GetAIAgentCommand") return agentResponse;
    if (name === "GetAIPromptCommand") {
      return {
        aiPrompt: {
          modelId: "anthropic.claude-3",
          templateConfiguration: {
            textFullAIPromptEditTemplateConfiguration: {
              text: "system prompt body",
            },
          },
        },
      };
    }
    return {};
  });
}

function makeStartEvent() {
  return makeEvent({
    body: JSON.stringify({ suiteId: "suite-001", concurrency: 1 }),
  });
}

describe("Run Trigger Lambda - snapshotAgent examples capture", () => {
  it("captures verbatim examples for every tool when the upstream payload carries them", async () => {
    const { mockDB, getSnapshot } = captureSnapshot();
    _setDBService(mockDB);

    // Mixture of multi-line, embedded-quote, leading/trailing-whitespace,
    // and empty-string entries to confirm no normalization is applied.
    const toolAExamples = [
      "What's my balance?",
      "Tell me my account total",
      "  leading and trailing whitespace  ",
    ];
    const toolBExamples = [
      "line\nbreak in example",
      '"quoted entry"',
      "",
    ];
    const toolCExamples: string[] = [];

    _setQConnectClient(
      createDispatchingQConnectClient(
        makeAgentResponseWithTools([
          {
            toolName: "ToolA",
            toolType: "LAMBDA",
            description: "Tool A",
            instruction: { instruction: "Use Tool A" },
            inputSchema: { type: "object" },
            examples: toolAExamples,
          },
          {
            toolName: "ToolB",
            toolType: "LAMBDA",
            description: "Tool B",
            inputSchema: { type: "object" },
            examples: toolBExamples,
          },
          {
            toolName: "ToolC",
            toolType: "LAMBDA",
            description: "Tool C",
            inputSchema: { type: "object" },
            examples: toolCExamples,
          },
        ]),
      ),
    );

    _setSFNClient(
      createMockSFNClient(
        vi.fn().mockResolvedValue({
          executionArn:
            "arn:aws:states:us-east-1:123456789012:execution:TestRunner:run-x",
        }),
      ),
    );

    const result = await handler(makeStartEvent());
    expect(result.statusCode).toBe(201);

    const snapshot = getSnapshot();
    expect(snapshot.tools).toHaveLength(3);

    // Element-wise equality including order and string content (R3.4).
    expect(snapshot.tools[0].toolName).toBe("ToolA");
    expect(snapshot.tools[0].examples).toEqual(toolAExamples);

    expect(snapshot.tools[1].toolName).toBe("ToolB");
    expect(snapshot.tools[1].examples).toEqual(toolBExamples);

    expect(snapshot.tools[2].toolName).toBe("ToolC");
    expect(snapshot.tools[2].examples).toEqual([]);

    // Field is always present on every tool (R1.5 / R3.2 — never omitted).
    snapshot.tools.forEach((tool: ToolDefinition) => {
      expect(Array.isArray(tool.examples)).toBe(true);
    });

    // The snapshot mapper SHALL copy, not alias, the upstream array so
    // later mutations on the QConnect response cannot leak into the
    // persisted snapshot.
    toolAExamples.push("mutated after snapshot");
    expect(snapshot.tools[0].examples).not.toContain("mutated after snapshot");
  });

  it("emits an empty examples array for every tool when the upstream payload omits the field", async () => {
    const { mockDB, getSnapshot } = captureSnapshot();
    _setDBService(mockDB);

    _setQConnectClient(
      createDispatchingQConnectClient(
        makeAgentResponseWithTools([
          {
            toolName: "ToolNoExamplesField",
            toolType: "LAMBDA",
            description: "Has no examples key at all",
            inputSchema: { type: "object" },
            // examples key intentionally absent
          },
          {
            toolName: "ToolNullExamples",
            toolType: "LAMBDA",
            description: "examples is null",
            inputSchema: { type: "object" },
            examples: null,
          },
          {
            toolName: "ToolUndefinedExamples",
            toolType: "LAMBDA",
            description: "examples is explicitly undefined",
            inputSchema: { type: "object" },
            examples: undefined,
          },
          {
            toolName: "ToolEmptyExamples",
            toolType: "LAMBDA",
            description: "examples is an empty array",
            inputSchema: { type: "object" },
            examples: [],
          },
        ]),
      ),
    );

    _setSFNClient(
      createMockSFNClient(
        vi.fn().mockResolvedValue({
          executionArn:
            "arn:aws:states:us-east-1:123456789012:execution:TestRunner:run-y",
        }),
      ),
    );

    const result = await handler(makeStartEvent());
    expect(result.statusCode).toBe(201);

    const snapshot = getSnapshot();
    expect(snapshot.tools).toHaveLength(4);
    snapshot.tools.forEach((tool) => {
      expect(tool.examples).toEqual([]);
    });
  });

  it("defensively coerces malformed examples (non-array on the upstream payload) to an empty array", async () => {
    const { mockDB, getSnapshot } = captureSnapshot();
    _setDBService(mockDB);

    _setQConnectClient(
      createDispatchingQConnectClient(
        makeAgentResponseWithTools([
          {
            toolName: "ToolNumberExamples",
            toolType: "LAMBDA",
            description: "examples is a number",
            inputSchema: { type: "object" },
            examples: 42,
          },
          {
            toolName: "ToolStringExamples",
            toolType: "LAMBDA",
            description: "examples is a string",
            inputSchema: { type: "object" },
            examples: "not an array",
          },
          {
            toolName: "ToolObjectExamples",
            toolType: "LAMBDA",
            description: "examples is an object",
            inputSchema: { type: "object" },
            examples: { 0: "indexed-like map", 1: "still not an array" },
          },
          {
            toolName: "ToolBooleanExamples",
            toolType: "LAMBDA",
            description: "examples is a boolean",
            inputSchema: { type: "object" },
            examples: true,
          },
        ]),
      ),
    );

    _setSFNClient(
      createMockSFNClient(
        vi.fn().mockResolvedValue({
          executionArn:
            "arn:aws:states:us-east-1:123456789012:execution:TestRunner:run-z",
        }),
      ),
    );

    // Malformed upstream payloads MUST NOT 500 here — the snapshot
    // captures defensively. The 500 path defined in R5.8 surfaces only on
    // analysis read (task 6), not on snapshot capture.
    const result = await handler(makeStartEvent());
    expect(result.statusCode).toBe(201);

    const snapshot = getSnapshot();
    expect(snapshot.tools).toHaveLength(4);
    snapshot.tools.forEach((tool) => {
      expect(tool.examples).toEqual([]);
      expect(Array.isArray(tool.examples)).toBe(true);
    });
  });

  it("round-trips the snapshot through the DDB document marshaller with the examples field intact", async () => {
    // Property R3.4 / R15.5: writing the snapshot through the marshaller
    // and reading it back SHALL produce a snapshot whose `examples` arrays
    // are element-wise equal to the input. We exercise the same pair of
    // helpers (`@aws-sdk/util-dynamodb` `marshall`/`unmarshall`) the
    // `DynamoDBDocumentClient` uses internally for every PutCommand /
    // GetCommand, which is the serialization boundary the snapshot
    // crosses on `db.writeSnapshot(...)` and `db.getSnapshot(...)`.
    const { mockDB, getSnapshot } = captureSnapshot();
    _setDBService(mockDB);

    const examplesA = ['"escaped"', "line1\nline2", "  spaces  ", ""];
    const examplesB = ["only one"];

    _setQConnectClient(
      createDispatchingQConnectClient(
        makeAgentResponseWithTools([
          {
            toolName: "ToolA",
            toolType: "LAMBDA",
            description: "Tool A",
            instruction: { instruction: "Use Tool A" },
            inputSchema: { type: "object", properties: { x: { type: "string" } } },
            examples: examplesA,
          },
          {
            toolName: "ToolB",
            toolType: "LAMBDA",
            description: "Tool B",
            inputSchema: { type: "object" },
            examples: examplesB,
          },
        ]),
      ),
    );

    _setSFNClient(
      createMockSFNClient(
        vi.fn().mockResolvedValue({
          executionArn:
            "arn:aws:states:us-east-1:123456789012:execution:TestRunner:run-rt",
        }),
      ),
    );

    const result = await handler(makeStartEvent());
    expect(result.statusCode).toBe(201);

    const snapshot = getSnapshot();

    // Marshall the persisted item shape (PK + SK + ...snapshot) the same
    // way `DynamoDBService.writeSnapshot` constructs it, then unmarshall
    // and strip the keys back out — equivalent to the read path's
    // `stripKeys`. The `examples` arrays MUST survive the round-trip
    // element-wise.
    const persistedItem = {
      PK: "RUN#run-rt",
      SK: "SNAPSHOT",
      ...snapshot,
    };
    const marshalled = marshall(persistedItem, {
      removeUndefinedValues: true,
    });
    const roundTripped = unmarshall(marshalled) as Record<string, unknown>;

    // Strip the DDB key attributes (the production read helper does the
    // same in `stripKeys`).
    delete roundTripped.PK;
    delete roundTripped.SK;
    const recovered = roundTripped as unknown as AgentSnapshot;

    expect(recovered.tools).toHaveLength(2);
    expect(recovered.tools[0].toolName).toBe("ToolA");
    expect(recovered.tools[0].examples).toEqual(examplesA);
    expect(recovered.tools[1].toolName).toBe("ToolB");
    expect(recovered.tools[1].examples).toEqual(examplesB);

    // Top-level snapshot shape is unchanged beyond the per-tool field
    // (R3.2 — `tools`, `systemPrompt`, `modelId`, `capturedAt` stay
    // byte-for-byte the same after the round-trip).
    expect(recovered.systemPrompt).toBe(snapshot.systemPrompt);
    expect(recovered.modelId).toBe(snapshot.modelId);
    expect(recovered.capturedAt).toBe(snapshot.capturedAt);
  });
});
