/**
 * Integration test for the synthetic-control-tool augmentation path.
 *
 * Validates the fix for the case-row vs. judge-context disagreement on
 * RETURN_TO_CONTROL tools (Complete / Escalate / custom control tools):
 *
 *   - `parseSpansToTrace` does not see RETURN_TO_CONTROL tools because Q
 *     in Connect emits them as a non-`execute_tool` span (e.g.
 *     `escalate_agent`) with no toolUse attributes.
 *   - `augmentTraceWithControlTools` injects a synthetic
 *     `type: "tool"` step (spanName `synthetic_control_tool`) so the
 *     judge's session-level `{context}` carries an `Action:` line for
 *     the tool the polling loop captured via
 *     `conversationSessionData["Tool"]`.
 *   - `renderJudgePromptContext` distinguishes synthetic entries from
 *     real `execute_tool` spans:
 *       * Session-level `{context}` (consumed by GoalSuccessRate) gets
 *         an explanatory parenthetical so the judge does not misread
 *         the empty payload as an agent defect.
 *       * The per-tool-call `toolTurns` array (consumed by
 *         ToolSelectionAccuracy) carries entries for synthetic tools
 *         too, but their `toolTurn` field uses the explanatory
 *         parenthetical form rather than the misleading `({})` payload.
 *         RETURN_TO_CONTROL tools and MCP tools both have descriptions,
 *         so both should be evaluated for tool-choice accuracy; the
 *         parenthetical signals to the judge that arguments are not
 *         observable so it grades only on whether the chosen tool was
 *         the right pick.
 *
 * Fixture: `tests/fixtures/spans/failure-escalation.json` already
 * contains an `escalateToHuman` tool that surfaces as a real
 * `execute_tool` span (the prior shape). For this test we exercise the
 * RETURN_TO_CONTROL shape: a span tagged `escalate_agent` (no toolUse
 * attributes) plus a `controlToolsInvoked` entry the polling loop would
 * have captured.
 */

import { describe, it, expect } from "vitest";

import {
  parseSpansToTrace,
  augmentTraceWithControlTools,
  type RawSpan,
} from "../../src/backend/orchestration/span-parser";
import {
  renderJudgePromptContext,
  renderToolTurnForToolCall,
  type ConversationTurnToolCall,
} from "../../src/shared/utils/judge-prompt-rendering";
import type { AgentSnapshot, TranscriptTurn } from "../../src/shared/types";

/**
 * Reproduces the failing-case bug condition from run
 * `034502f5176b3a460a544115` / case `3872aefd139228a55c355348`: an
 * `invoke_agent` → `inference` → `escalate_agent` (type `other`)
 * sequence whose `toolSequence` is `[]` until the augmenter runs.
 */
const ESCALATION_RAW_SPANS: RawSpan[] = [
  {
    spanName: "invoke_agent",
    startTimestamp: "2024-06-02T18:30:00.000Z",
    attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
  },
  {
    spanName: "inference",
    startTimestamp: "2024-06-02T18:30:01.000Z",
    attributes: {
      aiAgentName: "AnyBank",
      aiAgentType: "ORCHESTRATION",
      outputMessages: [
        {
          values: [
            {
              text: {
                value:
                  "Let me get you to a specialist who can take this from here.",
              },
            },
          ],
        },
      ],
    },
  },
  {
    spanName: "escalate_agent",
    startTimestamp: "2024-06-02T18:30:02.000Z",
    attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
  },
];

/**
 * A trace that exercises both shapes: a real `execute_tool` span
 * (`verifyIdentity`) followed by an `escalate_agent` span the augmenter
 * will turn into a synthetic step. Used by the "synthetic excluded but
 * real preserved" assertion below.
 */
const MIXED_RAW_SPANS: RawSpan[] = [
  {
    spanName: "invoke_agent",
    startTimestamp: "2024-06-02T18:30:00.000Z",
    attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
  },
  {
    spanName: "inference",
    startTimestamp: "2024-06-02T18:30:01.000Z",
    attributes: {
      aiAgentName: "AnyBank",
      aiAgentType: "ORCHESTRATION",
      outputMessages: [
        {
          values: [
            { text: { value: "Let me verify your identity first." } },
          ],
        },
      ],
    },
  },
  {
    spanName: "execute_tool",
    startTimestamp: "2024-06-02T18:30:02.000Z",
    attributes: {
      aiAgentName: "AnyBank",
      aiAgentType: "ORCHESTRATION",
      inputMessages: [
        {
          values: [
            {
              toolUse: {
                name: "verifyIdentity",
                arguments: '{"ani":"+15555550100"}',
              },
            },
          ],
        },
      ],
      outputMessages: [
        {
          values: [
            {
              toolResult: {
                values: [{ text: { value: '{"status":"success"}' } }],
              },
            },
          ],
        },
      ],
    },
  },
  {
    spanName: "inference",
    startTimestamp: "2024-06-02T18:30:03.000Z",
    attributes: {
      aiAgentName: "AnyBank",
      aiAgentType: "ORCHESTRATION",
      outputMessages: [
        {
          values: [
            {
              text: {
                value:
                  "Thanks. Let me get you to a specialist who can help with this.",
              },
            },
          ],
        },
      ],
    },
  },
  {
    spanName: "escalate_agent",
    startTimestamp: "2024-06-02T18:30:04.000Z",
    attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
  },
];

const TRANSCRIPT: TranscriptTurn[] = [
  {
    turnNumber: 0,
    role: "customer",
    text: "I'd like to be transferred to a human, please.",
    timestamp: "2024-06-02T18:30:00.500Z",
    elapsedMs: 0,
  },
];

const SNAPSHOT: AgentSnapshot = {
  tools: [],
  systemPrompt: "",
  modelId: "",
  capturedAt: "2024-06-02T18:30:10.000Z",
};

const SYNTHETIC_NOTE =
  "RETURN_TO_CONTROL — call arguments and result not surfaced by ListSpans";

describe("renderJudgePromptContext on an augmented trace", () => {
  it("renders the synthetic control tool with an explanatory parenthetical, never with the misleading `({})` payload", () => {
    const trace = parseSpansToTrace("session-fix-1", ESCALATION_RAW_SPANS);

    // Sanity: the parser, on its own, produces a trace with no tool
    // sequence — exactly the bug condition.
    expect(trace.toolSequence).toEqual([]);

    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    const rendered = renderJudgePromptContext({
      trace: augmented,
      transcript: TRANSCRIPT,
      snapshot: SNAPSHOT,
      expectedToolNames: ["Escalate"],
    });

    // The session-level context carries an `Action:` line that names the
    // tool AND notes that the call payload was not captured by the
    // platform. Without this annotation the GoalSuccessRate judge
    // misreads the empty payload as an agent defect (Score: No).
    expect(rendered.context).toContain(
      `Action: Escalate (${SYNTHETIC_NOTE})`,
    );
    expect(rendered.context).toContain("Tool: (not captured)");

    // Critical regression guard: the prior `Action: Escalate({})` shape
    // (which the judge interpreted as "agent failed to populate required
    // parameters") MUST NOT recur.
    expect(rendered.context).not.toContain("Action: Escalate({})");
  });

  it("uses the same explanatory parenthetical for any control tool name (not hardcoded to Escalate / Complete)", () => {
    const trace = parseSpansToTrace("session-fix-2", ESCALATION_RAW_SPANS);

    const augmented = augmentTraceWithControlTools(trace, [
      "TransferToFraudDept",
    ]);

    const rendered = renderJudgePromptContext({
      trace: augmented,
      transcript: TRANSCRIPT,
      snapshot: SNAPSHOT,
      expectedToolNames: ["TransferToFraudDept"],
    });

    expect(rendered.context).toContain(
      `Action: TransferToFraudDept (${SYNTHETIC_NOTE})`,
    );
    expect(rendered.context).toContain("Tool: (not captured)");
    expect(rendered.context).not.toContain(
      "Action: TransferToFraudDept({})",
    );
  });

  it("includes synthetic control-tool steps in `toolTurns` with the explanatory parenthetical (ToolSelectionAccuracy grades on tool choice, not on unobservable args)", () => {
    const trace = parseSpansToTrace("session-fix-3", ESCALATION_RAW_SPANS);
    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    const rendered = renderJudgePromptContext({
      trace: augmented,
      transcript: TRANSCRIPT,
      snapshot: SNAPSHOT,
      expectedToolNames: ["Escalate"],
    });

    // The trace's only tool step is synthetic. ToolSelectionAccuracy
    // still gets a unit to score: RETURN_TO_CONTROL tools have
    // descriptions in the AgentSnapshot just like MCP tools, so the
    // judge can evaluate whether `Escalate` was the right pick. The
    // `toolTurn` field uses the explanatory parenthetical form so the
    // judge recognises the arguments-not-observable case and does not
    // penalise on the empty payload.
    expect(rendered.toolTurns).toHaveLength(1);
    expect(rendered.toolTurns[0].toolTurn).toBe(
      "Escalate (RETURN_TO_CONTROL — call arguments not surfaced by ListSpans)",
    );

    // Critical: the misleading `Escalate({})` shape MUST NOT appear in
    // any tool-turn rendering — that is what the prior fix tripped on.
    expect(rendered.toolTurns[0].toolTurn).not.toBe("Escalate({})");
  });

  it("renders BOTH real `execute_tool` and synthetic entries in `toolTurns` with their respective forms (mixed trace)", () => {
    const trace = parseSpansToTrace("session-fix-4", MIXED_RAW_SPANS);

    // The parser sees the real verifyIdentity tool but not the
    // RETURN_TO_CONTROL escalate entry — exactly the production shape.
    expect(trace.toolSequence).toEqual(["verifyIdentity"]);

    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);
    expect(augmented.toolSequence).toEqual(["verifyIdentity", "Escalate"]);

    const rendered = renderJudgePromptContext({
      trace: augmented,
      transcript: TRANSCRIPT,
      snapshot: SNAPSHOT,
      expectedToolNames: ["verifyIdentity", "Escalate"],
    });

    // Both tools are dispatched to ToolSelectionAccuracy, in
    // chronological order. The real tool keeps its byte-compatible
    // `${toolName}(${args})` form. The synthetic tool uses the
    // explanatory parenthetical form so the judge does not interpret
    // the empty payload as an agent defect.
    expect(rendered.toolTurns).toHaveLength(2);
    expect(rendered.toolTurns[0].toolTurn).toBe(
      'verifyIdentity({"ani":"+15555550100"})',
    );
    expect(rendered.toolTurns[1].toolTurn).toBe(
      "Escalate (RETURN_TO_CONTROL — call arguments not surfaced by ListSpans)",
    );

    // The session-level context still surfaces both: the real call
    // with its arguments and result, and the synthetic call with the
    // explanatory parenthetical.
    expect(rendered.context).toContain(
      'Action: verifyIdentity({"ani":"+15555550100"})',
    );
    expect(rendered.context).toContain('Tool: {"status":"success"}');
    expect(rendered.context).toContain(
      `Action: Escalate (${SYNTHETIC_NOTE})`,
    );
    expect(rendered.context).toContain("Tool: (not captured)");
  });

  it("session-level `context` still surfaces every synthetic tool so GoalSuccessRate sees the tool was invoked (Req regression guard)", () => {
    // The original bug was the OPPOSITE direction: the goal-success
    // judge concluded "no tool was actually invoked" because the
    // synthesised step was missing from the rendered context. Guard
    // against any future change that would silently drop synthetic
    // steps from the session-level context (which is exactly what
    // happens to `toolTurns`).
    const trace = parseSpansToTrace("session-fix-5", ESCALATION_RAW_SPANS);
    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    const rendered = renderJudgePromptContext({
      trace: augmented,
      transcript: TRANSCRIPT,
      snapshot: SNAPSHOT,
      expectedToolNames: ["Escalate"],
    });

    const actionLines = rendered.context
      .split("\n")
      .filter((l) => l.startsWith("Action: Escalate"));
    expect(actionLines).toHaveLength(1);
    expect(actionLines[0]).toBe(`Action: Escalate (${SYNTHETIC_NOTE})`);
  });

  it("session-level `context` still surfaces synthetic tools (sanity re-check unaffected by the toolTurns change)", () => {
    // Re-affirms the existing prefix-context contract did not regress:
    // the session-level rendering uses `renderToolCallLines` (not
    // `renderToolTurn`) and that helper already handled synthetic
    // entries correctly. This sibling assertion to the regression-guard
    // case above guards against any future change that would silently
    // change either renderer.
    const trace = parseSpansToTrace("session-fix-6", ESCALATION_RAW_SPANS);
    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    const rendered = renderJudgePromptContext({
      trace: augmented,
      transcript: TRANSCRIPT,
      snapshot: SNAPSHOT,
      expectedToolNames: ["Escalate"],
    });

    expect(rendered.context).toContain(
      `Action: Escalate (${SYNTHETIC_NOTE})`,
    );
    expect(rendered.context).toContain("Tool: (not captured)");
  });

  it("renders RETURN_TO_CONTROL toolUse from inference outputMessages with full arguments (production shape)", () => {
    // Reproduces the live ListSpans dump shape: an inference span whose
    // outputMessages carries both a text entry and a toolUse entry for
    // Escalate, followed by an escalate_agent marker. The parser now
    // captures the toolUse with full arguments at parse time, so the
    // augmenter is a no-op and the rendering layer produces the standard
    // `Action: Escalate({...})` form — NOT the explanatory parenthetical.
    const ESCALATE_ARGS_JSON =
      '{"escalationReason":"Customer requested to speak with a human agent","customerIntent":"speak with a human agent","sentiment":"Neutral","escalationSummary":"summary text","customerFirstName":"Unknown","ProfileId":"Unknown"}';

    const PRODUCTION_RAW_SPANS: RawSpan[] = [
      {
        spanName: "invoke_agent",
        startTimestamp: "2024-06-02T18:30:00.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
      {
        spanName: "inference",
        startTimestamp: "2024-06-02T18:30:01.000Z",
        endTimestamp: "2024-06-02T18:30:01.500Z",
        attributes: {
          aiAgentName: "AnyBank",
          aiAgentType: "ORCHESTRATION",
          outputMessages: [
            {
              values: [
                {
                  text: {
                    value:
                      "I'll get you to a specialist who can help with this.",
                  },
                },
                {
                  toolUse: {
                    name: "Escalate",
                    arguments: ESCALATE_ARGS_JSON,
                  },
                },
              ],
            },
          ],
        },
      },
      {
        spanName: "escalate_agent",
        startTimestamp: "2024-06-02T18:30:02.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
    ];

    const trace = parseSpansToTrace("session-prod-shape", PRODUCTION_RAW_SPANS);

    // Parser captured Escalate at parse time with real arguments.
    expect(trace.toolSequence).toEqual(["Escalate"]);
    const inferenceToolUse = trace.steps.find(
      (s) => s.spanName === "inference_tool_use",
    );
    expect(inferenceToolUse?.tool?.toolName).toBe("Escalate");
    expect(inferenceToolUse?.tool?.arguments).toEqual({
      escalationReason: "Customer requested to speak with a human agent",
      customerIntent: "speak with a human agent",
      sentiment: "Neutral",
      escalationSummary: "summary text",
      customerFirstName: "Unknown",
      ProfileId: "Unknown",
    });

    // Augmenter is a no-op — Escalate is already in toolSequence.
    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);
    expect(augmented.steps).toEqual(trace.steps);
    expect(augmented.toolSequence).toEqual(["Escalate"]);
    expect(
      augmented.steps.find((s) => s.spanName === "synthetic_control_tool"),
    ).toBeUndefined();

    const rendered = renderJudgePromptContext({
      trace: augmented,
      transcript: TRANSCRIPT,
      snapshot: SNAPSHOT,
      expectedToolNames: ["Escalate"],
    });

    // Rendered context carries the full Action: Escalate({...}) line with
    // real arguments. The expected JSON shape uses JSON.stringify on the
    // parsed argument object (key order: as inserted into the object).
    const expectedActionLine = `Action: Escalate(${JSON.stringify({
      escalationReason: "Customer requested to speak with a human agent",
      customerIntent: "speak with a human agent",
      sentiment: "Neutral",
      escalationSummary: "summary text",
      customerFirstName: "Unknown",
      ProfileId: "Unknown",
    })})`;
    expect(rendered.context).toContain(expectedActionLine);

    // The toolTurn carries the same full-args form.
    expect(rendered.toolTurns).toHaveLength(1);
    expect(rendered.toolTurns[0].toolTurn).toBe(
      `Escalate(${JSON.stringify({
        escalationReason: "Customer requested to speak with a human agent",
        customerIntent: "speak with a human agent",
        sentiment: "Neutral",
        escalationSummary: "summary text",
        customerFirstName: "Unknown",
        ProfileId: "Unknown",
      })})`,
    );

    // Critical regression guards: neither the explanatory parenthetical
    // nor the misleading `Escalate({})` shape should appear anywhere.
    expect(rendered.context).not.toContain(SYNTHETIC_NOTE);
    expect(rendered.context).not.toContain("Action: Escalate({})");
    expect(rendered.toolTurns[0].toolTurn).not.toContain(SYNTHETIC_NOTE);
    expect(rendered.toolTurns[0].toolTurn).not.toBe("Escalate({})");
  });
});

describe("renderToolTurnForToolCall", () => {
  it("renders a real tool call as the byte-compatible `${toolName}(${JSON.stringify(args)})` form", () => {
    const real: ConversationTurnToolCall = {
      toolInvocation: {
        toolName: "verifyIdentity",
        arguments: { ani: "+15555550100" },
        result: { status: "success" },
        success: true,
      },
      isSynthetic: false,
    };

    expect(renderToolTurnForToolCall(real)).toBe(
      'verifyIdentity({"ani":"+15555550100"})',
    );
  });

  it("renders a real tool call with empty arguments as `name({})` (regression guard for the prior `Escalate({})` shape on a real tool)", () => {
    const real: ConversationTurnToolCall = {
      toolInvocation: {
        toolName: "noopTool",
        arguments: {},
        result: null,
        success: true,
      },
      isSynthetic: false,
    };

    expect(renderToolTurnForToolCall(real)).toBe("noopTool({})");
  });

  it("renders a synthetic RETURN_TO_CONTROL call with the explanatory parenthetical (no `({})` payload)", () => {
    const synthetic: ConversationTurnToolCall = {
      toolInvocation: {
        toolName: "Escalate",
        arguments: {},
        result: null,
        success: true,
      },
      isSynthetic: true,
    };

    expect(renderToolTurnForToolCall(synthetic)).toBe(
      "Escalate (RETURN_TO_CONTROL — call arguments not surfaced by ListSpans)",
    );
    expect(renderToolTurnForToolCall(synthetic)).not.toBe("Escalate({})");
  });

  it("uses the same parenthetical form for any synthetic tool name (not hardcoded to Escalate / Complete)", () => {
    const synthetic: ConversationTurnToolCall = {
      toolInvocation: {
        toolName: "TransferToFraudDept",
        arguments: {},
        result: null,
        success: true,
      },
      isSynthetic: true,
    };

    expect(renderToolTurnForToolCall(synthetic)).toBe(
      "TransferToFraudDept (RETURN_TO_CONTROL — call arguments not surfaced by ListSpans)",
    );
  });
});
