/**
 * Unit tests for the Contact Manager module.
 *
 * Covers:
 * - buildContactArn formatting (bare instance ID and instance ARN inputs)
 * - startContact returns contactId + ARN, attaches ANI, throws on missing ID
 * - stopContact is best-effort (swallows errors)
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import {
  buildContactArn,
  startContact,
  stopContact,
  _setConnectClient,
} from "../../src/backend/orchestration/contact-manager";

function mockConnect(send: ReturnType<typeof vi.fn>) {
  _setConnectClient({ send } as unknown as Parameters<typeof _setConnectClient>[0]);
}

describe("buildContactArn", () => {
  const originalEnv = process.env;
  beforeEach(() => {
    process.env = { ...originalEnv, AWS_REGION: "us-east-1", ACCOUNT_ID: "111122223333" };
  });
  afterEach(() => {
    process.env = originalEnv;
  });

  it("builds an ARN from a bare instance UUID", () => {
    const arn = buildContactArn("inst-uuid", "contact-uuid");
    expect(arn).toBe(
      "arn:aws:connect:us-east-1:111122223333:instance/inst-uuid/contact/contact-uuid"
    );
  });

  it("extracts the instance UUID from an instance ARN", () => {
    const arn = buildContactArn(
      "arn:aws:connect:us-east-1:111122223333:instance/inst-uuid",
      "contact-uuid"
    );
    expect(arn).toBe(
      "arn:aws:connect:us-east-1:111122223333:instance/inst-uuid/contact/contact-uuid"
    );
  });
});

describe("startContact", () => {
  beforeEach(() => {
    process.env = { ...process.env, AWS_REGION: "us-east-1", ACCOUNT_ID: "111122223333" };
  });
  afterEach(() => {
    _setConnectClient(null);
    vi.restoreAllMocks();
  });

  it("returns the minted contactId and fully-qualified ARN", async () => {
    const send = vi.fn().mockResolvedValue({ ContactId: "contact-123" });
    mockConnect(send);

    const result = await startContact("inst-uuid", "flow-uuid");

    expect(result.contactId).toBe("contact-123");
    expect(result.contactArn).toContain("/contact/contact-123");
  });

  it("passes instance, flow, and ANI attribute to StartChatContact", async () => {
    const send = vi.fn().mockResolvedValue({ ContactId: "contact-123" });
    mockConnect(send);

    await startContact("inst-uuid", "flow-uuid", "4074629069");

    expect(send).toHaveBeenCalledTimes(1);
    const input = send.mock.calls[0][0].input;
    expect(input.InstanceId).toBe("inst-uuid");
    expect(input.ContactFlowId).toBe("flow-uuid");
    expect(input.Attributes).toEqual({ ANI: "4074629069" });
  });

  it("omits Attributes when no ANI is provided", async () => {
    const send = vi.fn().mockResolvedValue({ ContactId: "contact-123" });
    mockConnect(send);

    await startContact("inst-uuid", "flow-uuid");

    const input = send.mock.calls[0][0].input;
    expect(input.Attributes).toBeUndefined();
  });

  it("throws when the response has no ContactId", async () => {
    const send = vi.fn().mockResolvedValue({});
    mockConnect(send);

    await expect(startContact("inst-uuid", "flow-uuid")).rejects.toThrow(/ContactId/);
  });
});

describe("stopContact", () => {
  afterEach(() => {
    _setConnectClient(null);
    vi.restoreAllMocks();
  });

  it("calls StopContact with instance and contact IDs", async () => {
    const send = vi.fn().mockResolvedValue({});
    mockConnect(send);

    await stopContact("inst-uuid", "contact-123");

    expect(send).toHaveBeenCalledTimes(1);
    const input = send.mock.calls[0][0].input;
    expect(input.InstanceId).toBe("inst-uuid");
    expect(input.ContactId).toBe("contact-123");
  });

  it("swallows errors (best-effort teardown)", async () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    const send = vi.fn().mockRejectedValue(new Error("contact already ended"));
    mockConnect(send);

    await expect(stopContact("inst-uuid", "contact-123")).resolves.toBeUndefined();
    expect(warnSpy).toHaveBeenCalled();
  });
});
