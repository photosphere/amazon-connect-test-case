/**
 * Pure, deploy-time runtime-config assembler/validator.
 *
 * Builds the `/config.json` document the frontend fetches at startup from the
 * five resolved stack outputs. This module has NO AWS imports and is fully
 * unit-testable without a deploy: it validates that every required field is a
 * non-empty, non-whitespace string and emits an object whose keys are EXACTLY
 * the five non-secret runtime-config fields — never a client secret and never
 * a Secrets Manager value.
 *
 * Requirements: 3.2, 3.6, 13.1, 13.2
 */

/**
 * The exact, non-secret runtime-config fields served at `/config.json`.
 *
 * `cognitoClientId` MUST reference the Web_Client (`UserPoolClientId`) and
 * never the M2M client. The set of keys is closed: no other field is ever
 * emitted (Requirements 13.1, 13.2).
 */
export interface RuntimeConfigInputs {
  /** API Gateway prod-stage invoke URL. */
  apiEndpoint: string;
  /** Cognito User Pool ID. */
  cognitoUserPoolId: string;
  /** Cognito Web_Client ID (UserPoolClientId) — never the M2M client. */
  cognitoClientId: string;
  /** Cognito hosted-UI domain. */
  cognitoDomain: string;
  /** AWS Region the stack is deployed into. */
  region: string;
  /** Deploy-time instance mode controlling agent-write UI visibility (Req 19.8). */
  instanceMode: string;
}

/**
 * The ordered, exhaustive list of fields that make up the runtime config.
 * Used both to validate inputs and to construct the output so that the
 * emitted object can never contain an unexpected (e.g. secret) key.
 */
const RUNTIME_CONFIG_FIELDS = [
  'apiEndpoint',
  'cognitoUserPoolId',
  'cognitoClientId',
  'cognitoDomain',
  'region',
  'instanceMode',
] as const;

type RuntimeConfigField = (typeof RUNTIME_CONFIG_FIELDS)[number];

/**
 * Assemble and validate the runtime config served at `/config.json`.
 *
 * Accepts the five resolved stack outputs and returns an object whose keys are
 * exactly those five non-secret fields. Throws at synth if any field is
 * missing, empty, or whitespace-only (Requirement 3.6), so an incomplete
 * `config.json` is never uploaded. The output contains no other keys — no M2M
 * secret and no Secrets Manager values (Requirements 13.1, 13.2).
 *
 * @param inputs Resolved stack outputs. Typed as a partial record so callers
 *   passing tokens/undefined are validated here rather than failing silently.
 * @returns A fully-populated, key-exact {@link RuntimeConfigInputs}.
 * @throws Error if any required field is missing/empty/whitespace.
 */
export function buildRuntimeConfig(
  inputs: Partial<Record<RuntimeConfigField, string | undefined>>
): RuntimeConfigInputs {
  const missing: RuntimeConfigField[] = [];
  const resolved = {} as Record<RuntimeConfigField, string>;

  for (const field of RUNTIME_CONFIG_FIELDS) {
    const value = inputs[field];
    if (typeof value !== 'string' || value.trim().length === 0) {
      missing.push(field);
      continue;
    }
    resolved[field] = value;
  }

  if (missing.length > 0) {
    throw new Error(
      `Cannot build runtime config: missing or empty required stack output(s): ${missing.join(
        ', '
      )}. Refusing to upload an incomplete config.json.`
    );
  }

  // Construct the output from the closed field list so the result can never
  // carry an unexpected (e.g. secret) key, even if `inputs` had extra keys.
  return {
    apiEndpoint: resolved.apiEndpoint,
    cognitoUserPoolId: resolved.cognitoUserPoolId,
    cognitoClientId: resolved.cognitoClientId,
    cognitoDomain: resolved.cognitoDomain,
    region: resolved.region,
    instanceMode: resolved.instanceMode,
  };
}
