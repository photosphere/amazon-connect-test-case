# Implementation Plan: Platform Hosting and Evaluations

## Overview

This plan extends the already-deployed Connect Agent Test Platform (CDK/TypeScript, account `104220062740`, `us-east-1`). It is organized into the two **independent workstreams** the design defines so they can be built and reviewed separately:

- **Workstream 1 — Hosting & Bootstrap (deploy-time, CDK):** Reqs 1–7, 12, 13. Pure deploy-time validators are implemented and property-tested first (no deploy needed), then the `BucketDeployment`/bootstrap constructs, stack wiring, CDK `assertions` template tests (including **Property 16** for the already-applied frontend-bucket hardening), the frontend runtime-config loading guard, and a post-deploy smoke-check script.
- **Workstream 2 — Evaluations, Harness, Comparison (runtime):** Reqs 8–11, 14, 15, 16. The pure modules (trace→OTel translation, score aggregation, result assembly, score-delta comparison) and their property tests come first so they are unit-testable without a deploy (Reqs 9.6, 15.6), then the thin AgentCore SDK seam, the Evaluation Lambda rewrite and local harness that compose them, the real `Span_Fixture` validation, and the score-aware results/comparison frontend wiring.

The two workstreams share no code; the only coupling is that the hosted UI (WS1) is how a user sees the scores (WS2). Properties 1–15 are property-based tests (Vitest + `fast-check`, min 100 iterations, tagged `// Feature: platform-hosting-and-evaluations, Property {n}: {text}`). Property 16 is a CDK `assertions` template test, not a PBT.

## Tasks

### Workstream 1 — Hosting & Bootstrap (deploy-time, CDK)

- [x] 1. Implement pure deploy-time validators and their property tests
  - [x] 1.1 Implement `buildRuntimeConfig` runtime-config assembler/validator
    - Create `lib/runtime-config.ts` exporting `buildRuntimeConfig(inputs): RuntimeConfigInputs` that accepts the five resolved outputs (`apiEndpoint`, `cognitoUserPoolId`, `cognitoClientId`, `cognitoDomain`, `region`)
    - Return an object whose keys are exactly those five non-secret fields; throw if any is missing/empty/whitespace; never emit any other key (no M2M secret, no Secrets Manager values)
    - _Requirements: 3.2, 3.6, 13.1, 13.2_
  - [x] 1.2 Write property test for `buildRuntimeConfig`
    - File `tests/unit/properties/runtime-config.test.ts`, `{ numRuns: 100 }`
    - **Property 1: Runtime config is complete-or-rejected**
    - **Validates: Requirements 3.2, 3.6, 13.1, 13.2**
  - [x] 1.3 Implement `validateCallbackUrls` helper
    - Create `lib/callback-urls.ts` exporting `validateCallbackUrls(urls: string[]): string[]` that trims entries, throws at synth on empty/non-absolute-URL entries, always includes the CloudFront URL, and returns a deduplicated set-preserving list
    - _Requirements: 4.4, 4.6_
  - [x] 1.4 Write property test for `validateCallbackUrls`
    - File `tests/unit/properties/callback-urls.test.ts`, `{ numRuns: 100 }`
    - **Property 2: Callback URLs are validated, deduplicated, and always include CloudFront**
    - **Validates: Requirements 4.4, 4.6**
  - [x] 1.5 Implement `parseAdminEmail` helper
    - Create `lib/admin-email.ts` exporting `parseAdminEmail(raw?: string): { skip: true } | { email: string }`; absent/empty/whitespace → skip; valid email (non-empty local part, single `@`, domain with a `.`) → trimmed email; invalid non-empty → throw at synth
    - _Requirements: 6.6, 7.1_
  - [x] 1.6 Write property test for `parseAdminEmail`
    - File `tests/unit/properties/admin-email.test.ts`, `{ numRuns: 100 }`
    - **Property 3: Admin email is parsed into create-or-skip-or-reject**
    - **Validates: Requirements 6.6, 7.1**

- [x] 2. Implement the frontend deployment construct
  - [x] 2.1 Create `FrontendDeploymentConstruct`
    - Create `lib/frontend-deployment-construct.ts` owning a single `s3deploy.BucketDeployment` with two sources — the build asset (`src/frontend/dist`, default, recursive/structure-preserving) and `Source.jsonData('config.json', buildRuntimeConfig(...))` — `prune: true`, `distribution` + `distributionPaths: ['/*']` for cache invalidation
    - Add a synth-time guard that throws if the resolved build dir is missing or lacks `index.html` at its root (no bucket mutation on failure); accept an injectable `buildDir` prop so synth tests can supply a fixture dir
    - Consume `buildRuntimeConfig` from task 1.1 for the `config.json` source
    - _Requirements: 1.1, 1.2, 1.4, 2.1, 3.1, 3.5, 12.1, 12.2_

- [x] 3. Implement the admin user bootstrap construct
  - [x] 3.1 Create `AdminUserBootstrapConstruct` and its custom-resource handler
    - Create `lib/admin-bootstrap-construct.ts` plus a small custom-resource Lambda `src/backend/bootstrap/admin-user-bootstrap.ts` calling Cognito `AdminCreateUser` with `Username`/email attribute = the validated email, `email_verified: true`, default `MessageAction` (temp-password email), `FORCE_CHANGE_PASSWORD` flow; treat `UsernameExistsException` as success without resetting credentials
    - Use `parseAdminEmail` (task 1.5): on `skip`, create **no** bootstrap resource at all; grant the role only `cognito-idp:AdminCreateUser` and `AdminGetUser` on the specific user-pool ARN; derive a stable physical resource id from the email for idempotency
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.7, 7.1, 7.2, 7.3, 7.4, 12.1_
  - [x] 3.2 Write unit tests for the bootstrap handler (mocked Cognito SDK)
    - File `tests/unit/admin-bootstrap.test.ts`: exactly one `AdminCreateUser`, `MessageAction` not `SUPPRESS`, email as username/attribute, `FORCE_CHANGE_PASSWORD`, and `UsernameExistsException` → success without reset
    - _Requirements: 6.2, 6.4, 6.5, 6.7_

- [x] 4. Wire hosting, bootstrap, and Cognito callback URLs into the stack
  - [x] 4.1 Integrate constructs and CloudFront callback/logout registration
    - In `lib/connect-agent-test-platform-stack.ts`, instantiate `FrontendDeploymentConstruct` (passing the `StorageConstruct` bucket + distribution and the resolved `RuntimeConfigInputs` from stack outputs) and `AdminUserBootstrapConstruct` (passing the user pool and the `adminEmail` context/prop)
    - Compute the Web_Client callback/logout URLs via `validateCallbackUrls([...contextUrls, cloudFrontUrl])` and pass them through to `lib/cognito-auth.ts` (`CognitoAuth` already accepts `callbackUrls`/`logoutUrls`); ensure `config.json` is sourced from the Web_Client id (`UserPoolClientId`), never `MachineClientId`
    - _Requirements: 1.1, 2.1, 3.1, 3.3, 4.1, 4.2, 4.4, 6.1, 7.1, 7.2, 13.3_

- [x] 5. Checkpoint
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Add CDK assertions template tests for hosting, bootstrap, and bucket hardening
  - [x] 6.1 Extend `tests/infrastructure/cdk-stack.test.ts` with hosting/wiring/idempotency assertions
    - Assert one `BucketDeployment` targets the frontend bucket with the build asset source + a `config.json` source and `prune` (Reqs 1.1, 3.1, 3.5) and sets `DistributionId` + `DistributionPaths: ['/*']` (Req 2.1); CloudFront `DefaultRootObject: index.html` and 403/404→`/index.html`/200 (Reqs 1.2, 1.5)
    - Assert `UserPoolClient` `CallbackURLs`/`LogoutURLs` include the CloudFront URL + provided URLs deduplicated (Reqs 4.1, 4.2, 4.4) and `config.json` references the Web_Client id not the machine client (Reqs 3.3, 13.3); with `adminEmail` a bootstrap resource exists and without it none does with all other resources identical (Reqs 6.1, 7.1, 7.2); logical ids of bucket/distribution/user pool/clients are stable across synth (Req 12.4)
    - Provide a fixture build dir so the construct's synth guard passes (mirror the existing `NodejsFunction` mocking pattern)
    - _Requirements: 1.1, 1.2, 1.5, 2.1, 3.1, 3.3, 3.5, 4.1, 4.2, 4.4, 6.1, 7.1, 7.2, 12.4, 13.3_
  - [x] 6.2 Write the frontend-bucket security CDK assertion test (Property 16)
    - New file `tests/infrastructure/frontend-bucket-security.test.ts` asserting the **already-applied** hardening in `lib/storage-construct.ts`: `PublicAccessBlockConfiguration` with all four flags `true`, `OwnershipControls` rule `ObjectOwnership: BucketOwnerEnforced`, the `aws:SecureTransport=false` deny statement, SSE encryption enabled, and no bucket-policy statement/ACL granting a public principal (`AllUsers`/`AuthenticatedUsers`/`*`)
    - **Property 16: Frontend bucket is private and ACL-free by construction** (declarative IaC — CDK assertion test, not PBT)
    - **Validates: Requirements 12, 13**

- [x] 7. Implement frontend runtime-config loading and auth guards
  - [x] 7.1 Harden runtime-config loading and auth error states
    - Update `src/frontend/src/api/config.ts` and `src/frontend/src/api/client.ts` (`getBaseUrl`) so a network failure, non-OK response, or malformed `/config.json` produces a visible "runtime configuration unavailable" error state, keeps the user on the page, and suppresses API calls with an undefined `apiEndpoint`; redirect unauthenticated loads to the hosted UI; on 401/403 show an error and prompt re-auth
    - _Requirements: 5.4, 5.5, 5.6_
  - [x] 7.2 Write component tests for config-unavailable and auth flows
    - File `tests/unit/frontend/config-loading.test.tsx`: config network/non-OK/malformed, unauthenticated redirect, and 401/403 re-auth prompt
    - _Requirements: 5.4, 5.5, 5.6_

- [x] 8. Implement the post-deploy smoke-check script
  - [x] 8.1 Create `scripts/smoke-check.ts`
    - Script (run via `npx tsx`) that GETs the CloudFront root → 200 `index.html`, GETs `/config.json` → 200 with `apiEndpoint` == prod invoke URL and `region` == deploy region, GETs a client-side route → 200 via SPA fallback, and reports a no-op redeploy expectation; non-zero exit on any failed check
    - _Requirements: 1.3, 1.5, 2.2, 3.4, 12.1, 12.2_

- [x] 9. Checkpoint
  - Ensure all tests pass, ask the user if questions arise.

### Workstream 2 — Evaluations, Harness, Comparison (runtime)

- [x] 10. Extend the result data model for the evaluation error state
  - [x] 10.1 Add `evaluationError` to `TestCaseResult`
    - In `src/shared/types.ts`, add the optional `evaluationError` object (`reason`, `code` ∈ `INSUFFICIENT_TRACE | TIMEOUT | AGENTCORE_ERROR | UNMAPPABLE_RESULT | MISSING_EVALUATOR`, optional `missingEvaluators`) without adding new score fields, so leaving scores unset is structurally enforced
    - _Requirements: 10.3, 8.7_

- [x] 11. Implement the trace-to-OTel translation module and property tests
  - [x] 11.1 Implement `buildOtelSession` (pure, standalone)
    - Create `src/backend/orchestration/trace-to-otel.ts` (no AWS imports) exporting `buildOtelSession(input): OtelSession` and `InsufficientTraceError`; emit one `invoke_agent`-style span/event per assistant turn (32-char `traceId`) and one `execute_tool`-style span/event per tool call (16-char `spanId`, parented to the current turn), all under one `session.id` with scope `strands.telemetry.tracer`, preserving chronological order; populate tool spans with name/args/result and attach available tools; carry `expectedToolNames` through unchanged; throw `InsufficientTraceError` when there are zero tool calls and zero assistant turns
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6_
  - [x] 11.2 Write property test: trace structure and order
    - File `tests/unit/properties/trace-to-otel.test.ts`, `{ numRuns: 100 }`, arbitrary `ExecutionTrace`/`ExecutionStep`/`ToolInvocation`
    - **Property 4: OTel translation preserves trace structure and order**
    - **Validates: Requirements 9.1, 16.3**
  - [x] 11.3 Write property test: AgentCore input-schema conformance
    - Same file as 11.2
    - **Property 5: OTel output conforms to the AgentCore input schema**
    - **Validates: Requirements 9.2, 16.2**
  - [x] 11.4 Write property test: tool spans carry name/args/result/available tools
    - Same file as 11.2
    - **Property 6: Tool spans carry tool name, arguments, result, and available tools**
    - **Validates: Requirements 9.3**
  - [x] 11.5 Write property test: expected trajectory passthrough
    - Same file as 11.2
    - **Property 7: Expected tool trajectory is passed through unchanged**
    - **Validates: Requirements 9.4**
  - [x] 11.6 Write property test: degenerate traces rejected
    - Same file as 11.2
    - **Property 8: Degenerate traces are rejected, not scored**
    - **Validates: Requirements 9.5**

- [x] 12. Implement the score mapping & aggregation module and property tests
  - [x] 12.1 Implement `clamp01`, `aggregateMean`, `aggregateScores` (pure)
    - Create `src/shared/utils/evaluation-scoring.ts`: map the session-level `Builtin.GoalSuccessRate` value to `goalSuccessScore`, reduce per-turn `Builtin.Helpfulness` and per-tool-call `Builtin.ToolSelectionAccuracy` by unweighted arithmetic mean, clamp every emitted score to `[0,1]`, and list requested-but-absent evaluators in `missingEvaluators`
    - _Requirements: 8.3, 8.4, 8.7_
  - [x] 12.2 Write property test: every emitted score in [0,1]
    - File `tests/unit/properties/evaluation-scoring.test.ts`, `{ numRuns: 100 }`, arbitrary evaluator-outcome value lists (incl. out-of-range and empty)
    - **Property 9: Every emitted score lies within [0.0, 1.0]**
    - **Validates: Requirements 8.3**
  - [x] 12.3 Write property test: goal direct + arithmetic-mean aggregation
    - Same file as 12.2
    - **Property 10: Aggregation maps goal directly and reduces per-unit results by arithmetic mean**
    - **Validates: Requirements 8.3, 8.4**
  - [x] 12.4 Write property test: missing-evaluator detection is the absent subset
    - Same file as 12.2
    - **Property 11: Missing-evaluator detection is exactly the absent subset**
    - **Validates: Requirements 8.7**

- [x] 13. Implement the evaluation result assembly mapping and property tests
  - [x] 13.1 Implement `assembleCaseEvaluation` (pure mapping)
    - Create `src/shared/utils/evaluation-result.ts` consuming `AggregatedScores` (task 12.1) + failure context and producing the `TestCaseResult` score fields or an `evaluationError` (code/reason/missingEvaluators); when an error state is produced, leave all three scores unset; never derive `toolAccuracyScore` from local `calculateToolAccuracy`
    - Depends on the `evaluationError` model (task 10.1)
    - _Requirements: 8.7, 10.2, 10.3, 10.6_
  - [x] 13.2 Write property test: error state leaves all three scores unset
    - File `tests/unit/properties/evaluation-result.test.ts`, `{ numRuns: 100 }`, arbitrary outcomes
    - **Property 12: An evaluation error state leaves all three scores unset**
    - **Validates: Requirements 10.3**
  - [x] 13.3 Write property test: tool accuracy originates only from AgentCore
    - Same file as 13.2
    - **Property 13: Tool accuracy originates only from AgentCore, never from local scoring**
    - **Validates: Requirements 10.6**

- [x] 14. Checkpoint
  - Ensure all tests pass, ask the user if questions arise.

- [x] 15. Implement the AgentCore client wrapper and SDK bundling/pinning
  - [x] 15.1 Implement the thin `AgentCoreEvaluationClient` wrapper
    - Create `src/backend/orchestration/agentcore-client.ts` wrapping `@aws-sdk/client-bedrock-agentcore` `EvaluateCommand`; expose `evaluate({ evaluatorId, sessionSpans, target?, referenceInputs?, timeoutMs })` returning raw `EvaluationResultContent[]`; wrap each call in a 60s timeout that throws a typed `EvaluationTimeoutError`; do not interpret scores
    - _Requirements: 8.2, 10.1_
  - [x] 15.2 Pin and bundle the AgentCore SDK
    - Add `@aws-sdk/client-bedrock-agentcore` to `package.json` at an exact (pinned) version and remove it from `externalModules` in `lib/orchestration-construct.ts` so it is bundled with the Evaluation Lambda, mirroring the existing `client-qconnect` bundling
    - _Requirements: 8.2_
  - [x] 15.3 Write unit tests for the wrapper and a bundling/pinning static check
    - File `tests/unit/agentcore-client.test.ts`: timeout → `EvaluationTimeoutError`, raw passthrough of results, and a static assertion that the SDK is pinned exact and absent from `externalModules`
    - _Requirements: 8.2, 10.1_

- [x] 16. Rewrite the Evaluation Lambda to compose the pure modules and client
  - [x] 16.1 Rewrite `src/backend/orchestration/evaluation.ts`
    - Remove the stub `callAgentCoreEvaluation`, `computeFallbackScores`, `formatTranscriptForEvaluation`, and all local-scoring fallback paths; per case load trace/transcript/snapshot, call `buildOtelSession`, run the three evaluators concurrently (GoalSuccessRate no target; Helpfulness on `traceIds`; ToolSelectionAccuracy on `spanIds` + `expectedTrajectory`), then `aggregateScores` + `assembleCaseEvaluation`; on `InsufficientTraceError`/timeout/error/unmappable/missing-evaluator set the `Evaluation_Error_State` with the specific reason and persist any scores produced; persist a result for every case to `PK=RUN#{runId}`, `SK=CASE#{caseId}` and never fail the run solely due to per-case error states
    - Export a reusable session-evaluation function so the harness (task 17.1) shares the exact same code path
    - _Requirements: 8.1, 8.5, 9.5, 10.1, 10.2, 10.3, 10.5, 10.6_
  - [x] 16.2 Write unit/example tests for the Lambda (mocked client + DynamoDB)
    - File `tests/unit/evaluation.test.ts`: one translation + one call per evaluator with correct targets (Req 8.1); persists to `RUN#/CASE#` (Req 8.5); timeout/error/unmappable/missing → error state with no local scoring; a mixed batch persists all cases and does not fail the run (Req 10.5)
    - _Requirements: 8.1, 8.5, 10.1, 10.2, 10.5_
  - [x] 16.3 Write a static check that the Lambda never imports local scoring
    - File `tests/unit/evaluation-no-fallback.test.ts`: assert `evaluation.ts` does not import `calculateToolAccuracy`
    - _Requirements: 10.6_

- [x] 17. Implement the local Evaluation Harness
  - [x] 17.1 Create `scripts/evaluation-harness.ts`
    - CLI taking one arg (transcript/trace file path or Q in Connect session id); file mode loads a transcript or `Span_Fixture`, session mode calls `ListSpans` + `parseSpansToTrace`; both feed the **same** translate→evaluate→aggregate→assemble path from task 16.1 and print the three scores plus per-evaluator detail; use the default AWS credential chain (no hardcoded creds); missing input/usage, unparseable file, unresolvable/empty session, missing creds, and AgentCore error/timeout/access-denied each print a clear message naming the operation and exit non-zero with no submission and no local fallback
    - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 11.6, 11.7, 11.8, 11.9, 14.2, 14.3, 14.4, 14.5_
  - [x] 17.2 Write unit tests for the harness
    - File `tests/unit/evaluation-harness.test.ts`: arg resolver (file vs session id), no-arg usage, missing/garbage file, empty `ListSpans`, missing creds, and access-denied paths each exit non-zero without submission/fallback; harness and Lambda import the same modules
    - _Requirements: 11.4, 11.5, 11.7, 11.8, 11.9, 14.4, 14.5_

- [x] 18. Checkpoint
  - Ensure all tests pass, ask the user if questions arise.

- [x] 19. Add real Span_Fixtures and fixture validation tests
  - [x] 19.1 Author at least two redacted `Span_Fixtures`
    - Create `tests/fixtures/spans/` files conforming to the `SpanFixture` shape (`rawSpans`, `sessionId`, `expectedToolSequence`, `availableTools`, `expectedToolNames`) for a `multi-tool-success` and a `failure-escalation` session, with all sensitive customer data (phone, SSN-last-four, names) replaced by non-production placeholders
    - _Requirements: 16.1, 16.5_
  - [x] 19.2 Write the fixture conformance test (Properties 4 & 5 on real data)
    - File `tests/unit/trace-to-otel.fixtures.test.ts`: run `buildOtelSession` against each fixture and assert schema conformance, required fields, supported scope, span/event pairing, and per-turn/per-tool counts with order preserved
    - **Reuses Property 4 and Property 5 against each checked-in `Span_Fixture`**
    - _Requirements: 16.2, 16.3_
  - [x] 19.3 Write the fixture redaction guard test
    - File `tests/unit/fixtures-redaction.test.ts`: scan every checked-in fixture for forbidden patterns (real phone numbers, SSN fragments) and assert placeholders are used
    - _Requirements: 16.5_

- [x] 20. Implement score-aware run comparison and wire the frontend
  - [x] 20.1 Implement `compareScores` (pure helper)
    - Create `src/shared/utils/score-comparison.ts` (extending the existing `run-comparison.ts` pattern): for each case in both runs and each metric, `delta = later − earlier` classified `improved`/`regressed`/`unchanged` by sign, `not-comparable` when a metric is present in only one run (including an `Evaluation_Error_State` case), plus a per-metric suite summary
    - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.6_
  - [x] 20.2 Write property test: delta classification + not-comparable on absence
    - File `tests/unit/properties/score-comparison.test.ts`, `{ numRuns: 100 }`, arbitrary `TestCaseResult[]` pairs
    - **Property 14: Score-delta classification is sign-consistent and not-comparable on absence**
    - **Validates: Requirements 15.1, 15.2, 15.3**
  - [x] 20.3 Write property test: per-metric summary counts are exhaustive
    - Same file as 20.2
    - **Property 15: Per-metric comparison summary counts are exhaustive**
    - **Validates: Requirements 15.4**
  - [x] 20.4 Wire `compareScores` into `Comparison.tsx`
    - Update `src/frontend/src/pages/Comparison.tsx` to consume `compareScores` alongside `compareRuns`, rendering per-metric deltas and the suite-level summary with the three classifications visually distinguished (color/icon) and `not-comparable` shown explicitly
    - _Requirements: 15.2, 15.4_
  - [x] 20.5 Update `ResultsViewer.tsx` to show scores or the error reason
    - Update `src/frontend/src/pages/ResultsViewer.tsx` to render `goalSuccessScore`/`helpfulnessScore`/`toolAccuracyScore` for scored cases and the recorded `evaluationError.reason` in place of scores for error-state cases, replacing the current "Fallback" badge heuristic
    - _Requirements: 8.6, 10.4, 15.5_
  - [x] 20.6 Write component tests for results and comparison rendering
    - File `tests/unit/frontend/results-comparison.test.tsx`: results view renders three scores or the error reason; comparison view distinguishes improved/regressed/unchanged/not-comparable and shows summary counts
    - _Requirements: 8.6, 10.4, 15.2, 15.5_

- [~] 21. Final checkpoint
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional test sub-tasks and can be skipped for a faster MVP; core implementation tasks are never optional.
- The two top-level workstreams share no code and can be implemented and reviewed independently (per the design's "Two Independent Workstreams").
- Pure logic (Reqs 9.6, 15.6) is built and property-tested before any deploy-dependent code, so it is verifiable without a CDK deploy.
- Each correctness property is implemented by a single property-based test (Properties 1–15), tagged `// Feature: platform-hosting-and-evaluations, Property {n}: {text}` and run at `{ numRuns: 100 }`. Property 16 is a CDK `assertions` template test.
- Property tests are co-located with the module they validate to catch errors early; Span_Fixture tests (task 19) re-run Properties 4 and 5 against genuine captured data.
- Hosting/bootstrap/idempotency are declarative IaC verified by CDK `assertions` template tests, not PBT.

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1", "1.3", "1.5", "10.1", "11.1", "12.1", "15.1", "15.2", "20.1", "7.1", "8.1", "19.1"] },
    { "id": 1, "tasks": ["1.2", "1.4", "1.6", "2.1", "3.1", "11.2", "12.2", "13.1", "20.2", "15.3", "7.2", "19.2", "19.3", "20.4", "20.5"] },
    { "id": 2, "tasks": ["3.2", "4.1", "11.3", "12.3", "13.2", "16.1", "20.3", "20.6"] },
    { "id": 3, "tasks": ["6.1", "6.2", "11.4", "12.4", "13.3", "16.2", "16.3", "17.1"] },
    { "id": 4, "tasks": ["11.5", "17.2"] },
    { "id": 5, "tasks": ["11.6"] }
  ]
}
```
