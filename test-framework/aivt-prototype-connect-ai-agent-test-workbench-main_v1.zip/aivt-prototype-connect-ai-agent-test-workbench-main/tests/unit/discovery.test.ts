/**
 * Unit tests for Discovery Lambda handler.
 *
 * Tests the GET /agents and GET /agents/{agentId} endpoints,
 * including ORCHESTRATION filtering, error handling, and retry guidance.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { QConnectClient } from "@aws-sdk/client-qconnect";
import {
  handler,
  listAgents,
  getAgentDetail,
  _setQConnectClient,
} from "../../src/backend/handlers/discovery";

// ---------------------------------------------------------------------------
// Mock setup
// ---------------------------------------------------------------------------

function createMockQConnectClient(sendFn: (command: unknown) => Promise<unknown>) {
  return { send: sendFn } as unknown as QConnectClient;
}

/**
 * Helper that wraps a primary `mockSend` (handles GetAIAgent / ListAIAgents)
 * and adds a synthetic GetAIPromptCommand response so getAgentDetail's
 * follow-up prompt-resolution call doesn't blow up the test. Tests that
 * specifically want to exercise the GetAIPrompt failure path should pass
 * `promptResponse: "throw"` to make the second call reject.
 *
 * Detection is by command class name (`constructor.name`) so we don't need
 * to import GetAIPromptCommand into the test file.
 */
function withPromptMock(
  primarySend: (command: unknown) => Promise<unknown>,
  promptResponse:
    | { text: string; modelId?: string }
    | "throw"
    | "empty" = { text: "Resolved prompt body", modelId: "us.anthropic.claude-3-haiku-20240307-v1:0" },
): (command: unknown) => Promise<unknown> {
  return async (command: unknown) => {
    const ctorName = (command as { constructor?: { name?: string } })
      ?.constructor?.name;
    if (ctorName === "GetAIPromptCommand") {
      if (promptResponse === "throw") {
        throw new Error("simulated GetAIPrompt failure");
      }
      if (promptResponse === "empty") {
        return { aiPrompt: undefined };
      }
      return {
        aiPrompt: {
          aiPromptId: "prompt-id",
          modelId: promptResponse.modelId,
          templateConfiguration: {
            textFullAIPromptEditTemplateConfiguration: {
              text: promptResponse.text,
            },
          },
        },
      };
    }
    return primarySend(command);
  };
}

// Save and restore env
const originalEnv = { ...process.env };

beforeEach(() => {
  process.env.ASSISTANT_ID = "test-assistant-id";
  process.env.AWS_REGION = "us-east-1";
});

afterEach(() => {
  _setQConnectClient(null);
  process.env = { ...originalEnv };
});

// ---------------------------------------------------------------------------
// Helper data
// ---------------------------------------------------------------------------

function makeOrchestrationAgent(id: string, name: string, toolCount: number) {
  const toolConfigurations = Array.from({ length: toolCount }, (_, i) => ({
    toolName: `tool-${i}`,
    toolType: "LAMBDA",
    description: `Tool ${i} description`,
    instruction: { instruction: `Use tool ${i} when...` },
    inputSchema: { type: "object", properties: { param: { type: "string" } } },
  }));

  return {
    aiAgentId: id,
    name,
    type: "ORCHESTRATION",
    assistantId: "test-assistant-id",
    assistantArn: "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
    aiAgentArn: `arn:aws:qconnect:us-east-1:123456789012:ai-agent/${id}`,
    visibilityStatus: "PUBLISHED",
    configuration: {
      orchestrationAIAgentConfiguration: {
        orchestrationAIPromptId: "prompt-123",
        toolConfigurations,
      },
    },
  };
}

function makeSelfServiceAgent(id: string, name: string) {
  return {
    aiAgentId: id,
    name,
    type: "SELF_SERVICE",
    assistantId: "test-assistant-id",
    assistantArn: "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
    aiAgentArn: `arn:aws:qconnect:us-east-1:123456789012:ai-agent/${id}`,
    visibilityStatus: "PUBLISHED",
    configuration: {
      selfServiceAIAgentConfiguration: {
        selfServicePreProcessingAIPromptId: "prompt-456",
      },
    },
  };
}

function makeAnswerRecommendationAgent(id: string, name: string) {
  return {
    aiAgentId: id,
    name,
    type: "ANSWER_RECOMMENDATION",
    assistantId: "test-assistant-id",
    assistantArn: "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
    aiAgentArn: `arn:aws:qconnect:us-east-1:123456789012:ai-agent/${id}`,
    visibilityStatus: "PUBLISHED",
    configuration: {
      answerRecommendationAIAgentConfiguration: {
        answerGenerationAIPromptId: "prompt-789",
      },
    },
  };
}

// ---------------------------------------------------------------------------
// Tests: GET /agents (list)
// ---------------------------------------------------------------------------

describe("Discovery Lambda - GET /agents", () => {
  it("returns only ORCHESTRATION agents from a mixed list", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgentSummaries: [
        makeOrchestrationAgent("agent-1", "Booking Agent", 3),
        makeSelfServiceAgent("agent-2", "Self Service Bot"),
        makeOrchestrationAgent("agent-3", "Support Agent", 1),
        makeAnswerRecommendationAgent("agent-4", "Recommender"),
      ],
      nextToken: undefined,
    });

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body);
    expect(body.agents).toHaveLength(2);
    expect(body.agents[0]).toEqual({
      agentId: "agent-1",
      name: "Booking Agent",
      type: "ORCHESTRATION",
      toolCount: 3,
      modelId: "prompt-123",
    });
    expect(body.agents[1]).toEqual({
      agentId: "agent-3",
      name: "Support Agent",
      type: "ORCHESTRATION",
      toolCount: 1,
      modelId: "prompt-123",
    });
  });

  it("handles pagination across multiple pages", async () => {
    let callCount = 0;
    const mockSend = vi.fn().mockImplementation(() => {
      callCount++;
      if (callCount === 1) {
        return Promise.resolve({
          aiAgentSummaries: [makeOrchestrationAgent("agent-1", "Agent 1", 2)],
          nextToken: "page-2-token",
        });
      }
      return Promise.resolve({
        aiAgentSummaries: [makeOrchestrationAgent("agent-2", "Agent 2", 4)],
        nextToken: undefined,
      });
    });

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body);
    expect(body.agents).toHaveLength(2);
    expect(body.agents[0].agentId).toBe("agent-1");
    expect(body.agents[1].agentId).toBe("agent-2");
    expect(mockSend).toHaveBeenCalledTimes(2);
  });

  it("returns empty array when no orchestration agents exist", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgentSummaries: [
        makeSelfServiceAgent("agent-1", "Self Service Bot"),
      ],
      nextToken: undefined,
    });

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body);
    expect(body.agents).toEqual([]);
  });

  it("returns empty array when no agents exist at all", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgentSummaries: [],
      nextToken: undefined,
    });

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body);
    expect(body.agents).toEqual([]);
  });
});

// ---------------------------------------------------------------------------
// Tests: GET /agents/{agentId} (detail)
// ---------------------------------------------------------------------------

describe("Discovery Lambda - GET /agents/{agentId}", () => {
  it("returns full agent detail with tools for an orchestration agent", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgent: {
        aiAgentId: "agent-1",
        name: "Booking Agent",
        type: "ORCHESTRATION",
        assistantId: "test-assistant-id",
        assistantArn: "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
        aiAgentArn: "arn:aws:qconnect:us-east-1:123456789012:ai-agent/agent-1",
        visibilityStatus: "PUBLISHED",
        configuration: {
          orchestrationAIAgentConfiguration: {
            orchestrationAIPromptId: "prompt-model-id",
            toolConfigurations: [
              {
                toolName: "SearchFlights",
                toolType: "LAMBDA",
                description: "Search for available flights",
                instruction: { instruction: "Use when customer wants to find flights" },
                inputSchema: {
                  type: "object",
                  properties: {
                    origin: { type: "string" },
                    destination: { type: "string" },
                  },
                },
              },
              {
                toolName: "BookFlight",
                toolType: "LAMBDA",
                description: "Book a specific flight",
                inputSchema: {
                  type: "object",
                  properties: {
                    flightId: { type: "string" },
                  },
                },
              },
            ],
          },
        },
      },
    });

    _setQConnectClient(
      createMockQConnectClient(
        withPromptMock(mockSend, {
          text: "Resolved prompt body for booking agent",
          modelId: "us.anthropic.claude-3-5-haiku-20241022-v1:0",
        }),
      ),
    );

    const result = await handler({
      httpMethod: "GET",
      pathParameters: { agentId: "agent-1" },
    });

    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body);
    expect(body.agentId).toBe("agent-1");
    expect(body.name).toBe("Booking Agent");
    expect(body.type).toBe("ORCHESTRATION");
    expect(body.systemPrompt).toBe("Resolved prompt body for booking agent");
    expect(body.modelId).toBe("us.anthropic.claude-3-5-haiku-20241022-v1:0");
    expect(body.tools).toHaveLength(2);
    expect(body.tools[0]).toEqual({
      toolName: "SearchFlights",
      toolType: "LAMBDA",
      description: "Search for available flights",
      instruction: "Use when customer wants to find flights",
      inputSchema: {
        type: "object",
        properties: {
          origin: { type: "string" },
          destination: { type: "string" },
        },
      },
      examples: [],
    });
    expect(body.tools[1]).toEqual({
      toolName: "BookFlight",
      toolType: "LAMBDA",
      description: "Book a specific flight",
      inputSchema: {
        type: "object",
        properties: {
          flightId: { type: "string" },
        },
      },
      examples: [],
    });
  });

  it("returns 404 for a non-ORCHESTRATION agent", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgent: {
        aiAgentId: "agent-2",
        name: "Self Service Bot",
        type: "SELF_SERVICE",
        assistantId: "test-assistant-id",
        assistantArn: "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
        aiAgentArn: "arn:aws:qconnect:us-east-1:123456789012:ai-agent/agent-2",
        visibilityStatus: "PUBLISHED",
        configuration: {
          selfServiceAIAgentConfiguration: {},
        },
      },
    });

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({
      httpMethod: "GET",
      pathParameters: { agentId: "agent-2" },
    });

    expect(result.statusCode).toBe(404);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("AgentNotFound");
  });

  it("handles tool without instruction gracefully", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgent: {
        aiAgentId: "agent-1",
        name: "Simple Agent",
        type: "ORCHESTRATION",
        assistantId: "test-assistant-id",
        assistantArn: "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
        aiAgentArn: "arn:aws:qconnect:us-east-1:123456789012:ai-agent/agent-1",
        visibilityStatus: "PUBLISHED",
        configuration: {
          orchestrationAIAgentConfiguration: {
            orchestrationAIPromptId: "prompt-id",
            toolConfigurations: [
              {
                toolName: "SimpleTool",
                toolType: "KNOWLEDGE_BASE",
                description: "A simple tool",
                inputSchema: { type: "object" },
              },
            ],
          },
        },
      },
    });

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const result = await handler({
      httpMethod: "GET",
      pathParameters: { agentId: "agent-1" },
    });

    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body);
    expect(body.tools[0]).toEqual({
      toolName: "SimpleTool",
      toolType: "KNOWLEDGE_BASE",
      description: "A simple tool",
      inputSchema: { type: "object" },
      examples: [],
    });
    // instruction should not be present
    expect(body.tools[0].instruction).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// Tests: Error handling
// ---------------------------------------------------------------------------

describe("Discovery Lambda - Error handling", () => {
  it("returns 429 with retry guidance on ThrottlingException", async () => {
    const error = new Error("Rate exceeded");
    (error as { name: string }).name = "ThrottlingException";
    const mockSend = vi.fn().mockRejectedValue(error);

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(429);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("ThrottlingException");
    expect(body.retryable).toBe(true);
    expect(body.retryAfterSeconds).toBe(5);
  });

  it("returns 403 on AccessDeniedException", async () => {
    const error = new Error("Access denied");
    (error as { name: string }).name = "AccessDeniedException";
    const mockSend = vi.fn().mockRejectedValue(error);

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(403);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("AccessDenied");
    expect(body.retryable).toBe(false);
  });

  it("returns 404 on ResourceNotFoundException", async () => {
    const error = new Error("Not found");
    (error as { name: string }).name = "ResourceNotFoundException";
    const mockSend = vi.fn().mockRejectedValue(error);

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({
      httpMethod: "GET",
      pathParameters: { agentId: "nonexistent" },
    });

    expect(result.statusCode).toBe(404);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("ResourceNotFound");
  });

  it("returns 400 on ValidationException", async () => {
    const error = new Error("Invalid parameter");
    (error as { name: string }).name = "ValidationException";
    const mockSend = vi.fn().mockRejectedValue(error);

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(400);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("ValidationError");
  });

  it("returns 500 with retryable on unknown errors", async () => {
    const mockSend = vi.fn().mockRejectedValue(new Error("Something broke"));

    _setQConnectClient(createMockQConnectClient(mockSend));

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("InternalError");
    expect(body.retryable).toBe(true);
    expect(body.retryAfterSeconds).toBe(2);
  });

  it("returns 405 for non-GET methods", async () => {
    const result = await handler({ httpMethod: "POST" });

    expect(result.statusCode).toBe(405);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("MethodNotAllowed");
  });

  it("returns 500 when ASSISTANT_ID is not configured", async () => {
    process.env.ASSISTANT_ID = "";

    const result = await handler({ httpMethod: "GET" });

    expect(result.statusCode).toBe(500);
    const body = JSON.parse(result.body);
    expect(body.error).toBe("ConfigurationError");
  });
});

// ---------------------------------------------------------------------------
// Tests: listAgents function directly
// ---------------------------------------------------------------------------

describe("listAgents", () => {
  it("filters and maps agents correctly", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgentSummaries: [
        makeOrchestrationAgent("orch-1", "My Agent", 5),
        makeSelfServiceAgent("self-1", "SS Agent"),
      ],
      nextToken: undefined,
    });

    _setQConnectClient(createMockQConnectClient(mockSend));

    const agents = await listAgents();

    expect(agents).toHaveLength(1);
    expect(agents[0].agentId).toBe("orch-1");
    expect(agents[0].toolCount).toBe(5);
    expect(agents[0].type).toBe("ORCHESTRATION");
  });
});

// ---------------------------------------------------------------------------
// Tests: getAgentDetail function directly
// ---------------------------------------------------------------------------

describe("getAgentDetail", () => {
  it("returns null when agent is not found", async () => {
    const mockSend = vi.fn().mockResolvedValue({ aiAgent: undefined });

    _setQConnectClient(createMockQConnectClient(mockSend));

    const detail = await getAgentDetail("missing-agent");
    expect(detail).toBeNull();
  });

  it("returns null for non-orchestration agent", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgent: {
        aiAgentId: "agent-x",
        name: "Not Orchestration",
        type: "MANUAL_SEARCH",
        assistantId: "test-assistant-id",
        assistantArn: "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
        aiAgentArn: "arn:aws:qconnect:us-east-1:123456789012:ai-agent/agent-x",
        visibilityStatus: "PUBLISHED",
        configuration: {
          manualSearchAIAgentConfiguration: {},
        },
      },
    });

    _setQConnectClient(createMockQConnectClient(mockSend));

    const detail = await getAgentDetail("agent-x");
    expect(detail).toBeNull();
  });

  it("handles agent with no tools", async () => {
    const mockSend = vi.fn().mockResolvedValue({
      aiAgent: {
        aiAgentId: "agent-empty",
        name: "Empty Agent",
        type: "ORCHESTRATION",
        assistantId: "test-assistant-id",
        assistantArn: "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
        aiAgentArn: "arn:aws:qconnect:us-east-1:123456789012:ai-agent/agent-empty",
        visibilityStatus: "PUBLISHED",
        configuration: {
          orchestrationAIAgentConfiguration: {
            orchestrationAIPromptId: "prompt-empty",
          },
        },
      },
    });

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const detail = await getAgentDetail("agent-empty");
    expect(detail).not.toBeNull();
    expect(detail!.tools).toEqual([]);
    expect(detail!.agentId).toBe("agent-empty");
  });
});

// ---------------------------------------------------------------------------
// Tests: getAgentDetail tool examples mapping (Task 12.1)
//
// Validates the `examples` mapping rule from `getAgentDetail`'s
// `toolConfigurations[]` mapper:
//   - present array → preserved verbatim (order, whitespace, newlines, quotes)
//   - null / undefined / non-array → mapped to []
//   - field is ALWAYS present on every tool in the response (R1.5)
//
// _Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5_
// ---------------------------------------------------------------------------

/**
 * Builds an orchestration `aiAgent` envelope whose tool list is exactly the
 * caller-provided array. Lets each test pin the upstream `examples` value
 * (array, null, undefined, or a non-array primitive) without having to repeat
 * the full envelope for every case.
 */
function makeOrchestrationDetailWithTools(
  agentId: string,
  toolConfigurations: unknown[],
) {
  return {
    aiAgent: {
      aiAgentId: agentId,
      name: `Agent ${agentId}`,
      type: "ORCHESTRATION",
      assistantId: "test-assistant-id",
      assistantArn:
        "arn:aws:qconnect:us-east-1:123456789012:assistant/test-assistant-id",
      aiAgentArn: `arn:aws:qconnect:us-east-1:123456789012:ai-agent/${agentId}`,
      visibilityStatus: "PUBLISHED",
      configuration: {
        orchestrationAIAgentConfiguration: {
          orchestrationAIPromptId: "prompt-id",
          toolConfigurations,
        },
      },
    },
  };
}

describe("getAgentDetail - tool examples mapping", () => {
  it("preserves a present examples array verbatim including order", async () => {
    const upstream = [
      "What's my balance?",
      "How much do I have in checking?",
      "Tell me my account total",
    ];

    const mockSend = vi
      .fn()
      .mockResolvedValue(
        makeOrchestrationDetailWithTools("agent-present", [
          {
            toolName: "GetBalance",
            toolType: "LAMBDA",
            description: "Returns account balance",
            instruction: { instruction: "After identity verification" },
            inputSchema: { type: "object" },
            examples: upstream,
          },
        ]),
      );

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const detail = await getAgentDetail("agent-present");

    expect(detail).not.toBeNull();
    expect(detail!.tools).toHaveLength(1);
    expect(detail!.tools[0].examples).toEqual(upstream);
    // Order is preserved verbatim — assert element-by-element to make a
    // future-introduced sort or dedupe regression louder than a deep-equal
    // mismatch.
    expect(detail!.tools[0].examples[0]).toBe("What's my balance?");
    expect(detail!.tools[0].examples[1]).toBe("How much do I have in checking?");
    expect(detail!.tools[0].examples[2]).toBe("Tell me my account total");
  });

  it("maps null examples to an empty array (never omits the field)", async () => {
    const mockSend = vi
      .fn()
      .mockResolvedValue(
        makeOrchestrationDetailWithTools("agent-null", [
          {
            toolName: "ToolWithNullExamples",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            examples: null,
          },
        ]),
      );

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const detail = await getAgentDetail("agent-null");

    expect(detail).not.toBeNull();
    expect(detail!.tools[0]).toHaveProperty("examples");
    expect(detail!.tools[0].examples).toEqual([]);
  });

  it("maps undefined examples to an empty array (never omits the field)", async () => {
    const mockSend = vi
      .fn()
      .mockResolvedValue(
        makeOrchestrationDetailWithTools("agent-undef", [
          {
            toolName: "ToolWithUndefinedExamples",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            // examples deliberately omitted (== undefined)
          },
        ]),
      );

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const detail = await getAgentDetail("agent-undef");

    expect(detail).not.toBeNull();
    expect(detail!.tools[0]).toHaveProperty("examples");
    expect(detail!.tools[0].examples).toEqual([]);
  });

  it("maps a non-array (number) examples value to an empty array", async () => {
    const mockSend = vi
      .fn()
      .mockResolvedValue(
        makeOrchestrationDetailWithTools("agent-nonarray", [
          {
            toolName: "ToolWithNonArrayExamples",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            examples: 42 as unknown as string[],
          },
        ]),
      );

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const detail = await getAgentDetail("agent-nonarray");

    expect(detail).not.toBeNull();
    expect(detail!.tools[0]).toHaveProperty("examples");
    expect(detail!.tools[0].examples).toEqual([]);
  });

  it("preserves whitespace, embedded newlines, and quote characters verbatim (no trim, no normalization)", async () => {
    const upstream = ["", "  ", "line\nbreak", '"quoted"'];

    const mockSend = vi
      .fn()
      .mockResolvedValue(
        makeOrchestrationDetailWithTools("agent-verbatim", [
          {
            toolName: "ToolWithEdgeCaseExamples",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            examples: upstream,
          },
        ]),
      );

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const detail = await getAgentDetail("agent-verbatim");

    expect(detail).not.toBeNull();
    expect(detail!.tools[0].examples).toEqual(upstream);
    // Element-wise checks make a future trim/normalize regression unmissable.
    expect(detail!.tools[0].examples[0]).toBe("");
    expect(detail!.tools[0].examples[1]).toBe("  ");
    expect(detail!.tools[0].examples[2]).toBe("line\nbreak");
    expect(detail!.tools[0].examples[3]).toBe('"quoted"');
  });

  it("returns the examples field on every tool even when tools mix present, missing, and malformed examples (R1.5)", async () => {
    // Cover all four input shapes in one response so the assertion that
    // `examples` is always present holds across heterogeneous tool lists.
    const mockSend = vi
      .fn()
      .mockResolvedValue(
        makeOrchestrationDetailWithTools("agent-mixed", [
          {
            toolName: "ToolPresent",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            examples: ["one", "two"],
          },
          {
            toolName: "ToolNull",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            examples: null,
          },
          {
            toolName: "ToolMissing",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            // examples deliberately omitted
          },
          {
            toolName: "ToolNonArray",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            examples: "a string is not an array" as unknown as string[],
          },
        ]),
      );

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const detail = await getAgentDetail("agent-mixed");

    expect(detail).not.toBeNull();
    expect(detail!.tools).toHaveLength(4);
    for (const tool of detail!.tools) {
      // Every tool MUST carry the field — R1.5 — never omitted.
      expect(tool).toHaveProperty("examples");
      expect(Array.isArray(tool.examples)).toBe(true);
    }
    expect(detail!.tools[0].examples).toEqual(["one", "two"]);
    expect(detail!.tools[1].examples).toEqual([]);
    expect(detail!.tools[2].examples).toEqual([]);
    expect(detail!.tools[3].examples).toEqual([]);
  });

  it("does not alias the upstream array (mutating the upstream after mapping leaves the response unchanged)", async () => {
    // The mapping spreads into a fresh array; this test pins that contract so
    // a future refactor can't silently swap to a reference assignment.
    const upstream = ["alpha", "beta"];

    const mockSend = vi
      .fn()
      .mockResolvedValue(
        makeOrchestrationDetailWithTools("agent-noalias", [
          {
            toolName: "ToolNoAlias",
            toolType: "LAMBDA",
            description: "desc",
            inputSchema: { type: "object" },
            examples: upstream,
          },
        ]),
      );

    _setQConnectClient(createMockQConnectClient(withPromptMock(mockSend)));

    const detail = await getAgentDetail("agent-noalias");

    // Mutate the upstream after the response has been built.
    upstream.push("mutated-after-mapping");

    expect(detail!.tools[0].examples).toEqual(["alpha", "beta"]);
    expect(detail!.tools[0].examples).not.toContain("mutated-after-mapping");
  });
});
