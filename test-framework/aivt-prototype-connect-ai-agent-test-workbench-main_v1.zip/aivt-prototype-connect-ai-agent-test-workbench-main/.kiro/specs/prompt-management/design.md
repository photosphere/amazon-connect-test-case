# Design Document

## Overview

The prompt-management feature centralizes every internal Bedrock prompt the platform invokes — thirteen prompt keys spanning suite/case scaffolding, failure analysis, suite recommendation, comparison summary, tournament summary, variant generation, customer simulation, four AgentCore-template judges, and the RAG evaluation job — into one in-code registry, one DynamoDB-backed override store, one HTTP API, and one Cloudscape-rendered Prompts page. Every existing Bedrock callsite that is not the agent-under-test is migrated to resolve its prompt text and model exclusively through that registry, so an edit propagates to the next invocation without a redeploy. Mid-edit safety comes from extending the existing run-start snapshot to pin the resolved prompt set per run; in-flight runs always read from the snapshot, never the live store.

The model dropdown exposes exactly the six models the user pinned: Claude Sonnet 4.6, Claude Haiku 4.5, Claude Opus 4.8, and Amazon Nova Lite / Pro / Premier. Per-model parameter shapes are encoded as one of two **Model_Capability_Profile** values (`anthropic_claude_4x` accepts only `maxTokens`; `amazon_nova` accepts the full Converse parameter set with `topK` placed under `additionalModelRequestFields.inferenceConfig.topK`). Real-Bedrock **Conformance_Probes** validate those assumptions against the live API and gate the release; the build refuses to ship a model whose positive or negative probe fails.

IAM grants are derived deterministically at CDK synth time from the registry's `allowedModels[]` and each model's `Routing_Region_Set` via a shared helper, replacing the seven hand-maintained Bedrock IAM blocks across `lib/api-construct.ts` and `lib/orchestration-construct.ts`. A CDK assertion test pins each Lambda's grant to the exact union of inference-profile + routing-region foundation-model ARNs — wider or narrower fails the build.

## Architecture

### High-Level Component Diagram

```
┌────────────────────────────────────────────────────────────────────────────┐
│                           Browser (Cloudscape)                             │
│                                                                            │
│   Sidebar ───► /prompts ──► PromptsListPage                                │
│                              └─► /prompts/{promptKey} ──► PromptDetailPage │
│                                          ├─ ModelSelector (capability-aware)│
│                                          ├─ HistoryPanel                   │
│                                          ├─ RevertConfirmModal             │
│                                          └─ ActiveRunsFlashbar             │
└────────────────────────────────┬───────────────────────────────────────────┘
                                 │ (Cognito access token, scope test-platform/run)
                                 ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                        API Gateway + Cognito Authorizer                    │
│                                                                            │
│   GET    /prompts                        ┐                                 │
│   GET    /prompts/{promptKey}            │                                 │
│   PUT    /prompts/{promptKey}            ├──► Prompts Lambda               │
│   POST   /prompts/{promptKey}/reset      │                                 │
│   GET    /prompts/{promptKey}/history    │                                 │
│   GET    /prompts/active-runs            ┘                                 │
└────────────────────────────────┬───────────────────────────────────────────┘
                                 │
                                 ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                              Prompts Lambda                                │
│                                                                            │
│  ┌─────────────────┐    ┌──────────────────┐    ┌────────────────────────┐ │
│  │ Prompt_Registry │◄──►│ Prompt_Resolver  │    │ Validation pipeline    │ │
│  │  (in-code)      │    │  (pure fn)       │    │  - placeholder schema  │ │
│  │  - 13 promptKeys│    │                  │    │  - size cap            │ │
│  │  - Supported_   │    │                  │    │  - allowedModels       │ │
│  │    Models (×6)  │    │                  │    │  - Model_Capability    │ │
│  │  - Capability   │    │                  │    │  - dry-render          │ │
│  │    Profiles (×2)│    │                  │    └────────────┬───────────┘ │
│  └─────────────────┘    └──────────────────┘                 │             │
│                                  │                           ▼             │
│                                  │                   ┌────────────────┐    │
│                                  │                   │ Audit_Log write│    │
│                                  │                   │ (best-effort)  │    │
│                                  │                   └────────────────┘    │
└──────────────────────────────────┼─────────────────────────────────────────┘
                                   │
                                   ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                     DynamoDB ConnectAgentTestPlatform                      │
│                                                                            │
│  PK=PROMPT#{promptKey}  SK=OVERRIDE              ◄── current override      │
│  PK=PROMPT#{promptKey}  SK=HISTORY#{paddedVer}   ◄── ≤10 prior versions    │
│  PK=RUN#{runId}         SK=SNAPSHOT              ◄── extended with prompts │
│  PK=TENANT#{tenantId}   SK=AUDIT#{ts}            ◄── prompt_edit/reset     │
│                                                                            │
└────────────────────────────────────────────────────────────────────────────┘
                                   ▲
                                   │ (read at every Bedrock call site)
                                   │
┌────────────────────────────────────────────────────────────────────────────┐
│                          Bedrock_Callsites                                 │
│                                                                            │
│  In-run path  (Lambda inside a Step Functions execution):                  │
│    callsite ──► Run_Snapshot.prompts[promptKey] ──► Bedrock Converse       │
│                                                                            │
│  Out-of-run path  (interactive endpoint, e.g. POST /scaffold):             │
│    callsite ──► Prompt_Resolver(live Prompts_Store) ──► Bedrock Converse   │
│                                                                            │
│  All callsites consult Model_Capability_Profile to shape inferenceConfig.  │
│  Fail-closed if neither path can resolve the prompt.                       │
└────────────────────────────────────────────────────────────────────────────┘
```

### Top-Level Control Flows

Three control flows fall out of this picture:

- **Edit path.** Browser submits `PUT /prompts/{promptKey}` → Prompts Lambda runs the validation pipeline (placeholder schema, size cap, allowedModels membership, capability-profile compliance, dry-render of the resulting Converse `inferenceConfig`) → on success writes the new override and the prior version's history entry in a single transaction → fires a best-effort `prompt_edit` audit record. No in-flight run is touched; subsequent runs pick up the change at their own snapshot capture.
- **Run-start capture.** PrepareRun Lambda calls `Prompt_Resolver` once per `promptKey` the run will consume, packs the resolved `(text, modelId, inferenceParameters)` triples into a new `prompts` map, and writes them as part of the existing `AgentSnapshot` record. The map is the run's pinned prompt set for the rest of its lifetime.
- **Callsite invocation.** Every existing Converse / `CreateEvaluationJob` callsite resolves `(text, modelId, inferenceParameters)` from the snapshot when it has a `runId` in scope and from the live `Prompt_Resolver` otherwise, then constructs the Converse request via a per-profile `buildInferenceConfig` helper so `topP` / `topK` / `temperature` only appear where the resolved model accepts them. Failure to resolve from both paths aborts the call with a structured error rather than substituting an empty prompt or a stale cached value.

### Strictly-Additive Posture

The whole feature is a strict superset of the existing platform — no API endpoints are removed, no Lambda is renamed, no run record schema changes shape (the `prompts` field is additive), and the `*_MODEL_ID` environment variables stay set so a partial-deploy state always has a working fallback. Cutover happens callsite-by-callsite, gated by the conformance-probe build invariant.

## Components and Interfaces

### Prompt_Registry (in-code single source of truth)

The registry lives at `src/backend/orchestration/prompt-registry/` and exports the canonical declaration of every prompt the platform recognises plus the catalog of supported models. The directory is organised so each prompt's bundled default text is a sibling file the registry imports at build time — keeping multi-thousand-character templates out of the index and giving each one a clean diff surface.

```
src/backend/orchestration/prompt-registry/
├── index.ts                    // public surface: registry, resolver, capability-profile API
├── types.ts                    // PromptDefinition, SupportedModel, ModelCapabilityProfile, …
├── prompts/
│   ├── suite-scaffold.ts       // default text + placeholders + allowedModels for one promptKey
│   ├── case-scaffold.ts
│   ├── failure-analysis.ts
│   ├── suite-recommendation.ts
│   ├── comparison-summary.ts
│   ├── tournament-summary.ts
│   ├── variant-generation.ts
│   ├── customer-simulator.ts
│   ├── judge-goal-success-rate.ts
│   ├── judge-helpfulness.ts
│   ├── judge-tool-selection.ts
│   ├── judge-opportunistic-faithfulness.ts
│   └── rag-evaluation-job.ts
├── supported-models.ts         // the six-entry Supported_Models catalog (Section 3)
├── capability-profiles.ts      // anthropic_claude_4x, amazon_nova (Section 3)
└── resolver.ts                 // pure Prompt_Resolver function
```

The four AgentCore-template judge prompts in `prompts/judge-*.ts` re-export the verbatim string constants already living in `src/backend/orchestration/judge-prompt-templates.ts` so the byte-for-byte copy from the AWS docs (and the steering doc that records the source URL plus copy date) stays exactly where it is — the judge templates module becomes the registry's source for those four `defaultText` values rather than being duplicated.

### Type signatures

Defined in `prompt-registry/types.ts`:

```ts
/** Stable machine identifiers for every promptKey the platform recognises. */
export type PromptKey =
  | "suite_scaffold"
  | "case_scaffold"
  | "failure_analysis"
  | "suite_recommendation"
  | "comparison_summary"
  | "tournament_summary"
  | "variant_generation"
  | "customer_simulator"
  | "judge_goal_success_rate"
  | "judge_helpfulness"
  | "judge_tool_selection"
  | "judge_opportunistic_faithfulness"
  | "rag_evaluation_job";

/** Stable machine identifiers for every model in the dropdown. */
export type ModelKey =
  | "claude_sonnet_4_6"
  | "claude_haiku_4_5"
  | "claude_opus_4_8"
  | "nova_lite"
  | "nova_pro"
  | "nova_premier";

/**
 * One placeholder declaration. The renderer substitutes `{name}` with the
 * caller-supplied value. `maxOccurrences=undefined` means unbounded.
 */
export interface Placeholder {
  name: string;
  description: string;
  maxOccurrences?: number;
}

/**
 * Schema for one inference-parameter the prompt may carry. The dry-render
 * validator and the frontend form derive their bounds from this declaration;
 * the Model_Capability_Profile decides which keys are present.
 */
export type InferenceParameterSchema =
  | { kind: "number"; min: number; max: number; default?: number }
  | { kind: "integer"; min: number; max: number; default?: number }
  | { kind: "stringArray"; maxLength: number };

/** A registered prompt — one entry per promptKey. */
export interface PromptDefinition {
  promptKey: PromptKey;
  name: string;
  description: string;
  category:
    | "scaffolding"
    | "analysis"
    | "evaluation"
    | "experiment"
    | "simulation"
    | "rag";
  defaultText: string;
  defaultModelKey: ModelKey;
  allowedModels: readonly ModelKey[];
  placeholders: readonly Placeholder[];
  /** Per-key max UTF-8 byte size; absent ⇒ default 64 KiB cap from R12.1. */
  maxTextBytes?: number;
  /** Inference-parameter schema keyed by Converse inferenceConfig key name. */
  inferenceParameters: Readonly<Record<string, InferenceParameterSchema>>;
  /** Default values for the inference parameters this prompt ships with. */
  defaultInferenceValues: Readonly<Record<string, unknown>>;
  /**
   * Optional: documented JSON-schema regions in the default text where literal
   * `{name}` braces appear that are NOT placeholders (R12.4).
   */
  literalBraceRegions?: ReadonlyArray<{ start: string; end: string }>;
}
```

### Prompt_Resolver

The resolver is the only path that callsites and PrepareRun use to read the effective `(text, modelId, inferenceParameters)` for a `promptKey`. It is a pure function that takes (a) the registry definition and (b) an in-memory snapshot of overrides keyed by `promptKey`, and returns the effective triple. No I/O happens inside the resolver — the Prompts Lambda fetches the override snapshot from DynamoDB once per request and the live-callsite path fetches it lazily on first invocation per Lambda warm.

```ts
/** A single override row materialised from the Prompts_Store. */
export interface PromptOverride {
  promptKey: PromptKey;
  text?: string;
  modelKey?: ModelKey;
  inferenceParameters?: Readonly<Record<string, unknown>>;
  version: number;
  lastModifiedAt: string;
  lastModifiedBy: string;
}

/** Output of the resolver — what the callsite actually sends to Bedrock. */
export interface ResolvedPrompt {
  promptKey: PromptKey;
  text: string;
  modelKey: ModelKey;
  modelId: string;
  inferenceParameters: Readonly<Record<string, unknown>>;
  /** Effective version: 0 when no override is in effect. */
  version: number;
  /** Capability profile of the resolved model — handed to buildInferenceConfig. */
  capabilityProfile: ModelCapabilityProfile;
}

export function resolvePrompt(
  promptKey: PromptKey,
  overrides: ReadonlyMap<PromptKey, PromptOverride>,
): ResolvedPrompt;
```

The resolver enforces three invariants on every call:

- **Default-fallback.** If the override is missing the `text`, `modelKey`, or `inferenceParameters` field individually, that field falls back to the registry's bundled default. The override record is intentionally a sparse update.
- **Stale-placeholder fallback.** If the resolved text is missing one or more of the prompt's declared placeholders (a stale override saved before a placeholder was added in code), the resolver falls back to the bundled `defaultText` for that single call, returns the default's `version=0`, and emits a structured warning log carrying `promptKey` and the missing placeholder names. The override record is left intact so the next deploy that updates the default propagates without an explicit user action. This implements R10.5.
- **Unknown promptKey.** Calling `resolvePrompt` with a `promptKey` the registry doesn't know throws a typed `UnknownPromptKeyError` rather than returning a synthesised default — the callsite must surface this as a structured error and abort the Bedrock call.

### Legacy `*_MODEL_ID` env-var seeding

The seven Converse callsites and the four judge callsites currently default their model id from per-callsite environment variables (`ANALYSIS_MODEL_ID`, `SCAFFOLD_MODEL_ID`, `SUITE_RECOMMEND_MODEL_ID`, `COMPARISON_SUMMARY_MODEL_ID`, `BEDROCK_MODEL_ID`, `SIMULATOR_MODEL_ID`, `JUDGE_MODEL_ID`). The registry preserves backward compatibility per R1.4 by reading those env vars **at registry construction time** and using the value as the per-prompt `defaultModelKey` seed when (a) the env var is set, (b) its value matches one of the six `Supported_Models` inference-profile ids, and (c) the prompt's `allowedModels[]` includes that model. If any of those three conditions fails, the registry falls back to the prompt's hardcoded `defaultModelKey` and emits a warning log naming the offending env var so the operator knows the seed was ignored. This bridge keeps a partial deploy from regressing default behaviour: the new code reads the same env var the old code read.

The bridge is removed in a follow-up cleanup once the registry has been the resolution path in production for a full release cycle. Until then, an operator who wants to override the default for a one-off run can still set the env var, and the registry will adopt it; once the override is persisted via the API, the env-var seed is silently overridden because `overrideModelKey` takes precedence per R1.4.

### Supported_Models catalog

`prompt-registry/supported-models.ts` declares the six-entry catalog as a frozen record. Each entry carries the canonical inference-profile id (used as the Bedrock `modelId`), the routing-region set (used by the IAM helper), the capability-profile key, and the `maxOutputTokens` ceiling (used by the capability profile's `maxTokens` numeric range).

```ts
export interface SupportedModel {
  modelKey: ModelKey;
  displayName: string;
  inferenceProfileId: string;          // sent as Bedrock modelId
  vendor: "anthropic" | "amazon";
  capabilityProfileKey: "anthropic_claude_4x" | "amazon_nova";
  maxOutputTokens: number;
  routingRegions: readonly string[];   // Routing_Region_Set
  /** Foundation-model wildcard fragment used in IAM (vendor-scoped). */
  foundationModelArnPattern: string;   // "anthropic.*" or "amazon.nova-*"
}

export const SUPPORTED_MODELS: Readonly<Record<ModelKey, SupportedModel>> = {
  claude_sonnet_4_6: {
    modelKey: "claude_sonnet_4_6",
    displayName: "Claude Sonnet 4.6",
    inferenceProfileId: "us.anthropic.claude-sonnet-4-6",
    vendor: "anthropic",
    capabilityProfileKey: "anthropic_claude_4x",
    maxOutputTokens: 64_000,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "anthropic.*",
  },
  claude_haiku_4_5: {
    modelKey: "claude_haiku_4_5",
    displayName: "Claude Haiku 4.5",
    inferenceProfileId: "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    vendor: "anthropic",
    capabilityProfileKey: "anthropic_claude_4x",
    maxOutputTokens: 64_000,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "anthropic.*",
  },
  claude_opus_4_8: {
    modelKey: "claude_opus_4_8",
    displayName: "Claude Opus 4.8",
    inferenceProfileId: "us.anthropic.claude-opus-4-8",
    vendor: "anthropic",
    capabilityProfileKey: "anthropic_claude_4x",
    maxOutputTokens: 128_000,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "anthropic.*",
  },
  nova_lite: {
    modelKey: "nova_lite",
    displayName: "Amazon Nova Lite",
    inferenceProfileId: "us.amazon.nova-lite-v1:0",
    vendor: "amazon",
    capabilityProfileKey: "amazon_nova",
    maxOutputTokens: 5_120,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "amazon.nova-*",
  },
  nova_pro: {
    modelKey: "nova_pro",
    displayName: "Amazon Nova Pro",
    inferenceProfileId: "us.amazon.nova-pro-v1:0",
    vendor: "amazon",
    capabilityProfileKey: "amazon_nova",
    maxOutputTokens: 5_120,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "amazon.nova-*",
  },
  nova_premier: {
    modelKey: "nova_premier",
    displayName: "Amazon Nova Premier",
    inferenceProfileId: "us.amazon.nova-premier-v1:0",
    vendor: "amazon",
    capabilityProfileKey: "amazon_nova",
    maxOutputTokens: 32_000,
    routingRegions: ["us-east-1"],
    foundationModelArnPattern: "amazon.nova-*",
  },
} as const;
```

The build invariant from R17.6 lives next to this catalog as a unit test that asserts every `modelKey` is unique, every `inferenceProfileId` matches its vendor's canonical prefix (`us.anthropic.*` or `us.amazon.*`), every `capabilityProfileKey` is declared in the capability-profile registry, and every `routingRegions[]` is non-empty.

### Model_Capability_Profile

`prompt-registry/capability-profiles.ts` declares the two profiles plus the helper that turns a profile + `inferenceParameters` map into a Bedrock Converse `inferenceConfig` (and any `additionalModelRequestFields` the model needs).

```ts
export interface ModelCapabilityProfile {
  key: "anthropic_claude_4x" | "amazon_nova";
  /** Keys that may appear in inferenceConfig (top-level Converse). */
  acceptsTopLevel: readonly string[];
  /** Keys that may appear in additionalModelRequestFields.inferenceConfig. */
  acceptsAdditional: readonly string[];
  /** Keys that MUST NOT appear anywhere — explicit forbid list for R10.4. */
  forbids: readonly string[];
  /** Numeric bounds used by the dry-render validator and the form. */
  numericRanges: Readonly<Record<string, { min: number; max: number }>>;
}

export const CAPABILITY_PROFILES: Readonly<
  Record<ModelCapabilityProfile["key"], ModelCapabilityProfile>
> = {
  anthropic_claude_4x: {
    key: "anthropic_claude_4x",
    acceptsTopLevel: ["maxTokens"],
    acceptsAdditional: [],
    forbids: ["temperature", "topP", "topK", "stopSequences"],
    numericRanges: { maxTokens: { min: 1, max: Number.MAX_SAFE_INTEGER } },
  },
  amazon_nova: {
    key: "amazon_nova",
    acceptsTopLevel: ["maxTokens", "temperature", "topP", "stopSequences"],
    acceptsAdditional: ["topK"],
    forbids: [],
    numericRanges: {
      maxTokens: { min: 1, max: Number.MAX_SAFE_INTEGER },
      temperature: { min: 0.0, max: 1.0 },
      topP: { min: 0.0, max: 1.0 },
      topK: { min: 1, max: 500 },
    },
  },
};
```

The `maxTokens.max` bound is `MAX_SAFE_INTEGER` at the profile level; the per-model effective ceiling is the smaller of the profile's bound and the model's `maxOutputTokens`. The dry-render validator enforces the effective bound so a Sonnet-4.6 prompt cannot persist `maxTokens: 200000`.

### `buildInferenceConfig` helper

Lives next to the capability-profile registry. Given a resolved prompt, it returns the Bedrock Converse argument shape: a top-level `inferenceConfig` containing only the keys present in `acceptsTopLevel` plus an optional `additionalModelRequestFields` carrying `acceptsAdditional` keys nested under `inferenceConfig`. Keys present in `inferenceParameters` but not in either accept list are dropped silently because the validation pipeline already rejected them at edit time — the helper has the simpler responsibility of *placing* the accepted keys correctly.

```ts
export function buildInferenceConfig(prompt: ResolvedPrompt): {
  inferenceConfig: Record<string, unknown>;
  additionalModelRequestFields?: { inferenceConfig: Record<string, unknown> };
};
```

For `anthropic_claude_4x` the helper returns `{ inferenceConfig: { maxTokens } }` — never anything else, even if the override carried legacy `temperature` values from before a model migration. For `amazon_nova` the helper returns `{ inferenceConfig: { maxTokens, temperature?, topP?, stopSequences? }, additionalModelRequestFields: { inferenceConfig: { topK } } }` (`topK` only when present). Callsites pass the result directly into their `ConverseCommand` constructor.

### Prompts_API

A new Prompts Lambda (`src/backend/handlers/prompts.ts`) handles every Prompts route through API Gateway proxy integration, dispatched by `(httpMethod, resource)` exactly as the Audit Lambda does today. The Lambda is added to `lib/api-construct.ts` alongside the existing analysis / scaffold / suite-recommend Lambdas, with the same `commonLambdaProps` posture (Node 20 ARM64, 512 MiB, tracing on, table grant). It needs `bedrock:InvokeModel` + `bedrock:Converse` against the union of `Supported_Models` (computed via the new `computeBedrockGrants` helper) so the dry-render check from R4.10 can actually assemble — but not send — a Converse request.

The routes and their MethodOptions:

| Route                                       | Auth                                           | Handler              |
|---------------------------------------------|------------------------------------------------|----------------------|
| `GET /prompts`                              | Cognito + `authorizationScopes: ['test-platform/run']` | `handleListPrompts`  |
| `GET /prompts/{promptKey}`                  | same                                           | `handleGetPrompt`    |
| `PUT /prompts/{promptKey}`                  | same                                           | `handleUpdatePrompt` |
| `POST /prompts/{promptKey}/reset`           | same                                           | `handleResetPrompt`  |
| `GET /prompts/{promptKey}/history`          | same                                           | `handleGetHistory`   |
| `GET /prompts/active-runs`                  | same                                           | `handleActiveRuns`   |

Every MethodOptions block sets `authorizationScopes: ['test-platform/run']` explicitly — the Implement Recommendations regression that we just fixed proved that omitting the scope flips the authorizer to ID-token mode and 401s on every frontend request.

#### Request / response contracts

```ts
// GET /prompts → 200
interface ListPromptsResponse {
  prompts: Array<{
    promptKey: PromptKey;
    name: string;
    category: string;
    description: string;
    defaultModelKey: ModelKey;
    currentModelKey: ModelKey;          // override if set, else default
    defaultModelDisplayName: string;
    currentModelDisplayName: string;
    lastModifiedAt: string | null;       // ISO 8601 UTC; null when never overridden
    lastModifiedBy: string | null;       // null when never overridden
    version: number;                     // 0 when never overridden
    isOverridden: boolean;
  }>;
}

// GET /prompts/{promptKey} → 200
interface GetPromptResponse {
  promptKey: PromptKey;
  name: string;
  description: string;
  category: string;
  defaultText: string;
  effectiveText: string;                 // override.text ?? defaultText
  defaultModelKey: ModelKey;
  currentModelKey: ModelKey;
  inferenceParameters: Record<string, unknown>;
  inferenceParameterSchema: Record<string, InferenceParameterSchema>;
  placeholders: Placeholder[];
  allowedModels: Array<{
    modelKey: ModelKey;
    displayName: string;
    inferenceProfileId: string;
    vendor: "anthropic" | "amazon";
    capabilityProfileKey: string;
    capabilityProfile: {
      acceptsTopLevel: string[];
      acceptsAdditional: string[];
      forbids: string[];
      numericRanges: Record<string, { min: number; max: number }>;
    };
  }>;
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;
  version: number;
  isOverridden: boolean;
}

// PUT /prompts/{promptKey}
interface UpdatePromptRequest {
  text?: string;
  modelKey?: ModelKey;
  inferenceParameters?: Record<string, unknown>;
}
interface UpdatePromptResponse {           // 200
  promptKey: PromptKey;
  version: number;
  lastModifiedAt: string;
  lastModifiedBy: string;
}

// POST /prompts/{promptKey}/reset
interface ResetPromptRequest {
  confirm: true;                           // R6.6 — anything else → 400
}
interface ResetPromptResponse {            // 200
  promptKey: PromptKey;
  version: 0;
  resetAt: string;
}

// GET /prompts/{promptKey}/history → 200
interface GetHistoryResponse {
  history: Array<{
    version: number;
    text: string;
    modelKey: ModelKey;
    inferenceParameters: Record<string, unknown>;
    modifiedAt: string;
    modifiedBy: string;
    changeKind: "edit" | "reset";
  }>;
}

// GET /prompts/active-runs → 200
interface ActiveRunsResponse {
  count: number;                           // running OR pending (R16.5)
}
```

Error responses follow the existing platform shape: `{ error: string, code: string, details?: object }`. The structured error codes the design commits to are `PROMPT_NOT_FOUND` (404), `PROMPT_TEXT_TOO_LARGE`, `PLACEHOLDERS_MISSING`, `PLACEHOLDER_COUNT_EXCEEDED`, `UNKNOWN_PLACEHOLDER`, `MODEL_NOT_ALLOWED`, `MODEL_FORBIDS_KEY` (carrying the offending key name; supersedes the obsolete `SONNET_4_6_NO_TOPP`), `INFERENCE_PARAMETER_OUT_OF_BOUNDS`, `DRY_RENDER_FAILED`, `RESET_CONFIRMATION_REQUIRED`. All of these are 400 except `PROMPT_NOT_FOUND` (404) and any pre-handler auth failure (401, returned by API Gateway before our code runs per R8.2).

### Validation pipeline

`PUT /prompts/{promptKey}` runs the body through a strictly-ordered validation pipeline; the first failure short-circuits and is returned as a 400 with the corresponding structured code. Order matters because each stage assumes the prior stage's invariants.

1. **Promptkey existence.** Path parameter must be in `Prompt_Registry`; else 404 `PROMPT_NOT_FOUND`.
2. **Body parse.** Reject malformed JSON with 400 (no structured code; API Gateway reports the parse error).
3. **Text size.** When `body.text` is present, UTF-8 byte length ≤ `prompt.maxTextBytes ?? 64 KiB`; else 400 `PROMPT_TEXT_TOO_LARGE` with observed and limit byte counts.
4. **Placeholder presence.** Every `placeholder.name` in the registry must occur at least once as the literal token `{name}` in `body.text`; else 400 `PLACEHOLDERS_MISSING` with the missing names.
5. **Placeholder occurrence cap.** For every placeholder declaring a finite `maxOccurrences`, count `{name}` occurrences in `body.text` and reject with 400 `PLACEHOLDER_COUNT_EXCEEDED` when the count exceeds the bound.
6. **Unknown placeholder detection.** Tokenise `body.text` for `{identifier}` segments. Any token whose name is not in the registry's `placeholders[]` AND does not lie within a registry-declared `literalBraceRegions[]` window → 400 `UNKNOWN_PLACEHOLDER` with the offending token and its character offset.
7. **Model membership.** When `body.modelKey` is present, it must be in the registry's `allowedModels[]` for this prompt; else 400 `MODEL_NOT_ALLOWED` with the supplied modelKey and the allowed list.
8. **Capability-profile compliance.** Compute the resolved `modelKey` (override-or-default) and `inferenceParameters` (override-or-default merged with the request body). For every key in `inferenceParameters`, the key must be in `acceptsTopLevel ∪ acceptsAdditional` AND must not be in `forbids`; else 400 `MODEL_FORBIDS_KEY` with the offending key and the model's profile name.
9. **Numeric bounds.** For every numeric key, value must lie in the profile's declared range (using the per-prompt `inferenceParameterSchema` as a tighter constraint when present, e.g. `temperature ∈ [0, 1]`); else 400 `INFERENCE_PARAMETER_OUT_OF_BOUNDS` with the offending key, supplied value, and declared interval.
10. **Dry-render.** Build the synthetic placeholder context (`{ name: `<sample-${name}>` }` for every declared placeholder), call `fillTemplate(body.text, syntheticContext)` to ensure the renderer doesn't throw, then call `buildInferenceConfig({ ...resolved, inferenceParameters: merged })` to ensure the resulting Converse argument shape is producible. If either step throws, or the resulting `inferenceConfig` keys are not a subset of `acceptsTopLevel`, return 400 `DRY_RENDER_FAILED` with the throwing step name (`fillTemplate` / `buildInferenceConfig`) and the throw message.

Stages 1–9 are pure; Stage 10 is also pure (it never sends the request — it just constructs it and runs the renderer). The validation module exports each stage as a separate function so the property-based tests can hammer them individually.

### Frontend components

The frontend changes live under `src/frontend/src/`:

- `components/AppLayout/sideNav.tsx` — add a `Prompts` entry immediately below `Test Suites` per R13.1, linked to `/prompts`.
- `pages/PromptsListPage.tsx` — Cloudscape `Table` over `GET /prompts` with columns `name`, `category`, `currentModelDisplayName`, `lastModifiedAt`, `lastModifiedBy`, an `isOverridden` badge column, and a row-click handler that navigates to `/prompts/{promptKey}`. Includes the loading state, error state, and empty state from R13.5–R13.7.
- `pages/PromptDetailPage.tsx` — split-pane Cloudscape `Container` layout: left pane is the `Cloudscape Textarea`-based editor seeded with `effectiveText`, right pane is a read-only viewer of `defaultText`. Below: the `ModelSelector` (Cloudscape `Select` over `allowedModels`), the `InferenceParameterForm` (auto-generated from `inferenceParameterSchema` filtered by the current model's `capabilityProfile.acceptsTopLevel ∪ acceptsAdditional`), the `PlaceholderHints` panel (a small list of `{name}` chips with their descriptions), and the `Save` / `Revert to default` button row.
- `components/Prompts/ModelSelector.tsx` — capability-aware select. When the user picks a `modelKey` whose capability profile differs from the current one, the form rebuilds: keys in the new profile's `forbids[]` are removed from the visible form, keys it newly accepts appear with their schema defaults pre-filled but only get sent on the next `Save`. The selector emits a Cloudscape `Alert` when the switch removes form fields so the user knows what changed.
- `components/Prompts/HistoryPanel.tsx` — Cloudscape collapsible `ExpandableSection` rendered beneath the editor. On expand, refetches `GET /prompts/{promptKey}` (per R14.5) and `GET /prompts/{promptKey}/history` in parallel, then renders the history list with a per-entry `View` affordance that swaps the right-pane viewer from `defaultText` to that historical entry's text.
- `components/Prompts/RevertConfirmModal.tsx` — Cloudscape `Modal` confirming the reset; on `Revert` issues `POST /prompts/{promptKey}/reset` with `{ confirm: true }` and refetches the detail.
- `components/Prompts/ActiveRunsFlashbar.tsx` — Cloudscape `Flashbar`. The detail page polls `GET /prompts/active-runs` once on mount and again immediately before submitting an edit/reset; if the response's `count > 0`, the Flashbar surfaces the R14.6 message after a successful save.
- `api/prompts.ts` — typed API client wrappers (`listPrompts`, `getPrompt`, `updatePrompt`, `resetPrompt`, `getHistory`, `getActiveRuns`) layered on the existing `useApi` hook, so the components don't talk to `fetch` directly.

The list page renders even when zero prompts have ever been overridden, because the registry always has thirteen entries — the empty state from R13.7 only fires if the `GET /prompts` response itself is empty (which would indicate a registry build regression).

### Conformance_Probe runner

Lives at `scripts/bedrock-probe.ts` (one self-contained TypeScript file, modelled on the existing `scripts/bedrock-judge-probe.ts` so the same probe-style stayed in tree). Invoked as `npm run probe:bedrock` (positive + negative + RAG-job for every model in the catalog) or `npm run probe:bedrock -- --dry-run` (mocked Bedrock client, used in unit tests).

Architecture:

```
scripts/bedrock-probe.ts
├── parseArgs()             // --dry-run, --models nova_lite,claude_haiku_4_5
├── buildPositiveProbe(m)   // Converse with profile.acceptsTopLevel keys, maxTokens=32
├── buildNegativeProbe(m)   // Converse with one profile.forbids key set
├── buildRagJobProbe()      // CreateEvaluationJob → StopEvaluationJob
├── runProbe(probe, client) // sends Converse and times it
├── isRegionReachable(m)    // skips models whose routing-regions are unreachable from the current AWS region; emits a structured warning per R18.8
├── main()                  // iterates the catalog, collects results, writes the report
```

Output is a JSON report at `bedrock-probe-report.json` — one entry per `(modelKey, probeKind)` per R18.5. Every positive probe caps `inferenceConfig.maxTokens` at 32 (R18.8 cost cap). Every negative probe sends exactly one forbidden key set to its profile-default value and asserts a 4xx; if a 200 comes back it dumps the request and response and fails the build per R18.3 — that's the "doc lag" sentinel that catches Anthropic silently re-accepting `temperature` later.

The runner keys CI integration off two events: a build that touches `src/backend/orchestration/prompt-registry/` or any Bedrock callsite re-runs the full positive+negative suite and asserts every report entry is `pass`; the release pipeline runs the same gate before it deploys to a non-development environment per R18.4. The `--dry-run` mode swaps `BedrockRuntimeClient.send` for a mock that returns a synthetic `{ output: { message: { content: [{ text: "ok" }] } } }` and lets the unit test assert the request shape rather than the live response.

### CDK helper `computeBedrockGrants`

`lib/bedrock-grants.ts` exports the helper. It walks the `Prompt_Registry` and the `Supported_Models` catalog at synth time, takes the union of `allowedModels[]` reachable from the input promptKeys, and emits one IAM `PolicyStatement` whose `Resource` list is exactly the union of inference-profile + routing-region foundation-model ARNs.

```ts
export interface ComputeBedrockGrantsArgs {
  promptKeys: readonly PromptKey[];
  stack: cdk.Stack;            // for stack.region / stack.account substitution
}

export interface BedrockGrant {
  statement: iam.PolicyStatement;
  /** modelKeys covered by this grant; surfaced on the BedrockGrantSummary CFN output. */
  modelKeys: readonly ModelKey[];
}

export function computeBedrockGrants(args: ComputeBedrockGrantsArgs): BedrockGrant;
```

Logic:

1. For each `promptKey` in the input, look up its `allowedModels[]` from the registry. Union the results into a `Set<ModelKey>`. Throw if any `promptKey` is unknown.
2. For each model in the union, look up its `SupportedModel` entry. Throw if the entry has an empty `routingRegions[]` (R19.5).
3. Emit one Resource per model: the inference-profile ARN in the deployment region (`arn:aws:bedrock:${stack.region}:${stack.account}:inference-profile/${inferenceProfileId}`).
4. Emit one Resource per routing-region per model: a vendor-scoped foundation-model wildcard (`arn:aws:bedrock:${region}::foundation-model/${foundationModelArnPattern}`). Deduplicate identical ARNs across models that share a vendor and region.
5. Wrap the Resource list in a single `iam.PolicyStatement` whose `Actions` are exactly `["bedrock:InvokeModel", "bedrock:Converse"]` and return it alongside the modelKey set.

Each Bedrock-calling Lambda construct (`scaffoldLambda`, `analysisLambda`, `comparisonSummaryLambda`, `suiteRecommendLambda` in `api-construct.ts`; the Evaluation Lambda, the Customer Simulator path inside `conversationDriverFn`, the Variant Generator Lambda, the Tournament Summary Lambda in `orchestration-construct.ts`; the RAG Evaluate Lambda; and the new Prompts Lambda) is refactored to:

```ts
const grant = computeBedrockGrants({
  promptKeys: [
    "failure_analysis",
    "suite_recommendation",
    // ... promptKeys this Lambda actually invokes
  ],
  stack,
});
lambda.addToRolePolicy(grant.statement);
bedrockGrantSummary[lambda.node.id] = grant.modelKeys;
```

The constructs build a `bedrockGrantSummary: Record<string, readonly ModelKey[]>` map and emit one `cdk.CfnOutput("BedrockGrantSummary", { value: JSON.stringify(bedrockGrantSummary) })` per stack so the deploy review can read off which model each Lambda is allowed to invoke without parsing the synthesised IAM JSON.

The CDK assertion test (`tests/cdk/bedrock-grants.test.ts`) synthesises the stack, walks every Lambda's role policies, and for each Bedrock-calling Lambda asserts that the Resource list is the exact union (set-equal — neither wider nor narrower) of (a) the inference-profile ARNs and (b) the routing-region foundation-model wildcards reachable from that Lambda's promptKey set per R19.3.

### Run_Snapshot extension and PrepareRun integration

The existing `AgentSnapshot` shape in `src/shared/types.ts` carries `tools`, `systemPrompt`, `modelId`, and `capturedAt`. The feature adds one optional field, `prompts`, without changing any of the existing fields:

```ts
export interface AgentSnapshot {
  tools: ToolDefinition[];
  systemPrompt: string;
  modelId: string;
  capturedAt: string;
  /**
   * Per-promptKey resolved prompts pinned at run start. Optional for backward
   * compatibility with snapshots written before this feature shipped — readers
   * that find this field absent fall back to the live registry per R11.4 / R16.2.
   */
  prompts?: Readonly<Record<PromptKey, ResolvedPromptSnapshot>>;
}

export interface ResolvedPromptSnapshot {
  text: string;
  modelKey: ModelKey;
  modelId: string;
  inferenceParameters: Readonly<Record<string, unknown>>;
  capabilityProfileKey: "anthropic_claude_4x" | "amazon_nova";
  /** Effective version at capture; 0 if no override was in effect. */
  version: number;
}
```

`prepare-run.ts` is extended to import the registry and resolver, fetch the live override snapshot once via `DynamoDBService.listPromptOverrides()` (new helper), call `resolvePrompt(promptKey, overrides)` for every `promptKey` in `RUN_PROMPT_KEYS` (a constant declared next to the registry that names the keys any test run can consume — every key except `suite_scaffold` / `case_scaffold` / `comparison_summary` which are interactive only), and write the resulting map into `AgentSnapshot.prompts` on the existing `writeSnapshot` call.

Capture happens before PrepareRun's existing `createRun` write so the run record never reaches `RUNNING` status without its prompts pinned (R11.1 + R16.1 ordering). If `listPromptOverrides()` fails, PrepareRun fails the entire run with a structured `PROMPT_RESOLUTION_FAILED` error rather than writing a snapshot with no `prompts` field — the run never starts in a half-pinned state per R11 acceptance criterion 2.

### Bedrock_Callsite resolution path

Every callsite picks up a small new module, `src/backend/orchestration/prompt-registry/runtime.ts`, that exposes:

```ts
/**
 * Used inside a Step Functions execution. Reads the snapshot once per Lambda
 * warm cache, resolves the prompt from the snapshot, and falls back to the
 * live registry when the snapshot lacks a `prompts` field (pre-feature run).
 */
export async function resolvePromptForRun(
  promptKey: PromptKey,
  runId: string,
): Promise<ResolvedPromptSnapshot>;

/**
 * Used outside any run scope (interactive endpoints like POST /scaffold,
 * POST /comparison-summary). Reads the live override store and runs the
 * resolver.
 */
export async function resolvePromptLive(
  promptKey: PromptKey,
): Promise<ResolvedPromptSnapshot>;
```

Both functions return `ResolvedPromptSnapshot` so callsites have a single shape to consume. Both fail closed when neither path can resolve: `resolvePromptForRun` throws a `PromptResolutionError` if the snapshot read fails AND the live registry read also fails (R16.3); `resolvePromptLive` throws the same error if the live registry read fails. Callsites surface the error to their caller — the conversation driver maps it to a case-error, the API handlers map it to a 500.

Each migrated callsite then becomes:

```ts
const prompt = await resolvePromptForRun("failure_analysis", runId);
const { inferenceConfig, additionalModelRequestFields } = buildInferenceConfig(prompt);
const command = new ConverseCommand({
  modelId: prompt.modelId,
  system: [{ text: fillTemplate(prompt.text, vars) }],
  messages,
  inferenceConfig,
  ...(additionalModelRequestFields ? { additionalModelRequestFields } : {}),
});
```

### Audit_Log integration

`AuditWriter` is the existing helper that the Apply Recommendations and the new Prompts handlers share for writing `PK=TENANT#{tenantId}, SK=AUDIT#{ts}` records. The Prompts Lambda calls it after a successful `PUT` or `reset`:

- `prompt_edit` payload: `{ promptKey, previousVersion, newVersion, textHash: <sha256 lowercase hex>, textLength: <UTF-8 byte length> }`
- `prompt_reset` payload: `{ promptKey, previousVersion }`

`userDecision` is `"normal"` for both. The full text body is never persisted to the audit table — only the SHA-256 hash and the byte length per R9.4. The handler logs an error at error level if the audit write throws but always responds 200 to the caller (R9.3, "best-effort audit").

## Data Models

### Prompts_Store records

Two record families on the existing `ConnectAgentTestPlatform` single table.

**Override record** — exactly one per `promptKey` that has ever been overridden:

```
PK = "PROMPT#{promptKey}"
SK = "OVERRIDE"
Attributes:
  promptKey:           string                       // duplicated for queryless reads
  text:                string?                      // sparse — absent means "use default"
  modelKey:            ModelKey?                    // sparse — absent means "use default"
  inferenceParameters: Map<string, unknown>?         // sparse — absent means "use default"
  version:             number                       // monotonically increasing, starts at 1
  lastModifiedAt:      string                        // ISO 8601 UTC, ms precision
  lastModifiedBy:      string                        // Cognito sub or client_id
```

Sparse semantics let a user override just the `modelKey` without forcing them to also re-save `text` and vice versa; the resolver fills missing fields from the registry default. A reset removes the entire row per R6.1.

**History record** — at most ten per `promptKey`, one per prior version:

```
PK = "PROMPT#{promptKey}"
SK = "HISTORY#{paddedVersion}"           // paddedVersion = String(version).padStart(10, "0")
Attributes:
  promptKey:           string
  version:             number
  text:                string                        // resolved (default-merged) text at this version
  modelKey:            ModelKey
  modelId:             string                        // resolved at write time
  inferenceParameters: Map<string, unknown>
  modifiedAt:          string
  modifiedBy:          string
  changeKind:          "edit" | "reset"
```

The padded SK suffix makes lexicographic ordering match numeric ordering up to ten billion versions — far past anything the platform will hit in practice.

#### Write path semantics

A `PUT` is implemented as a DynamoDB `TransactWriteItems` of three items:

1. **Snapshot the prior override** as a new HISTORY record. The handler reads the current OVERRIDE row first (a separate `GetItem` outside the transaction so the transaction's `ConditionExpression` sees a fresh `version`), then inserts `PK=PROMPT#{promptKey}, SK=HISTORY#{paddedPriorVersion}`. If no prior override exists the insert is skipped — version 0 is the implicit default state and is never persisted as a HISTORY record.
2. **Update the OVERRIDE record** with the merged sparse update, the incremented version, the new `lastModifiedAt`, and the new `lastModifiedBy`. The transaction's `ConditionExpression` asserts `attribute_not_exists(version) OR version = :priorVersion` for optimistic concurrency — two concurrent edits cannot both succeed.
3. **Evict the oldest history entry** when the post-write history count exceeds ten per R7.2. This is a separate `DeleteItem` (not in the transaction — eviction is best-effort and runs after the transaction commits) keyed at `PK=PROMPT#{promptKey}, SK=HISTORY#{paddedOldestVersion}`. The handler computes the oldest version by querying for the lowest `HISTORY#` SK before deleting; if the eviction fails the handler logs a warning and continues — at worst we accumulate one extra history entry, which the next eviction picks up.

A `reset` is similarly transactional: snapshot the prior OVERRIDE as a HISTORY record with `changeKind=reset`, then `DeleteItem` the OVERRIDE row. The condition expression asserts the body's `confirm: true` was honoured by the handler before the transaction is even constructed (R6.6) — the transaction itself doesn't see the `confirm` field.

A `reset` against a prompt that has never been overridden is a no-op transaction: zero history insert (no prior to snapshot), zero OVERRIDE delete (none exists), and the response is 200 with `version: 0` per R6.4 idempotence.

### Run_Snapshot extension

The existing `PK=RUN#{runId}, SK=SNAPSHOT` record stores `AgentSnapshot`. The feature adds the optional `prompts` map per the type defined above. Reads of pre-feature snapshots (records without `prompts`) succeed and the runtime resolver falls back to the live registry per R11.4 — the field is genuinely additive.

### Audit_Log extension

`AuditRecord.source` gains two new literal values, `"prompt_edit"` and `"prompt_reset"`, joining the existing literals (`apply_recommendations`, etc.) declared in `src/shared/types.ts`. The payload shape is recorded above under Audit_Log integration. Audit records remain queryable via the existing `GET /audit` endpoint without any handler change.

## Error Handling

### API-level errors

Every `4xx` response returned by the Prompts Lambda carries `{ error: string, code: string, details?: object }` per the platform convention. The structured codes the handler emits are exhaustive and machine-checkable:

| HTTP | Code                                | When                                                            |
|------|-------------------------------------|-----------------------------------------------------------------|
| 400  | `RESET_CONFIRMATION_REQUIRED`       | `POST /reset` body lacks `confirm: true`                        |
| 400  | `PROMPT_TEXT_TOO_LARGE`             | UTF-8 byte length > size cap; `details.observedBytes`, `details.limitBytes`           |
| 400  | `PLACEHOLDERS_MISSING`              | one or more declared placeholders absent from new text; `details.missing[]`           |
| 400  | `PLACEHOLDER_COUNT_EXCEEDED`        | placeholder occurs more than its declared `maxOccurrences`; `details.placeholder`, `details.observed`, `details.max` |
| 400  | `UNKNOWN_PLACEHOLDER`               | new text contains a `{name}` not declared and not in `literalBraceRegions`; `details.token`, `details.offset`        |
| 400  | `MODEL_NOT_ALLOWED`                 | requested `modelKey` not in this prompt's `allowedModels[]`; `details.requested`, `details.allowed[]` |
| 400  | `MODEL_FORBIDS_KEY`                 | `inferenceParameters` contains a key the resolved model forbids; `details.key`, `details.profile` |
| 400  | `INFERENCE_PARAMETER_OUT_OF_BOUNDS` | numeric inferenceParameter outside the declared range; `details.key`, `details.value`, `details.range` |
| 400  | `DRY_RENDER_FAILED`                 | renderer or `buildInferenceConfig` threw during dry-render; `details.step`, `details.message` |
| 401  | _none_                              | API Gateway authorizer rejection; never reaches our handler    |
| 404  | `PROMPT_NOT_FOUND`                  | path parameter not in the registry                              |
| 500  | `INTERNAL_ERROR`                    | unhandled handler exception                                     |

The `MODEL_FORBIDS_KEY` code replaces the requirements-stage `SONNET_4_6_NO_TOPP` specifically because the new code path is generic: any future model that adds a forbidden key surfaces the same code with the new key name, no schema migration needed.

### Callsite-level errors

Every Bedrock callsite handles three structured error classes from `runtime.ts`:

- `UnknownPromptKeyError` — the registry doesn't recognise the `promptKey` the callsite passed. This is a programming error and surfaces as a 500 from interactive endpoints; in-run callsites map it to a case-error with `errorMessage` "Unknown prompt key: {key}". This is unrecoverable at runtime and should be caught in CI by the build invariant (R1.5).
- `PromptResolutionError` — both the snapshot path and the live-registry fallback failed (R16.3 fail-closed). The callsite aborts the Bedrock call (no synthesised default, no empty prompt, no cached value) and surfaces the error to its caller so the run records it as an `error` status with `errorMessage` carrying the cause.
- `StalePlaceholderWarning` — the resolver returned the bundled default after detecting a stale override (R10.5). This is a *warning*, not a thrown error: the callsite proceeds with the bundled default, the resolver has already emitted a structured warning log, and the case is otherwise indistinguishable from a fresh registry read. The override row is left intact so a subsequent registry edit propagates without operator action.

### Snapshot read failure mid-run

If a callsite is mid-execution inside a Map iteration and its snapshot read fails (DDB throttling, transient AZ failure, etc.), the runtime resolver retries up to three times with full jitter exponential backoff (1s base, 10s cap) per the platform's existing throttle-retry helper. After exhausting retries, it falls back to the live registry per R16.3. If the live registry read also fails, it throws `PromptResolutionError` and the case errors out — the run continues; only the affected case is marked errored, exactly as a Bedrock 4xx would be.

### CDK synth-time errors

`computeBedrockGrants` throws synth-time errors with explicit messages naming the offending modelKey or promptKey when:

- An input `promptKey` is not registered (R19 misconfiguration).
- A `Supported_Models` entry has an empty `routingRegions[]` (R19.5).
- The registry's `allowedModels[]` references a `modelKey` not in the catalog (R17.6).

Synth fails so the misconfiguration cannot reach a deployable artifact.

## Testing Strategy

### Unit tests

Each new module ships with a co-located unit test file in `tests/unit/`. The high-leverage targets:

- `tests/unit/prompt-registry.test.ts` — registry build invariants from R1.1 (the thirteen promptKey values are present), R17.1 (the six modelKey values are present, every inference profile id matches its vendor prefix), R17.6 (every `capabilityProfileKey` is declared, every `routingRegions[]` is non-empty), and R3.3 (the `defaultText` of every prompt round-trips through `JSON.stringify` byte-for-byte to confirm no normalization happens at the registry layer).
- `tests/unit/prompt-resolver.test.ts` — the resolver's three behaviour invariants (default-fallback, stale-placeholder fallback emits a warning and returns `version=0`, unknown promptKey throws `UnknownPromptKeyError`).
- `tests/unit/capability-profiles.test.ts` — the helper's correctness: anthropic-4x always omits `temperature`/`topP`/`topK`/`stopSequences`; nova places `topK` in `additionalModelRequestFields.inferenceConfig.topK`, never top-level.
- `tests/unit/prompts-validation.test.ts` — every validation pipeline stage in isolation, asserting the right error code for the right input. One test per `(stage, error code)` pair so a regression in one stage doesn't accidentally re-test the wrong code.
- `tests/unit/prompts-handler.test.ts` — the API handler routes (mocked DDB and mocked `AuditWriter`), verifying response shapes match the `GetPromptResponse`/`UpdatePromptResponse`/`GetHistoryResponse`/`ResetPromptResponse`/`ActiveRunsResponse` types byte-for-byte.
- `tests/unit/runtime.test.ts` — `resolvePromptForRun` snapshot-first / live-fallback / fail-closed semantics with both DDB clients mocked.
- `tests/unit/prepare-run-prompts.test.ts` — extending the existing prepare-run test file: assert the new `prompts` field is present and resolves all `RUN_PROMPT_KEYS` for both pristine (no overrides) and partially-overridden (one override saved) cases.
- `tests/unit/bedrock-probe-dry-run.test.ts` — exercising every probe builder against the mocked Bedrock client to assert the correct request shape is produced per profile (positive: only accepted keys; negative: exactly one forbidden key; RAG-job: `CreateEvaluationJob` with `evaluatorModelConfig.bedrockEvaluatorModels[].modelIdentifier` set to the resolved model id).
- `tests/cdk/bedrock-grants.test.ts` — synthesises the stack, walks every Bedrock-calling Lambda's role policy, and asserts set-equality with the union computed by `computeBedrockGrants`. Also asserts the `BedrockGrantSummary` CFN output exists and decodes back to a map keyed by every Bedrock-calling Lambda's logical id.

### Integration / smoke

The Conformance_Probe runner *is* the integration test for live Bedrock. Local development runs `npm run probe:bedrock -- --dry-run` for fast feedback; CI on registry/callsite changes runs the full probe suite with real credentials. The probe report is uploaded as a build artifact so a doc-lag false-negative leaves a forensic trail.

### Property-based testing

Five property-based tests live in `tests/properties/`. Each runs ≥100 iterations under the existing fast-check harness, with mocked DDB and Bedrock clients so they're deterministic and fast (≤60s per property per R15.6).

- `tests/properties/prompts-roundtrip.property.test.ts` — the round-trip property from R15.1.
- `tests/properties/prompts-reset-idempotence.property.test.ts` — the reset idempotence property from R15.2.
- `tests/properties/prompts-placeholder-preservation.property.test.ts` — the placeholder preservation property from R15.3.
- `tests/properties/prompts-registry-only-resolution.property.test.ts` — the registry-only resolution property from R15.4 / R17.6 (a static AST-walk over `src/backend/handlers/` and `src/backend/orchestration/` that asserts no Bedrock-calling source file contains a top-level `const SYSTEM_PROMPT = ` literal or a top-level `process.env.*_MODEL_ID ?? "..."` fallback).
- `tests/properties/prompts-capability-profile.property.test.ts` — the capability-profile rule from R17 (for any `(promptKey, modelKey)` pair the resolver could return, the resolved `inferenceParameters` key set is a subset of `acceptsTopLevel ∪ acceptsAdditional` and disjoint from `forbids`).

### fast-check generators

Three new generators live in `tests/properties/generators.ts`:

```ts
/** Picks one of the thirteen registered promptKeys uniformly at random. */
export const promptKeyArb: fc.Arbitrary<PromptKey>;

/**
 * Generates a valid `text` body for the given prompt: every declared
 * placeholder appears at least once, no unknown placeholders are introduced,
 * total UTF-8 byte length stays under the prompt's size cap.
 */
export function validTextArb(prompt: PromptDefinition): fc.Arbitrary<string>;

/**
 * Generates a valid `inferenceParameters` body for the given (prompt, model)
 * pair: keys are a subset of the model's capability profile's accept lists,
 * numeric values lie inside their declared bounds.
 */
export function validInferenceParametersArb(
  prompt: PromptDefinition,
  model: SupportedModel,
): fc.Arbitrary<Record<string, unknown>>;
```

The generators are imported by every property test so the same valid-input distribution is shared across the suite.

### Mocked client setup

Tests mock `DynamoDBDocumentClient` via the existing `_setDDBClient` injection points already present on every handler module — no new harness needed. Bedrock calls in the unit and property tests inject `_setBedrockClient` with a stub returning canned responses (Converse: `{ output: { message: { content: [{ text: "ok" }] } } }`; CreateEvaluationJob: `{ jobArn: "arn:aws:bedrock:..." }`).

## Correctness Properties

The five property-based invariants required by R15. Each one names the exact pre-condition, the exact post-condition, and the test file that pins it.

### Property 1: Override Round-Trip

**Pre-condition.** A `(promptKey, text, modelKey, inferenceParameters)` tuple where `text` satisfies the prompt's placeholder schema, fits under the size cap, and contains no unknown placeholders; `modelKey` is in the prompt's `allowedModels[]`; `inferenceParameters` is valid for the model's capability profile.

**Post-condition.** A `PUT /prompts/{promptKey}` with that body followed by a `GET /prompts/{promptKey}` returns `effectiveText`, `currentModelKey`, and `inferenceParameters` element-wise equal to the input.

**Test.** `tests/properties/prompts-roundtrip.property.test.ts`. Generators: `promptKeyArb`, `validTextArb`, `validInferenceParametersArb`. The property holds across at least 100 iterations.

**Validates: Requirements 4.4, 15.1**

### Property 2: Reset Idempotence

**Pre-condition.** Any non-empty sequence of `PUT` and `reset` operations against a single `promptKey`, ending in a `reset`. The sequence length is bounded to ≤20 ops per iteration so the in-memory mock DDB doesn't have to materialise unbounded history.

**Post-condition.** After the final `reset`, applying one additional `reset` leaves the `promptKey`'s state unchanged: `GET /prompts/{promptKey}` returns the same `effectiveText`, `currentModelKey`, `inferenceParameters`, `version: 0`, and `isOverridden: false`.

**Test.** `tests/properties/prompts-reset-idempotence.property.test.ts`. Builds operation sequences via `fc.array(fc.oneof(editOpArb, resetOpArb), { minLength: 1, maxLength: 20 })`.

**Validates: Requirements 6.4, 15.2**

### Property 3: Placeholder Preservation

**Pre-condition.** Any persisted Prompt (default state, edited, or post-reset).

**Post-condition.** The set of declared `placeholder.name` values is a subset of the set of `{name}` tokens in the persisted `effectiveText`. Equivalently: every required placeholder appears at least once in the text the resolver returns.

**Test.** `tests/properties/prompts-placeholder-preservation.property.test.ts`. Hammered against random override sequences plus the bundled defaults.

**Validates: Requirements 12.2, 15.3**

### Property 4: Registry-Only Resolution

**Pre-condition.** Any source file under `src/backend/handlers/` or `src/backend/orchestration/` that imports `BedrockRuntimeClient`, `ConverseCommand`, `BedrockAgentCoreClient`, or that issues a Bedrock RAG `CreateEvaluationJob` (matched by AST-walking import declarations and call expressions).

**Post-condition.** That source file imports `resolvePromptForRun` or `resolvePromptLive` from `prompt-registry/runtime` AND does NOT contain a top-level `const SYSTEM_PROMPT = ` literal AND does NOT contain a top-level `process.env.*_MODEL_ID ?? "..."` fallback assignment.

**Test.** `tests/properties/prompts-registry-only-resolution.property.test.ts`. This is a static AST-level invariant rather than a generative property; it iterates the file system once per test invocation and asserts the rule on every Bedrock-touching file. The "≥100 iterations" budget from R15.6 is satisfied by parameterising over the file set rather than over generated inputs.

**Validates: Requirements 1.3, 15.4**

### Property 5: Model_Capability_Profile Compliance

**Pre-condition.** Any `(promptKey, modelKey)` pair the resolver could return — including pairs where `modelKey` is the prompt's bundled default and pairs where it is a persisted override.

**Post-condition.** The resolved `inferenceParameters` key set is a subset of `capabilityProfile.acceptsTopLevel ∪ capabilityProfile.acceptsAdditional` AND is disjoint from `capabilityProfile.forbids`. In particular, no `anthropic_claude_4x` resolution ever carries `temperature`, `topP`, `topK`, or `stopSequences`.

**Test.** `tests/properties/prompts-capability-profile.property.test.ts`. Generates random override sequences across all `(promptKey, modelKey)` pairs and asserts the post-condition on every resolver output.

**Validates: Requirements 15.5, 17.4**

## Migration Plan

The seven Converse callsites, four judge prompts, and the RAG eval job model are migrated in waves so a partial deploy is always operable. Each wave is one mergeable PR / deploy. The conformance-probe suite gates every wave.

### Wave 0 — Registry foundation (no behavioural change)

- Create `src/backend/orchestration/prompt-registry/` with the empty registry, capability profiles, supported-models catalog, resolver, and runtime helpers. The registry is wired but no Lambda imports it yet.
- Add the Prompts Lambda, the API routes, and the Cloudscape pages. `GET /prompts` returns thirteen entries every one of which has `isOverridden: false` because no overrides exist yet. Editing a prompt persists an override and the OVERRIDE/HISTORY records appear in DDB, but no callsite reads them.
- Add `computeBedrockGrants`. The existing inline IAM blocks are NOT removed in this wave — both the new helper-derived statement and the legacy inline statement are attached to each Lambda's role. This keeps the deployed permissions a strict superset of what's needed during cutover.
- Conformance_Probe runner ships and is wired into CI. The full positive + negative + RAG-job suite must pass before the next wave merges.

### Wave 1 — Lowest-risk callsites first

In order of risk (lowest first):

1. **`comparison-summary.ts`** — interactive endpoint, called once per user click, doesn't run inside any Step Functions execution. Migrated to `resolvePromptLive("comparison_summary", …)`. The legacy `process.env.COMPARISON_SUMMARY_MODEL_ID` env var stays set so a partial-deploy Lambda still resolves the same modelId via the env-var seed.
2. **`scaffold.ts`** — same pattern, `resolvePromptLive("suite_scaffold", …)` and `resolvePromptLive("case_scaffold", …)`. Only the registry-resolution path changes; the request shape is unchanged.
3. **`suite-recommend.ts`** — same pattern, `resolvePromptLive("suite_recommendation", …)`.
4. **`analysis.ts`** — same pattern, `resolvePromptLive("failure_analysis", …)`.

After Wave 1 the four interactive Bedrock callsites all read from the registry and edits propagate without redeploy. None of these callsites runs inside a Step Functions execution so there's no Run_Snapshot dependency yet.

### Wave 2 — In-run callsites + Run_Snapshot

This wave is where the snapshot extension becomes live.

1. Extend `prepare-run.ts` to capture the `prompts` map. Backward compatibility is automatic: existing snapshot reads of pre-feature records get `prompts === undefined` and the runtime resolver falls back to the live registry per R11.4.
2. Migrate `customer-simulator.ts` to `resolvePromptForRun("customer_simulator", runId)` inside the Map iteration.
3. Migrate `variant-generator.ts` to `resolvePromptForRun("variant_generation", runId)`.
4. Migrate `tournament-summary.ts` to `resolvePromptForRun("tournament_summary", runId)`. **Bonus side effect:** this wave also migrates the orphan default `claude-sonnet-4-20250514-v1:0` in `tournament-summary.ts` onto the registry's `claude_sonnet_4_6` modelKey, retiring the only callsite that hadn't yet adopted the platform's standard default.
5. Migrate the four AgentCore-template judges (`bedrock-judge-client.ts` consumers in the Evaluation Lambda + `opportunistic-faithfulness.ts`) to `resolvePromptForRun("judge_*", runId)`. Each judge's existing `JUDGE_MODEL_ID` env var stays set as the legacy seed.
6. Migrate the RAG evaluation job (`rag-evaluate.ts`) to `resolvePromptForRun("rag_evaluation_job", runId)` — but here the resolved `modelId` populates `evaluatorModelConfig.bedrockEvaluatorModels[].modelIdentifier` on the `CreateEvaluationJob` request rather than a Converse argument, per R10.2.

After Wave 2 every Bedrock callsite the platform owns reads from the registry. The conformance-probe suite has been re-run on every PR.

### Wave 3 — IAM cleanup + env-var retirement

1. Remove the legacy inline `bedrock:*` `addToRolePolicy` blocks from `api-construct.ts` and `orchestration-construct.ts`. Each Lambda now has exactly one Bedrock statement, the one `computeBedrockGrants` produced. The CDK assertion test (set-equality) starts failing if any inline grant is reintroduced.
2. Remove the legacy `*_MODEL_ID` environment variables from every Lambda's `commonEnv`. The registry no longer reads them; the env-var seeding bridge in `prompt-registry/index.ts` is deleted in the same change.
3. Retire the obsolete `Sonnet_4_6_Family` glossary references in any code comment that survived the requirements-stage replacement. The capability-profile-driven validation has fully subsumed the old carve-out.

Wave 3 is the cleanup wave — no new behaviour, only removal of code that the new architecture made redundant.

### Risk gates between waves

- Each wave must merge with the conformance-probe suite green.
- Each wave must merge with the property-based test suite green at ≥100 iterations per property.
- Wave 2 cannot merge until at least one full test run has executed end-to-end with the Wave 1 callsites resolving from the registry — the Run Dashboard's existing alarm that flags stuck-running runs is the early-warning signal.
- Wave 3 cannot merge until at least one release cycle has passed with Wave 2 in production. This gives the env-var seed bridge enough time to prove operationally redundant.

### Rollback posture

Every wave is reversible by reverting the merge: the new code paths read from the registry, the legacy paths read from the env vars, and Waves 0–2 keep both paths working. Wave 3 narrows IAM and removes env vars — rolling that back requires re-merging the inline IAM blocks first (one PR), then redeploying the env vars (a second PR), then reverting the registry consumers (a third PR). The wave order is intentional: the riskiest cleanup happens last, against the most thoroughly-exercised registry path.
