// Feature: test-case-validity-analysis, Properties 3, 9, 10: Test case recommendation validation
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import { sanitizeRecommendations } from "@backend/handlers/analysis";
import type { Recommendation, RecommendationTarget, TestCaseTargetField } from "@shared/types";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** The five valid TestCaseTargetField values. */
const VALID_TEST_CASE_FIELDS: readonly TestCaseTargetField[] = [
  "successCriteria",
  "initialUtterance",
  "persona",
  "customerKnowledge",
  "goalDescription",
];

const VALID_TEST_CASE_FIELDS_SET: ReadonlySet<string> = new Set(VALID_TEST_CASE_FIELDS);

/** The five valid RecommendationTarget values. */
const VALID_TARGET_FIELDS: readonly RecommendationTarget[] = [
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
  "test_case",
];

/** Agent-targeted ToolSurface values. */
const TOOL_SURFACE_VALUES: readonly RecommendationTarget[] = [
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
];

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Non-empty trimmed string (suitable for targetName, currentText, etc.). */
const nonEmptyStringArb = fc
  .string({ minLength: 1, maxLength: 60 })
  .filter((s) => s.trim().length > 0);

/** Arbitrary valid TestCaseTargetField value. */
const testCaseFieldArb: fc.Arbitrary<TestCaseTargetField> = fc.constantFrom(
  ...VALID_TEST_CASE_FIELDS,
);

/** Arbitrary valid RecommendationTarget value. */
const targetFieldArb: fc.Arbitrary<RecommendationTarget> = fc.constantFrom(
  ...VALID_TARGET_FIELDS,
);

/** Arbitrary agent-targeted ToolSurface value. */
const agentTargetFieldArb: fc.Arbitrary<RecommendationTarget> = fc.constantFrom(
  ...TOOL_SURFACE_VALUES,
);

/** Arbitrary rootCauseCategory — either test_case_defect or some other value. */
const rootCauseCategoryArb: fc.Arbitrary<string> = fc.oneof(
  fc.constant("test_case_defect"),
  fc.constantFrom(
    "overlapping_tool_descriptions",
    "missing_disambiguation",
    "incorrect_tool_prioritization",
    "incomplete_tool_description",
    "system_prompt_gap",
    "missing_tool_instruction",
    "parameter_mismatch",
    "other",
  ),
);

/** Arbitrary non-defect rootCauseCategory. */
const nonDefectRootCauseArb: fc.Arbitrary<string> = fc.constantFrom(
  "overlapping_tool_descriptions",
  "missing_disambiguation",
  "incorrect_tool_prioritization",
  "incomplete_tool_description",
  "system_prompt_gap",
  "missing_tool_instruction",
  "parameter_mismatch",
  "other",
);

/** Arbitrary caseId. */
const caseIdArb = fc.string({ minLength: 1, maxLength: 30 }).filter((s) => s.trim().length > 0);

/**
 * Arbitrary well-formed test_case recommendation — valid testCaseField,
 * non-empty targetName, and at least one of currentText/suggestedText non-empty.
 */
const wellFormedTestCaseRecArb: fc.Arbitrary<Recommendation> = fc.record({
  targetField: fc.constant("test_case" as RecommendationTarget),
  targetName: nonEmptyStringArb,
  currentText: nonEmptyStringArb,
  suggestedText: nonEmptyStringArb,
  rationale: fc.string({ minLength: 0, maxLength: 60 }),
  testCaseField: testCaseFieldArb,
});

/**
 * Arbitrary agent-targeted recommendation (valid targetField from ToolSurface,
 * non-empty targetName, at least one of currentText/suggestedText non-empty).
 */
const agentRecArb: fc.Arbitrary<Recommendation> = fc.record({
  targetField: agentTargetFieldArb,
  targetName: nonEmptyStringArb,
  currentText: nonEmptyStringArb,
  suggestedText: fc.string({ minLength: 0, maxLength: 60 }),
  rationale: fc.string({ minLength: 0, maxLength: 60 }),
});

/**
 * Arbitrary recommendation with potentially invalid testCaseField for test_case recs
 * (to test that validation drops them), or with test_case targetField under non-defect
 * root cause categories.
 */
const mixedRecArb: fc.Arbitrary<Recommendation> = fc.oneof(
  // well-formed test_case rec
  wellFormedTestCaseRecArb,
  // test_case rec with missing testCaseField
  fc.record({
    targetField: fc.constant("test_case" as RecommendationTarget),
    targetName: nonEmptyStringArb,
    currentText: nonEmptyStringArb,
    suggestedText: nonEmptyStringArb,
    rationale: fc.string({ minLength: 0, maxLength: 60 }),
  }).map((r) => r as Recommendation),
  // test_case rec with invalid testCaseField
  fc.record({
    targetField: fc.constant("test_case" as RecommendationTarget),
    targetName: nonEmptyStringArb,
    currentText: nonEmptyStringArb,
    suggestedText: nonEmptyStringArb,
    rationale: fc.string({ minLength: 0, maxLength: 60 }),
    testCaseField: fc.constant("invalidField" as TestCaseTargetField),
  }),
  // agent-targeted rec (valid)
  agentRecArb,
  // rec with both currentText and suggestedText empty (should be dropped)
  fc.record({
    targetField: targetFieldArb,
    targetName: nonEmptyStringArb,
    currentText: fc.constant(""),
    suggestedText: fc.constant(""),
    rationale: fc.string({ minLength: 0, maxLength: 60 }),
  }).map((r) => r as Recommendation),
);

/** Arrays of 0..20 mixed recommendations. */
const recsArrayArb = fc.array(mixedRecArb, { minLength: 0, maxLength: 20 });

// ---------------------------------------------------------------------------
// Property 3: Test case recommendation validation invariant
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 3.3, 3.4, 11.3**
 *
 * Property 3: Test case recommendation validation invariant
 *
 * For any array of Recommendation records and any rootCauseCategory string,
 * after sanitizeRecommendations processing:
 *   (a) every surviving recommendation with targetField === "test_case" has a
 *       testCaseField value that is one of the five valid TestCaseTargetField values
 *   (b) no surviving recommendation with targetField === "test_case" exists when
 *       rootCauseCategory is not "test_case_defect"
 */
describe("Feature: test-case-validity-analysis, Property 3: Test case recommendation validation invariant", () => {
  it("(a) every surviving test_case rec has a valid testCaseField from the five valid values", () => {
    fc.assert(
      fc.property(caseIdArb, recsArrayArb, rootCauseCategoryArb, (caseId, recs, rootCause) => {
        const result = sanitizeRecommendations(caseId, recs, rootCause);

        for (const rec of result) {
          if (rec.targetField === "test_case") {
            expect(rec.testCaseField).toBeDefined();
            expect(VALID_TEST_CASE_FIELDS_SET.has(rec.testCaseField!)).toBe(true);
          }
        }
      }),
      { numRuns: 100 },
    );
  });

  it("(b) no surviving test_case rec exists when rootCauseCategory is not 'test_case_defect'", () => {
    fc.assert(
      fc.property(caseIdArb, recsArrayArb, nonDefectRootCauseArb, (caseId, recs, rootCause) => {
        const result = sanitizeRecommendations(caseId, recs, rootCause);

        const testCaseRecs = result.filter((r) => r.targetField === "test_case");
        expect(testCaseRecs).toHaveLength(0);
      }),
      { numRuns: 100 },
    );
  });

  it("both (a) and (b) hold simultaneously for any input combination", () => {
    fc.assert(
      fc.property(caseIdArb, recsArrayArb, rootCauseCategoryArb, (caseId, recs, rootCause) => {
        const result = sanitizeRecommendations(caseId, recs, rootCause);

        for (const rec of result) {
          if (rec.targetField === "test_case") {
            // (a) valid testCaseField
            expect(rec.testCaseField).toBeDefined();
            expect(VALID_TEST_CASE_FIELDS_SET.has(rec.testCaseField!)).toBe(true);
            // (b) only exists with test_case_defect root cause
            expect(rootCause).toBe("test_case_defect");
          }
        }
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 9: Valid test_case_defect analysis preserves test_case recommendations
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 11.2**
 *
 * Property 9: Valid test_case_defect analysis preserves test_case recommendations
 *
 * When rootCauseCategory IS "test_case_defect" and a test_case recommendation
 * has a valid testCaseField, non-empty targetName, and at least one of
 * currentText/suggestedText is non-empty, the recommendation survives sanitization.
 */
describe("Feature: test-case-validity-analysis, Property 9: Valid test_case_defect analysis preserves test_case recommendations", () => {
  it("well-formed test_case recs survive when rootCauseCategory is 'test_case_defect'", () => {
    fc.assert(
      fc.property(
        caseIdArb,
        fc.array(wellFormedTestCaseRecArb, { minLength: 1, maxLength: 10 }),
        (caseId, recs) => {
          const result = sanitizeRecommendations(caseId, recs, "test_case_defect");

          // At least one test_case rec should survive
          const testCaseRecs = result.filter((r) => r.targetField === "test_case");
          expect(testCaseRecs.length).toBeGreaterThanOrEqual(1);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("each individual well-formed test_case rec survives sanitization under test_case_defect", () => {
    fc.assert(
      fc.property(caseIdArb, wellFormedTestCaseRecArb, (caseId, rec) => {
        const result = sanitizeRecommendations(caseId, [rec], "test_case_defect");

        // The single well-formed rec should survive
        expect(result).toHaveLength(1);
        expect(result[0].targetField).toBe("test_case");
        expect(result[0].testCaseField).toBe(rec.testCaseField);
      }),
      { numRuns: 100 },
    );
  });

  it("well-formed test_case recs mixed with agent recs all survive under test_case_defect", () => {
    fc.assert(
      fc.property(
        caseIdArb,
        fc.array(wellFormedTestCaseRecArb, { minLength: 1, maxLength: 5 }),
        fc.array(agentRecArb, { minLength: 0, maxLength: 5 }),
        (caseId, testCaseRecs, agentRecs) => {
          const allRecs = [...testCaseRecs, ...agentRecs];
          const result = sanitizeRecommendations(caseId, allRecs, "test_case_defect");

          // All well-formed test_case recs should survive
          const survivingTestCase = result.filter((r) => r.targetField === "test_case");
          expect(survivingTestCase.length).toBe(testCaseRecs.length);
        },
      ),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 10: successCriteria currentText is non-empty
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 11.6**
 *
 * Property 10: successCriteria currentText is non-empty
 *
 * For any test_case recommendation with testCaseField === "successCriteria"
 * that survives sanitization, currentText should be non-empty (a test case
 * always has at least one criterion). This is an application-level invariant —
 * sanitizeRecommendations won't drop a rec just because currentText is empty
 * if suggestedText is non-empty. Test that if currentText AND suggestedText
 * are both non-empty, the rec is preserved (and currentText remains non-empty).
 */
describe("Feature: test-case-validity-analysis, Property 10: successCriteria currentText is non-empty", () => {
  /**
   * Arbitrary test_case recommendation specifically targeting successCriteria
   * with both currentText and suggestedText non-empty.
   */
  const successCriteriaRecArb: fc.Arbitrary<Recommendation> = fc.record({
    targetField: fc.constant("test_case" as RecommendationTarget),
    targetName: nonEmptyStringArb,
    currentText: nonEmptyStringArb,
    suggestedText: nonEmptyStringArb,
    rationale: fc.string({ minLength: 0, maxLength: 60 }),
    testCaseField: fc.constant("successCriteria" as TestCaseTargetField),
  });

  it("successCriteria recs with non-empty currentText and suggestedText survive and preserve non-empty currentText", () => {
    fc.assert(
      fc.property(caseIdArb, successCriteriaRecArb, (caseId, rec) => {
        const result = sanitizeRecommendations(caseId, [rec], "test_case_defect");

        // The rec should survive
        expect(result).toHaveLength(1);
        expect(result[0].targetField).toBe("test_case");
        expect(result[0].testCaseField).toBe("successCriteria");
        // currentText must be non-empty after sanitization
        expect(result[0].currentText.length).toBeGreaterThan(0);
      }),
      { numRuns: 100 },
    );
  });

  it("any surviving test_case rec with testCaseField === 'successCriteria' has non-empty currentText when both texts were non-empty", () => {
    fc.assert(
      fc.property(
        caseIdArb,
        fc.array(successCriteriaRecArb, { minLength: 1, maxLength: 10 }),
        fc.array(agentRecArb, { minLength: 0, maxLength: 5 }),
        (caseId, scRecs, agentRecs) => {
          const allRecs = [...scRecs, ...agentRecs];
          const result = sanitizeRecommendations(caseId, allRecs, "test_case_defect");

          // Filter to surviving successCriteria recs
          const survivingSC = result.filter(
            (r) => r.targetField === "test_case" && r.testCaseField === "successCriteria",
          );

          for (const rec of survivingSC) {
            expect(rec.currentText.length).toBeGreaterThan(0);
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("successCriteria rec count in output matches input count when all are well-formed under test_case_defect", () => {
    fc.assert(
      fc.property(
        caseIdArb,
        fc.array(successCriteriaRecArb, { minLength: 1, maxLength: 8 }),
        (caseId, recs) => {
          const result = sanitizeRecommendations(caseId, recs, "test_case_defect");

          const survivingSC = result.filter(
            (r) => r.targetField === "test_case" && r.testCaseField === "successCriteria",
          );
          expect(survivingSC.length).toBe(recs.length);
        },
      ),
      { numRuns: 100 },
    );
  });
});
