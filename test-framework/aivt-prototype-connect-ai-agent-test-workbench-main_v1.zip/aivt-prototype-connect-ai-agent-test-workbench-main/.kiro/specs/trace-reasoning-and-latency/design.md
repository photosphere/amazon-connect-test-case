# Design Document: Trace Reasoning and Latency

## Overview

This feature extends the Connect Agent Test Platform to surface three new data dimensions from the Q in Connect `ListSpans` API that the platform currently discards:

1. **Reasoning** — the agent's internal chain-of-thought (distinct from customer-facing text)
2. **Per-step latency** — wall-clock `durationMs` derived from span `startTimestamp`/`endTimestamp`
3. **Inference metadata** — token usage, model id, TTFT, finish reason, prompt identity, system instructions

The data flows through four layers: parsing (Span_Parser), persistence (DynamoDB TRACE row), presentation (Timeline_Transcript), and downstream analytics (failure-analysis and suite-recommendation prompts). The design preserves backward compatibility with pre-feature TRACE rows and does not touch the three Bedrock pass/fail judges.

A secondary change (Requirement 14) corrects the Helpfulness judge's `{context}` renderer to include same-turn tool calls, fixing a scoring defect where "Let me transfer you" + `Escalate` was graded as an unfulfilled promise.

## Architecture

```mermaid
flowchart TD
    subgraph Ingestion
        LS[Q in Connect ListSpans API]
        SP[Span_Parser<br/>span-parser.ts]
    end

    subgraph Persistence
        DDB[(DynamoDB<br/>TRACE row)]
    end

    subgraph Presentation
        TT[TimelineTranscript<br/>React component]
    end

    subgraph Analytics
        FA[Failure Analysis<br/>analysis.ts]
        SR[Suite Recommend<br/>suite-recommend.ts]
        PR[Prompt_Registry<br/>versioned entries]
    end

    subgraph Judges ["Judges (unchanged)"]
        JPR[Judge Prompt Renderer<br/>judge-prompt-rendering.ts]
    end

    LS --> SP
    SP --> DDB
    DDB --> TT
    DDB --> FA
    DDB --> SR
    FA --> PR
    SR --> PR
    JPR -->|R14: same-turn tool calls| TT
```

### Data Flow

1. `ListSpans` returns raw spans with `reasoning.value`, timestamps, and inference attributes.
2. `parseSpansToTrace` extracts reasoning, computes `durationMs`, builds `InferenceMetadata`.
3. `writeExecutionTrace` serializes `steps[]` (including new fields) to a single DynamoDB item.
4. `getExecutionTrace` deserializes; old rows missing the new fields naturally map to `undefined`.
5. `TimelineTranscript` renders reasoning rows, duration labels, and collapsed inference-details.
6. `analysis.ts` and `suite-recommend.ts` include reasoning in the user-message sections sent to Bedrock.
7. `judge-prompt-rendering.ts` adds same-turn tool calls to the Helpfulness per-turn `{context}`.

## Components and Interfaces

### 1. Extended Type Interfaces (`src/shared/types.ts`)

```typescript
/** New interface — inference-level metadata from ListSpans. */
export interface InferenceMetadata {
  usageInputTokens?: number;
  usageOutputTokens?: number;
  usageTotalTokens?: number;
  requestModel?: string;
  requestMaxTokens?: number;
  temperature?: number;
  timeToFirstTokenMs?: number;
  responseFinishReasons?: string[];
  promptArn?: string;
  promptId?: string;
  promptName?: string;
  promptVersion?: number;
  aiAgentVersion?: number;
  /** Joined from attributes.systemInstructions[].text.value with "\n\n". */
  systemInstructions?: string;
}

/** Additions to ExecutionStep (existing fields unchanged). */
export interface ExecutionStep {
  // ... existing fields ...
  /** Wall-clock duration of this span in whole milliseconds (non-negative). */
  durationMs?: number;
  /** Agent's chain-of-thought reasoning (distinct from customer-facing text). */
  reasoning?: string;
  /** Inference-level metadata (only on type === "inference" steps). */
  inferenceMetadata?: InferenceMetadata;
}
```

### 2. Extended Span Parser Interfaces (`src/backend/orchestration/span-parser.ts`)

```typescript
/** Addition to RawSpanValue — the reasoning block Q in Connect surfaces. */
interface RawSpanValue {
  // ... existing text, toolUse, toolResult ...
  reasoning?: { value?: string };
}

/** Additions to RawSpanAttributes — inference metadata source fields. */
interface RawSpanAttributes {
  // ... existing fields ...
  usageInputTokens?: unknown;
  usageOutputTokens?: unknown;
  usageTotalTokens?: unknown;
  requestModel?: unknown;
  requestMaxTokens?: unknown;
  temperature?: unknown;
  timeToFirstTokenMs?: unknown;
  responseFinishReasons?: unknown;
  promptArn?: unknown;
  promptId?: unknown;
  promptName?: unknown;
  promptVersion?: unknown;
  aiAgentVersion?: unknown;
  systemInstructions?: Array<{ text?: { value?: unknown } }>;
}
```

### 3. Span Parser Logic Changes

Three new pure extraction helpers added to `parseSpansToTrace`:

| Helper | Responsibility | Returns |
|--------|---------------|---------|
| `extractReasoning(messages)` | Concatenates valid `reasoning.value` strings from `outputMessages` with `"\n"` separator, skipping invalid entries | `string \| undefined` |
| `computeDurationMs(startTimestamp, endTimestamp)` | Parses timestamps, returns rounded non-negative integer or `undefined` | `number \| undefined` |
| `extractInferenceMetadata(attrs)` | Type-checks each source field, builds `InferenceMetadata` or returns `undefined` | `InferenceMetadata \| undefined` |

Each helper is a pure function over its inputs — no I/O, no side effects beyond `console.warn` for the negative-duration case.

### 4. Trace Persistence (`src/backend/services/dynamodb.ts`)

No schema change to the DynamoDB item. The new fields live inside the JSON-serialized `steps` blob. A 350 KB truncation guard on `systemInstructions` prevents oversized items from hitting the 400 KB DynamoDB limit.

### 5. Timeline Transcript (`TimelineTranscript.tsx`)

New sub-components:

| Component | Purpose |
|-----------|---------|
| `ReasoningRow` | Renders a `Reasoning` row with lavender background and `pre-wrap` whitespace |
| `DurationLabel` | Formats `durationMs` as `725 ms` or `1.6 s` |
| `InferenceDetailsDisclosure` | Cloudscape `ExpandableSection` with key-value metadata |
| `SystemPromptDisclosure` | Nested collapsed disclosure for `systemInstructions` |

The existing `ReasoningStepRow` for inference steps splits into two DOM rows when `reasoning` is present (reasoning-first, agent-reply second) and relabels the agent-facing text as `Agent reply`.

### 6. Recommendation Engine Changes

**Per-case (`analysis.ts`)**: `buildAnalysisPrompt` gains an optional `## Reasoning trace` section appended to the user message when at least one step carries reasoning. Format:

```
## Reasoning trace
[step 2 · 2025-01-15T10:30:01.000Z]
The customer is asking for their mortgage rate...

[step 5 · 2025-01-15T10:30:04.000Z]
I need to verify their identity before...
```

**Per-suite (`suite-recommend.ts`)**: The per-case section in the suite user-message embeds the same formatted reasoning block per failed case.

Both changes are registered as forward Prompt_Registry versions.

### 7. Helpfulness Context Fix (`judge-prompt-rendering.ts`)

`renderContextForAssistantTurn` is modified to include same-turn tool calls after the `Assistant:` line. The change applies only to the Helpfulness `{context}` — GoalSuccessRate (full conversation) and ToolSelectionAccuracy (strictly-prefix) are unchanged.

## Data Models

### InferenceMetadata (new)

| Field | Type | Source attribute | Notes |
|-------|------|-----------------|-------|
| `usageInputTokens` | `number?` | `attributes.usageInputTokens` | Input token count |
| `usageOutputTokens` | `number?` | `attributes.usageOutputTokens` | Output token count |
| `usageTotalTokens` | `number?` | `attributes.usageTotalTokens` | Total token count |
| `requestModel` | `string?` | `attributes.requestModel` | Bedrock model ID |
| `requestMaxTokens` | `number?` | `attributes.requestMaxTokens` | Max tokens configured |
| `temperature` | `number?` | `attributes.temperature` | Sampling temperature |
| `timeToFirstTokenMs` | `number?` | `attributes.timeToFirstTokenMs` | Time to first token |
| `responseFinishReasons` | `string[]?` | `attributes.responseFinishReasons` | Finish reasons array |
| `promptArn` | `string?` | `attributes.promptArn` | Prompt ARN |
| `promptId` | `string?` | `attributes.promptId` | Prompt UUID |
| `promptName` | `string?` | `attributes.promptName` | Prompt display name |
| `promptVersion` | `number?` | `attributes.promptVersion` | Prompt version number |
| `aiAgentVersion` | `number?` | `attributes.aiAgentVersion` | AI Agent version |
| `systemInstructions` | `string?` | `attributes.systemInstructions[].text.value` | Joined with `"\n\n"` |

### DynamoDB TRACE Row (unchanged top-level schema)

| Attribute | Type | Notes |
|-----------|------|-------|
| `PK` | `string` | `RUN#{runId}#CASE#{caseId}` |
| `SK` | `string` | `TRACE` |
| `sessionId` | `string` | |
| `aiAgentName` | `string?` | |
| `aiAgentType` | `string?` | |
| `toolSequence` | `string[]` | |
| `steps` | `string` | JSON blob — now includes `durationMs`, `reasoning`, `inferenceMetadata` per step |
| `capturedAt` | `string` | ISO 8601 |

### Prompt_Registry Version Additions

| promptKey | Change | New version |
|-----------|--------|-------------|
| `failure_analysis` | `defaultText` updated to document the reasoning-trace section | Forward version (n+1) |
| `suite_recommendation` | `defaultText` updated to document reasoning inclusion | Forward version (n+1) |
| `judge_helpfulness` | Bump only if fixture re-render shows byte-different output | Conditional forward version |



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Reasoning extraction preserves verbatim content

*For any* non-empty string `s` placed as a single `reasoning.value` entry on a raw inference span's `outputMessages[].values[]`, parsing that span SHALL produce a step whose `reasoning` field is strictly equal (`===`) to `s` — preserving whitespace, newlines, tabs, unicode, and embedded punctuation without truncation.

**Validates: Requirements 1.1, 1.7**

### Property 2: Multi-entry reasoning concatenation

*For any* array of 2+ non-empty strings placed as `reasoning.value` entries on a single inference span (interspersed with invalid entries — null, empty, whitespace-only, non-string), parsing SHALL produce a step whose `reasoning` field equals the valid entries joined in array order with `"\n"`, with no leading separator, no trailing separator, and no adjacent duplicate separators.

**Validates: Requirements 1.2**

### Property 3: Invalid reasoning yields undefined

*For any* raw span whose `outputMessages[].values[].reasoning.value` entries are all absent, empty, whitespace-only, or non-string, parsing SHALL produce a step whose `reasoning` field is strictly `undefined` (not `null`, not `""`).

**Validates: Requirements 1.3**

### Property 4: Text and reasoning are independent

*For any* inference span carrying both a valid `text.value` string and a valid `reasoning.value` string, parsing SHALL produce a step where `step.text` equals the text input and `step.reasoning` equals the reasoning input, and modifying one source field (in a hypothetical second parse) does not affect the other output field.

**Validates: Requirements 1.4**

### Property 5: durationMs is non-negative or undefined

*For any* raw span, the parsed step's `durationMs` is either `undefined` (when timestamps are missing or unparseable) or a non-negative integer equal to `Math.round(Math.max(0, Date.parse(endTimestamp) - Date.parse(startTimestamp)))` when both timestamps are finite.

**Validates: Requirements 2.1, 2.7**

### Property 6: Synthetic steps have undefined durationMs

*For any* step whose `spanName` is `"inference_tool_use"` or `"synthetic_control_tool"`, the step's `durationMs` SHALL be strictly `undefined`.

**Validates: Requirements 2.5, 2.6**

### Property 7: InferenceMetadata contains exactly the valid typed fields

*For any* inference span whose `attributes` carry a random subset of the 14 metadata source fields (some matching expected types, some mismatched), parsing SHALL produce an `inferenceMetadata` object containing exactly the type-matching fields and no others — or `undefined` when zero fields match.

**Validates: Requirements 3.1, 3.7**

### Property 8: systemInstructions join preserves content

*For any* array of `systemInstructions` entries containing a mix of valid `text.value` strings and invalid entries, parsing SHALL produce an `inferenceMetadata.systemInstructions` equal to the valid strings joined with `"\n\n"` (byte-for-byte, no trim, no normalization), or `undefined` when the filtered list is empty.

**Validates: Requirements 3.2, 3.6**

### Property 9: inferenceMetadata absent on non-inference steps

*For any* step whose `type` is not `"inference"`, the step's `inferenceMetadata` SHALL be strictly `undefined`.

**Validates: Requirements 3.4**

### Property 10: Persistence round-trip

*For any* valid `ExecutionTrace` whose steps carry arbitrary combinations of `durationMs`, `reasoning`, and `inferenceMetadata` (including `undefined` values), writing via `writeExecutionTrace` and reading back via `getExecutionTrace` SHALL produce an `ExecutionTrace` whose every step is deep-equal to the input on those three fields.

**Validates: Requirements 4.3**

### Property 11: Duration label formatting

*For any* integer `d` in `[0, 86400000]`: if `d < 1000`, the formatted label is `"${d} ms"`; if `d >= 1000`, the formatted label is `"${(d / 1000).toFixed(1)} s"` using half-up rounding. The function is total and never throws.

**Validates: Requirements 6.1**

### Property 12: Failure analysis prompt deterministic with reasoning

*For any* `ExecutionTrace` with at least one step carrying non-empty `reasoning`, the rendered failure-analysis user message SHALL contain a `## Reasoning trace` section enumerating each reasoning step in chronological order, and calling the renderer twice on the same input SHALL produce byte-identical output.

**Validates: Requirements 9.1, 9.3, 9.4**

### Property 13: Failure analysis prompt backward compatibility

*For any* `ExecutionTrace` where no step carries a non-empty `reasoning` value, the new renderer SHALL produce a user message byte-identical to the prior renderer for the same input.

**Validates: Requirements 9.2**

### Property 14: Suite prompt includes per-case reasoning

*For any* set of failed cases where at least one case's trace contains non-empty reasoning, the rendered suite-recommendation user message SHALL include that case's reasoning trace in chronological order within the per-case section.

**Validates: Requirements 10.1**

### Property 15: Suite prompt backward compatibility

*For any* set of failed cases where no case carries reasoning on any step, the new suite renderer SHALL produce a prompt byte-identical to the prior renderer.

**Validates: Requirements 10.2**

### Property 16: Helpfulness context includes same-turn tool calls

*For any* trace where an assistant turn has N tool calls (N >= 1), the new Helpfulness per-turn `{context}` SHALL differ from the prior renderer's output by exactly the addition of N `Action:` / `Tool:` line pairs (one per same-turn tool call, in chronological order) immediately after the `Assistant:` line — no other text additions, deletions, or reorderings.

**Validates: Requirements 14.1, 14.2, 14.8**

### Property 17: GoalSuccessRate and ToolSelectionAccuracy contexts unchanged

*For any* trace, the GoalSuccessRate `context` and the ToolSelectionAccuracy per-tool `context` produced by the new renderer SHALL be byte-identical to the prior renderer's output for the same input.

**Validates: Requirements 14.3**

## Error Handling

| Scenario | Handling |
|----------|----------|
| `reasoning.value` is non-string type | Silently skipped; field set to `undefined` |
| Negative timestamp difference | `durationMs` set to `0`; single `console.warn` |
| Missing/unparseable timestamps | `durationMs` left `undefined`; no throw |
| Metadata field wrong type | Individual field omitted from `InferenceMetadata`; no throw |
| `systemInstructions` > 350 KB after JSON serialization | Truncated with `"\n…[truncated]"` suffix; `console.warn` |
| Truncation routine throws | Hard write failure; error surfaced to caller |
| Lazy re-fetch ListSpans returns 0 spans or error | Existing TRACE row preserved; failure logged; no user-visible error |
| Lazy re-fetch DDB overwrite fails | Retry once; on second failure, render in-memory trace + inline notice |
| Pre-feature TRACE row read | New fields are `undefined`; UI shows empty states per R5.4/R6.3/R7.3 |
| Pre-feature ANALYSIS records read | Returned unchanged; no regeneration |
| `durationMs` outside [0, 86400000] in rendering | Duration label omitted; no throw |
| `timeToFirstTokenMs` outside [0, 600000] in rendering | TTFT label omitted; no throw |

## Testing Strategy

### Property-Based Tests (fast-check, minimum 100 iterations each)

The feature's pure logic layer — span parsing, duration computation, metadata extraction, prompt rendering, and persistence round-trip — is well-suited to property-based testing. Each property above maps to a single `fast-check` test tagged with the property number.

**Library**: `fast-check` (already available in the project's test dependencies)

**Tag format**: `Feature: trace-reasoning-and-latency, Property {N}: {title}`

**Test locations**:
- `tests/unit/properties/span-parser-reasoning.test.ts` — Properties 1–9
- `tests/unit/properties/trace-persistence-roundtrip.test.ts` — Property 10
- `tests/unit/properties/duration-formatting.test.ts` — Property 11
- `tests/unit/properties/analysis-prompt-reasoning.test.ts` — Properties 12–15
- `tests/unit/properties/helpfulness-context.test.ts` — Properties 16–17

### Unit Tests (example-based)

| Area | Test file | Coverage |
|------|-----------|----------|
| Span parser edge cases | `tests/unit/span-parser.test.ts` | Empty spans, multi-tool-use inference, missing attributes |
| Timeline rendering | `tests/unit/components/TimelineTranscript.test.tsx` | Reasoning row, duration label, metadata disclosure, empty states |
| Persistence truncation | `tests/unit/dynamodb-trace.test.ts` | 350 KB truncation, truncation failure |
| Backward compat | `tests/unit/analysis-compat.test.ts` | Pre-feature records returned unchanged |
| Helpfulness fix | `tests/unit/judge-prompt-rendering.test.ts` | Same-turn inclusion, skip rule preserved |

### Integration Tests

| Area | Coverage |
|------|----------|
| Lazy re-fetch | Mock ListSpans + DDB, verify re-fetch/skip/error paths |
| Prompt_Registry versions | Verify forward version on registry entries |
| End-to-end rendering | Verified-evidence fixture (`tmp/spans-mortgage-rate.json`) → full pipeline → assertions on all new fields |

### Fixture Tests

The verified-evidence fixture `tmp/spans-mortgage-rate.json` serves as the golden-path integration fixture. A dedicated test parses it through the new Span_Parser, verifies reasoning extraction, durationMs computation, and inferenceMetadata population against the known span attributes, then renders through the analysis prompt builder and judge-prompt renderer to assert byte-stability.
