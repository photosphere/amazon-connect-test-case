// @vitest-environment jsdom
/**
 * Component tests for the Prompt detail/edit page (task 13.10).
 *
 * Validates:
 *  - **Requirement 14.1** — the side-by-side editor renders with both
 *    `effectiveText` (editable) and `defaultText` (read-only) textareas
 *    seeded from the `getPrompt` response.
 *  - **Requirement 14.3** — Save issues `PUT` with only the changed
 *    fields (sparse body); modifying just the text sends `{ text }` and
 *    nothing else, even though `modelKey` and `inferenceParameters` are
 *    part of the editor's draft state.
 *  - **Requirement 14.4** — clicking "Revert to default" surfaces the
 *    confirmation modal; confirming it issues `resetPrompt(promptKey)`.
 *  - **Requirement 14.5** — `HistoryPanel` refetches detail + history
 *    in parallel when expanded.
 *  - **Requirement 14.6** — the active-runs Flashbar appears only when
 *    `getActiveRuns().count > 0` AT SUBMIT TIME, with the verbatim
 *    "Saved. The change will not affect runs already in progress…"
 *    message; runs that are zero at submit do not raise the Flashbar.
 *  - **Requirement R5.5** — switching to a model whose Model_Capability_
 *    Profile forbids a key currently in the inference-parameters draft
 *    drops that key from the draft and surfaces the warning Alert.
 *
 * Mocked seams: the typed `prompts` API client wrappers and the
 * `react-router-dom` hooks. The page's own state machinery, the
 * Cloudscape components, the ModelSelector / InferenceParameterForm /
 * HistoryPanel / RevertConfirmModal / ActiveRunsFlashbar all run as in
 * production.
 */

import React from 'react';
import {
  describe,
  it,
  expect,
  beforeAll,
  beforeEach,
  afterEach,
  vi,
} from 'vitest';
import {
  render,
  screen,
  waitFor,
  cleanup,
  fireEvent,
} from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

// ---------------------------------------------------------------------------
// Mock the API barrel BEFORE importing the page module.
// ---------------------------------------------------------------------------

const {
  listPromptsMock,
  getPromptMock,
  updatePromptMock,
  resetPromptMock,
  getHistoryMock,
  getActiveRunsMock,
} = vi.hoisted(() => ({
  listPromptsMock: vi.fn(),
  getPromptMock: vi.fn(),
  updatePromptMock: vi.fn(),
  resetPromptMock: vi.fn(),
  getHistoryMock: vi.fn(),
  getActiveRunsMock: vi.fn(),
}));

vi.mock('../../../src/frontend/src/api', () => {
  // Mirror the runtime ApiClientError / PromptApiError shapes the page
  // narrows on (`err instanceof PromptApiError` / `instanceof ApiClientError`).
  class MockApiClientError extends Error {
    public readonly status: number;
    public readonly retryable: boolean;
    public readonly code?: string;
    public readonly details?: Record<string, unknown>;
    constructor(
      status: number,
      message: string,
      retryable: boolean,
      options?: { code?: string; details?: Record<string, unknown> },
    ) {
      super(message);
      this.name = 'ApiClientError';
      this.status = status;
      this.retryable = retryable;
      this.code = options?.code;
      this.details = options?.details;
    }
  }
  class MockRuntimeConfigUnavailableError extends Error {
    constructor(message = 'Runtime configuration unavailable.') {
      super(message);
      this.name = 'RuntimeConfigUnavailableError';
    }
  }
  class MockPromptApiError extends Error {
    public readonly code: string;
    public readonly httpStatus: number;
    public readonly details?: Record<string, unknown>;
    constructor(args: {
      message: string;
      code: string;
      httpStatus: number;
      details?: Record<string, unknown>;
    }) {
      super(args.message);
      this.name = 'PromptApiError';
      this.code = args.code;
      this.httpStatus = args.httpStatus;
      this.details = args.details;
    }
  }
  return {
    apiClient: {
      get: vi.fn(),
      post: vi.fn(),
      put: vi.fn(),
      delete: vi.fn(),
    },
    ApiClientError: MockApiClientError,
    RuntimeConfigUnavailableError: MockRuntimeConfigUnavailableError,
    PromptApiError: MockPromptApiError,
    loadConfig: vi.fn(),
    getConfig: vi.fn(),
    getConfigStatus: vi.fn(),
    subscribeToNotifications: vi.fn(() => () => {}),
    notifyError: vi.fn(),
    listPrompts: listPromptsMock,
    getPrompt: getPromptMock,
    updatePrompt: updatePromptMock,
    resetPrompt: resetPromptMock,
    getHistory: getHistoryMock,
    getActiveRuns: getActiveRunsMock,
  };
});

// The page imports `PromptApiError` from `../api/prompts` directly;
// re-export the mocked class through that path so the `instanceof` narrow
// works on either import.
vi.mock('../../../src/frontend/src/api/prompts', async () => {
  const barrel: any = await import('../../../src/frontend/src/api');
  return {
    PromptApiError: barrel.PromptApiError,
    listPrompts: barrel.listPrompts,
    getPrompt: barrel.getPrompt,
    updatePrompt: barrel.updatePrompt,
    resetPrompt: barrel.resetPrompt,
    getHistory: barrel.getHistory,
    getActiveRuns: barrel.getActiveRuns,
  };
});

// ---------------------------------------------------------------------------
// Mock react-router-dom — see results-comparison.test.tsx for the rationale.
// `useParams` reads from a mutable `routerState.promptKey` so individual
// tests can drive the URL parameter without spinning up MemoryRouter (the
// frontend's nested React would otherwise produce two React copies).
// ---------------------------------------------------------------------------

const { routerState, navigateMock } = vi.hoisted(() => ({
  routerState: { promptKey: '' as string },
  navigateMock: vi.fn(),
}));

vi.mock('react-router-dom', () => ({
  useNavigate: () => navigateMock,
  useParams: () => ({ promptKey: routerState.promptKey }),
}));

// Page module is imported AFTER the vi.mock calls above so it picks up the
// mocked api barrel and the stubbed router hooks.
import { PromptDetailPage } from '../../../src/frontend/src/pages/PromptDetailPage';

// ---------------------------------------------------------------------------
// jsdom polyfills (mirrors results-comparison.test.tsx).
// ---------------------------------------------------------------------------

beforeAll(() => {
  const g = globalThis as unknown as {
    ResizeObserver?: unknown;
    IntersectionObserver?: unknown;
  };
  if (typeof g.ResizeObserver === 'undefined') {
    g.ResizeObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
    };
  }
  if (typeof g.IntersectionObserver === 'undefined') {
    g.IntersectionObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
      takeRecords(): unknown[] {
        return [];
      }
      readonly root = null;
      readonly rootMargin = '';
      readonly thresholds: ReadonlyArray<number> = [];
    };
  }
  if (typeof window.matchMedia !== 'function') {
    window.matchMedia = (query: string) =>
      ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => {},
        removeListener: () => {},
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => false,
      }) as MediaQueryList;
  }
});

beforeEach(() => {
  listPromptsMock.mockReset();
  getPromptMock.mockReset();
  updatePromptMock.mockReset();
  resetPromptMock.mockReset();
  getHistoryMock.mockReset();
  getActiveRunsMock.mockReset();
  navigateMock.mockReset();
  // Default the active-runs poll to zero so the active-runs Alert and
  // post-save Flashbar stay hidden unless a test explicitly opts in.
  getActiveRunsMock.mockResolvedValue({ count: 0 });
  // Default the history fetch to empty so HistoryPanel re-fetches do not
  // throw if a test happens to expand the panel.
  getHistoryMock.mockResolvedValue({ history: [] });
  routerState.promptKey = 'failure_analysis';
});

afterEach(() => {
  cleanup();
});

// ---------------------------------------------------------------------------
// Fixture builders
// ---------------------------------------------------------------------------

// `anthropic_claude_4x_lax` profile — what the API now returns for
// Claude Sonnet 4.6 and Haiku 4.5 (post-Wave-3 conformance probe split).
// The accepts list is the same as the strict profile; the difference is
// that `forbids[]` is empty because the wire silently drops the legacy
// sampling keys instead of 4xx-rejecting them. Both profiles still
// strip `temperature` from a draft on a model switch because
// `acceptsTopLevel = ["maxTokens"]` excludes it from the accept set —
// `computeRemovedKeys` keys off the accept set, not the forbid set.
const ANTHROPIC_LAX_PROFILE = {
  acceptsTopLevel: ['maxTokens'],
  acceptsAdditional: [] as string[],
  forbids: [] as string[],
  numericRanges: { maxTokens: { min: 1, max: 64_000 } },
};

const NOVA_PROFILE = {
  acceptsTopLevel: ['maxTokens', 'temperature', 'topP', 'stopSequences'],
  acceptsAdditional: ['topK'],
  forbids: [] as string[],
  numericRanges: {
    maxTokens: { min: 1, max: 5_000 },
    temperature: { min: 0, max: 1 },
    topP: { min: 0, max: 1 },
    topK: { min: 1, max: 500 },
  },
};

function buildAllowedModels() {
  return [
    {
      modelKey: 'claude_sonnet_4_6',
      displayName: 'Claude Sonnet 4.6',
      inferenceProfileId:
        'us.anthropic.claude-sonnet-4-6-20250514-v1:0',
      vendor: 'anthropic' as const,
      capabilityProfileKey: 'anthropic_claude_4x_lax',
      capabilityProfile: ANTHROPIC_LAX_PROFILE,
    },
    {
      modelKey: 'nova_pro',
      displayName: 'Nova Pro',
      inferenceProfileId:
        'us.amazon.nova-pro-v1:0',
      vendor: 'amazon' as const,
      capabilityProfileKey: 'amazon_nova',
      capabilityProfile: NOVA_PROFILE,
    },
  ];
}

function buildGetPromptResponse(overrides: Record<string, unknown> = {}) {
  return {
    promptKey: 'failure_analysis',
    name: 'Failure Analysis',
    description: 'Analyses failed cases.',
    category: 'analysis',
    defaultText:
      'You are an expert. Analyse {failureSummary} and respond with JSON.',
    effectiveText:
      'You are an expert. Analyse {failureSummary} and respond with JSON.',
    defaultModelKey: 'claude_sonnet_4_6',
    currentModelKey: 'claude_sonnet_4_6',
    inferenceParameters: { maxTokens: 1024 },
    inferenceParameterSchema: {
      maxTokens: { kind: 'integer', min: 1, max: 64_000, default: 1024 },
      temperature: { kind: 'number', min: 0, max: 1, default: 0.7 },
      topP: { kind: 'number', min: 0, max: 1, default: 0.9 },
      topK: { kind: 'integer', min: 1, max: 500, default: 50 },
    },
    placeholders: [
      {
        name: 'failureSummary',
        description: 'Summary of the failed cases',
        required: true,
      },
    ],
    allowedModels: buildAllowedModels(),
    lastModifiedAt: null,
    lastModifiedBy: null,
    version: 0,
    isOverridden: false,
    ...overrides,
  };
}

/**
 * Convenience: render the page and wait for the initial getPrompt fetch
 * to land so subsequent assertions exercise the loaded state.
 */
async function renderDetailPage() {
  const utils = render(<PromptDetailPage />);
  // Wait for the loaded view by asserting the H1 heading appears.
  // Cloudscape's RevertConfirmModal also mounts the prompt name inside
  // a hidden body region (the modal is rendered into the DOM even when
  // `visible={false}`), so we disambiguate by querying for the H1
  // specifically.
  await screen.findByRole('heading', { name: 'Failure Analysis', level: 1 });
  return utils;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('PromptDetailPage', () => {
  it('renders the side-by-side editor seeded with effectiveText and defaultText (R14.1)', async () => {
    getPromptMock.mockResolvedValueOnce(buildGetPromptResponse());

    await renderDetailPage();

    // Two `<textarea>` elements: one editable (effectiveText), one
    // read-only (defaultText). Both render the same fixture text in this
    // setup because the prompt is on its bundled default.
    const textareas = screen.getAllByRole(
      'textbox',
    ) as HTMLTextAreaElement[];
    // The page has at minimum two textareas (editor + viewer); the
    // InferenceParameterForm may add an Input role="textbox" for the
    // stringArray editor, but we asserted the prompt's schema has none
    // of those, so exactly two are expected.
    expect(textareas.length).toBe(2);
    const [editor, viewer] = textareas;
    expect(editor.value).toContain('Analyse {failureSummary}');
    expect(viewer.value).toContain('Analyse {failureSummary}');
    // The viewer is read-only per R14.1.
    expect(viewer).toHaveAttribute('readonly');
    expect(editor).not.toHaveAttribute('readonly');
    // The placeholders chip list renders the declared placeholder.
    expect(screen.getByText('{failureSummary}')).toBeInTheDocument();
    // The initial active-runs poll fired on mount.
    await waitFor(() => {
      expect(getActiveRunsMock).toHaveBeenCalledTimes(1);
    });
  });

  it('Save issues a sparse PUT body containing only the changed fields (R14.3)', async () => {
    getPromptMock.mockResolvedValueOnce(buildGetPromptResponse());
    // After save, fetchDetail re-issues getPrompt; resolve with the
    // updated effective text so the editor's draft can re-sync.
    getPromptMock.mockResolvedValueOnce(
      buildGetPromptResponse({
        effectiveText:
          'Updated text with {failureSummary} placeholder.',
        version: 1,
        isOverridden: true,
        lastModifiedAt: '2024-01-01T00:00:00.000Z',
        lastModifiedBy: 'sub-1234',
      }),
    );
    updatePromptMock.mockResolvedValueOnce({
      promptKey: 'failure_analysis',
      version: 1,
      lastModifiedAt: '2024-01-01T00:00:00.000Z',
      lastModifiedBy: 'sub-1234',
    });

    await renderDetailPage();

    // Mutate the editor's `<textarea>` with the new text. The Cloudscape
    // Textarea forwards native change events on the underlying element,
    // so a fireEvent.change triggers its onChange callback.
    const [editor] = screen.getAllByRole(
      'textbox',
    ) as HTMLTextAreaElement[];
    const newText = 'Updated text with {failureSummary} placeholder.';
    fireEvent.change(editor, { target: { value: newText } });

    // The Save button is disabled until the draft differs from the
    // server detail; once the text changes it becomes enabled.
    const saveButton = screen.getByRole('button', { name: /^save$/i });
    await waitFor(() => expect(saveButton).not.toBeDisabled());

    fireEvent.click(saveButton);

    // R14.3 sparse-body assertion: only the `text` field is present;
    // `modelKey` and `inferenceParameters` are omitted because they were
    // not changed.
    await waitFor(() => {
      expect(updatePromptMock).toHaveBeenCalledTimes(1);
    });
    expect(updatePromptMock).toHaveBeenCalledWith('failure_analysis', {
      text: newText,
    });

    // Post-save: the page refetches the detail, and because
    // getActiveRunsMock returns count=0 by default, the Flashbar stays
    // hidden.
    await waitFor(() => {
      expect(getPromptMock).toHaveBeenCalledTimes(2);
    });
    expect(
      screen.queryByText(
        /Saved\. The change will not affect runs already in progress/i,
      ),
    ).not.toBeInTheDocument();
  });

  it('Revert flow opens the modal and triggers resetPrompt on confirm (R14.4)', async () => {
    // The "Revert to default" button is disabled unless the prompt is
    // currently overridden — seed the fixture accordingly.
    getPromptMock.mockResolvedValueOnce(
      buildGetPromptResponse({
        isOverridden: true,
        version: 3,
        lastModifiedAt: '2024-01-01T00:00:00.000Z',
        lastModifiedBy: 'sub-1234',
      }),
    );
    // After reset, the page refetches; resolve with the bundled-default
    // shape so the editor returns to the default state.
    getPromptMock.mockResolvedValueOnce(buildGetPromptResponse());
    resetPromptMock.mockResolvedValueOnce({
      promptKey: 'failure_analysis',
      version: 0,
      resetAt: '2024-01-02T00:00:00.000Z',
    });

    await renderDetailPage();

    // Modal is hidden initially — the body copy "Revert to bundled default"
    // header is part of the Modal which Cloudscape mounts but only shows
    // when `visible`. Assert the modal's confirmation copy isn't visible
    // before clicking, then becomes visible after.
    expect(
      screen.queryByText(/Revert\s+.*Failure Analysis/i),
    ).not.toBeInTheDocument();

    // Click "Revert to default" → opens the RevertConfirmModal.
    fireEvent.click(
      screen.getByRole('button', { name: /revert to default/i }),
    );
    // Modal body copy appears now.
    expect(
      await screen.findByText(/discards the current override/i),
    ).toBeInTheDocument();

    // Click "Revert" inside the modal → triggers resetPrompt.
    // The modal's primary button is a Cloudscape Button labelled
    // "Revert"; getAllByRole returns the outer "Revert to default"
    // page button + the modal's "Revert" button. Pick the modal's
    // (the latter is uniquely "Revert" without "to default").
    const revertButtons = screen.getAllByRole('button', {
      name: /^revert$/i,
    });
    expect(revertButtons.length).toBeGreaterThanOrEqual(1);
    fireEvent.click(revertButtons[0]);

    await waitFor(() => {
      expect(resetPromptMock).toHaveBeenCalledTimes(1);
    });
    expect(resetPromptMock).toHaveBeenCalledWith('failure_analysis');
    // Page refetches the detail after reset.
    await waitFor(() => {
      expect(getPromptMock).toHaveBeenCalledTimes(2);
    });
  });

  it('HistoryPanel refetches the detail and history when expanded (R14.5)', async () => {
    getPromptMock.mockResolvedValueOnce(buildGetPromptResponse());
    // History panel's expand triggers a fresh detail fetch in parallel
    // with the history fetch (R14.5 staleness guard).
    getPromptMock.mockResolvedValueOnce(buildGetPromptResponse());
    getHistoryMock.mockResolvedValueOnce({
      history: [
        {
          version: 2,
          text: 'Older text {failureSummary}',
          modelKey: 'claude_sonnet_4_6',
          inferenceParameters: { maxTokens: 512 },
          modifiedAt: '2024-01-01T00:00:00.000Z',
          modifiedBy: 'sub-1234',
          changeKind: 'edit' as const,
        },
      ],
    });

    await renderDetailPage();

    // Pre-expand: getHistory has not been called yet — the panel only
    // fetches on first expand. getPrompt was called once on mount.
    expect(getHistoryMock).not.toHaveBeenCalled();
    expect(getPromptMock).toHaveBeenCalledTimes(1);

    // Expand the "Change history" ExpandableSection. Cloudscape renders
    // the section header as a button.
    const expander = screen.getByRole('button', { name: /change history/i });
    fireEvent.click(expander);

    // R14.5 staleness guard: expand triggers a parallel fetch of both
    // `GET /prompts/{key}` (the editor's "current version" badge) and
    // `GET /prompts/{key}/history` (the history list itself). Asserting
    // the call counts is robust to Cloudscape's internal table-rendering
    // states (loading vs. loaded) — what we care about is that the two
    // network calls fired in response to the expand event.
    await waitFor(() => {
      expect(getHistoryMock).toHaveBeenCalledWith('failure_analysis');
    });
    await waitFor(() => {
      // First getPrompt was the initial mount; the second is the
      // staleness-guard refetch the panel triggered via onExpand().
      expect(getPromptMock).toHaveBeenCalledTimes(2);
    });
  });

  it('renders the post-save active-runs Flashbar only when count > 0 at submit time (R14.6)', async () => {
    getPromptMock.mockResolvedValueOnce(buildGetPromptResponse());
    // After save, refetch returns the updated prompt.
    getPromptMock.mockResolvedValueOnce(
      buildGetPromptResponse({
        effectiveText: 'Edit {failureSummary}',
        version: 1,
        isOverridden: true,
      }),
    );
    updatePromptMock.mockResolvedValueOnce({
      promptKey: 'failure_analysis',
      version: 1,
      lastModifiedAt: '2024-01-01T00:00:00.000Z',
      lastModifiedBy: 'sub-1234',
    });
    // Override the default count=0 so this test exercises the count > 0
    // branch on both the mount poll and the pre-submit poll.
    getActiveRunsMock.mockReset();
    getActiveRunsMock.mockResolvedValue({ count: 2 });

    await renderDetailPage();

    // The mount-time active-runs Alert (`Test run in progress`) is shown
    // because count=2 from the initial poll.
    expect(
      await screen.findByText(/test run in progress/i),
    ).toBeInTheDocument();

    // Modify text and Save.
    const [editor] = screen.getAllByRole(
      'textbox',
    ) as HTMLTextAreaElement[];
    fireEvent.change(editor, {
      target: { value: 'Edit {failureSummary}' },
    });
    const saveButton = screen.getByRole('button', { name: /^save$/i });
    await waitFor(() => expect(saveButton).not.toBeDisabled());
    fireEvent.click(saveButton);

    // Post-save Flashbar — verbatim text per R14.6.
    expect(
      await screen.findByText(
        /Saved\. The change will not affect runs already in progress; it will apply to the next run started\./i,
      ),
    ).toBeInTheDocument();
    // The active-runs poll fired twice: once on mount, once before submit.
    expect(getActiveRunsMock).toHaveBeenCalledTimes(2);
  });

  it('switching to a model whose profile forbids a draft key strips the key and surfaces the warning Alert (R5.5)', async () => {
    // Seed the prompt with a Nova-only key (`temperature`) already in the
    // inference parameters so a switch to Claude (which forbids it) has
    // something to drop.
    getPromptMock.mockResolvedValueOnce(
      buildGetPromptResponse({
        currentModelKey: 'nova_pro',
        defaultModelKey: 'nova_pro',
        inferenceParameters: { maxTokens: 1024, temperature: 0.7 },
      }),
    );

    const { container } = await renderDetailPage();

    // Cloudscape Select renders the trigger as a `<button aria-haspopup=
    // "listbox">`. The popup opens on `mousedown` and options inside it
    // commit the selection on `mouseup` (production behaviour confirmed
    // by probing the rendered DOM in jsdom). Use the aria-haspopup
    // attribute selector to find the trigger unambiguously — the page
    // renders many other buttons (back-to-prompts, save, revert, etc.)
    // that we do not want to accidentally activate.
    const selectTrigger = container.querySelector(
      'button[aria-haspopup="listbox"]',
    ) as HTMLButtonElement | null;
    expect(selectTrigger).not.toBeNull();
    fireEvent.mouseDown(selectTrigger!);

    // The dropdown popup renders the list of options with role="option".
    // Find the Claude option by its text content (the displayName is
    // rendered verbatim inside the option's `<span>`).
    const claudeOption = await screen.findByRole('option', {
      name: /Claude Sonnet 4\.6/i,
    });
    // Cloudscape options commit on mouseUp rather than click in jsdom.
    fireEvent.mouseUp(claudeOption);

    expect(
      await screen.findByText(
        /Inference parameters dropped to match the new model/i,
      ),
    ).toBeInTheDocument();
    // The dropped key name appears inside the alert body.
    expect(screen.getByText(/temperature/)).toBeInTheDocument();
  });
});
