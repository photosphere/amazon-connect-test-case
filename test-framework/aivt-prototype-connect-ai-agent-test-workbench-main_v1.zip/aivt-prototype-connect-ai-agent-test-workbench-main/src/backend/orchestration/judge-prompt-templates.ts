/**
 * Verbatim Bedrock-judge prompt templates — single source of truth for the
 * three AWS-published built-in evaluator prompts the platform uses as its
 * scoring rubric.
 *
 * These string constants MUST match, byte-for-byte, the templates in the
 * steering doc at `.kiro/steering/bedrock-judge-prompts.md` (Requirement
 * 5.4). The steering doc records the source URL and the copy date next to
 * each template so any AWS revision surfaces as a code-review diff against
 * both this file and the steering doc.
 *
 * Placeholders interpolated by `judge-prompt-rendering.ts`:
 * - `GOAL_SUCCESS_RATE_TEMPLATE`: `{available_tools}`, `{context}`.
 * - `HELPFULNESS_TEMPLATE`:        `{context}`, `{assistant_turn}`.
 * - `TOOL_SELECTION_TEMPLATE`:     `{available_tools}`, `{context}`,
 *                                  `{tool_turn}`.
 *
 * All other `{...}` braces inside each template's embedded JSON-schema
 * block are part of the schema and pass through to the judge as literal
 * text. The judge client's `fillTemplate` uses `split(...).join(...)` so
 * only keys present in the `vars` map are substituted, leaving every
 * other `{...}` segment untouched.
 *
 * @module judge-prompt-templates
 */

/**
 * `Builtin.GoalSuccessRate` — session-level rubric. Maps `Yes`/`No` →
 * `[0.0, 1.0]` via `GOAL_SUCCESS_SCALE` in `evaluation-scoring.ts`.
 *
 * Source: https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html
 * Date of copy: 2026-06-05.
 */
export const GOAL_SUCCESS_RATE_TEMPLATE = `You are an objective judge evaluating the quality of an AI assistant as to whether a conversation between a User and the AI assistant successfully completed all User goals. You will be provided with:
1. The list of available tools the AI assistant can use. There are descriptions for each tool about when to use it and how to use it.
2. The complete conversation record with multiple turns including:
    - User messages (User:)
    - Assistant responses (Assistant:)
    - Tool selected by the assistant (Action:)
    - Tool outputs (Tool:)
3. The final assistant response that concludes the conversation.

Your task is to carefully analyze the conversation and determine if all User goals were successfully achieved. In order to achieve a User goal, the AI assistant usually need to use some tools and respond to User about the outcome. Please assess the goals one by one, following the steps below:
1. First, analyze the list of available tools, reason about what tools the AI assistant should use, and what response it should provide to the User in order to achieve the goal;
2. Next, check the conversation record and the final assistant response to decide whether the AI assistant used the expected tools and got the expected output, got the expected information, and responded to the User in the expected way. If the AI assistant did all expected work in the conversation record and provided an appropriate final response, the goal was achieved.
3. After judging about all the goals, decide whether the conversation achieved all user goals or not.

## Evaluation Rubric
- Yes: All user goals were achieved. The agent successfully completed all requested tasks, provided accurate information, and the user received satisfactory outcomes.
- No: Not all user goals were achieved. The agent failed to complete one or more requested tasks, provided incomplete/incorrect information, or the user's needs were not fully met.

**IMPORTANT**: The tool output ALWAYS takes priority over your own knowledge.

## Available tools
{available_tools}

## Conversation record
{context}

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Yes' or 'No'", "enum": ["Yes", "No"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}
Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (\`\`\`).`;

/**
 * `Builtin.Helpfulness` — per-assistant-turn rubric. Maps the seven-level
 * ordinal scale (`Not Helpful At All` … `Above And Beyond`) to `[0.0, 1.0]`
 * in steps of `1/6` via `HELPFULNESS_SCALE` in `evaluation-scoring.ts`.
 *
 * Source: https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html
 * Date of copy: 2026-06-05.
 *
 * Version bump (2026-06-12): {context} now includes same-turn tool calls
 * (Action: / Tool: lines) that fired in the same turn as the assistant
 * utterance being scored, so the judge can see that an assistant reply like
 * "Let me transfer you" was actually followed by an Escalate tool call.
 * Prior versions excluded these same-turn actions, causing the judge to
 * score fulfilled promises as low-helpfulness.
 */
export const HELPFULNESS_TEMPLATE = `You are an objective judge evaluating the helpfulness of an AI assistant's response from the user's perspective. Your task is to assess whether the assistant's turn moves the user closer to achieving or formulating their goals.

IMPORTANT: Evaluate purely from the user's perspective, without considering the factual accuracy or backend operations. Focus only on how the response helps the user progress towards their goals.

**IMPORTANT**: The tool output ALWAYS takes priority over your own knowledge.

Infer the user's goals purely based on the user's initial request, and any additional context they may provide afterwards.

# Conversation Context:
## Previous turns:
Note: The context below includes any tool actions (Action:/Tool: lines) that were taken in the same turn as the assistant response being evaluated. Consider these actions as evidence of whether the assistant followed through on its stated intent.
{context}

## Target turn to evaluate:
{assistant_turn}

# Evaluation Guidelines:
Rate the helpfulness of the assistant's turn using this scale:

0. Not Helpful At All
1. Very Unhelpful
2. Somewhat Unhelpful
3. Neutral/Mixed
4. Somewhat Helpful
5. Very Helpful
6. Above And Beyond

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Not Helpful At All', 'Very Unhelpful', 'Somewhat Unhelpful', 'Neutral/Mixed', 'Somewhat Helpful', 'Very Helpful' or 'Above And Beyond'", "enum": ["Not Helpful At All", "Very Unhelpful", "Somewhat Unhelpful", "Neutral/Mixed", "Somewhat Helpful", "Very Helpful", "Above And Beyond"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}

Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (\`\`\`).`;

/**
 * `Builtin.ToolSelectionAccuracy` — per-`execute_tool` rubric. Maps
 * `Yes`/`No` → `[0.0, 1.0]` via `TOOL_SELECTION_SCALE` in
 * `evaluation-scoring.ts`.
 *
 * Source: https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html
 * Date of copy: 2026-06-05.
 */
export const TOOL_SELECTION_TEMPLATE = `You are an objective judge evaluating if an AI assistant's action is justified at this specific point in the conversation.
## Available tool-calls
{available_tools}
## Previous conversation history
{context}
## Target tool-call to evaluate
{tool_turn}
## Evaluation Question:
Given the current state of the conversation, is the Agent justified in calling this specific action at this point in the conversation?
Consider:
1. Does this action reasonably address the user's current request or implied need?
2. Is the action aligned with the user's expressed or implied intent?
3. Are the minimum necessary parameters available to make the call useful?
4. Would a helpful assistant reasonably take this action to serve the user?
## Output Format:
First, provide a brief analysis of why this action is or is not justified at this point in the conversation.
Then, answer the evaluation question with EXACTLY ONE of these responses:
- Yes (if the action reasonably serves the user's intention at this point)
- No (if the action clearly does not serve the user's intention at this point)

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Yes' or 'No'", "enum": ["Yes", "No"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}
Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (\`\`\`).`;
