import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  resolve: {
    alias: [
      { find: '@shared', replacement: path.resolve(__dirname, 'src/shared') },
      { find: '@backend', replacement: path.resolve(__dirname, 'src/backend') },
      { find: '@frontend', replacement: path.resolve(__dirname, 'src/frontend') },
      // The frontend ships its own node_modules; when tests render frontend
      // components (e.g. tests/unit/frontend/*.test.tsx), the Cloudscape
      // components import React via `src/frontend/node_modules/react`, while
      // tests import React via the root `node_modules/react`. Two copies of
      // React in one render tree breaks hooks. Force every import of `react`
      // and `react-dom` (regardless of which package issues it) to resolve to
      // the root copy so there is exactly one instance.
      {
        find: /^react$/,
        replacement: path.resolve(__dirname, 'node_modules/react/index.js'),
      },
      {
        find: /^react\/jsx-runtime$/,
        replacement: path.resolve(__dirname, 'node_modules/react/jsx-runtime.js'),
      },
      {
        find: /^react\/jsx-dev-runtime$/,
        replacement: path.resolve(__dirname, 'node_modules/react/jsx-dev-runtime.js'),
      },
      {
        find: /^react-dom$/,
        replacement: path.resolve(__dirname, 'node_modules/react-dom/index.js'),
      },
      {
        find: /^react-dom\/client$/,
        replacement: path.resolve(__dirname, 'node_modules/react-dom/client.js'),
      },
      // Same problem for `react-router` and `react-router-dom`: when a page
      // module under `src/frontend/src/pages/*` imports them, Node's resolver
      // would otherwise pick up the nested `src/frontend/node_modules` copy
      // (which in turn imports its OWN nested `react`), giving us two React
      // copies in one render tree and breaking hooks. Pin every import of
      // these bare specifiers to the root copy.
      {
        find: /^react-router$/,
        replacement: path.resolve(__dirname, 'node_modules/react-router/dist/index.js'),
      },
      {
        find: /^react-router-dom$/,
        replacement: path.resolve(__dirname, 'node_modules/react-router-dom/dist/index.js'),
      },
      // Same deduplication for @testing-library packages — tests under
      // src/frontend/src/ would otherwise resolve from the nested
      // src/frontend/node_modules copy, which uses its own react-dom.
      {
        find: /^@testing-library\/react$/,
        replacement: path.resolve(__dirname, 'node_modules/@testing-library/react/dist/@testing-library/react.esm.js'),
      },
    ],
    dedupe: ['react', 'react-dom'],
  },
  test: {
    globals: true,
    environment: 'node',
    // Match both .test.ts and .test.tsx so component tests under
    // tests/unit/frontend can use JSX. Per-file environment is set via
    // `// @vitest-environment jsdom` at the top of frontend test files.
    include: ['tests/**/*.test.ts', 'tests/**/*.test.tsx', 'src/**/__tests__/*.property.ts', 'src/**/__tests__/*.test.ts', 'src/**/__tests__/*.test.tsx'],
    // Cloudscape ships ESM (.mjs/.js) modules under
    // `src/frontend/node_modules/@cloudscape-design/*` that import `react`.
    // Without inlining, Node's loader resolves their `react` import to the
    // nested `src/frontend/node_modules/react`, producing a second React copy
    // and breaking hooks. Inlining forces Vite to transform these modules so
    // the `react`/`react-dom` aliases above apply uniformly.
    server: {
      deps: {
        inline: [/@cloudscape-design\//, /@testing-library\//],
      },
    },
    coverage: {
      provider: 'v8',
      reporter: ['text', 'lcov'],
      include: ['src/**/*.ts', 'lib/**/*.ts'],
    },
  },
});
