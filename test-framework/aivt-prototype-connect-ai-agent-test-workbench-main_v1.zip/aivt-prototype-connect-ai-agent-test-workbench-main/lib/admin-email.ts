/**
 * Pure, deploy-time admin-email resolver/validator for the optional first-user
 * bootstrap.
 *
 * Resolves the optional `Admin_Email` deploy parameter into one of three
 * outcomes:
 *  - absent / empty / whitespace-only  -> `{ skip: true }` (deploy still
 *    succeeds, no Cognito user created — Requirement 7.1)
 *  - a valid email                      -> `{ email: <trimmed email> }`
 *  - a non-empty but invalid email      -> throws at synth (fails the deploy,
 *    creates nothing — Requirement 6.6)
 *
 * Validity is the spec's definition: a non-empty local part, a single "@"
 * separator, and a domain containing at least one ".".
 *
 * This module has NO AWS imports and is fully unit-testable without a deploy.
 *
 * Requirements: 6.6, 7.1
 */

/** Result of resolving the optional admin email. */
export type ParsedAdminEmail = { skip: true } | { email: string };

/**
 * Validate an already-trimmed, non-empty candidate against the spec's email
 * definition: exactly one "@", a non-empty local part, and a domain that
 * contains at least one "." with non-empty labels on either side of it.
 */
function isValidEmail(candidate: string): boolean {
  const atParts = candidate.split('@');
  if (atParts.length !== 2) {
    // Zero or more than one "@" separator.
    return false;
  }

  const [localPart, domain] = atParts;
  if (localPart.length === 0) {
    return false;
  }

  // Domain must contain at least one ".", and that "." must separate two
  // non-empty labels (so "a@b." and "a@.b" are rejected).
  const dotIndex = domain.indexOf('.');
  if (dotIndex <= 0 || dotIndex >= domain.length - 1) {
    return false;
  }

  // Reject any whitespace inside the address (it was trimmed at the edges,
  // but interior whitespace is never valid).
  if (/\s/.test(candidate)) {
    return false;
  }

  return true;
}

/**
 * Resolve the optional admin email into a create-or-skip-or-reject outcome.
 *
 * @param raw The raw `Admin_Email` value from CDK context/prop; may be
 *   undefined, empty, or whitespace-only.
 * @returns `{ skip: true }` when absent/empty/whitespace; otherwise
 *   `{ email }` with the trimmed address.
 * @throws Error if `raw` is non-empty but not a valid email address.
 */
export function parseAdminEmail(raw?: string): ParsedAdminEmail {
  if (typeof raw !== 'string') {
    return { skip: true };
  }

  const trimmed = raw.trim();
  if (trimmed.length === 0) {
    return { skip: true };
  }

  if (!isValidEmail(trimmed)) {
    throw new Error(
      `Invalid Admin_Email: "${raw}" is not a valid email address (expected a non-empty local part, a single "@", and a domain containing at least one "."). No Cognito user will be created.`
    );
  }

  return { email: trimmed };
}
