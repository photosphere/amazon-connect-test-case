# Implementation Plan: Implement Recommendations

## Overview

This plan implements the recommendation-to-action feature with two execution paths: Direct Apply (confirmation-gated writes to live agent config) and Multi-Variant Experiment (3 diverse variants generated via Bedrock, tested in parallel via Step Functions, compared in a Tournament View). Both paths are gated by `INSTANCE_MODE` at UI, API, and IAM layers.

Implementation proceeds bottom-up: shared types and pure logic modules first, then handlers and orchestration, then CDK infrastructure, then frontend components. Property-based tests validate core invariants alongside implementation.

## Tasks

- [x] 1. Set up shared types, interfaces, and constants
  - [x] 1.1 Define experiment and audit data model types
    - Add `ExperimentRecord`, `ExperimentStatus`, `AuditRecord`, `ApplyRecord`, `DriftedField`, `VariantConfig`, `VariantScore`, `TournamentSummary`, `CleanupResult` interfaces to `src/shared/types.ts`
    - Add `ExperimentCreateRequest`, `ExperimentCreateResponse`, `ApplyRecommendationsRequest`, `ApplyRecommendationsResponse` API request/response types
    - _Requirements: 12.1, 14.1, 14.2, 14.3, 14.4, 15.1_
  - [x] 1.2 Extend DynamoDB key pattern constants
    - Add `EXPERIMENT`, `APPLY_DIRECT`, `TENANT`, and `AUDIT` patterns to the existing `SK_PATTERNS` and `PK_PATTERNS` in `src/shared/constants.ts`
    - _Requirements: 3.5, 12.1, 15.2_

- [x] 2. Implement core pure logic modules
  - [x] 2.1 Implement drift detection module
    - Create `src/backend/orchestration/drift-detection.ts` with `checkDrift` pure function
    - Compares each recommendation's `currentText` against live agent field value character-for-character
    - Handles all four Tool_Surface types: `tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`
    - Returns `DriftCheckResult` with `hasDrift`, `driftedFields`, `cleanFields`
    - _Requirements: 3.6, 11.1, 11.2, 18.1_
  - [x] 2.2 Write property test for drift detection
    - **Property 1: Drift detection correctness**
    - **Validates: Requirements 3.6, 11.1, 11.2, 18.1**
  - [x] 2.3 Implement config writer module
    - Create `src/backend/orchestration/config-writer.ts` with `writeConfig` async function
    - Builds `UpdateAIAgent` payload for tool surface changes and `UpdateAIPrompt` payload for system_prompt changes
    - Single atomic call per API — all tool changes in one `UpdateAIAgent`, all prompt changes in one `UpdateAIPrompt`
    - Returns `WriteResult` with `newAgentVersionId`, `newPromptVersionId`
    - _Requirements: 3.1, 3.2, 3.3, 18.2_
  - [x] 2.4 Write property test for write payload purity
    - **Property 2: Write payload purity**
    - **Validates: Requirements 3.2, 18.2**
  - [x] 2.5 Implement variant selection module
    - Create `src/backend/orchestration/variant-selection.ts` with `selectWinningVariant` pure function
    - Deterministic selection: highest pass rate, tiebreak by avg goal success score
    - Excludes errored variants; returns null if all errored
    - _Requirements: 8.4, 18.5_
  - [x] 2.6 Write property test for winner selection determinism
    - **Property 4: Winner selection determinism and idempotence**
    - **Validates: Requirements 8.4, 18.5**
  - [x] 2.7 Implement recommendation structural validation
    - Create validation utility (can be in `src/backend/orchestration/validation.ts` or inline)
    - Validates `targetField` is one of 4 ToolSurface values, `targetName` non-empty, at least one of currentText/suggestedText non-empty
    - Validates tool_examples operation semantics (add/remove/replace)
    - _Requirements: 5.4, 13.1, 13.3_
  - [x] 2.8 Write property test for recommendation structural validation
    - **Property 7: Recommendation structural validation**
    - **Validates: Requirements 5.4, 13.1**
  - [x] 2.9 Implement score aggregation utility
    - Pure function computing passRate, avgGoalSuccessScore, avgHelpfulnessScore, avgToolAccuracyScore from TestCaseResult[]
    - Cases with undefined scores excluded from mean (not counted as 0)
    - _Requirements: 8.2_
  - [x] 2.10 Write property test for score aggregation correctness
    - **Property 8: Score aggregation correctness**
    - **Validates: Requirements 8.2**

- [x] 3. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Implement variant generation and system prompt safety
  - [x] 4.1 Implement system prompt safety validation
    - Create `src/backend/orchestration/system-prompt-safety.ts`
    - Validates dynamic parameters (`{{$.Custom.*}}`, `{{agent.*}}`, `{{session.*}}`) remain at end of prompt
    - Validates thinking/messaging blocks (`<thinking>`, `<messaging>` or equivalent delimiters) are byte-for-byte unchanged
    - Validates no new examples introduced into system prompt body
    - Falls back to treating entire prompt as editable (minus dynamic params) when no markers detected
    - _Requirements: 20.1, 20.2, 20.3, 20.5, 20.6_
  - [x] 4.2 Write property test for system prompt safety validation
    - **Property 6: System prompt safety validation**
    - **Validates: Requirements 20.1, 20.2, 20.3, 20.5, 20.6**
  - [x] 4.3 Implement variant generator module
    - Create `src/backend/orchestration/variant-generator.ts` with `generateVariants` async function
    - Calls Bedrock Converse with temperature=0.7, does NOT set topP (Sonnet 4.6 constraint)
    - Uses the variant generation prompt strategy from design (3 strategies: conciseness, example-heavy, restructured)
    - Validates each variant against structural constraints, surface scope containment, and system prompt safety
    - Retries once per failed variant before marking as failed
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 13.3, 20.4_
  - [x] 4.4 Write property test for variant surface scope containment
    - **Property 3: Variant surface scope containment**
    - **Validates: Requirements 5.3, 13.1, 13.3, 18.4**
  - [x] 4.5 Implement tournament summary generator
    - Create `src/backend/orchestration/tournament-summary.ts` with `generateTournamentSummary` async function
    - Calls Bedrock Converse with temperature=0, does NOT set topP
    - Winning variant computed deterministically via `selectWinningVariant`; AI only explains the result
    - Produces per-variant highlights (improved/regressed case lists)
    - _Requirements: 8.5, 17.4_

- [x] 5. Implement Lambda handlers
  - [x] 5.1 Implement apply-recommendations handler
    - Create `src/backend/handlers/apply-recommendations.ts`
    - Validates INSTANCE_MODE !== "production" → 403
    - Loads per-suite recommendations from DynamoDB
    - Resolves selected indices, calls GetAIAgent for live config
    - Runs drift detection; returns 409 with driftedFields on conflict
    - Calls config writer; persists audit record and apply record
    - Validates agentId belongs to configured assistantId
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 11.1, 14.1, 14.6, 15.1, 16.3, 19.3_
  - [x] 5.2 Write property test for production mode API enforcement
    - **Property 9: Production mode API enforcement**
    - **Validates: Requirements 19.3**
  - [x] 5.3 Write property test for agent-assistant ownership validation
    - **Property 10: Agent-assistant ownership validation**
    - **Validates: Requirements 16.3**
  - [x] 5.4 Implement experiment-create handler
    - Create `src/backend/handlers/experiment-create.ts`
    - Validates INSTANCE_MODE !== "production" → 403
    - Generates experimentId (UUID v4), loads recommendations
    - Persists experiment record with status "generating_variants"
    - Starts Experiment State Machine execution
    - Returns experimentId and status
    - _Requirements: 14.2, 6.6, 12.1, 19.3_
  - [x] 5.5 Implement experiment-get handler
    - Create `src/backend/handlers/experiment-get.ts`
    - Returns full experiment state: status, variant configs, run IDs, tournament summary
    - Reads from DynamoDB experiment record
    - _Requirements: 14.3, 12.1, 12.2, 12.3_
  - [x] 5.6 Implement experiment-apply handler
    - Create `src/backend/handlers/experiment-apply.ts`
    - Validates INSTANCE_MODE !== "production" → 403
    - Loads variant config for specified variant letter
    - Runs same write logic as direct apply: drift detection → config writer → audit
    - Updates experiment record with appliedVariant and appliedAt
    - _Requirements: 9.2, 9.3, 9.5, 14.4, 19.3_
  - [x] 5.7 Implement experiment-cleanup handler
    - Create `src/backend/handlers/experiment-cleanup.ts`
    - Deletes all temporary agents via DeleteAIAgent
    - Retries once with exponential backoff per agent
    - Updates experiment record with cleanupStatus
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_
  - [x] 5.8 Write property test for cleanup completeness
    - **Property 5: Cleanup completeness**
    - **Validates: Requirements 10.1, 18.3**
  - [x] 5.9 Implement audit handler
    - Create `src/backend/handlers/audit.ts`
    - GET /audit endpoint returning tenant's audit records in reverse chronological order
    - Paginated at 50 records per page with nextToken
    - _Requirements: 15.2, 15.3, 15.4_

- [x] 6. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Implement CDK construct and state machine
  - [x] 7.1 Implement Experiment State Machine definition
    - Create `src/backend/orchestration/experiment-state-machine.ts`
    - Define Step Functions flow: GenerateVariants → ValidateVariants → CreateTempAgents → Parallel(3×RunSuite) → WaitForCompletion → GenerateSummary → Cleanup → MarkCompleted
    - Parallel state for 3 variant runs with individual catch handlers
    - Cleanup runs unconditionally regardless of variant success/failure
    - Error handling: rollback agents on creation failure, continue on single variant failure
    - _Requirements: 7.1, 7.2, 7.5, 7.6, 10.4_
  - [x] 7.2 Implement CDK construct
    - Create `lib/implement-recommendations-construct.ts`
    - Creates all Lambda functions (apply-recommendations, experiment-create, experiment-get, experiment-apply, experiment-cleanup, audit)
    - Creates API Gateway routes with Cognito authorizer
    - Creates Experiment State Machine
    - Scopes IAM roles to assistant ARN (no wildcard resources)
    - Conditionally omits write IAM actions when `instanceMode === "production"`
    - Wires DynamoDB table access, Step Functions trigger permissions
    - _Requirements: 16.1, 16.2, 16.3, 16.4, 19.7_
  - [x] 7.3 Integrate construct into main stack
    - Import and instantiate `ImplementRecommendationsConstruct` in the main CDK stack
    - Pass existing table, API, authorizer, state machine ARN, and instance mode
    - Wire INSTANCE_MODE into frontend config.json build
    - _Requirements: 19.1, 19.8_

- [x] 8. Implement frontend components
  - [x] 8.1 Implement ImplementButton and ModeSelector components
    - Create `src/frontend/src/components/ImplementRecommendations/ImplementButton.tsx`
    - Create `src/frontend/src/components/ImplementRecommendations/ModeSelector.tsx`
    - ImplementButton hidden when INSTANCE_MODE=production or no recommendations or run still running
    - ModeSelector presents "Apply directly" and "Advanced: Multi-variant experiment" options
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 19.2_
  - [x] 8.2 Implement ConfirmationDialog component
    - Create `src/frontend/src/components/ImplementRecommendations/ConfirmationDialog.tsx`
    - Side-by-side diff viewer grouped by Tool_Surface and tool name
    - Displays agent name and ID at top, warning banner, Cancel/Confirm actions
    - Handles add (green highlight), remove (red highlight), replace operations
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7_
  - [x] 8.3 Implement ConflictResolution component
    - Create `src/frontend/src/components/ImplementRecommendations/ConflictResolution.tsx`
    - Shows drifted fields: field name, expected value, actual current value
    - Three options: "Apply anyway", "Cancel", "Re-analyze"
    - _Requirements: 11.2, 11.3, 11.4_
  - [x] 8.4 Implement ExperimentProgress component
    - Create `src/frontend/src/components/ImplementRecommendations/ExperimentProgress.tsx`
    - Loading state with "Generating experiment variants..." message
    - Progress indicator during variant creation and test execution
    - "Experiment is running. You can leave this page..." message
    - _Requirements: 5.6, 7.3, 12.2_
  - [x] 8.5 Implement TournamentView component
    - Create `src/frontend/src/components/ImplementRecommendations/TournamentView.tsx`
    - 4-column comparison: Baseline, Variant A, Variant B, Variant C
    - Aggregate scores per column (pass rate, avg goal success, avg helpfulness, avg tool accuracy)
    - Per-case rows with status change highlighting (failed→passed = green)
    - "Recommended" badge on best-performing variant
    - AI-generated summary section; error state for failed variants
    - "Apply to Agent" button per variant column
    - "Retry summary" button if Bedrock summary call failed
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7, 9.1, 17.1, 17.4_
  - [x] 8.6 Implement post-apply re-run prompt and instance mode badge
    - Add success notification with "Re-run Suite" button after apply
    - Add "Production (read-only)" or "Development" badge to application header based on INSTANCE_MODE
    - _Requirements: 4.1, 4.2, 4.3, 19.5, 19.6_
  - [x] 8.7 Wire frontend components into existing pages
    - Add ImplementButton to Run Dashboard (RecommendedChangesPanel)
    - Add ImplementButton to Failure Analysis View per-suite section
    - Add "Experiment Results" link on Run Dashboard for runs with experiments
    - Add routing for TournamentView page
    - _Requirements: 1.1, 1.2, 8.7, 12.2_

- [x] 9. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document (10 properties total)
- Unit tests validate specific examples and edge cases
- The Sonnet 4.6 constraint (only set temperature, never topP) applies to variant-generator.ts and tournament-summary.ts
- INSTANCE_MODE gating is enforced at three layers: UI (hide buttons), API (403 response), IAM (omit permissions)
- All Bedrock calls use Converse API; temporary agents are never routed to by the assistant

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1", "1.2"] },
    { "id": 1, "tasks": ["2.1", "2.5", "2.7", "2.9"] },
    { "id": 2, "tasks": ["2.2", "2.3", "2.6", "2.8", "2.10", "4.1"] },
    { "id": 3, "tasks": ["2.4", "4.2", "4.3"] },
    { "id": 4, "tasks": ["4.4", "4.5", "5.1", "5.5", "5.9"] },
    { "id": 5, "tasks": ["5.2", "5.3", "5.4", "5.6", "5.7"] },
    { "id": 6, "tasks": ["5.8", "7.1"] },
    { "id": 7, "tasks": ["7.2"] },
    { "id": 8, "tasks": ["7.3", "8.1", "8.3", "8.4"] },
    { "id": 9, "tasks": ["8.2", "8.5", "8.6"] },
    { "id": 10, "tasks": ["8.7"] }
  ]
}
```
