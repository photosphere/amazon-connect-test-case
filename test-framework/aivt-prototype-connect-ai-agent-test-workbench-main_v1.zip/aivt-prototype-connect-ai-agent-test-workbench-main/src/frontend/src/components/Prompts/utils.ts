/**
 * Shared formatting and error-describer helpers used by the Prompts
 * detail page and its lifted-out subcomponents (`HistoryPanel`,
 * `RevertConfirmModal`, `ActiveRunsFlashbar`, …).
 *
 * Hoisting these helpers out of `pages/PromptDetailPage.tsx` (task
 * 13.7's HistoryPanel lift) avoids duplicating ~40 lines of error
 * mapping in every subcomponent and keeps the structured-error-code
 * → human message translation centralised next to the components
 * that consume it.
 *
 * No JSX is allowed in this file so it can stay a plain `.ts`
 * module that any sibling component can import freely.
 *
 * @module frontend/components/Prompts/utils
 */

import { PromptApiError } from '../../api/prompts';

/**
 * Format an ISO 8601 timestamp for display. `null`/`undefined` renders
 * an em-dash so a never-overridden prompt's "last modified" cell is
 * visually distinct from one that was edited at the Unix epoch.
 */
export function formatTimestamp(iso: string | null | undefined): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleString();
}

/**
 * Shape a {@link PromptApiError} into a human-readable inline message
 * that names the constraint that failed and, where helpful, the
 * offending field (R14.3). The structured `details` object carries
 * the offending key/value pair for most error codes; we surface the
 * most useful piece first so the user can act on it directly.
 */
export function describePromptError(err: PromptApiError): string {
  const d = err.details ?? {};
  switch (err.code) {
    case 'PLACEHOLDERS_MISSING':
      return `Missing required placeholders: ${
        Array.isArray(d.missing) ? (d.missing as string[]).join(', ') : '(unknown)'
      }`;
    case 'PROMPT_TEXT_TOO_LARGE':
      return `Text too large: ${d.observedBytes ?? '?'} bytes (limit ${
        d.limitBytes ?? '?'
      } bytes).`;
    case 'PLACEHOLDER_COUNT_EXCEEDED':
      return `Placeholder "${d.placeholder ?? '?'}" appears ${
        d.observed ?? '?'
      } times (max ${d.max ?? '?'}).`;
    case 'UNKNOWN_PLACEHOLDER':
      return `Unknown placeholder "${d.token ?? '?'}" at offset ${
        d.offset ?? '?'
      }.`;
    case 'MODEL_NOT_ALLOWED':
      return `Model "${d.requested ?? '?'}" is not in this prompt's allowed list.`;
    case 'MODEL_FORBIDS_KEY':
      return `Inference parameter "${d.key ?? '?'}" is forbidden by model profile "${
        d.profile ?? '?'
      }".`;
    case 'INFERENCE_PARAMETER_OUT_OF_BOUNDS': {
      const range = d.range as { min?: number; max?: number } | undefined;
      const min = range?.min;
      const max = range?.max;
      return `Inference parameter "${d.key ?? '?'}" = ${
        d.value ?? '?'
      } is outside the allowed range [${min ?? '?'}, ${max ?? '?'}].`;
    }
    case 'DRY_RENDER_FAILED':
      return `Dry-render check failed; the platform refuses to persist a prompt that would crash at runtime. ${err.message}`;
    case 'RESET_CONFIRMATION_REQUIRED':
      return 'Reset requires explicit confirmation.';
    case 'VERSION_CONFLICT':
      return 'Another user updated this prompt while you were editing. Reload to see the latest version.';
    case 'PROMPT_NOT_FOUND':
      return 'This prompt no longer exists in the registry.';
    default:
      return err.message;
  }
}
