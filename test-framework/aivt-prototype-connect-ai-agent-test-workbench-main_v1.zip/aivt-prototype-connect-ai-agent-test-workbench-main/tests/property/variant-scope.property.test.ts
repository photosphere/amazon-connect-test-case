// Feature: implement-recommendations, Property 3: Variant surface scope containment
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import type { VariantConfig, Recommendation, RecommendationTarget, ToolSurface } from "@shared/types";

// ---------------------------------------------------------------------------
// Scope Containment Check (pure helper mirroring variant-generator.ts logic)
// ---------------------------------------------------------------------------

/**
 * Checks whether the variant's targetField set is a subset of (or equal to)
 * the source recommendations' targetField set. This is the core scope
 * containment property from the design doc — variant generation SHALL NOT
 * introduce changes to Tool_Surface values that were not already recommended.
 *
 * Returns true if variant surfaces ⊆ source surfaces.
 */
function checkScopeContainment(
  variantRecommendations: Recommendation[],
  sourceRecommendations: Recommendation[]
): boolean {
  const sourceSurfaces = new Set<RecommendationTarget>(
    sourceRecommendations.map((r) => r.targetField)
  );
  const variantSurfaces = new Set<RecommendationTarget>(
    variantRecommendations.map((r) => r.targetField)
  );

  for (const surface of variantSurfaces) {
    if (!sourceSurfaces.has(surface)) {
      return false;
    }
  }
  return true;
}

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** The four valid ToolSurface values. */
const ALL_SURFACES: ToolSurface[] = [
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
];

/** Arbitrary ToolSurface value. */
const toolSurfaceArb: fc.Arbitrary<ToolSurface> = fc.constantFrom(...ALL_SURFACES);

/** Arbitrary non-empty string for targetName. */
const targetNameArb: fc.Arbitrary<string> = fc.string({ minLength: 1, maxLength: 50 });

/** Arbitrary text for currentText/suggestedText (at least one non-empty is typical). */
const textArb: fc.Arbitrary<string> = fc.string({ minLength: 1, maxLength: 200 });

/** Arbitrary Recommendation with a specific targetField. */
function recommendationWithSurface(surface: ToolSurface): fc.Arbitrary<Recommendation> {
  return fc.tuple(targetNameArb, textArb, textArb, fc.string({ maxLength: 100 })).map(
    ([targetName, currentText, suggestedText, rationale]) => ({
      targetField: surface,
      targetName,
      currentText,
      suggestedText,
      rationale,
    })
  );
}

/** Arbitrary Recommendation with any valid surface. */
const recommendationArb: fc.Arbitrary<Recommendation> = toolSurfaceArb.chain(
  (surface) => recommendationWithSurface(surface)
);

/**
 * Generates a VariantConfig whose recommendations target ONLY surfaces
 * from the provided source surfaces (valid subset).
 */
function variantSubsetArb(sourceSurfaces: ToolSurface[]): fc.Arbitrary<VariantConfig> {
  const variantLetter = fc.constantFrom("A" as const, "B" as const, "C" as const);
  const strategy = fc.constantFrom("conciseness", "example-heavy", "restructured");

  return fc
    .tuple(
      variantLetter,
      strategy,
      fc.shuffledSubarray(sourceSurfaces, { minLength: 1, maxLength: sourceSurfaces.length }).chain(
        (selectedSurfaces) =>
          fc
            .tuple(
              ...selectedSurfaces.map((surface) =>
                fc.array(recommendationWithSurface(surface), { minLength: 1, maxLength: 3 })
              )
            )
            .map((arrays) => arrays.flat())
      )
    )
    .map(([letter, strat, recommendations]) => ({
      variantLetter: letter,
      strategy: strat,
      recommendations,
    }));
}

/**
 * Generates a VariantConfig that introduces at least one surface NOT in the
 * source set (violates scope containment).
 */
function variantViolatingArb(sourceSurfaces: ToolSurface[]): fc.Arbitrary<VariantConfig> {
  const sourceSet = new Set(sourceSurfaces);
  const outsideSurfaces = ALL_SURFACES.filter((s) => !sourceSet.has(s));

  // This should only be called when there ARE surfaces outside the source set
  if (outsideSurfaces.length === 0) {
    // All 4 surfaces are in source — this can't violate. Return a dummy that
    // will be filtered out in tests.
    return variantSubsetArb(sourceSurfaces);
  }

  const variantLetter = fc.constantFrom("A" as const, "B" as const, "C" as const);
  const strategy = fc.constantFrom("conciseness", "example-heavy", "restructured");

  // At least one recommendation with an outside surface
  const outsideRec = fc.constantFrom(...outsideSurfaces).chain((surface) =>
    recommendationWithSurface(surface)
  );

  // Optionally some valid recs from source surfaces too
  const validRecs = fc.array(
    fc.constantFrom(...sourceSurfaces).chain((surface) =>
      recommendationWithSurface(surface)
    ),
    { minLength: 0, maxLength: 3 }
  );

  return fc
    .tuple(variantLetter, strategy, outsideRec, validRecs)
    .map(([letter, strat, violation, valid]) => ({
      variantLetter: letter,
      strategy: strat,
      recommendations: [violation, ...valid],
    }));
}

// ---------------------------------------------------------------------------
// Property 3: Variant surface scope containment
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 5.3, 13.1, 13.3, 18.4**
 *
 * Property 3: Variant surface scope containment
 * For any generated variant configuration and its source recommendation set,
 * the set of targetField values present in the variant's recommendations
 * SHALL be a subset of (or equal to) the set of targetField values present
 * in the source recommendations. Variant generation never introduces changes
 * to Tool_Surface values that were not already recommended.
 */
describe("Feature: implement-recommendations, Property 3: Variant surface scope containment", () => {
  it("subset: variant targeting only source surfaces passes scope check", () => {
    fc.assert(
      fc.property(
        fc
          .shuffledSubarray(ALL_SURFACES, { minLength: 1, maxLength: 4 })
          .chain((surfaces) =>
            fc.tuple(
              fc.constant(surfaces),
              variantSubsetArb(surfaces),
              // Generate source recommendations covering those surfaces
              fc
                .tuple(
                  ...surfaces.map((s) =>
                    fc.array(recommendationWithSurface(s), { minLength: 1, maxLength: 3 })
                  )
                )
                .map((arrays) => arrays.flat())
            )
          ),
        ([_surfaces, variant, sourceRecs]) => {
          const result = checkScopeContainment(variant.recommendations, sourceRecs);
          expect(result).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("violation: variant introducing a surface NOT in source fails scope check", () => {
    fc.assert(
      fc.property(
        fc
          .shuffledSubarray(ALL_SURFACES, { minLength: 1, maxLength: 3 }) // Leave at least 1 surface outside
          .chain((surfaces) =>
            fc.tuple(
              fc.constant(surfaces),
              variantViolatingArb(surfaces),
              // Generate source recommendations covering only those surfaces
              fc
                .tuple(
                  ...surfaces.map((s) =>
                    fc.array(recommendationWithSurface(s), { minLength: 1, maxLength: 3 })
                  )
                )
                .map((arrays) => arrays.flat())
            )
          ),
        ([surfaces, variant, sourceRecs]) => {
          // Verify this is actually violating (guard for the edge case where
          // all 4 surfaces are in source)
          const sourceSet: Set<string> = new Set(surfaces);
          const variantSurfaces = new Set(variant.recommendations.map((r) => r.targetField));
          const hasViolation = [...variantSurfaces].some((s) => !sourceSet.has(s));

          if (hasViolation) {
            const result = checkScopeContainment(variant.recommendations, sourceRecs);
            expect(result).toBe(false);
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  it("empty source set: any non-empty variant always violates scope", () => {
    fc.assert(
      fc.property(
        fc.array(recommendationArb, { minLength: 1, maxLength: 5 }),
        (variantRecs) => {
          // Empty source means no surfaces are permitted
          const result = checkScopeContainment(variantRecs, []);
          expect(result).toBe(false);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("equal sets: variant with same targetField set as source is valid", () => {
    fc.assert(
      fc.property(
        fc
          .shuffledSubarray(ALL_SURFACES, { minLength: 1, maxLength: 4 })
          .chain((surfaces) =>
            fc.tuple(
              // Source recs: at least one per surface
              fc
                .tuple(
                  ...surfaces.map((s) =>
                    fc.array(recommendationWithSurface(s), { minLength: 1, maxLength: 3 })
                  )
                )
                .map((arrays) => arrays.flat()),
              // Variant recs: exactly one per surface (covers all source surfaces)
              fc
                .tuple(
                  ...surfaces.map((s) =>
                    fc.array(recommendationWithSurface(s), { minLength: 1, maxLength: 2 })
                  )
                )
                .map((arrays) => arrays.flat())
            )
          ),
        ([sourceRecs, variantRecs]) => {
          const result = checkScopeContainment(variantRecs, sourceRecs);
          expect(result).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });
});
