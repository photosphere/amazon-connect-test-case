import React from 'react';
import { useAuth } from './AuthContext';
import { redirectToLogin } from './cognito';
import Spinner from '@cloudscape-design/components/spinner';
import Box from '@cloudscape-design/components/box';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { authenticated, loading } = useAuth();

  if (loading) {
    return (
      <Box textAlign="center" padding={{ top: 'xxxl' }}>
        <Spinner size="large" />
        <Box variant="p" margin={{ top: 's' }}>
          Loading...
        </Box>
      </Box>
    );
  }

  if (!authenticated) {
    redirectToLogin();
    return (
      <Box textAlign="center" padding={{ top: 'xxxl' }}>
        <Spinner size="large" />
        <Box variant="p" margin={{ top: 's' }}>
          Redirecting to sign in...
        </Box>
      </Box>
    );
  }

  return <>{children}</>;
}
