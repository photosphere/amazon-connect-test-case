/**
 * `case_scaffold` — system prompt for the Bedrock Converse call that
 * maps technical parameter names to customer-facing labels inside the
 * `POST /suites/{suiteId}/cases/scaffold` handler. The user message
 * (containing the parameter list) is constructed dynamically by
 * `buildLabelMappingPrompt`; the registered prompt is the literal
 * `system` block lifted byte-for-byte from
 * `src/backend/handlers/scaffold.ts`'s `mapParameterLabels` call.
 *
 * @module backend/orchestration/prompt-registry/prompts/case-scaffold
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

/**
 * The byte-for-byte literal currently passed as the `system` text in the
 * `mapParameterLabels` `ConverseCommand` in `scaffold.ts`.
 */
const DEFAULT_TEXT =
  "You are a UX labeling assistant. Convert technical parameter names to clear, customer-friendly labels. Respond with valid JSON only.";

export const caseScaffoldPrompt: PromptDefinition = {
  promptKey: "case_scaffold",
  name: "Case Scaffold — Customer-Facing Label Mapper",
  description:
    "System prompt for the Converse call that converts technical agent-tool parameter names into clear, customer-facing labels for the per-case knowledge template.",
  category: "scaffolding",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 4_096 },
  },
  defaultInferenceValues: {
    maxTokens: 4_096,
  },
};
