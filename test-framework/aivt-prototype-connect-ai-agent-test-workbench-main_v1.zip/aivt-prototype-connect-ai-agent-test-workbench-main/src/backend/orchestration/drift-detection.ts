/**
 * Drift Detection Module
 *
 * Pure function that compares each recommendation's `currentText` against
 * the live agent's corresponding field value. Character-for-character
 * comparison — no trimming, no normalization.
 *
 * Used by both Direct Apply and Apply Winning Variant flows to detect
 * conflicting changes before writing to the agent (R3.6, R11.1, R11.2).
 *
 * @module drift-detection
 */

import {
  AgentDetail,
  DriftedField,
  Recommendation,
  ToolSurface,
} from "../../shared/types";

// ---------------------------------------------------------------------------
// Public Interfaces
// ---------------------------------------------------------------------------

export interface DriftCheckInput {
  recommendations: Recommendation[];
  liveAgentConfig: AgentDetail;
}

export interface DriftCheckResult {
  hasDrift: boolean;
  driftedFields: DriftedField[];
  cleanFields: Recommendation[];
}

// ---------------------------------------------------------------------------
// Implementation
// ---------------------------------------------------------------------------

/**
 * Resolves the live value for a recommendation's target field from the agent
 * config. Returns `undefined` if the tool or field cannot be found.
 */
function resolveLiveValue(
  rec: Recommendation,
  liveAgentConfig: AgentDetail
): string | undefined {
  const { targetField, targetName, currentText } = rec;

  if (targetField === "system_prompt") {
    // For system_prompt recommendations, the model's currentText is often
    // a substring of the full prompt (the specific section being edited).
    // Due to YAML indentation stripping differences between how the snapshot
    // captures the prompt vs. how the apply handler extracts it, we use a
    // normalized comparison (collapse whitespace on each line) to avoid
    // false drift from harmless indent differences.
    const fullPrompt = liveAgentConfig.systemPrompt;

    // Add operation: currentText is empty → nothing to drift from
    if (!currentText) {
      return "";
    }

    // Normalize: collapse leading whitespace differences per line
    const normalize = (s: string) => s.split('\n').map(l => l.trimStart()).join('\n');
    const normalizedExpected = normalize(currentText);
    const normalizedActual = normalize(fullPrompt);

    if (normalizedActual.includes(normalizedExpected)) {
      // The expected section is present in the live prompt → no drift
      return currentText;
    }
    // The expected section is NOT in the live prompt → drift
    return fullPrompt;
  }

  // For tool-scoped surfaces, find the tool by targetName
  const tool = liveAgentConfig.tools.find((t) => t.toolName === targetName);
  if (!tool) {
    return undefined;
  }

  switch (targetField as ToolSurface) {
    case "tool_description":
      return tool.description;

    case "tool_instruction":
      // Treat undefined instruction as empty string per design doc
      return tool.instruction ?? "";

    case "tool_examples":
      // For tool_examples, we look for the exact currentText entry in the
      // tool's examples array. If currentText is empty (an "add" operation),
      // drift is not applicable — the entry didn't exist before, so there's
      // nothing to drift from. We return "" to match the empty currentText.
      if (currentText === "") {
        return "";
      }
      // Find the matching example in the live tool's examples array
      const matchingExample = tool.examples.find((ex) => ex === currentText);
      // If found, return the example (which equals currentText → no drift).
      // If not found, return undefined to signal drift (the expected example
      // is no longer present in the live config).
      return matchingExample !== undefined ? matchingExample : undefined;

    default:
      return undefined;
  }
}

/**
 * Pure function: compares each recommendation's currentText against the live
 * agent's corresponding field value. Character-for-character comparison.
 *
 * For tool_description/tool_instruction/tool_examples:
 *   - Finds the tool by targetName in liveAgentConfig.tools
 *   - Compares currentText against the live value of that field
 *
 * For system_prompt:
 *   - Compares currentText against liveAgentConfig.systemPrompt
 *
 * Returns the set of drifted fields and the set of clean recommendations.
 */
export function checkDrift(input: DriftCheckInput): DriftCheckResult {
  const { recommendations, liveAgentConfig } = input;

  const driftedFields: DriftedField[] = [];
  const cleanFields: Recommendation[] = [];

  for (const rec of recommendations) {
    // Drift detection only applies to agent-targeted recommendations
    // (ToolSurface values). test_case recommendations are skipped.
    if (rec.targetField === "test_case") continue;

    const liveValue = resolveLiveValue(rec, liveAgentConfig);

    // If liveValue is undefined, the tool or field doesn't exist in the
    // live config — that's a drift (the expected state is gone).
    if (liveValue === undefined) {
      driftedFields.push({
        targetField: rec.targetField,
        targetName: rec.targetName,
        expectedText: rec.currentText,
        actualText: "",
      });
      continue;
    }

    // Character-for-character comparison — no trimming, no normalization
    if (rec.currentText === liveValue) {
      cleanFields.push(rec);
    } else {
      driftedFields.push({
        targetField: rec.targetField,
        targetName: rec.targetName,
        expectedText: rec.currentText,
        actualText: liveValue,
      });
    }
  }

  return {
    hasDrift: driftedFields.length > 0,
    driftedFields,
    cleanFields,
  };
}
