import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import {
  isAuthenticated,
  initializeAuth,
  handleAuthCallback,
  signOut as cognitoSignOut,
  redirectToLogin,
  getStoredTokens,
} from './cognito';

interface AuthContextValue {
  authenticated: boolean;
  loading: boolean;
  userEmail: string | null;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextValue>({
  authenticated: false,
  loading: true,
  userEmail: null,
  signOut: () => {},
});

export function useAuth(): AuthContextValue {
  return useContext(AuthContext);
}

function extractEmailFromToken(idToken: string): string | null {
  try {
    const payload = JSON.parse(atob(idToken.split('.')[1]));
    return payload.email || payload['cognito:username'] || null;
  } catch {
    return null;
  }
}

interface AuthProviderProps {
  children: React.ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [authenticated, setAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  useEffect(() => {
    async function init() {
      // Check if this is an OAuth callback
      const params = new URLSearchParams(window.location.search);
      if (params.has('code')) {
        try {
          const redirectPath = await handleAuthCallback();
          setAuthenticated(true);
          const tokens = getStoredTokens();
          if (tokens) {
            setUserEmail(extractEmailFromToken(tokens.idToken));
          }
          // Navigate to the originally requested path
          if (redirectPath && redirectPath !== window.location.pathname) {
            window.history.replaceState({}, '', redirectPath);
          }
        } catch (err) {
          console.error('Auth callback failed:', err);
          redirectToLogin();
          return;
        }
      } else {
        // Check existing session
        initializeAuth();
        if (isAuthenticated()) {
          setAuthenticated(true);
          const tokens = getStoredTokens();
          if (tokens) {
            setUserEmail(extractEmailFromToken(tokens.idToken));
          }
        }
      }
      setLoading(false);
    }

    init();
  }, []);

  const handleSignOut = useCallback(() => {
    cognitoSignOut();
  }, []);

  return (
    <AuthContext.Provider value={{ authenticated, loading, userEmail, signOut: handleSignOut }}>
      {children}
    </AuthContext.Provider>
  );
}
