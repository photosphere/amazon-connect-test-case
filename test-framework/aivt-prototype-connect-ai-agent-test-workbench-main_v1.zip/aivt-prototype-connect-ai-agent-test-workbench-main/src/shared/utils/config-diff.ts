/**
 * Configuration diff utility for comparing agent snapshots.
 *
 * @module config-diff
 */

import { AgentSnapshot, ToolDefinition } from "../types";

/** Types of changes detected in an agent configuration diff. */
export type ConfigChangeType =
  | "tool-added"
  | "tool-removed"
  | "tool-modified"
  | "tool-examples-changed"
  | "system-prompt-changed"
  | "model-changed";

/**
 * A single change entry in the config diff.
 *
 * `priorExamples` and `newExamples` are populated only on
 * `tool-examples-changed` records and are left undefined on every other
 * change type. They carry the two `examples` arrays so the Comparison_View
 * can render the side-by-side added/removed/reordered diff client-side
 * without re-reading the snapshots (R4.1, R4.3).
 */
export interface ConfigChange {
  changeType: ConfigChangeType;
  /** Tool name (for tool-related changes). */
  toolName?: string;
  /** Description of what changed. */
  detail: string;
  /** Prior examples array — populated only on `tool-examples-changed`. */
  priorExamples?: string[];
  /** New examples array — populated only on `tool-examples-changed`. */
  newExamples?: string[];
}

/** Result of comparing two agent configuration snapshots. */
export interface ConfigDiffResult {
  changes: ConfigChange[];
  hasChanges: boolean;
}

/**
 * Returns true when the two examples arrays are element-wise equal in
 * length, order, and string content. A missing/undefined input is treated
 * as `[]` for backward compatibility with snapshots persisted before the
 * `examples` field shipped (R3.3, R4.2).
 */
function examplesEqual(
  a: string[] | undefined,
  b: string[] | undefined
): boolean {
  const left = a ?? [];
  const right = b ?? [];
  if (left.length !== right.length) return false;
  for (let i = 0; i < left.length; i++) {
    if (left[i] !== right[i]) return false;
  }
  return true;
}

/**
 * Compares two agent configuration snapshots and identifies differences.
 *
 * Identifies:
 * - Tools added in the second snapshot
 * - Tools removed from the first snapshot
 * - Tools with modified descriptions or instructions
 * - Tools whose `examples` array differs in length, order, or content
 *   (emitted as `tool-examples-changed`, independently of `tool-modified`)
 * - Changes to the system prompt
 * - Changes to the model ID
 *
 * Returns zero changes only when snapshots are functionally identical
 * (tools, system prompt, and model ID all match — including each tool's
 * `examples` array).
 *
 * @param snapshotA - The first (earlier) agent configuration snapshot
 * @param snapshotB - The second (later) agent configuration snapshot
 * @returns All detected configuration changes
 */
export function diffAgentConfigs(
  snapshotA: AgentSnapshot,
  snapshotB: AgentSnapshot
): ConfigDiffResult {
  const changes: ConfigChange[] = [];

  // Compare tools
  const toolsA = new Map<string, ToolDefinition>();
  const toolsB = new Map<string, ToolDefinition>();

  for (const tool of snapshotA.tools) {
    toolsA.set(tool.toolName, tool);
  }
  for (const tool of snapshotB.tools) {
    toolsB.set(tool.toolName, tool);
  }

  // Tools added in B
  for (const [toolName, tool] of toolsB) {
    if (!toolsA.has(toolName)) {
      changes.push({
        changeType: "tool-added",
        toolName,
        detail: `Tool "${toolName}" added with description: "${tool.description}"`,
      });
    }
  }

  // Tools removed from A
  for (const [toolName] of toolsA) {
    if (!toolsB.has(toolName)) {
      changes.push({
        changeType: "tool-removed",
        toolName,
        detail: `Tool "${toolName}" removed`,
      });
    }
  }

  // Tools modified (present in both but with different description, instruction, or examples).
  // `tool-modified` covers description/instruction; `tool-examples-changed` is emitted
  // independently so a tool whose only difference is its examples array produces a
  // `tool-examples-changed` record and no `tool-modified` record (R4.4).
  for (const [toolName, toolA] of toolsA) {
    const toolB = toolsB.get(toolName);
    if (!toolB) continue;

    const modifications: string[] = [];

    if (toolA.description !== toolB.description) {
      modifications.push("description");
    }
    if (toolA.instruction !== toolB.instruction) {
      modifications.push("instruction");
    }

    if (modifications.length > 0) {
      changes.push({
        changeType: "tool-modified",
        toolName,
        detail: `Tool "${toolName}" has modified: ${modifications.join(", ")}`,
      });
    }

    // Examples comparison — independent of tool-modified.
    // Treat missing examples on either snapshot as [] (R3.3, R4.2): a pre-feature
    // snapshot diffed against a post-feature snapshot does not emit a
    // `tool-examples-changed` record when the post-feature snapshot also has no
    // examples for that tool (both collapse to []).
    const priorExamples = toolA.examples ?? [];
    const newExamples = toolB.examples ?? [];
    if (!examplesEqual(priorExamples, newExamples)) {
      changes.push({
        changeType: "tool-examples-changed",
        toolName,
        detail: `Tool "${toolName}" examples changed (${priorExamples.length} → ${newExamples.length})`,
        priorExamples: [...priorExamples],
        newExamples: [...newExamples],
      });
    }
  }

  // Compare system prompt
  if (snapshotA.systemPrompt !== snapshotB.systemPrompt) {
    changes.push({
      changeType: "system-prompt-changed",
      detail: "System prompt changed",
    });
  }

  // Compare model ID
  if (snapshotA.modelId !== snapshotB.modelId) {
    changes.push({
      changeType: "model-changed",
      detail: `Model changed from "${snapshotA.modelId}" to "${snapshotB.modelId}"`,
    });
  }

  return {
    changes,
    hasChanges: changes.length > 0,
  };
}
