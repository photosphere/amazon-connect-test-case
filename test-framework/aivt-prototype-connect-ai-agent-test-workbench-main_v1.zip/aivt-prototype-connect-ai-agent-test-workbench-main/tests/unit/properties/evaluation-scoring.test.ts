// Feature: bedrock-judge-evaluations, Property 4: Goal direct + arithmetic-mean aggregation
// Feature: bedrock-judge-evaluations, Property 5: Every emitted score is in [0.0, 1.0]
// Feature: bedrock-judge-evaluations, Property 6: Error state leaves the right scores unset
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import {
  REQUESTED_EVALUATOR_IDS,
  aggregateScores,
  type EvaluationResultContent,
  type EvaluatorOutcome,
} from '../../../src/shared/utils/evaluation-scoring';

/**
 * Property tests for the score mapping & aggregation module.
 *
 * Three properties live in this file (one per task in 12.x):
 *   - Property  5 — every emitted score is finite and in [0.0, 1.0]
 *   - Property  4 — goal maps directly; helpfulness / tool accuracy reduce
 *                   per-unit results by unweighted arithmetic mean
 *   - Property  6 — `missingEvaluators` is exactly the absent-or-all-unusable
 *                   subset of the three requested evaluator ids
 *
 * The module under test is pure and has no AWS imports, so these tests
 * exercise its real behaviour without any mocking.
 */

// ---------------------------------------------------------------------------
// Shared arbitraries
// ---------------------------------------------------------------------------

const REQUESTED_IDS = [...REQUESTED_EVALUATOR_IDS];

/** A non-finite numeric value: NaN, +Infinity, or -Infinity. */
const nonFiniteNumberArb: fc.Arbitrary<number> = fc.constantFrom(
  Number.NaN,
  Number.POSITIVE_INFINITY,
  Number.NEGATIVE_INFINITY
);

/** A finite value possibly out of [0,1] — exercises the clamp path. */
const anyFiniteValueArb: fc.Arbitrary<number> = fc.double({
  min: -1_000,
  max: 1_000,
  noNaN: true,
  noDefaultInfinity: true,
});

/** A value strictly within [0,1] — clamp is a no-op for these. */
const inRangeValueArb: fc.Arbitrary<number> = fc.double({
  min: 0,
  max: 1,
  noNaN: true,
  noDefaultInfinity: true,
});

/**
 * A result whose `value` is "unusable": either non-finite or absent.
 * Used in Property 6 to construct present-but-all-unusable evaluator
 * outcomes that should still be flagged as missing.
 */
const unusableResultArb: fc.Arbitrary<EvaluationResultContent> = fc.oneof(
  // Non-finite numeric value.
  nonFiniteNumberArb.map((value) => ({ value }) as EvaluationResultContent),
  // No `value` key at all.
  fc.constant({} as EvaluationResultContent),
  // `value` set to a non-numeric type via an explicit cast.
  fc.string({ maxLength: 5 }).map(
    (s) => ({ value: s as unknown as number }) as EvaluationResultContent
  )
);

/**
 * A result whose `value` is a usable finite number, possibly out of range.
 * Exercises both the clamp path and the in-range pass-through path.
 */
const usableResultArb: fc.Arbitrary<EvaluationResultContent> = fc.record({
  value: anyFiniteValueArb,
  label: fc.option(fc.string({ maxLength: 8 }), { nil: undefined }),
  explanation: fc.option(fc.string({ maxLength: 16 }), { nil: undefined }),
});

/**
 * A result with an arbitrary `value`: usable, non-finite, or absent. Used
 * by Property 5 so we sweep the whole input space.
 */
const anyResultArb: fc.Arbitrary<EvaluationResultContent> = fc.oneof(
  { weight: 3, arbitrary: usableResultArb },
  { weight: 2, arbitrary: unusableResultArb }
);

/**
 * A non-empty list of in-range usable results — for Property 4, where we
 * require deterministic non-clamped means.
 */
const inRangeResultListArb: fc.Arbitrary<EvaluationResultContent[]> = fc.array(
  inRangeValueArb.map((value) => ({ value }) as EvaluationResultContent),
  { minLength: 1, maxLength: 8 }
);

/**
 * An evaluator id from outside the three requested ones. Used by Property 5
 * and Property 6 to confirm extra outcomes are silently ignored.
 */
const otherEvaluatorIdArb: fc.Arbitrary<string> = fc
  .string({ minLength: 1, maxLength: 16 })
  .filter((s) => !REQUESTED_IDS.includes(s as (typeof REQUESTED_IDS)[number]));

// ---------------------------------------------------------------------------
// Property 5
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 1.6, 8.3**
 *
 * Property 5: Every emitted score is in [0.0, 1.0]
 *
 * For any list of `EvaluatorOutcome`s — including ids outside the three
 * requested, results with out-of-range numbers, results with non-finite
 * numbers (NaN / ±Infinity), and empty result lists — every defined score
 * (`goalSuccessScore`, `helpfulnessScore`, `toolAccuracyScore`) on the
 * returned `AggregatedScores` is a finite number in `[0.0, 1.0]`.
 */
describe('Property 5: Every emitted score is in [0.0, 1.0]', () => {
  /**
   * Free-form outcome arb: id is sometimes one of the three requested
   * (so the corresponding score gets populated) and sometimes another
   * string (so it should be ignored). Results may be empty.
   */
  const outcomeArb: fc.Arbitrary<EvaluatorOutcome> = fc.record({
    evaluatorId: fc.oneof(
      { weight: 3, arbitrary: fc.constantFrom(...REQUESTED_IDS) },
      { weight: 1, arbitrary: otherEvaluatorIdArb }
    ),
    results: fc.array(anyResultArb, { minLength: 0, maxLength: 6 }),
  });

  const outcomesArb: fc.Arbitrary<EvaluatorOutcome[]> = fc.array(outcomeArb, {
    minLength: 0,
    maxLength: 8,
  });

  it('every defined score is finite and within [0.0, 1.0]', () => {
    fc.assert(
      fc.property(outcomesArb, (outcomes) => {
        const scores = aggregateScores(outcomes);

        for (const field of [
          'goalSuccessScore',
          'helpfulnessScore',
          'toolAccuracyScore',
        ] as const) {
          const v = scores[field];
          if (v === undefined) continue;
          expect(Number.isFinite(v)).toBe(true);
          expect(v).toBeGreaterThanOrEqual(0);
          expect(v).toBeLessThanOrEqual(1);
        }
      }),
      { numRuns: 100 }
    );
  });
});

// ---------------------------------------------------------------------------
// Property 4
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 1.3, 1.4, 1.5, 8.4**
 *
 * Property 4: Goal direct + arithmetic-mean aggregation
 *
 * For outcomes whose values are finite and within `[0, 1]` (so `clamp01` is
 * a no-op):
 *  - `goalSuccessScore` equals the FIRST usable goal value (i.e.
 *    `clamp01(firstGoalValue) === firstGoalValue`),
 *  - `helpfulnessScore` equals the unweighted arithmetic mean of every
 *    usable helpfulness value,
 *  - `toolAccuracyScore` equals the unweighted arithmetic mean of every
 *    usable tool-accuracy value,
 *  - `missingEvaluators` is empty.
 *
 * Equality is asserted within a small absolute tolerance because IEEE 754
 * sum order can produce a different last bit; the implementation sums in
 * input order and so does the test.
 */
describe('Property 4: Goal direct + arithmetic-mean aggregation', () => {
  const FLOAT_TOLERANCE = 1e-9;

  /** Reference mean: same accumulation order as the implementation. */
  function meanInOrder(values: readonly number[]): number {
    let sum = 0;
    for (const v of values) {
      sum += v;
    }
    return sum / values.length;
  }

  /** Inputs guarantee at least one usable result for every requested id. */
  const inputArb = fc.record({
    goalValues: inRangeResultListArb,
    helpfulnessValues: inRangeResultListArb,
    toolAccuracyValues: inRangeResultListArb,
  });

  it('goal equals first value, helpfulness/tool accuracy equal the unweighted mean, no missing evaluators', () => {
    fc.assert(
      fc.property(inputArb, ({ goalValues, helpfulnessValues, toolAccuracyValues }) => {
        const outcomes: EvaluatorOutcome[] = [
          { evaluatorId: 'Builtin.GoalSuccessRate', results: goalValues },
          { evaluatorId: 'Builtin.Helpfulness', results: helpfulnessValues },
          { evaluatorId: 'Builtin.ToolSelectionAccuracy', results: toolAccuracyValues },
        ];

        const scores = aggregateScores(outcomes);

        // No evaluator should be reported missing — every list is non-empty
        // and every value is finite & in range.
        expect(scores.missingEvaluators).toEqual([]);

        // Goal: first usable value, clamped (no-op here).
        expect(scores.goalSuccessScore).toBeDefined();
        expect(Math.abs((scores.goalSuccessScore as number) - (goalValues[0].value as number)))
          .toBeLessThan(FLOAT_TOLERANCE);

        // Helpfulness: arithmetic mean across all per-turn values.
        const expectedHelpfulness = meanInOrder(
          helpfulnessValues.map((r) => r.value as number)
        );
        expect(scores.helpfulnessScore).toBeDefined();
        expect(Math.abs((scores.helpfulnessScore as number) - expectedHelpfulness))
          .toBeLessThan(FLOAT_TOLERANCE);

        // Tool accuracy: arithmetic mean across all per-tool-call values.
        const expectedToolAccuracy = meanInOrder(
          toolAccuracyValues.map((r) => r.value as number)
        );
        expect(scores.toolAccuracyScore).toBeDefined();
        expect(Math.abs((scores.toolAccuracyScore as number) - expectedToolAccuracy))
          .toBeLessThan(FLOAT_TOLERANCE);
      }),
      { numRuns: 100 }
    );
  });
});

// ---------------------------------------------------------------------------
// Property 6 (missing-evaluator co-property)
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 1.9, 8.5, 8.7**
 *
 * Property 6: Missing-evaluator detection is exactly the absent subset
 *
 * The aggregator side of "Error state leaves the right scores unset": for
 * each of the three requested evaluator ids, choose whether to:
 *  - include it with a non-empty list of usable in-range values
 *    (it should NOT appear in `missingEvaluators` and its score IS defined),
 *  - omit it entirely (it SHOULD appear in `missingEvaluators` and its
 *    score is undefined), OR
 *  - include it with results that are all unusable (non-finite / no value)
 *    (it SHOULD appear in `missingEvaluators` and its score is undefined).
 *
 * Outcomes for evaluator ids OUTSIDE the three requested ones are also
 * sometimes injected, and must not affect `missingEvaluators` or any
 * score.
 */
describe('Property 6: Missing-evaluator detection is exactly the absent subset', () => {
  type Disposition = 'present-usable' | 'absent' | 'present-unusable';

  const dispositionArb: fc.Arbitrary<Disposition> = fc.constantFrom(
    'present-usable',
    'absent',
    'present-unusable'
  );

  /** Score-field on `AggregatedScores` corresponding to each evaluator id. */
  const SCORE_FIELD: Record<
    (typeof REQUESTED_IDS)[number],
    'goalSuccessScore' | 'helpfulnessScore' | 'toolAccuracyScore'
  > = {
    'Builtin.GoalSuccessRate': 'goalSuccessScore',
    'Builtin.Helpfulness': 'helpfulnessScore',
    'Builtin.ToolSelectionAccuracy': 'toolAccuracyScore',
  };

  const inputArb = fc.record({
    goalDisposition: dispositionArb,
    helpfulnessDisposition: dispositionArb,
    toolAccuracyDisposition: dispositionArb,
    goalUsable: inRangeResultListArb,
    goalUnusable: fc.array(unusableResultArb, { minLength: 1, maxLength: 4 }),
    helpfulnessUsable: inRangeResultListArb,
    helpfulnessUnusable: fc.array(unusableResultArb, { minLength: 1, maxLength: 4 }),
    toolAccuracyUsable: inRangeResultListArb,
    toolAccuracyUnusable: fc.array(unusableResultArb, { minLength: 1, maxLength: 4 }),
    extras: fc.array(
      fc.record({
        evaluatorId: otherEvaluatorIdArb,
        results: fc.array(anyResultArb, { minLength: 0, maxLength: 4 }),
      }),
      { minLength: 0, maxLength: 4 }
    ),
  });

  it('missingEvaluators equals the absent-or-all-unusable subset; scores defined iff present-usable', () => {
    fc.assert(
      fc.property(inputArb, (input) => {
        const dispositions: Record<(typeof REQUESTED_IDS)[number], Disposition> = {
          'Builtin.GoalSuccessRate': input.goalDisposition,
          'Builtin.Helpfulness': input.helpfulnessDisposition,
          'Builtin.ToolSelectionAccuracy': input.toolAccuracyDisposition,
        };

        const usableResults: Record<(typeof REQUESTED_IDS)[number], EvaluationResultContent[]> = {
          'Builtin.GoalSuccessRate': input.goalUsable,
          'Builtin.Helpfulness': input.helpfulnessUsable,
          'Builtin.ToolSelectionAccuracy': input.toolAccuracyUsable,
        };

        const unusableResults: Record<(typeof REQUESTED_IDS)[number], EvaluationResultContent[]> = {
          'Builtin.GoalSuccessRate': input.goalUnusable,
          'Builtin.Helpfulness': input.helpfulnessUnusable,
          'Builtin.ToolSelectionAccuracy': input.toolAccuracyUnusable,
        };

        const outcomes: EvaluatorOutcome[] = [];
        const expectedMissing = new Set<string>();

        for (const id of REQUESTED_IDS) {
          const d = dispositions[id];
          if (d === 'present-usable') {
            outcomes.push({ evaluatorId: id, results: usableResults[id] });
          } else if (d === 'present-unusable') {
            outcomes.push({ evaluatorId: id, results: unusableResults[id] });
            expectedMissing.add(id);
          } else {
            // absent — do not push an outcome.
            expectedMissing.add(id);
          }
        }

        // Inject extra outcomes for non-requested evaluator ids — these
        // must not affect anything.
        for (const extra of input.extras) {
          outcomes.push(extra);
        }

        const scores = aggregateScores(outcomes);

        // missingEvaluators (as a set) equals exactly the expected set.
        expect(new Set(scores.missingEvaluators)).toEqual(expectedMissing);

        // Score field is defined iff the evaluator is NOT missing.
        for (const id of REQUESTED_IDS) {
          const field = SCORE_FIELD[id];
          if (expectedMissing.has(id)) {
            expect(scores[field]).toBeUndefined();
          } else {
            expect(scores[field]).toBeDefined();
          }
        }

        // Sanity check: missingEvaluators only ever contains requested ids
        // (extras must never leak in).
        for (const id of scores.missingEvaluators) {
          expect(REQUESTED_IDS).toContain(id);
        }
      }),
      { numRuns: 100 }
    );
  });
});
