import { useCallback, useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import Container from '@cloudscape-design/components/container';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Form from '@cloudscape-design/components/form';
import FormField from '@cloudscape-design/components/form-field';
import Input from '@cloudscape-design/components/input';
import Textarea from '@cloudscape-design/components/textarea';
import Select, { type SelectProps } from '@cloudscape-design/components/select';
import Button from '@cloudscape-design/components/button';
import Alert from '@cloudscape-design/components/alert';
import Box from '@cloudscape-design/components/box';
import Table, { type TableProps } from '@cloudscape-design/components/table';
import Modal from '@cloudscape-design/components/modal';
import Toggle from '@cloudscape-design/components/toggle';
import Badge from '@cloudscape-design/components/badge';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import AttributeEditor, { type AttributeEditorProps } from '@cloudscape-design/components/attribute-editor';
import Spinner from '@cloudscape-design/components/spinner';
import StatusIndicator, {
  type StatusIndicatorProps,
} from '@cloudscape-design/components/status-indicator';
import { apiClient, ApiClientError } from '../api';
import type {
  TestSuite,
  TestCase,
  ToolStep,
  AgentSummary,
  TestRun,
  RagThresholds,
} from '../../../shared/types';
import { DEFAULT_RAG_THRESHOLDS } from '../../../shared/types';
import { CommunicationStyle, RunStatus } from '../../../shared/enums';
import { useActiveRunsContext } from '../hooks/ActiveRunsContext';
import {
  SUITE_NAME_MAX,
  SUITE_DESCRIPTION_MAX,
  CASE_NAME_MAX,
  CASE_DESCRIPTION_MAX,
  INITIAL_UTTERANCE_MAX,
  CUSTOMER_KNOWLEDGE_MAX_PAIRS,
  CUSTOMER_KNOWLEDGE_KEY_MAX,
  CUSTOMER_KNOWLEDGE_VALUE_MAX,
  SUCCESS_CRITERIA_MAX_STEPS,
  SUCCESS_CRITERIA_MIN_STEPS,
  PARAMETER_CHECKS_MAX,
  RAG_QUESTION_MAX,
  RAG_GROUND_TRUTH_MAX,
} from '../../../shared/constants';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface ListAgentsResponse {
  agents: AgentSummary[];
}

interface ListCasesResponse {
  cases: TestCase[];
}

interface ScaffoldResponse {
  suggestedTools: { toolName: string; position: number; required: boolean }[];
  customerKnowledgeTemplate: { key: string; label: string; toolGroup: string }[];
}

interface SuiteFormErrors {
  name?: string;
  agentId?: string;
}

interface CaseFormErrors {
  name?: string;
  description?: string;
  initialUtterance?: string;
  successCriteria?: string;
  customerKnowledge?: string;
  question?: string;
  groundTruthAnswer?: string;
  ragSessionData?: string;
}

interface KnowledgePair {
  key: string;
  value: string;
}

// ---------------------------------------------------------------------------
// Style options
// ---------------------------------------------------------------------------

const STYLE_OPTIONS: SelectProps.Option[] = [
  { label: 'Direct', value: CommunicationStyle.DIRECT },
  { label: 'Indirect', value: CommunicationStyle.INDIRECT },
  { label: 'Colloquial', value: CommunicationStyle.COLLOQUIAL },
  { label: 'Question-heavy', value: CommunicationStyle.QUESTION },
  { label: 'Complaint', value: CommunicationStyle.COMPLAINT },
];

const TEST_TYPE_OPTIONS: SelectProps.Option[] = [
  { label: 'Conversation', value: 'tool_sequence' },
  { label: 'RAG', value: 'rag' },
];

// ---------------------------------------------------------------------------
// Main Component
// ---------------------------------------------------------------------------

export function SuiteDetail() {
  const { suiteId } = useParams<{ suiteId: string }>();
  const navigate = useNavigate();
  const isCreate = suiteId === 'create';

  // Suite state
  const [suiteName, setSuiteName] = useState('');
  const [suiteDescription, setSuiteDescription] = useState('');
  const [selectedAgentOption, setSelectedAgentOption] = useState<SelectProps.Option | null>(null);
  const [agents, setAgents] = useState<AgentSummary[]>([]);
  const [agentsLoading, setAgentsLoading] = useState(true);
  const [suiteLoading, setSuiteLoading] = useState(!isCreate);
  const [saving, setSaving] = useState(false);
  const [suiteErrors, setSuiteErrors] = useState<SuiteFormErrors>({});
  const [suiteAlert, setSuiteAlert] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // RAG thresholds state
  const [ragThresholds, setRagThresholds] = useState<RagThresholds>({ ...DEFAULT_RAG_THRESHOLDS });

  // Test cases state
  const [cases, setCases] = useState<TestCase[]>([]);
  const [casesLoading, setCasesLoading] = useState(false);
  const [caseEditorVisible, setCaseEditorVisible] = useState(false);
  const [editingCase, setEditingCase] = useState<TestCase | null>(null);

  // ---------------------------------------------------------------------------
  // Load agents
  // ---------------------------------------------------------------------------

  const fetchAgents = useCallback(async () => {
    setAgentsLoading(true);
    try {
      const response = await apiClient.get<ListAgentsResponse>('/agents');
      setAgents(response.agents);
    } catch {
      // Silent fail — agent selector will just be empty
    } finally {
      setAgentsLoading(false);
    }
  }, []);

  // ---------------------------------------------------------------------------
  // Load suite (edit mode)
  // ---------------------------------------------------------------------------

  const fetchSuite = useCallback(async () => {
    if (isCreate || !suiteId) return;
    setSuiteLoading(true);
    try {
      const suite = await apiClient.get<TestSuite>(`/suites/${suiteId}`);
      setSuiteName(suite.name);
      setSuiteDescription(suite.description || '');
      setSelectedAgentOption({ label: suite.agentId, value: suite.agentId });
      setRagThresholds(suite.ragThresholds ?? { ...DEFAULT_RAG_THRESHOLDS });
    } catch (err) {
      if (err instanceof ApiClientError) {
        setSuiteAlert({ type: 'error', message: err.message });
      } else {
        setSuiteAlert({ type: 'error', message: 'Failed to load suite.' });
      }
    } finally {
      setSuiteLoading(false);
    }
  }, [isCreate, suiteId]);

  // ---------------------------------------------------------------------------
  // Load test cases
  // ---------------------------------------------------------------------------

  const fetchCases = useCallback(async () => {
    if (isCreate || !suiteId) return;
    setCasesLoading(true);
    try {
      const response = await apiClient.get<ListCasesResponse>(`/suites/${suiteId}/cases`);
      setCases(response.cases);
    } catch {
      // Silent fail — will show empty table
    } finally {
      setCasesLoading(false);
    }
  }, [isCreate, suiteId]);

  useEffect(() => {
    fetchAgents();
    fetchSuite();
    fetchCases();
  }, [fetchAgents, fetchSuite, fetchCases]);

  // Update agent selector when agents load
  useEffect(() => {
    if (selectedAgentOption?.value && agents.length > 0) {
      const match = agents.find((a) => a.agentId === selectedAgentOption.value);
      if (match) {
        setSelectedAgentOption({ label: match.name, value: match.agentId, description: match.agentId });
      }
    }
  }, [agents, selectedAgentOption?.value]);

  // ---------------------------------------------------------------------------
  // Suite validation
  // ---------------------------------------------------------------------------

  function validateSuite(): boolean {
    const errors: SuiteFormErrors = {};
    if (!suiteName.trim()) {
      errors.name = 'Suite name is required.';
    } else if (suiteName.length > SUITE_NAME_MAX) {
      errors.name = `Suite name must be at most ${SUITE_NAME_MAX} characters.`;
    }
    if (!selectedAgentOption?.value) {
      errors.agentId = 'An AI Agent must be selected.';
    }
    setSuiteErrors(errors);
    return Object.keys(errors).length === 0;
  }

  // ---------------------------------------------------------------------------
  // Save suite
  // ---------------------------------------------------------------------------

  const handleSaveSuite = async () => {
    if (!validateSuite()) return;
    setSaving(true);
    setSuiteAlert(null);
    try {
      // Persist ragThresholds on every save (including create). Thresholds
      // only take effect when the suite contains RAG cases, but persisting
      // them up-front lets the user pre-configure the bar before adding any
      // RAG cases. Suites with no RAG cases simply ignore the values.
      const body: Record<string, unknown> = {
        name: suiteName.trim(),
        description: suiteDescription.trim() || undefined,
        agentId: selectedAgentOption!.value,
        ragThresholds,
      };
      if (isCreate) {
        const created = await apiClient.post<TestSuite>('/suites', body);
        navigate(`/suites/${created.suiteId}`, { replace: true });
      } else {
        await apiClient.put(`/suites/${suiteId}`, body);
        setSuiteAlert({ type: 'success', message: 'Suite saved successfully.' });
      }
    } catch (err) {
      if (err instanceof ApiClientError) {
        setSuiteAlert({ type: 'error', message: err.message });
      } else {
        setSuiteAlert({ type: 'error', message: 'Failed to save suite.' });
      }
    } finally {
      setSaving(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Agent options
  // ---------------------------------------------------------------------------

  const agentOptions: SelectProps.Options = agents.map((a) => ({
    label: a.name,
    value: a.agentId,
    description: a.agentId,
  }));

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  if (suiteLoading) {
    return (
      <ContentLayout header={<Header variant="h1">Loading...</Header>}>
        <Box textAlign="center" padding="l">
          <Spinner size="large" />
        </Box>
      </ContentLayout>
    );
  }

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description={isCreate ? 'Create a new test suite' : `Suite: ${suiteId}`}
          actions={
            <SpaceBetween direction="horizontal" size="xs">
              <Button variant="link" onClick={() => navigate('/suites')}>
                Back to suites
              </Button>
              {/*
                "Run suite" — the only entry point the GUI exposes for
                starting a Test_Run. The Run Dashboard reads ?suiteId=...
                from the query string, builds the POST /runs body from it,
                and replaces the URL with /runs/{realRunId} once the Step
                Functions execution has been launched.

                Hidden on the create-suite path (no suiteId yet) and
                disabled until the suite has been saved AND has at least
                one test case (running an empty suite is a footgun).
              */}
              {!isCreate && (
                <Button
                  variant="primary"
                  disabled={!suiteId || cases.length === 0}
                  onClick={() => navigate(`/runs/new?suiteId=${suiteId}`)}
                >
                  Run suite
                </Button>
              )}
            </SpaceBetween>
          }
        >
          {isCreate ? 'Create Test Suite' : 'Edit Test Suite'}
        </Header>
      }
    >
      <SpaceBetween size="l">
        {suiteAlert && (
          <Alert
            type={suiteAlert.type}
            dismissible
            onDismiss={() => setSuiteAlert(null)}
          >
            {suiteAlert.message}
          </Alert>
        )}

        {/* Suite Form */}
        <Container header={<Header variant="h2">Suite Configuration</Header>}>
          <Form
            actions={
              <SpaceBetween direction="horizontal" size="xs">
                <Button variant="link" onClick={() => navigate('/suites')}>
                  Cancel
                </Button>
                <Button variant="primary" onClick={handleSaveSuite} loading={saving}>
                  {isCreate ? 'Create suite' : 'Save changes'}
                </Button>
              </SpaceBetween>
            }
          >
            <SpaceBetween size="l">
              <FormField
                label="Suite name"
                constraintText={`Maximum ${SUITE_NAME_MAX} characters`}
                errorText={suiteErrors.name}
              >
                <Input
                  value={suiteName}
                  onChange={({ detail }) => setSuiteName(detail.value)}
                  placeholder="Enter suite name"
                />
              </FormField>

              <FormField
                label="Description"
                constraintText={`Optional. Maximum ${SUITE_DESCRIPTION_MAX} characters`}
              >
                <Textarea
                  value={suiteDescription}
                  onChange={({ detail }) => setSuiteDescription(detail.value)}
                  placeholder="Describe this test suite"
                  rows={3}
                />
              </FormField>

              <FormField
                label="AI Agent"
                errorText={suiteErrors.agentId}
              >
                <Select
                  selectedOption={selectedAgentOption}
                  onChange={({ detail }) => setSelectedAgentOption(detail.selectedOption)}
                  options={agentOptions}
                  placeholder="Select an AI Agent"
                  loadingText="Loading agents..."
                  statusType={agentsLoading ? 'loading' : 'finished'}
                  filteringType="auto"
                  empty="No agents available"
                />
              </FormField>

              {/* RAG Evaluation Thresholds — always visible so testers can
                  configure the quality bar before adding RAG cases. The
                  values only take effect when the suite contains at least
                  one RAG case (suites with no RAG cases simply ignore them).
                  Default-expanded so the form is discoverable in both create
                  and edit modes. */}
              <ExpandableSection
                headerText="RAG Evaluation Thresholds"
                variant="footer"
                defaultExpanded
              >
                <SpaceBetween size="s">
                  <Box variant="p" color="text-body-secondary">
                    Pass/fail thresholds applied to every RAG test case in this
                    suite. Each value must be between 0 and 1 (one decimal place).
                    Defaults to 0.7 for each metric. Faithfulness has a hard gate —
                    falling below it fails the case regardless of other scores.
                  </Box>
                    <SpaceBetween direction="horizontal" size="l">
                      <FormField label="Faithfulness">
                        <Input
                          type="number"
                          value={String(ragThresholds.faithfulness)}
                          onChange={({ detail }) => {
                            const val = parseFloat(detail.value);
                            if (!isNaN(val) && val >= 0 && val <= 1) {
                              setRagThresholds({ ...ragThresholds, faithfulness: Math.round(val * 10) / 10 });
                            } else if (detail.value === '') {
                              setRagThresholds({ ...ragThresholds, faithfulness: 0.7 });
                            }
                          }}
                          step={0.1}
                          inputMode="decimal"
                        />
                      </FormField>
                      <FormField label="Correctness">
                        <Input
                          type="number"
                          value={String(ragThresholds.correctness)}
                          onChange={({ detail }) => {
                            const val = parseFloat(detail.value);
                            if (!isNaN(val) && val >= 0 && val <= 1) {
                              setRagThresholds({ ...ragThresholds, correctness: Math.round(val * 10) / 10 });
                            } else if (detail.value === '') {
                              setRagThresholds({ ...ragThresholds, correctness: 0.7 });
                            }
                          }}
                          step={0.1}
                          inputMode="decimal"
                        />
                      </FormField>
                      <FormField label="Completeness">
                        <Input
                          type="number"
                          value={String(ragThresholds.completeness)}
                          onChange={({ detail }) => {
                            const val = parseFloat(detail.value);
                            if (!isNaN(val) && val >= 0 && val <= 1) {
                              setRagThresholds({ ...ragThresholds, completeness: Math.round(val * 10) / 10 });
                            } else if (detail.value === '') {
                              setRagThresholds({ ...ragThresholds, completeness: 0.7 });
                            }
                          }}
                          step={0.1}
                          inputMode="decimal"
                        />
                      </FormField>
                      <FormField label="Helpfulness">
                        <Input
                          type="number"
                          value={String(ragThresholds.helpfulness)}
                          onChange={({ detail }) => {
                            const val = parseFloat(detail.value);
                            if (!isNaN(val) && val >= 0 && val <= 1) {
                              setRagThresholds({ ...ragThresholds, helpfulness: Math.round(val * 10) / 10 });
                            } else if (detail.value === '') {
                              setRagThresholds({ ...ragThresholds, helpfulness: 0.7 });
                            }
                          }}
                          step={0.1}
                          inputMode="decimal"
                        />
                      </FormField>
                    </SpaceBetween>
                  </SpaceBetween>
                </ExpandableSection>
            </SpaceBetween>
          </Form>
        </Container>

        {/* Test Cases (only visible for existing suites) */}
        {!isCreate && (
          <Container header={<Header variant="h2">Test Cases</Header>}>
            <SpaceBetween size="m">
              <TestCaseTable
                cases={cases}
                loading={casesLoading}
                onEdit={(tc) => {
                  setEditingCase(tc);
                  setCaseEditorVisible(true);
                }}
                onAdd={() => {
                  setEditingCase(null);
                  setCaseEditorVisible(true);
                }}
                onRefresh={fetchCases}
                suiteId={suiteId!}
              />
            </SpaceBetween>
          </Container>
        )}

        {/*
          Run History — replaces the previous top-level "Compare Runs"
          page so a user can browse this suite's runs, drill into one,
          and select two for a side-by-side comparison without leaving
          the suite context. Cross-suite comparisons are intentionally
          not supported (different test cases / agents make the diff
          meaningless).

          Wrapped in an anchor div so the breadcrumb's `Runs` crumb
          (`/suites/{suiteId}#run-history`) scrolls directly to this
          section. Without the wrapping id the fragment hash has
          nowhere to land and the page just renders at the top.
        */}
        {!isCreate && suiteId && (
          <div id="run-history">
            <RunHistorySection suiteId={suiteId} />
          </div>
        )}

        {/* Test Case Editor Modal */}
        {caseEditorVisible && (
          <TestCaseEditorModal
            visible={caseEditorVisible}
            onDismiss={() => setCaseEditorVisible(false)}
            suiteId={suiteId!}
            agentId={selectedAgentOption?.value || ''}
            existingCase={editingCase}
            onSaved={() => {
              setCaseEditorVisible(false);
              fetchCases();
            }}
          />
        )}
      </SpaceBetween>
    </ContentLayout>
  );
}

// ---------------------------------------------------------------------------
// Test Case Table
// ---------------------------------------------------------------------------

interface TestCaseTableProps {
  cases: TestCase[];
  loading: boolean;
  onEdit: (tc: TestCase) => void;
  onAdd: () => void;
  onRefresh: () => void;
  suiteId: string;
}

function TestCaseTable({ cases, loading, onEdit, onAdd, onRefresh, suiteId }: TestCaseTableProps) {
  const [selected, setSelected] = useState<TestCase | null>(null);
  const [deleteVisible, setDeleteVisible] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // "Run this case" tracks per-row launch state so the user can click Run on
  // multiple rows without confusing the loading indicator. Keyed by caseId.
  const [runningCaseId, setRunningCaseId] = useState<string | null>(null);
  const navigate = useNavigate();
  const { trackRun } = useActiveRunsContext();

  /**
   * Launch a one-case run via POST /runs with caseIds=[caseId]. The backend
   * runs the same translate→judge→aggregate→assemble pipeline as a
   * full-suite run, just over a single case. On success we register the
   * run with the active-runs tracker so the persistent banner follows the
   * user across pages, and navigate to the run dashboard.
   */
  const handleRunCase = async (testCase: TestCase) => {
    setRunningCaseId(testCase.caseId);
    setError(null);
    try {
      const response = await apiClient.post<{ runId: string; sfnExecutionArn: string }>(
        '/runs',
        { suiteId, caseIds: [testCase.caseId] },
      );
      trackRun(response.runId, suiteId);
      navigate(`/runs/${response.runId}?suiteId=${suiteId}`);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError(`Failed to start run for case "${testCase.name}".`);
      }
    } finally {
      setRunningCaseId(null);
    }
  };

  const handleDelete = async () => {
    if (!selected) return;
    setDeleting(true);
    try {
      await apiClient.delete(`/suites/${suiteId}/cases/${selected.caseId}`);
      setDeleteVisible(false);
      setSelected(null);
      onRefresh();
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to delete test case.');
      }
    } finally {
      setDeleting(false);
    }
  };

  const columnDefinitions: TableProps.ColumnDefinition<TestCase>[] = [
    { id: 'name', header: 'Name', cell: (item) => item.name, sortingField: 'name' },
    {
      id: 'type',
      header: 'Type',
      cell: (item) => (
        <Badge color={item.type === 'rag' ? 'blue' : 'grey'}>
          {item.type === 'rag' ? 'RAG' : 'Conversation'}
        </Badge>
      ),
      sortingField: 'type',
    },
    {
      // Show the description so test cases are identifiable at a glance
      // (the prior "Initial Utterance" column had every case starting with
      // the same handful of greetings, which made distinguishing them
      // impossible without opening each one). Truncated to 120 chars
      // because a full 2000-char scenario will not fit a table cell.
      id: 'description',
      header: 'Description',
      cell: (item) =>
        item.description.length > 120
          ? item.description.substring(0, 120) + '…'
          : item.description,
      sortingField: 'description',
    },
    {
      id: 'style',
      header: 'Style',
      cell: (item) => item.type === 'tool_sequence' ? item.style : '—',
    },
    {
      id: 'steps',
      header: 'Steps',
      cell: (item) => item.type === 'tool_sequence' ? item.successCriteria.length : '—',
    },
    {
      id: 'actions',
      header: 'Actions',
      cell: (item) => (
        // Per-row "Run" lets the user execute one case without selecting it
        // first; mirrors the IntelliJ "run gutter" affordance. The button's
        // loading flag is keyed to the row's caseId so other rows stay
        // clickable while a launch is pending.
        <Button
          variant="inline-link"
          loading={runningCaseId === item.caseId}
          onClick={() => handleRunCase(item)}
          ariaLabel={`Run test case ${item.name}`}
        >
          Run
        </Button>
      ),
    },
  ];

  return (
    <>
      {error && (
        <Alert type="error" dismissible onDismiss={() => setError(null)}>
          {error}
        </Alert>
      )}
      <Table
        columnDefinitions={columnDefinitions}
        items={cases}
        loading={loading}
        loadingText="Loading test cases..."
        selectionType="single"
        selectedItems={selected ? [selected] : []}
        onSelectionChange={(e) => setSelected((e.detail.selectedItems[0] as TestCase) || null)}
        trackBy="caseId"
        header={
          <Header
            counter={`(${cases.length})`}
            actions={
              <SpaceBetween direction="horizontal" size="xs">
                <Button disabled={!selected} onClick={() => selected && onEdit(selected)}>
                  Edit
                </Button>
                <Button disabled={!selected} onClick={() => setDeleteVisible(true)}>
                  Delete
                </Button>
                <Button variant="primary" onClick={onAdd}>
                  Add test case
                </Button>
              </SpaceBetween>
            }
          >
            Test Cases
          </Header>
        }
        empty={
          <Box textAlign="center" color="inherit" padding="l">
            <SpaceBetween size="m">
              <b>No test cases</b>
              <Box variant="p" color="inherit">
                Add test cases to define customer scenarios.
              </Box>
              <Button onClick={onAdd}>Add test case</Button>
            </SpaceBetween>
          </Box>
        }
      />
      <Modal
        visible={deleteVisible}
        onDismiss={() => setDeleteVisible(false)}
        header="Delete test case"
        footer={
          <Box float="right">
            <SpaceBetween direction="horizontal" size="xs">
              <Button variant="link" onClick={() => setDeleteVisible(false)}>Cancel</Button>
              <Button variant="primary" onClick={handleDelete} loading={deleting}>Delete</Button>
            </SpaceBetween>
          </Box>
        }
      >
        Are you sure you want to delete the test case <strong>{selected?.name}</strong>? This action cannot be undone.
      </Modal>
    </>
  );
}

// ---------------------------------------------------------------------------
// Test Case Editor Modal
// ---------------------------------------------------------------------------

interface TestCaseEditorModalProps {
  visible: boolean;
  onDismiss: () => void;
  suiteId: string;
  agentId: string;
  existingCase: TestCase | null;
  onSaved: () => void;
}

function TestCaseEditorModal({ visible, onDismiss, suiteId, agentId, existingCase, onSaved }: TestCaseEditorModalProps) {
  const isEdit = !!existingCase;

  // Test type state
  const [testType, setTestType] = useState<SelectProps.Option>(
    existingCase?.type === 'rag'
      ? TEST_TYPE_OPTIONS[1]
      : TEST_TYPE_OPTIONS[0]
  );

  // Form state — shared
  const [caseName, setCaseName] = useState(existingCase?.name || '');
  const [caseDescription, setCaseDescription] = useState(existingCase?.description || '');

  // Form state — tool_sequence specific
  const [style, setStyle] = useState<SelectProps.Option | null>(
    existingCase && existingCase.type === 'tool_sequence'
      ? STYLE_OPTIONS.find((o) => o.value === existingCase.style) || STYLE_OPTIONS[0]
      : STYLE_OPTIONS[0]
  );
  const [initialUtterance, setInitialUtterance] = useState(
    existingCase && existingCase.type === 'tool_sequence' ? existingCase.initialUtterance : ''
  );
  const [knowledgePairs, setKnowledgePairs] = useState<KnowledgePair[]>(() => {
    if (existingCase && existingCase.type === 'tool_sequence' && existingCase.customerKnowledge) {
      return Object.entries(existingCase.customerKnowledge).map(([key, value]) => ({ key, value }));
    }
    return [];
  });
  const [toolSteps, setToolSteps] = useState<ToolStep[]>(
    existingCase && existingCase.type === 'tool_sequence'
      ? existingCase.successCriteria || [{ toolName: '', required: true }]
      : [{ toolName: '', required: true }]
  );

  // Form state — RAG specific
  const [question, setQuestion] = useState(
    existingCase && existingCase.type === 'rag' ? existingCase.question : ''
  );
  const [groundTruthAnswer, setGroundTruthAnswer] = useState(
    existingCase && existingCase.type === 'rag' ? existingCase.groundTruthAnswer : ''
  );
  const [ragSessionData, setRagSessionData] = useState<KnowledgePair[]>(() => {
    if (existingCase && existingCase.type === 'rag' && existingCase.sessionData) {
      return Object.entries(existingCase.sessionData).map(([key, value]) => ({ key, value }));
    }
    return [];
  });

  // UI state
  const [errors, setErrors] = useState<CaseFormErrors>({});
  const [saving, setSaving] = useState(false);
  const [alert, setAlert] = useState<string | null>(null);
  const [scaffolding, setScaffolding] = useState(false);
  // The "Goal description" textarea is now persisted as TestCase.goalDescription
  // (see TestCase jsdoc). Prefill from the existing case so editing a case
  // re-shows the goal the user originally entered, instead of an empty box
  // that would silently overwrite the persisted value on save.
  const [scaffoldGoal, setScaffoldGoal] = useState(
    existingCase && existingCase.type === 'tool_sequence' ? existingCase.goalDescription || '' : ''
  );

  // ---------------------------------------------------------------------------
  // Validation
  // ---------------------------------------------------------------------------

  function validateCase(): boolean {
    const errs: CaseFormErrors = {};

    if (caseName.length > CASE_NAME_MAX) {
      errs.name = `Name must be at most ${CASE_NAME_MAX} characters.`;
    }

    if (!caseDescription.trim()) {
      errs.description = 'Description is required.';
    } else if (caseDescription.length > CASE_DESCRIPTION_MAX) {
      errs.description = `Description must be at most ${CASE_DESCRIPTION_MAX} characters.`;
    }

    const selectedType = testType.value;

    if (selectedType === 'tool_sequence') {
      if (!initialUtterance.trim()) {
        errs.initialUtterance = 'Initial utterance is required.';
      } else if (initialUtterance.length > INITIAL_UTTERANCE_MAX) {
        errs.initialUtterance = `Initial utterance must be at most ${INITIAL_UTTERANCE_MAX} characters.`;
      }

      // Validate customer knowledge
      if (knowledgePairs.length > CUSTOMER_KNOWLEDGE_MAX_PAIRS) {
        errs.customerKnowledge = `Maximum ${CUSTOMER_KNOWLEDGE_MAX_PAIRS} knowledge pairs allowed.`;
      } else {
        const invalidPair = knowledgePairs.find(
          (p) => p.key.length > CUSTOMER_KNOWLEDGE_KEY_MAX || p.value.length > CUSTOMER_KNOWLEDGE_VALUE_MAX
        );
        if (invalidPair) {
          errs.customerKnowledge = `Key max ${CUSTOMER_KNOWLEDGE_KEY_MAX} chars, value max ${CUSTOMER_KNOWLEDGE_VALUE_MAX} chars.`;
        }
      }

      // Validate success criteria
      const validSteps = toolSteps.filter((s) => s.toolName.trim());
      if (validSteps.length < SUCCESS_CRITERIA_MIN_STEPS) {
        errs.successCriteria = 'At least one tool step is required in success criteria.';
      } else if (validSteps.length > SUCCESS_CRITERIA_MAX_STEPS) {
        errs.successCriteria = `Maximum ${SUCCESS_CRITERIA_MAX_STEPS} tool steps allowed.`;
      } else {
        const invalidStep = validSteps.find(
          (s) => s.parameterChecks && s.parameterChecks.length > PARAMETER_CHECKS_MAX
        );
        if (invalidStep) {
          errs.successCriteria = `Maximum ${PARAMETER_CHECKS_MAX} parameter checks per step.`;
        }
      }
    } else {
      // RAG validation
      if (!question.trim()) {
        errs.question = 'Question is required.';
      } else if (question.length > RAG_QUESTION_MAX) {
        errs.question = `Question must be at most ${RAG_QUESTION_MAX} characters.`;
      }

      if (!groundTruthAnswer.trim()) {
        errs.groundTruthAnswer = 'Ground truth answer is required.';
      } else if (groundTruthAnswer.length > RAG_GROUND_TRUTH_MAX) {
        errs.groundTruthAnswer = `Ground truth answer must be at most ${RAG_GROUND_TRUTH_MAX} characters.`;
      }

      // Validate RAG session data
      if (ragSessionData.length > CUSTOMER_KNOWLEDGE_MAX_PAIRS) {
        errs.ragSessionData = `Maximum ${CUSTOMER_KNOWLEDGE_MAX_PAIRS} session data pairs allowed.`;
      }
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  // ---------------------------------------------------------------------------
  // Save
  // ---------------------------------------------------------------------------

  const handleSave = async () => {
    if (!validateCase()) return;
    setSaving(true);
    setAlert(null);

    const selectedType = testType.value as 'tool_sequence' | 'rag';

    let body: Record<string, unknown>;

    if (selectedType === 'tool_sequence') {
      // Discard RAG fields — only send tool_sequence fields
      const customerKnowledge: Record<string, string> = {};
      knowledgePairs.forEach((p) => {
        if (p.key.trim()) {
          customerKnowledge[p.key.trim()] = p.value;
        }
      });

      const validSteps = toolSteps.filter((s) => s.toolName.trim());

      body = {
        type: 'tool_sequence',
        name: caseName.trim(),
        description: caseDescription.trim(),
        goalDescription: scaffoldGoal.trim() || undefined,
        persona: caseName.trim(),
        style: style?.value || CommunicationStyle.DIRECT,
        customerKnowledge,
        initialUtterance: initialUtterance.trim(),
        successCriteria: validSteps,
      };
    } else {
      // Discard tool_sequence fields — only send RAG fields
      const sessionData: Record<string, string> = {};
      ragSessionData.forEach((p) => {
        if (p.key.trim()) {
          sessionData[p.key.trim()] = p.value;
        }
      });

      body = {
        type: 'rag',
        name: caseName.trim(),
        description: caseDescription.trim(),
        question: question.trim(),
        groundTruthAnswer: groundTruthAnswer.trim(),
        ...(Object.keys(sessionData).length > 0 ? { sessionData } : {}),
      };
    }

    try {
      if (isEdit) {
        await apiClient.put(`/suites/${suiteId}/cases/${existingCase!.caseId}`, body);
      } else {
        await apiClient.post(`/suites/${suiteId}/cases`, body);
      }
      onSaved();
    } catch (err) {
      if (err instanceof ApiClientError) {
        setAlert(err.message);
      } else {
        setAlert('Failed to save test case.');
      }
    } finally {
      setSaving(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Suggest Tools (scaffold)
  // ---------------------------------------------------------------------------

  const handleSuggestTools = async () => {
    if (!scaffoldGoal.trim() || !agentId) return;
    setScaffolding(true);
    setAlert(null);
    try {
      const response = await apiClient.post<ScaffoldResponse>(
        `/suites/${suiteId}/cases/scaffold`,
        { goalDescription: scaffoldGoal.trim(), agentId }
      );
      // Apply suggested tools
      const newSteps: ToolStep[] = response.suggestedTools.map((t) => ({
        toolName: t.toolName,
        required: t.required,
      }));
      if (newSteps.length > 0) {
        setToolSteps(newSteps);
      }
      // Apply customer knowledge template
      if (response.customerKnowledgeTemplate.length > 0) {
        const newPairs: KnowledgePair[] = response.customerKnowledgeTemplate.map((t) => ({
          key: t.key,
          value: '',
        }));
        setKnowledgePairs(newPairs);
      }
    } catch (err) {
      if (err instanceof ApiClientError) {
        setAlert(err.message);
      } else {
        setAlert('Failed to suggest tools. You can manually build the tool sequence.');
      }
    } finally {
      setScaffolding(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Tool Steps management
  // ---------------------------------------------------------------------------

  const addToolStep = () => {
    if (toolSteps.length >= SUCCESS_CRITERIA_MAX_STEPS) return;
    setToolSteps([...toolSteps, { toolName: '', required: true }]);
  };

  const removeToolStep = (index: number) => {
    setToolSteps(toolSteps.filter((_, i) => i !== index));
  };

  const updateToolStep = (index: number, field: keyof ToolStep, value: string | boolean) => {
    const updated = [...toolSteps];
    if (field === 'toolName') {
      updated[index] = { ...updated[index], toolName: value as string };
    } else if (field === 'required') {
      updated[index] = { ...updated[index], required: value as boolean };
    }
    setToolSteps(updated);
  };

  const moveToolStep = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= toolSteps.length) return;
    const updated = [...toolSteps];
    [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]];
    setToolSteps(updated);
  };

  // ---------------------------------------------------------------------------
  // Knowledge pairs (AttributeEditor)
  // ---------------------------------------------------------------------------

  const knowledgeDefinition: AttributeEditorProps.FieldDefinition<KnowledgePair>[] = [
    {
      label: 'Key',
      control: (item: KnowledgePair, index: number) => (
        <Input
          value={item.key}
          onChange={({ detail }) => {
            const updated = [...knowledgePairs];
            updated[index] = { ...updated[index], key: detail.value };
            setKnowledgePairs(updated);
          }}
          placeholder="e.g. account_number"
        />
      ),
      constraintText: `Max ${CUSTOMER_KNOWLEDGE_KEY_MAX} chars`,
    },
    {
      label: 'Value',
      control: (item: KnowledgePair, index: number) => (
        <Input
          value={item.value}
          onChange={({ detail }) => {
            const updated = [...knowledgePairs];
            updated[index] = { ...updated[index], value: detail.value };
            setKnowledgePairs(updated);
          }}
          placeholder="e.g. 123456789"
        />
      ),
      constraintText: `Max ${CUSTOMER_KNOWLEDGE_VALUE_MAX} chars`,
    },
  ];

  const ragSessionDataDefinition: AttributeEditorProps.FieldDefinition<KnowledgePair>[] = [
    {
      label: 'Key',
      control: (item: KnowledgePair, index: number) => (
        <Input
          value={item.key}
          onChange={({ detail }) => {
            const updated = [...ragSessionData];
            updated[index] = { ...updated[index], key: detail.value };
            setRagSessionData(updated);
          }}
          placeholder="e.g. department"
        />
      ),
      constraintText: `Max ${CUSTOMER_KNOWLEDGE_KEY_MAX} chars`,
    },
    {
      label: 'Value',
      control: (item: KnowledgePair, index: number) => (
        <Input
          value={item.value}
          onChange={({ detail }) => {
            const updated = [...ragSessionData];
            updated[index] = { ...updated[index], value: detail.value };
            setRagSessionData(updated);
          }}
          placeholder="e.g. engineering"
        />
      ),
      constraintText: `Max ${CUSTOMER_KNOWLEDGE_VALUE_MAX} chars`,
    },
  ];

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  return (
    <Modal
      visible={visible}
      onDismiss={onDismiss}
      header={isEdit ? 'Edit Test Case' : 'Add Test Case'}
      size="large"
      footer={
        <Box float="right">
          <SpaceBetween direction="horizontal" size="xs">
            <Button variant="link" onClick={onDismiss}>Cancel</Button>
            <Button variant="primary" onClick={handleSave} loading={saving}>
              {isEdit ? 'Save changes' : 'Create test case'}
            </Button>
          </SpaceBetween>
        </Box>
      }
    >
      <SpaceBetween size="l">
        {alert && (
          <Alert type="error" dismissible onDismiss={() => setAlert(null)}>
            {alert}
          </Alert>
        )}

        {/* Test Type Dropdown — first field, disabled in edit mode */}
        <FormField label="Test Type">
          <Select
            selectedOption={testType}
            onChange={({ detail }) => setTestType(detail.selectedOption)}
            options={TEST_TYPE_OPTIONS}
            disabled={isEdit}
          />
        </FormField>

        {/* Basic Info — shared between both types */}
        <FormField
          label="Test case name"
          constraintText={`Maximum ${CASE_NAME_MAX} characters`}
          errorText={errors.name}
        >
          <Input
            value={caseName}
            onChange={({ detail }) => setCaseName(detail.value)}
            placeholder="Enter test case name"
          />
        </FormField>

        <FormField
          label="Description"
          constraintText={`Required. Maximum ${CASE_DESCRIPTION_MAX} characters`}
          errorText={errors.description}
        >
          <Textarea
            value={caseDescription}
            onChange={({ detail }) => setCaseDescription(detail.value)}
            placeholder="Describe the customer scenario this test case validates"
            rows={4}
          />
        </FormField>

        {/* === Tool Sequence fields === */}
        {testType.value === 'tool_sequence' && (
          <>
            <FormField label="Persona communication style">
              <Select
                selectedOption={style}
                onChange={({ detail }) => setStyle(detail.selectedOption)}
                options={STYLE_OPTIONS}
              />
            </FormField>

            {/* Customer Knowledge */}
            <FormField
              label="Customer knowledge"
              constraintText={`Key-value pairs the simulated customer knows. Maximum ${CUSTOMER_KNOWLEDGE_MAX_PAIRS} pairs.`}
              errorText={errors.customerKnowledge}
            >
              <AttributeEditor
                items={knowledgePairs}
                definition={knowledgeDefinition}
                onAddButtonClick={() => {
                  if (knowledgePairs.length < CUSTOMER_KNOWLEDGE_MAX_PAIRS) {
                    setKnowledgePairs([...knowledgePairs, { key: '', value: '' }]);
                  }
                }}
                onRemoveButtonClick={({ detail }) => {
                  setKnowledgePairs(knowledgePairs.filter((_, i) => i !== detail.itemIndex));
                }}
                addButtonText="Add knowledge pair"
                removeButtonText="Remove"
                empty="No customer knowledge defined."
                isItemRemovable={() => true}
              />
            </FormField>

            {/* Initial Utterance */}
            <FormField
              label="Initial utterance"
              constraintText={`Required. Maximum ${INITIAL_UTTERANCE_MAX} characters. The first message sent to the agent.`}
              errorText={errors.initialUtterance}
            >
              <Textarea
                value={initialUtterance}
                onChange={({ detail }) => setInitialUtterance(detail.value)}
                placeholder="e.g. Hi, I need to rebook my flight for tomorrow"
                rows={2}
              />
            </FormField>

            {/* Suggest Tools */}
            <Container header={<Header variant="h3">Suggest Tools</Header>}>
              <SpaceBetween size="s">
                <FormField
                  label="Goal description"
                  constraintText="Describe the customer's goal and the platform will suggest the expected tool sequence."
                >
                  <Textarea
                    value={scaffoldGoal}
                    onChange={({ detail }) => setScaffoldGoal(detail.value)}
                    placeholder="e.g. Customer wants to rebook a flight to a different date"
                    rows={2}
                  />
                </FormField>
                <Button
                  onClick={handleSuggestTools}
                  loading={scaffolding}
                  disabled={!scaffoldGoal.trim() || !agentId}
                >
                  Suggest Tools
                </Button>
              </SpaceBetween>
            </Container>

            {/* Success Criteria (Tool Sequence Builder) */}
            <FormField
              label="Success criteria — expected tool sequence"
              constraintText={`Ordered sequence of tools the agent should invoke. ${SUCCESS_CRITERIA_MIN_STEPS}–${SUCCESS_CRITERIA_MAX_STEPS} steps.`}
              errorText={errors.successCriteria}
            >
              <SpaceBetween size="s">
                {toolSteps.map((step, index) => (
                  <ToolStepRow
                    key={index}
                    step={step}
                    index={index}
                    total={toolSteps.length}
                    onChange={(field, value) => updateToolStep(index, field, value)}
                    onRemove={() => removeToolStep(index)}
                    onMove={(dir) => moveToolStep(index, dir)}
                  />
                ))}
                <Button
                  iconName="add-plus"
                  onClick={addToolStep}
                  disabled={toolSteps.length >= SUCCESS_CRITERIA_MAX_STEPS}
                >
                  Add tool step
                </Button>
              </SpaceBetween>
            </FormField>
          </>
        )}

        {/* === RAG fields === */}
        {testType.value === 'rag' && (
          <>
            <FormField
              label="Question"
              constraintText={`Required. Maximum ${RAG_QUESTION_MAX} characters. The single question sent to the agent.`}
              errorText={errors.question}
            >
              <Textarea
                value={question}
                onChange={({ detail }) => setQuestion(detail.value)}
                placeholder="e.g. What is the refund policy for cancelled flights?"
                rows={3}
              />
            </FormField>

            <FormField
              label="Ground Truth Answer"
              constraintText={`Required. Maximum ${RAG_GROUND_TRUTH_MAX} characters. The known-good answer for metric scoring.`}
              errorText={errors.groundTruthAnswer}
            >
              <Textarea
                value={groundTruthAnswer}
                onChange={({ detail }) => setGroundTruthAnswer(detail.value)}
                placeholder="The expected correct answer the agent should provide"
                rows={5}
              />
            </FormField>

            <ExpandableSection headerText="Session Data (optional)">
              <FormField
                constraintText={`Key-value pairs injected into the session before the question is sent. Maximum ${CUSTOMER_KNOWLEDGE_MAX_PAIRS} pairs.`}
                errorText={errors.ragSessionData}
              >
                <AttributeEditor
                  items={ragSessionData}
                  definition={ragSessionDataDefinition}
                  onAddButtonClick={() => {
                    if (ragSessionData.length < CUSTOMER_KNOWLEDGE_MAX_PAIRS) {
                      setRagSessionData([...ragSessionData, { key: '', value: '' }]);
                    }
                  }}
                  onRemoveButtonClick={({ detail }) => {
                    setRagSessionData(ragSessionData.filter((_, i) => i !== detail.itemIndex));
                  }}
                  addButtonText="Add session data pair"
                  removeButtonText="Remove"
                  empty="No session data defined."
                  isItemRemovable={() => true}
                />
              </FormField>
            </ExpandableSection>
          </>
        )}
      </SpaceBetween>
    </Modal>
  );
}

// ---------------------------------------------------------------------------
// Tool Step Row
// ---------------------------------------------------------------------------

interface ToolStepRowProps {
  step: ToolStep;
  index: number;
  total: number;
  onChange: (field: keyof ToolStep, value: string | boolean) => void;
  onRemove: () => void;
  onMove: (direction: 'up' | 'down') => void;
}

function ToolStepRow({ step, index, total, onChange, onRemove, onMove }: ToolStepRowProps) {
  return (
    <SpaceBetween direction="horizontal" size="xs" alignItems="center">
      <Box variant="code" fontSize="body-s" color="text-status-inactive">
        {index + 1}.
      </Box>
      <div style={{ flex: 1 }}>
        <Input
          value={step.toolName}
          onChange={({ detail }) => onChange('toolName', detail.value)}
          placeholder="Tool name"
        />
      </div>
      <Toggle
        checked={step.required}
        onChange={({ detail }) => onChange('required', detail.checked)}
      >
        {step.required ? 'Required' : 'Optional'}
      </Toggle>
      <Button
        iconName="angle-up"
        variant="icon"
        onClick={() => onMove('up')}
        disabled={index === 0}
        ariaLabel="Move up"
      />
      <Button
        iconName="angle-down"
        variant="icon"
        onClick={() => onMove('down')}
        disabled={index === total - 1}
        ariaLabel="Move down"
      />
      <Button
        iconName="close"
        variant="icon"
        onClick={onRemove}
        ariaLabel="Remove step"
      />
    </SpaceBetween>
  );
}

// ---------------------------------------------------------------------------
// Run History (suite-scoped run list + comparison launcher)
// ---------------------------------------------------------------------------

interface ListRunsResponse {
  runs: TestRun[];
  nextToken?: string;
}

/**
 * Renders a colored Cloudscape badge for the given run status. Mirrors the
 * helper in TestSuites.tsx; consolidating it here keeps the suite-detail
 * page self-contained.
 */
function runStatusIndicator(status: RunStatus | undefined): JSX.Element {
  if (!status) return <StatusIndicator type="info">—</StatusIndicator>;
  const map: Record<RunStatus, StatusIndicatorProps.Type> = {
    [RunStatus.RUNNING]: 'in-progress',
    [RunStatus.COMPLETED]: 'success',
    [RunStatus.FAILED]: 'error',
    [RunStatus.ABORTED]: 'stopped',
  };
  const label: Record<RunStatus, string> = {
    [RunStatus.RUNNING]: 'Running',
    [RunStatus.COMPLETED]: 'Completed',
    [RunStatus.FAILED]: 'Failed',
    [RunStatus.ABORTED]: 'Aborted',
  };
  return <StatusIndicator type={map[status]}>{label[status]}</StatusIndicator>;
}

/**
 * Suite-scoped Run History section, embedded on the Suite Detail page in
 * place of the previous top-level "Compare Runs" route. Lists runs for
 * the current suite, lets the user drill into one (Run Dashboard) or
 * select exactly two for a side-by-side comparison.
 *
 * The comparison itself is rendered by the existing Comparison page —
 * we deep-link to it with `?suiteId=…&runIds=A,B` so all the
 * heavy-lifting (results / scores / config-diff) stays in one place.
 *
 * Live-polls every 5s while any visible run is RUNNING so the user can
 * watch a launched run progress without leaving the suite.
 */
function RunHistorySection({ suiteId }: { suiteId: string }): JSX.Element {
  const navigate = useNavigate();
  const [runs, setRuns] = useState<TestRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<TestRun[]>([]);

  const fetchRuns = useCallback(async () => {
    setError(null);
    try {
      const response = await apiClient.get<ListRunsResponse>(
        `/suites/${suiteId}/runs?limit=50`,
      );
      setRuns(response.runs);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('Failed to load run history.');
      }
    } finally {
      setLoading(false);
    }
  }, [suiteId]);

  useEffect(() => {
    setLoading(true);
    fetchRuns();
  }, [fetchRuns]);

  // Auto-poll while any run is RUNNING. Stops as soon as every visible
  // run has settled — same approach the Test Suites list uses, just
  // scoped to one suite here.
  useEffect(() => {
    const anyRunning = runs.some((r) => r.status === RunStatus.RUNNING);
    if (!anyRunning) return;
    const id = setInterval(() => {
      fetchRuns();
    }, 5_000);
    return () => clearInterval(id);
  }, [runs, fetchRuns]);

  const onSelectionChange: TableProps<TestRun>['onSelectionChange'] = (event) => {
    const items = event.detail.selectedItems as TestRun[];
    if (items.length <= 2) setSelected(items);
  };

  const handleCompare = () => {
    if (selected.length !== 2) return;
    const ids = selected.map((r) => r.runId).join(',');
    navigate(`/compare?suiteId=${suiteId}&runIds=${ids}`);
  };

  const columns: TableProps.ColumnDefinition<TestRun>[] = [
    {
      id: 'startTime',
      header: 'Started',
      cell: (item) => new Date(item.startTime).toLocaleString(),
      sortingField: 'startTime',
    },
    {
      id: 'status',
      header: 'Status',
      cell: (item) => runStatusIndicator(item.status),
    },
    {
      id: 'accuracy',
      header: 'Accuracy',
      cell: (item) =>
        item.totalCases > 0
          ? `${((item.passed / item.totalCases) * 100).toFixed(1)}%`
          : '—',
    },
    {
      id: 'passRate',
      header: 'Pass / Total',
      cell: (item) =>
        item.totalCases > 0 ? `${item.passed} / ${item.totalCases}` : '—',
    },
    {
      id: 'open',
      header: 'Open',
      // Link straight to the Run Dashboard for that run, preserving the
      // suiteId hint so the dashboard can resolve in-progress run records
      // from the suite partition (see getRunByRunId in results.ts).
      cell: (item) => (
        <Button
          variant="inline-link"
          onClick={() =>
            navigate(`/runs/${item.runId}?suiteId=${suiteId}`)
          }
        >
          View
        </Button>
      ),
    },
    {
      id: 'runId',
      header: 'Run ID',
      cell: (item) => (
        <Box variant="code" fontSize="body-s">
          {item.runId.slice(0, 12)}…
        </Box>
      ),
    },
  ];

  return (
    <Container
      header={
        <Header
          variant="h2"
          counter={`(${runs.length})`}
          description="Run history for this suite. Select two runs to compare."
          actions={
            <SpaceBetween direction="horizontal" size="xs">
              <Button iconName="refresh" onClick={fetchRuns} loading={loading}>
                Refresh
              </Button>
              <Button
                variant="primary"
                disabled={selected.length !== 2}
                onClick={handleCompare}
              >
                Compare selected runs
              </Button>
            </SpaceBetween>
          }
        >
          Run History
        </Header>
      }
    >
      <SpaceBetween size="m">
        {error && (
          <Alert type="error" dismissible onDismiss={() => setError(null)}>
            {error}
          </Alert>
        )}
        <Table
          columnDefinitions={columns}
          items={runs}
          loading={loading}
          loadingText="Loading run history..."
          selectionType="multi"
          selectedItems={selected}
          onSelectionChange={onSelectionChange}
          isItemDisabled={(item) =>
            selected.length >= 2 && !selected.some((r) => r.runId === item.runId)
          }
          trackBy="runId"
          variant="embedded"
          empty={
            <Box textAlign="center" padding="l">
              <SpaceBetween size="m">
                <b>No runs yet</b>
                <Box variant="p" color="inherit">
                  Click "Run suite" above to launch your first test run.
                </Box>
              </SpaceBetween>
            </Box>
          }
        />
      </SpaceBetween>
    </Container>
  );
}
