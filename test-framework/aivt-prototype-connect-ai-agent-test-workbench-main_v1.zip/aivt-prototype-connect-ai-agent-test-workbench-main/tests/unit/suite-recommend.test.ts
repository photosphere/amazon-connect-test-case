/**
 * Unit tests for the Suite Recommend Lambda handler
 * (`POST /runs/{runId}/recommend-suite`).
 *
 * The Lambda exposes two test seams: `_setBedrockClient` (the Bedrock
 * Converse client) and `_setDDBDocClient` (the DynamoDB document client).
 * Tests inject duck-typed mocks through these seams so no real AWS SDK
 * is invoked.
 *
 * Coverage (task 12.7):
 *   - Persisted-read shortcut: `force !== true` returns the persisted
 *     record unchanged AND does not invoke Bedrock (R8.8, R9.3).
 *   - `force: true` bypasses the shortcut, re-invokes Bedrock, overwrites
 *     the persisted record, refreshes `generatedAt` (R8.7).
 *   - Server-side ordering: comparator + 1-based dense rank produces a
 *     monotonic-priority array (R9.1, R9.2).
 *   - Drop invalid `targetField` (R5.9), empty `targetName` (R13.3),
 *     no-op recommendations (R13.3), and `liftedCaseIds` references
 *     not in the failed-case-ID set (R8.6).
 *   - Deduplicate `liftedCaseIds` within each surviving recommendation
 *     (R8.6).
 *   - Snapshot missing → HTTP 404 `{ error: "snapshot_missing" }`
 *     (R12.3).
 *   - Snapshot examples malformed → HTTP 500
 *     `{ error: "snapshot_examples_malformed", toolName }` (R5.8).
 *   - Empty model output → persists `[]` and returns 200 with empty
 *     array (R8.1).
 *   - Persistence failure on DDB write → response still returns 200 with
 *     the in-memory sorted recommendations (R6.6 semantics).
 *   - Throttle posture: `ThrottlingException` is retried; terminal
 *     throttle returns HTTP 503 with `retryable: true` (R12.1, R12.2).
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import {
  GetCommand,
  PutCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";
import { ConverseCommand } from "@aws-sdk/client-bedrock-runtime";

import {
  handler,
  parseSuiteRecommendResponse,
  filterAndNormalizeSuiteRecommendations,
  sortAndDenseRankSuiteRecommendations,
  _setBedrockClient,
  _setDDBDocClient,
  type SuiteRecommendResponse,
} from "../../src/backend/handlers/suite-recommend";
import {
  buildInferenceConfig,
  resolvePrompt,
} from "../../src/backend/orchestration/prompt-registry";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";
import type {
  AgentSnapshot,
  PerSuiteRecommendation,
  TestCaseResult,
  ToolDefinition,
} from "../../src/shared/types";
import { CaseStatus, RunStatus } from "../../src/shared/enums";

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------

/** Tag the keyed item shape DDB returns for SK=ANALYSIS#SUITE. */
interface PersistedSuiteItem {
  PK: string;
  SK: string;
  recommendations: PerSuiteRecommendation[];
  generatedAt: string;
  modelId: string;
}

const RUN_ID = "run-12345";
const PK_RUN = `RUN#${RUN_ID}`;

/**
 * Build a minimal {@link AgentSnapshot} fixture with `examples` arrays
 * populated on every tool. Used for happy-path tests where the snapshot
 * must be present and well-formed.
 */
function makeSnapshot(overrides: Partial<AgentSnapshot> = {}): AgentSnapshot {
  const tools: ToolDefinition[] = [
    {
      toolName: "lookupAccount",
      toolType: "FUNCTION",
      description: "Look up account information.",
      instruction: "Use when the customer asks about their account.",
      inputSchema: {},
      examples: ["What's my balance?", "Show my recent transactions"],
    },
    {
      toolName: "transferFunds",
      toolType: "FUNCTION",
      description: "Transfer money between accounts.",
      instruction: "Use when the customer wants to transfer money.",
      inputSchema: {},
      examples: [],
    },
  ];
  return {
    tools,
    systemPrompt: "You are a helpful banking assistant.",
    modelId: "claude-3",
    capturedAt: "2024-06-01T00:00:00Z",
    ...overrides,
  };
}

/** Build a failed test case result fixture. */
function makeFailedCase(caseId: string): TestCaseResult {
  return {
    runId: RUN_ID,
    caseId,
    status: CaseStatus.FAILED,
    toolsInvoked: ["transferFunds"],
    turnCount: 1,
    latencyMs: 5000,
    errorMessage: `Wrong tool selected for ${caseId}`,
  };
}

/**
 * Tag the structural shape of a candidate recommendation as the model
 * would emit it. The handler's `filterAndNormalizeSuiteRecommendations`
 * tolerates loose shapes, so the fixture is `unknown`-typed at the
 * boundary and cast on the way in.
 */
function makeCandidate(overrides: Partial<PerSuiteRecommendation> = {}): PerSuiteRecommendation {
  return {
    targetField: "tool_description",
    targetName: "lookupAccount",
    currentText: "Look up account information.",
    suggestedText: "Look up account information including balance and history.",
    rationale: "Existing description is too sparse.",
    priority: 1,
    predictedImpact: {
      liftedCaseIds: ["case-1"],
      rationale: "Disambiguates from transferFunds.",
    },
    ...overrides,
  };
}

/**
 * Wrap a JSON object into a Bedrock Converse response shape.
 */
function bedrockResponseWith(body: unknown): {
  output: { message: { content: { text: string }[] } };
} {
  return {
    output: {
      message: {
        content: [{ text: JSON.stringify(body) }],
      },
    },
  };
}

/**
 * Build a `ThrottlingException` that matches the SDK's runtime shape.
 * The handler discriminates by `error.name`.
 */
function throttleError(): Error {
  const e = new Error("Rate exceeded");
  (e as { name: string }).name = "ThrottlingException";
  return e;
}

/**
 * Construct an APIGateway-shaped request event for the Lambda.
 */
function makeEvent(body?: unknown): {
  httpMethod: string;
  body: string | null;
  pathParameters: { runId: string };
  resource: string;
} {
  return {
    httpMethod: "POST",
    body: body === undefined ? null : JSON.stringify(body),
    pathParameters: { runId: RUN_ID },
    resource: "/runs/{runId}/recommend-suite",
  };
}

/**
 * Smart DDB mock dispatcher. Routes commands to per-command handlers
 * based on the command class name, so callers can express intent
 * declaratively rather than ordering `mockResolvedValueOnce` calls.
 *
 * The Lambda issues, in order:
 *   1. GetCommand (ANALYSIS#SUITE) — only if !force
 *   2. QueryCommand (begins_with CASE#)
 *   3. GetCommand (SNAPSHOT)
 *   4. QueryCommand (begins_with ANALYSIS#CASE#)
 *   5. PutCommand (ANALYSIS#SUITE)  — persistence-on-success
 */
interface DDBHandlers {
  /** Map of `SK` → return value for `GetCommand`. */
  getResults?: Map<string, unknown>;
  /** Function returning `{ Items: [...] }` for `QueryCommand`, keyed by SK prefix. */
  queryResults?: Map<string, { Items: unknown[] }>;
  /** Override the put behaviour; default is success. */
  putBehaviour?: () => Promise<unknown>;
}

interface DDBMock {
  client: {
    send: ReturnType<typeof vi.fn>;
  };
  /** All `PutCommand` payloads written, in order. */
  puts: Array<Record<string, unknown>>;
  /** Whether a GetCommand for ANALYSIS#SUITE was issued. */
  suiteGetCalls: number;
  /** Whether a PutCommand for ANALYSIS#SUITE was issued. */
  suitePutCalls: number;
}

function makeDDBMock(handlers: DDBHandlers): DDBMock {
  const puts: Array<Record<string, unknown>> = [];
  let suiteGetCalls = 0;
  let suitePutCalls = 0;

  const send = vi.fn(async (command: unknown) => {
    if (command instanceof GetCommand) {
      const sk = command.input.Key?.SK as string | undefined;
      if (sk === "ANALYSIS#SUITE") suiteGetCalls += 1;
      const result = handlers.getResults?.get(sk ?? "");
      return result === undefined ? { Item: undefined } : result;
    }
    if (command instanceof QueryCommand) {
      const skPrefix = command.input.ExpressionAttributeValues?.[":sk"] as
        | string
        | undefined;
      const result = handlers.queryResults?.get(skPrefix ?? "");
      return result ?? { Items: [] };
    }
    if (command instanceof PutCommand) {
      const item = command.input.Item as Record<string, unknown>;
      puts.push(item);
      if (item?.SK === "ANALYSIS#SUITE") suitePutCalls += 1;
      if (handlers.putBehaviour) return handlers.putBehaviour();
      return {};
    }
    throw new Error(
      `Unexpected DDB command in test: ${command?.constructor?.name ?? typeof command}`,
    );
  });

  const mock: DDBMock = {
    client: { send },
    puts,
    get suiteGetCalls() {
      return suiteGetCalls;
    },
    get suitePutCalls() {
      return suitePutCalls;
    },
  } as DDBMock;
  return mock;
}

// ---------------------------------------------------------------------------
// Module-level setup / teardown
// ---------------------------------------------------------------------------

const originalEnv = { ...process.env };

beforeEach(() => {
  process.env.TABLE_NAME = "ConnectAgentTestPlatform";
  process.env.AWS_REGION = "us-east-1";

  // Inject a stub Prompts_Store so `resolvePromptLive("suite_recommendation")`
  // returns the registry's bundled default triple instead of attempting a
  // real DynamoDB read. The handler executes outside any run scope, so
  // only `listPromptOverrides` is consulted; `getSnapshot` is wired for
  // symmetry but never called on this path.
  _clearPromptRegistryCaches();
  const promptStore = {
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
    getSnapshot: vi.fn().mockResolvedValue(null),
  } as unknown as DynamoDBService;
  _setPromptRegistryStore(promptStore);
});

afterEach(() => {
  _setBedrockClient(null);
  _setDDBDocClient(null);
  _setPromptRegistryStore(null);
  _clearPromptRegistryCaches();
  process.env = { ...originalEnv };
  vi.restoreAllMocks();
});

// ===========================================================================
// Tests — pure helpers (no Lambda invocation needed)
// ===========================================================================

describe("filterAndNormalizeSuiteRecommendations", () => {
  it("drops recommendations with an invalid targetField (R5.9)", () => {
    const candidates = [
      makeCandidate(),
      makeCandidate({
        // Cast through unknown to construct the invalid payload the
        // model could plausibly emit.
        targetField: "totally_invalid" as unknown as PerSuiteRecommendation["targetField"],
        targetName: "lookupAccount",
      }),
    ];
    const out = filterAndNormalizeSuiteRecommendations(
      candidates,
      new Set(["case-1"]),
      new Set(),
    );
    expect(out).toHaveLength(1);
    expect(out[0].targetField).toBe("tool_description");
  });

  it("drops recommendations with an empty targetName (R13.3)", () => {
    const candidates = [
      makeCandidate({ targetName: "" }),
      makeCandidate({ targetName: "   " }),
      makeCandidate({ targetName: "lookupAccount" }),
    ];
    const out = filterAndNormalizeSuiteRecommendations(
      candidates,
      new Set(["case-1"]),
      new Set(),
    );
    expect(out).toHaveLength(1);
    expect(out[0].targetName).toBe("lookupAccount");
  });

  it("drops no-op recommendations where both currentText and suggestedText are empty (R13.3)", () => {
    const candidates = [
      makeCandidate({ currentText: "", suggestedText: "" }),
      makeCandidate({ currentText: "old", suggestedText: "" }),
      makeCandidate({ currentText: "", suggestedText: "new" }),
    ];
    const out = filterAndNormalizeSuiteRecommendations(
      candidates,
      new Set(["case-1"]),
      new Set(),
    );
    expect(out).toHaveLength(2);
    expect(out.map((r) => r.suggestedText)).toEqual(["", "new"]);
  });

  it("drops liftedCaseIds entries that are not in the failed-case-ID set (R8.6)", () => {
    const candidates = [
      makeCandidate({
        predictedImpact: {
          liftedCaseIds: ["case-1", "case-99-not-in-set", "case-2"],
          rationale: "test",
        },
      }),
    ];
    const out = filterAndNormalizeSuiteRecommendations(
      candidates,
      new Set(["case-1", "case-2"]),
      new Set(),
    );
    expect(out).toHaveLength(1);
    expect(out[0].predictedImpact.liftedCaseIds).toEqual(["case-1", "case-2"]);
  });

  it("deduplicates liftedCaseIds within each surviving recommendation (R8.6)", () => {
    const candidates = [
      makeCandidate({
        predictedImpact: {
          liftedCaseIds: ["case-1", "case-2", "case-1", "case-2", "case-1"],
          rationale: "dup test",
        },
      }),
    ];
    const out = filterAndNormalizeSuiteRecommendations(
      candidates,
      new Set(["case-1", "case-2"]),
      new Set(),
    );
    expect(out[0].predictedImpact.liftedCaseIds).toEqual(["case-1", "case-2"]);
  });
});

describe("sortAndDenseRankSuiteRecommendations", () => {
  it("renumbers priority into a 1-based dense rank monotonic with array index (R9.1)", () => {
    const recs: PerSuiteRecommendation[] = [
      makeCandidate({
        targetName: "B",
        priority: 7,
        predictedImpact: { liftedCaseIds: ["case-1"], rationale: "" },
      }),
      makeCandidate({
        targetName: "A",
        priority: 3,
        predictedImpact: { liftedCaseIds: ["case-1", "case-2"], rationale: "" },
      }),
      makeCandidate({
        targetName: "C",
        priority: 11,
        predictedImpact: { liftedCaseIds: ["case-1"], rationale: "" },
      }),
    ];
    const sorted = sortAndDenseRankSuiteRecommendations(recs);

    // Monotonic-priority property holds.
    for (let i = 0; i + 1 < sorted.length; i++) {
      expect(sorted[i].priority).toBeLessThanOrEqual(sorted[i + 1].priority);
    }
    // Original priorities (3, 7, 11) collapse into 1, 2, 3.
    expect(sorted.map((r) => r.priority)).toEqual([1, 2, 3]);
    // Comparator: priority asc → array reordered to start with the
    // model-priority-3 entry.
    expect(sorted[0].targetName).toBe("A");
  });

  it("breaks ties using liftedCaseIds.length desc, then lex(targetField+'|'+targetName) asc", () => {
    const recs: PerSuiteRecommendation[] = [
      // Same priority — tie broken first by liftedCaseIds.length DESC,
      // then by lex order ASC. Three entries:
      //   X: priority=5, lifted=["c1"]              → 1 lift, "tool_description|X"
      //   Y: priority=5, lifted=["c1","c2","c3"]    → 3 lifts, "tool_description|Y"
      //   Z: priority=5, lifted=["c1","c2"]         → 2 lifts, "tool_description|Z"
      // Expected order after dense-rank: Y, Z, X.
      makeCandidate({
        targetName: "X",
        priority: 5,
        predictedImpact: { liftedCaseIds: ["c1"], rationale: "" },
      }),
      makeCandidate({
        targetName: "Y",
        priority: 5,
        predictedImpact: { liftedCaseIds: ["c1", "c2", "c3"], rationale: "" },
      }),
      makeCandidate({
        targetName: "Z",
        priority: 5,
        predictedImpact: { liftedCaseIds: ["c1", "c2"], rationale: "" },
      }),
    ];

    const sorted = sortAndDenseRankSuiteRecommendations(recs);
    expect(sorted.map((r) => r.targetName)).toEqual(["Y", "Z", "X"]);
    // All three share an original priority — dense-rank collapses them
    // into the same priority value (1).
    expect(sorted.map((r) => r.priority)).toEqual([1, 1, 1]);
  });

  it("returns an empty array for empty input", () => {
    expect(sortAndDenseRankSuiteRecommendations([])).toEqual([]);
  });
});

describe("parseSuiteRecommendResponse", () => {
  it("parses a valid JSON object", () => {
    const body = {
      recommendations: [
        {
          targetField: "tool_description",
          targetName: "lookupAccount",
          currentText: "old",
          suggestedText: "new",
          rationale: "because",
          priority: 1,
          predictedImpact: { liftedCaseIds: ["case-1"], rationale: "lifts" },
        },
      ],
    };
    const out = parseSuiteRecommendResponse(JSON.stringify(body));
    expect(out).not.toBeNull();
    expect(out).toHaveLength(1);
  });

  it("strips a markdown code fence even though the prompt forbids it", () => {
    const body = { recommendations: [] };
    const fenced = `\`\`\`json\n${JSON.stringify(body)}\n\`\`\``;
    expect(parseSuiteRecommendResponse(fenced)).toEqual([]);
  });

  it("returns null for unrecognizable text", () => {
    expect(parseSuiteRecommendResponse("not json at all")).toBeNull();
  });
});

// ===========================================================================
// Tests — handler (full Lambda invocation with mocked clients)
// ===========================================================================

describe("Suite Recommend Lambda handler", () => {
  // -------------------------------------------------------------------------
  // Persisted-read shortcut and force override
  // -------------------------------------------------------------------------

  describe("persisted-read shortcut", () => {
    it("returns the persisted record unchanged and does not invoke Bedrock when force !== true (R8.8, R9.3)", async () => {
      const persistedRecs: PerSuiteRecommendation[] = [
        makeCandidate({
          targetName: "alpha",
          priority: 1,
          predictedImpact: { liftedCaseIds: ["case-1"], rationale: "" },
        }),
        makeCandidate({
          targetName: "beta",
          priority: 2,
          predictedImpact: { liftedCaseIds: [], rationale: "" },
        }),
      ];
      const persistedItem: PersistedSuiteItem = {
        PK: PK_RUN,
        SK: "ANALYSIS#SUITE",
        recommendations: persistedRecs,
        generatedAt: "2024-06-01T00:00:00.000Z",
        modelId: "us.anthropic.claude-sonnet-4-6",
      };

      const ddb = makeDDBMock({
        getResults: new Map([["ANALYSIS#SUITE", { Item: persistedItem }]]),
      });
      _setDDBDocClient(ddb.client as never);

      const bedrockSend = vi.fn();
      _setBedrockClient({ send: bedrockSend } as never);

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body) as SuiteRecommendResponse;
      // Verify the persisted ordering is preserved byte-for-byte.
      expect(body.recommendations).toEqual(persistedRecs);
      expect(body.generatedAt).toBe("2024-06-01T00:00:00.000Z");

      // Bedrock MUST NOT be invoked.
      expect(bedrockSend).not.toHaveBeenCalled();

      // Only the persisted-read GetCommand should fire — no PutCommand.
      expect(ddb.suiteGetCalls).toBe(1);
      expect(ddb.suitePutCalls).toBe(0);
    });

    it("bypasses the shortcut when force is true, re-invokes Bedrock, overwrites the persisted record, refreshes generatedAt (R8.7)", async () => {
      const stalePersisted: PersistedSuiteItem = {
        PK: PK_RUN,
        SK: "ANALYSIS#SUITE",
        recommendations: [
          makeCandidate({
            targetName: "stale",
            priority: 1,
            predictedImpact: { liftedCaseIds: ["case-1"], rationale: "" },
          }),
        ],
        generatedAt: "2020-01-01T00:00:00.000Z",
        modelId: "stale-model",
      };

      const snapshot = makeSnapshot();
      const ddb = makeDDBMock({
        // Persisted record present, but should be ignored when force=true.
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: stalePersisted }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                {
                  PK: PK_RUN,
                  SK: "CASE#case-1",
                  ...makeFailedCase("case-1"),
                },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      const freshRecs = {
        recommendations: [
          {
            targetField: "system_prompt",
            targetName: "system_prompt",
            currentText: "old prompt",
            suggestedText: "new and better prompt",
            rationale: "Clarifies disambiguation.",
            priority: 1,
            predictedImpact: {
              liftedCaseIds: ["case-1"],
              rationale: "Lifts case-1.",
            },
          },
        ],
      };
      const bedrockSend = vi.fn().mockResolvedValue(bedrockResponseWith(freshRecs));
      _setBedrockClient({ send: bedrockSend } as never);

      const beforeMs = Date.now();
      const response = await handler(makeEvent({ force: true }));
      expect(response.statusCode).toBe(200);

      // Bedrock IS invoked exactly once.
      expect(bedrockSend).toHaveBeenCalledTimes(1);
      expect(bedrockSend.mock.calls[0][0]).toBeInstanceOf(ConverseCommand);

      const body = JSON.parse(response.body) as SuiteRecommendResponse;
      expect(body.recommendations).toHaveLength(1);
      expect(body.recommendations[0].suggestedText).toBe("new and better prompt");

      // generatedAt is fresh — strictly newer than the persisted timestamp,
      // and within a small window of "now" so we know it was generated by
      // the handler call rather than copied from the persisted record.
      const refreshedAt = new Date(body.generatedAt).getTime();
      expect(refreshedAt).toBeGreaterThanOrEqual(beforeMs);
      expect(refreshedAt).toBeGreaterThan(
        new Date(stalePersisted.generatedAt).getTime(),
      );

      // The persisted record was overwritten — exactly one PutCommand for
      // ANALYSIS#SUITE was issued.
      expect(ddb.suitePutCalls).toBe(1);
      const written = ddb.puts.find((p) => p.SK === "ANALYSIS#SUITE");
      expect(written).toBeDefined();
      expect((written as { recommendations: PerSuiteRecommendation[] }).recommendations).toHaveLength(1);
    });
  });

  // -------------------------------------------------------------------------
  // Converse wire-shape assertion (Wave 1 migration — Task 15.5)
  // -------------------------------------------------------------------------

  describe("converse wire shape", () => {
    it("issues Converse with the inferenceConfig and modelId from the resolved suite_recommendation prompt", async () => {
      // Compute the wire shape directly from the same registry helpers
      // the migrated handler calls. The test asserts that every key the
      // capability profile accepts (and only those keys) reaches the
      // SDK, and the legacy `temperature: 0` literal from the
      // pre-migration handler does not leak through.
      const prompt = resolvePrompt("suite_recommendation", new Map());
      const expected = buildInferenceConfig(prompt);

      const snapshot = makeSnapshot();
      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      const okBody = {
        recommendations: [
          {
            targetField: "tool_description",
            targetName: "lookupAccount",
            currentText: "old",
            suggestedText: "new",
            rationale: "...",
            priority: 1,
            predictedImpact: { liftedCaseIds: ["case-1"], rationale: "" },
          },
        ],
      };
      const bedrockSend = vi
        .fn()
        .mockResolvedValue(bedrockResponseWith(okBody));
      _setBedrockClient({ send: bedrockSend } as never);

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(200);

      expect(bedrockSend).toHaveBeenCalledTimes(1);
      const cmd = bedrockSend.mock.calls[0][0] as ConverseCommand;
      expect(cmd).toBeInstanceOf(ConverseCommand);
      expect(cmd.input.modelId).toBe(prompt.modelId);
      expect(cmd.input.inferenceConfig).toEqual(expected.inferenceConfig);
      // `anthropic_claude_4x` profile — no additional model request fields.
      expect(cmd.input.additionalModelRequestFields).toBeUndefined();
      // System prompt text comes from the registry — not a literal in the
      // handler.
      expect(cmd.input.system).toEqual([{ text: prompt.text }]);
    });
  });

  // -------------------------------------------------------------------------
  // Server-side ordering: comparator + dense-rank
  // -------------------------------------------------------------------------

  describe("server-side ordering", () => {
    it("applies the comparator and renumbers priority to a 1-based dense rank monotonic with array index (R9.1, R9.2)", async () => {
      const snapshot = makeSnapshot();
      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
                { PK: PK_RUN, SK: "CASE#case-2", ...makeFailedCase("case-2") },
                { PK: PK_RUN, SK: "CASE#case-3", ...makeFailedCase("case-3") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      // Model emits in arbitrary order with mixed priority/lift counts.
      // The handler must apply the comparator then renumber the priority.
      const modelOutput = {
        recommendations: [
          {
            targetField: "tool_description",
            targetName: "transferFunds",
            currentText: "Transfer money between accounts.",
            suggestedText: "Transfer money between your own accounts only.",
            rationale: "...",
            priority: 99,
            predictedImpact: {
              liftedCaseIds: ["case-1"],
              rationale: "",
            },
          },
          {
            targetField: "system_prompt",
            targetName: "system_prompt",
            currentText: "old",
            suggestedText: "new",
            rationale: "...",
            priority: 5,
            predictedImpact: {
              liftedCaseIds: ["case-1", "case-2", "case-3"],
              rationale: "",
            },
          },
          {
            targetField: "tool_instruction",
            targetName: "lookupAccount",
            currentText: "old",
            suggestedText: "new",
            rationale: "...",
            priority: 5,
            predictedImpact: {
              liftedCaseIds: ["case-2"],
              rationale: "",
            },
          },
        ],
      };
      const bedrockSend = vi.fn().mockResolvedValue(bedrockResponseWith(modelOutput));
      _setBedrockClient({ send: bedrockSend } as never);

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as SuiteRecommendResponse;

      expect(body.recommendations).toHaveLength(3);

      // Monotonic-priority property — the contract from R9.1.
      for (let i = 0; i + 1 < body.recommendations.length; i++) {
        expect(body.recommendations[i].priority).toBeLessThanOrEqual(
          body.recommendations[i + 1].priority,
        );
      }

      // Comparator-driven order:
      //   - The two priority=5 entries collapse into rank 1 (dense),
      //     ordered between themselves by liftedCaseIds.length DESC:
      //       1st = system_prompt (3 lifts)
      //       2nd = tool_instruction (1 lift)
      //   - The priority=99 entry follows at rank 2.
      expect(body.recommendations[0].targetField).toBe("system_prompt");
      expect(body.recommendations[1].targetField).toBe("tool_instruction");
      expect(body.recommendations[2].targetField).toBe("tool_description");

      // Dense-rank: priorities are 1, 1, 2.
      expect(body.recommendations.map((r) => r.priority)).toEqual([1, 1, 2]);
    });
  });

  // -------------------------------------------------------------------------
  // Filter + dedupe in the handler path
  // -------------------------------------------------------------------------

  describe("filter and dedupe", () => {
    it("drops invalid targetField, empty targetName, no-op recommendations, and out-of-set liftedCaseIds; deduplicates remaining liftedCaseIds (R5.9, R8.6, R13.3)", async () => {
      const snapshot = makeSnapshot();
      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
                { PK: PK_RUN, SK: "CASE#case-2", ...makeFailedCase("case-2") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      const modelOutput = {
        recommendations: [
          // Drop: invalid targetField (R5.9).
          {
            targetField: "not_a_real_surface",
            targetName: "lookupAccount",
            currentText: "a",
            suggestedText: "b",
            rationale: "",
            priority: 1,
            predictedImpact: { liftedCaseIds: ["case-1"], rationale: "" },
          },
          // Drop: empty targetName (R13.3).
          {
            targetField: "tool_description",
            targetName: "",
            currentText: "a",
            suggestedText: "b",
            rationale: "",
            priority: 2,
            predictedImpact: { liftedCaseIds: ["case-1"], rationale: "" },
          },
          // Drop: no-op (both texts empty) (R13.3).
          {
            targetField: "system_prompt",
            targetName: "system_prompt",
            currentText: "",
            suggestedText: "",
            rationale: "",
            priority: 3,
            predictedImpact: { liftedCaseIds: ["case-1"], rationale: "" },
          },
          // Keep: out-of-set IDs are filtered, duplicates collapsed.
          {
            targetField: "tool_instruction",
            targetName: "lookupAccount",
            currentText: "old",
            suggestedText: "new",
            rationale: "...",
            priority: 4,
            predictedImpact: {
              liftedCaseIds: [
                "case-1",
                "case-1",
                "case-not-in-set",
                "case-2",
                "case-2",
              ],
              rationale: "",
            },
          },
        ],
      };
      const bedrockSend = vi.fn().mockResolvedValue(bedrockResponseWith(modelOutput));
      _setBedrockClient({ send: bedrockSend } as never);

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as SuiteRecommendResponse;

      // Three of four candidates dropped; one survives.
      expect(body.recommendations).toHaveLength(1);
      const surviving = body.recommendations[0];
      expect(surviving.targetField).toBe("tool_instruction");
      expect(surviving.targetName).toBe("lookupAccount");
      // liftedCaseIds: `case-not-in-set` removed; duplicates collapsed.
      expect(surviving.predictedImpact.liftedCaseIds).toEqual([
        "case-1",
        "case-2",
      ]);
    });
  });

  // -------------------------------------------------------------------------
  // Snapshot validation
  // -------------------------------------------------------------------------

  describe("snapshot validation", () => {
    it("returns HTTP 404 with snapshot_missing when the snapshot is absent (R12.3)", async () => {
      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          ["SNAPSHOT", { Item: undefined }],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      const bedrockSend = vi.fn();
      _setBedrockClient({ send: bedrockSend } as never);

      const response = await handler(makeEvent());

      expect(response.statusCode).toBe(404);
      const body = JSON.parse(response.body);
      expect(body.error).toBe("snapshot_missing");
      // Bedrock MUST NOT be invoked when the snapshot is missing.
      expect(bedrockSend).not.toHaveBeenCalled();
    });

    it("returns HTTP 500 with snapshot_examples_malformed when a tool's examples is not an array (R5.8)", async () => {
      // Construct a snapshot with a non-array `examples` field on one
      // tool — surfaces the read-time validation error.
      const malformed = makeSnapshot();
      (malformed.tools[1] as unknown as { examples: unknown }).examples = 42;

      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...malformed } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      const bedrockSend = vi.fn();
      _setBedrockClient({ send: bedrockSend } as never);

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(500);
      const body = JSON.parse(response.body);
      expect(body.error).toBe("snapshot_examples_malformed");
      expect(body.toolName).toBe("transferFunds");
      // Bedrock MUST NOT be invoked when the snapshot is malformed.
      expect(bedrockSend).not.toHaveBeenCalled();
    });
  });

  // -------------------------------------------------------------------------
  // Empty model output
  // -------------------------------------------------------------------------

  describe("empty model output", () => {
    it("persists [] and returns HTTP 200 with an empty recommendations array (R8.1)", async () => {
      const snapshot = makeSnapshot();
      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      const bedrockSend = vi
        .fn()
        .mockResolvedValue(bedrockResponseWith({ recommendations: [] }));
      _setBedrockClient({ send: bedrockSend } as never);

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as SuiteRecommendResponse;
      expect(body.recommendations).toEqual([]);

      // The empty array IS persisted so the next read short-circuits.
      expect(ddb.suitePutCalls).toBe(1);
      const written = ddb.puts.find((p) => p.SK === "ANALYSIS#SUITE");
      expect(written).toBeDefined();
      expect((written as { recommendations: unknown[] }).recommendations).toEqual([]);
    });
  });

  // -------------------------------------------------------------------------
  // Persistence failure
  // -------------------------------------------------------------------------

  describe("persistence failure", () => {
    it("returns HTTP 200 with the in-memory sorted recommendations even when the DDB write fails (R6.6 semantics)", async () => {
      const snapshot = makeSnapshot();
      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
        putBehaviour: () =>
          Promise.reject(new Error("DDB write failed: ProvisionedThroughputExceededException")),
      });
      _setDDBDocClient(ddb.client as never);

      const modelOutput = {
        recommendations: [
          {
            targetField: "tool_description",
            targetName: "lookupAccount",
            currentText: "old",
            suggestedText: "new",
            rationale: "...",
            priority: 1,
            predictedImpact: {
              liftedCaseIds: ["case-1"],
              rationale: "",
            },
          },
        ],
      };
      const bedrockSend = vi
        .fn()
        .mockResolvedValue(bedrockResponseWith(modelOutput));
      _setBedrockClient({ send: bedrockSend } as never);

      // Suppress the warning the handler logs on persistence failure.
      const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as SuiteRecommendResponse;

      // The in-memory result still carries the sorted recommendation.
      expect(body.recommendations).toHaveLength(1);
      expect(body.recommendations[0].targetName).toBe("lookupAccount");

      // The handler did try to persist — and the failure was logged.
      expect(ddb.suitePutCalls).toBe(1);
      expect(warnSpy).toHaveBeenCalled();
    });
  });

  // -------------------------------------------------------------------------
  // Throttle posture
  // -------------------------------------------------------------------------

  describe("throttle posture", () => {
    it("retries on ThrottlingException and ultimately succeeds (R12.1)", async () => {
      const snapshot = makeSnapshot();
      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      // Speed up the test: stub the backoff sleep so the retry loop
      // runs without real delay. The handler uses `setTimeout` for the
      // jittered backoff, which fake timers + immediate-resolve emulates.
      const setTimeoutSpy = vi
        .spyOn(globalThis, "setTimeout")
        .mockImplementation(
          ((cb: (...args: unknown[]) => unknown) => {
            cb();
            return 0 as unknown as ReturnType<typeof setTimeout>;
          }) as unknown as typeof setTimeout,
        );

      const okBody = {
        recommendations: [
          {
            targetField: "tool_description",
            targetName: "lookupAccount",
            currentText: "old",
            suggestedText: "new",
            rationale: "...",
            priority: 1,
            predictedImpact: {
              liftedCaseIds: ["case-1"],
              rationale: "",
            },
          },
        ],
      };
      const bedrockSend = vi
        .fn()
        // Two throttles, then success on the third attempt.
        .mockRejectedValueOnce(throttleError())
        .mockRejectedValueOnce(throttleError())
        .mockResolvedValueOnce(bedrockResponseWith(okBody));
      _setBedrockClient({ send: bedrockSend } as never);

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body) as SuiteRecommendResponse;
      expect(body.recommendations).toHaveLength(1);

      // Bedrock was retried twice after the initial failure — three
      // calls total (matches `THROTTLE_MAX_RETRIES = 2`).
      expect(bedrockSend).toHaveBeenCalledTimes(3);

      setTimeoutSpy.mockRestore();
    });

    it("returns HTTP 503 with retryable: true when the throttle is terminal (R12.2)", async () => {
      const snapshot = makeSnapshot();
      const ddb = makeDDBMock({
        getResults: new Map<string, unknown>([
          ["ANALYSIS#SUITE", { Item: undefined }],
          [
            "SNAPSHOT",
            { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } },
          ],
        ]),
        queryResults: new Map([
          [
            "CASE#",
            {
              Items: [
                { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
              ],
            },
          ],
          ["ANALYSIS#CASE#", { Items: [] }],
        ]),
      });
      _setDDBDocClient(ddb.client as never);

      // Stub setTimeout to drain the retry loop without real delay.
      const setTimeoutSpy = vi
        .spyOn(globalThis, "setTimeout")
        .mockImplementation(
          ((cb: (...args: unknown[]) => unknown) => {
            cb();
            return 0 as unknown as ReturnType<typeof setTimeout>;
          }) as unknown as typeof setTimeout,
        );

      // Always throttle.
      const bedrockSend = vi.fn().mockRejectedValue(throttleError());
      _setBedrockClient({ send: bedrockSend } as never);

      const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

      const response = await handler(makeEvent());
      expect(response.statusCode).toBe(503);
      const body = JSON.parse(response.body);
      expect(body.error).toBe("ThrottlingException");
      expect(body.retryable).toBe(true);

      // `THROTTLE_MAX_RETRIES = 2` → three attempts in total before
      // surfacing the terminal throttle.
      expect(bedrockSend).toHaveBeenCalledTimes(3);

      // Persistence MUST NOT happen when Bedrock failed terminally.
      expect(ddb.suitePutCalls).toBe(0);

      setTimeoutSpy.mockRestore();
      errorSpy.mockRestore();
    });
  });
});

// ===========================================================================
// Tests — formatCaseReasoningTrace and buildUserMessage reasoning (Task 8.1)
// ===========================================================================

import {
  buildUserMessage,
  formatCaseReasoningTrace,
  type PersistedCaseAnalysis,
} from "../../src/backend/handlers/suite-recommend";
import type { ExecutionTrace } from "../../src/shared/types";

describe("formatCaseReasoningTrace", () => {
  it("returns undefined when trace is undefined", () => {
    expect(formatCaseReasoningTrace(undefined)).toBeUndefined();
  });

  it("returns undefined when trace has no steps", () => {
    const trace: ExecutionTrace = {
      sessionId: "s1",
      steps: [],
      toolSequence: [],
      capturedAt: "2025-01-15T10:30:00.000Z",
    };
    expect(formatCaseReasoningTrace(trace)).toBeUndefined();
  });

  it("returns undefined when no step carries non-empty reasoning", () => {
    const trace: ExecutionTrace = {
      sessionId: "s1",
      steps: [
        { index: 0, type: "inference", spanName: "inference", text: "Hello" },
        { index: 1, type: "tool", spanName: "execute_tool" },
      ],
      toolSequence: ["lookupAccount"],
      capturedAt: "2025-01-15T10:30:00.000Z",
    };
    expect(formatCaseReasoningTrace(trace)).toBeUndefined();
  });

  it("returns undefined when reasoning is empty string", () => {
    const trace: ExecutionTrace = {
      sessionId: "s1",
      steps: [
        { index: 0, type: "inference", spanName: "inference", reasoning: "" },
      ],
      toolSequence: [],
      capturedAt: "2025-01-15T10:30:00.000Z",
    };
    expect(formatCaseReasoningTrace(trace)).toBeUndefined();
  });

  it("formats a single reasoning step with index and timestamp", () => {
    const trace: ExecutionTrace = {
      sessionId: "s1",
      steps: [
        {
          index: 2,
          type: "inference",
          spanName: "inference",
          timestamp: "2025-01-15T10:30:01.000Z",
          reasoning: "The customer is asking for their mortgage rate...",
        },
      ],
      toolSequence: [],
      capturedAt: "2025-01-15T10:30:00.000Z",
    };
    const result = formatCaseReasoningTrace(trace);
    expect(result).toBe(
      "[step 2 · 2025-01-15T10:30:01.000Z]\nThe customer is asking for their mortgage rate..."
    );
  });

  it("formats multiple reasoning steps chronologically separated by blank line", () => {
    const trace: ExecutionTrace = {
      sessionId: "s1",
      steps: [
        {
          index: 5,
          type: "inference",
          spanName: "inference",
          timestamp: "2025-01-15T10:30:04.000Z",
          reasoning: "I need to verify their identity before...",
        },
        {
          index: 2,
          type: "inference",
          spanName: "inference",
          timestamp: "2025-01-15T10:30:01.000Z",
          reasoning: "The customer is asking for their mortgage rate...",
        },
        { index: 3, type: "tool", spanName: "execute_tool" },
      ],
      toolSequence: ["lookupAccount"],
      capturedAt: "2025-01-15T10:30:00.000Z",
    };
    const result = formatCaseReasoningTrace(trace);
    expect(result).toBe(
      "[step 2 · 2025-01-15T10:30:01.000Z]\n" +
      "The customer is asking for their mortgage rate...\n" +
      "\n" +
      "[step 5 · 2025-01-15T10:30:04.000Z]\n" +
      "I need to verify their identity before..."
    );
  });

  it("preserves reasoning verbatim including whitespace and special chars", () => {
    const trace: ExecutionTrace = {
      sessionId: "s1",
      steps: [
        {
          index: 0,
          type: "inference",
          spanName: "inference",
          timestamp: "2025-01-15T10:30:00.000Z",
          reasoning: "  line1\n\ttabbed\n  trailing  ",
        },
      ],
      toolSequence: [],
      capturedAt: "2025-01-15T10:30:00.000Z",
    };
    const result = formatCaseReasoningTrace(trace);
    expect(result).toBe(
      "[step 0 · 2025-01-15T10:30:00.000Z]\n  line1\n\ttabbed\n  trailing  "
    );
  });

  it("uses empty string for timestamp when undefined", () => {
    const trace: ExecutionTrace = {
      sessionId: "s1",
      steps: [
        {
          index: 1,
          type: "inference",
          spanName: "inference",
          reasoning: "thinking...",
        },
      ],
      toolSequence: [],
      capturedAt: "2025-01-15T10:30:00.000Z",
    };
    const result = formatCaseReasoningTrace(trace);
    expect(result).toBe("[step 1 · ]\nthinking...");
  });
});

describe("buildUserMessage reasoning trace integration", () => {
  it("produces byte-identical output when no case carries reasoning (R10.2)", () => {
    const failedResults: TestCaseResult[] = [makeFailedCase("case-1")];
    const perCaseAnalyses = new Map<string, PersistedCaseAnalysis>();
    const snapshot = makeSnapshot();

    // Call without reasoning → this is the baseline
    const output = buildUserMessage({
      failedCaseIds: ["case-1"],
      snapshot,
      failedResults,
      perCaseAnalyses,
    });

    // Output must not contain a reasoning trace section
    expect(output).not.toContain("#### Reasoning trace");
    expect(output).not.toContain("[step");

    // Call again — must be byte-identical (deterministic)
    const output2 = buildUserMessage({
      failedCaseIds: ["case-1"],
      snapshot,
      failedResults,
      perCaseAnalyses,
    });
    expect(output2).toBe(output);
  });

  it("includes per-case reasoning trace when case has steps with reasoning (R10.1)", () => {
    const failedResults: TestCaseResult[] = [
      {
        ...makeFailedCase("case-1"),
        executionTrace: {
          sessionId: "s1",
          steps: [
            {
              index: 0,
              type: "inference",
              spanName: "inference",
              timestamp: "2025-01-15T10:30:00.000Z",
              reasoning: "Customer wants a transfer",
              text: "I'll help you with that transfer.",
            },
            {
              index: 1,
              type: "tool",
              spanName: "execute_tool",
            },
          ],
          toolSequence: ["transferFunds"],
          capturedAt: "2025-01-15T10:30:00.000Z",
        },
      },
    ];
    const perCaseAnalyses = new Map<string, PersistedCaseAnalysis>();
    const snapshot = makeSnapshot();

    const output = buildUserMessage({
      failedCaseIds: ["case-1"],
      snapshot,
      failedResults,
      perCaseAnalyses,
    });

    expect(output).toContain("#### Reasoning trace");
    expect(output).toContain("[step 0 · 2025-01-15T10:30:00.000Z]");
    expect(output).toContain("Customer wants a transfer");
  });

  it("includes reasoning only for cases that have it, not for cases without", () => {
    const failedResults: TestCaseResult[] = [
      {
        ...makeFailedCase("case-1"),
        executionTrace: {
          sessionId: "s1",
          steps: [
            {
              index: 0,
              type: "inference",
              spanName: "inference",
              timestamp: "2025-01-15T10:30:00.000Z",
              reasoning: "Reasoning for case 1",
            },
          ],
          toolSequence: [],
          capturedAt: "2025-01-15T10:30:00.000Z",
        },
      },
      makeFailedCase("case-2"), // no executionTrace
    ];
    const perCaseAnalyses = new Map<string, PersistedCaseAnalysis>();
    const snapshot = makeSnapshot();

    const output = buildUserMessage({
      failedCaseIds: ["case-1", "case-2"],
      snapshot,
      failedResults,
      perCaseAnalyses,
    });

    // case-1 has reasoning
    const case1Section = output.split("### Case case-2")[0];
    expect(case1Section).toContain("#### Reasoning trace");
    expect(case1Section).toContain("Reasoning for case 1");

    // case-2 does NOT have reasoning
    const case2Section = output.split("### Case case-2")[1];
    expect(case2Section).not.toContain("#### Reasoning trace");
  });
});

// ---------------------------------------------------------------------------
// R10.4 — Suite persistence of testCaseField on test_case recommendations
// ---------------------------------------------------------------------------

describe("Suite Recommend Lambda handler — testCaseField persistence (R10.4)", () => {
  it("persists testCaseField on test_case suite recommendations in the ANALYSIS#SUITE record", async () => {
    const snapshot = makeSnapshot();
    const ddb = makeDDBMock({
      getResults: new Map<string, unknown>([
        ["ANALYSIS#SUITE", { Item: undefined }],
        ["SNAPSHOT", { Item: { PK: PK_RUN, SK: "SNAPSHOT", ...snapshot } }],
      ]),
      queryResults: new Map([
        [
          "CASE#",
          {
            Items: [
              { PK: PK_RUN, SK: "CASE#case-1", ...makeFailedCase("case-1") },
            ],
          },
        ],
        [
          "ANALYSIS#CASE#",
          {
            Items: [
              {
                PK: PK_RUN,
                SK: "ANALYSIS#CASE#case-1",
                caseId: "case-1",
                rootCauseCategory: "test_case_defect",
                explanation: "The agent was correct.",
                traceAvailable: true,
                recommendations: [
                  {
                    targetField: "test_case",
                    targetName: "case-1",
                    currentText: "1. TransferFunds (required: true)",
                    suggestedText:
                      "1. ConfirmTransfer (required: true)\n2. TransferFunds (required: true)",
                    rationale: "Missing confirmation step.",
                    testCaseField: "successCriteria",
                  },
                ],
                generatedAt: "2024-06-01T00:00:00Z",
                modelId: "us.anthropic.claude-sonnet-4-6",
                testCaseDefect: true,
              },
            ],
          },
        ],
      ]),
    });
    _setDDBDocClient(ddb.client as never);

    // Bedrock returns a test_case recommendation with testCaseField
    const bedrockResponse = {
      recommendations: [
        {
          targetField: "test_case",
          targetName: "case-1",
          currentText: "1. TransferFunds (required: true)",
          suggestedText:
            "1. ConfirmTransfer (required: true)\n2. TransferFunds (required: true)",
          rationale: "Missing confirmation step in success criteria.",
          priority: 1,
          testCaseField: "successCriteria",
          predictedImpact: {
            liftedCaseIds: ["case-1"],
            rationale: "Adding confirmation step fixes the test.",
          },
        },
      ],
    };
    const bedrockSend = vi
      .fn()
      .mockResolvedValue(bedrockResponseWith(bedrockResponse));
    _setBedrockClient({ send: bedrockSend } as never);

    const response = await handler(makeEvent());
    expect(response.statusCode).toBe(200);

    const body = JSON.parse(response.body) as SuiteRecommendResponse;
    expect(body.recommendations).toHaveLength(1);
    expect(body.recommendations[0].targetField).toBe("test_case");
    expect(body.recommendations[0].testCaseField).toBe("successCriteria");

    // Verify the persisted DDB item carries testCaseField
    expect(ddb.suitePutCalls).toBe(1);
    const written = ddb.puts.find((p) => p.SK === "ANALYSIS#SUITE") as
      | Record<string, unknown>
      | undefined;
    expect(written).toBeDefined();
    const persistedRecs = (written as { recommendations: PerSuiteRecommendation[] })
      .recommendations;
    expect(persistedRecs).toHaveLength(1);
    expect(persistedRecs[0].targetField).toBe("test_case");
    expect(persistedRecs[0].testCaseField).toBe("successCriteria");
    expect(persistedRecs[0].targetName).toBe("case-1");
    expect(persistedRecs[0].currentText).toBe(
      "1. TransferFunds (required: true)",
    );
    expect(persistedRecs[0].suggestedText).toBe(
      "1. ConfirmTransfer (required: true)\n2. TransferFunds (required: true)",
    );
  });
});

// Tag: keep the unused enum import quiet for the linter — RunStatus is
// imported here for type symmetry with companion tests under
// `tests/unit/`, even though no assertion in this file references it.
void RunStatus;
