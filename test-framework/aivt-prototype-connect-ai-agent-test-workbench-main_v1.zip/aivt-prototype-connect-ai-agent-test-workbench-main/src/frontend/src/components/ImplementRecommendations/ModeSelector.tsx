/**
 * ModeSelector — modal dialog presenting the two implementation modes:
 *   1. "Apply directly" — triggers the Direct Apply flow (confirmation dialog)
 *   2. "Advanced: Multi-variant experiment" — triggers variant generation
 *
 * Requirement 1.3: WHEN the user activates the "Implement Recommendations"
 * button, THE Platform SHALL present a choice dialog with two options.
 *
 * @module components/ImplementRecommendations/ModeSelector
 */

import { useState } from 'react';
import Modal from '@cloudscape-design/components/modal';
import Box from '@cloudscape-design/components/box';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Button from '@cloudscape-design/components/button';
import RadioGroup, {
  type RadioGroupProps,
} from '@cloudscape-design/components/radio-group';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface ModeSelectorProps {
  visible: boolean;
  onDismiss: () => void;
  /** Called when the user confirms "Apply directly". */
  onDirectApply: () => void;
  /** Called when the user confirms "Advanced: Multi-variant experiment". */
  onExperiment: () => void;
}

// ---------------------------------------------------------------------------
// Mode options
// ---------------------------------------------------------------------------

type ImplementMode = 'direct' | 'experiment';

const MODE_OPTIONS: RadioGroupProps.RadioButtonDefinition[] = [
  {
    value: 'direct',
    label: 'Apply directly',
    description:
      'Write the recommended changes to your agent configuration immediately. You will review a diff before confirming.',
  },
  {
    value: 'experiment',
    label: 'Advanced: Multi-variant experiment',
    description:
      'Generate 3 diverse prompt variants from the recommendations, test them in parallel, and compare results before applying.',
  },
];

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function ModeSelector({
  visible,
  onDismiss,
  onDirectApply,
  onExperiment,
}: ModeSelectorProps): JSX.Element {
  const [selectedMode, setSelectedMode] = useState<ImplementMode>('direct');

  const handleConfirm = () => {
    if (selectedMode === 'direct') {
      onDirectApply();
    } else {
      onExperiment();
    }
  };

  return (
    <Modal
      visible={visible}
      onDismiss={onDismiss}
      header="Implement Recommendations"
      closeAriaLabel="Close"
      footer={
        <Box float="right">
          <SpaceBetween direction="horizontal" size="xs">
            <Button variant="link" onClick={onDismiss}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleConfirm}>
              Continue
            </Button>
          </SpaceBetween>
        </Box>
      }
    >
      <SpaceBetween size="m">
        <Box variant="p">
          Choose how you would like to implement the recommendations for this
          run.
        </Box>
        <RadioGroup
          onChange={({ detail }) =>
            setSelectedMode(detail.value as ImplementMode)
          }
          value={selectedMode}
          items={MODE_OPTIONS}
        />
      </SpaceBetween>
    </Modal>
  );
}
