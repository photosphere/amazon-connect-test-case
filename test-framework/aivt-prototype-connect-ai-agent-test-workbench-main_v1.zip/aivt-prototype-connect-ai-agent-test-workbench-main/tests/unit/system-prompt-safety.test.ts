import { describe, it, expect } from "vitest";
import {
  validateSystemPromptSafety,
  SystemPromptSafetyResult,
} from "../../src/backend/orchestration/system-prompt-safety";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function expectValid(result: SystemPromptSafetyResult): void {
  expect(result.valid).toBe(true);
  expect(result.violations).toHaveLength(0);
}

function expectInvalid(
  result: SystemPromptSafetyResult,
  violationSubstring?: string
): void {
  expect(result.valid).toBe(false);
  expect(result.violations.length).toBeGreaterThan(0);
  if (violationSubstring) {
    expect(
      result.violations.some((v) => v.includes(violationSubstring))
    ).toBe(true);
  }
}

// ---------------------------------------------------------------------------
// Rule 1: Dynamic parameters must remain at end of prompt
// ---------------------------------------------------------------------------

describe("system-prompt-safety: Rule 1 — Dynamic parameters at end", () => {
  it("passes when dynamic parameters remain at end unchanged", () => {
    const original =
      "You are a helpful agent.\n\n{{$.Custom.Name}}\n{{agent.locale}}";
    const modified =
      "You are an improved agent.\n\n{{$.Custom.Name}}\n{{agent.locale}}";
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("passes when prompt has no dynamic parameters", () => {
    const original = "You are a helpful agent.";
    const modified = "You are an improved agent.";
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("fails when a dynamic parameter is removed", () => {
    const original =
      "You are a helpful agent.\n\n{{$.Custom.Name}}\n{{agent.locale}}";
    const modified = "You are an improved agent.\n\n{{$.Custom.Name}}";
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "was removed"
    );
  });

  it("fails when dynamic parameter is moved to middle of prompt", () => {
    const original =
      "You are a helpful agent.\n\n{{$.Custom.Name}}";
    const modified =
      "You are {{$.Custom.Name}} a helpful agent.";
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "not in the trailing section"
    );
  });

  it("passes with multiple params all at end with whitespace between", () => {
    const original =
      "Instructions here.\n\n{{$.Custom.Foo}}\n{{agent.bar}}\n{{session.baz}}";
    const modified =
      "Better instructions here.\n\n{{$.Custom.Foo}}\n{{agent.bar}}\n{{session.baz}}";
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("fails when parameters are surrounded by non-whitespace content at end", () => {
    const original =
      "You are a helpful agent.\n\n{{$.Custom.Name}}";
    const modified =
      "You are a helpful agent.\nExtra content {{$.Custom.Name}} more content";
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "Dynamic parameters"
    );
  });
});

// ---------------------------------------------------------------------------
// Rule 2: Thinking/messaging blocks must be byte-for-byte unchanged
// ---------------------------------------------------------------------------

describe("system-prompt-safety: Rule 2 — Thinking/messaging blocks immutable", () => {
  it("passes when thinking block is preserved unchanged", () => {
    const thinkingBlock =
      "<thinking>\nReason step by step before responding.\n</thinking>";
    const original = `Instructions.\n\n${thinkingBlock}\n\nMore instructions.`;
    const modified = `Better instructions.\n\n${thinkingBlock}\n\nMore instructions.`;
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("passes when messaging block is preserved unchanged", () => {
    const messagingBlock =
      "<messaging>\nAlways be polite and professional.\n</messaging>";
    const original = `Instructions.\n\n${messagingBlock}`;
    const modified = `Better instructions.\n\n${messagingBlock}`;
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("fails when thinking block content is modified", () => {
    const originalBlock =
      "<thinking>\nReason step by step before responding.\n</thinking>";
    const modifiedBlock =
      "<thinking>\nThink carefully before responding.\n</thinking>";
    const original = `Instructions.\n\n${originalBlock}`;
    const modified = `Instructions.\n\n${modifiedBlock}`;
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "was modified"
    );
  });

  it("fails when thinking block is removed entirely", () => {
    const thinkingBlock =
      "<thinking>\nReason step by step.\n</thinking>";
    const original = `Instructions.\n\n${thinkingBlock}\n\nMore text.`;
    const modified = "Instructions.\n\nMore text.";
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "was removed"
    );
  });

  it("fails when messaging block is modified", () => {
    const originalBlock =
      "<messaging>\nBe helpful.\n</messaging>";
    const modifiedBlock =
      "<messaging>\nBe very helpful.\n</messaging>";
    const original = `Start.\n${originalBlock}\nEnd.`;
    const modified = `Start.\n${modifiedBlock}\nEnd.`;
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "was modified"
    );
  });

  it("passes with both thinking and messaging blocks preserved", () => {
    const thinking = "<thinking>\nStep by step.\n</thinking>";
    const messaging = "<messaging>\nBe polite.\n</messaging>";
    const original = `Intro.\n${thinking}\nMiddle.\n${messaging}\nEnd.`;
    const modified = `New intro.\n${thinking}\nNew middle.\n${messaging}\nNew end.`;
    expectValid(validateSystemPromptSafety(original, modified));
  });
});

// ---------------------------------------------------------------------------
// Rule 3: No new examples introduced into system prompt body
// ---------------------------------------------------------------------------

describe("system-prompt-safety: Rule 3 — No new examples in prompt body", () => {
  it("passes when no examples exist in either version", () => {
    const original = "You are a helpful agent.";
    const modified = "You are an improved helpful agent.";
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("passes when existing examples are preserved", () => {
    const original =
      "Instructions.\nCustomer: Hello\nAgent: Hi there!\n\n<thinking>\nReason.\n</thinking>";
    const modified =
      "Better instructions.\nCustomer: Hello\nAgent: Hi there!\n\n<thinking>\nReason.\n</thinking>";
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("fails when new Customer:/Agent: dialogue is added (with markers)", () => {
    const thinking = "<thinking>\nReason.\n</thinking>";
    const original = `Instructions.\n\n${thinking}`;
    const modified = `Instructions.\nCustomer: Hi\nAgent: Hello!\n\n${thinking}`;
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "New example content"
    );
  });

  it("fails when new Q:/A: pattern is added (with markers)", () => {
    const thinking = "<thinking>\nReason.\n</thinking>";
    const original = `Instructions.\n\n${thinking}`;
    const modified = `Instructions.\nQ: What is X?\nA: X is Y.\n\n${thinking}`;
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "New example content"
    );
  });

  it("passes when existing examples are tweaked (not new)", () => {
    const thinking = "<thinking>\nReason.\n</thinking>";
    const original = `Instructions.\nCustomer: Hello\nAgent: Hi there!\n\n${thinking}`;
    const modified = `Instructions.\nCustomer: Hey\nAgent: Hello!\n\n${thinking}`;
    // Both have example patterns — existing examples can be tweaked
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("fails when new examples added in no-marker fallback mode", () => {
    const original = "You are a helpful agent.\n\n{{$.Custom.Name}}";
    const modified =
      "You are a helpful agent.\nCustomer: Hi\nAgent: Hello!\n\n{{$.Custom.Name}}";
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "New example content"
    );
  });
});

// ---------------------------------------------------------------------------
// Fallback: No markers detected
// ---------------------------------------------------------------------------

describe("system-prompt-safety: Fallback — no structural markers", () => {
  it("treats entire prompt as editable when no markers exist", () => {
    const original = "You are a helpful agent.";
    const modified = "You are a completely different agent with new capabilities.";
    expectValid(validateSystemPromptSafety(original, modified));
  });

  it("still enforces dynamic params at end in fallback mode", () => {
    const original = "Instructions.\n\n{{$.Custom.Name}}";
    const modified = "{{$.Custom.Name}}\nInstructions rewritten.";
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "not in the trailing section"
    );
  });

  it("still enforces no new examples in fallback mode", () => {
    const original = "Simple instructions.\n\n{{agent.locale}}";
    const modified =
      "Simple instructions.\nExample 1: do this\n\n{{agent.locale}}";
    expectInvalid(
      validateSystemPromptSafety(original, modified),
      "New example content"
    );
  });

  it("does not enforce block immutability when no blocks exist", () => {
    // Since there are no blocks, removing text that looks like a block
    // opener/closer is fine
    const original = "Instructions mentioning <thinking> concept.";
    const modified = "Instructions about reasoning concept.";
    // This is not a violation because <thinking> without </thinking> is
    // not detected as a structural block
    expectValid(validateSystemPromptSafety(original, modified));
  });
});

// ---------------------------------------------------------------------------
// Combined scenarios
// ---------------------------------------------------------------------------

describe("system-prompt-safety: Combined validation", () => {
  it("reports multiple violations when multiple rules broken", () => {
    const original =
      "Instructions.\n\n<thinking>\nReason step by step.\n</thinking>\n\n{{$.Custom.Name}}";
    const modified =
      "{{$.Custom.Name}}\nInstructions.\nCustomer: Hi\nAgent: Hello!\n\n<thinking>\nModified thinking.\n</thinking>";
    const result = validateSystemPromptSafety(original, modified);
    expect(result.valid).toBe(false);
    // Should have violations for: param not at end, block modified, new examples
    expect(result.violations.length).toBeGreaterThanOrEqual(2);
  });

  it("passes a realistic well-formed prompt modification", () => {
    const thinking = "<thinking>\nYou must reason through each customer request step by step.\nIdentify the intent, then select the appropriate tool.\n</thinking>";
    const messaging = "<messaging>\nAlways acknowledge the customer's concern before providing a solution.\nUse the customer's name when available.\n</messaging>";
    const params = "{{$.Custom.CustomerName}}\n{{agent.locale}}\n{{session.contactId}}";

    const original = `You are a customer service agent for AnyBank.\n\n${thinking}\n\n${messaging}\n\nWhen greeting customers, be warm and professional.\n\n${params}`;
    const modified = `You are an expert customer service agent for AnyBank.\nYour role is to resolve issues efficiently.\n\n${thinking}\n\n${messaging}\n\nWhen greeting customers, be warm, professional, and empathetic.\n\n${params}`;

    expectValid(validateSystemPromptSafety(original, modified));
  });
});
