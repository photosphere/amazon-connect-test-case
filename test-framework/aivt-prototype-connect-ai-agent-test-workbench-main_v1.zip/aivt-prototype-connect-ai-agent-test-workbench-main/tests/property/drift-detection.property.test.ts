// Feature: implement-recommendations, Property 1: Drift detection correctness
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import { checkDrift } from "@backend/orchestration/drift-detection";
import type {
  AgentDetail,
  Recommendation,
  ToolDefinition,
} from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Non-empty tool name (1–30 chars, printable ASCII). */
const toolNameArb: fc.Arbitrary<string> = fc.string({
  minLength: 1,
  maxLength: 30,
  unit: fc.char().filter((c) => c >= " " && c <= "~"),
});

/** Arbitrary non-empty text for field values (1–200 chars). */
const nonEmptyTextArb: fc.Arbitrary<string> = fc.string({
  minLength: 1,
  maxLength: 200,
});

/** Arbitrary text that can be empty (0–200 chars). */
const textArb: fc.Arbitrary<string> = fc.string({
  minLength: 0,
  maxLength: 200,
});

/**
 * Generates a ToolDefinition with the given name and field values.
 */
function makeToolDef(
  toolName: string,
  description: string,
  instruction: string,
  examples: string[],
): ToolDefinition {
  return {
    toolName,
    toolType: "CODE_INTERPRETER",
    description,
    instruction,
    inputSchema: {},
    examples,
  };
}

/**
 * Generates an AgentDetail containing the specified tools and system prompt.
 */
function makeAgentDetail(
  systemPrompt: string,
  tools: ToolDefinition[],
): AgentDetail {
  return {
    agentId: "agent-test-id",
    name: "TestAgent",
    type: "ORCHESTRATION",
    systemPrompt,
    modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
    tools,
  };
}

/**
 * Produces a string that differs from the input by at least one character.
 * Strategy: appends a character that's different from the last char, or
 * prepends if input is empty.
 */
const mutateTextArb = (original: string): fc.Arbitrary<string> => {
  // Generate a non-equal string by choosing among several mutation strategies
  return fc
    .oneof(
      // Strategy 1: Append a character
      fc.char().map((c) => original + c),
      // Strategy 2: Prepend a character
      fc.char().map((c) => c + original),
      // Strategy 3: Replace with completely different string (guaranteed non-empty)
      fc.string({ minLength: 1, maxLength: 200 }),
    )
    .filter((s) => s !== original);
};

// ---------------------------------------------------------------------------
// Property 1: Drift detection correctness
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 3.6, 11.1, 11.2, 18.1**
 *
 * Property 1: Drift detection correctness
 *
 * For any Recommendation and any live agent configuration, if the
 * recommendation's `currentText` matches the corresponding live agent field
 * character-for-character, then the drift detection function SHALL return
 * `no_drift` for that field. Conversely, if they differ by even one character,
 * it SHALL return `drift` for that field. This holds regardless of whitespace
 * variations in other fields, the number of recommendations in the batch, or
 * the Tool_Surface type.
 */
describe("Feature: implement-recommendations, Property 1: Drift detection correctness", () => {
  describe("no-drift: matching currentText → field is clean", () => {
    it("tool_description: when currentText matches live description, no drift reported", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          textArb,
          textArb,
          fc.array(textArb, { minLength: 0, maxLength: 5 }),
          textArb,
          (toolName, description, instruction, suggestedText, examples, systemPrompt) => {
            const rec: Recommendation = {
              targetField: "tool_description",
              targetName: toolName,
              currentText: description,
              suggestedText: suggestedText || "new text",
              rationale: "test",
            };

            const agent = makeAgentDetail(systemPrompt, [
              makeToolDef(toolName, description, instruction, examples),
            ]);

            const result = checkDrift({
              recommendations: [rec],
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(false);
            expect(result.driftedFields).toHaveLength(0);
            expect(result.cleanFields).toHaveLength(1);
            expect(result.cleanFields[0]).toBe(rec);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("tool_instruction: when currentText matches live instruction, no drift reported", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          textArb,
          textArb,
          textArb,
          fc.array(textArb, { minLength: 0, maxLength: 5 }),
          textArb,
          (toolName, description, instruction, suggestedText, examples, systemPrompt) => {
            const rec: Recommendation = {
              targetField: "tool_instruction",
              targetName: toolName,
              currentText: instruction,
              suggestedText: suggestedText || "new instruction",
              rationale: "test",
            };

            const agent = makeAgentDetail(systemPrompt, [
              makeToolDef(toolName, description, instruction, examples),
            ]);

            const result = checkDrift({
              recommendations: [rec],
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(false);
            expect(result.driftedFields).toHaveLength(0);
            expect(result.cleanFields).toHaveLength(1);
            expect(result.cleanFields[0]).toBe(rec);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("tool_examples: when currentText matches a live example, no drift reported", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          textArb,
          textArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 4 }),
          textArb,
          (toolName, description, instruction, exampleText, otherExamples, systemPrompt) => {
            const rec: Recommendation = {
              targetField: "tool_examples",
              targetName: toolName,
              currentText: exampleText,
              suggestedText: "replacement example",
              rationale: "test",
            };

            const allExamples = [exampleText, ...otherExamples];
            const agent = makeAgentDetail(systemPrompt, [
              makeToolDef(toolName, description, instruction, allExamples),
            ]);

            const result = checkDrift({
              recommendations: [rec],
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(false);
            expect(result.driftedFields).toHaveLength(0);
            expect(result.cleanFields).toHaveLength(1);
            expect(result.cleanFields[0]).toBe(rec);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("tool_examples add operation: empty currentText always reports no drift", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          textArb,
          textArb,
          fc.array(textArb, { minLength: 0, maxLength: 5 }),
          nonEmptyTextArb,
          textArb,
          (toolName, description, instruction, examples, newExample, systemPrompt) => {
            const rec: Recommendation = {
              targetField: "tool_examples",
              targetName: toolName,
              currentText: "", // add operation
              suggestedText: newExample,
              rationale: "test",
            };

            const agent = makeAgentDetail(systemPrompt, [
              makeToolDef(toolName, description, instruction, examples),
            ]);

            const result = checkDrift({
              recommendations: [rec],
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(false);
            expect(result.driftedFields).toHaveLength(0);
            expect(result.cleanFields).toHaveLength(1);
            expect(result.cleanFields[0]).toBe(rec);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("system_prompt: when currentText matches live systemPrompt, no drift reported", () => {
      fc.assert(
        fc.property(
          nonEmptyTextArb,
          textArb,
          toolNameArb,
          textArb,
          textArb,
          fc.array(textArb, { minLength: 0, maxLength: 3 }),
          (systemPrompt, suggestedText, toolName, desc, inst, examples) => {
            const rec: Recommendation = {
              targetField: "system_prompt",
              targetName: "system_prompt",
              currentText: systemPrompt,
              suggestedText: suggestedText || "new prompt",
              rationale: "test",
            };

            const agent = makeAgentDetail(systemPrompt, [
              makeToolDef(toolName, desc, inst, examples),
            ]);

            const result = checkDrift({
              recommendations: [rec],
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(false);
            expect(result.driftedFields).toHaveLength(0);
            expect(result.cleanFields).toHaveLength(1);
            expect(result.cleanFields[0]).toBe(rec);
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("drift: differing currentText → field reports drift", () => {
    it("tool_description: when currentText differs from live description, drift reported", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          textArb,
          fc.array(textArb, { minLength: 0, maxLength: 5 }),
          textArb,
          (toolName, liveDescription, instruction, examples, systemPrompt) => {
            // Generate a currentText that differs from the live description
            return fc.assert(
              fc.property(
                mutateTextArb(liveDescription),
                (differentCurrentText) => {
                  const rec: Recommendation = {
                    targetField: "tool_description",
                    targetName: toolName,
                    currentText: differentCurrentText,
                    suggestedText: "suggested",
                    rationale: "test",
                  };

                  const agent = makeAgentDetail(systemPrompt, [
                    makeToolDef(toolName, liveDescription, instruction, examples),
                  ]);

                  const result = checkDrift({
                    recommendations: [rec],
                    liveAgentConfig: agent,
                  });

                  expect(result.hasDrift).toBe(true);
                  expect(result.driftedFields).toHaveLength(1);
                  expect(result.driftedFields[0].targetField).toBe("tool_description");
                  expect(result.driftedFields[0].targetName).toBe(toolName);
                  expect(result.driftedFields[0].expectedText).toBe(differentCurrentText);
                  expect(result.driftedFields[0].actualText).toBe(liveDescription);
                  expect(result.cleanFields).toHaveLength(0);
                },
              ),
              { numRuns: 1 },
            );
          },
        ),
        { numRuns: 100 },
      );
    });

    it("tool_instruction: when currentText differs from live instruction, drift reported", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          textArb,
          textArb,
          fc.array(textArb, { minLength: 0, maxLength: 5 }),
          textArb,
          (toolName, description, liveInstruction, examples, systemPrompt) => {
            return fc.assert(
              fc.property(
                mutateTextArb(liveInstruction),
                (differentCurrentText) => {
                  const rec: Recommendation = {
                    targetField: "tool_instruction",
                    targetName: toolName,
                    currentText: differentCurrentText,
                    suggestedText: "suggested",
                    rationale: "test",
                  };

                  const agent = makeAgentDetail(systemPrompt, [
                    makeToolDef(toolName, description, liveInstruction, examples),
                  ]);

                  const result = checkDrift({
                    recommendations: [rec],
                    liveAgentConfig: agent,
                  });

                  expect(result.hasDrift).toBe(true);
                  expect(result.driftedFields).toHaveLength(1);
                  expect(result.driftedFields[0].targetField).toBe("tool_instruction");
                  expect(result.driftedFields[0].targetName).toBe(toolName);
                  expect(result.driftedFields[0].expectedText).toBe(differentCurrentText);
                  expect(result.driftedFields[0].actualText).toBe(liveInstruction);
                  expect(result.cleanFields).toHaveLength(0);
                },
              ),
              { numRuns: 1 },
            );
          },
        ),
        { numRuns: 100 },
      );
    });

    it("system_prompt: when currentText differs from live systemPrompt, drift reported", () => {
      fc.assert(
        fc.property(
          nonEmptyTextArb,
          toolNameArb,
          textArb,
          textArb,
          fc.array(textArb, { minLength: 0, maxLength: 3 }),
          (liveSystemPrompt, toolName, desc, inst, examples) => {
            return fc.assert(
              fc.property(
                mutateTextArb(liveSystemPrompt),
                (differentCurrentText) => {
                  const rec: Recommendation = {
                    targetField: "system_prompt",
                    targetName: "system_prompt",
                    currentText: differentCurrentText,
                    suggestedText: "new prompt",
                    rationale: "test",
                  };

                  const agent = makeAgentDetail(liveSystemPrompt, [
                    makeToolDef(toolName, desc, inst, examples),
                  ]);

                  const result = checkDrift({
                    recommendations: [rec],
                    liveAgentConfig: agent,
                  });

                  expect(result.hasDrift).toBe(true);
                  expect(result.driftedFields).toHaveLength(1);
                  expect(result.driftedFields[0].targetField).toBe("system_prompt");
                  expect(result.driftedFields[0].expectedText).toBe(differentCurrentText);
                  expect(result.driftedFields[0].actualText).toBe(liveSystemPrompt);
                  expect(result.cleanFields).toHaveLength(0);
                },
              ),
              { numRuns: 1 },
            );
          },
        ),
        { numRuns: 100 },
      );
    });

    it("tool_examples: when currentText not found in live examples, drift reported", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          textArb,
          textArb,
          fc.array(nonEmptyTextArb, { minLength: 1, maxLength: 5 }),
          textArb,
          (toolName, description, instruction, liveExamples, systemPrompt) => {
            // Generate a currentText that is NOT in liveExamples
            const notInExamples = liveExamples.join("") + "_different";

            const rec: Recommendation = {
              targetField: "tool_examples",
              targetName: toolName,
              currentText: notInExamples,
              suggestedText: "replacement",
              rationale: "test",
            };

            const agent = makeAgentDetail(systemPrompt, [
              makeToolDef(toolName, description, instruction, liveExamples),
            ]);

            const result = checkDrift({
              recommendations: [rec],
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(true);
            expect(result.driftedFields).toHaveLength(1);
            expect(result.driftedFields[0].targetField).toBe("tool_examples");
            expect(result.driftedFields[0].targetName).toBe(toolName);
            expect(result.driftedFields[0].expectedText).toBe(notInExamples);
            expect(result.cleanFields).toHaveLength(0);
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("batch behavior: multiple recommendations with mixed drift", () => {
    it("batch of recommendations correctly partitions into drifted and clean", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          (toolName, liveDescription, liveInstruction, liveSystemPrompt) => {
            // Create a batch: first rec matches (clean), second rec doesn't (drifted)
            const cleanRec: Recommendation = {
              targetField: "tool_description",
              targetName: toolName,
              currentText: liveDescription,
              suggestedText: "new desc",
              rationale: "test",
            };

            const driftedRec: Recommendation = {
              targetField: "system_prompt",
              targetName: "system_prompt",
              currentText: liveSystemPrompt + "_modified",
              suggestedText: "new prompt",
              rationale: "test",
            };

            const agent = makeAgentDetail(liveSystemPrompt, [
              makeToolDef(toolName, liveDescription, liveInstruction, []),
            ]);

            const result = checkDrift({
              recommendations: [cleanRec, driftedRec],
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(true);
            expect(result.cleanFields).toHaveLength(1);
            expect(result.cleanFields[0]).toBe(cleanRec);
            expect(result.driftedFields).toHaveLength(1);
            expect(result.driftedFields[0].targetField).toBe("system_prompt");
          },
        ),
        { numRuns: 100 },
      );
    });

    it("all-clean batch: hasDrift is false when every currentText matches", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          fc.array(nonEmptyTextArb, { minLength: 0, maxLength: 3 }),
          (toolName, liveDesc, liveInst, liveSysPrompt, liveExamples) => {
            const recs: Recommendation[] = [
              {
                targetField: "tool_description",
                targetName: toolName,
                currentText: liveDesc,
                suggestedText: "new",
                rationale: "",
              },
              {
                targetField: "tool_instruction",
                targetName: toolName,
                currentText: liveInst,
                suggestedText: "new",
                rationale: "",
              },
              {
                targetField: "system_prompt",
                targetName: "system_prompt",
                currentText: liveSysPrompt,
                suggestedText: "new",
                rationale: "",
              },
            ];

            const agent = makeAgentDetail(liveSysPrompt, [
              makeToolDef(toolName, liveDesc, liveInst, liveExamples),
            ]);

            const result = checkDrift({
              recommendations: recs,
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(false);
            expect(result.driftedFields).toHaveLength(0);
            expect(result.cleanFields).toHaveLength(3);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("whitespace in OTHER fields does not affect drift detection on the target field", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          textArb,
          textArb,
          (toolName, liveDescription, arbitraryInstruction, arbitrarySystemPrompt) => {
            // Recommendation targets tool_description which matches exactly
            // Other fields (instruction, systemPrompt) may have arbitrary whitespace
            const rec: Recommendation = {
              targetField: "tool_description",
              targetName: toolName,
              currentText: liveDescription,
              suggestedText: "new",
              rationale: "",
            };

            const agent = makeAgentDetail(arbitrarySystemPrompt, [
              makeToolDef(toolName, liveDescription, arbitraryInstruction, []),
            ]);

            const result = checkDrift({
              recommendations: [rec],
              liveAgentConfig: agent,
            });

            // Regardless of whitespace content in other fields, this field has no drift
            expect(result.hasDrift).toBe(false);
            expect(result.cleanFields).toHaveLength(1);
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("edge cases: missing tools and batch size independence", () => {
    it("tool not found in live config → drift reported", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          toolNameArb,
          textArb,
          textArb,
          textArb,
          (missingToolName, currentText, otherToolName, desc, inst, systemPrompt) => {
            // Ensure the tool names differ
            fc.pre(missingToolName !== otherToolName);

            const rec: Recommendation = {
              targetField: "tool_description",
              targetName: missingToolName,
              currentText: currentText,
              suggestedText: "new",
              rationale: "",
            };

            // Agent has a different tool, not the one referenced by the recommendation
            const agent = makeAgentDetail(systemPrompt, [
              makeToolDef(otherToolName, desc, inst, []),
            ]);

            const result = checkDrift({
              recommendations: [rec],
              liveAgentConfig: agent,
            });

            expect(result.hasDrift).toBe(true);
            expect(result.driftedFields).toHaveLength(1);
            expect(result.driftedFields[0].targetName).toBe(missingToolName);
            expect(result.driftedFields[0].actualText).toBe("");
          },
        ),
        { numRuns: 100 },
      );
    });

    it("drift result is independent of batch ordering", () => {
      fc.assert(
        fc.property(
          toolNameArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          nonEmptyTextArb,
          (toolName, liveDesc, liveInst, liveSysPrompt) => {
            const cleanRec: Recommendation = {
              targetField: "tool_description",
              targetName: toolName,
              currentText: liveDesc,
              suggestedText: "new",
              rationale: "",
            };

            const driftedRec: Recommendation = {
              targetField: "tool_instruction",
              targetName: toolName,
              currentText: liveInst + "_changed",
              suggestedText: "new",
              rationale: "",
            };

            const agent = makeAgentDetail(liveSysPrompt, [
              makeToolDef(toolName, liveDesc, liveInst, []),
            ]);

            // Order 1: clean first, drifted second
            const result1 = checkDrift({
              recommendations: [cleanRec, driftedRec],
              liveAgentConfig: agent,
            });

            // Order 2: drifted first, clean second
            const result2 = checkDrift({
              recommendations: [driftedRec, cleanRec],
              liveAgentConfig: agent,
            });

            // Both should report the same drift result regardless of ordering
            expect(result1.hasDrift).toBe(true);
            expect(result2.hasDrift).toBe(true);
            expect(result1.driftedFields).toHaveLength(1);
            expect(result2.driftedFields).toHaveLength(1);
            expect(result1.cleanFields).toHaveLength(1);
            expect(result2.cleanFields).toHaveLength(1);
          },
        ),
        { numRuns: 100 },
      );
    });
  });
});
