// Feature: connect-agent-test-platform, Property 5: Tool selection accuracy
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import {
  calculateToolAccuracy,
} from "@shared/utils/tool-accuracy";
import { ToolStep } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Arbitrary for a tool name — short alphanumeric identifiers. */
const toolNameArb = fc.stringOf(fc.constantFrom(...'abcdefghijklmnopqrstuvwxyz'.split('')), {
  minLength: 1,
  maxLength: 10,
});

/** Arbitrary for a single ToolStep (required or optional). */
const toolStepArb: fc.Arbitrary<ToolStep> = fc.record({
  toolName: toolNameArb,
  required: fc.boolean(),
});

/** Arbitrary for a non-empty expected tool sequence (1–15 steps). */
const expectedSequenceArb = fc.array(toolStepArb, { minLength: 1, maxLength: 15 });

/** Arbitrary for an actual invocation list (0–30 tool names). */
const actualListArb = fc.array(toolNameArb, { minLength: 0, maxLength: 30 });

// ---------------------------------------------------------------------------
// Helper: Reference implementation for ordered subsequence matching
// ---------------------------------------------------------------------------

/**
 * Reference implementation to count how many required steps from `expected`
 * appear as an ordered subsequence in `actual`.
 */
function countOrderedSubsequenceMatches(
  expected: ToolStep[],
  actual: string[],
  filterRequired: boolean,
): number {
  const steps = filterRequired
    ? expected.filter((s) => s.required)
    : expected.filter((s) => !s.required);
  let actualIdx = 0;
  let matched = 0;

  for (const step of steps) {
    for (let i = actualIdx; i < actual.length; i++) {
      if (actual[i] === step.toolName) {
        matched++;
        actualIdx = i + 1;
        break;
      }
    }
  }

  return matched;
}

// ---------------------------------------------------------------------------
// Property 5: Tool Selection Accuracy — Ordered Subsequence Matching
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 9.2, 9.6**
 *
 * Property 5: Tool selection accuracy — ordered subsequence matching
 * For any expected tool sequence (where each step is marked required or
 * optional) and any actual tool invocation list, the tool accuracy score
 * SHALL be computed as: count of matched required steps appearing in correct
 * relative order as a subsequence of the actual list, divided by total
 * required steps. Optional steps do not affect the score negatively if absent,
 * but are counted positively if present in any position.
 */
describe("Feature: connect-agent-test-platform, Property 5: Tool selection accuracy", () => {
  // -------------------------------------------------------------------------
  // 1. Score is always between 0.0 and 1.0 inclusive
  // -------------------------------------------------------------------------
  it("score is always between 0.0 and 1.0 inclusive", () => {
    fc.assert(
      fc.property(expectedSequenceArb, actualListArb, (expected, actual) => {
        const result = calculateToolAccuracy(expected, actual);
        expect(result.score).toBeGreaterThanOrEqual(0.0);
        expect(result.score).toBeLessThanOrEqual(1.0);
      }),
      { numRuns: 100 },
    );
  });

  // -------------------------------------------------------------------------
  // 2. Score is 1.0 iff all required tools appear as ordered subsequence
  // -------------------------------------------------------------------------
  it("score is 1.0 if and only if all required tools appear as an ordered subsequence in actual", () => {
    fc.assert(
      fc.property(expectedSequenceArb, actualListArb, (expected, actual) => {
        const result = calculateToolAccuracy(expected, actual);
        const totalRequired = expected.filter((s) => s.required).length;

        if (totalRequired === 0) {
          // No required steps → score is vacuously 1.0
          expect(result.score).toBe(1.0);
          return;
        }

        // Check if all required steps form an ordered subsequence of actual
        const matchedRequired = countOrderedSubsequenceMatches(expected, actual, true);
        const allRequiredPresent = matchedRequired === totalRequired;

        if (allRequiredPresent) {
          expect(result.score).toBe(1.0);
        } else {
          expect(result.score).toBeLessThan(1.0);
        }
      }),
      { numRuns: 100 },
    );
  });

  // -------------------------------------------------------------------------
  // 3. Score equals matchedRequired / totalRequired (when totalRequired > 0)
  // -------------------------------------------------------------------------
  it("score equals matchedRequired / totalRequired when totalRequired > 0", () => {
    // Use only-required steps to avoid interaction with optional step matching order
    const requiredOnlySequenceArb = fc.array(
      fc.record({ toolName: toolNameArb, required: fc.constant(true) }),
      { minLength: 1, maxLength: 15 },
    );

    fc.assert(
      fc.property(requiredOnlySequenceArb, actualListArb, (expected, actual) => {
        const result = calculateToolAccuracy(expected, actual);
        const totalRequired = expected.length;
        const matchedRequired = countOrderedSubsequenceMatches(expected, actual, true);
        const expectedScore = Math.round((matchedRequired / totalRequired) * 1000) / 1000;

        expect(result.score).toBe(expectedScore);
      }),
      { numRuns: 100 },
    );
  });

  // -------------------------------------------------------------------------
  // 4. Optional steps do NOT affect the denominator
  // -------------------------------------------------------------------------
  it("optional steps do NOT affect the denominator — adding optional steps does not lower the score", () => {
    const requiredOnlyArb = fc.array(
      fc.record({ toolName: toolNameArb, required: fc.constant(true) }),
      { minLength: 1, maxLength: 10 },
    );
    const optionalStepsArb = fc.array(
      fc.record({ toolName: toolNameArb, required: fc.constant(false) }),
      { minLength: 1, maxLength: 5 },
    );

    fc.assert(
      fc.property(requiredOnlyArb, optionalStepsArb, actualListArb, (required, optional, actual) => {
        const requiredOnly = calculateToolAccuracy(required, actual);

        // Interleave optional steps at the end (so they don't consume actual positions before required)
        const withOptional = calculateToolAccuracy([...required, ...optional], actual);

        // Score should be the same since optional steps after required don't steal matches
        // Actually they could be different if optional steps at end don't interfere
        // The key assertion: score is still matchedRequired/totalRequired and totalRequired is unchanged
        const totalRequired = required.length;
        expect(withOptional.score).toBe(requiredOnly.score);
        // Verify denominator hasn't changed
        expect(totalRequired).toBeGreaterThan(0);
        expect(Number.isFinite(withOptional.score)).toBe(true);
      }),
      { numRuns: 100 },
    );
  });

  // -------------------------------------------------------------------------
  // 5. Optional steps matched count is non-negative and <= optionalTotal
  // -------------------------------------------------------------------------
  it("optionalMatched is non-negative and <= optionalTotal", () => {
    fc.assert(
      fc.property(expectedSequenceArb, actualListArb, (expected, actual) => {
        const result = calculateToolAccuracy(expected, actual);
        expect(result.optionalMatched).toBeGreaterThanOrEqual(0);
        expect(result.optionalMatched).toBeLessThanOrEqual(result.optionalTotal);
        expect(result.optionalTotal).toBe(expected.filter((s) => !s.required).length);
      }),
      { numRuns: 100 },
    );
  });

  // -------------------------------------------------------------------------
  // 6. If expected is empty, score is 1.0
  // -------------------------------------------------------------------------
  it("if expected is empty, score is 1.0", () => {
    fc.assert(
      fc.property(actualListArb, (actual) => {
        const result = calculateToolAccuracy([], actual);
        expect(result.score).toBe(1.0);
        expect(result.optionalMatched).toBe(0);
        expect(result.optionalTotal).toBe(0);
      }),
      { numRuns: 100 },
    );
  });

  // -------------------------------------------------------------------------
  // 7. If actual contains all expected tools in exact order, score is 1.0
  // -------------------------------------------------------------------------
  it("if actual contains all expected tools in exact order, score is 1.0", () => {
    fc.assert(
      fc.property(expectedSequenceArb, (expected) => {
        // Build an actual list that is exactly the tool names from expected in order
        const actual = expected.map((s) => s.toolName);
        const result = calculateToolAccuracy(expected, actual);
        expect(result.score).toBe(1.0);
      }),
      { numRuns: 100 },
    );
  });

  // -------------------------------------------------------------------------
  // Bonus: Score is 1.0 when actual is a superset containing all expected in order
  // -------------------------------------------------------------------------
  it("score is 1.0 when actual is a superset with all expected tools in order (interleaved with noise)", () => {
    fc.assert(
      fc.property(
        expectedSequenceArb,
        fc.array(toolNameArb, { minLength: 0, maxLength: 10 }),
        (expected, noise) => {
          // Build actual by interleaving expected tool names with random noise
          const actual: string[] = [];
          let noiseIdx = 0;
          for (const step of expected) {
            // Add some noise before each expected tool
            const noiseCount = noiseIdx < noise.length ? 1 : 0;
            if (noiseCount > 0) {
              actual.push(noise[noiseIdx++]);
            }
            actual.push(step.toolName);
          }
          // Add remaining noise at the end
          while (noiseIdx < noise.length) {
            actual.push(noise[noiseIdx++]);
          }

          const result = calculateToolAccuracy(expected, actual);
          expect(result.score).toBe(1.0);
        },
      ),
      { numRuns: 100 },
    );
  });
});
