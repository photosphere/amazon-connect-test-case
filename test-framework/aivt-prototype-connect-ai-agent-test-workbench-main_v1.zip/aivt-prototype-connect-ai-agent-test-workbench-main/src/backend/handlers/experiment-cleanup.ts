/**
 * Experiment Cleanup Lambda — Step Functions handler for deleting temporary agents.
 *
 * Invoked by the Experiment State Machine after all variant executions complete.
 * Deletes all temporary agents created for the experiment via DeleteAIAgent.
 * Retries once with exponential backoff per agent. Updates the experiment record
 * in DynamoDB with the cleanup status.
 *
 * This handler is NOT behind API Gateway — it receives its input directly from
 * the Step Functions state machine as a plain event object (CleanupInput).
 *
 * Environment variables:
 * - TABLE_NAME: DynamoDB table name
 * - ASSISTANT_ID: The Q in Connect assistant identifier
 *
 * @module experiment-cleanup
 */

import {
  QConnectClient,
  DeleteAIAgentCommand,
} from "@aws-sdk/client-qconnect";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import type { CleanupResult } from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

function getTableName(): string {
  return process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
}

function getAssistantId(): string {
  return process.env.ASSISTANT_ID ?? "";
}

function getRegion(): string {
  return process.env.AWS_REGION ?? "us-east-1";
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Input provided by the Experiment State Machine. */
export interface CleanupInput {
  experimentId: string;
  runId: string;
  temporaryAgentIds: string[];
  assistantId: string;
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

let qconnectClient: QConnectClient | null = null;
let ddbDocClient: DynamoDBDocumentClient | null = null;

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: getRegion() });
  }
  return qconnectClient;
}

function getDDBDocClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

/** @internal — allows test injection */
export function _setDDBDocClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Sleep for the specified number of milliseconds.
 */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Attempt to delete a single temporary agent. Retries once with exponential
 * backoff (1 second delay before retry) on failure.
 *
 * @returns true if deletion succeeded, false if it failed after retry.
 */
async function deleteAgentWithRetry(
  agentId: string,
  assistantId: string,
): Promise<boolean> {
  const client = getQConnectClient();

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      await client.send(
        new DeleteAIAgentCommand({
          assistantId,
          aiAgentId: agentId,
        }),
      );
      return true;
    } catch (error: unknown) {
      // If agent is already gone, treat as success
      const errorName = (error as { name?: string })?.name ?? "";
      if (errorName === "ResourceNotFoundException") {
        return true;
      }

      if (attempt === 0) {
        // Retry once after exponential backoff (1 second)
        console.warn(
          `[experiment-cleanup] DeleteAIAgent(${agentId}) attempt ${attempt + 1} failed: ${
            error instanceof Error ? error.message : String(error)
          }. Retrying after backoff...`,
        );
        await sleep(1000);
      } else {
        // Second attempt also failed — give up on this agent
        console.error(
          `[experiment-cleanup] DeleteAIAgent(${agentId}) failed after retry: ${
            error instanceof Error ? error.message : String(error)
          }`,
        );
      }
    }
  }

  return false;
}

/**
 * Update the experiment record in DynamoDB with cleanup results.
 */
async function updateExperimentCleanupStatus(
  runId: string,
  experimentId: string,
  cleanupStatus: "success" | "partial_failure",
  failedIds: string[],
): Promise<void> {
  const client = getDDBDocClient();

  const updateExpression =
    cleanupStatus === "success"
      ? "SET cleanupStatus = :cs, #st = :status"
      : "SET cleanupStatus = :cs, failedCleanupAgentIds = :fids, #st = :status";

  const expressionAttributeValues: Record<string, unknown> =
    cleanupStatus === "success"
      ? { ":cs": "success", ":status": "cleaned_up" }
      : { ":cs": "partial_failure", ":fids": failedIds, ":status": "cleaned_up" };

  await client.send(
    new UpdateCommand({
      TableName: getTableName(),
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `${SK_PATTERNS.EXPERIMENT}${experimentId}`,
      },
      UpdateExpression: updateExpression,
      ExpressionAttributeNames: { "#st": "status" },
      ExpressionAttributeValues: expressionAttributeValues,
      ConditionExpression: "attribute_exists(PK)",
    }),
  );
}

// ---------------------------------------------------------------------------
// Main handler — Step Functions direct invocation
// ---------------------------------------------------------------------------

/**
 * Lambda handler for experiment cleanup. Invoked by the Experiment State Machine
 * after all variant executions complete. Deletes all temporary agents and updates
 * the experiment record with cleanup status.
 */
export async function handler(event: CleanupInput): Promise<CleanupResult> {
  const { experimentId, runId, temporaryAgentIds, assistantId } = event;

  console.log(
    `[experiment-cleanup] Starting cleanup for experiment ${experimentId}. ` +
      `Agents to delete: ${temporaryAgentIds.length}`,
  );

  // Use the assistantId from input, falling back to environment variable
  const resolvedAssistantId = assistantId || getAssistantId();

  if (!resolvedAssistantId) {
    console.error("[experiment-cleanup] No assistantId available");
    // Can't delete without assistantId — mark all as failed
    const result: CleanupResult = {
      deletedCount: 0,
      failedIds: [...temporaryAgentIds],
      cleanupStatus: "partial_failure",
    };
    await updateExperimentCleanupStatus(
      runId,
      experimentId,
      "partial_failure",
      temporaryAgentIds,
    );
    return result;
  }

  // Delete each temporary agent with retry
  const failedIds: string[] = [];
  let deletedCount = 0;

  for (const agentId of temporaryAgentIds) {
    const success = await deleteAgentWithRetry(agentId, resolvedAssistantId);
    if (success) {
      deletedCount++;
    } else {
      failedIds.push(agentId);
    }
  }

  // Determine cleanup status
  const cleanupStatus: "success" | "partial_failure" =
    failedIds.length === 0 ? "success" : "partial_failure";

  // Update experiment record in DynamoDB
  try {
    await updateExperimentCleanupStatus(
      runId,
      experimentId,
      cleanupStatus,
      failedIds,
    );
  } catch (error: unknown) {
    console.error(
      `[experiment-cleanup] Failed to update experiment record: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
    // Still return the cleanup result even if DDB update fails
  }

  const result: CleanupResult = {
    deletedCount,
    failedIds,
    cleanupStatus,
  };

  console.log(
    `[experiment-cleanup] Cleanup complete for experiment ${experimentId}. ` +
      `Deleted: ${deletedCount}, Failed: ${failedIds.length}`,
  );

  return result;
}
