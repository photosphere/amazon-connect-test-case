/**
 * Pure `Prompt_Resolver` — the only path Bedrock_Callsites and
 * `PrepareRun` use to read the effective `(text, modelKey, modelId,
 * inferenceParameters, capabilityProfile, version)` triple for a
 * `promptKey`. The function is intentionally I/O-free: it takes (a) the
 * registry definition (defaulted to the module's bundled registry) and
 * (b) an in-memory `overrides` snapshot keyed by `promptKey`, and returns
 * a fully-shaped {@link ResolvedPrompt}.
 *
 * The resolver enforces the three behaviour invariants documented in the
 * design's Prompt_Resolver section:
 *
 *   1. **Default-fallback.** A persisted override is intentionally a
 *      sparse update: missing `text`, `modelKey`, or `inferenceParameters`
 *      fields fall back to the registry's bundled defaults individually,
 *      not as a unit. This lets a user persist a model-only override
 *      without having to also re-save the bundled `defaultText`.
 *
 *   2. **Stale-placeholder fallback.** If the resolved text is missing
 *      one or more declared placeholders — typically because the override
 *      was saved before the platform added a new `{name}` token in code —
 *      the resolver falls back to the bundled `defaultText` for that
 *      single call, returns `version: 0` (signalling the default was
 *      used), and emits a structured warning log carrying `promptKey` and
 *      the missing placeholder names. The override record is left intact
 *      so the next deploy that updates the default propagates without
 *      requiring an explicit user action.
 *
 *   3. **Unknown promptKey.** Calling the resolver with a `promptKey`
 *      value that is not in the registry throws {@link
 *      UnknownPromptKeyError} rather than synthesising a default. The
 *      callsite must surface this as a structured error and abort the
 *      Bedrock call.
 *
 * The registry itself is built at module load from the thirteen
 * per-prompt definition files in `./prompts/` and exported as
 * {@link PROMPT_REGISTRY}. A typed `as const` cast pinned to {@link
 * PromptRegistry} is the build-time gate that ensures every member of the
 * closed `PromptKey` union has exactly one definition (R1.1).
 *
 * @module backend/orchestration/prompt-registry/resolver
 */

import { CAPABILITY_PROFILES } from "./capability-profiles";
import { caseScaffoldPrompt } from "./prompts/case-scaffold";
import { comparisonSummaryPrompt } from "./prompts/comparison-summary";
import { customerSimulatorPrompt } from "./prompts/customer-simulator";
import { failureAnalysisPrompt } from "./prompts/failure-analysis";
import { judgeGoalSuccessRatePrompt } from "./prompts/judge-goal-success-rate";
import { judgeHelpfulnessPrompt } from "./prompts/judge-helpfulness";
import { judgeOpportunisticFaithfulnessPrompt } from "./prompts/judge-opportunistic-faithfulness";
import { judgeToolSelectionPrompt } from "./prompts/judge-tool-selection";
import { ragEvaluationJobPrompt } from "./prompts/rag-evaluation-job";
import { suiteRecommendationPrompt } from "./prompts/suite-recommendation";
import { suiteScaffoldPrompt } from "./prompts/suite-scaffold";
import { tournamentSummaryPrompt } from "./prompts/tournament-summary";
import { variantGenerationPrompt } from "./prompts/variant-generation";
import { SUPPORTED_MODELS } from "./supported-models";
import {
  UnknownPromptKeyError,
  type Placeholder,
  type PromptDefinition,
  type PromptKey,
  type PromptOverride,
  type PromptRegistry,
  type ResolvedPrompt,
} from "./types";

// ---------------------------------------------------------------------------
// In-module Prompt_Registry
// ---------------------------------------------------------------------------

/**
 * The thirteen-entry in-module registry, keyed by every member of the
 * closed {@link PromptKey} union. The `Readonly<Record<PromptKey,
 * PromptDefinition>>` typing is the build-time gate from R1.1: removing
 * a key here, or letting one drift out of the closed union, fails
 * `tsc` rather than slipping into runtime.
 *
 * Exported so that the registry's invariant unit tests and the runtime
 * helpers in `runtime.ts` can read the shipped defaults without
 * round-tripping through the resolver. Production callers SHALL go
 * through {@link resolvePrompt} so the three invariants documented in
 * the module header are always enforced.
 */
export const PROMPT_REGISTRY: PromptRegistry = {
  suite_scaffold: suiteScaffoldPrompt,
  case_scaffold: caseScaffoldPrompt,
  failure_analysis: failureAnalysisPrompt,
  suite_recommendation: suiteRecommendationPrompt,
  comparison_summary: comparisonSummaryPrompt,
  tournament_summary: tournamentSummaryPrompt,
  variant_generation: variantGenerationPrompt,
  customer_simulator: customerSimulatorPrompt,
  judge_goal_success_rate: judgeGoalSuccessRatePrompt,
  judge_helpfulness: judgeHelpfulnessPrompt,
  judge_tool_selection: judgeToolSelectionPrompt,
  judge_opportunistic_faithfulness: judgeOpportunisticFaithfulnessPrompt,
  rag_evaluation_job: ragEvaluationJobPrompt,
} as const;

// ---------------------------------------------------------------------------
// Resolver
// ---------------------------------------------------------------------------

/**
 * Return the names of every declared placeholder whose `{name}` token
 * does NOT occur at least once in `text`. A non-empty result triggers
 * the stale-placeholder fallback invariant; an empty result means the
 * resolved text honours the prompt's declared placeholder schema.
 *
 * `placeholders` may be empty (several prompts ship with no
 * placeholders, e.g. `failure_analysis`); in that case the result is
 * always an empty array and the fallback never fires.
 *
 * Detection uses literal substring search rather than a regex so that
 * placeholder names containing regex meta-characters (none today, but
 * the field is a free-form string) cannot accidentally short-circuit
 * detection.
 */
function findMissingPlaceholders(
  text: string,
  placeholders: readonly Placeholder[],
): string[] {
  const missing: string[] = [];
  for (const placeholder of placeholders) {
    const token = `{${placeholder.name}}`;
    if (!text.includes(token)) {
      missing.push(placeholder.name);
    }
  }
  return missing;
}

/**
 * Resolve the effective `(text, modelKey, modelId, inferenceParameters,
 * capabilityProfile, version)` triple for `promptKey`, honouring the
 * three invariants documented in the module header.
 *
 * Pure function — no I/O. The override snapshot is supplied by the
 * caller (the Prompts Lambda fetches it from DynamoDB once per request;
 * the runtime helper in `runtime.ts` caches it per Lambda warm).
 *
 * @param promptKey   — the registered prompt to resolve.
 * @param overrides   — snapshot of persisted override rows keyed by
 *                      `promptKey`. Pass an empty `Map` to resolve every
 *                      prompt to its bundled defaults.
 * @param registry    — optional registry override, defaulted to the
 *                      module-level {@link PROMPT_REGISTRY}. Exists for
 *                      testability so unit tests can inject a registry
 *                      stub without re-importing the module.
 * @returns the resolved prompt ready to feed to `buildInferenceConfig`
 *          and the Bedrock Converse call.
 * @throws {UnknownPromptKeyError} when `promptKey` is not present in
 *          the registry.
 */
export function resolvePrompt(
  promptKey: PromptKey,
  overrides: ReadonlyMap<PromptKey, PromptOverride>,
  registry: PromptRegistry = PROMPT_REGISTRY,
): ResolvedPrompt {
  // Invariant 3: unknown promptKey throws rather than synthesising a
  // default. We index via `Object.prototype.hasOwnProperty.call` so a
  // property named `__proto__` or `constructor` cannot masquerade as a
  // registered prompt.
  if (!Object.prototype.hasOwnProperty.call(registry, promptKey)) {
    throw new UnknownPromptKeyError(promptKey);
  }
  const definition: PromptDefinition = registry[promptKey];

  const override = overrides.get(promptKey);

  // Invariant 1: default-fallback. Each field falls back individually so
  // a sparse override (e.g. modelKey-only) does not shadow the bundled
  // defaultText.
  let text = override?.text ?? definition.defaultText;
  const modelKey = override?.modelKey ?? definition.defaultModelKey;
  const inferenceParameters: Readonly<Record<string, unknown>> =
    override?.inferenceParameters ?? definition.defaultInferenceValues;
  let version = override !== undefined ? override.version : 0;

  // Invariant 2: stale-placeholder fallback. If the resolved text — which
  // may be the persisted override — is missing one or more of the
  // prompt's declared placeholders, fall back to the bundled defaultText
  // for this single call, mark the resolved version as 0, and emit a
  // structured warning so operators can see why the default surfaced.
  const missingPlaceholders = findMissingPlaceholders(
    text,
    definition.placeholders,
  );
  if (missingPlaceholders.length > 0) {
    console.warn(
      `[prompt-registry] Stale override for promptKey="${promptKey}" is missing declared placeholders [${missingPlaceholders
        .map((n) => `"${n}"`)
        .join(
          ", ",
        )}]; falling back to bundled defaultText for this call. The override record is left intact.`,
    );
    text = definition.defaultText;
    version = 0;
  }

  // The supported-models catalog has its build-time invariants validated
  // at module load (see `supported-models.ts`); a missing `modelKey` here
  // would indicate the override carries a stale value that bypassed the
  // validation pipeline. That cannot happen for the bundled default
  // because every prompt's defaultModelKey is checked against the catalog
  // by the registry's invariant unit test (Task 2.7).
  const supportedModel = SUPPORTED_MODELS[modelKey];
  const capabilityProfile =
    CAPABILITY_PROFILES[supportedModel.capabilityProfileKey];

  return {
    promptKey,
    text,
    modelKey,
    modelId: supportedModel.inferenceProfileId,
    inferenceParameters,
    version,
    capabilityProfile,
  };
}
