/**
 * Unit tests for the Experiment Get Lambda handler.
 *
 * Tests GET /runs/{runId}/experiments/{experimentId} route handling,
 * 404 for missing experiments, and error cases by mocking the DynamoDB
 * document client.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import type { ExperimentRecord } from "../../src/shared/types";

// Mock DynamoDB client
const mockSend = vi.fn();
const mockClient = { send: mockSend } as unknown as DynamoDBDocumentClient;

// Import after mock setup
import {
  handler,
  _setDDBClient,
  type APIGatewayEvent,
} from "../../src/backend/handlers/experiment-get";

describe("Experiment Get Lambda", () => {
  beforeEach(() => {
    _setDDBClient(mockClient);
    mockSend.mockReset();
  });

  afterEach(() => {
    _setDDBClient(null);
  });

  // -------------------------------------------------------------------------
  // Successful retrieval
  // -------------------------------------------------------------------------

  describe("GET /runs/{runId}/experiments/{experimentId}", () => {
    const baseEvent: APIGatewayEvent = {
      httpMethod: "GET",
      resource: "/runs/{runId}/experiments/{experimentId}",
      pathParameters: { runId: "run-123", experimentId: "exp-456" },
      queryStringParameters: null,
    };

    it("returns full experiment record when found", async () => {
      const experiment: ExperimentRecord = {
        experimentId: "exp-456",
        runId: "run-123",
        agentId: "agent-789",
        status: "completed",
        variantConfigs: [
          {
            variantLetter: "A",
            strategy: "conciseness",
            recommendations: [],
          },
          {
            variantLetter: "B",
            strategy: "example-heavy",
            recommendations: [],
          },
          {
            variantLetter: "C",
            strategy: "restructured",
            recommendations: [],
          },
        ],
        temporaryAgentIds: {
          A: "temp-agent-a",
          B: "temp-agent-b",
          C: "temp-agent-c",
        },
        variantRunIds: {
          A: "run-a",
          B: "run-b",
          C: "run-c",
        },
        baselineRunId: "run-123",
        sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:exp-456",
        tournamentSummary: {
          winningVariant: "B",
          summary: "Variant B achieved 92% pass rate vs 75% baseline...",
          perVariantHighlights: {
            A: { improved: ["case-1"], regressed: [] },
            B: { improved: ["case-1", "case-2"], regressed: [] },
            C: { improved: ["case-1"], regressed: ["case-3"] },
          },
        },
        cleanupStatus: "success",
        createdAt: "2025-01-15T10:00:00Z",
        completedAt: "2025-01-15T10:15:00Z",
      };

      mockSend.mockResolvedValueOnce({
        Item: {
          PK: "RUN#run-123",
          SK: "EXPERIMENT#exp-456",
          ...experiment,
        },
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.experimentId).toBe("exp-456");
      expect(body.runId).toBe("run-123");
      expect(body.agentId).toBe("agent-789");
      expect(body.status).toBe("completed");
      expect(body.variantConfigs).toHaveLength(3);
      expect(body.variantRunIds.A).toBe("run-a");
      expect(body.variantRunIds.B).toBe("run-b");
      expect(body.variantRunIds.C).toBe("run-c");
      expect(body.baselineRunId).toBe("run-123");
      expect(body.tournamentSummary.winningVariant).toBe("B");
      expect(body.cleanupStatus).toBe("success");
      expect(body.createdAt).toBe("2025-01-15T10:00:00Z");
      expect(body.completedAt).toBe("2025-01-15T10:15:00Z");
    });

    it("returns experiment in running state", async () => {
      const experiment: ExperimentRecord = {
        experimentId: "exp-456",
        runId: "run-123",
        agentId: "agent-789",
        status: "running",
        variantConfigs: [
          { variantLetter: "A", strategy: "conciseness", recommendations: [] },
          { variantLetter: "B", strategy: "example-heavy", recommendations: [] },
          { variantLetter: "C", strategy: "restructured", recommendations: [] },
        ],
        temporaryAgentIds: {
          A: "temp-agent-a",
          B: "temp-agent-b",
          C: "temp-agent-c",
        },
        variantRunIds: { A: "run-a", B: "run-b", C: "run-c" },
        baselineRunId: "run-123",
        sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:exp-456",
        cleanupStatus: "pending",
        createdAt: "2025-01-15T10:00:00Z",
      };

      mockSend.mockResolvedValueOnce({
        Item: { PK: "RUN#run-123", SK: "EXPERIMENT#exp-456", ...experiment },
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.status).toBe("running");
      expect(body.tournamentSummary).toBeUndefined();
      expect(body.completedAt).toBeUndefined();
      expect(body.cleanupStatus).toBe("pending");
    });

    it("strips DynamoDB key attributes from the response", async () => {
      mockSend.mockResolvedValueOnce({
        Item: {
          PK: "RUN#run-123",
          SK: "EXPERIMENT#exp-456",
          GSI1PK: "some-gsi-value",
          GSI1SK: "another-gsi-value",
          experimentId: "exp-456",
          runId: "run-123",
          agentId: "agent-789",
          status: "generating_variants",
          variantConfigs: [],
          temporaryAgentIds: { A: "", B: "", C: "" },
          variantRunIds: { A: "", B: "", C: "" },
          baselineRunId: "run-123",
          sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:exp-456",
          cleanupStatus: "pending",
          createdAt: "2025-01-15T10:00:00Z",
        },
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.PK).toBeUndefined();
      expect(body.SK).toBeUndefined();
      expect(body.GSI1PK).toBeUndefined();
      expect(body.GSI1SK).toBeUndefined();
      expect(body.experimentId).toBe("exp-456");
    });
  });

  // -------------------------------------------------------------------------
  // Not found
  // -------------------------------------------------------------------------

  describe("Experiment not found", () => {
    it("returns 404 with experiment_not_found when experiment does not exist", async () => {
      mockSend.mockResolvedValueOnce({ Item: undefined });

      const event: APIGatewayEvent = {
        httpMethod: "GET",
        resource: "/runs/{runId}/experiments/{experimentId}",
        pathParameters: { runId: "run-123", experimentId: "non-existent" },
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(404);
      expect(JSON.parse(response.body).error).toBe("experiment_not_found");
    });
  });

  // -------------------------------------------------------------------------
  // Validation errors
  // -------------------------------------------------------------------------

  describe("Parameter validation", () => {
    it("returns 400 when runId is missing", async () => {
      const event: APIGatewayEvent = {
        httpMethod: "GET",
        resource: "/runs/{runId}/experiments/{experimentId}",
        pathParameters: { experimentId: "exp-456" },
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(400);
      expect(JSON.parse(response.body).error).toContain("runId");
    });

    it("returns 400 when experimentId is missing", async () => {
      const event: APIGatewayEvent = {
        httpMethod: "GET",
        resource: "/runs/{runId}/experiments/{experimentId}",
        pathParameters: { runId: "run-123" },
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(400);
      expect(JSON.parse(response.body).error).toContain("experimentId");
    });
  });

  // -------------------------------------------------------------------------
  // Method / Error handling
  // -------------------------------------------------------------------------

  describe("Error handling", () => {
    it("returns 405 for non-GET methods", async () => {
      const event: APIGatewayEvent = {
        httpMethod: "POST",
        resource: "/runs/{runId}/experiments/{experimentId}",
        pathParameters: { runId: "run-123", experimentId: "exp-456" },
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(405);
    });

    it("returns 500 on unexpected DynamoDB errors", async () => {
      mockSend.mockRejectedValueOnce(new Error("DynamoDB connection timeout"));

      const event: APIGatewayEvent = {
        httpMethod: "GET",
        resource: "/runs/{runId}/experiments/{experimentId}",
        pathParameters: { runId: "run-123", experimentId: "exp-456" },
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(500);
      expect(JSON.parse(response.body).error).toBe("Internal server error");
    });

    it("includes CORS headers on all responses", async () => {
      mockSend.mockResolvedValueOnce({ Item: undefined });

      const event: APIGatewayEvent = {
        httpMethod: "GET",
        resource: "/runs/{runId}/experiments/{experimentId}",
        pathParameters: { runId: "run-123", experimentId: "exp-456" },
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.headers["Access-Control-Allow-Origin"]).toBe("*");
      expect(response.headers["Content-Type"]).toBe("application/json");
    });
  });
});
