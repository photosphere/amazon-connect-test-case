/**
 * Scaffold Lambda — POST /suites/{suiteId}/cases/scaffold
 *
 * Accepts a goal description and agent ID, uses Bedrock to analyze the agent's
 * tools against the goal, infers the tool chain with required/optional labels,
 * then analyzes tool input schemas to generate a deduplicated customer knowledge
 * template with customer-facing labels.
 *
 * Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6
 *
 * @module scaffold
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ConverseCommandInput,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";
import {
  QConnectClient,
  GetAIAgentCommand,
} from "@aws-sdk/client-qconnect";
import {
  deduplicateParameters,
  type ToolSchema,
} from "../../shared/utils/parameter-dedup";
import {
  buildInferenceConfig,
  type ResolvedPrompt,
} from "../orchestration/prompt-registry";
import { resolvePromptLive } from "../orchestration/prompt-registry/runtime";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";
const ASSISTANT_ID = process.env.ASSISTANT_ID ?? "";
// The model id, system prompt text, and `maxTokens` cap for this Lambda's
// two Converse calls come from the Prompt_Registry: the suite-level tool
// chain inference resolves `suite_scaffold` and the case-level parameter
// label mapping resolves `case_scaffold`, both via `resolvePromptLive`.
// The legacy `SCAFFOLD_MODEL_ID` env var is still set in
// `lib/api-construct.ts` as a Wave-1 safety net and is removed in Wave 3
// (per the prompt-management migration plan).
const OPERATION_TIMEOUT_MS = 30_000;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Request body for the scaffold endpoint. */
export interface ScaffoldRequest {
  goalDescription: string;
  agentId: string;
}

/** A suggested tool in the inferred sequence. */
export interface SuggestedTool {
  toolName: string;
  position: number;
  required: boolean;
}

/** A single entry in the customer knowledge template. */
export interface KnowledgeTemplateField {
  key: string;
  label: string;
  toolGroup: string;
}

/** Full response from the scaffold endpoint. */
export interface ScaffoldResponse {
  suggestedTools: SuggestedTool[];
  customerKnowledgeTemplate: KnowledgeTemplateField[];
}

/** Tool definition extracted from the agent config. */
interface AgentTool {
  toolName: string;
  description: string;
  inputSchema: Record<string, unknown>;
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

let bedrockClient: BedrockRuntimeClient | null = null;
let qconnectClient: QConnectClient | null = null;

function getBedrockClient(): BedrockRuntimeClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: REGION });
  }
  return qconnectClient;
}

/** @internal — allows test injection */
export function _setBedrockClient(client: BedrockRuntimeClient | null): void {
  bedrockClient = client;
}

/** @internal — allows test injection */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

// ---------------------------------------------------------------------------
// Agent tool fetching
// ---------------------------------------------------------------------------

/**
 * Fetch the full tool list for an agent using GetAIAgent.
 */
async function fetchAgentTools(agentId: string): Promise<AgentTool[]> {
  const client = getQConnectClient();

  const command = new GetAIAgentCommand({
    assistantId: ASSISTANT_ID,
    aiAgentId: agentId,
  });

  const response = await client.send(command);
  const agentConfig = response.aiAgent;

  if (!agentConfig || !agentConfig.configuration) {
    return [];
  }

  // With updated SDK, configuration is a union with the key as the config type
  const config = agentConfig.configuration as any;
  const orchConfig = config.orchestrationAIAgentConfiguration;

  if (!orchConfig || !orchConfig.toolConfigurations) {
    return [];
  }

  const tools: AgentTool[] = [];
  for (const toolConfig of orchConfig.toolConfigurations) {
    const toolName = toolConfig.toolName ?? "";
    const description = toolConfig.description ?? "";
    const inputSchema = toolConfig.inputSchema as Record<string, unknown> ?? {};

    if (toolName) {
      tools.push({ toolName, description, inputSchema });
    }
  }

  return tools;
}

// ---------------------------------------------------------------------------
// Bedrock: Tool sequence inference
// ---------------------------------------------------------------------------

/**
 * Build the prompt to infer the tool chain from a goal description.
 */
export function buildToolSequencePrompt(
  goalDescription: string,
  tools: AgentTool[]
): string {
  const toolDescriptions = tools
    .map((t) => {
      const schemaStr = Object.keys(t.inputSchema).length > 0
        ? `\n    Input Schema: ${JSON.stringify(t.inputSchema)}`
        : "";
      return `  - ${t.toolName}: ${t.description}${schemaStr}`;
    })
    .join("\n");

  return `You are an expert at analyzing AI agent tool configurations. Given a customer goal and the available tools, determine the ordered sequence of tools the agent would need to invoke to fulfill the goal.

## Customer Goal
${goalDescription}

## Available Tools
${toolDescriptions}

## Instructions
Determine the likely sequence of tool invocations needed to fulfill the customer's goal. For each tool in the sequence:
- Assign a position (1-based, ordered)
- Label it as "required" if it MUST be invoked for goal completion, or "optional" if it MAY be invoked depending on the conversation path

If you cannot determine a clear tool sequence (due to ambiguity, insufficient tool coverage, or the goal not matching available tools), respond with:
{"error": "reason explanation"}

Otherwise respond with ONLY valid JSON (no markdown fences):
{"tools": [{"toolName": "ToolName", "position": 1, "required": true}]}`;
}

/**
 * Call Bedrock to infer the tool sequence for a goal.
 */
async function inferToolSequence(
  goalDescription: string,
  tools: AgentTool[]
): Promise<{ tools: SuggestedTool[] } | { error: string }> {
  const client = getBedrockClient();

  // Resolve the live prompt (system text, model id, and `maxTokens`)
  // from the registry. Fail-closed: if the override store read fails the
  // resolver throws `PromptResolutionError` and the caller maps it to a 500.
  const prompt: ResolvedPrompt = await resolvePromptLive("suite_scaffold");

  const userText = buildToolSequencePrompt(goalDescription, tools);
  const messages: Message[] = [
    { role: "user", content: [{ text: userText }] },
  ];

  // The wire-shape helper places `maxTokens` (and any future
  // capability-profile-accepted keys) into the exact arguments the
  // Converse SDK expects. The casts on `inferenceConfig` and
  // `additionalModelRequestFields` bridge the SDK's strict types and
  // our runtime payload — `buildInferenceConfig` already enforced the
  // exact key set against the resolved capability profile.
  const built = buildInferenceConfig(prompt);

  const command = new ConverseCommand({
    modelId: prompt.modelId,
    system: [{ text: prompt.text }],
    messages,
    inferenceConfig:
      built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(built.additionalModelRequestFields
      ? {
          additionalModelRequestFields:
            built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  const response = await client.send(command);
  const content = response.output?.message?.content;

  if (!content || content.length === 0 || !content[0].text) {
    return { error: "Bedrock returned empty response" };
  }

  return parseToolSequenceResponse(content[0].text.trim());
}

/**
 * Parse the Bedrock tool sequence response.
 */
export function parseToolSequenceResponse(
  responseText: string
): { tools: SuggestedTool[] } | { error: string } {
  try {
    // Strip markdown fences if present
    let jsonStr = responseText;
    const fenceMatch = responseText.match(
      /```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/
    );
    if (fenceMatch) {
      jsonStr = fenceMatch[1];
    }

    const parsed = JSON.parse(jsonStr);

    // Check for error response
    if (typeof parsed.error === "string") {
      return { error: parsed.error };
    }

    // Validate tools array
    if (!Array.isArray(parsed.tools)) {
      return { error: "Invalid response: missing tools array" };
    }

    const tools: SuggestedTool[] = parsed.tools
      .filter(
        (t: Record<string, unknown>) =>
          typeof t.toolName === "string" &&
          typeof t.position === "number"
      )
      .map((t: Record<string, unknown>) => ({
        toolName: t.toolName as string,
        position: t.position as number,
        required: t.required !== false, // default to required
      }));

    if (tools.length === 0) {
      return { error: "No valid tools in response" };
    }

    return { tools };
  } catch {
    return { error: "Failed to parse Bedrock response as JSON" };
  }
}

// ---------------------------------------------------------------------------
// Bedrock: Parameter label mapping
// ---------------------------------------------------------------------------

/**
 * Build the prompt to map parameter names to customer-facing labels.
 */
export function buildLabelMappingPrompt(
  parameters: Array<{ paramName: string; toolGroup: string }>
): string {
  const paramList = parameters
    .map((p) => `  - "${p.paramName}" (used by tool: ${p.toolGroup})`)
    .join("\n");

  return `Map the following technical parameter names to customer-facing labels. Each label should be a short, descriptive phrase that a non-technical user would understand (e.g., "accountNumber" → "Account Number", "destinationCity" → "Destination City", "pnrCode" → "Booking Reference").

## Parameters
${paramList}

## Instructions
Respond with ONLY valid JSON (no markdown fences):
{"labels": [{"paramName": "originalName", "label": "Customer-Facing Label"}]}`;
}

/**
 * Call Bedrock to map parameter names to customer-facing labels.
 */
async function mapParameterLabels(
  parameters: Array<{ paramName: string; toolGroup: string }>
): Promise<Map<string, string>> {
  if (parameters.length === 0) {
    return new Map();
  }

  const client = getBedrockClient();

  // Resolve the live prompt for case-level parameter labelling.
  const prompt: ResolvedPrompt = await resolvePromptLive("case_scaffold");

  const userText = buildLabelMappingPrompt(parameters);
  const messages: Message[] = [
    { role: "user", content: [{ text: userText }] },
  ];

  const built = buildInferenceConfig(prompt);

  const command = new ConverseCommand({
    modelId: prompt.modelId,
    system: [{ text: prompt.text }],
    messages,
    inferenceConfig:
      built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(built.additionalModelRequestFields
      ? {
          additionalModelRequestFields:
            built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  const response = await client.send(command);
  const content = response.output?.message?.content;

  if (!content || content.length === 0 || !content[0].text) {
    // Fallback: use param names as labels
    return new Map(parameters.map((p) => [p.paramName, p.paramName]));
  }

  return parseLabelMappingResponse(content[0].text.trim(), parameters);
}

/**
 * Parse the label mapping response from Bedrock.
 */
export function parseLabelMappingResponse(
  responseText: string,
  parameters: Array<{ paramName: string; toolGroup: string }>
): Map<string, string> {
  const fallbackMap = new Map(
    parameters.map((p) => [p.paramName, p.paramName])
  );

  try {
    let jsonStr = responseText;
    const fenceMatch = responseText.match(
      /```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/
    );
    if (fenceMatch) {
      jsonStr = fenceMatch[1];
    }

    const parsed = JSON.parse(jsonStr);

    if (!Array.isArray(parsed.labels)) {
      return fallbackMap;
    }

    const labelMap = new Map<string, string>();
    for (const entry of parsed.labels) {
      if (
        typeof entry.paramName === "string" &&
        typeof entry.label === "string"
      ) {
        labelMap.set(entry.paramName, entry.label);
      }
    }

    // Fill in any missing labels with the param name itself
    for (const p of parameters) {
      if (!labelMap.has(p.paramName)) {
        labelMap.set(p.paramName, p.paramName);
      }
    }

    return labelMap;
  } catch {
    return fallbackMap;
  }
}

// ---------------------------------------------------------------------------
// Knowledge template generation
// ---------------------------------------------------------------------------

/**
 * Extract parameter names from a JSON Schema input schema.
 */
export function extractParameterNames(
  inputSchema: Record<string, unknown>
): string[] {
  // JSON Schema typically has "properties" at the top level or under type: "object"
  const properties = inputSchema.properties as Record<string, unknown> | undefined;

  if (properties && typeof properties === "object") {
    return Object.keys(properties);
  }

  // If the schema itself has keys that look like param definitions (flat schema)
  // filter out JSON Schema meta-keywords
  const metaKeys = new Set([
    "type",
    "properties",
    "required",
    "description",
    "title",
    "additionalProperties",
    "$schema",
    "$ref",
    "items",
    "allOf",
    "anyOf",
    "oneOf",
    "not",
    "enum",
    "const",
    "default",
    "examples",
    "definitions",
    "$defs",
  ]);

  const keys = Object.keys(inputSchema).filter((k) => !metaKeys.has(k));
  return keys.length > 0 ? keys : [];
}

/**
 * Generate the customer knowledge template from the inferred tool sequence.
 *
 * Uses deduplicateParameters from the shared utility, then enriches with
 * customer-facing labels from Bedrock.
 */
async function generateKnowledgeTemplate(
  suggestedTools: SuggestedTool[],
  agentTools: AgentTool[]
): Promise<KnowledgeTemplateField[]> {
  // Build a lookup map for agent tools
  const toolMap = new Map(agentTools.map((t) => [t.toolName, t]));

  // Build ToolSchema array for deduplication
  const toolSchemas: ToolSchema[] = suggestedTools
    .sort((a, b) => a.position - b.position)
    .map((st) => {
      const agentTool = toolMap.get(st.toolName);
      const parameters = agentTool
        ? extractParameterNames(agentTool.inputSchema)
        : [];
      return { toolName: st.toolName, parameters };
    });

  // Deduplicate parameters using the shared utility
  const deduplicated = deduplicateParameters(toolSchemas);

  if (deduplicated.length === 0) {
    return [];
  }

  // Map parameter names to customer-facing labels via Bedrock
  const paramsForLabeling = deduplicated.map((entry) => ({
    paramName: entry.paramName,
    toolGroup: entry.toolGroup,
  }));

  const labelMap = await mapParameterLabels(paramsForLabeling);

  // Build the final template
  return deduplicated.map((entry) => ({
    key: entry.paramName,
    label: labelMap.get(entry.paramName) ?? entry.paramName,
    toolGroup: entry.toolGroup,
  }));
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

/**
 * Lambda handler for POST /suites/{suiteId}/cases/scaffold.
 *
 * Orchestrates intelligent test case scaffolding:
 * 1. Fetches agent tools via GetAIAgent
 * 2. Calls Bedrock to infer tool sequence from goal description
 * 3. Deduplicates parameters across tools
 * 4. Calls Bedrock to generate customer-facing labels
 * 5. Returns suggested tools and knowledge template
 */
export async function handler(event: {
  pathParameters?: { suiteId?: string };
  body?: string;
}): Promise<{
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}> {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  };

  // Parse and validate request body
  if (!event.body) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Missing request body" }),
      headers,
    };
  }

  let request: ScaffoldRequest;
  try {
    const parsed = JSON.parse(event.body);
    if (!parsed.goalDescription || typeof parsed.goalDescription !== "string") {
      return {
        statusCode: 400,
        body: JSON.stringify({
          error: "Missing or invalid goalDescription field",
        }),
        headers,
      };
    }
    if (!parsed.agentId || typeof parsed.agentId !== "string") {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing or invalid agentId field" }),
        headers,
      };
    }
    request = { goalDescription: parsed.goalDescription, agentId: parsed.agentId };
  } catch {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Invalid JSON in request body" }),
      headers,
    };
  }

  // Apply overall operation timeout
  const controller = new AbortController();
  const timeout = setTimeout(
    () => controller.abort(),
    OPERATION_TIMEOUT_MS
  );

  try {
    // 1. Fetch agent tools
    const agentTools = await fetchAgentTools(request.agentId);

    if (agentTools.length === 0) {
      clearTimeout(timeout);
      return {
        statusCode: 400,
        body: JSON.stringify({
          error: "No tools found for the specified agent",
        }),
        headers,
      };
    }

    // 2. Infer tool sequence via Bedrock
    const sequenceResult = await inferToolSequence(
      request.goalDescription,
      agentTools
    );

    if ("error" in sequenceResult) {
      clearTimeout(timeout);
      return {
        statusCode: 422,
        body: JSON.stringify({
          error: "Unable to infer tool sequence",
          reason: sequenceResult.error,
        }),
        headers,
      };
    }

    // 3 & 4. Generate knowledge template (dedup + label mapping)
    const knowledgeTemplate = await generateKnowledgeTemplate(
      sequenceResult.tools,
      agentTools
    );

    clearTimeout(timeout);

    // 5. Return response
    const response: ScaffoldResponse = {
      suggestedTools: sequenceResult.tools,
      customerKnowledgeTemplate: knowledgeTemplate,
    };

    return {
      statusCode: 200,
      body: JSON.stringify(response),
      headers,
    };
  } catch (error) {
    clearTimeout(timeout);

    // Handle abort (timeout)
    if (error instanceof Error && error.name === "AbortError") {
      return {
        statusCode: 504,
        body: JSON.stringify({
          error: "Operation timed out",
          reason: "Scaffold operation exceeded the 30-second timeout",
        }),
        headers,
      };
    }

    console.error(
      "[scaffold] Handler error:",
      error instanceof Error ? error.message : error
    );
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal server error during scaffolding",
        message: error instanceof Error ? error.message : "Unknown error",
      }),
      headers,
    };
  }
}
