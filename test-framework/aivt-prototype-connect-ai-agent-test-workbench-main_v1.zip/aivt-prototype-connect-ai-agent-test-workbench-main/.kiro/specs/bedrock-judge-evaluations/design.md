# Design Document: Bedrock-Judge Evaluations

## Overview

This feature replaces the AgentCore Evaluate (`bedrock-agentcore:Evaluate`) integration that was specified in `platform-hosting-and-evaluations` Workstream 2 with a direct **Bedrock Converse** integration that uses the **AWS-published built-in evaluator prompt templates** as its scoring rubric. The platform produces the same three scores per `TestCaseResult` (`goalSuccessScore`, `helpfulnessScore`, `toolAccuracyScore`) in the same `[0.0, 1.0]` range, with the same `Evaluation_Error_State` semantics, the same persistence shape, and the same UI surfaces. The only seam that changes is the scoring backend and the modules that call it.

This document explains why the pivot is necessary, defines the new high-level system, lists what is reused unchanged from the previous spec, and states the migration plan.

## Why the pivot is necessary (validated facts)

The original spec assumed AgentCore Evaluate as the scoring backend. **That assumption does not hold for this platform's use case.** The reasons below are empirically validated, not speculative.

1. **Wrong agent runtime.** This platform tests **Q in Connect ORCHESTRATION agents** via `qconnect:ListSpans`. AgentCore Evaluate is built around **AgentCore Runtime + ADOT**: it consumes telemetry that has been emitted by an AgentCore Runtime agent, exported through the AWS Distro for OpenTelemetry, and ingested into the CloudWatch log groups `aws/spans` and `/aws/bedrock-agentcore/runtimes/{agent_id}-DEFAULT`. The Evaluate API expects records in that **post-ingestion** form, not raw OTLP/JSON.

2. **The wire format is not publicly documented.** The published `EvaluationInput` schema describes `sessionSpans` as "OpenTelemetry-format" but the actual wire shape is whatever the AgentCore Runtime + ADOT pipeline writes to CloudWatch. The `bedrock-agentcore-starter-toolkit` evaluation toolkit (`operations/evaluation/on_demand_processor.py`) reads spans from `aws/spans`, reads runtime logs from `/aws/bedrock-agentcore/runtimes/...`, and submits the raw `@message` text **verbatim** to Evaluate. There is no public schema we can hand-craft.

3. **Direct empirical confirmation.** We ran 9 live `bedrock-agentcore:Evaluate` calls against this dev account testing different hand-crafted wire shapes — numeric vs string `*UnixNano`, scope with/without `version`, stringified vs structured `body`, separate input/output events vs combined events, events nested inside the span vs top-level, post-ingestion-style records — and every single variant that included an `invoke_agent` span returned `LogEventMissingException` with the message *"Span with ID X and name invoke_agent is missing a corresponding log event"*. The service is doing internal pairing that requires records produced by its own pipeline.

4. **Ingestion prerequisite is off in this account.** AgentCore observability requires CloudWatch Transaction Search to be enabled. The current dev account has `aws xray get-trace-segment-destination` returning `XRay`, not `CloudWatch`. Even if we deployed an AgentCore Runtime agent, observability would not surface the spans Evaluate needs without a separate, billable account-level change.

5. **AWS publishes the rubric.** AWS documents the **exact prompt templates** AgentCore's built-in evaluators use at `https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html`, including `Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, and `Builtin.ToolSelectionAccuracy`. The templates take placeholder strings (`{available_tools}`, `{context}`, `{assistant_turn}`, `{tool_turn}`) and return a fenced-JSON `{ reasoning, score }` object. Calling `bedrock:Converse` with these templates produces equivalent scoring without needing the ingestion pipeline.

### Validation evidence

`scripts/bedrock-judge-probe.ts` is committed in this repo as the working reference. Running it against the two checked-in `Span_Fixtures` produces:

| Fixture | goalSuccessScore | helpfulnessScore | toolAccuracyScore |
|---|---|---|---|
| `multi-tool-success` | 1.0000 | 0.7500 | 0.5000 |
| `failure-escalation` | 0.0000 | 0.6667 | 0.3333 |

The judge reasoning was defensible in both cases: in `multi-tool-success` the judge correctly flagged the `verifyIdentity` tool call as "No" because the customer never explicitly volunteered the ANI in conversation (the agent inferred it from caller-ID context the judge cannot see); in `failure-escalation` the judge correctly identified that the dispute was escalated, not resolved.

### Failure modes that disappear with this pivot

Two categories of integration failure that the AgentCore Evaluate spec had to plan for **no longer exist** with the Bedrock-judge approach:

- The `LogEventMissingException` pairing failure (we don't go through CloudWatch ingestion).
- The `evaluationReferenceInputs[].context` validation failure (reference inputs become part of the prompt context, not a separate API field).

The remaining error modes (timeout, throttling, model error, malformed JSON response) are mapped to the same `Evaluation_Error_State` codes that the previous spec defined.

## Architecture

### System context

```mermaid
flowchart TB
    SFN[State Machine] --> EV[Evaluation Lambda]
    EV --> DDB[(DynamoDB<br/>RUN# / CASE#)]
    EV --> RENDER[judge-prompt-rendering<br/>pure module]
    RENDER --> JUDGE[bedrock-judge-client<br/>thin SDK seam]
    JUDGE --> BR[bedrock-runtime<br/>ConverseCommand]
    BR --> MODEL[(Claude Sonnet 4.6<br/>cross-region<br/>inference profile)]

    EV --> AGGR[evaluation-scoring<br/>reused unchanged]
    EV --> ASSEMBLE[evaluation-result<br/>reused unchanged]

    Dev([Developer]) -->|harness CLI| HARNESS[scripts/evaluation-harness.ts]
    HARNESS --> RENDER
    HARNESS --> JUDGE

    STEER[".kiro/steering/<br/>bedrock-judge-prompts.md<br/>(verbatim AWS templates)"] --> RENDER

    classDef reused fill:#e8f5e9,stroke:#2e7d32
    classDef new fill:#e3f2fd,stroke:#1565c0
    classDef external fill:#fff3e0,stroke:#ef6c00
    class AGGR,ASSEMBLE,DDB reused
    class RENDER,JUDGE,STEER new
    class BR,MODEL external
```

### Per-case data flow

```mermaid
sequenceDiagram
    participant SM as State Machine
    participant EV as Evaluation Lambda
    participant DB as DynamoDB
    participant PR as prompt-rendering (pure)
    participant JC as bedrock-judge-client
    participant BR as bedrock:Converse

    SM->>EV: EvaluationInput {runId, caseResults, testCases}
    loop each test case
        EV->>DB: getExecutionTrace + getTranscript + getSnapshot
        alt trace has zero turns AND zero tool calls
            EV->>DB: writeResult (Evaluation_Error_State INSUFFICIENT_TRACE)
        else submittable
            EV->>PR: render { context, available_tools, per-turn assistant_turns, per-tool tool_turns }
            par GoalSuccessRate (1 call)
                EV->>JC: judge(GSR template, vars)
                JC->>BR: ConverseCommand
            and Helpfulness (N calls — one per assistant turn)
                EV->>JC: judge(Help template, vars) × N
                JC->>BR: ConverseCommand × N
            and ToolSelectionAccuracy (M calls — one per tool call)
                EV->>JC: judge(Tool template, vars) × M
                JC->>BR: ConverseCommand × M
            end
            JC-->>EV: { reasoning, score } per call
            alt all required outcomes present
                EV->>EV: map score-scale → [0,1], aggregate (mean), clamp
                EV->>DB: writeResult { goalSuccessScore, helpfulnessScore, toolAccuracyScore }
            else timeout / model error / unmappable / missing
                EV->>DB: writeResult (Evaluation_Error_State + partial scores)
            end
        end
    end
    EV-->>SM: { evaluated, errored }
```

The semantics — "submit once, fan out across evaluator units, aggregate, clamp, persist" — match what the previous spec specified. The only change is the **submission target**: where AgentCore Evaluate would have been one HTTP call per evaluator returning multiple results, the Bedrock judge is one Converse call per evaluator **unit** (one for the session-level goal, N for per-turn helpfulness, M for per-tool selection). Per-case Converse calls are made concurrently and the per-case timeout is preserved.

## Components and Interfaces

### 1. Prompt-template steering doc (new)

**Path**: `.kiro/steering/bedrock-judge-prompts.md`

Conditionally included on this feature's spec files. Contains **verbatim** copies of the three AWS-published prompt templates we use (Goal Success Rate, Helpfulness, Tool Selection Accuracy), each preceded by a header noting the AWS doc URL it was copied from and the date of the copy. Single source of truth for the prompts; version-controlled so AWS updates can be diffed and merged deliberately.

The steering doc also documents the **score-scale mappings** we use to convert categorical scores into the `[0.0, 1.0]` range, so the mapping logic and the prompt contract live next to each other.

### 2. Pure prompt-rendering module (new, replaces OTel translation)

**Path**: `src/shared/utils/judge-prompt-rendering.ts`

No AWS imports. Takes an `ExecutionTrace`, the matching `TranscriptTurn[]`, the `AgentSnapshot.tools`, and the test case's `expectedToolNames`. Produces:

- `renderContext(trace, transcript)` — the formatted conversation as `User:` / `Assistant:` / `Action:` / `Tool:` lines that the templates expect for `{context}`.
- `renderAvailableTools(tools)` — a numbered list of tool name + description + input schema for `{available_tools}`.
- `renderAssistantTurn(step)` — the per-turn assistant utterance for `{assistant_turn}` (used by Helpfulness).
- `renderToolTurn(toolInvocation)` — `name(jsonArgs)` for `{tool_turn}` (used by Tool Selection Accuracy).
- A turn-grouping helper that splits the trace into per-assistant-turn windows so we can build the *prefix-only* context required by the per-turn evaluators (each evaluator sees only the conversation up to and including the unit being evaluated).

This is the **direct replacement for `trace-to-otel.ts`**. The pure trace-grouping logic carries over; the OTel-specific synthesis goes away. Reqs 9.6 (unit-testable without deploy) and 16 (validated against checked-in `Span_Fixtures`) carry over unchanged in spirit — the new fixture conformance tests assert the *rendered prompts* match committed golden snapshots, not the OTel schema.

### 3. Bedrock judge client wrapper (new)

**Path**: `src/backend/orchestration/bedrock-judge-client.ts`

Thin SDK seam over `@aws-sdk/client-bedrock-runtime` `ConverseCommand`. Single public method:

```
judge({ template, vars, timeoutMs }) → { reasoning: string; score: string }
```

- Substitutes the `vars` into the `template` string, sends one Converse call to the configured judge model, parses the fenced-JSON response (matches the `\`\`\`...\`\`\`` block the templates ask for), returns `{ reasoning, score }` raw.
- Wraps each call in a timeout (default 60 s, satisfying the previous spec's Req 10.1 intent). Timeout throws a typed `JudgeTimeoutError`.
- Does **not** interpret scores. All score-scale mapping lives in `evaluation-scoring.ts` so it stays pure and testable.
- Mockable via `_setBedrockClient` for unit tests, mirroring the existing `_setQConnectClient` pattern.

### 4. Score-scale mapping (extension to existing module)

**Path**: `src/shared/utils/evaluation-scoring.ts` (extended; existing exports unchanged)

Add canonical mapping tables for the three evaluators' rubrics:

- **Goal Success Rate** (Yes / No) → `{ Yes: 1.0, No: 0.0 }`.
- **Tool Selection Accuracy** (Yes / No) → same as above.
- **Helpfulness** (7-point scale) → `{ "Not Helpful At All": 0/6, "Very Unhelpful": 1/6, "Somewhat Unhelpful": 2/6, "Neutral/Mixed": 3/6, "Somewhat Helpful": 4/6, "Very Helpful": 5/6, "Above And Beyond": 6/6 }`.

The existing `clamp01`, `aggregateMean`, `aggregateScores` are reused unchanged: per-turn helpfulness values are mean-reduced into `helpfulnessScore`; per-tool tool-selection values are mean-reduced into `toolAccuracyScore`; the session-level goal value maps directly to `goalSuccessScore`. The same arithmetic-mean documentation that satisfied the previous Req 8.4 carries over.

### 5. Evaluation Lambda rewrite

**Path**: `src/backend/orchestration/evaluation.ts`

Composes the new modules end-to-end. Per test case:

1. Load trace / transcript / snapshot (unchanged).
2. If trace has zero turns AND zero tool calls → `Evaluation_Error_State` code `INSUFFICIENT_TRACE`. No submission. (Same as previous spec Req 9.5.)
3. Render the four context strings via the prompt-rendering module.
4. Issue concurrent judge calls: 1 GSR + N Helpfulness + M Tool Selection.
5. Map results to `[0.0, 1.0]` scores via `evaluation-scoring.ts`.
6. `aggregateScores(...)`. If any call timed out, errored, or returned an unmappable score, set `Evaluation_Error_State` with the specific reason; persist whatever scores *were* produced. (Same as previous spec Reqs 8.7, 10.2.)
7. Persist a `TestCaseResult` for every case to `RUN#/CASE#` (same as previous spec Req 8.5).
8. Run is never failed solely due to per-case error states (same as previous spec Req 10.5).
9. **No local-scoring fallback** anywhere in the path (same as previous spec Req 10.6).

The error-state code enum gets a single rename: `AGENTCORE_ERROR` → `JUDGE_ERROR`. Other codes (`INSUFFICIENT_TRACE`, `TIMEOUT`, `UNMAPPABLE_RESULT`, `MISSING_EVALUATOR`) are unchanged.

### 6. Local harness update

**Path**: `scripts/evaluation-harness.ts`

Swap the AgentCore client for the Bedrock judge client; same CLI surface (file path or session id). Same code path as the Lambda (preserves previous Req 11.4). `scripts/bedrock-judge-probe.ts` is the validated reference behavior; the harness becomes the production version with proper error handling and DynamoDB integration when in session mode.

### 7. CDK orchestration construct change

**Path**: `lib/orchestration-construct.ts`

- Remove `@aws-sdk/client-bedrock-agentcore` from `package.json` and from the Lambda's bundle. The probe confirmed we don't need it.
- Keep `@aws-sdk/client-bedrock-runtime` (already bundled).
- IAM grants on the evaluation Lambda role:
  - **Drop**: `bedrock-agentcore:Evaluate` (and any `agentcore-*` permissions added for the previous spec).
  - **Add**: `bedrock:InvokeModel` and `bedrock:Converse` scoped to **exactly** the configured Judge_Model — one inference-profile ARN per region in the profile's Judge_Model_Routing_Regions set, plus one foundation-model ARN per region in the same set for the underlying Anthropic model id the profile resolves to. No `us.anthropic.*` or `anthropic.*` wildcard segments in the resource ARNs; no `bedrock:*` wildcard actions. The grant is narrower than the existing Conversation_Driver and Analysis Lambda grants in `lib/api-construct.ts` and `lib/orchestration-construct.ts`, which use family wildcards.
  - The inference-profile prefix (`us.` / `eu.` / `apac.`) deterministically selects the routing region set; a bare foundation-model id (no profile prefix) yields a one-region grant. An unrecognized prefix fails synth (Requirement 6.8).
- Lambda env var `JUDGE_MODEL_ID` defaulting to `us.anthropic.claude-sonnet-4-6` — the same model id used by `src/backend/handlers/analysis.ts` and `src/backend/handlers/scaffold.ts`, so reasoning-quality is consistent across the platform. Configurable via CDK context (`judgeModelId`) so a deployer can pin a different judge model without code changes.

### 8. Configurable judge model

The judge model is treated as a **deploy-time configuration**, not a per-case parameter:

- Default `us.anthropic.claude-sonnet-4-6` — matches the model id used elsewhere in the platform (`analysis.ts`, `scaffold.ts`) so reasoning-quality is consistent across analysis, scaffold, and judge.
- Configurable via CDK context key `judgeModelId` and corresponding Lambda env var `JUDGE_MODEL_ID`.
- The IAM grant is derived deterministically from `judgeModelId`:
  - For an inference-profile id with prefix `us.` / `eu.` / `apac.`, the grant enumerates the inference-profile ARN in the home region and the underlying foundation-model ARN in **every region the profile may route to** (us-prefix → us-east-1/us-east-2/us-west-2; eu-prefix → eu-central-1/eu-west-1/eu-west-3/eu-north-1; apac-prefix → ap-northeast-1/ap-northeast-2/ap-south-1/ap-southeast-1/ap-southeast-2).
  - For a bare foundation-model id (no profile prefix), the grant is a single foundation-model ARN in the deploy region.
  - Resource ARNs are exact — no wildcard in the model id segment. A profile prefix outside the supported set fails synth.
- The validated probe (`scripts/bedrock-judge-probe.ts`) hard-codes a different model id (`us.anthropic.claude-3-5-sonnet-20241022-v2:0`) as its sample reference and is intentionally left unchanged; the production default tracks the platform's standard reasoning model.

A future evolution could allow per-case judge models, but it is **explicitly out of scope** for this feature to keep the integration deterministic and reproducible.

### 9. Cost & latency expectations

Per test case, the number of Converse calls is `1 + N + M` where N is the count of assistant turns and M is the count of tool calls in the trace. For our two checked-in fixtures that's **5** and **7** calls respectively.

- **Latency**: with within-case parallelism (one batch of `1 + N + M` Converse calls fired concurrently), wall-clock per case is bounded by the slowest single Converse call plus a fixed overhead. Per-call timeout is 60 s (preserved from the previous spec). A per-case budget of 90 s is documented.
- **Cost**: Claude Sonnet 4.6 is the default judge. A typical case (~5 calls, ~3K input tokens + ~500 output tokens per call) is on the order of `~$0.03–$0.05` per case at current Bedrock pricing. Documented cost guidance: a 100-case run is `~$3–$5` of judge cost. (Compared to the AgentCore Evaluate path, the cost order is similar — AgentCore's billing also flows through the underlying judge model.)
- **Throttling resilience**: the SDK already retries with exponential backoff. The Lambda treats persistent throttling at end of timeout as a `JUDGE_ERROR` Evaluation_Error_State code. No local fallback.

## Data models

### TestCaseResult — unchanged

The persisted `TestCaseResult` shape (in `src/shared/types.ts`) is **identical** to the previous spec. The three score fields and the `evaluationError` shape carry over verbatim. Only the `evaluationError.code` enum's `AGENTCORE_ERROR` member is renamed to `JUDGE_ERROR`.

### Score-scale tables — new

Documented in the steering file and exported from `evaluation-scoring.ts`:

```
GoalSuccessScale  : { Yes: 1.0, No: 0.0 }
HelpfulnessScale  : 7 levels uniformly spaced 0..1 (steps of 1/6)
ToolSelectionScale: { Yes: 1.0, No: 0.0 }
```

The mapping tables are explicit, version-controlled constants — not derived from the prompt strings — so a future prompt revision that changes the rubric can be paired with an explicit mapping change in code review.

### Span_Fixture — unchanged

The two checked-in `Span_Fixture` files (`tests/fixtures/spans/multi-tool-success.json`, `tests/fixtures/spans/failure-escalation.json`) are reused unchanged. Their fixture conformance tests now assert that the **rendered prompts** match committed golden snapshots, not that the synthesized OTel JSON matches the AgentCore input schema (the previous spec's Req 16.2/16.3).

## Reused unchanged

These pure modules from the `platform-hosting-and-evaluations` spec are declared dependencies of this feature and **must not be rewritten**:

| Module | Why it's reused |
|---|---|
| `src/shared/utils/evaluation-scoring.ts` | `clamp01`, `aggregateMean`, `aggregateScores` are scoring-backend-agnostic. Extended with the new score-scale tables; existing exports unchanged. |
| `src/shared/utils/evaluation-result.ts` | `assembleCaseEvaluation` already maps `AggregatedScores` + failure context into `TestCaseResult`. The only edit is one renamed enum value. |
| `src/shared/utils/score-comparison.ts` | `compareScores` operates on persisted score values, not on how they were produced. Untouched. |
| `src/shared/types.ts` | `TestCaseResult`, `evaluationError`, `ExecutionTrace`, `TranscriptTurn`, `AgentSnapshot`. Only the `evaluationError.code` enum gets one renamed member. |
| Frontend results / comparison views | They render values from `TestCaseResult` and `compareScores`; the source of those values is irrelevant to them. Untouched. |
| Run history, suite list, run detail APIs | Untouched. |

## Error Handling

The `Evaluation_Error_State` semantics from the previous spec carry over verbatim. Each per-case failure mode maps to a specific `evaluationError.code`, the three score fields are left unset for that case, the run is **not** failed solely because individual cases entered the error state, and **no local-scoring fallback is ever substituted**.

| Failure mode | Detection | `evaluationError.code` | Behavior |
|---|---|---|---|
| Trace has zero turns AND zero tool calls | Pre-flight check before any judge call | `INSUFFICIENT_TRACE` | Persist error state with reason; no Converse call; do not fail the run |
| Single Converse call exceeds 60 s | Per-call timeout in `bedrock-judge-client` | `TIMEOUT` | Persist error state naming the timed-out evaluator; partial scores from other evaluators are preserved |
| Bedrock returns an error (`ThrottlingException`, `ValidationException`, `ServiceUnavailableException`, `ModelStreamErrorException`, etc.) | SDK error propagated through the judge client | `JUDGE_ERROR` | Persist error state with the error name and message; partial scores preserved |
| Judge response is not valid fenced JSON, or `score` is not in the rubric, or response cannot be parsed | Parse / validation failure in the judge client | `UNMAPPABLE_RESULT` | Persist error state; partial scores preserved |
| One requested evaluator returns no usable result while others succeed | After aggregation, when `aggregateScores` reports `missingEvaluators` | `MISSING_EVALUATOR` | Persist whatever scores *were* produced; record which evaluator(s) were missing |
| Per-case overall budget exceeded (90 s wall-clock) | Lambda-level deadline | `TIMEOUT` | Persist error state; cancel any in-flight Converse calls for that case |

The `JUDGE_ERROR` code is the only addition compared with the previous spec; it is the rename of `AGENTCORE_ERROR`. The error-reason strings are human-readable and surface in the results UI in place of the missing scores (preserved from previous spec Req 10.4).

The CDK construct grants `bedrock:InvokeModel` and `bedrock:Converse` only on the configured judge model's foundation-model ARN and inference-profile ARN. Any access-denied response is surfaced as `JUDGE_ERROR` with the operation name in the reason, so a misconfiguration is diagnosable without code changes.

## Correctness Properties

The pure modules in this feature are validated by property-based tests (Vitest + `fast-check`, min 100 iterations) in line with the platform's PBT convention. Each property below is implemented by a single property-based test tagged `// Feature: bedrock-judge-evaluations, Property {n}: {text}` and run at `{ numRuns: 100 }`.

### Property 1: Prompt rendering is deterministic and complete

For every parsed `ExecutionTrace`, the rendered context (a) preserves chronological order across turns and tool calls, (b) emits one `User:` line per customer turn, one `Assistant:` line per inference step, and one `Action:`/`Tool:` pair per tool call, (c) does not omit or duplicate any step.

**Validates: Requirements 2.1, 2.2, 11.3**

### Property 2: Per-turn windowing is prefix-only

The `{context}` rendered for the i-th assistant turn or the i-th tool call references **only** the steps that strictly precede it (and the unit being evaluated, where the template requires it). No future steps leak into the per-turn context.

**Validates: Requirements 2.4**

### Property 3: Score-scale mapping is total and in-range

Every label in each documented rubric maps to a finite value in `[0.0, 1.0]`; an unrecognized label is treated as a parse failure that triggers `UNMAPPABLE_RESULT`, not a silent zero.

**Validates: Requirements 4.1, 4.2, 4.4, 8.3**

### Property 4: Goal direct + arithmetic-mean aggregation

The session-level goal value maps directly to `goalSuccessScore`; per-turn helpfulness values reduce to `helpfulnessScore` by unweighted arithmetic mean; per-tool tool-selection values reduce to `toolAccuracyScore` by unweighted arithmetic mean. (Carried over from the previous spec's Property 10.)

**Validates: Requirements 1.3, 1.4, 1.5**

### Property 5: Every emitted score is in [0.0, 1.0]

Every score persisted to a `TestCaseResult` passes through `clamp01`. (Carried over from Property 9.)

**Validates: Requirements 1.6**

### Property 6: Error state leaves the right scores unset

When the entire case fails before any score is produced, all three scores are unset; when partial scoring succeeds, only the missing scores are unset and produced scores are preserved. (Carried over from Property 12.)

**Validates: Requirements 8.5, 1.9, 8.4**

### Property 7: No local-scoring fallback path

A static check asserts the Lambda never imports any local-scoring helper as a substitute for a judge call. (Carried over from Property 13.)

**Validates: Requirements 8.5, 8.8**

Properties 14, 15, 16 from the previous spec (score-delta classification, summary exhaustiveness, frontend bucket security) are owned by other specs and are unaffected.

## Testing Strategy

Three layers of validation:

1. **Property-based tests (Vitest + fast-check, ≥100 iterations) for the pure modules.** Co-located with each module under `tests/unit/properties/`. Properties 1–7 above.
2. **Golden-prompt snapshot tests against the checked-in `Span_Fixtures`.** For each fixture in `tests/fixtures/spans/`, render the four context strings (`{context}`, `{available_tools}`, `{assistant_turn}` per turn, `{tool_turn}` per tool call), commit them as `.txt` snapshots under `tests/fixtures/golden-prompts/`, and assert byte-equality on every test run. Any change to the rendering logic or to a fixture surfaces as a snapshot diff in code review.
3. **Mocked Lambda tests.** Inject a mock `bedrock-judge-client` whose `judge` method returns a scripted sequence of `{ reasoning, score }` payloads (including timeouts, malformed JSON, throttling, and missing evaluators) and assert that the Lambda persists the right `TestCaseResult` (or `Evaluation_Error_State`) for each scenario. The DynamoDB writes are asserted via the existing `aws-sdk-client-mock` patterns.

The local harness (`scripts/evaluation-harness.ts`) imports the same modules as the Lambda and is the principal way developers iterate on prompts/rendering without redeploying. Live AgentCore-style end-to-end runs against the real Bedrock API are demonstrated by `scripts/bedrock-judge-probe.ts`; those runs are billable and are not part of the automated test suite.

## Migration plan

The previous spec's `tasks.md` is split:

- **Workstream 1 (Tasks 1–9)** — frontend hosting & first-user bootstrap. **Stays as-is.** It is independent of the evaluation backend and is largely complete.
- **Workstream 2 (Tasks 10–21)** — the AgentCore evaluations integration, harness, and fixtures. **Superseded** by this spec.

Concretely:

1. The pure modules already produced under Workstream 2 (Tasks 10, 12, 13, 20) are kept in place and inherited by this feature. Task 20 (`compareScores` + UI wiring) is fully complete and unchanged.
2. The AgentCore-specific modules built under Workstream 2 are removed:
   - `src/backend/orchestration/trace-to-otel.ts` → deleted (replaced by `judge-prompt-rendering.ts`).
   - `src/backend/orchestration/agentcore-client.ts` → deleted (replaced by `bedrock-judge-client.ts`).
   - The OTel-translation property tests (Tasks 11.2–11.6) → replaced with golden-prompt and turn-grouping property tests against the prompt renderer.
   - The Span_Fixture AgentCore-input-schema conformance test (Task 19.2) → replaced with a `renderContext` snapshot test against the same fixtures.
3. The Evaluation Lambda (`evaluation.ts`) and harness (`evaluation-harness.ts`) are rewritten to compose the new modules.
4. CDK construct (`lib/orchestration-construct.ts`) and `package.json` change as described above.
5. Steering file added.

The `bedrock-judge-probe.ts` script remains in `scripts/` as a documented reference. The other diagnostic probes (`agentcore-shape-probe.ts`, `strands-tracer-probe.py`) can be deleted once the new spec ships.

### Probe-to-production mapping

For reviewers cross-referencing the validated probe with the production design:

| Concern in `scripts/bedrock-judge-probe.ts` | Production home |
|---|---|
| `GOAL_SUCCESS_RATE_TEMPLATE`, `HELPFULNESS_TEMPLATE`, `TOOL_SELECTION_TEMPLATE` constants | `.kiro/steering/bedrock-judge-prompts.md` |
| `HELPFULNESS_SCALE`, `YES_NO_SCALE` constants | `src/shared/utils/evaluation-scoring.ts` (extended) |
| `groupTraceIntoTurns`, `renderFullContext`, `renderContextBefore`, `renderAvailableTools` | `src/shared/utils/judge-prompt-rendering.ts` |
| `judge`, `extractJson`, `fillTemplate` helpers | `src/backend/orchestration/bedrock-judge-client.ts` |
| `main` orchestration loop | `src/backend/orchestration/evaluation.ts` (production) and `scripts/evaluation-harness.ts` (developer-facing) |
| Per-case parallelism (probe is sequential for clarity) | Production fans out 1 + N + M Converse calls concurrently |
| Error handling (probe throws on first failure) | Production maps each failure mode to a specific `Evaluation_Error_State` code |

## Dependencies on AWS-published prompt templates

The prompt templates are pulled from `https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html`. The steering file records the URL and the date of each copy.

**Refresh strategy when AWS publishes updates**:

1. Periodic check (manual or via a hook on the steering file): diff the live AWS docs against the committed steering file. If the templates change, open a small PR that updates the steering file with the new verbatim copy AND updates the score-scale mappings in `evaluation-scoring.ts` if the rubric changed.
2. Golden-prompt snapshot tests in this feature ensure that any change to a template (or to the rendering logic) is surfaced in code review as a snapshot diff, not silently absorbed.
3. The judge model id is also configurable per deploy, so a deployer can pin to a model version that was validated against a specific template revision.

The platform does not silently track AWS updates. All updates are explicit, reviewed changes.

## Out of scope

- Reusing any of the AgentCore Evaluate API surface. We are abandoning it for Q in Connect agents.
- Custom evaluators (the AgentCore `Custom_Evaluator` / Lambda-as-judge flow). We use only the three published built-in templates.
- Multi-judge ensembles or judge model A/B testing.
- Re-implementing AgentCore's exact rounding, calibration, or label thresholding. Our scores are independently produced; we mirror AgentCore's rubrics, not its post-processing.
- Online (streaming) evaluation. The Lambda evaluates a completed run; online evaluation is a separate feature.
- A future move to AgentCore Runtime + the official Evaluate API path. If the platform later runs Q in Connect agents through an AgentCore Runtime shim, it could call Evaluate directly; that would be a new feature.

## Open questions for follow-up

1. **Judge model selection**: The default tracks the platform's standard reasoning model (`us.anthropic.claude-sonnet-4-6`, same as `analysis.ts` / `scaffold.ts`). If the platform later standardises on a global vs. region-prefixed inference profile, the `judgeModelId` default — and the routing-region table in §8 — should move with it.
2. **Within-case concurrency limit**: at high case counts, an unbounded fan-out per case could throttle Bedrock. Is a per-case Converse semaphore (e.g., 4 concurrent calls) worth specifying?
3. **Steering-file refresh cadence**: should there be an explicit hook/CI job that fails if `bedrock-judge-prompts.md` is older than 90 days? Or is "fresh on every PR that touches evaluation" sufficient?

These are tracked but not blocking the high-level design.
