/**
 * Score-aware run comparison utility.
 *
 * Pure helper that extends the {@link ./run-comparison} pattern: for each test
 * case present in both runs, compute per-metric deltas (`later − earlier`) for
 * `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore`; classify
 * each delta as `improved` / `regressed` / `unchanged` by sign; emit
 * `not-comparable` when a metric is present in only one of the two runs
 * (including a case in the `Evaluation_Error_State`); and produce a per-metric
 * suite summary.
 *
 * Implemented as a pure function so score-comparison correctness can be
 * verified without a deploy (Req 15.6).
 *
 * @module score-comparison
 */

import { TestCaseResult } from "../types";

/** The three evaluation score fields compared per case. */
export type MetricKey =
  | "goalSuccessScore"
  | "helpfulnessScore"
  | "toolAccuracyScore";

/** Classification of a per-metric delta between two runs. */
export type DeltaClass =
  | "improved"
  | "regressed"
  | "unchanged"
  | "not-comparable";

/** Ordered list of the metrics compared. */
export const METRIC_KEYS: readonly MetricKey[] = [
  "goalSuccessScore",
  "helpfulnessScore",
  "toolAccuracyScore",
] as const;

/** Per-metric delta for a single case. */
export interface MetricDelta {
  metric: MetricKey;
  /** `later − earlier`. Undefined when classification is `not-comparable`. */
  delta?: number;
  classification: DeltaClass;
}

/** Per-case bundle of all three metric deltas. */
export interface CaseScoreComparison {
  caseId: string;
  metrics: Record<MetricKey, MetricDelta>;
}

/** Per-metric counts of classifications across all comparable cases. */
export interface ScoreComparisonSummary {
  perMetric: Record<
    MetricKey,
    {
      improved: number;
      regressed: number;
      unchanged: number;
      notComparable: number;
    }
  >;
}

/** Aggregate result of comparing scores between two runs. */
export interface ScoreComparisonResult {
  entries: CaseScoreComparison[];
  summary: ScoreComparisonSummary;
}

/**
 * Compare per-metric evaluation scores for cases present in both runs.
 *
 * Matching is performed by `caseId` (mirroring {@link ./run-comparison}).
 * For each case present in both runs:
 * - If a metric has a numeric value in both runs, `delta = later − earlier`
 *   classified `improved` (>0), `regressed` (<0), or `unchanged` (==0).
 * - If a metric is present in only one run (including an
 *   `Evaluation_Error_State` case where the three score fields are unset),
 *   classification is `not-comparable` and `delta` is undefined.
 *
 * Cases present in only one of the two runs (added/removed) are deliberately
 * excluded — that classification is owned by `compareRuns`. This helper
 * layers per-metric deltas on top of the existing case-level comparison.
 *
 * @param runA - Earlier run results.
 * @param runB - Later run results.
 * @returns Per-case metric deltas and a per-metric summary.
 */
export function compareScores(
  runA: TestCaseResult[],
  runB: TestCaseResult[]
): ScoreComparisonResult {
  const mapA = new Map<string, TestCaseResult>();
  const mapB = new Map<string, TestCaseResult>();

  for (const result of runA) {
    mapA.set(result.caseId, result);
  }
  for (const result of runB) {
    mapB.set(result.caseId, result);
  }

  const entries: CaseScoreComparison[] = [];
  const summary: ScoreComparisonSummary = {
    perMetric: {
      goalSuccessScore: emptyCounts(),
      helpfulnessScore: emptyCounts(),
      toolAccuracyScore: emptyCounts(),
    },
  };

  // Iterate cases present in BOTH runs (per Req 15.1). Use runA's order to
  // produce a stable, deterministic output for the same inputs.
  for (const [caseId, earlier] of mapA) {
    const later = mapB.get(caseId);
    if (!later) continue;

    const metrics = {} as Record<MetricKey, MetricDelta>;

    for (const metric of METRIC_KEYS) {
      const earlierValue = earlier[metric];
      const laterValue = later[metric];
      const metricDelta = classify(metric, earlierValue, laterValue);
      metrics[metric] = metricDelta;

      const counts = summary.perMetric[metric];
      switch (metricDelta.classification) {
        case "improved":
          counts.improved += 1;
          break;
        case "regressed":
          counts.regressed += 1;
          break;
        case "unchanged":
          counts.unchanged += 1;
          break;
        case "not-comparable":
          counts.notComparable += 1;
          break;
      }
    }

    entries.push({ caseId, metrics });
  }

  return { entries, summary };
}

function classify(
  metric: MetricKey,
  earlier: number | undefined,
  later: number | undefined
): MetricDelta {
  const haveEarlier = isFiniteNumber(earlier);
  const haveLater = isFiniteNumber(later);

  if (!haveEarlier || !haveLater) {
    return { metric, classification: "not-comparable" };
  }

  const delta = (later as number) - (earlier as number);
  let classification: DeltaClass;
  if (delta > 0) {
    classification = "improved";
  } else if (delta < 0) {
    classification = "regressed";
  } else {
    classification = "unchanged";
  }
  return { metric, delta, classification };
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function emptyCounts() {
  return { improved: 0, regressed: 0, unchanged: 0, notComparable: 0 };
}
