/**
 * Experiment Create Lambda — POST /runs/{runId}/experiments
 *
 * Creates a multi-variant experiment from a run's per-suite recommendations.
 * Generates a new experiment record and starts the Experiment State Machine
 * to orchestrate variant generation, temporary agent creation, parallel test
 * execution, and cleanup.
 *
 * Flow:
 * 1. Validate INSTANCE_MODE !== "production" → 403
 * 2. Generate experimentId (UUID v4)
 * 3. Load per-suite recommendations for the run
 * 4. Persist experiment record with status "generating_variants"
 * 5. Start Experiment State Machine execution
 * 6. Return { experimentId, status: "generating_variants" }
 *
 * Environment variables:
 * - TABLE_NAME: DynamoDB table name
 * - INSTANCE_MODE: "production" or "development"
 * - EXPERIMENT_STATE_MACHINE_ARN: ARN of the Experiment Step Functions state machine
 *
 * @module experiment-create
 */

import { SFNClient, StartExecutionCommand } from "@aws-sdk/client-sfn";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
} from "@aws-sdk/lib-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import type {
  ExperimentCreateRequest,
  ExperimentRecord,
  PerSuiteRecommendation,
} from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

function getTableName(): string {
  return process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
}

function getInstanceMode(): string {
  return process.env.INSTANCE_MODE ?? "development";
}

function getExperimentStateMachineArn(): string {
  return process.env.EXPERIMENT_STATE_MACHINE_ARN ?? "";
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

let sfnClient: SFNClient | null = null;
let ddbDocClient: DynamoDBDocumentClient | null = null;

function getSFNClient(): SFNClient {
  if (!sfnClient) {
    sfnClient = new SFNClient({ region: process.env.AWS_REGION ?? "us-east-1" });
  }
  return sfnClient;
}

function getDDBDocClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setSFNClient(client: SFNClient | null): void {
  sfnClient = client;
}

/** @internal — allows test injection */
export function _setDDBDocClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  body?: string | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, string>;
    };
  };
}

export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(statusCode: number, body: unknown): APIGatewayResponse {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

function nowISO(): string {
  return new Date().toISOString();
}

/** Sort key used by the suite-recommend handler to store per-suite analysis. */
const ANALYSIS_SUITE_SK = "ANALYSIS#SUITE";

// ---------------------------------------------------------------------------
// DynamoDB Accessors
// ---------------------------------------------------------------------------

interface PersistedSuiteAnalysis {
  recommendations: PerSuiteRecommendation[];
  generatedAt: string;
  modelId: string;
}

/**
 * Strips DynamoDB key attributes (PK, SK, GSI*) from an item.
 */
function stripKeys<T>(item: Record<string, unknown>): T {
  const copy = { ...item };
  delete copy.PK;
  delete copy.SK;
  delete copy.GSI1PK;
  delete copy.GSI1SK;
  delete copy.GSI2PK;
  delete copy.GSI2SK;
  return copy as unknown as T;
}

/**
 * Load persisted per-suite analysis for a run.
 */
async function loadSuiteAnalysis(
  runId: string
): Promise<PersistedSuiteAnalysis | null> {
  const client = getDDBDocClient();
  const result = await client.send(
    new GetCommand({
      TableName: getTableName(),
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: ANALYSIS_SUITE_SK,
      },
    })
  );
  if (!result.Item) return null;
  return stripKeys<PersistedSuiteAnalysis>(
    result.Item as Record<string, unknown>
  );
}

/**
 * Persist the initial experiment record to DynamoDB.
 */
async function persistExperimentRecord(
  runId: string,
  record: ExperimentRecord
): Promise<void> {
  const client = getDDBDocClient();
  await client.send(
    new PutCommand({
      TableName: getTableName(),
      Item: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `${SK_PATTERNS.EXPERIMENT}${record.experimentId}`,
        ...record,
      },
    })
  );
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

/**
 * Lambda handler for POST /runs/{runId}/experiments.
 */
export async function handler(
  event: APIGatewayEvent
): Promise<APIGatewayResponse> {
  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  // --- Step 1: Validate INSTANCE_MODE ---
  if (getInstanceMode() === "production") {
    return jsonResponse(403, {
      error: "write_disabled",
      reason: "Agent writes and experiments are disabled in production mode",
    });
  }

  // Extract runId from path parameters
  const runId = event.pathParameters?.runId;
  if (!runId) {
    return jsonResponse(400, { error: "runId is required" });
  }

  // Parse request body
  if (!event.body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let request: ExperimentCreateRequest;
  try {
    request = JSON.parse(event.body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  // Validate request fields
  if (request.mode !== "multi_variant") {
    return jsonResponse(400, { error: 'mode must be "multi_variant"' });
  }
  if (!request.agentId || typeof request.agentId !== "string") {
    return jsonResponse(400, { error: "agentId is required" });
  }

  try {
    // --- Step 2: Generate experimentId ---
    const experimentId = crypto.randomUUID();

    // --- Step 3: Load per-suite recommendations ---
    const suiteAnalysis = await loadSuiteAnalysis(runId);
    if (!suiteAnalysis || suiteAnalysis.recommendations.length === 0) {
      return jsonResponse(404, { error: "no_recommendations" });
    }

    const recommendations = suiteAnalysis.recommendations;

    // --- Step 4: Persist experiment record ---
    const now = nowISO();
    const experimentRecord: ExperimentRecord = {
      experimentId,
      runId,
      agentId: request.agentId,
      status: "generating_variants",
      variantConfigs: [],
      temporaryAgentIds: {} as Record<"A" | "B" | "C", string>,
      variantRunIds: {} as Record<"A" | "B" | "C", string>,
      baselineRunId: runId,
      sfnExecutionArn: "", // will be updated after start
      cleanupStatus: "pending",
      createdAt: now,
    };

    await persistExperimentRecord(runId, experimentRecord);

    // --- Step 5: Start Experiment State Machine ---
    const sfn = getSFNClient();
    const stateMachineArn = getExperimentStateMachineArn();

    const executionInput = JSON.stringify({
      runId,
      experimentId,
      agentId: request.agentId,
      recommendations,
    });

    const execResult = await sfn.send(
      new StartExecutionCommand({
        stateMachineArn,
        name: `experiment-${experimentId}-${Date.now()}`,
        input: executionInput,
      })
    );

    // Update experiment record with the execution ARN (best-effort)
    if (execResult.executionArn) {
      const client = getDDBDocClient();
      await client.send(
        new PutCommand({
          TableName: getTableName(),
          Item: {
            PK: `${PK_PATTERNS.RUN}${runId}`,
            SK: `${SK_PATTERNS.EXPERIMENT}${experimentId}`,
            ...experimentRecord,
            sfnExecutionArn: execResult.executionArn,
          },
        })
      );
    }

    // --- Step 6: Return experiment ID and status ---
    return jsonResponse(202, {
      experimentId,
      status: "generating_variants",
    });
  } catch (error: unknown) {
    console.error(
      "[experiment-create] Handler error:",
      error instanceof Error ? error.message : error
    );

    const errorName = (error as { name?: string })?.name ?? "";

    if (errorName === "ThrottlingException") {
      return jsonResponse(429, {
        error: "ThrottlingException",
        message: "Request rate exceeded. Please retry after a brief delay.",
        retryable: true,
        retryAfterSeconds: 5,
      });
    }

    if (errorName === "StateMachineDoesNotExist") {
      return jsonResponse(500, {
        error: "configuration_error",
        message: "Experiment state machine is not configured",
      });
    }

    return jsonResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
}
