/**
 * Score Aggregation Module
 *
 * Pure function computing aggregate scores from an array of TestCaseResult.
 * Used by the Tournament View to display per-column aggregate metrics
 * (pass rate, average goal success, average helpfulness, average tool accuracy).
 *
 * Cases with undefined scores are excluded from mean calculations (not
 * counted as 0). If no cases define a given score, the aggregate returns 0.
 * An empty input array yields all zeros.
 *
 * @module score-aggregation
 */

import { CaseStatus } from "../../shared/enums";
import { TestCaseResult } from "../../shared/types";

// ---------------------------------------------------------------------------
// Public Interfaces
// ---------------------------------------------------------------------------

export interface AggregateScores {
  passRate: number;
  avgGoalSuccessScore: number;
  avgHelpfulnessScore: number;
  avgToolAccuracyScore: number;
}

// ---------------------------------------------------------------------------
// Implementation
// ---------------------------------------------------------------------------

/**
 * Computes aggregate scores from an array of TestCaseResult.
 *
 * - passRate: count of cases with status "passed" / total cases
 * - avgGoalSuccessScore: mean of goalSuccessScore across cases where it's defined
 * - avgHelpfulnessScore: mean of helpfulnessScore across cases where it's defined
 * - avgToolAccuracyScore: mean of toolAccuracyScore across cases where it's defined
 *
 * Cases with undefined scores are excluded from the mean calculation (not counted as 0).
 * If no cases have a defined score for a metric, return 0 for that metric.
 * If the input array is empty, all values are 0.
 */
export function aggregateScores(results: TestCaseResult[]): AggregateScores {
  if (results.length === 0) {
    return {
      passRate: 0,
      avgGoalSuccessScore: 0,
      avgHelpfulnessScore: 0,
      avgToolAccuracyScore: 0,
    };
  }

  // Pass rate: count of PASSED / total
  const passedCount = results.filter(
    (r) => r.status === CaseStatus.PASSED
  ).length;
  const passRate = passedCount / results.length;

  // Average goal success score (excluding undefined)
  const avgGoalSuccessScore = computeMean(
    results,
    (r) => r.goalSuccessScore
  );

  // Average helpfulness score (excluding undefined)
  const avgHelpfulnessScore = computeMean(
    results,
    (r) => r.helpfulnessScore
  );

  // Average tool accuracy score (excluding undefined)
  const avgToolAccuracyScore = computeMean(
    results,
    (r) => r.toolAccuracyScore
  );

  return {
    passRate,
    avgGoalSuccessScore,
    avgHelpfulnessScore,
    avgToolAccuracyScore,
  };
}

/**
 * Computes the arithmetic mean of a numeric field across results, excluding
 * entries where the extractor returns undefined. Returns 0 if no entries
 * have a defined value.
 */
function computeMean(
  results: TestCaseResult[],
  extractor: (r: TestCaseResult) => number | undefined
): number {
  let sum = 0;
  let count = 0;

  for (const result of results) {
    const value = extractor(result);
    if (value !== undefined) {
      sum += value;
      count++;
    }
  }

  return count === 0 ? 0 : sum / count;
}
