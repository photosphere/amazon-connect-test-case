/**
 * `comparison_summary` — system prompt for the Bedrock Converse call
 * inside `POST /comparisons/summarize`. The user message (a structured
 * JSON diff between two runs) is built locally by `buildUserMessage`
 * inside `comparison-summary.ts`; the registered prompt is the literal
 * `SYSTEM_PROMPT` constant lifted byte-for-byte from
 * `src/backend/handlers/comparison-summary.ts`.
 *
 * @module backend/orchestration/prompt-registry/prompts/comparison-summary
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

/**
 * Byte-for-byte equivalent of the `SYSTEM_PROMPT` array-join in
 * `comparison-summary.ts`. The legacy module composes the literal as
 * `[ ... ].join("\n")` so the registry default uses the same pattern to
 * preserve identity.
 */
const DEFAULT_TEXT = [
  "You are a concise summariser of test-run comparisons for an Amazon Connect AI agent test platform.",
  "You receive a JSON diff describing two runs of the same test suite (Run A is the earlier run, Run B is the later run).",
  "Produce a 3-5 bullet summary that highlights only what is meaningfully different between the two runs.",
  "Strict rules:",
  " - Cite ONLY facts present in the JSON. Do NOT speculate about root causes; the platform has a separate failure-analysis tool for that.",
  " - When you reference a numeric change (status counts, score means, character deltas), state it explicitly (e.g. 'goal success mean 0.83 → 1.00').",
  " - When two runs are identical (no status changes, no score deltas, no config diffs), say so plainly in one sentence and stop.",
  " - Never fabricate case ids; reference only ids that appear in caseStatusChanges.",
  " - Output plain text. Use '- ' for bullets. No markdown headers, no preamble, no JSON wrapping.",
  " - Hard limit: 6 bullets, 60 words per bullet.",
].join("\n");

export const comparisonSummaryPrompt: PromptDefinition = {
  promptKey: "comparison_summary",
  name: "Comparison Summary — Run vs Run",
  description:
    "System prompt for the Converse call that produces a short, deterministic, plain-language summary of the diff between two runs of the same suite.",
  category: "analysis",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 2_048 },
  },
  defaultInferenceValues: {
    maxTokens: 2_048,
  },
};
