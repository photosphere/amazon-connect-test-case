/**
 * Unit tests for the Cases CRUD Lambda handler.
 *
 * Tests type-discriminator validation, normalization, and response structure
 * using a mocked DynamoDB service layer.
 *
 * Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 11.4
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import {
  handler,
  _setDBService,
  _setAgentToolsFetcher,
  normalizeTestCase,
  type APIGatewayEvent,
} from "../../src/backend/handlers/cases";
import { DynamoDBService } from "../../src/backend/services/dynamodb";
import type { ToolSequenceTestCase } from "../../src/shared/types";
import { CommunicationStyle } from "../../src/shared/enums";

// ---------------------------------------------------------------------------
// Mock DynamoDB service
// ---------------------------------------------------------------------------

function createMockDBService(): {
  service: DynamoDBService;
  mocks: Record<string, ReturnType<typeof vi.fn>>;
} {
  const mocks = {
    createSuite: vi.fn().mockResolvedValue(undefined),
    getSuite: vi.fn().mockResolvedValue(null),
    updateSuite: vi.fn().mockResolvedValue(undefined),
    deleteSuite: vi.fn().mockResolvedValue(undefined),
    listSuites: vi.fn().mockResolvedValue([]),
    createCase: vi.fn().mockResolvedValue(undefined),
    getCase: vi.fn().mockResolvedValue(null),
    updateCase: vi.fn().mockResolvedValue(undefined),
    deleteCase: vi.fn().mockResolvedValue(undefined),
    listCases: vi.fn().mockResolvedValue([]),
  };

  return { service: mocks as unknown as DynamoDBService, mocks };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const TENANT_ID = "tenant-abc-123";
const SUITE_ID = "suite-001";

function makeEvent(overrides: Partial<APIGatewayEvent>): APIGatewayEvent {
  return {
    httpMethod: "GET",
    resource: "/suites/{suiteId}/cases",
    pathParameters: { suiteId: SUITE_ID },
    body: null,
    requestContext: {
      authorizer: {
        claims: { sub: TENANT_ID },
      },
    },
    ...overrides,
  };
}

function makeSuite() {
  return {
    tenantId: TENANT_ID,
    suiteId: SUITE_ID,
    name: "My Test Suite",
    description: "A test suite description",
    agentId: "agent-xyz",
    assistantId: "assistant-abc",
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  };
}

function makeToolSequenceCase(overrides: Partial<ToolSequenceTestCase> = {}): ToolSequenceTestCase {
  return {
    type: "tool_sequence",
    suiteId: SUITE_ID,
    caseId: "case-001",
    name: "Test Case 1",
    description: "A test case description",
    persona: "Friendly customer",
    style: CommunicationStyle.DIRECT,
    customerKnowledge: { accountId: "12345" },
    initialUtterance: "I need help with my account",
    successCriteria: [{ toolName: "AuthenticateUser", required: true }],
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("Cases CRUD Lambda", () => {
  let mockDB: ReturnType<typeof createMockDBService>;

  beforeEach(() => {
    mockDB = createMockDBService();
    _setDBService(mockDB.service);
    _setAgentToolsFetcher(null);
  });

  describe("POST /suites/{suiteId}/cases — Create RAG case", () => {
    it("creates a valid RAG case and persists with type: 'rag'", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: SUITE_ID },
        body: JSON.stringify({
          type: "rag",
          name: "RAG Case",
          description: "Testing return policy",
          question: "What is the return policy?",
          groundTruthAnswer: "Returns are accepted within 30 days of purchase.",
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(201);

      const body = JSON.parse(result.body);
      expect(body.type).toBe("rag");
      expect(body.question).toBe("What is the return policy?");
      expect(body.groundTruthAnswer).toBe("Returns are accepted within 30 days of purchase.");
      expect(body.suiteId).toBe(SUITE_ID);
      expect(body.caseId).toBeDefined();

      // Verify DB call
      expect(mockDB.mocks.createCase).toHaveBeenCalledOnce();
      const persistedCase = mockDB.mocks.createCase.mock.calls[0][0];
      expect(persistedCase.type).toBe("rag");
    });

    it("returns HTTP 400 when 'question' is missing", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: SUITE_ID },
        body: JSON.stringify({
          type: "rag",
          name: "RAG Case",
          description: "Testing return policy",
          groundTruthAnswer: "Returns within 30 days.",
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);

      const body = JSON.parse(result.body);
      expect(body.details).toBeDefined();
      expect(body.details.some((e: { field: string }) => e.field === "question")).toBe(true);
    });

    it("returns HTTP 400 when 'question' is empty after trimming", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: SUITE_ID },
        body: JSON.stringify({
          type: "rag",
          name: "RAG Case",
          description: "Testing",
          question: "   ",
          groundTruthAnswer: "Some answer.",
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);

      const body = JSON.parse(result.body);
      expect(body.details).toBeDefined();
      expect(body.details.some((e: { field: string }) => e.field === "question")).toBe(true);
    });

    it("returns HTTP 400 with 'rag_case_extraneous_field' when simulator field is present on RAG case", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: SUITE_ID },
        body: JSON.stringify({
          type: "rag",
          name: "RAG Case",
          description: "Testing",
          question: "What is the return policy?",
          groundTruthAnswer: "Returns within 30 days.",
          persona: "Angry customer", // extraneous simulator field
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);

      const body = JSON.parse(result.body);
      expect(body.error).toBe("rag_case_extraneous_field");
      expect(body.field).toBe("persona");
    });

    it("returns HTTP 400 when sessionData has more than 20 pairs", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      // Build sessionData with 21 entries
      const sessionData: Record<string, string> = {};
      for (let i = 0; i < 21; i++) {
        sessionData[`key${i}`] = `value${i}`;
      }

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: SUITE_ID },
        body: JSON.stringify({
          type: "rag",
          name: "RAG Case",
          description: "Testing",
          question: "What is the return policy?",
          groundTruthAnswer: "Returns within 30 days.",
          sessionData,
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);

      const body = JSON.parse(result.body);
      expect(body.details).toBeDefined();
      expect(
        body.details.some((e: { field: string }) => e.field === "sessionData"),
      ).toBe(true);
    });
  });

  describe("POST /suites/{suiteId}/cases — Create tool-sequence case", () => {
    it("creates a valid tool-sequence case preserving all existing fields", async () => {
      mockDB.mocks.getSuite.mockResolvedValue(makeSuite());

      const event = makeEvent({
        httpMethod: "POST",
        resource: "/suites/{suiteId}/cases",
        pathParameters: { suiteId: SUITE_ID },
        body: JSON.stringify({
          type: "tool_sequence",
          name: "TS Case",
          description: "A tool-sequence test case",
          persona: "Impatient customer",
          style: "direct",
          customerKnowledge: { orderId: "ORD-123" },
          initialUtterance: "Where is my order?",
          successCriteria: [
            { toolName: "LookupOrder", required: true },
            { toolName: "GetShipmentStatus", required: true },
          ],
          sessionData: { phoneNumber: "+15551234567" },
          primingMessage: "[System] Customer has reached you.",
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(201);

      const body = JSON.parse(result.body);
      expect(body.type).toBe("tool_sequence");
      expect(body.persona).toBe("Impatient customer");
      expect(body.style).toBe("direct");
      expect(body.customerKnowledge).toEqual({ orderId: "ORD-123" });
      expect(body.initialUtterance).toBe("Where is my order?");
      expect(body.successCriteria).toHaveLength(2);
      expect(body.sessionData).toEqual({ phoneNumber: "+15551234567" });
      expect(body.primingMessage).toBe("[System] Customer has reached you.");
      expect(body.caseId).toBeDefined();
    });
  });

  describe("PUT /suites/{suiteId}/cases/{caseId} — Type mutation", () => {
    it("returns HTTP 400 when attempting to change type on PUT", async () => {
      // Existing case is tool_sequence
      mockDB.mocks.getCase.mockResolvedValue(makeToolSequenceCase());

      const event = makeEvent({
        httpMethod: "PUT",
        resource: "/suites/{suiteId}/cases/{caseId}",
        pathParameters: { suiteId: SUITE_ID, caseId: "case-001" },
        body: JSON.stringify({
          type: "rag", // attempting to change from tool_sequence to rag
          question: "Some question",
          groundTruthAnswer: "Some answer",
        }),
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(400);

      const body = JSON.parse(result.body);
      expect(body.error).toContain("immutable");
    });
  });

  describe("GET /suites/{suiteId}/cases/{caseId} — Legacy normalization", () => {
    it("normalizes a legacy record without 'type' field to 'tool_sequence' on read", async () => {
      // Simulate a legacy record that has no type field
      const legacyRecord = {
        suiteId: SUITE_ID,
        caseId: "case-legacy",
        name: "Legacy Case",
        description: "Old case without type",
        persona: "Customer",
        style: CommunicationStyle.DIRECT,
        customerKnowledge: {},
        initialUtterance: "Hello",
        successCriteria: [{ toolName: "SomeTool", required: true }],
        // No 'type' field — this is how pre-feature records look
      };
      mockDB.mocks.getCase.mockResolvedValue(legacyRecord);

      const event = makeEvent({
        httpMethod: "GET",
        resource: "/suites/{suiteId}/cases/{caseId}",
        pathParameters: { suiteId: SUITE_ID, caseId: "case-legacy" },
      });

      const result = await handler(event);
      expect(result.statusCode).toBe(200);

      const body = JSON.parse(result.body);
      expect(body.type).toBe("tool_sequence");
      // All original fields preserved
      expect(body.persona).toBe("Customer");
      expect(body.initialUtterance).toBe("Hello");
    });
  });

  describe("normalizeTestCase function", () => {
    it("normalizes record without type to tool_sequence", () => {
      const raw = {
        suiteId: SUITE_ID,
        caseId: "case-001",
        name: "Old Case",
        description: "Legacy",
        persona: "Customer",
      };

      const normalized = normalizeTestCase(raw);
      expect(normalized.type).toBe("tool_sequence");
    });

    it("preserves type: rag when present", () => {
      const raw = {
        type: "rag",
        suiteId: SUITE_ID,
        caseId: "case-002",
        name: "RAG Case",
        description: "Test",
        question: "Q?",
        groundTruthAnswer: "A.",
      };

      const normalized = normalizeTestCase(raw);
      expect(normalized.type).toBe("rag");
    });
  });
});
