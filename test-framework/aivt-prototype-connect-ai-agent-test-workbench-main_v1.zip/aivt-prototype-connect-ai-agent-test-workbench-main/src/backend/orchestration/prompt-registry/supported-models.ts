/**
 * Supported_Models catalog — the frozen record that enumerates every
 * Bedrock model the Prompts page exposes in its per-prompt model
 * dropdown. This module is the single source of truth for the canonical
 * cross-region inference-profile id (used as the Bedrock `modelId`), the
 * capability-profile mapping (used by the validation pipeline and the
 * `buildInferenceConfig` helper), the per-model `maxOutputTokens` ceiling
 * (used by the dry-render validator), the `routingRegions[]` set (used by
 * the `computeBedrockGrants` CDK helper), and the foundation-model
 * wildcard fragment (used by the IAM grant expansion).
 *
 * The catalog currently exposes five models: Claude Sonnet 4.6, Claude
 * Haiku 4.5, Claude Opus 4.8, Amazon Nova Lite, and Amazon Nova Pro.
 * Adding a new model is a registry edit followed by a real-Bedrock
 * conformance probe gate (per R18) — never a silent change.
 *
 * Amazon Nova Premier was previously listed here but was removed after a
 * conformance probe surfaced that Bedrock now classifies it as Legacy
 * with 30-day-usage gating. New tenants see `Access denied. This Model
 * is marked by provider as Legacy and you have not been actively using
 * the model in the last 30 days.` on the first Converse call. Removing
 * it from the catalog matches the wire reality: a Lambda that resolves
 * to it would 4xx instead of producing tokens.
 *
 * Build-time invariants (R17.6) are enforced by a module-level
 * self-check that runs on first import: every `modelKey` is unique,
 * every `inferenceProfileId` matches the vendor's canonical prefix
 * (`us.anthropic.*` for Anthropic, `us.amazon.*` for Amazon), every
 * `capabilityProfileKey` is declared in the {@link CAPABILITY_PROFILES}
 * catalog, and every `routingRegions[]` is non-empty. A violation throws
 * a typed `Error` at module load — i.e., at Lambda cold-start or test
 * runner start — so a malformed catalog cannot reach a callsite.
 *
 * @module backend/orchestration/prompt-registry/supported-models
 */

import { CAPABILITY_PROFILES } from "./capability-profiles";
import type { ModelKey, SupportedModel } from "./types";

// ---------------------------------------------------------------------------
// Catalog
// ---------------------------------------------------------------------------

/**
 * The Supported_Models catalog. Frozen by `as const` so adding
 * or removing a key starts as a TypeScript error at the consumer side
 * (every consumer that indexes by `ModelKey` would need to handle the
 * new key explicitly).
 *
 * Each entry's fields are sourced as follows:
 *
 *   - `inferenceProfileId` — the canonical cross-region inference profile
 *     id from the AWS Bedrock catalog. Sent verbatim as the Converse
 *     `modelId` argument.
 *   - `capabilityProfileKey` — selects the {@link ModelCapabilityProfile}
 *     governing which `inferenceConfig` keys this model accepts.
 *   - `maxOutputTokens` — the per-model output-token ceiling enforced by
 *     the dry-render validator (the smaller of this and the profile's
 *     `maxTokens.max`).
 *   - `routingRegions` — the AWS Regions the cross-region inference
 *     profile may dispatch a request to. Drives the IAM grant computed at
 *     CDK synth time per R19.
 *   - `foundationModelArnPattern` — the vendor-scoped wildcard fragment
 *     the IAM helper expands into one foundation-model ARN per Region in
 *     `routingRegions[]`.
 *
 * Capability-profile assignment notes (post-Wave-3 conformance probe):
 *
 *   - `claude_opus_4_8` uses the strict `anthropic_claude_4x` profile
 *     because Opus 4.8 wire-rejects `temperature` at the API boundary
 *     (`temperature is deprecated for this model`).
 *   - `claude_sonnet_4_6` and `claude_haiku_4_5` use the lax
 *     `anthropic_claude_4x_lax` profile because both models silently
 *     accept (and drop) `temperature` / `topP` / `topK` / `stopSequences`
 *     on the wire — a strict `forbids[]` would be tighter than wire
 *     reality and the negative probe would fail spuriously.
 */
export const SUPPORTED_MODELS: Readonly<Record<ModelKey, SupportedModel>> = {
  claude_sonnet_4_6: {
    modelKey: "claude_sonnet_4_6",
    displayName: "Claude Sonnet 4.6",
    inferenceProfileId: "us.anthropic.claude-sonnet-4-6",
    vendor: "anthropic",
    capabilityProfileKey: "anthropic_claude_4x_lax",
    maxOutputTokens: 64_000,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "anthropic.*",
  },
  claude_haiku_4_5: {
    modelKey: "claude_haiku_4_5",
    displayName: "Claude Haiku 4.5",
    inferenceProfileId: "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    vendor: "anthropic",
    capabilityProfileKey: "anthropic_claude_4x_lax",
    maxOutputTokens: 64_000,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "anthropic.*",
  },
  claude_opus_4_8: {
    modelKey: "claude_opus_4_8",
    displayName: "Claude Opus 4.8",
    inferenceProfileId: "us.anthropic.claude-opus-4-8",
    vendor: "anthropic",
    capabilityProfileKey: "anthropic_claude_4x",
    maxOutputTokens: 128_000,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "anthropic.*",
  },
  nova_lite: {
    modelKey: "nova_lite",
    displayName: "Amazon Nova Lite",
    inferenceProfileId: "us.amazon.nova-lite-v1:0",
    vendor: "amazon",
    capabilityProfileKey: "amazon_nova",
    maxOutputTokens: 5_120,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "amazon.nova-*",
  },
  nova_pro: {
    modelKey: "nova_pro",
    displayName: "Amazon Nova Pro",
    inferenceProfileId: "us.amazon.nova-pro-v1:0",
    vendor: "amazon",
    capabilityProfileKey: "amazon_nova",
    maxOutputTokens: 5_120,
    routingRegions: ["us-east-1", "us-east-2", "us-west-2"],
    foundationModelArnPattern: "amazon.nova-*",
  },
} as const;

// ---------------------------------------------------------------------------
// Build-time invariants (R17.6)
// ---------------------------------------------------------------------------

/**
 * Vendor-scoped canonical prefix every `inferenceProfileId` must start
 * with for that vendor. Anthropic models use the `us.anthropic.` US
 * cross-region prefix; Amazon models use the `us.amazon.` US cross-region
 * prefix. A mismatch indicates the catalog has drifted from the AWS
 * Bedrock cross-region inference profile naming convention.
 */
const VENDOR_PREFIXES: Readonly<Record<SupportedModel["vendor"], string>> = {
  anthropic: "us.anthropic.",
  amazon: "us.amazon.",
};

/**
 * Validate the catalog at module load. Throws a typed `Error` naming the
 * offending `modelKey` when any invariant fails; the throw aborts the
 * module's evaluation so no consumer can observe a malformed catalog.
 *
 * Exported only so the registry's invariant unit test (Task 2.7) can
 * import and re-run the check against test-double catalogs without having
 * to reload this module from disk. Production callers SHALL NOT invoke it
 * — the runtime invocation at the bottom of this file already pinned the
 * catalog when the module was first imported.
 */
export function assertSupportedModelsInvariants(
  catalog: Readonly<Record<ModelKey, SupportedModel>>,
): void {
  const seenModelKeys = new Set<string>();

  for (const [key, model] of Object.entries(catalog) as Array<
    [ModelKey, SupportedModel]
  >) {
    // Invariant 1: every `modelKey` is unique. The `Record` typing already
    // forces uniqueness at the TypeScript level, but we re-check at runtime
    // so that a hand-rolled object that omits the literal-key constraint
    // (e.g. one constructed via `Object.fromEntries`) still trips the
    // assertion.
    if (model.modelKey !== key) {
      throw new Error(
        `SUPPORTED_MODELS invariant violation: catalog key "${key}" does not match entry.modelKey "${model.modelKey}"`,
      );
    }
    if (seenModelKeys.has(model.modelKey)) {
      throw new Error(
        `SUPPORTED_MODELS invariant violation: duplicate modelKey "${model.modelKey}"`,
      );
    }
    seenModelKeys.add(model.modelKey);

    // Invariant 2: every `inferenceProfileId` starts with the canonical
    // vendor prefix. Catches a copy-paste regression where, e.g., an
    // Anthropic entry lands with an `us.amazon.*` profile id.
    const expectedPrefix = VENDOR_PREFIXES[model.vendor];
    if (!model.inferenceProfileId.startsWith(expectedPrefix)) {
      throw new Error(
        `SUPPORTED_MODELS invariant violation: model "${model.modelKey}" has vendor "${model.vendor}" but inferenceProfileId "${model.inferenceProfileId}" does not start with "${expectedPrefix}"`,
      );
    }

    // Invariant 3: every `capabilityProfileKey` is declared in the
    // capability-profile catalog. Catches a typo or a profile that was
    // removed without updating its consumers.
    if (
      !Object.prototype.hasOwnProperty.call(
        CAPABILITY_PROFILES,
        model.capabilityProfileKey,
      )
    ) {
      throw new Error(
        `SUPPORTED_MODELS invariant violation: model "${model.modelKey}" references capabilityProfileKey "${model.capabilityProfileKey}" which is not declared in CAPABILITY_PROFILES`,
      );
    }

    // Invariant 4: `routingRegions[]` is non-empty (R19.5). The IAM helper
    // expands this list into per-region foundation-model ARNs; an empty
    // list would yield an unscoped wildcard that grants the Lambda the
    // ability to invoke the model in every Region — exactly the broad
    // grant we are trying to avoid.
    if (model.routingRegions.length === 0) {
      throw new Error(
        `SUPPORTED_MODELS invariant violation: model "${model.modelKey}" has empty routingRegions[]`,
      );
    }
  }
}

// Run the invariant check at module load so a malformed catalog can never
// reach a callsite. The throw aborts module evaluation; the import in any
// consumer fails loudly with the reason in the stack trace.
assertSupportedModelsInvariants(SUPPORTED_MODELS);
