// Feature: trace-reasoning-and-latency, Properties 7–9: Span parser metadata
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import {
  extractInferenceMetadata,
  parseSpansToTrace,
  computeDurationMs,
  augmentTraceWithControlTools,
} from "@backend/orchestration/span-parser";
import type { RawSpan } from "@backend/orchestration/span-parser";

// ---------------------------------------------------------------------------
// Shared Arbitraries
// ---------------------------------------------------------------------------

/** All 14 metadata fields with their expected types for generation. */
const NUMBER_FIELDS = [
  "usageInputTokens",
  "usageOutputTokens",
  "usageTotalTokens",
  "requestMaxTokens",
  "temperature",
  "timeToFirstTokenMs",
  "promptVersion",
  "aiAgentVersion",
] as const;

const STRING_FIELDS = [
  "requestModel",
  "promptArn",
  "promptId",
  "promptName",
] as const;

/** Arbitrary for a value that does NOT match the expected type for number fields. */
const invalidNumberArb = fc.oneof(
  fc.string({ minLength: 1, maxLength: 20 }),
  fc.boolean(),
  fc.constant(null),
  fc.constant(undefined),
  fc.constant([1, 2]),
  fc.constant({ value: 42 }),
);

/** Arbitrary for a value that does NOT match the expected type for string fields. */
const invalidStringArb = fc.oneof(
  fc.integer(),
  fc.boolean(),
  fc.constant(null),
  fc.constant(undefined),
  fc.constant([1, 2]),
  fc.constant({ value: "x" }),
);

/** Arbitrary for a valid number value. */
const validNumberArb = fc.oneof(fc.integer(), fc.double({ noNaN: true }));

/** Arbitrary for a valid string value (non-empty for realism). */
const validStringArb = fc.string({ minLength: 1, maxLength: 100 });

/** Arbitrary for a valid responseFinishReasons array (array of strings). */
const validFinishReasonsArb = fc.array(fc.string({ minLength: 1, maxLength: 20 }), { minLength: 1, maxLength: 5 });

/** Arbitrary for an invalid responseFinishReasons value. */
const invalidFinishReasonsArb = fc.oneof(
  fc.constant("not_an_array"),
  fc.constant(123),
  fc.constant(null),
  fc.constant(undefined),
  // Array containing non-string elements
  fc.array(fc.oneof(fc.integer(), fc.boolean(), fc.constant(null)), { minLength: 1, maxLength: 3 }),
);

/** Arbitrary for a valid systemInstructions entry. */
const validSystemInstructionEntryArb = fc.string({ minLength: 0, maxLength: 200 }).map(
  (s) => ({ text: { value: s } }),
);

/** Arbitrary for an invalid systemInstructions entry. */
const invalidSystemInstructionEntryArb = fc.oneof(
  fc.constant({}),
  fc.constant({ text: {} }),
  fc.constant({ text: { value: 123 } }),
  fc.constant({ text: { value: null } }),
  fc.constant({ text: { value: undefined } }),
  fc.constant(null as unknown as { text?: { value?: unknown } }),
);

/**
 * Generates attributes with a random subset of the 14 metadata fields.
 * For each selected field, randomly decide whether to provide a valid or
 * invalid value. Returns both the attributes and which fields are expected
 * to be in the result (those with valid types).
 */
const metadataAttributesArb = fc.record({
  numberFieldEntries: fc.tuple(
    ...NUMBER_FIELDS.map((field) =>
      fc.record({
        field: fc.constant(field),
        include: fc.boolean(),
        useValid: fc.boolean(),
        validValue: validNumberArb,
        invalidValue: invalidNumberArb,
      }),
    ),
  ),
  stringFieldEntries: fc.tuple(
    ...STRING_FIELDS.map((field) =>
      fc.record({
        field: fc.constant(field),
        include: fc.boolean(),
        useValid: fc.boolean(),
        validValue: validStringArb,
        invalidValue: invalidStringArb,
      }),
    ),
  ),
  finishReasons: fc.record({
    include: fc.boolean(),
    useValid: fc.boolean(),
    validValue: validFinishReasonsArb,
    invalidValue: invalidFinishReasonsArb,
  }),
  systemInstructions: fc.record({
    include: fc.boolean(),
    entries: fc.array(
      fc.oneof(validSystemInstructionEntryArb, invalidSystemInstructionEntryArb),
      { minLength: 0, maxLength: 5 },
    ),
  }),
});

/**
 * Build an attributes object and the expected field set from the generated data.
 */
function buildAttributesAndExpected(gen: typeof metadataAttributesArb extends fc.Arbitrary<infer T> ? T : never) {
  const attrs: Record<string, unknown> = {};
  const expectedFields: Record<string, unknown> = {};

  // Number fields
  for (const entry of gen.numberFieldEntries) {
    if (!entry.include) continue;
    if (entry.useValid) {
      attrs[entry.field] = entry.validValue;
      expectedFields[entry.field] = entry.validValue;
    } else {
      attrs[entry.field] = entry.invalidValue;
    }
  }

  // String fields
  for (const entry of gen.stringFieldEntries) {
    if (!entry.include) continue;
    if (entry.useValid) {
      attrs[entry.field] = entry.validValue;
      expectedFields[entry.field] = entry.validValue;
    } else {
      attrs[entry.field] = entry.invalidValue;
    }
  }

  // responseFinishReasons
  if (gen.finishReasons.include) {
    if (gen.finishReasons.useValid) {
      attrs.responseFinishReasons = gen.finishReasons.validValue;
      expectedFields.responseFinishReasons = gen.finishReasons.validValue;
    } else {
      attrs.responseFinishReasons = gen.finishReasons.invalidValue;
    }
  }

  // systemInstructions
  if (gen.systemInstructions.include && gen.systemInstructions.entries.length > 0) {
    attrs.systemInstructions = gen.systemInstructions.entries;
    // Only string text.value entries pass
    const validStrings = gen.systemInstructions.entries
      .filter((e): e is { text: { value: string } } =>
        e != null && typeof e === "object" && "text" in e &&
        e.text != null && typeof e.text === "object" && "value" in e.text &&
        typeof e.text.value === "string",
      )
      .map((e) => e.text.value);
    if (validStrings.length > 0) {
      expectedFields.systemInstructions = validStrings.join("\n\n");
    }
  }

  return { attrs, expectedFields };
}

/** Arbitrary for non-inference span names. */
const nonInferenceSpanNameArb = fc.constantFrom(
  "execute_tool",
  "invoke_agent",
  "escalate_agent",
  "complete_agent",
  "unknown",
  "custom_step",
);

// ---------------------------------------------------------------------------
// Property 7: InferenceMetadata contains exactly the valid typed fields
// ---------------------------------------------------------------------------

describe("Feature: trace-reasoning-and-latency, Property 7: InferenceMetadata contains exactly the valid typed fields", () => {
  /**
   * Validates: Requirements 3.1, 3.7
   */

  it("result contains ONLY the fields that matched their expected type", () => {
    fc.assert(
      fc.property(metadataAttributesArb, (gen) => {
        const { attrs, expectedFields } = buildAttributesAndExpected(gen);
        const result = extractInferenceMetadata(attrs as Parameters<typeof extractInferenceMetadata>[0]);

        const expectedFieldCount = Object.keys(expectedFields).length;

        if (expectedFieldCount === 0) {
          // When zero fields match → result is undefined
          expect(result).toBeUndefined();
        } else {
          expect(result).toBeDefined();
          // Result contains exactly the expected fields
          for (const [key, value] of Object.entries(expectedFields)) {
            expect((result as Record<string, unknown>)[key]).toEqual(value);
          }
          // Result does NOT contain any extra fields beyond expected
          const resultKeys = Object.keys(result!).filter(
            (k) => (result as Record<string, unknown>)[k] !== undefined,
          );
          expect(resultKeys.sort()).toEqual(Object.keys(expectedFields).sort());
        }
      }),
      { numRuns: 200 },
    );
  });

  it("when zero fields match → result is undefined (not empty object)", () => {
    fc.assert(
      fc.property(
        fc.record({
          // All number fields present but with wrong types
          usageInputTokens: invalidNumberArb,
          usageOutputTokens: invalidNumberArb,
          requestModel: invalidStringArb,
        }),
        (attrs) => {
          const result = extractInferenceMetadata(attrs as Parameters<typeof extractInferenceMetadata>[0]);
          // Could still be undefined or defined depending on what invalidArb produces
          // The key property: if result is defined, it must have at least one valid field
          if (result !== undefined) {
            const keys = Object.keys(result).filter(
              (k) => (result as Record<string, unknown>)[k] !== undefined,
            );
            expect(keys.length).toBeGreaterThan(0);
          }
        },
      ),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 8: systemInstructions join preserves content
// ---------------------------------------------------------------------------

describe("Feature: trace-reasoning-and-latency, Property 8: systemInstructions join preserves content", () => {
  /**
   * Validates: Requirements 3.2, 3.6
   */

  /** Arbitrary for arrays mixing valid and invalid systemInstructions entries. */
  const mixedSystemInstructionsArb = fc.array(
    fc.oneof(
      // Valid entry: text.value is a string
      fc.string({ minLength: 0, maxLength: 300 }).map((s) => ({
        valid: true as const,
        entry: { text: { value: s } },
        value: s,
      })),
      // Invalid: missing text
      fc.constant({ valid: false as const, entry: {}, value: undefined }),
      // Invalid: text without value
      fc.constant({ valid: false as const, entry: { text: {} }, value: undefined }),
      // Invalid: text.value is a number
      fc.integer().map((n) => ({
        valid: false as const,
        entry: { text: { value: n } },
        value: undefined,
      })),
      // Invalid: text.value is null
      fc.constant({ valid: false as const, entry: { text: { value: null } }, value: undefined }),
      // Invalid: text.value is boolean
      fc.boolean().map((b) => ({
        valid: false as const,
        entry: { text: { value: b } },
        value: undefined,
      })),
      // Invalid: entry is null
      fc.constant({ valid: false as const, entry: null, value: undefined }),
    ),
    { minLength: 1, maxLength: 10 },
  );

  it("systemInstructions equals valid strings joined with '\\n\\n' (byte-for-byte)", () => {
    fc.assert(
      fc.property(mixedSystemInstructionsArb, (entries) => {
        const rawEntries = entries.map((e) => e.entry);
        const validStrings = entries
          .filter((e) => e.valid)
          .map((e) => e.value as string);

        const attrs = { systemInstructions: rawEntries } as Parameters<typeof extractInferenceMetadata>[0];
        const result = extractInferenceMetadata(attrs);

        if (validStrings.length === 0) {
          // When filtered list is empty → field should be undefined (not empty string)
          if (result !== undefined) {
            expect(result.systemInstructions).toBeUndefined();
          }
        } else {
          const expected = validStrings.join("\n\n");
          expect(result).toBeDefined();
          expect(result!.systemInstructions).toBe(expected);
        }
      }),
      { numRuns: 200 },
    );
  });

  it("preserves content byte-for-byte: no trim, no normalization", () => {
    fc.assert(
      fc.property(
        fc.array(
          fc.string({ minLength: 1, maxLength: 200 }),
          { minLength: 1, maxLength: 5 },
        ),
        (strings) => {
          // All valid entries — test that content is preserved exactly
          const entries = strings.map((s) => ({ text: { value: s } }));
          const attrs = { systemInstructions: entries } as Parameters<typeof extractInferenceMetadata>[0];
          const result = extractInferenceMetadata(attrs);

          expect(result).toBeDefined();
          expect(result!.systemInstructions).toBe(strings.join("\n\n"));

          // Verify no trimming occurred
          for (const s of strings) {
            expect(result!.systemInstructions!).toContain(s);
          }
        },
      ),
      { numRuns: 200 },
    );
  });

  it("when all entries are invalid → systemInstructions field is undefined", () => {
    fc.assert(
      fc.property(
        fc.array(invalidSystemInstructionEntryArb, { minLength: 1, maxLength: 5 }),
        (entries) => {
          const attrs = { systemInstructions: entries } as Parameters<typeof extractInferenceMetadata>[0];
          const result = extractInferenceMetadata(attrs);

          // Either result is undefined (no fields at all) or systemInstructions is absent
          if (result !== undefined) {
            expect(result.systemInstructions).toBeUndefined();
          }
        },
      ),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 9: inferenceMetadata absent on non-inference steps
// ---------------------------------------------------------------------------

describe("Feature: trace-reasoning-and-latency, Property 9: inferenceMetadata absent on non-inference steps", () => {
  /**
   * Validates: Requirements 3.4
   */

  /** Build a span with the given spanName and some valid metadata attributes. */
  const nonInferenceSpanWithMetadataArb = fc.record({
    spanName: nonInferenceSpanNameArb,
    startTimestamp: fc.constant("2025-01-15T10:30:00.000Z"),
    endTimestamp: fc.constant("2025-01-15T10:30:01.000Z"),
    attributes: fc.record({
      usageInputTokens: fc.constant(500),
      usageOutputTokens: fc.constant(100),
      requestModel: fc.constant("us.anthropic.claude-haiku-4-5-20251001-v1:0"),
      temperature: fc.constant(0),
      inputMessages: fc.constant([{ values: [{ toolUse: { name: "someTool", arguments: "{}" } }] }]),
      outputMessages: fc.constant([{ values: [{ toolResult: { values: [{ text: { value: '{"status":"success"}' } }] } }] }]),
    }),
  });

  it("every step whose type !== 'inference' has inferenceMetadata === undefined", () => {
    fc.assert(
      fc.property(
        fc.array(nonInferenceSpanWithMetadataArb, { minLength: 1, maxLength: 10 }),
        (spans) => {
          const trace = parseSpansToTrace("test-session", spans as RawSpan[]);

          for (const step of trace.steps) {
            if (step.type !== "inference") {
              expect(step.inferenceMetadata).toBeUndefined();
            }
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("non-inference span names never produce inferenceMetadata even with valid metadata attributes", () => {
    fc.assert(
      fc.property(
        nonInferenceSpanNameArb,
        validNumberArb,
        validStringArb,
        (spanName, tokenCount, model) => {
          const span: RawSpan = {
            spanName,
            startTimestamp: "2025-01-15T10:30:00.000Z",
            endTimestamp: "2025-01-15T10:30:01.500Z",
            attributes: {
              usageInputTokens: tokenCount,
              usageOutputTokens: tokenCount,
              usageTotalTokens: tokenCount * 2,
              requestModel: model,
              temperature: 0.7,
              inputMessages: spanName === "execute_tool"
                ? [{ values: [{ toolUse: { name: "testTool", arguments: "{}" } }] }]
                : [],
              outputMessages: spanName === "execute_tool"
                ? [{ values: [{ toolResult: { values: [{ text: { value: '{"status":"success"}' } }] } }] }]
                : [],
            },
          };

          const trace = parseSpansToTrace("test-session", [span]);

          for (const step of trace.steps) {
            if (step.type !== "inference") {
              expect(step.inferenceMetadata).toBeUndefined();
            }
          }
        },
      ),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Shared Arbitraries for Properties 5–6
// ---------------------------------------------------------------------------

/** Arbitrary for a valid ISO 8601 timestamp within a reasonable range. */
const validTimestampArb = fc
  .date({
    min: new Date("2020-01-01T00:00:00Z"),
    max: new Date("2030-12-31T23:59:59Z"),
  })
  .map((d) => d.toISOString());

/** Arbitrary for an invalid/unparseable timestamp. */
const invalidTimestampArb: fc.Arbitrary<string | undefined | null> = fc.oneof(
  fc.constant(undefined as string | undefined | null),
  fc.constant(null as string | undefined | null),
  fc.constant("" as string | undefined | null),
  fc.constant("not-a-date" as string | undefined | null),
  fc.constant("2025-13-45T99:99:99Z" as string | undefined | null),
  // Filter out random strings that JavaScript's Date.parse() can interpret as valid dates
  fc.stringOf(fc.char(), { minLength: 1, maxLength: 20 })
    .filter((s) => Number.isNaN(Date.parse(s)))
    .map((s) => s as string | undefined | null),
);

/** Arbitrary for a timestamp that may be valid or invalid. */
const maybeTimestampArb: fc.Arbitrary<string | undefined | null> = fc.oneof(
  validTimestampArb.map((v) => v as string | undefined | null),
  invalidTimestampArb,
);

/** Arbitrary for a non-empty tool name. */
const toolNameArb = fc.string({ minLength: 1, maxLength: 30 });

// ---------------------------------------------------------------------------
// Feature: trace-reasoning-and-latency, Property 5: durationMs is non-negative or undefined
// ---------------------------------------------------------------------------

describe("Feature: trace-reasoning-and-latency, Property 5: durationMs is non-negative or undefined", () => {
  /**
   * Validates: Requirements 2.1, 2.7
   */

  it("computeDurationMs returns non-negative integer when both timestamps are valid", () => {
    fc.assert(
      fc.property(validTimestampArb, validTimestampArb, (start, end) => {
        const result = computeDurationMs(start, end, "test");
        expect(result).toBeDefined();
        expect(typeof result).toBe("number");
        expect(result).toBeGreaterThanOrEqual(0);
        expect(Number.isInteger(result)).toBe(true);

        // Verify exact formula: Math.round(Math.max(0, end - start))
        const expected = Math.round(
          Math.max(0, Date.parse(end) - Date.parse(start)),
        );
        expect(result).toBe(expected);
      }),
      { numRuns: 200 },
    );
  });

  it("computeDurationMs returns undefined when either timestamp is missing or unparseable", () => {
    fc.assert(
      fc.property(
        fc.oneof(
          // start invalid, end valid
          fc.tuple(invalidTimestampArb, validTimestampArb.map((v) => v as string | undefined | null)),
          // start valid, end invalid
          fc.tuple(
            validTimestampArb.map((v) => v as string | undefined | null),
            invalidTimestampArb,
          ),
          // both invalid
          fc.tuple(invalidTimestampArb, invalidTimestampArb),
        ),
        ([start, end]) => {
          const result = computeDurationMs(start, end, "test");
          expect(result).toBeUndefined();
        },
      ),
      { numRuns: 200 },
    );
  });

  it("computeDurationMs never throws regardless of input", () => {
    fc.assert(
      fc.property(
        maybeTimestampArb,
        maybeTimestampArb,
        (start, end) => {
          expect(() =>
            computeDurationMs(start, end, "test"),
          ).not.toThrow();
        },
      ),
      { numRuns: 200 },
    );
  });

  it("result is always either undefined or a non-negative integer for any input pair", () => {
    fc.assert(
      fc.property(
        maybeTimestampArb,
        maybeTimestampArb,
        (start, end) => {
          const result = computeDurationMs(start, end, "test");
          if (result !== undefined) {
            expect(typeof result).toBe("number");
            expect(result).toBeGreaterThanOrEqual(0);
            expect(Number.isInteger(result)).toBe(true);
          }
        },
      ),
      { numRuns: 200 },
    );
  });
});

// ---------------------------------------------------------------------------
// Feature: trace-reasoning-and-latency, Property 6: Synthetic steps have undefined durationMs
// ---------------------------------------------------------------------------

describe("Feature: trace-reasoning-and-latency, Property 6: Synthetic steps have undefined durationMs", () => {
  /**
   * Validates: Requirements 2.5, 2.6
   */

  it("inference_tool_use steps always have durationMs === undefined", () => {
    fc.assert(
      fc.property(
        toolNameArb,
        validTimestampArb,
        validTimestampArb,
        (toolName, startTs, endTs) => {
          // Build an inference span with a toolUse in outputMessages that
          // will produce a synthetic inference_tool_use step.
          // The tool must NOT appear on a separate execute_tool span so it
          // won't be deduplicated.
          const inferenceSpan: RawSpan = {
            spanName: "inference",
            startTimestamp: startTs,
            endTimestamp: endTs,
            attributes: {
              outputMessages: [
                {
                  values: [
                    {
                      toolUse: { name: toolName, arguments: {} },
                    },
                  ],
                },
              ],
            },
          };

          const trace = parseSpansToTrace("test-session", [inferenceSpan]);

          // Find all inference_tool_use steps
          const syntheticSteps = trace.steps.filter(
            (s) => s.spanName === "inference_tool_use",
          );
          expect(syntheticSteps.length).toBeGreaterThan(0);

          for (const step of syntheticSteps) {
            expect(step.durationMs).toBeUndefined();
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("synthetic_control_tool steps always have durationMs === undefined", () => {
    fc.assert(
      fc.property(
        toolNameArb,
        validTimestampArb,
        (toolName, timestamp) => {
          // Use augmentTraceWithControlTools to create synthetic_control_tool steps
          const baseTrace = {
            sessionId: "test-session",
            steps: [
              {
                index: 0,
                type: "inference" as const,
                spanName: "inference",
                timestamp,
              },
            ],
            toolSequence: [] as string[],
            capturedAt: new Date().toISOString(),
          };

          const augmented = augmentTraceWithControlTools(baseTrace, [toolName]);

          const syntheticSteps = augmented.steps.filter(
            (s) => s.spanName === "synthetic_control_tool",
          );
          expect(syntheticSteps.length).toBeGreaterThan(0);

          for (const step of syntheticSteps) {
            expect(step.durationMs).toBeUndefined();
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("real (non-synthetic) steps may have defined durationMs when timestamps are valid", () => {
    fc.assert(
      fc.property(
        validTimestampArb,
        validTimestampArb,
        (startTs, endTs) => {
          const inferenceSpan: RawSpan = {
            spanName: "inference",
            startTimestamp: startTs,
            endTimestamp: endTs,
            attributes: {
              outputMessages: [
                {
                  values: [{ text: { value: "Hello" } }],
                },
              ],
            },
          };

          const trace = parseSpansToTrace("test-session", [inferenceSpan]);

          // The inference step (non-synthetic) should have a defined durationMs
          const inferenceStep = trace.steps.find(
            (s) => s.spanName === "inference",
          );
          expect(inferenceStep).toBeDefined();
          expect(inferenceStep!.durationMs).toBeDefined();
          expect(inferenceStep!.durationMs).toBeGreaterThanOrEqual(0);
        },
      ),
      { numRuns: 100 },
    );
  });
});
