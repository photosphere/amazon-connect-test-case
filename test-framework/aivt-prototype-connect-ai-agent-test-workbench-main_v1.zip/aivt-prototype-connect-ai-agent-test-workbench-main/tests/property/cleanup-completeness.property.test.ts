// Feature: implement-recommendations, Property 5: Cleanup completeness
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import fc from "fast-check";
import { QConnectClient } from "@aws-sdk/client-qconnect";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

import {
  handler,
  _setQConnectClient,
  _setDDBDocClient,
} from "@backend/handlers/experiment-cleanup";
import type { CleanupInput } from "@backend/handlers/experiment-cleanup";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Creates a mock QConnect client that tracks which agent IDs are passed to
 * DeleteAIAgent and succeeds for all deletions.
 */
function createSucceedingQConnectClient(deletedIds: string[]): QConnectClient {
  const mockSend = async (command: unknown) => {
    const input = (command as { input?: { aiAgentId?: string } }).input;
    if (input?.aiAgentId) {
      deletedIds.push(input.aiAgentId);
    }
    return {};
  };

  return { send: mockSend } as unknown as QConnectClient;
}

/**
 * Creates a mock QConnect client that always fails on DeleteAIAgent.
 */
function createFailingQConnectClient(attemptedIds: string[]): QConnectClient {
  const mockSend = async (command: unknown) => {
    const input = (command as { input?: { aiAgentId?: string } }).input;
    if (input?.aiAgentId) {
      attemptedIds.push(input.aiAgentId);
    }
    const error = new Error("Service unavailable");
    error.name = "ServiceUnavailableException";
    throw error;
  };

  return { send: mockSend } as unknown as QConnectClient;
}

/**
 * Creates a mock DDB Document Client that succeeds on UpdateCommand.
 */
function createMockDDBDocClient(): DynamoDBDocumentClient {
  const mockSend = async () => ({});
  return { send: mockSend } as unknown as DynamoDBDocumentClient;
}

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Arbitrary agent ID (UUID-like string). */
const agentIdArb: fc.Arbitrary<string> = fc.uuid();

/** Arbitrary experiment ID. */
const experimentIdArb: fc.Arbitrary<string> = fc.uuid();

/** Arbitrary run ID. */
const runIdArb: fc.Arbitrary<string> = fc.uuid();

/** Arbitrary assistant ID. */
const assistantIdArb: fc.Arbitrary<string> = fc.uuid();

/**
 * Arbitrary array of 1, 2, or 3 unique agent IDs — matching the valid
 * temporary agent count for an experiment.
 */
const temporaryAgentIdsArb: fc.Arbitrary<string[]> = fc
  .integer({ min: 1, max: 3 })
  .chain((n) =>
    fc.uniqueArray(agentIdArb, { minLength: n, maxLength: n }),
  );

/**
 * Arbitrary CleanupInput with 1–3 temporary agent IDs.
 */
const cleanupInputArb: fc.Arbitrary<CleanupInput> = fc
  .tuple(experimentIdArb, runIdArb, temporaryAgentIdsArb, assistantIdArb)
  .map(([experimentId, runId, temporaryAgentIds, assistantId]) => ({
    experimentId,
    runId,
    temporaryAgentIds,
    assistantId,
  }));

// ---------------------------------------------------------------------------
// Environment setup / teardown
// ---------------------------------------------------------------------------

const originalEnv = { ...process.env };

beforeEach(() => {
  vi.useFakeTimers();
  process.env.TABLE_NAME = "TestTable";
  process.env.ASSISTANT_ID = "test-assistant-id";
  process.env.AWS_REGION = "us-east-1";
});

afterEach(() => {
  vi.useRealTimers();
  _setQConnectClient(null);
  _setDDBDocClient(null);
  process.env = { ...originalEnv };
});

// ---------------------------------------------------------------------------
// Property 5: Cleanup completeness
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 10.1, 18.3**
 *
 * Property 5: Cleanup completeness
 *
 * For any experiment with N Temporary_Agents (where N is 1, 2, or 3), the
 * cleanup function SHALL attempt deletion of exactly N agents. When all
 * deletions succeed, the post-cleanup state SHALL have 0 temporary agents
 * remaining. The function never attempts to delete agents that were not
 * created for this experiment, and never skips agents that were.
 */
describe("Feature: implement-recommendations, Property 5: Cleanup completeness", () => {
  it("attempts deletion of exactly N agents (where N = temporaryAgentIds.length)", async () => {
    await fc.assert(
      fc.asyncProperty(cleanupInputArb, async (input) => {
        const deletedIds: string[] = [];
        _setQConnectClient(createSucceedingQConnectClient(deletedIds));
        _setDDBDocClient(createMockDDBDocClient());

        await handler(input);

        // Each agent should have been attempted exactly once (succeeds first try)
        expect(deletedIds.length).toBe(input.temporaryAgentIds.length);
      }),
      { numRuns: 100 },
    );
  });

  it("when all deletions succeed, deletedCount === N and failedIds is empty", async () => {
    await fc.assert(
      fc.asyncProperty(cleanupInputArb, async (input) => {
        const deletedIds: string[] = [];
        _setQConnectClient(createSucceedingQConnectClient(deletedIds));
        _setDDBDocClient(createMockDDBDocClient());

        const result = await handler(input);

        expect(result.deletedCount).toBe(input.temporaryAgentIds.length);
        expect(result.failedIds).toEqual([]);
      }),
      { numRuns: 100 },
    );
  });

  it("when all deletions succeed, cleanupStatus is 'success'", async () => {
    await fc.assert(
      fc.asyncProperty(cleanupInputArb, async (input) => {
        const deletedIds: string[] = [];
        _setQConnectClient(createSucceedingQConnectClient(deletedIds));
        _setDDBDocClient(createMockDDBDocClient());

        const result = await handler(input);

        expect(result.cleanupStatus).toBe("success");
      }),
      { numRuns: 100 },
    );
  });

  it("never attempts to delete agents outside the provided list", async () => {
    await fc.assert(
      fc.asyncProperty(cleanupInputArb, async (input) => {
        const deletedIds: string[] = [];
        _setQConnectClient(createSucceedingQConnectClient(deletedIds));
        _setDDBDocClient(createMockDDBDocClient());

        await handler(input);

        // Every ID that was attempted must be in the original list
        for (const id of deletedIds) {
          expect(input.temporaryAgentIds).toContain(id);
        }
      }),
      { numRuns: 100 },
    );
  });

  it("for any N in {1, 2, 3}, the function processes all N agents", async () => {
    // Test each value of N explicitly with many random agent IDs
    for (const n of [1, 2, 3]) {
      const nAgentIdsArb = fc.uniqueArray(agentIdArb, {
        minLength: n,
        maxLength: n,
      });

      await fc.assert(
        fc.asyncProperty(
          experimentIdArb,
          runIdArb,
          nAgentIdsArb,
          assistantIdArb,
          async (experimentId, runId, temporaryAgentIds, assistantId) => {
            const deletedIds: string[] = [];
            _setQConnectClient(createSucceedingQConnectClient(deletedIds));
            _setDDBDocClient(createMockDDBDocClient());

            const input: CleanupInput = {
              experimentId,
              runId,
              temporaryAgentIds,
              assistantId,
            };

            const result = await handler(input);

            // All N agents processed
            expect(result.deletedCount).toBe(n);
            expect(result.failedIds).toHaveLength(0);

            // The set of deleted IDs is exactly the set of input IDs
            const deletedSet = new Set(deletedIds);
            const inputSet = new Set(temporaryAgentIds);
            expect(deletedSet).toEqual(inputSet);
          },
        ),
        { numRuns: 100 },
      );
    }
  });

  it("when all deletions fail, attempts each agent exactly twice (initial + retry) and reports all as failed", async () => {
    await fc.assert(
      fc.asyncProperty(cleanupInputArb, async (input) => {
        const attemptedIds: string[] = [];
        _setQConnectClient(createFailingQConnectClient(attemptedIds));
        _setDDBDocClient(createMockDDBDocClient());

        // Run handler; advance fake timers to resolve sleep() calls
        const resultPromise = handler(input);
        // Advance timers enough to resolve all retries (1s per agent)
        await vi.runAllTimersAsync();
        const result = await resultPromise;

        // Each agent attempted twice (initial + 1 retry)
        expect(attemptedIds.length).toBe(input.temporaryAgentIds.length * 2);

        // All agents reported as failed
        expect(result.failedIds.length).toBe(input.temporaryAgentIds.length);
        expect(result.deletedCount).toBe(0);
        expect(result.cleanupStatus).toBe("partial_failure");

        // Failed IDs match input IDs exactly
        const failedSet = new Set(result.failedIds);
        const inputSet = new Set(input.temporaryAgentIds);
        expect(failedSet).toEqual(inputSet);
      }),
      { numRuns: 100 },
    );
  });
});
