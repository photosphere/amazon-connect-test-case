// Feature: rag-test-cases, Property 1: JSONL Serialization Round-Trip
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import {
  serializeRagCaseToJsonl,
  type RagCaseInput,
} from "@backend/orchestration/jsonl-serializer";
import type { RetrievedChunk } from "@shared/types";

/**
 * **Validates: Requirements 11.1, 5.1, 5.2, 5.3, 5.4, 5.7**
 *
 * Property 1: JSONL Serialization Round-Trip
 *
 * For any valid RAG case input (arbitrary question string 1..1000 chars,
 * arbitrary groundTruthAnswer 1..4000 chars, arbitrary agentResponse string,
 * and zero or more RetrievedChunks with arbitrary text content), the JSONL
 * serializer SHALL produce a single-line valid JSON object whose
 * `conversationTurns[0].prompt.content[0].text` equals the input question
 * byte-for-byte, whose `conversationTurns[0].referenceResponses[0].content[0].text`
 * equals the input groundTruthAnswer byte-for-byte, whose
 * `conversationTurns[0].output.text` equals the input agentResponse byte-for-byte,
 * and whose `conversationTurns[0].output.retrievedPassages.retrievalResults[i].content.text`
 * equals the i-th chunk's text byte-for-byte.
 */

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Generates arbitrary text content that exercises JSON escaping edge cases. */
const arbitraryText: fc.Arbitrary<string> = fc.oneof(
  fc.string({ minLength: 1, maxLength: 200 }),
  fc.fullUnicodeString({ minLength: 1, maxLength: 200 }),
  fc.constant("line1\nline2\nline3"),
  fc.constant('"quoted" and \\backslash'),
  fc.constant("\ttab\r\nCRLF"),
  fc.constant("emoji: 🎉🔥 and null char: \u0000"),
);

/** Question: 1..1000 chars. */
const questionArb: fc.Arbitrary<string> = fc.oneof(
  fc.string({ minLength: 1, maxLength: 1000 }),
  fc.fullUnicodeString({ minLength: 1, maxLength: 500 }),
);

/** Ground truth answer: 1..4000 chars. */
const groundTruthAnswerArb: fc.Arbitrary<string> = fc.oneof(
  fc.string({ minLength: 1, maxLength: 4000 }),
  fc.fullUnicodeString({ minLength: 1, maxLength: 2000 }),
);

/** Agent response: arbitrary string. */
const agentResponseArb: fc.Arbitrary<string> = fc.oneof(
  fc.string({ maxLength: 500 }),
  fc.fullUnicodeString({ maxLength: 500 }),
  fc.constant(""),
);

/** A single RetrievedChunk with arbitrary text. */
const retrievedChunkArb: fc.Arbitrary<RetrievedChunk> = fc.record({
  text: arbitraryText,
  knowledgeBaseId: fc.option(fc.string({ minLength: 1, maxLength: 50 }), {
    nil: undefined,
  }),
  contentId: fc.option(fc.string({ minLength: 1, maxLength: 50 }), {
    nil: undefined,
  }),
  title: fc.option(fc.string({ minLength: 1, maxLength: 100 }), {
    nil: undefined,
  }),
  index: fc.nat({ max: 100 }),
});

/** 0..10 chunks. */
const retrievedChunksArb: fc.Arbitrary<RetrievedChunk[]> = fc.array(
  retrievedChunkArb,
  { minLength: 0, maxLength: 10 },
);

/** Optional knowledgeBaseId override. */
const knowledgeBaseIdArb: fc.Arbitrary<string | undefined> = fc.option(
  fc.string({ minLength: 1, maxLength: 50 }),
  { nil: undefined },
);

/** Model identifier. */
const modelIdentifierArb: fc.Arbitrary<string> = fc.string({
  minLength: 1,
  maxLength: 80,
});

/** Full RagCaseInput generator. */
const ragCaseInputArb: fc.Arbitrary<RagCaseInput> = fc.record({
  question: questionArb,
  groundTruthAnswer: groundTruthAnswerArb,
  agentResponse: agentResponseArb,
  retrievedChunks: retrievedChunksArb,
  knowledgeBaseId: knowledgeBaseIdArb,
  modelIdentifier: modelIdentifierArb,
});

// ---------------------------------------------------------------------------
// Property test
// ---------------------------------------------------------------------------

describe("Property 1: JSONL Serialization Round-Trip", () => {
  it("produces single-line valid JSON preserving all text fields byte-for-byte", () => {
    fc.assert(
      fc.property(ragCaseInputArb, (input) => {
        const jsonlLine = serializeRagCaseToJsonl(input);

        // Must be a single line (no embedded newlines outside JSON string escaping)
        // JSON.stringify handles escaping, so the output string itself has no raw newlines
        expect(jsonlLine).not.toMatch(/\n/);

        // Must be valid JSON
        const parsed = JSON.parse(jsonlLine);

        // Structural shape assertions
        const turn = parsed.conversationTurns[0];
        expect(turn).toBeDefined();

        // R5.2: prompt.content[0].text === input.question byte-for-byte
        expect(turn.prompt.content[0].text).toBe(input.question);

        // R5.3: referenceResponses[0].content[0].text === input.groundTruthAnswer byte-for-byte
        expect(turn.referenceResponses[0].content[0].text).toBe(
          input.groundTruthAnswer,
        );

        // R5.4: output.text === input.agentResponse byte-for-byte
        expect(turn.output.text).toBe(input.agentResponse);

        // R5.7: retrievalResults[i].content.text === input.retrievedChunks[i].text byte-for-byte
        const retrievalResults =
          turn.output.retrievedPassages.retrievalResults;
        expect(retrievalResults).toHaveLength(input.retrievedChunks.length);

        for (let i = 0; i < input.retrievedChunks.length; i++) {
          expect(retrievalResults[i].content.text).toBe(
            input.retrievedChunks[i].text,
          );
        }
      }),
      { numRuns: 100 },
    );
  });
});
