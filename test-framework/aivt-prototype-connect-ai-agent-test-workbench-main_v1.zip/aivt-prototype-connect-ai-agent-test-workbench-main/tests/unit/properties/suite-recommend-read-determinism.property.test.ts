// Feature: actionable-recommendations, Property 4: Persisted-read determinism
import { describe, it, expect, afterEach, vi } from "vitest";
import fc from "fast-check";
import { GetCommand } from "@aws-sdk/lib-dynamodb";

import {
  handler,
  _setBedrockClient,
  _setDDBDocClient,
  type SuiteRecommendResponse,
} from "@backend/handlers/suite-recommend";
import type { PerSuiteRecommendation, ToolSurface } from "@shared/types";

/**
 * **Validates: Requirements 9.3, 15.4**
 *
 * Property 4: Persisted-read determinism
 *
 * For any persisted per-suite analysis at
 * `PK=RUN#{runId}, SK=ANALYSIS#SUITE`, repeated reads (handler
 * invocations without `force`) return the recommendations array
 * verbatim — same length, same element order, same every field of
 * every element. The read path MUST NOT invoke Bedrock and MUST NOT
 * reorder, deduplicate, or otherwise modify the persisted array.
 *
 * Implementation: the handler exposes two test seams,
 * `_setBedrockClient` and `_setDDBDocClient`. The test injects a
 * duck-typed DDB mock that returns a fixed persisted item for
 * `SK=ANALYSIS#SUITE`, calls the handler twice, and asserts both
 * responses are element-wise equal to the input and to each other.
 * The Bedrock mock asserts zero invocations across both reads.
 */

// ---------------------------------------------------------------------------
// Test constants
// ---------------------------------------------------------------------------

const RUN_ID = "run-determinism-test";
const PK_RUN = `RUN#${RUN_ID}`;

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** All four valid {@link ToolSurface} values. */
const toolSurfaceArb: fc.Arbitrary<ToolSurface> = fc.constantFrom(
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
);

/** Non-empty string for `targetName` and IDs (no all-whitespace strings). */
const nonEmptyStringArb = fc
  .string({ minLength: 1, maxLength: 40 })
  .filter((s) => s.trim().length > 0);

/**
 * Generate a {@link PerSuiteRecommendation} that satisfies the
 * persistence invariants the suite-recommend Lambda enforces (R13.3):
 * valid `targetField`, non-empty `targetName`, at least one of
 * `currentText` or `suggestedText` non-empty.
 */
const recommendationArb: fc.Arbitrary<PerSuiteRecommendation> = fc
  .record({
    targetField: toolSurfaceArb,
    targetName: nonEmptyStringArb,
    currentText: fc.string({ maxLength: 200 }),
    suggestedText: fc.string({ maxLength: 200 }),
    rationale: fc.string({ maxLength: 200 }),
    priority: fc.integer({ min: 1, max: 100 }),
    predictedImpact: fc.record({
      liftedCaseIds: fc.array(nonEmptyStringArb, {
        minLength: 0,
        maxLength: 10,
      }),
      rationale: fc.string({ maxLength: 200 }),
    }),
  })
  // Avoid the no-op shape (both texts empty) — this is what the Lambda
  // would have rejected before persistence per R13.3, so a "persisted"
  // record satisfying the invariants will not have it either.
  .filter(
    (r) => r.currentText.length > 0 || r.suggestedText.length > 0,
  );

/**
 * Generate a "persisted" recommendations array — length 0..30, sorted
 * by ascending priority so it satisfies the monotonic-priority contract
 * the Lambda enforces before persistence (R9.1). The property tests
 * read-path determinism, so the contents are arbitrary but well-formed.
 */
const persistedRecsArb: fc.Arbitrary<PerSuiteRecommendation[]> = fc
  .array(recommendationArb, { minLength: 0, maxLength: 30 })
  .map((arr) => [...arr].sort((a, b) => a.priority - b.priority));

/** Generate a valid ISO 8601 timestamp string. */
const isoTimestampArb = fc
  .date({ min: new Date("2020-01-01"), max: new Date("2030-12-31") })
  .map((d) => d.toISOString());

/** Limit the model id arbitrary to a small set of plausible values. */
const modelIdArb = fc.constantFrom(
  "us.anthropic.claude-sonnet-4-6",
  "us.anthropic.claude-3-5-sonnet",
  "us.anthropic.claude-3-7-sonnet",
);

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------

/** Construct an APIGateway-shaped event for the Lambda. */
function makeEvent(): {
  httpMethod: string;
  body: string | null;
  pathParameters: { runId: string };
  resource: string;
} {
  return {
    httpMethod: "POST",
    body: null,
    pathParameters: { runId: RUN_ID },
    resource: "/runs/{runId}/recommend-suite",
  };
}

interface DDBMock {
  client: { send: ReturnType<typeof vi.fn> };
  /** Number of GetCommand invocations against `SK=ANALYSIS#SUITE`. */
  readonly suiteGetCalls: number;
  /** Number of any non-GetCommand invocations (should remain 0 on the read path). */
  readonly otherCommandCalls: number;
}

/**
 * Smart DDB mock dispatcher for the read path. Only GetCommand for
 * `SK=ANALYSIS#SUITE` is expected — the persisted-read shortcut returns
 * before any QueryCommand or PutCommand fires.
 */
function makeDDBMock(persistedItem: Record<string, unknown>): DDBMock {
  let suiteGetCalls = 0;
  let otherCommandCalls = 0;

  const send = vi.fn(async (command: unknown) => {
    if (command instanceof GetCommand) {
      const sk = command.input.Key?.SK as string | undefined;
      if (sk === "ANALYSIS#SUITE") {
        suiteGetCalls += 1;
        return { Item: persistedItem };
      }
      // Any other GetCommand is unexpected on the read path.
      otherCommandCalls += 1;
      return { Item: undefined };
    }
    otherCommandCalls += 1;
    return {};
  });

  const mock: DDBMock = {
    client: { send },
    get suiteGetCalls() {
      return suiteGetCalls;
    },
    get otherCommandCalls() {
      return otherCommandCalls;
    },
  } as DDBMock;
  return mock;
}

// ---------------------------------------------------------------------------
// Cleanup
// ---------------------------------------------------------------------------

afterEach(() => {
  _setBedrockClient(null);
  _setDDBDocClient(null);
  vi.restoreAllMocks();
});

// ---------------------------------------------------------------------------
// Property 4: Persisted-read determinism
// ---------------------------------------------------------------------------

describe("Property 4: Persisted-read determinism", () => {
  it("two consecutive reads of a persisted per-suite record return the recommendations array verbatim with no reordering", async () => {
    await fc.assert(
      fc.asyncProperty(
        persistedRecsArb,
        isoTimestampArb,
        modelIdArb,
        async (persistedRecs, generatedAt, modelId) => {
          // The persisted item DDB returns. The handler's `stripKeys`
          // helper strips PK/SK before returning, so the response body
          // surfaces only the domain fields.
          const persistedItem = {
            PK: PK_RUN,
            SK: "ANALYSIS#SUITE",
            recommendations: persistedRecs,
            generatedAt,
            modelId,
          };

          const ddb = makeDDBMock(persistedItem);
          _setDDBDocClient(ddb.client as never);

          const bedrockSend = vi.fn();
          _setBedrockClient({ send: bedrockSend } as never);

          // Read 1.
          const response1 = await handler(makeEvent());
          // Read 2.
          const response2 = await handler(makeEvent());

          expect(response1.statusCode).toBe(200);
          expect(response2.statusCode).toBe(200);

          const body1 = JSON.parse(response1.body) as SuiteRecommendResponse;
          const body2 = JSON.parse(response2.body) as SuiteRecommendResponse;

          // Bedrock MUST NOT be invoked on the persisted-read path
          // (zero calls across both reads).
          expect(bedrockSend).not.toHaveBeenCalled();

          // Only the persisted-read GetCommand fires — no QueryCommand
          // for failed cases / per-case analyses, no PutCommand for
          // overwriting the suite record.
          expect(ddb.suiteGetCalls).toBe(2);
          expect(ddb.otherCommandCalls).toBe(0);

          // Both reads return the persisted array verbatim — same
          // length, same element order, same every field of every
          // element (including `priority`, `targetField`, `targetName`,
          // `currentText`, `suggestedText`, `rationale`,
          // `predictedImpact.liftedCaseIds`, and
          // `predictedImpact.rationale`).
          expect(body1.recommendations).toEqual(persistedRecs);
          expect(body2.recommendations).toEqual(persistedRecs);

          // The two reads are element-wise equal to each other —
          // determinism across repeated invocations.
          expect(body1.recommendations).toEqual(body2.recommendations);

          // The accompanying metadata fields are preserved verbatim
          // across both reads.
          expect(body1.generatedAt).toBe(generatedAt);
          expect(body2.generatedAt).toBe(generatedAt);
          expect(body1.modelId).toBe(modelId);
          expect(body2.modelId).toBe(modelId);
        },
      ),
      { numRuns: 100 },
    );
  });
});
