// Feature: implement-recommendations, Property 9: Production mode API enforcement
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import fc from "fast-check";

import { handler } from "@backend/handlers/apply-recommendations";
import type { APIGatewayEvent } from "@backend/handlers/apply-recommendations";

// ---------------------------------------------------------------------------
// Environment setup / teardown
// ---------------------------------------------------------------------------

let originalInstanceMode: string | undefined;

beforeEach(() => {
  originalInstanceMode = process.env.INSTANCE_MODE;
  process.env.INSTANCE_MODE = "production";
});

afterEach(() => {
  if (originalInstanceMode === undefined) {
    delete process.env.INSTANCE_MODE;
  } else {
    process.env.INSTANCE_MODE = originalInstanceMode;
  }
});

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Arbitrary valid agent ID (UUID-like string). */
const agentIdArb: fc.Arbitrary<string> = fc.uuid();

/** Arbitrary valid recommendation indices array (non-empty array of non-negative integers). */
const recommendationIndicesArb: fc.Arbitrary<number[]> = fc.array(
  fc.nat({ max: 99 }),
  { minLength: 1, maxLength: 20 },
);

/** Arbitrary valid request body for apply-recommendations. */
const validRequestBodyArb: fc.Arbitrary<{
  mode: "direct";
  agentId: string;
  recommendationIndices: number[];
}> = fc
  .tuple(agentIdArb, recommendationIndicesArb)
  .map(([agentId, recommendationIndices]) => ({
    mode: "direct" as const,
    agentId,
    recommendationIndices,
  }));

/** Arbitrary run ID (UUID-like string). */
const runIdArb: fc.Arbitrary<string> = fc.uuid();

/** Arbitrary tenant ID for Cognito claims. */
const tenantIdArb: fc.Arbitrary<string> = fc.uuid();

/**
 * Build a full APIGatewayEvent from request body components.
 */
function buildEvent(
  runId: string,
  tenantId: string,
  body: object,
): APIGatewayEvent {
  return {
    httpMethod: "POST",
    resource: "/runs/{runId}/apply-recommendations",
    pathParameters: { runId },
    body: JSON.stringify(body),
    requestContext: {
      authorizer: {
        claims: { sub: tenantId },
      },
    },
  };
}

// ---------------------------------------------------------------------------
// Property 9: Production mode API enforcement
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 19.3**
 *
 * Property 9: Production mode API enforcement
 * When INSTANCE_MODE === "production", all write endpoints
 * (apply-recommendations, experiment-create, experiment-apply) SHALL return
 * 403 regardless of request payload validity.
 */
describe("Feature: implement-recommendations, Property 9: Production mode API enforcement", () => {
  it("apply-recommendations handler always returns 403 with write_disabled when INSTANCE_MODE is production", async () => {
    await fc.assert(
      fc.asyncProperty(
        runIdArb,
        tenantIdArb,
        validRequestBodyArb,
        async (runId, tenantId, body) => {
          const event = buildEvent(runId, tenantId, body);
          const response = await handler(event);

          expect(response.statusCode).toBe(403);

          const parsedBody = JSON.parse(response.body);
          expect(parsedBody.error).toBe("write_disabled");
          expect(parsedBody.reason).toContain("production");
        },
      ),
      { numRuns: 100 },
    );
  });

  it("production mode check takes precedence over missing/invalid request fields", async () => {
    await fc.assert(
      fc.asyncProperty(
        runIdArb,
        tenantIdArb,
        // Generate arbitrary (possibly invalid) JSON bodies
        fc.oneof(
          fc.constant({}),
          fc.constant({ mode: "invalid_mode" }),
          fc.constant({ mode: "direct" }), // missing agentId
          fc.constant({ mode: "direct", agentId: "", recommendationIndices: [] }),
          fc.record({
            mode: fc.constant("direct"),
            agentId: fc.string({ minLength: 0, maxLength: 5 }),
            recommendationIndices: fc.constant([]),
          }),
        ),
        async (runId, tenantId, body) => {
          const event = buildEvent(runId, tenantId, body);
          const response = await handler(event);

          // Production mode always returns 403 BEFORE any validation
          expect(response.statusCode).toBe(403);

          const parsedBody = JSON.parse(response.body);
          expect(parsedBody.error).toBe("write_disabled");
        },
      ),
      { numRuns: 100 },
    );
  });

  it("production mode check takes precedence even without authentication claims", async () => {
    await fc.assert(
      fc.asyncProperty(
        runIdArb,
        validRequestBodyArb,
        async (runId, body) => {
          // Event with no authorizer claims — would normally be 401
          const event: APIGatewayEvent = {
            httpMethod: "POST",
            resource: "/runs/{runId}/apply-recommendations",
            pathParameters: { runId },
            body: JSON.stringify(body),
            requestContext: {},
          };

          const response = await handler(event);

          // 403 from production mode check, not 401 from missing auth
          expect(response.statusCode).toBe(403);

          const parsedBody = JSON.parse(response.body);
          expect(parsedBody.error).toBe("write_disabled");
        },
      ),
      { numRuns: 100 },
    );
  });
});
