import { describe, it, expect } from "vitest";
import {
  validateTestSuite,
  validateTestCase,
} from "@shared/validation";
import {
  SUITE_NAME_MAX,
  SUITE_DESCRIPTION_MAX,
  CASE_NAME_MAX,
  CASE_DESCRIPTION_MAX,
  INITIAL_UTTERANCE_MAX,
  CUSTOMER_KNOWLEDGE_MAX_PAIRS,
  CUSTOMER_KNOWLEDGE_KEY_MAX,
  CUSTOMER_KNOWLEDGE_VALUE_MAX,
  SUCCESS_CRITERIA_MAX_STEPS,
  PARAMETER_CHECKS_MAX,
} from "@shared/constants";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function validSuiteInput() {
  return { name: "My Suite", agentId: "agent-123" };
}

function validCaseInput() {
  return {
    description: "Test that the agent books a flight",
    initialUtterance: "I want to book a flight to Seattle",
    successCriteria: [{ toolName: "bookFlight", required: true }],
  };
}

// ---------------------------------------------------------------------------
// validateTestSuite
// ---------------------------------------------------------------------------

describe("validateTestSuite", () => {
  it("returns valid for a correct minimal input", () => {
    const result = validateTestSuite(validSuiteInput());
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it("returns valid when optional description is provided within limits", () => {
    const result = validateTestSuite({
      ...validSuiteInput(),
      description: "A short description",
    });
    expect(result.valid).toBe(true);
  });

  it("reports error when name is missing", () => {
    const result = validateTestSuite({ agentId: "agent-1" });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "name" })
    );
  });

  it("reports error when name is empty string", () => {
    const result = validateTestSuite({ name: "   ", agentId: "agent-1" });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "name", message: "Name is required" })
    );
  });

  it("reports error when name exceeds max length", () => {
    const result = validateTestSuite({
      name: "x".repeat(SUITE_NAME_MAX + 1),
      agentId: "agent-1",
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "name" })
    );
  });

  it("reports error when agentId is missing", () => {
    const result = validateTestSuite({ name: "Suite" });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "agentId" })
    );
  });

  it("reports error when agentId is whitespace-only", () => {
    const result = validateTestSuite({ name: "Suite", agentId: "  " });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "agentId" })
    );
  });

  it("reports error when description exceeds max length", () => {
    const result = validateTestSuite({
      ...validSuiteInput(),
      description: "d".repeat(SUITE_DESCRIPTION_MAX + 1),
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "description" })
    );
  });

  it("collects multiple errors at once", () => {
    const result = validateTestSuite({});
    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThanOrEqual(2);
    const fields = result.errors.map((e) => e.field);
    expect(fields).toContain("name");
    expect(fields).toContain("agentId");
  });
});

// ---------------------------------------------------------------------------
// validateTestCase
// ---------------------------------------------------------------------------

describe("validateTestCase", () => {
  it("returns valid for a correct minimal input", () => {
    const result = validateTestCase(validCaseInput());
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it("allows name to be omitted (optional)", () => {
    const result = validateTestCase(validCaseInput());
    expect(result.valid).toBe(true);
  });

  it("reports error when name exceeds max length", () => {
    const result = validateTestCase({
      ...validCaseInput(),
      name: "n".repeat(CASE_NAME_MAX + 1),
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "name" })
    );
  });

  it("reports error when description is missing", () => {
    const { description, ...noDesc } = validCaseInput();
    const result = validateTestCase(noDesc);
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "description" })
    );
  });

  it("reports error when description exceeds max length", () => {
    const result = validateTestCase({
      ...validCaseInput(),
      description: "d".repeat(CASE_DESCRIPTION_MAX + 1),
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "description" })
    );
  });

  it("reports error when initialUtterance is missing", () => {
    const { initialUtterance, ...noUtterance } = validCaseInput();
    const result = validateTestCase(noUtterance);
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "initialUtterance" })
    );
  });

  it("reports error when initialUtterance exceeds max length", () => {
    const result = validateTestCase({
      ...validCaseInput(),
      initialUtterance: "u".repeat(INITIAL_UTTERANCE_MAX + 1),
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "initialUtterance" })
    );
  });

  it("reports error when customerKnowledge exceeds max pairs", () => {
    const knowledge: Record<string, string> = {};
    for (let i = 0; i < CUSTOMER_KNOWLEDGE_MAX_PAIRS + 1; i++) {
      knowledge[`key${i}`] = "value";
    }
    const result = validateTestCase({
      ...validCaseInput(),
      customerKnowledge: knowledge,
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "customerKnowledge" })
    );
  });

  it("reports error when a customerKnowledge key is too long", () => {
    const result = validateTestCase({
      ...validCaseInput(),
      customerKnowledge: { ["k".repeat(CUSTOMER_KNOWLEDGE_KEY_MAX + 1)]: "val" },
    });
    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.field.startsWith("customerKnowledge."))).toBe(true);
  });

  it("reports error when a customerKnowledge value is too long", () => {
    const result = validateTestCase({
      ...validCaseInput(),
      customerKnowledge: { myKey: "v".repeat(CUSTOMER_KNOWLEDGE_VALUE_MAX + 1) },
    });
    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.field.startsWith("customerKnowledge."))).toBe(true);
  });

  it("reports error when successCriteria is empty", () => {
    const result = validateTestCase({
      ...validCaseInput(),
      successCriteria: [],
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "successCriteria" })
    );
  });

  it("reports error when successCriteria exceeds max steps", () => {
    const steps = Array.from({ length: SUCCESS_CRITERIA_MAX_STEPS + 1 }, (_, i) => ({
      toolName: `tool${i}`,
      required: true,
    }));
    const result = validateTestCase({
      ...validCaseInput(),
      successCriteria: steps,
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "successCriteria" })
    );
  });

  it("reports error when a step has empty toolName", () => {
    const result = validateTestCase({
      ...validCaseInput(),
      successCriteria: [{ toolName: "", required: true }],
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "successCriteria[0].toolName" })
    );
  });

  it("reports error when parameterChecks exceed max per step", () => {
    const checks = Array.from({ length: PARAMETER_CHECKS_MAX + 1 }, (_, i) => ({
      paramName: `p${i}`,
      expectedValue: "val",
    }));
    const result = validateTestCase({
      ...validCaseInput(),
      successCriteria: [{ toolName: "myTool", required: true, parameterChecks: checks }],
    });
    expect(result.valid).toBe(false);
    expect(result.errors).toContainEqual(
      expect.objectContaining({ field: "successCriteria[0].parameterChecks" })
    );
  });

  it("collects multiple errors at once", () => {
    const result = validateTestCase({});
    expect(result.valid).toBe(false);
    const fields = result.errors.map((e) => e.field);
    expect(fields).toContain("description");
    expect(fields).toContain("initialUtterance");
    expect(fields).toContain("successCriteria");
  });
});
