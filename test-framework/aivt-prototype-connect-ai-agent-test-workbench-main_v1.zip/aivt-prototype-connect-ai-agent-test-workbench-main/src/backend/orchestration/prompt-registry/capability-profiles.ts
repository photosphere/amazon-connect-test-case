/**
 * Model_Capability_Profile catalog and the `buildInferenceConfig` helper.
 *
 * The registry recognises three capability profiles today, mirroring
 * the Bedrock model families exposed by the platform:
 *
 *   - `anthropic_claude_4x` — strict Claude 4.x family profile
 *     (currently Claude Opus 4.8). Accepts only `maxTokens` on the
 *     Converse request and explicitly forbids `temperature`, `topP`,
 *     `topK`, and `stopSequences`. Opus 4.8 wire-rejects these keys
 *     (`temperature is deprecated for this model`) so the strict
 *     `forbids[]` is exactly what the SDK expects, and the negative
 *     conformance probe asserts that the 4xx surfaces.
 *   - `anthropic_claude_4x_lax` — lax Claude 4.x family profile
 *     (currently Claude Sonnet 4.6 and Claude Haiku 4.5). Accepts only
 *     `maxTokens` so the Prompts page UI continues to expose only
 *     `maxTokens` as a tunable knob; forbids nothing because both
 *     models silently accept and drop `temperature` / `topP` / `topK` /
 *     `stopSequences` at the wire. The empty `forbids[]` causes the
 *     conformance probe runner to skip the negative probe per its
 *     standard skip-on-empty-forbids contract — a strict `forbids[]`
 *     would be tighter than wire reality and the negative probe would
 *     report a false-positive 200-acceptance regression.
 *   - `amazon_nova` — Nova Lite / Pro. Accepts the full Converse
 *     parameter set top-level (`maxTokens`, `temperature`, `topP`,
 *     `stopSequences`) and also accepts `topK`, but only when nested
 *     under `additionalModelRequestFields.inferenceConfig.topK` per
 *     Bedrock's vendor-specific request shape (R17.4).
 *
 * Note on validator behaviour: the dry-render validator's
 * `validateCapabilityProfileCompliance` stage rejects parameters
 * outside `acceptsTopLevel ∪ acceptsAdditional`. With
 * `acceptsTopLevel = ["maxTokens"]` and the extra keys not in
 * `forbids[]`, an override that adds e.g. `temperature` is still
 * rejected — by failing the accept-list check, not the forbid-list
 * check. The Prompts UI accordingly only exposes `maxTokens` as
 * editable for both Claude profiles.
 *
 * The numeric bounds declared on each profile are the *capability* bounds
 * (what the model family will accept). Each individual prompt may declare
 * a tighter range via `PromptDefinition.inferenceParameters`; the
 * dry-render validator enforces the tighter of the two so an Anthropic
 * `maxTokens` cannot persist above the resolved model's `maxOutputTokens`
 * even though the profile's `max` is `Number.MAX_SAFE_INTEGER`.
 *
 * `buildInferenceConfig` is the wire-shape helper every Bedrock_Callsite
 * uses to turn a {@link ResolvedPrompt} into the exact `inferenceConfig` /
 * `additionalModelRequestFields` arguments accepted by `ConverseCommand`.
 * The helper's *only* job is to place accepted keys correctly:
 *
 *   - Keys listed in the resolved profile's `acceptsTopLevel` are copied to
 *     the top-level `inferenceConfig` object.
 *   - Keys listed in the resolved profile's `acceptsAdditional` are copied
 *     under `additionalModelRequestFields.inferenceConfig`.
 *   - Keys absent from both accept lists (including any key on the
 *     profile's `forbids` list) are silently dropped — the validation
 *     pipeline already rejected them at edit time, so the helper does not
 *     re-validate; it has the simpler responsibility of correct placement.
 *
 * `additionalModelRequestFields` is omitted from the return value entirely
 * when no additional keys are present, so the spread used at callsites
 * (`...(additionalModelRequestFields ? { additionalModelRequestFields } : {})`)
 * stays clean for Anthropic models.
 *
 * @module backend/orchestration/prompt-registry/capability-profiles
 */

import type { ModelCapabilityProfile, ResolvedPrompt } from "./types";

// ---------------------------------------------------------------------------
// Capability profiles
// ---------------------------------------------------------------------------

/**
 * The capability profiles every {@link SupportedModel} entry maps to.
 * Frozen at module load and keyed by the profile's stable `key` so that
 * {@link SupportedModel.capabilityProfileKey} can index this map directly.
 *
 * The shape is `Readonly<Record<ModelCapabilityProfile["key"], ModelCapabilityProfile>>`
 * which forces every key of the union (`anthropic_claude_4x`,
 * `anthropic_claude_4x_lax`, `amazon_nova`) to be present at compile
 * time — adding a fourth profile later starts as a TypeScript error
 * here, which is exactly the build-time gate we want.
 */
export const CAPABILITY_PROFILES: Readonly<
  Record<ModelCapabilityProfile["key"], ModelCapabilityProfile>
> = {
  anthropic_claude_4x: {
    key: "anthropic_claude_4x",
    acceptsTopLevel: ["maxTokens"],
    acceptsAdditional: [],
    forbids: ["temperature", "topP", "topK", "stopSequences"],
    numericRanges: {
      maxTokens: { min: 1, max: Number.MAX_SAFE_INTEGER },
    },
  },
  anthropic_claude_4x_lax: {
    key: "anthropic_claude_4x_lax",
    acceptsTopLevel: ["maxTokens"],
    acceptsAdditional: [],
    // Empty by design: Sonnet 4.6 and Haiku 4.5 silently accept (and
    // drop) `temperature`/`topP`/`topK`/`stopSequences` on the wire, so
    // a strict forbid would be tighter than reality and the negative
    // conformance probe would falsely report a 200-acceptance
    // regression. See module header for the full rationale.
    forbids: [],
    numericRanges: {
      maxTokens: { min: 1, max: Number.MAX_SAFE_INTEGER },
    },
  },
  amazon_nova: {
    key: "amazon_nova",
    acceptsTopLevel: ["maxTokens", "temperature", "topP", "stopSequences"],
    acceptsAdditional: ["topK"],
    forbids: [],
    numericRanges: {
      maxTokens: { min: 1, max: Number.MAX_SAFE_INTEGER },
      temperature: { min: 0.0, max: 1.0 },
      topP: { min: 0.0, max: 1.0 },
      topK: { min: 1, max: 500 },
    },
  },
} as const;

// ---------------------------------------------------------------------------
// Wire-shape helper
// ---------------------------------------------------------------------------

/**
 * Shape of the Converse arguments the helper produces. `inferenceConfig` is
 * always present (possibly empty if the resolved prompt carried no
 * top-level-accepted keys); `additionalModelRequestFields` is present only
 * when at least one additional-accepted key was carried.
 */
export interface BuiltInferenceConfig {
  inferenceConfig: Record<string, unknown>;
  additionalModelRequestFields?: { inferenceConfig: Record<string, unknown> };
}

/**
 * Place the resolved prompt's `inferenceParameters` into the exact request
 * shape `ConverseCommand` expects for the resolved model's capability
 * profile. See the module header for the full placement contract.
 *
 * For an `anthropic_claude_4x`-profile prompt this returns
 * `{ inferenceConfig: { maxTokens } }` — never anything else, even if the
 * override carried legacy `temperature`/`topP`/`topK`/`stopSequences`
 * values from before a model migration; those keys are forbidden by the
 * profile and silently dropped here.
 *
 * For an `amazon_nova`-profile prompt this returns
 * `{ inferenceConfig: { maxTokens, temperature?, topP?, stopSequences? },
 * additionalModelRequestFields: { inferenceConfig: { topK } } }` with
 * every optional key emitted only when it appears in
 * `inferenceParameters`. The `topK` key is always nested under
 * `additionalModelRequestFields.inferenceConfig.topK` and never bubbled to
 * the top-level inference config (R17.4).
 */
export function buildInferenceConfig(
  prompt: ResolvedPrompt,
): BuiltInferenceConfig {
  const { capabilityProfile, inferenceParameters } = prompt;

  const inferenceConfig: Record<string, unknown> = {};
  for (const key of capabilityProfile.acceptsTopLevel) {
    if (Object.prototype.hasOwnProperty.call(inferenceParameters, key)) {
      inferenceConfig[key] = inferenceParameters[key];
    }
  }

  const additionalInferenceConfig: Record<string, unknown> = {};
  for (const key of capabilityProfile.acceptsAdditional) {
    if (Object.prototype.hasOwnProperty.call(inferenceParameters, key)) {
      additionalInferenceConfig[key] = inferenceParameters[key];
    }
  }

  if (Object.keys(additionalInferenceConfig).length === 0) {
    return { inferenceConfig };
  }

  return {
    inferenceConfig,
    additionalModelRequestFields: { inferenceConfig: additionalInferenceConfig },
  };
}
