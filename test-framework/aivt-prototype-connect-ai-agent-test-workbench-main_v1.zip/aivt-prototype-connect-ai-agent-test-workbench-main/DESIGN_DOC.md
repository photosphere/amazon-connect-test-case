# Connect AI Agent Test Framework — Design Document

## What We Built (Prototype)

A Python test harness that measures Q in Connect AI Agent tool-selection accuracy as tool count scales. The prototype proves that 50 return-to-control tools maintain 96%+ accuracy with no meaningful latency degradation.

### Key Findings

| Metric | 10 tools | 30 tools | 50 tools |
|--------|----------|----------|----------|
| Accuracy | 100% | 98% | 96% |
| Single-turn latency | 3.4s | 3.4s | 3.4s |
| Multi-turn avg | 10.1s | — | 12.9s |

- Tool count does NOT increase per-turn latency
- All "failures" at 50 tools were the agent choosing a logical prerequisite step (e.g., SetupBillPay before PayBillOneTime)
- Multi-turn conversations with a Bedrock-simulated customer work reliably

### Architecture (Current Prototype)

```
┌─────────────────────────────────────────────────────────┐
│  run_test.py (ThreadPoolExecutor, 9 concurrent)          │
│                                                          │
│  For each test utterance:                                │
│  ┌────────────────────────────────────────────────────┐ │
│  │ 1. CreateSession (Q in Connect)                     │ │
│  │ 2. SendMessage(aiAgentId=..., text=utterance)       │ │
│  │ 3. Poll GetNextMessage until tool or text response  │ │
│  │ 4. If text (clarifying question):                   │ │
│  │    → customer_simulator.py (Bedrock Haiku)          │ │
│  │    → SendMessage(text=simulated_response)           │ │
│  │    → Repeat from step 3 (up to 10 turns)            │ │
│  │ 5. Extract Tool from conversationSessionData        │ │
│  │ 6. Compare actual vs expected tool                  │ │
│  └────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

### Key Technical Discoveries

1. **Agent override**: Use `aiAgentId` parameter on `SendMessage` — NOT on `CreateSession`. The session-level agent config hits the default SelfService agent with the QUESTION tool.

2. **Filler responses**: The agent returns `"..."` with status READY while still processing internally. This is a "hold please" message for voice. Keep polling with the nextMessageToken until you get either a tool selection or substantive text.

3. **Tool extraction**: Tool name is in `conversationSessionData` under key `"Tool"` (not in `requestedToolInvocation` which doesn't exist in this API path).

4. **Prompt handling**: The system prompt (`SelfServiceOrchestrationVoice`) auto-injects `{{$.toolConfigurationList}}`. You don't need to create/modify prompts when changing tools — just update the agent's `toolConfigurations`.

5. **connectInstanceArn on agent**: If present, the service injects a `QUESTION` retrieval tool that catches everything. Avoid using system default prompts on agents with KB associations, or use custom prompts that deprioritize QUESTION.

6. **Parallel execution**: Each utterance is an independent session. 9 concurrent sessions stayed under the 10 TPS limit with exponential backoff handling the occasional throttle.

---

### Issues Resolved (Chronological)

These are the problems we hit during development, in order. Each one cost significant debugging time. Any new project should encode these as known constraints from day one.

#### Issue 1: CreateSession `name` parameter is required

**Symptom**: `ParamValidationError: Missing required parameter in input: "name"`

**Cause**: The `qconnect.create_session()` API requires a `name` parameter (a human-readable session name). The boto3 docs don't make this obvious.

**Fix**: Pass `name=f"test-{uuid.uuid4().hex[:8]}"` on every CreateSession call.

---

#### Issue 2: CreateSession response shape — `sessionId` is nested

**Symptom**: `KeyError: 'sessionId'` when accessing `resp["sessionId"]`

**Cause**: The session ID is nested under `resp["session"]["sessionId"]`, not at the top level.

**Fix**: `session_id = resp["session"]["sessionId"]`

---

#### Issue 3: Agent type mismatch — ORCHESTRATION vs SELF_SERVICE

**Symptom**: All test utterances returned `Tool: QUESTION` regardless of configured tools.

**Cause**: When you pass `aiAgentConfiguration={"ORCHESTRATION": {"aiAgentId": ...}}` on `CreateSession`, the service still routes through its default SELF_SERVICE agent (`529207fe`). The SELF_SERVICE layer has a built-in `QUESTION` tool that catches everything.

**Investigation**: ListSpans API showed `aiAgentId: 529207fe` (the system SELF_SERVICE agent), not our orchestration agent.

**Fix**: Do NOT specify agent on CreateSession. Instead, pass `aiAgentId=<your_agent_id>` directly on each `SendMessage` call. This overrides the default routing at the message level.

```python
# WRONG — hits the default SelfService agent
client.create_session(
    assistantId=ASSISTANT_ID,
    aiAgentConfiguration={"ORCHESTRATION": {"aiAgentId": AI_AGENT_ID}},
)

# RIGHT — override at message level
client.send_message(
    assistantId=ASSISTANT_ID,
    sessionId=session_id,
    aiAgentId=AI_AGENT_ID,  # <-- This is the key
    type="TEXT",
    message={"value": {"text": {"value": text}}},
)
```

---

#### Issue 4: The QUESTION tool is injected by the service, not from toolConfigurations

**Symptom**: Agent always selects `QUESTION` even when we configured 10 custom tools and removed any QUESTION tool from the config.

**Cause**: When an agent has `connectInstanceArn` set (which links to the Connect instance's knowledge base), the system automatically injects a `QUESTION` retrieval tool into the prompt. This tool is a catch-all — its description matches any customer query. It's NOT in your `toolConfigurations` list.

**What didn't work**:
- Removing QUESTION from toolConfigurations (it was never there)
- Using the system default prompt `SelfServiceOrchestrationVoice`
- Using `SelfServiceOrchestrationChat`
- Creating a custom prompt that says "don't use QUESTION"
- Omitting `connectInstanceArn` from the update call (API preserves it)

**Fix**: The `aiAgentId` override on `SendMessage` (Issue 3) resolved this. When you specify the agent at the message level, it routes directly to your orchestration agent's tool selection logic, bypassing the SELF_SERVICE layer that injects QUESTION.

---

#### Issue 5: Tool configuration shape differs by agent type

**Symptom**: `Parameter validation failed: Unknown parameter "customToolConfiguration"`

**Cause**: The design spec assumed tools needed a wrapper (`customToolConfiguration`, `toolUseConfirmationConfiguration`, `type: "RETURN_CONTROL"`). In reality, ORCHESTRATION-type agents use a flat tool structure matching `tools.json` directly: `toolName`, `toolType`, `description`, `instruction`, `inputSchema`, `userInteractionConfiguration`.

**Investigation**: Dumped `.original_agent_config.json` and compared the actual tool shape on the live agent.

**Fix**: Pass tools directly from `tools.json` without any transformation:
```python
def build_tool_configurations(tools):
    return tools  # No wrapping needed
```

---

#### Issue 6: Prompt creation requires specific YAML format

**Symptom**: `ValidationException: Prompt is not in expected YAML format`

**Cause**: AI Prompts must be valid YAML with at minimum a `system:` key (block scalar) and a `messages:` array. The messages array must contain `"{{$.conversationHistory}}"` and `{"role": "assistant", "content": "<message>"}`.

**Fix**: Not relevant for the final design — we don't modify prompts. The system prompt auto-injects the tool list. But if you DO need a custom prompt:
```yaml
system: |
  Your system prompt text here...
  {{$.toolConfigurationList}}
messages:
  - "{{$.conversationHistory}}"
  - role: assistant
    content: "<message>"
```

---

#### Issue 7: Agent returns filler text `"..."` as intermediate response

**Symptom**: Polling loop received status=READY with `text="..."` and no tool. The code treated this as "agent asked a clarifying question" and triggered the customer simulator. The simulator responded to `"..."` with "Hello? Are you there?" which degraded accuracy.

**Cause**: On a voice channel, `"..."` is a TTS placeholder — "hold on, I'm working on it." The orchestration loop fires this as an intermediate response while the agent reasons internally. The status is READY because from the API's perspective, a message was delivered. But more messages are coming on the same token.

**Fix**: After receiving a READY response, check if the nextMessageToken advanced. If it did, keep polling — there's more content. If it didn't and you have substantive text, the turn is complete. If the text is just `"..."`, treat it as "agent needs more time" and keep polling on the same token.

The current implementation: if no tool is extracted and text is present, return the text as the agent's response for multi-turn handling. If no tool and no substantive text, continue polling.

---

#### Issue 8: Bedrock Converse API role semantics for customer simulation

**Symptom**: Bedrock returned empty `content: []` when we tried to simulate the customer.

**Cause**: The Converse API always generates `assistant` role responses. We initially passed `assistant` (agent messages) → `user` (expecting model to respond as customer). But the model needs the conversation framed so IT plays the customer role.

**Fix**: Flip the roles for the Bedrock call:
- Customer's prior messages → `assistant` role (model "said" these)
- Agent's messages → `user` role (model responds to these)
- System prompt instructs the model: "You are the customer"

```python
# For Bedrock customer simulation:
# Agent says "Which account?" → becomes user role in Bedrock
# Customer said "I want to check my balance" → becomes assistant role
messages = [
    {"role": "assistant", "content": [{"text": "I want to check my balance"}]},  # customer
    {"role": "user", "content": [{"text": "Which account?"}]},  # agent
]
# Model generates next customer response as "assistant"
```

---

#### Issue 9: System prompt always creates a QUESTION tool (KB association)

**Symptom**: Even with a custom prompt and custom tools, the system default prompts (`SelfServiceOrchestrationVoice`, `SelfServiceOrchestrationChat`) always route to `QUESTION` first.

**Cause**: The system default AI Agents (type SELF_SERVICE) have a pre-processing and answer-generation pipeline that includes KB retrieval. The `connectInstanceArn` field on the orchestration agent links it to the instance's knowledge base. The system injects a `QUESTION` tool into the orchestration prompt that the custom tools can't outcompete.

**Key insight**: System agents (origin=SYSTEM) like `SelfServiceOrchestratorVoice` (type ORCHESTRATION) and `SelfService` (type SELF_SERVICE) include built-in tool injection. Custom agents (origin=CUSTOMER) don't — but only if you bypass the SELF_SERVICE layer via the `aiAgentId` override on SendMessage.

**Fix**: Use `aiAgentId` on SendMessage (Issue 3). This directly invokes your custom ORCHESTRATION agent's tool selection logic without going through the SELF_SERVICE wrapper.

---

#### Issue 10: Throttle handling at 9 concurrent sessions

**Symptom**: Occasional `429 ThrottlingException` on `SendMessage` or `GetNextMessage` when running 9 sessions in parallel.

**Cause**: Q in Connect APIs have a default 10 TPS limit per instance. With 9 concurrent sessions each making multiple API calls (CreateSession + SendMessage + multiple GetNextMessage polls), bursts can exceed 10 TPS momentarily.

**Fix**: Exponential backoff with jitter on every API call:
```python
def call_with_throttle_retry(func, **kwargs):
    for attempt in range(THROTTLE_MAX_RETRIES + 1):
        try:
            return func(**kwargs)
        except ClientError as e:
            if is_throttle(e) and attempt < THROTTLE_MAX_RETRIES:
                delay = random.uniform(0, min(2 * 2**attempt, 30))
                time.sleep(delay)
                continue
            raise
```

With 9 concurrent sessions, we observed only 2 throttle retries across 250 utterances. The backoff handled them transparently.

### Files (Prototype)

```
scratch/scaling_test/
├── run_test.py              # Main test runner (parallel, multi-turn)
├── customer_simulator.py    # Bedrock-powered customer persona
├── configure_agent.py       # Updates AI Agent tool configurations
├── cleanup_agent.py         # Restores original agent config
├── run_all_tiers.py         # Orchestrates multi-tier runs
├── tools.json               # 50 banking tool definitions
├── utterances.json          # 250 test utterances with customer_context
├── contact_flow_voice_validation.json  # Optional live voice flow
├── results/                 # JSON result files per run
└── tests/                   # Property-based and unit tests
```

---

## Forward-Looking Design: General-Purpose Agent Test Framework

### Vision

A standalone CLI tool that automated-tests any Q in Connect AI Agent deployment. It auto-discovers the agent configuration, runs scenario-based test suites, and reports task completion rates.

### Name Candidates

- `connect-agent-tester`
- `qic-agent-eval`
- `agent-sim`

### Core Concepts

#### Test Case = Customer Journey

A test case isn't a single utterance — it's a full customer journey that may invoke multiple tools across many turns.

```yaml
test_cases:
  - id: wire-transfer-new-customer
    description: "Customer wants to send a domestic wire transfer"
    persona:
      name: "Marcus Johnson"
      style: "direct"
      knowledge:
        recipient_name: "Jane Smith"
        routing_number: "021000021"
        account_number: "987654321"
        amount: "$5,000"
        wire_type: "domestic"
    initial_utterance: "I need to wire five thousand dollars to someone"
    success_criteria:
      - tool: SendWireTransfer
        params_contain:
          recipientName: "Jane Smith"
          amount: 5000
    max_turns: 20
    
  - id: dispute-then-provisional-credit
    description: "Customer disputes a charge and requests provisional credit"
    persona:
      name: "Lisa Park"
      style: "complaint"
      knowledge:
        transaction_id: "TXN-20240305-4455"
        amount: "$89.99"
        merchant: "StreamFlix"
        dispute_reason: "unauthorized"
        claim_id: "DSP-2024-55612"
    initial_utterance: "I got charged for something I didn't buy and I want my money back now"
    success_criteria:
      - tool: DisputeTransaction
      - tool: RequestProvisionalCredit
    max_turns: 30
```

#### Agent Auto-Discovery

The framework connects to Q in Connect, reads the agent config, and understands what tools are available without manual setup:

```python
# Auto-discover
agent = framework.discover_agent(
    assistant_id="...",
    ai_agent_id="...",
    region="us-east-1",
)
# agent.tools → list of tool definitions with names, descriptions, schemas
# agent.prompt_id → current orchestration prompt
# agent.model_id → underlying model
```

#### Simulated Customer (Enhanced)

The customer simulator evolves from "answer clarifying questions" to "drive the conversation toward a goal":

- **Goal-oriented**: The simulator knows what task the customer wants to complete
- **Persona-consistent**: Maintains communication style across turns
- **Knowledge-bounded**: Only reveals information it "knows" from the test case
- **Proactive**: Can introduce complications ("actually, wait — can you also check my balance?")
- **Evaluator**: After the conversation, a separate Bedrock call evaluates whether the task was completed

#### Success Criteria

Multiple evaluation modes:

1. **Tool invocation** — specific tools must be called (with optional param checks)
2. **Task completion** — evaluated by an LLM judge: "Was the customer's goal achieved?"
3. **Conversation quality** — no infinite loops, reasonable turn count, professional tone
4. **Negative testing** — agent should NOT invoke certain tools for certain inputs

#### Results and Reporting

```
┌─────────────────────────────────────────────────────────┐
│ Test Suite: AnyBank Mortgage Servicing Agent             │
│ Agent: d54d3dee-b9ec-415a-9a4b-b4769426f365            │
│ Model: us.anthropic.claude-haiku-4-5-20251001-v1:0     │
│ Tools: 23 configured                                    │
│ Run: 2026-06-02T23:30:00Z                              │
├─────────────────────────────────────────────────────────┤
│ Results:                                                 │
│   Total test cases:    45                                │
│   Passed:              42 (93.3%)                        │
│   Failed:               2 (4.4%)                         │
│   Errors:               1 (2.2%)                         │
│                                                          │
│ Failed:                                                  │
│   - escalate-edge-case: Agent completed task instead    │
│     of escalating (expected escalation)                  │
│   - multi-tool-sequence: Only invoked 2/3 required      │
│     tools before ending conversation                     │
│                                                          │
│ Avg turns per test: 4.2                                  │
│ Avg latency (first tool): 3.8s                          │
│ Total runtime: 2m 14s                                    │
└─────────────────────────────────────────────────────────┘
```

### Proposed Architecture

```
connect-agent-tester/
├── README.md
├── pyproject.toml
├── src/
│   └── agent_tester/
│       ├── __init__.py
│       ├── cli.py                # Click/typer CLI
│       ├── discovery.py          # Auto-discover agent config
│       ├── runner.py             # Test execution engine (parallel)
│       ├── simulator.py          # Bedrock customer simulator
│       ├── evaluator.py          # LLM-based task completion judge
│       ├── session.py            # Q in Connect session management
│       ├── models.py             # TestCase, TestResult, AgentConfig
│       └── reporting.py          # Console + JSON reports
├── tests/
│   ├── test_simulator.py
│   ├── test_evaluator.py
│   └── test_session.py
└── examples/
    ├── banking_suite.yaml        # Example test suite
    └── mortgage_suite.yaml
```

### CLI Interface

```bash
# Run a test suite against a live agent
agent-tester run \
  --assistant-id 5664eea5-... \
  --agent-id 8c02abb3-... \
  --suite examples/banking_suite.yaml \
  --concurrency 9 \
  --region us-east-1

# Discover agent configuration
agent-tester discover \
  --assistant-id 5664eea5-... \
  --agent-id 8c02abb3-...

# Generate test cases from tool definitions
agent-tester generate \
  --assistant-id 5664eea5-... \
  --agent-id 8c02abb3-... \
  --output generated_suite.yaml
```

### Key Design Decisions

1. **YAML test suites** — human-readable, version-controllable, shareable between teams
2. **LLM-as-judge for completion** — more flexible than exact tool matching; handles multi-path solutions
3. **Auto-generation of test cases** — read tool definitions and generate synthetic test scenarios
4. **No infrastructure changes required** — works against any existing Q in Connect agent via API
5. **Parallel execution** — concurrent sessions with throttle backoff (proven at 9 TPS)
6. **Conversation transcript recording** — full multi-turn transcripts saved for debugging

### IAM Requirements

The caller needs:
- `wisdom:CreateSession`, `wisdom:SendMessage`, `wisdom:GetNextMessage` — session APIs
- `wisdom:GetAIAgent`, `wisdom:ListAIAgents` — agent discovery
- `wisdom:GetAIPrompt` — prompt inspection (optional)
- `bedrock:InvokeModel` — for the customer simulator (Bedrock Converse API)

Both `wisdom:` and `qconnect:` resource ARN prefixes needed (per the known gotcha).

### What to Reuse from the Prototype

| Component | Reuse | Notes |
|-----------|-------|-------|
| `customer_simulator.py` | Core logic | Enhance with goal-driven behavior |
| Polling logic (`poll_for_response`) | Direct port | Handles filler responses, timeouts |
| `call_with_throttle_retry` | Direct port | Exponential backoff for 429s |
| `extract_tool_name` | Direct port | conversationSessionData extraction |
| Parallel execution pattern | Direct port | ThreadPoolExecutor + per-thread clients |
| `aiAgentId` on SendMessage | Critical discovery | The only way to override the default agent |

### What's New

| Component | Description |
|-----------|-------------|
| Agent discovery | Read agent config, tools, prompt via API |
| YAML test suite parser | Load and validate test case definitions |
| Goal-oriented simulator | Drive conversation toward task completion, not just answer questions |
| LLM evaluator | Post-conversation judgment: was the task completed? |
| Multi-tool tracking | Record ALL tools invoked across a conversation |
| CLI with reporting | Formatted console output + JSON/HTML reports |
| Test case generator | Auto-create scenarios from tool definitions |


---

## Web Platform Design

### Overview

A hosted web application that provides a visual interface for creating, running, and analyzing AI Agent test suites. Replaces the CLI-only workflow with a shareable platform that stores results historically and recommends improvements.

### User Flow

```
1. Login (Cognito) → 2. Select Agent → 3. Create/Edit Test Suite → 4. Run Tests → 5. View Results → 6. Compare Over Time → 7. Get Recommendations
```

### Architecture

```
┌────────────────────────────────────────────────────────────────────┐
│  Frontend (React + Cloudscape)                                      │
│  - Agent discovery browser                                          │
│  - Test case editor (form-based → YAML)                            │
│  - Run dashboard (live progress)                                    │
│  - Results viewer (pass/fail, transcripts, latency charts)         │
│  - Historical comparison (trend lines, regression detection)        │
│  - Recommendation panel (prompt/tool instruction suggestions)       │
└─────────────────────────────────┬──────────────────────────────────┘
                                  │ API Gateway + Cognito
                                  │
┌─────────────────────────────────▼──────────────────────────────────┐
│  Backend (Lambda + Step Functions)                                   │
│                                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐ │
│  │ Discovery API │  │ Test Runner  │  │ Analysis / Recommender   │ │
│  │ (Lambda)      │  │ (Step Func)  │  │ (Lambda + Bedrock)       │ │
│  │               │  │              │  │                          │ │
│  │ - ListAgents  │  │ - Parallel   │  │ - LLM judge for pass/   │ │
│  │ - GetAgent    │  │   sessions   │  │   fail evaluation        │ │
│  │ - GetPrompt   │  │ - Bedrock    │  │ - Diff analysis between  │ │
│  │ - ListTools   │  │   simulator  │  │   runs                   │ │
│  └──────┬───────┘  │ - Timeout/   │  │ - Prompt/tool instruct-  │ │
│         │           │   retry      │  │   ion recommendations    │ │
│         │           └──────┬───────┘  └──────────┬───────────────┘ │
│         │                  │                     │                   │
│  ┌──────▼──────────────────▼─────────────────────▼───────────────┐ │
│  │                    DynamoDB Tables                              │ │
│  │  - TestSuites (PK=tenantId, SK=suiteId)                       │ │
│  │  - TestRuns (PK=suiteId, SK=runTimestamp)                     │ │
│  │  - TestResults (PK=runId, SK=testCaseId) — per-case results   │ │
│  │  - Transcripts (PK=runId#caseId, SK=turnNumber)               │ │
│  │  - AgentSnapshots (PK=agentId, SK=timestamp) — config at run  │ │
│  └────────────────────────────────────────────────────────────────┘ │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐ │
│  │  Q in Connect APIs              Bedrock APIs                    │ │
│  │  - CreateSession                - Converse (customer sim)       │ │
│  │  - SendMessage(aiAgentId)       - Converse (LLM judge)          │ │
│  │  - GetNextMessage               - Converse (recommendations)    │ │
│  │  - GetAIAgent                                                   │ │
│  │  - ListAIAgents                                                 │ │
│  └────────────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────┘
```

### Key Pages

#### 1. Agent Browser
- Auto-discovers all agents on the assistant via `ListAIAgents`
- Shows: agent name, type, tool count, model, last modified
- Click to see full tool list with descriptions, input schemas
- Displays the current prompt text (read-only)

#### 2. Test Suite Editor
- Form-based UI for creating test cases (no YAML knowledge needed)
- Fields: persona name, communication style, customer knowledge (key-value pairs), initial utterance, success criteria (tool selections + optional param checks)
- "Generate from tools" button — auto-creates test cases for each tool using Bedrock
- Import/export YAML for CLI users
- Suites are saved to DynamoDB, versioned

#### 3. Run Dashboard
- "Run Suite" button triggers a Step Functions execution
- Live progress: shows active sessions, completed count, pass/fail as they complete
- Configurable concurrency (default 9)
- Can abort mid-run
- Shows throttle events and retries in real-time

#### 4. Results Viewer
- Pass/fail table with expandable rows
- Each row shows: test case name, status, tools invoked, turn count, latency
- Expand to see full conversation transcript (customer ↔ agent turns)
- Filter by: passed, failed, tool invoked, latency range
- Export results as JSON/CSV

#### 5. Historical Comparison
- Line charts: accuracy over time, latency over time
- Diff view: what changed between two runs (agent config, prompt, tools)
- Regression alerts: "Accuracy dropped from 98% to 91% after prompt change on June 2"
- Agent config snapshot stored with each run for reproducibility

#### 6. Recommendation Engine
- After a test run, Bedrock analyzes failures and suggests:
  - Tool instruction rewrites ("Make the DisputeTransaction description more specific to avoid confusion with ViewTransactionHistory")
  - System prompt adjustments ("Add guidance about prerequisite tools")
  - Missing tools ("Customers ask about X but no tool handles it")
- Shows before/after diff of suggested changes
- "Apply suggestion" button (with confirmation) updates the agent config

### Authentication

- **Cognito User Pool** for frontend auth
- **Cognito Identity Pool** for temporary AWS credentials
- IAM roles scoped to specific assistants/agents (multi-tenant safe)
- Optional: federate with corporate SSO via SAML/OIDC

### Data Model (DynamoDB)

```
TestSuites
  PK: TENANT#<tenantId>
  SK: SUITE#<suiteId>
  Attributes: name, description, agentId, assistantId, testCases[], createdAt, updatedAt

TestRuns  
  PK: SUITE#<suiteId>
  SK: RUN#<timestamp>
  Attributes: status, totalCases, passed, failed, errors, concurrency, 
              agentSnapshot (config at time of run), startTime, endTime

TestResults
  PK: RUN#<runId>
  SK: CASE#<testCaseId>
  Attributes: status, toolsInvoked[], turnCount, latencyMs, 
              expectedTools[], actualTools[], evaluationNotes

Transcripts
  PK: RUN#<runId>#CASE#<caseId>
  SK: TURN#<turnNumber>
  Attributes: role (customer|agent), text, toolSelected, timestamp
```

### Tech Stack

| Layer | Technology | Rationale |
|-------|-----------|-----------|
| Frontend | React + Cloudscape | AWS console-native design system |
| Auth | Cognito | Managed auth, federable |
| API | API Gateway + Lambda | Serverless, no infra to manage |
| Orchestration | Step Functions | Parallel test execution, timeouts, retries |
| Storage | DynamoDB | Single-table, fast, cheap |
| AI | Bedrock Converse | Customer simulation + LLM judge + recommendations |
| IaC | CDK (TypeScript) | Consistent with existing project patterns |
| Hosting | CloudFront + S3 | Static frontend, global CDN |

### MVP Scope (Phase 1)

Focus on the core loop: discover → create tests → run → view results.

- Agent discovery page (read-only)
- Test suite CRUD (form-based editor)
- Run execution (Step Functions, parallel)
- Results table with transcripts
- Cognito auth (email/password, no SSO yet)
- Single DynamoDB table

### Phase 2

- Historical comparison and trend charts
- Recommendation engine (Bedrock-powered suggestions)
- Auto-generate test cases from tool definitions
- Export/import YAML
- SSO federation

### Phase 3

- Multi-tenant (multiple teams sharing the platform)
- CI/CD integration (trigger test runs on agent config changes)
- Webhook/SNS notifications on regressions
- Custom evaluation functions (beyond LLM judge)
- Voice channel testing (via contact flow + Lex, not just API)


---

## Bedrock AgentCore Evaluations Integration

### Overview

Amazon Bedrock AgentCore Evaluations (public preview) provides a managed service for exactly the evaluation pattern we built manually. It offers:

- **Simulated multi-turn conversations** with LLM-backed actors (personas + goals)
- **Built-in evaluators** (`Builtin.GoalSuccessRate`, `Builtin.Helpfulness`)
- **Custom evaluators** (define your own scoring criteria)
- **Batch evaluation** — run many scenarios in parallel
- **Dataset-driven** — define scenarios in JSON with actor profiles

### How It Maps to Our Design

| Our prototype concept | AgentCore equivalent |
|----------------------|---------------------|
| `customer_simulator.py` (Bedrock-as-customer) | **User Simulation** — LLM-backed actor with persona, traits, and goal |
| `customer_context` in utterances.json | **ActorProfile.context** — background info the actor knows |
| utterance `style` (direct, colloquial, etc.) | **ActorProfile.traits** — key-value personality traits |
| Tool selection accuracy check | **Assertions** — natural language assertions evaluated after conversation |
| `compute_accuracy()` pass/fail | **Builtin.GoalSuccessRate** — did the actor achieve its goal? |
| `max_turns=10` | **max_turns** field on SimulatedScenario |
| Our parallel ThreadPoolExecutor | **BatchEvaluationRunner** — managed parallel execution |

### AgentCore Simulation Schema

Their scenario format is close to what we'd want:

```json
{
  "scenarios": [
    {
      "scenario_id": "wire-transfer-new-customer",
      "scenario_description": "Customer wants to send a domestic wire transfer",
      "actor_profile": {
        "traits": {"expertise": "non-technical", "tone": "direct", "patience": "moderate"},
        "context": "Needs to send $5,000 to landlord John Smith at Chase Bank. Has routing number 021000021 and account 987654321.",
        "goal": "Successfully initiate a domestic wire transfer of $5,000 to John Smith"
      },
      "input": "I need to wire five thousand dollars to someone",
      "max_turns": 20,
      "assertions": [
        "Agent collects all required wire transfer details",
        "Agent confirms the transfer details before proceeding",
        "Agent successfully initiates the SendWireTransfer tool"
      ]
    }
  ]
}
```

### Key Differences from Our Approach

| Aspect | Our prototype | AgentCore Evaluations |
|--------|--------------|----------------------|
| Agent invocation | Direct Q in Connect API (CreateSession → SendMessage → GetNextMessage) | Agent Runtime ARN invocation (different API surface) |
| Tool detection | `conversationSessionData.Tool` extraction | OpenTelemetry traces (tool use spans) |
| Hosting | Local Python script | Managed service with CloudWatch log ingestion |
| Scoring | Simple pass/fail on tool name match | LLM-as-judge with multiple evaluator dimensions |
| Cost | Pay for Bedrock calls (simulator) + Q in Connect sessions | Pay for evaluator model invocations + actor model invocations |

### Integration Challenge: Q in Connect vs AgentCore Runtime

AgentCore Evaluations expects an **agent invoker** — a function that takes input text and returns output text. It's designed for agents deployed as AgentCore Runtimes (with a Runtime ARN). Q in Connect AI Agents are NOT AgentCore Runtimes — they're accessed via the `qconnect` session API.

**Options to bridge this:**

1. **Custom agent invoker** — Write an `agent_invoker` function that wraps our Q in Connect session logic (CreateSession → SendMessage → poll GetNextMessage). The evaluator calls this function as if it were a standard agent.

2. **Hybrid approach** — Use AgentCore's evaluation/scoring engine (built-in evaluators + custom evaluators) but keep our own conversation driver (since we know how to handle the Q in Connect session quirks — filler responses, aiAgentId override, etc.).

3. **Wait for native integration** — Q in Connect may eventually expose agents as AgentCore Runtimes natively. Not available today.

**Recommended: Option 2 (Hybrid)**

We keep our proven conversation driver (handles all the Q in Connect API quirks) but leverage AgentCore for:
- **Scoring** — use `Builtin.GoalSuccessRate` and `Builtin.Helpfulness` as post-conversation evaluators
- **Custom evaluators** — define evaluators specific to tool selection accuracy
- **Batch orchestration** — if they add support for custom agent invokers

### Proposed Hybrid Architecture

```
┌─────────────────────────────────────────────────────┐
│  Our Framework (conversation driver)                 │
│  - Q in Connect session management                   │
│  - aiAgentId override on SendMessage                 │
│  - Filler response handling                          │
│  - Multi-turn with Bedrock actor (our simulator)     │
│  - Transcript recording                             │
└─────────────────────────┬───────────────────────────┘
                          │ Conversation transcripts
                          ▼
┌─────────────────────────────────────────────────────┐
│  AgentCore Evaluations (scoring)                     │
│  - Builtin.GoalSuccessRate                          │
│  - Builtin.Helpfulness                              │
│  - Custom evaluator: ToolSelectionAccuracy          │
│  - Custom evaluator: ConversationEfficiency         │
└─────────────────────────────────────────────────────┘
```

### Custom Evaluator Ideas

Using AgentCore's custom evaluator framework, we could define:

- **ToolSelectionAccuracy** — "Did the agent invoke the expected tool(s) from the success criteria?"
- **ConversationEfficiency** — "Did the agent reach tool invocation within a reasonable number of turns?"
- **InformationGathering** — "Did the agent collect all required parameters before invoking the tool?"
- **NegativeRouting** — "Did the agent correctly NOT invoke tools for out-of-scope requests?"
- **EscalationAppropriateeness** — "Was escalation to a human justified?"

### Decision: When to Use AgentCore vs Our Own Evaluation

| Use case | Recommendation |
|----------|---------------|
| Running conversations against Q in Connect agents | **Our framework** (handles API quirks) |
| Scoring conversation quality post-hoc | **AgentCore evaluators** (managed, consistent) |
| Simulating diverse customer personas | **Either** — our simulator works today; AgentCore's is more standard |
| Batch regression testing at scale | **AgentCore batch runner** (if custom invoker supported) |
| Tool selection accuracy for return-to-control | **Our framework** (we extract from conversationSessionData) |
| General helpfulness/tone evaluation | **AgentCore Builtin.Helpfulness** |

### Action Items for New Project

1. Research whether AgentCore's `agent_invoker` can wrap Q in Connect session calls (it accepts arbitrary Python functions)
2. Evaluate `Builtin.GoalSuccessRate` against our test suite — does it agree with our pass/fail results?
3. Build a custom evaluator for tool selection accuracy that reads from conversation transcripts
4. Consider using AgentCore's actor simulation instead of our custom `customer_simulator.py` if it supports the persona detail we need
