# Operations

This guide covers running the platform in production-like environments: instance modes, IAM scoping, audit, observability, and troubleshooting.

## Table of contents

1. [Instance modes](#instance-modes)
2. [IAM model](#iam-model)
3. [Audit trail](#audit-trail)
4. [Observability](#observability)
5. [Cost considerations](#cost-considerations)
6. [Troubleshooting](#troubleshooting)
7. [Disaster recovery](#disaster-recovery)
8. [Operator scripts](#operator-scripts)

---

## Instance modes

The platform supports two deploy-time modes:

| Mode | Description |
|---|---|
| `development` (default) | All capabilities enabled. Apply Recommendations and Multi-Variant Experiments work. |
| `production` | Read-only against the live agent. Apply / experiment write paths are disabled. |

Set via the `instanceMode` CDK context parameter:

```bash
npx cdk deploy --context instanceMode=production ...
```

### What production mode disables

Production mode is **defense in depth across three layers**, so a misconfiguration or compromised Lambda can't bypass it:

**1. UI layer.** The frontend reads `instanceMode` from `/config.json` (generated at deploy time) and uses it to:
- Hide the **Implement Recommendations** button on the run dashboard and failure analysis page.
- Hide the **Apply to Agent** buttons in the tournament view.
- Display a **"Production (read-only)"** badge in the application header.

Source: `src/frontend/src/components/ImplementRecommendations/InstanceModeBadge.tsx`, `ImplementButton.tsx`.

**2. API layer.** Every write handler validates `process.env.INSTANCE_MODE` and returns 403 with `{ "error": "write_disabled", "reason": "..." }` if it's `production`. This check runs **before** any other validation (tenant, drift, body shape), so even malformed requests get the production-mode response.

Affected endpoints:
- `POST /runs/{id}/apply-recommendations`
- `POST /runs/{id}/experiments`
- `POST /runs/{id}/experiments/{id}/apply`

Source: each handler's `getInstanceMode()` check at the top of its `handler()` function.

**3. IAM layer.** When `instanceMode === "production"`, the `ImplementRecommendationsConstruct` **omits** these actions from the Lambda execution role's policies:
- `wisdom:UpdateAIAgent`, `qconnect:UpdateAIAgent`
- `wisdom:UpdateAIPrompt`, `qconnect:UpdateAIPrompt`
- `wisdom:CreateAIAgent`, `qconnect:CreateAIAgent`
- `wisdom:DeleteAIAgent`, `qconnect:DeleteAIAgent`

Read actions (`GetAIAgent`, `GetAIPrompt`) are always granted. The Lambda physically cannot make a write call — even if the API check is bypassed, the SDK call fails with AccessDenied.

Source: `lib/implement-recommendations-construct.ts`, the conditional `addToRolePolicy` block guarded by `if (instanceMode !== "production")`.

### What production mode does NOT disable

- Test execution (Q in Connect session APIs are read-only from the agent's perspective).
- Failure analysis and recommendation generation (Bedrock-only operations).
- Multi-variant experiments **submission** is disabled, but viewing prior experiments and tournament results is unaffected.
- Audit trail reads.

### When to use production mode

- Customer environments where the live Connect agent serves real production traffic.
- Compliance environments where any agent modification requires a separate change control process.
- Multi-stage CI: development account runs experiments, then a separate production account validates with a read-only deployment.

### Switching modes

Re-deploy with the new `instanceMode` value. CloudFormation recomputes the IAM policies and writes a fresh `config.json`. No data is lost.

```bash
# Switching from development to production
npx cdk deploy --context instanceMode=production --context connectInstanceId=...
```

## IAM model

### Lambda role principles

Every Lambda has a dedicated role with least-privilege grants:

- **DynamoDB** — `grantReadWriteData` for handlers that mutate state, `grantReadData` for read-only handlers (`results`, `audit`, `experiment-get`).
- **Q in Connect** — scoped to assistant ARNs by default, narrowed to specific resource types where possible. Both `wisdom:` and `qconnect:` prefixes are granted because the service straddles two ARN namespaces.
- **Bedrock** — scoped to inference profile and foundation model ARNs in supported regions (`us-east-1`, `us-east-2`, `us-west-2`).
- **Step Functions** — `states:StartExecution` only on the specific state machine ARN.
- **Secrets Manager** — none of the platform's main Lambdas read the machine-client secret. CI/CD callers fetch it themselves.

### Authenticated user role

The Cognito Identity Pool issues short-lived AWS credentials to authenticated users. The attached role grants:

- `wisdom:CreateSession`, `wisdom:SendMessage`, `wisdom:GetNextMessage` (plus `qconnect:` equivalents) — scoped to assistant and session ARNs.
- `bedrock:InvokeModel`, `bedrock:Converse` — scoped to foundation models in the deploy region.

These are used by the frontend for direct calls (currently none — all calls go through API Gateway) and reserved for future browser-side scenarios.

### Tenant isolation

`tenantId` comes from the Cognito JWT claim `sub` (interactive) or `client_id` (machine). Every DynamoDB query and write includes `PK=TENANT#{tenantId}` (or operates on records owned by a parent suite/run that itself is tenant-scoped). Cross-tenant data access is impossible by construction — there's no code path that takes tenant ID as a parameter from the request body.

Audit records (`PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}`) are queryable only by the owning tenant via `GET /audit`.

## Audit trail

Every write to a live agent produces an audit record in DynamoDB at `PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}`.

### Record shape

```typescript
interface AuditRecord {
  tenantId: string;
  timestamp: string;        // ISO 8601
  runId: string;
  agentId: string;
  source: "direct_apply" | "experiment_apply";
  experimentId?: string;     // for experiment_apply
  appliedVariant?: "A" | "B" | "C";  // for experiment_apply
  previousVersionId: string;
  newVersionId: string;
  recommendations: Recommendation[];  // full Recommendation objects
  driftDetected?: boolean;
  driftedFields?: DriftedField[];
  userDecision?: "apply_anyway" | "normal";
}
```

The `recommendations` array contains the full Recommendation objects (not just indices), so the audit log is self-contained — replaying or auditing later doesn't require re-resolving against the original run.

### Querying

Via the API:

```bash
curl -H "Authorization: Bearer $TOKEN" "$API_URL/audit"
```

Returns 50 records per page, reverse chronological. Use `nextToken` for pagination.

Via DynamoDB directly (operator-only):

```bash
aws dynamodb query \
  --table-name $TABLE_NAME \
  --key-condition-expression "PK = :pk AND begins_with(SK, :sk)" \
  --expression-attribute-values '{":pk":{"S":"TENANT#tenant-uuid"},":sk":{"S":"AUDIT#"}}' \
  --scan-index-forward false \
  --limit 50
```

### Forensics workflow

If you need to investigate a configuration drift incident:

1. Query the audit trail for the affected agent.
2. The record carries `previousVersionId` and `newVersionId`. Use the Q in Connect `ListAIAgentVersions` API to enumerate versions and `GetAIAgent --aiAgentVersion` to retrieve the historical config.
3. Each audit record carries the full `recommendations` payload — you can see exactly what was applied.

For experiment audits, the `experimentId` field links to the persisted experiment record (`PK=RUN#{runId}, SK=EXPERIMENT#{experimentId}`) which has the full variant config and tournament summary.

## Observability

### Logs

Every Lambda emits CloudWatch Logs. Log groups follow the pattern `/aws/lambda/{stack}-{function-name}`.

Structured logs include:
- Request handler entry/exit with input and output sizes.
- Error stack traces with the original error name (used for retry classification).
- Throttle backoff messages (`[bedrock] Rate exceeded, retry attempt N`).

For the test execution path, the `conversation-driver` logs every Q in Connect API call with the session ID, message ID, and tool selection. This is your debugging trail when a test case behaves unexpectedly.

### X-Ray tracing

Enabled on every Lambda (`tracing: lambda.Tracing.ACTIVE`) and on the experiment state machine. Traces show:

- API Gateway → Lambda invocations.
- Lambda → DynamoDB calls.
- Lambda → Bedrock and Q in Connect calls.
- Step Functions task durations.

Useful for pinpointing where time is going in a slow run (typically Bedrock judge calls dominate).

### Step Functions execution history

Both state machines retain execution history per the AWS default (90 days). Click into an execution from the Step Functions console to see:

- Per-step input and output JSON.
- Catch handler activations.
- Lambda invocation links (jump straight to the X-Ray trace).

### DynamoDB metrics

Standard CloudWatch DynamoDB metrics: `ConsumedReadCapacityUnits`, `ConsumedWriteCapacityUnits`, `ThrottledRequests`. The table is on-demand, so throttling is rare; if you see it, the table may be auto-scaling and a brief retry will succeed.

### Setting up alarms

The base stack does not create CloudWatch alarms. Recommended alarms for production deployments:

- **Lambda errors** — sum of Errors metric > 0 over 5 minutes per function.
- **API Gateway 5xx** — `5XXError` > 1% over 15 minutes.
- **Step Functions execution failures** — `ExecutionsFailed` > 0 on the test run state machine over 5 minutes.
- **DynamoDB throttles** — any `UserErrors` or throttled-request count > 0.
- **Bedrock throttles** — derived from CloudWatch Logs metric filter on `ThrottlingException`.

Add these as a separate CDK construct or via the CloudWatch console.

## Cost considerations

The platform is serverless and pay-per-use. The dominant cost categories:

| Category | What drives it | Typical magnitude |
|---|---|---|
| **Bedrock judge** | 1 + N + M Converse calls per test case (1 GoalSuccessRate + N Helpfulness + M ToolSelectionAccuracy). | ~$0.03–$0.05 per case. A 100-case run is ~$3–$5. |
| **Bedrock RAG evaluation** | One evaluation job per run with at least one RAG case. | ~$0.10–$0.30 per RAG case depending on chunk count. |
| **Bedrock variant generation** | One Converse call per experiment (with up to 3 retries per failed variant). | ~$0.05 per experiment. |
| **Bedrock customer simulation** | One Converse call per simulated customer turn. | ~$0.01 per turn. |
| **Bedrock analysis** | One Converse call per failed case. | ~$0.02 per failed case. |
| **Q in Connect session API** | CreateSession + several SendMessage + many GetNextMessage per case. | Small — typically <$0.01 per case. |
| **Lambda** | Each test run spans ~1 minute of compute across N Lambda invocations. | Negligible — tens of cents per run. |
| **DynamoDB** | On-demand, modest read/write per case. | Negligible. |
| **Step Functions** | One state machine execution per run + one per experiment. | Negligible. |
| **CloudFront + S3** | Frontend static asset serving. | Negligible. |
| **CloudWatch logs** | All Lambda logs. | Modest — $0.50/GB ingested, scale with run frequency. |

For a customer engagement running 5 suites of 50 cases each weekly, expect Bedrock costs around $50-100/month. RAG-heavy suites and frequent multi-variant experiments push this higher.

To reduce cost:
- Pin a smaller judge model via `judgeModelId` (e.g. Haiku instead of Sonnet) — see `.kiro/steering/bedrock-judge-prompts.md` for the IAM grant tightening.
- Use the persisted analysis cache: don't re-run `/analyze` with `force: true` unless you've changed the input.
- Limit RAG case count per suite — RAG evaluation is more expensive per case than judge scoring.

## Troubleshooting

### Test runs stuck in `running`

Symptoms: the run dashboard shows `running` indefinitely.

Diagnosis:

1. Check the Step Functions execution in the console.
2. Look for stuck `PollForResponse` polling loops — typically Q in Connect throttling beyond the retry envelope.
3. Check CloudWatch Logs for the `RunTrigger` Lambda for the run start event, then trace through `ExecuteCases` task logs.

Mitigation:
- Click **Abort run** to stop the state machine.
- Reduce concurrency on the next run (default 9 → 4 or 6).
- If throttling is severe, contact AWS support to raise the Q in Connect API quota for the account.

### Drift detected on every apply

Symptoms: clicking **Confirm and Apply** always returns 409 with drifted fields.

Diagnosis: someone (or something) edited the agent in the Q in Connect console between the run capturing its snapshot and the apply attempt. The platform refuses to silently overwrite.

Mitigation:
- Re-run the suite to capture a fresh snapshot, then apply against that.
- Or click **Re-analyze** to regenerate recommendations against the now-current state.
- Or click **Apply anyway** to force-write (the audit record will reflect this with `userDecision: "apply_anyway"`).

### Frontend shows "Runtime configuration unavailable"

Symptoms: the app loads but immediately shows an error banner.

Diagnosis: `/config.json` failed to load. Most common causes:
1. The frontend deployment didn't upload `config.json` (check the `FrontendDeployment` custom resource logs).
2. CloudFront cache is serving a stale negative response.
3. A network issue in the user's browser.

Mitigation:
- Re-run `cdk deploy` to refresh `config.json`.
- Manually invalidate CloudFront: `aws cloudfront create-invalidation --distribution-id ... --paths '/config.json' '/index.html'`.

### Experiment cleanup left orphaned agents

Symptoms: temp agents `{name}-experiment-{id}-variant-X` remain in the Q in Connect console after an experiment.

Diagnosis: cleanup retries failed twice for those specific agent IDs. The experiment record's `cleanupStatus` will be `partial_failure` with `failedCleanupAgentIds` populated.

Mitigation:
- Delete manually via the Q in Connect console or CLI:
  ```bash
  aws qconnect delete-ai-agent --assistant-id $ASSISTANT_ID --ai-agent-id <orphaned-id>
  ```
- Investigate the underlying cause — typically a transient permissions issue on the Lambda role at the moment of deletion. The next experiment cleanup is unaffected.

### "no_recommendations" on apply

Symptoms: clicking **Apply directly** returns 404 `no_recommendations`.

Diagnosis: the run hasn't generated per-suite recommendations yet, or they were never persisted.

Mitigation: navigate to the run dashboard and click the recommendations panel header — that triggers `/recommend-suite`. After it completes, retry the apply.

### Authentication loops

Symptoms: signing in redirects back to the sign-in page.

Diagnosis: usually a callback URL mismatch — the URL the user hit isn't in the Cognito Web Client's `callbackUrls`.

Mitigation:
- Always go through the CloudFront URL or a callback URL listed at deploy time.
- For custom domains, add the domain to `callbackUrls` and redeploy.

### Bedrock model access errors

Symptoms: scaffold, analysis, or judge calls fail with `AccessDeniedException: ... not authorized to perform: bedrock:InvokeModel`.

Diagnosis: model access not granted in the deployment region.

Mitigation:
- Open the Bedrock console → Model access → Request access for `Anthropic Claude` family.
- Wait a few minutes for the grant to propagate.
- If still failing, verify the configured `judgeModelId` matches an inference profile available in your region.

## Disaster recovery

### Data backup

The DynamoDB table has **point-in-time recovery enabled**. Restore to any moment in the last 35 days via the DynamoDB console.

### Loss scenarios

| Scenario | Recovery |
|---|---|
| DynamoDB data corrupted | Restore from PITR. |
| CloudFront distribution deleted | Re-deploy the stack — CloudFront is provisioned by CDK. |
| Cognito user pool deleted | Re-deploy. Users must be re-created (history is lost — Cognito doesn't have PITR). The optional `adminEmail` bootstrap re-creates the first user. |
| S3 frontend bucket emptied | Re-deploy — `BucketDeployment` re-uploads. |
| Live agent broken by a bad apply | Use the audit trail to find the last apply, identify `previousVersionId`, and revert via the Q in Connect console (`UpdateAIAgent --aiAgentVersion` to restore). |

### Out-of-band changes to the Connect agent

If someone edits the agent in the Q in Connect console while a test run is in progress: the test run completes against the original snapshot, but subsequent applies against the same run will detect drift. The audit trail tracks the platform's writes; out-of-band edits aren't tracked here. Use Q in Connect's own version history for that.

## Operator scripts

Several maintenance scripts live under `scripts/`:

| Script | Purpose |
|---|---|
| `scripts/evaluation-harness.ts` | Run the Bedrock judge integration locally against a saved transcript or live session — without redeploying the stack. Useful when iterating on prompt template changes. |
| `scripts/bedrock-judge-probe.ts` | Smoke-test the three judge templates against fixtures. Reference implementation for the prompt source-of-truth in `.kiro/steering/bedrock-judge-prompts.md`. |

Run them with `npx ts-node scripts/<name>.ts --help` for usage.

## Updating the judge model

The judge model is configured by the `judgeModelId` CDK context parameter. Default: `us.anthropic.claude-sonnet-4-6`.

To switch:

```bash
npx cdk deploy --context judgeModelId=anthropic.claude-3-5-sonnet-20241022-v2:0 ...
```

The deploy:
- Updates `JUDGE_MODEL_ID` env var on the Evaluation Lambda.
- Recomputes the IAM grant — for inference profiles (with `us.`/`eu.`/`apac.` prefix), the grant covers all routing regions; for bare model IDs, only the deploy region.

When the AWS docs publish a new revision of any judge prompt template, follow the procedure in `.kiro/steering/bedrock-judge-prompts.md`:
1. Diff the template against the live AWS doc.
2. Update the verbatim copy in the steering file.
3. Update the corresponding constant in `src/backend/orchestration/judge-prompt-templates.ts`.
4. Update Score_Scale entries in `src/shared/utils/evaluation-scoring.ts` if labels moved.
5. Update the golden-prompt snapshot tests.
