/**
 * PostApplyPrompt — success notification rendered after a successful
 * Direct_Apply or Apply Winning Variant operation. Prompts the user to
 * re-run the test suite to validate the improvements.
 *
 * Requirements addressed:
 *   - R4.1: Display prompt "Changes applied successfully. Re-run the test
 *     suite to validate the improvements?" with a "Re-run Suite" button.
 *   - R4.2: "Re-run Suite" triggers a new test run and navigates to the
 *     Run Dashboard for the new run.
 *   - R4.3: Dismissing the prompt does not trigger a run and returns the
 *     user to the Recommended_Changes_Panel.
 *
 * @module components/ImplementRecommendations/PostApplyPrompt
 */

import Button from '@cloudscape-design/components/button';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Flashbar, { type FlashbarProps } from '@cloudscape-design/components/flashbar';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface PostApplyPromptProps {
  /** Whether the prompt is visible. */
  visible: boolean;
  /** The new agent version ID created by the apply operation. */
  newVersionId: string;
  /** Callback fired when the user clicks "Re-run Suite". */
  onReRunSuite: () => void;
  /** Callback fired when the user dismisses the prompt. */
  onDismiss: () => void;
  /** Callback fired when the user clicks "Revert Changes". */
  onRevert?: () => void;
  /** Whether a revert is currently in progress. */
  reverting?: boolean;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * Renders a Cloudscape Flashbar success message with a "Re-run Suite"
 * action button. The component is fully controlled via the `visible` prop.
 */
export function PostApplyPrompt({
  visible,
  newVersionId,
  onReRunSuite,
  onDismiss,
  onRevert,
  reverting,
}: PostApplyPromptProps): JSX.Element | null {
  if (!visible) {
    return null;
  }

  const items: FlashbarProps.MessageDefinition[] = [
    {
      type: 'success',
      dismissible: true,
      dismissLabel: 'Dismiss',
      onDismiss,
      content: `Changes applied successfully (version: ${newVersionId}). Re-run the test suite to validate the improvements?`,
      action: (
        <SpaceBetween direction="horizontal" size="xs">
          <Button onClick={onReRunSuite}>
            Re-run Suite
          </Button>
          {onRevert && (
            <Button onClick={onRevert} loading={reverting} variant="link">
              Revert Changes
            </Button>
          )}
        </SpaceBetween>
      ),
      id: 'post-apply-success',
    },
  ];

  return <Flashbar items={items} />;
}
