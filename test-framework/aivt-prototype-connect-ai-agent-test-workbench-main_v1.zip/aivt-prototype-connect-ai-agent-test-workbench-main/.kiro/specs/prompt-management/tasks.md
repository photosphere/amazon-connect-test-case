# Implementation Plan: Prompt Management

## Overview

This plan delivers the prompt-management feature in the four waves the design lays out: a foundation wave that ships the registry, the API, the Cloudscape pages, the conformance-probe runner, and the IAM helper without touching any existing Bedrock callsite; a low-risk wave that migrates the four interactive Bedrock callsites; an in-run wave that extends Run_Snapshot and migrates the seven in-run callsites plus the RAG evaluation job; and a cleanup wave that retires the legacy inline IAM blocks and `*_MODEL_ID` environment variables.

Bottom-up implementation order inside each wave: shared types and the registry first, then the resolver and capability profiles, then the validation pipeline, then the handlers and CDK helpers, then the frontend components, then the conformance probe. Property-based tests pin the five correctness invariants alongside the implementation.

The conformance-probe runner gates every wave: a wave cannot merge with a failing positive or negative probe.

## Tasks

- [x] 1. Set up shared types, the registry skeleton, and DDB constants
  - [x] 1.1 Add prompt-management types to `src/shared/types.ts`
    - Add `PromptKey` literal-union, `ModelKey` literal-union, `Placeholder`, `InferenceParameterSchema`, `PromptDefinition`, `PromptOverride`, `ResolvedPrompt`, `ResolvedPromptSnapshot`, `SupportedModel`, `ModelCapabilityProfile` interfaces per the Components and Interfaces section of the design
    - Extend the existing `AgentSnapshot` interface with the optional `prompts?: Readonly<Record<PromptKey, ResolvedPromptSnapshot>>` field
    - Extend `AuditRecord["source"]` literal type with `"prompt_edit"` and `"prompt_reset"`
    - _Requirements: 1.1, 1.2, 11.1, 16.1, 17.1_
  - [x] 1.2 Extend DynamoDB key pattern constants
    - Add `PROMPT: "PROMPT#"` to `PK_PATTERNS` and `OVERRIDE: "OVERRIDE"`, `HISTORY: "HISTORY#"` to `SK_PATTERNS` in `src/shared/constants.ts`
    - Add the `PROMPT_TEXT_DEFAULT_MAX_BYTES = 65_536` and `PROMPT_HISTORY_MAX_ENTRIES = 10` constants
    - _Requirements: 7.2, 12.1_

- [x] 2. Implement the Prompt_Registry single source of truth
  - [x] 2.1 Create `src/backend/orchestration/prompt-registry/types.ts`
    - Re-export the shared types and add the registry-internal `PromptRegistry` map type plus the `UnknownPromptKeyError` class
    - _Requirements: 1.1, 1.2_
  - [x] 2.2 Create `src/backend/orchestration/prompt-registry/capability-profiles.ts`
    - Declare `CAPABILITY_PROFILES` exactly as the design's Components and Interfaces section spells out: `anthropic_claude_4x` (accepts `maxTokens` only; forbids `temperature`/`topP`/`topK`/`stopSequences`) and `amazon_nova` (accepts `maxTokens`/`temperature`/`topP`/`stopSequences` top-level + `topK` via additional fields; numeric ranges per the design)
    - Implement and export `buildInferenceConfig(prompt: ResolvedPrompt)` that places `topK` under `additionalModelRequestFields.inferenceConfig.topK` for Nova and emits `{ inferenceConfig: { maxTokens } }` for Anthropic 4.x
    - _Requirements: 17.2, 17.4, 10.4_
  - [x] 2.3 Create `src/backend/orchestration/prompt-registry/supported-models.ts`
    - Declare the `SUPPORTED_MODELS` six-entry frozen record exactly per the design (Sonnet 4.6 / Haiku 4.5 / Opus 4.8 / Nova Lite / Nova Pro / Nova Premier with their canonical inference profile ids and `routingRegions[]`)
    - Add a build-time invariant module-level assertion that every `modelKey` is unique, every `inferenceProfileId` matches the vendor's canonical prefix, every `capabilityProfileKey` is declared in `CAPABILITY_PROFILES`, and every `routingRegions[]` is non-empty
    - _Requirements: 17.1, 17.6_
  - [x] 2.4 Create per-prompt definition files under `src/backend/orchestration/prompt-registry/prompts/`
    - One file per of the thirteen `promptKey` values (`suite-scaffold.ts`, `case-scaffold.ts`, `failure-analysis.ts`, `suite-recommendation.ts`, `comparison-summary.ts`, `tournament-summary.ts`, `variant-generation.ts`, `customer-simulator.ts`, `judge-goal-success-rate.ts`, `judge-helpfulness.ts`, `judge-tool-selection.ts`, `judge-opportunistic-faithfulness.ts`, `rag-evaluation-job.ts`)
    - Each file exports a `PromptDefinition` whose `defaultText` is lifted byte-for-byte from the existing callsite (the four judges re-export the constants in `src/backend/orchestration/judge-prompt-templates.ts`; the seven Converse callsites lift their existing `SYSTEM_PROMPT` literals)
    - Declare `placeholders[]`, `allowedModels[]` (initially the platform's existing default's `modelKey`, plus any peers we want exposed at launch), `inferenceParameters` schema, and `defaultInferenceValues` per the design
    - For each prompt, `defaultModelKey` is seeded from the legacy `*_MODEL_ID` env var when its value matches a `Supported_Models` inference profile id, else from the prompt's hardcoded default
    - _Requirements: 1.1, 1.2, 1.4_
  - [x] 2.5 Create `src/backend/orchestration/prompt-registry/resolver.ts`
    - Implement the pure `resolvePrompt(promptKey, overrides)` function with the three behaviour invariants from the design (default-fallback, stale-placeholder fallback emits warning + returns `version: 0`, unknown promptKey throws `UnknownPromptKeyError`)
    - _Requirements: 10.1, 10.5_
  - [x] 2.6 Create `src/backend/orchestration/prompt-registry/index.ts`
    - Public surface re-export: registry map, `resolvePrompt`, `SUPPORTED_MODELS`, `CAPABILITY_PROFILES`, `buildInferenceConfig`, `RUN_PROMPT_KEYS` (the array of promptKeys any test run can consume — every key except the three interactive-only `suite_scaffold`/`case_scaffold`/`comparison_summary`)
    - _Requirements: 1.1, 11.1_
  - [x] 2.7 Write unit test for registry build invariants
    - Create `tests/unit/prompt-registry.test.ts` asserting all thirteen `promptKey` values are present, every `defaultText` is non-empty and contains every declared placeholder at least once, every `defaultModelKey` is in the prompt's `allowedModels[]`, every `allowedModels[]` references valid `modelKey` values
    - Assert each prompt's `defaultText` is byte-for-byte equal to the legacy literal it replaces (the test imports both the registry and the legacy module and compares strings directly)
    - _Requirements: 1.1, 1.2, 3.3, 17.6_

- [x] 3. Implement the property-based correctness invariants for the registry
  - [x] 3.1 Add fast-check generators
    - Create `tests/properties/generators.ts` exporting `promptKeyArb`, `validTextArb(prompt)`, `validInferenceParametersArb(prompt, model)` per the design's Testing Strategy section
    - _Requirements: 15.6_
  - [x] 3.2 Write property test for placeholder preservation
    - **Property 3: Placeholder preservation**
    - For any persisted prompt (default state, edited, or post-reset), the set of declared `placeholder.name` values is a subset of the set of `{name}` tokens in the persisted `effectiveText`
    - Run ≥100 iterations under fast-check with mocked DDB
    - **Validates: Requirements 12.2, 15.3**
  - [x] 3.3 Write property test for capability-profile compliance
    - **Property 5: Model_Capability_Profile compliance**
    - For any `(promptKey, modelKey)` pair the resolver could return — including pairs where `modelKey` is the prompt's bundled default and pairs where it is a persisted override — the resolved `inferenceParameters` key set is a subset of `acceptsTopLevel ∪ acceptsAdditional` and disjoint from `forbids`
    - Run ≥100 iterations under fast-check
    - **Validates: Requirements 15.5, 17.4**
  - [x] 3.4 Write static AST-based test for registry-only resolution rule
    - **Property 4: Registry-only resolution rule (static)**
    - Walk every source file under `src/backend/handlers/` and `src/backend/orchestration/`. For every file that imports `BedrockRuntimeClient`/`ConverseCommand`/`BedrockAgentCoreClient` or that calls `CreateEvaluationJob`, assert the file imports `resolvePromptForRun` or `resolvePromptLive` from `prompt-registry/runtime` AND does NOT contain a top-level `const SYSTEM_PROMPT = ` literal AND does NOT contain a top-level `process.env.*_MODEL_ID ?? "..."` fallback
    - This test fails the build before Wave 1 lands; it is initially scoped to skip files that have not yet been migrated, with one allow-listed callsite removed per migration step in Tasks 11–12
    - **Validates: Requirements 1.3, 15.4**

- [x] 4. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Implement the Prompts_Store and DDB service helpers
  - [x] 5.1 Add Prompts_Store CRUD methods to `src/backend/services/dynamodb.ts`
    - Add `getPromptOverride(promptKey)`, `listPromptOverrides()`, `putPromptOverride(override, priorVersion)`, `deletePromptOverride(promptKey)`, `listPromptHistory(promptKey)`, `evictOldestHistoryEntry(promptKey, maxEntries)`
    - `putPromptOverride` is the transactional `TransactWriteItems` write described in the Data Models section: snapshot prior → conditional put on `version = priorVersion` for optimistic concurrency
    - `evictOldestHistoryEntry` is a separate best-effort `DeleteItem` that runs after the transaction commits; failure logs a warning and returns
    - _Requirements: 4.2, 4.3, 7.2_
  - [x] 5.2 Write unit test for the Prompts_Store transactional write
    - Create `tests/unit/prompts-store.test.ts` mocking the DDB document client; assert `putPromptOverride` builds a `TransactWriteItems` with the correct three items (history insert if prior exists, conditional override update with `version = priorVersion`, no eviction in the transaction itself)
    - Assert optimistic-concurrency violation: when the prior `GetItem` returns `version=5` but a concurrent writer bumped it to `version=6` before the transaction commits, the transaction's `ConditionalCheckFailedException` propagates to the caller with the right typed error
    - _Requirements: 4.2, 7.2_
  - [x] 5.3 Write property test for override round-trip
    - **Property 1: Override round-trip**
    - For any `(promptKey, text, modelKey, inferenceParameters)` tuple where the text satisfies the prompt's placeholder schema, fits under the size cap, and contains no unknown placeholders; modelKey is in the prompt's `allowedModels[]`; inferenceParameters is valid for the model's capability profile — a `PUT` followed by a `GET` returns the same triple element-wise
    - Run ≥100 iterations against an in-memory mock DDB
    - **Validates: Requirements 4.4, 15.1**
  - [x] 5.4 Write property test for reset idempotence
    - **Property 2: Reset idempotence**
    - For any non-empty sequence of `PUT` and `reset` ops (≤20 ops per iteration) ending in a `reset`, applying one additional reset leaves the state unchanged: `effectiveText`, `currentModelKey`, `inferenceParameters`, `version: 0`, `isOverridden: false`
    - **Validates: Requirements 6.4, 15.2**

- [x] 6. Implement the Prompts_API validation pipeline
  - [x] 6.1 Create `src/backend/handlers/prompts-validation.ts`
    - Export each of the ten validation pipeline stages from the design's Validation pipeline section as a separate pure function: `validatePromptKeyExists`, `validateTextSize`, `validatePlaceholdersPresent`, `validatePlaceholderOccurrenceCap`, `validateNoUnknownPlaceholders`, `validateModelMembership`, `validateCapabilityProfileCompliance`, `validateNumericBounds`, `validateDryRender`
    - Each function returns either `{ ok: true }` or `{ ok: false, code: string, details?: object }` matching the structured error code table in the Error Handling section
    - The dry-render validator constructs but does NOT send a `ConverseCommand`
    - _Requirements: 4.5, 4.6, 4.7, 4.8, 4.9, 4.10, 12.1, 12.2, 12.3, 12.4, 12.5_
  - [x] 6.2 Write unit tests for each validation stage
    - One test per `(stage, error code)` pair so a regression in one stage doesn't accidentally re-test the wrong code
    - Cover: `PROMPT_TEXT_TOO_LARGE`, `PLACEHOLDERS_MISSING`, `PLACEHOLDER_COUNT_EXCEEDED`, `UNKNOWN_PLACEHOLDER`, `MODEL_NOT_ALLOWED`, `MODEL_FORBIDS_KEY`, `INFERENCE_PARAMETER_OUT_OF_BOUNDS`, `DRY_RENDER_FAILED`
    - _Requirements: 4.5, 4.6, 4.7, 4.8, 4.9, 4.10, 12.3, 12.4, 12.5_

- [x] 7. Implement the Prompts Lambda handler
  - [x] 7.1 Create `src/backend/handlers/prompts.ts`
    - API Gateway proxy integration handler dispatching by `(httpMethod, resource)` exactly as `src/backend/handlers/audit.ts` does
    - Implement `handleListPrompts`, `handleGetPrompt`, `handleUpdatePrompt`, `handleResetPrompt`, `handleGetHistory`, `handleActiveRuns`
    - `handleUpdatePrompt` runs the validation pipeline in order, then issues `putPromptOverride`, then writes the audit record best-effort
    - `handleResetPrompt` enforces `body.confirm === true` (R6.6) returning `RESET_CONFIRMATION_REQUIRED` otherwise, then is idempotent for "no override exists" per R6.4
    - `handleActiveRuns` queries the run-store for runs with status `running` or `pending` and returns the count
    - All response shapes match the `ListPromptsResponse`/`GetPromptResponse`/`UpdatePromptResponse`/`ResetPromptResponse`/`GetHistoryResponse`/`ActiveRunsResponse` interfaces from the design's API contract section
    - _Requirements: 2.1-2.5, 3.1-3.4, 4.1-4.10, 5.1-5.5, 6.1-6.6, 7.1-7.4, 16.5_
  - [x] 7.2 Write unit test for the Prompts handler
    - Create `tests/unit/prompts-handler.test.ts` with mocked DDB and mocked `AuditWriter`
    - Assert `GET /prompts` returns thirteen entries sorted by category then name, with `defaultText`/`overrideText` body absent (R2.4)
    - Assert `GET /prompts/{promptKey}` returns `defaultText` byte-for-byte and `effectiveText = override.text ?? defaultText`
    - Assert `PUT` increments `version` exactly by one and writes the prior to history (R4.2, R4.3)
    - Assert `POST /reset` returns 400 `RESET_CONFIRMATION_REQUIRED` when `confirm` is missing or not strictly `true`; assert idempotence for the "no override" case
    - Assert `GET /history` returns history sorted by `version` descending with at most ten entries
    - Assert audit write failure does not affect the 200 response (R9.3)
    - _Requirements: 2.1-2.5, 3.1-3.4, 4.1-4.4, 6.1-6.6, 7.1-7.4, 9.1-9.4_

- [x] 8. Implement the runtime prompt resolution helpers
  - [x] 8.1 Create `src/backend/orchestration/prompt-registry/runtime.ts`
    - Implement `resolvePromptForRun(promptKey, runId)`: reads the run's `AgentSnapshot.prompts` map; falls back to the live registry when the snapshot lacks a `prompts` field (pre-feature run); throws `PromptResolutionError` when both paths fail (R16.3)
    - Implement `resolvePromptLive(promptKey)`: reads the live override store via `listPromptOverrides`, runs `resolvePrompt`, throws `PromptResolutionError` on store failure
    - Add a per-Lambda-warm cache for the snapshot read keyed by `runId`; the live-override read is also cached for ≤30s to avoid hammering DDB during a Map iteration
    - Both functions implement R16.3 fail-closed: never substitute an empty prompt or a stale cached value
    - _Requirements: 10.1, 11.2, 11.3, 16.2, 16.3_
  - [x] 8.2 Write unit test for runtime resolver semantics
    - Create `tests/unit/runtime.test.ts`
    - Snapshot-first path: snapshot has `prompts.{key}`, returns it without consulting the live store
    - Live-fallback path: snapshot has no `prompts` field, falls back to live store and emits an info log
    - Fail-closed path: both reads fail, throws `PromptResolutionError` with the underlying cause attached
    - Cache behaviour: two consecutive calls within 30s of each other share one DDB read; calls 31s apart issue two reads
    - _Requirements: 11.2, 11.3, 16.2, 16.3_

- [x] 9. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Implement the CDK helper, IAM grants, and the Prompts Lambda construct
  - [x] 10.1 Create `lib/bedrock-grants.ts`
    - Implement and export `computeBedrockGrants({ promptKeys, stack })` per the design's CDK helper section
    - Throws synth-time errors with explicit messages for unknown promptKey, empty `routingRegions[]` (R19.5), and `allowedModels[]` referencing a `modelKey` not in the catalog
    - Returns `{ statement: iam.PolicyStatement, modelKeys: readonly ModelKey[] }`
    - _Requirements: 19.1, 19.5_
  - [x] 10.2 Wire `computeBedrockGrants` into `lib/api-construct.ts` for `scaffoldLambda`, `analysisLambda`, `comparisonSummaryLambda`, `suiteRecommendLambda`
    - Add the helper-derived statement IN ADDITION TO the existing inline `bedrock:*` statement (Wave 0 keeps both for safety; Wave 3 removes the inline ones)
    - Build a `bedrockGrantSummary: Record<string, readonly ModelKey[]>` map keyed by Lambda logical id
    - Emit `new cdk.CfnOutput(this, "BedrockGrantSummary", { value: JSON.stringify(bedrockGrantSummary) })`
    - _Requirements: 19.2, 19.6_
  - [x] 10.3 Wire `computeBedrockGrants` into `lib/orchestration-construct.ts` for the Evaluation Lambda, the Conversation Driver Lambda's customer-simulator path, the Variant Generator Lambda, the Tournament Summary Lambda, and the RAG Evaluate Lambda
    - Same pattern as Task 10.2; same dual-grant posture
    - The Evaluation Lambda's existing tightly-scoped Bedrock_Judge IAM block stays — `computeBedrockGrants` adds the broader catalog grant in parallel; Wave 3 retires the narrow block once the registry has been the resolution path for one full release cycle
    - _Requirements: 19.2, 19.6_
  - [x] 10.4 Add the Prompts Lambda construct to `lib/api-construct.ts`
    - New `NodejsFunction` from `src/backend/handlers/prompts.ts` with the same `commonLambdaProps` posture as the audit Lambda (Node 20 ARM64, 512 MiB, tracing on)
    - `commonBundling` excludes `@aws-sdk/client-bedrock-runtime` (the dry-render validator constructs a `ConverseCommand` but never calls `send`)
    - Grant `props.table.grantReadWriteData(this.promptsLambda)` for the override/history/audit writes
    - Grant via `computeBedrockGrants({ promptKeys: ALL_PROMPT_KEYS, stack })` so the dry-render check can construct a Converse for any model
    - _Requirements: 8.1, 8.2_
  - [x] 10.5 Wire the Prompts API routes in `lib/api-construct.ts`
    - Add the resource tree `/prompts`, `/prompts/{promptKey}`, `/prompts/{promptKey}/reset`, `/prompts/{promptKey}/history`, `/prompts/active-runs`
    - Every method's `MethodOptions` carries `authorizationType: apigateway.AuthorizationType.COGNITO`, the existing User Pool authorizer, and `authorizationScopes: ['test-platform/run']` per R8.1; missing the scope flips the authorizer to ID-token mode and 401s the frontend
    - _Requirements: 8.1_
  - [x] 10.6 Write CDK assertion test for IAM grants and routes
    - Create `tests/cdk/bedrock-grants.test.ts` that synthesises the stack, walks every Bedrock-calling Lambda's role policy, and asserts the helper-derived statement's `Resource` list is exactly the union (set-equal — neither wider nor narrower) of inference-profile + routing-region foundation-model wildcards reachable from that Lambda's promptKey set
    - Assert `BedrockGrantSummary` CFN output exists and parses as a JSON map with one entry per Bedrock-calling Lambda
    - Add a separate test asserting every Prompts API method has `authorizationScopes: ['test-platform/run']` set (regression guard for the implement-recommendations bug we just fixed)
    - _Requirements: 19.2, 19.3, 19.6, 8.1_

- [x] 11. Implement the Conformance_Probe runner
  - [x] 11.1 Create `scripts/bedrock-probe.ts`
    - Self-contained TypeScript file modelled on the existing `scripts/bedrock-judge-probe.ts`
    - Implement `parseArgs()`, `buildPositiveProbe(model)`, `buildNegativeProbe(model)`, `buildRagJobProbe()`, `runProbe(probe, client)`, `isRegionReachable(model)`, `main()` per the design
    - Positive probe: Converse with `inferenceConfig` populated from the profile's `acceptsTopLevel` keys (default values), `maxTokens=32` (R18.8 cost cap), synthetic `"ping"` user message; assert non-empty response
    - Negative probe: Converse with exactly one forbidden key set to its profile-default value (Anthropic 4.x: try `temperature=0.5`); assert 4xx response. If a 200 comes back, dump the request and response and fail the build (R18.3 — the doc-lag sentinel)
    - RAG-job probe: `CreateEvaluationJob` followed immediately by `StopEvaluationJob`; if the job is in `IN_PROGRESS` and `Stop` rejects, log the `jobArn` and let it terminate naturally (R18.2)
    - `isRegionReachable` skips models whose routing-regions are unreachable from the executing AWS region; emits a structured warning log per R18.8
    - _Requirements: 18.1, 18.2, 18.3, 18.4, 18.5, 18.7, 18.8_
  - [x] 11.2 Add `npm run probe:bedrock` to `package.json`
    - Script: `node --loader tsx scripts/bedrock-probe.ts`
    - Add `npm run probe:bedrock:dry-run` aliasing `npm run probe:bedrock -- --dry-run`
    - _Requirements: 18.1, 18.7_
  - [x] 11.3 Write unit test for the probe builder against a mocked Bedrock client
    - Create `tests/unit/bedrock-probe-dry-run.test.ts`
    - Inject a stub Bedrock client that captures the `ConverseCommand` parameters; assert positive-probe shape per profile (Anthropic 4.x: `inferenceConfig` contains exactly `maxTokens`; Nova: contains all profile keys, with `topK` under `additionalModelRequestFields.inferenceConfig`)
    - Assert negative-probe shape: exactly one forbidden key present
    - Assert RAG-job probe sets `evaluatorModelConfig.bedrockEvaluatorModels[].modelIdentifier` to the resolved model id
    - _Requirements: 18.7_
  - [x] 11.4 Wire CI to run the conformance probe
    - Add a CI step that runs `npm run probe:bedrock` when any file under `src/backend/orchestration/prompt-registry/` or any Bedrock callsite is modified in the PR
    - Upload `bedrock-probe-report.json` as a build artifact so a failure leaves a forensic trail
    - Add a release-pipeline step that runs the same gate before deploying to non-development environments
    - _Requirements: 18.4, 18.6_

- [x] 12. Checkpoint — Ensure all tests pass and the conformance probe is green
  - Ensure all tests pass.
  - Run `npm run probe:bedrock -- --dry-run` and confirm zero failures in the report.
  - Ask the user to run `npm run probe:bedrock` against live Bedrock and review the report before proceeding to Wave 1 callsite migration.

- [x] 13. Implement the Prompts frontend (sidebar, list page, detail page)
  - [x] 13.1 Add the typed API client wrappers
    - Create `src/frontend/src/api/prompts.ts` exporting `listPrompts()`, `getPrompt(promptKey)`, `updatePrompt(promptKey, body)`, `resetPrompt(promptKey)`, `getHistory(promptKey)`, `getActiveRuns()`
    - Wrap the existing `useApi` hook so error responses are mapped to the typed structured-error-code shape (`{ code, details }`) per the design's error table
    - _Requirements: 13.2, 14.1, 14.3, 14.4_
  - [x] 13.2 Add the Prompts sidebar entry
    - Edit `src/frontend/src/components/AppLayout/sideNav.tsx`: add a `Prompts` entry immediately below `Test Suites` per R13.1, linked to `/prompts`
    - _Requirements: 13.1_
  - [x] 13.3 Implement `pages/PromptsListPage.tsx`
    - Cloudscape `Table` over `GET /prompts` with columns `name`, `category`, `currentModelDisplayName`, `lastModifiedAt`, `lastModifiedBy`, an `isOverridden` badge column
    - Sort by `category` then `name` ascending, case-insensitive (R2.2)
    - Loading state: Cloudscape `StatusIndicator` while the request is pending; rows hidden until the response arrives (R13.5)
    - Error state: Cloudscape `Alert` with retry button when the request fails or exceeds 10s (R13.6)
    - Empty state: Cloudscape `<EmptyState>` reading "No prompts available" if the response is empty (R13.7)
    - Row click navigates to `/prompts/{promptKey}` (R13.4)
    - _Requirements: 13.2, 13.3, 13.4, 13.5, 13.6, 13.7_
  - [x] 13.4 Implement `pages/PromptDetailPage.tsx`
    - Cloudscape split-pane layout: left pane is the editable `Textarea` seeded with `effectiveText`; right pane is a read-only viewer of `defaultText`
    - Render prompt `name`, `description`, `category`, current effective `modelId`, and the `placeholders[]` chip list with descriptions
    - Below: the `ModelSelector`, the `InferenceParameterForm`, the `Save` and `Revert to default` buttons, and the `HistoryPanel`
    - On `Save`, issue `PUT` with only the fields the user changed (R14.3); render any HTTP 400 validation error inline; on 200, refetch the detail
    - On `Revert`, open the `RevertConfirmModal`; on confirmation, issue `POST /reset` with `{ confirm: true }` and refetch
    - Polls `GET /prompts/active-runs` once on mount and once before submitting an edit/reset; if `count > 0`, show the `ActiveRunsFlashbar` after a successful save with the R14.6 message
    - _Requirements: 14.1, 14.3, 14.4, 14.6_
  - [x] 13.5 Implement `components/Prompts/ModelSelector.tsx`
    - Cloudscape `Select` over the prompt's `allowedModels[]`
    - When the selected `modelKey` changes, rebuild the `InferenceParameterForm`: keys in the new profile's `forbids[]` are removed; keys it newly accepts appear with their schema defaults pre-filled (R5.5 — the additional keys appear but are not auto-populated until the user saves explicitly)
    - Emit a Cloudscape `Alert` when the switch removes form fields so the user knows what changed
    - _Requirements: 5.2, 5.5, 14.2_
  - [x] 13.6 Implement `components/Prompts/InferenceParameterForm.tsx`
    - Auto-generated form fields driven by the prompt's `inferenceParameterSchema` filtered by the resolved model's `capabilityProfile.acceptsTopLevel ∪ acceptsAdditional`
    - Numeric inputs use Cloudscape `Slider` with the schema's declared min/max; integer inputs use `Input` with `type="number"`
    - For the `amazon_nova` profile, render the `topK` field with a label note that it's sent under `additionalModelRequestFields.inferenceConfig.topK`
    - _Requirements: 14.1, 17.4_
  - [x] 13.7 Implement `components/Prompts/HistoryPanel.tsx`
    - Cloudscape `ExpandableSection` rendered beneath the editor
    - On expand, refetch `GET /prompts/{promptKey}` (R14.5 — staleness guard) and `GET /prompts/{promptKey}/history` in parallel
    - Render each history entry with `version`, `modifiedAt`, `modifiedBy`, `changeKind`, and a `View` affordance that swaps the right-pane viewer from `defaultText` to that historical entry's text without mutating the editor
    - _Requirements: 14.5_
  - [x] 13.8 Implement `components/Prompts/RevertConfirmModal.tsx` and `components/Prompts/ActiveRunsFlashbar.tsx`
    - `RevertConfirmModal`: Cloudscape `Modal`. On `Revert`, call `resetPrompt(promptKey)` with `{ confirm: true }`. On Cancel, close without action
    - `ActiveRunsFlashbar`: Cloudscape `Flashbar` shown only when `activeRuns.count > 0`; message: "Saved. The change will not affect runs already in progress; it will apply to the next run started." per R14.6
    - _Requirements: 14.4, 14.6_
  - [x] 13.9 Add the `/prompts` and `/prompts/{promptKey}` routes
    - Wire React Router routes for `PromptsListPage` and `PromptDetailPage` in the existing router config
    - _Requirements: 13.1, 14.1_
  - [x] 13.10 Write component tests for the Prompts pages
    - `tests/frontend/PromptsListPage.test.tsx`: assert Cloudscape Table renders with the right columns, loading/error/empty states, row click navigation
    - `tests/frontend/PromptDetailPage.test.tsx`: assert side-by-side editor renders, `ModelSelector` filters form fields by capability profile, `Save` issues only the changed fields, `Revert` flow triggers the modal, `HistoryPanel` refetches on expand, `ActiveRunsFlashbar` shows only when `count > 0`
    - _Requirements: 13.2-13.7, 14.1-14.6_

- [x] 14. Checkpoint — Ensure all tests pass and the new Prompts page renders end-to-end
  - Run the full test suite.
  - Manually verify (or ask the user to verify) that the Prompts sidebar entry appears, the list page renders the thirteen prompts, opening one renders the detail page, editing and saving a prompt round-trips through the API, and reverting works.

- [x] 15. Wave 1 — Migrate the four interactive Bedrock callsites to the registry
  - [x] 15.1 Migrate `src/backend/handlers/comparison-summary.ts`
    - Replace the literal `SYSTEM_PROMPT` string and `process.env.COMPARISON_SUMMARY_MODEL_ID ?? "..."` fallback with `await resolvePromptLive("comparison_summary")`
    - Construct the Converse via `buildInferenceConfig(prompt)` and `fillTemplate(prompt.text, vars)`
    - Keep the legacy env var set in `lib/api-construct.ts` as a safety net (deleted in Wave 3)
    - Remove the file from the static AST allow-list in Task 3.4
    - _Requirements: 1.3, 10.1, 10.3_
  - [x] 15.2 Migrate `src/backend/handlers/scaffold.ts`
    - Same pattern. Two distinct `promptKey` resolutions: `resolvePromptLive("suite_scaffold")` for the suite-level scaffold and `resolvePromptLive("case_scaffold")` for case-level scaffold
    - Remove from the static AST allow-list
    - _Requirements: 1.3, 10.1, 10.3_
  - [x] 15.3 Migrate `src/backend/handlers/suite-recommend.ts`
    - Same pattern. `resolvePromptLive("suite_recommendation")`
    - Remove from the static AST allow-list
    - _Requirements: 1.3, 10.1, 10.3_
  - [x] 15.4 Migrate `src/backend/handlers/analysis.ts`
    - Same pattern. `resolvePromptLive("failure_analysis")`
    - Remove from the static AST allow-list
    - _Requirements: 1.3, 10.1, 10.3_
  - [x] 15.5 Update existing handler unit tests for the four callsites
    - Each handler's test file mocks `resolvePromptLive` (or the underlying override store) instead of stubbing the env var
    - Assert the Converse `inferenceConfig` shape matches what `buildInferenceConfig` produced for the resolved model
    - _Requirements: 10.1, 10.4_

- [x] 16. Wave 1 — Run the conformance probe and merge
  - Run `npm run probe:bedrock` against the dev account; confirm zero failures.
  - Deploy Wave 1 to the dev account (`AWS_DEFAULT_REGION=us-east-1 npx cdk deploy -c connectInstanceId=46837cc7-8562-4b3f-92b2-1bae0ede624b --require-approval never`).
  - Smoke test: edit one prompt via the UI, fire the corresponding interactive endpoint (e.g. `POST /comparison-summary`), confirm the edited prompt was used.

- [x] 17. Wave 2 — Extend Run_Snapshot and migrate in-run callsites
  - [x] 17.1 Extend `src/backend/orchestration/handlers/prepare-run.ts` to capture the prompts map
    - Import the registry, call `listPromptOverrides()` once, then `resolvePrompt(key, overrides)` for every key in `RUN_PROMPT_KEYS`
    - Pack the resolved `(text, modelKey, modelId, inferenceParameters, capabilityProfileKey, version)` triples into the new `AgentSnapshot.prompts` map keyed by `promptKey`
    - Do this BEFORE the existing `createRun` call so the run record never reaches `RUNNING` without its prompts pinned (R11.1)
    - If `listPromptOverrides()` fails, abort the run with a structured `PROMPT_RESOLUTION_FAILED` error (R11.2 fail-closed at run start)
    - _Requirements: 11.1, 11.2, 16.1_
  - [x] 17.2 Update the prepare-run unit test
    - Extend `tests/unit/prepare-run.test.ts` (or add a sibling file): assert `AgentSnapshot.prompts` is present, contains every `RUN_PROMPT_KEYS` key, every entry's `text` is the resolved string (default for pristine, override for an overridden prompt)
    - Assert capture order: the `writeSnapshot` call happens before `createRun`
    - Assert the failure case: `listPromptOverrides` rejecting causes prepare-run to throw without writing a partial snapshot
    - _Requirements: 11.1, 11.2_
  - [x] 17.3 Migrate `src/backend/orchestration/customer-simulator.ts`
    - Replace the env-var modelId fallback and the inline `buildSimulatorPrompt` system prompt with `await resolvePromptForRun("customer_simulator", runId)` and `fillTemplate(prompt.text, vars)`
    - Construct Converse via `buildInferenceConfig(prompt)`
    - Remove from the static AST allow-list
    - _Requirements: 10.1, 11.2, 11.3_
  - [x] 17.4 Migrate `src/backend/orchestration/variant-generator.ts`
    - `resolvePromptForRun("variant_generation", runId)` for the system prompt
    - Construct Converse via `buildInferenceConfig(prompt)` — the `temperature: 0.7` value carries on the registry override since `variant_generation`'s default model is in the `amazon_nova` profile (or stays Anthropic and the temperature value is dropped per R10.4 + R17.4)
    - Decide at registry-population time whether to migrate this callsite to a Nova model so it can keep its `temperature` value, or leave it Anthropic and drop `temperature` per the capability profile; document the choice in the registry's prompt definition file
    - Remove from the static AST allow-list
    - _Requirements: 10.1, 11.2, 11.3, 17.4_
  - [x] 17.5 Migrate `src/backend/orchestration/tournament-summary.ts`
    - `resolvePromptForRun("tournament_summary", runId)`
    - **Side effect:** the orphan default `claude-sonnet-4-20250514-v1:0` is retired here — the registry's `tournament_summary` prompt uses `claude_sonnet_4_6` as its default `modelKey`, matching the platform's standard
    - Remove from the static AST allow-list
    - _Requirements: 1.3, 10.1, 11.2, 11.3_
  - [x] 17.6 Migrate the four AgentCore-template judges
    - `src/backend/orchestration/bedrock-judge-client.ts`: replace the direct `process.env.JUDGE_MODEL_ID` read and the inline `inferenceConfig: { maxTokens: 1024, temperature: 0 }` construction with a per-call resolver lookup; the caller (Evaluation Lambda or harness) passes the `runId` through to the judge client
    - The four judge promptKeys (`judge_goal_success_rate`, `judge_helpfulness`, `judge_tool_selection`, `judge_opportunistic_faithfulness`) each resolve their own `(text, modelId, inferenceParameters)` triple
    - `src/backend/orchestration/opportunistic-faithfulness.ts`: same pattern for `judge_opportunistic_faithfulness`
    - The judge templates module (`src/backend/orchestration/judge-prompt-templates.ts`) remains unchanged — the registry imports its constants
    - Remove these files from the static AST allow-list
    - _Requirements: 1.3, 10.1, 10.3, 11.2, 11.3_
  - [x] 17.7 Migrate the RAG evaluation job
    - `src/backend/orchestration/rag-evaluate.ts`: resolve `rag_evaluation_job` via `resolvePromptForRun`, then set `evaluatorModelConfig.bedrockEvaluatorModels[].modelIdentifier` to `prompt.modelId` per R10.2
    - The registry's `rag_evaluation_job` prompt definition has no `text` placeholder body — the prompt's value is purely the model identifier; declare an empty placeholder list and set `defaultText: ""` with a `maxTextBytes: 0` cap so the Prompts page surfaces it as a model-only entry
    - Remove from the static AST allow-list
    - _Requirements: 1.3, 10.1, 10.2, 11.2_
  - [x] 17.8 Update conversation-driver and evaluation Lambda tests
    - Mock `resolvePromptForRun` in the test setup; assert the Converse / `CreateEvaluationJob` calls receive the resolved `(modelId, inferenceConfig)` shape per the model's capability profile
    - _Requirements: 10.1, 11.2_

- [x] 18. Wave 2 — Run conformance probe and merge
  - Run `npm run probe:bedrock` and confirm zero failures.
  - Deploy Wave 2 to the dev account.
  - Smoke test: kick off a real test run end-to-end. Confirm the run completes, the `AgentSnapshot.prompts` field is present in DDB, and the Step Functions execution output shows the resolved modelIds match the registry defaults.

- [x] 19. Checkpoint — Run a release-cycle bake before Wave 3
  - Wave 3 (IAM cleanup + env-var retirement) cannot merge until at least one full release cycle has passed with Wave 2 in production. Confirm the production deploy of Wave 2 has been live and exercised by real test runs before proceeding.
  - Ask the user to confirm before continuing.

- [x] 20. Wave 3 — IAM cleanup and env-var retirement
  - [x] 20.1 Remove the inline `bedrock:*` `addToRolePolicy` blocks from `lib/api-construct.ts`
    - Drop the legacy inline statements on `scaffoldLambda`, `analysisLambda`, `comparisonSummaryLambda`, `suiteRecommendLambda`. Each Lambda now has exactly one Bedrock statement, the one `computeBedrockGrants` produced
    - The CDK assertion test from Task 10.6 starts failing if any inline grant is reintroduced
    - _Requirements: 19.2, 19.3_
  - [x] 20.2 Remove the inline `bedrock:*` `addToRolePolicy` blocks from `lib/orchestration-construct.ts`
    - Drop the legacy inline statements on the Conversation Driver, Variant Generator, Tournament Summary, RAG Evaluate Lambdas. Drop the tightly-scoped Bedrock_Judge IAM block on the Evaluation Lambda since `computeBedrockGrants` now provides the catalog grant
    - _Requirements: 19.2, 19.3_
  - [x] 20.3 Remove the legacy `*_MODEL_ID` environment variables
    - Strip `ANALYSIS_MODEL_ID`, `SUITE_RECOMMEND_MODEL_ID`, `COMPARISON_SUMMARY_MODEL_ID`, `BEDROCK_MODEL_ID`, `SIMULATOR_MODEL_ID`, `SCAFFOLD_MODEL_ID`, `JUDGE_MODEL_ID` from the relevant Lambda's `environment` blocks in both CDK constructs
    - Delete the env-var seeding bridge from `prompt-registry/index.ts` (registry now reads only its hardcoded defaults; overrides via `PUT /prompts/{key}`)
    - Update all unit tests that previously stubbed these env vars
    - _Requirements: 1.4_
  - [x] 20.4 Retire any residual `Sonnet_4_6_Family` glossary references
    - Sweep the codebase for `Sonnet_4_6_Family` and `SONNET_4_6_NO_TOPP` references in code comments and doc strings
    - Replace with references to the `anthropic_claude_4x` capability profile or the `MODEL_FORBIDS_KEY` error code
    - _Requirements: 17.2_
  - [x] 20.5 Update the CDK assertion test to enforce single-grant posture
    - Tighten `tests/cdk/bedrock-grants.test.ts`: assert each Bedrock-calling Lambda has exactly ONE Bedrock policy statement (not two — Wave 0 deliberately had two for the dual-grant safety period). Wider or narrower fails the build
    - _Requirements: 19.3_

- [x] 21. Wave 3 — Run conformance probe, deploy, and merge
  - Run `npm run probe:bedrock` and confirm zero failures.
  - Deploy Wave 3 to the dev account.
  - Smoke test: kick off another test run end-to-end. Confirm runs continue to work without the legacy env vars.
  - Ask the user to confirm before merging Wave 3 to main and deploying to production.

- [x] 22. Final checkpoint — Run the full test suite and the conformance probe
  - All unit tests pass.
  - All five property-based tests pass at ≥100 iterations.
  - `tests/cdk/bedrock-grants.test.ts` passes with the tightened single-grant invariant from Task 20.5.
  - `npm run probe:bedrock` against the dev account passes with all positive + negative + RAG-job entries reporting `result: pass`.
  - Manually verify (or ask the user to verify) that:
    - The Prompts sidebar entry exists and the list page renders all thirteen prompts.
    - Editing a prompt persists, the next interactive Bedrock call uses the override, and the next test run snapshots the override at run-start.
    - Reverting a prompt clears the override and the next run uses the bundled default.
    - The change history panel renders for an edited-then-reverted prompt with two history entries.
    - The Active Runs Flashbar appears when editing while a run is running.
  - At this point the feature is complete; the spec can be archived.

## Task Dependency Graph

```json
{
  "waves": [
    { "wave": 1, "tasks": ["1"] },
    { "wave": 2, "tasks": ["2"] },
    { "wave": 3, "tasks": ["3", "5"] },
    { "wave": 4, "tasks": ["4"] },
    { "wave": 5, "tasks": ["6", "8"] },
    { "wave": 6, "tasks": ["7"] },
    { "wave": 7, "tasks": ["9"] },
    { "wave": 8, "tasks": ["10", "11"] },
    { "wave": 9, "tasks": ["12"] },
    { "wave": 10, "tasks": ["13"] },
    { "wave": 11, "tasks": ["14"] },
    { "wave": 12, "tasks": ["15"] },
    { "wave": 13, "tasks": ["16"] },
    { "wave": 14, "tasks": ["17"] },
    { "wave": 15, "tasks": ["18"] },
    { "wave": 16, "tasks": ["19"] },
    { "wave": 17, "tasks": ["20"] },
    { "wave": 18, "tasks": ["21"] },
    { "wave": 19, "tasks": ["22"] }
  ]
}
```

```mermaid
graph TD
    T1[1. Shared types & DDB constants]
    T2[2. Prompt_Registry]
    T3[3. Property tests for registry]
    T4[4. Checkpoint]
    T5[5. Prompts_Store + DDB helpers]
    T6[6. Validation pipeline]
    T7[7. Prompts Lambda handler]
    T8[8. Runtime resolver helpers]
    T9[9. Checkpoint]
    T10[10. CDK helper, IAM, Prompts construct]
    T11[11. Conformance_Probe runner]
    T12[12. Checkpoint + live probe]
    T13[13. Frontend pages]
    T14[14. Checkpoint]
    T15[15. Wave 1 - migrate interactive callsites]
    T16[16. Wave 1 - probe & deploy]
    T17[17. Wave 2 - Run_Snapshot + in-run callsites]
    T18[18. Wave 2 - probe & deploy]
    T19[19. Release-cycle bake]
    T20[20. Wave 3 - cleanup]
    T21[21. Wave 3 - probe & deploy]
    T22[22. Final checkpoint]

    T1 --> T2
    T2 --> T3
    T2 --> T5
    T3 --> T4
    T5 --> T4
    T2 --> T6
    T5 --> T6
    T6 --> T7
    T2 --> T8
    T5 --> T8
    T7 --> T9
    T8 --> T9
    T9 --> T10
    T9 --> T11
    T10 --> T12
    T11 --> T12
    T12 --> T13
    T13 --> T14
    T14 --> T15
    T15 --> T16
    T16 --> T17
    T17 --> T18
    T18 --> T19
    T19 --> T20
    T20 --> T21
    T21 --> T22
```

## Notes

- The plan delivers the four waves the design lays out: Wave 0 (Tasks 1-14) ships the registry, store, API, IAM helper, conformance probe, and frontend without touching any existing Bedrock callsite. Wave 1 (Tasks 15-16) migrates the four interactive callsites. Wave 2 (Tasks 17-18) extends Run_Snapshot and migrates the seven in-run callsites plus the RAG eval job. Wave 3 (Tasks 20-21) retires the legacy inline IAM blocks and `*_MODEL_ID` env vars.
- Every wave is gated by `npm run probe:bedrock`. A failing positive or negative probe halts the wave.
- The static AST allow-list referenced in Tasks 3.4, 15, and 17 is the mechanism that lets the registry-only resolution rule (Property 4) ratchet down callsite-by-callsite without breaking CI mid-migration. Each migration task removes one entry from the allow-list; the rule is fully strict by the end of Wave 2.
- Tournament-summary's orphan default model id (`claude-sonnet-4-20250514-v1:0`) is retired in Task 17.5 — that's the only callsite still pinned to a non-platform-standard model.
- Wave 3 cannot merge until at least one full release cycle has passed with Wave 2 in production. Task 19 is an explicit human-checked gate.
- The conformance probe's negative variant (Task 11.1) is the doc-lag sentinel: if a future Bedrock release silently re-accepts a parameter the platform thought was forbidden, the probe will catch it and the build will fail with a request/response dump so the maintainer can update the capability profile to match observed behaviour.
- The dual-grant posture in Task 10.2/10.3 (helper-derived statement + legacy inline statement coexisting through Waves 0-2) makes every wave reversible by `git revert` of the merge.
