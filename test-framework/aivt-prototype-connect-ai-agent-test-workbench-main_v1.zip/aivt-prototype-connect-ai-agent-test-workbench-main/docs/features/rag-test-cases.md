# RAG test cases

How single-turn retrieval-augmented test cases work end to end.

## When to use RAG cases

Tool-sequence cases verify "the agent picked the right tools in the right order." That's the wrong assertion when the agent uses a `Retrieve` tool against a Knowledge Base — what matters there is **the natural-language answer**: is it grounded in the retrieved chunks, factually correct, complete, and helpful?

RAG cases are the answer. Each case has:
- A **question** (the literal customer turn).
- A **ground truth answer** (the known-good agent reply).

Execution is single-turn: send the question, capture the agent's terminal response and the chunks it retrieved, score both against the ground truth.

## Authoring

In the test case form, set **Test Type** to **RAG**. Required fields:

- **Name and description**.
- **Question** (1–1000 chars, trimmed-non-empty).
- **Ground Truth Answer** (1–4000 chars, trimmed-non-empty).
- **Session Data** (optional, up to 20 key-value pairs) — for content tag filters or any other session-driven retrieval behavior.

Tool-sequence-only fields (`persona`, `style`, `customerKnowledge`, `initialUtterance`, `successCriteria`, `goalDescription`, `primingMessage`) are not present on RAG cases. Server-side validation rejects them with `400 rag_case_extraneous_field`.

The case type **cannot be changed after creation** — the edit form disables the dropdown. Switching types is equivalent to creating a different case.

## Execution

The conversation driver runs RAG cases differently from tool-sequence cases:

1. **CreateSession** with the same `aiAgentId` override pattern.
2. **One SendMessage** with the case's `question` as the customer turn (no priming, no simulator).
3. **Poll until the agent's terminal text response** is captured. The customer simulator is **never** invoked for RAG cases — the question stands alone.
4. **One ListSpans call** after the terminal response.
5. **Extract retrieved chunks** from every `execute_tool` span whose tool name matches the agent's `Retrieve` tool name (resolved at run start from the AgentSnapshot — typically `Retrieve` but the snapshot is authoritative).

For each chunk:
- `text` — the chunk content, preserved verbatim including embedded whitespace and newlines.
- `knowledgeBaseId`, `contentId`, `title` — pulled from the corresponding `SpanCitation` objects when present.
- `index` — monotonic ordinal across the case's chunks.

The chunks are persisted on the `TestCaseResult` under `retrievedChunks: RetrievedChunk[]`. If the agent never invoked Retrieve, `retrievedChunks` is the empty array `[]` (not absent). Faithfulness scoring against zero chunks is informative — typically scores low — and surfaces as a normal failure rather than an error.

If the conversation driver itself fails (timeout, session error, throttle exhaustion), the case is marked `error`, `retrievedChunks` is left unset, and the case is **excluded from Stage 2**.

## Stage 2 — Bedrock RAG evaluation

The run pipeline branches based on suite content:

- **Suite has zero RAG cases** → existing single-stage flow, no Stage 2.
- **Suite has at least one RAG case** → Two_Stage_Run: Stage 1 (`ExecuteCases`) + Stage 2 (`RAG_Evaluate`).

Stage 2:

1. Filter to RAG cases that completed Stage 1 with a captured agent response (skip errored cases).
2. Build one BYOI JSONL line per surviving case — see [Dataset format](#dataset-format) below.
3. Upload to `s3://{RAG_Job_Bucket}/{runId}/input.jsonl`.
4. Call `bedrock:CreateEvaluationJob` once with all lines batched.
5. Poll `bedrock:GetEvaluationJob` every 30s. Hard cap: 30 minutes.
6. On `COMPLETED`: read per-prompt metric output from S3, join by prompt index back to caseId, persist scores per case.

If every RAG case errored in Stage 1, the platform skips `CreateEvaluationJob` entirely and advances the run.

## Dataset format

The platform builds Bedrock's BYOI retrieve-and-generate JSONL format. One line per case. Source: `src/backend/orchestration/jsonl-serializer.ts`.

```json
{
  "conversationTurns": [
    {
      "prompt": {
        "content": [{ "text": "<verbatim case.question>" }]
      },
      "referenceResponses": [
        {
          "content": [{ "text": "<verbatim case.groundTruthAnswer>" }]
        }
      ],
      "output": {
        "text": "<verbatim agent terminal response>",
        "knowledgeBaseIdentifier": "<first non-empty chunk's KB id, or 'connect-orchestration-retrieve'>",
        "modelIdentifier": "<agent's model id from snapshot>",
        "retrievedPassages": {
          "retrievalResults": [
            {
              "content": { "text": "<verbatim chunk text>" },
              "name": "<chunk.title if present>",
              "metadata": {
                "contentId": "<chunk.contentId>",
                "knowledgeBaseId": "<chunk.knowledgeBaseId>"
              }
            }
          ]
        }
      }
    }
  ]
}
```

A line-index → caseId mapping is persisted at `PK=RUN#{runId}, SK=RAGJOB` so per-prompt output can be joined back to caseId regardless of how Bedrock orders results.

## Metrics and thresholds

Bedrock's built-in metric set for retrieve-and-generate evaluations scores four metrics per prompt:

| Metric | What it measures |
|---|---|
| **Faithfulness** | Is the agent's response grounded in the retrieved chunks? Equivalent to the user-facing concept of "groundedness". |
| **Correctness** | Does the response factually match the ground truth? |
| **Completeness** | Does the response cover everything the ground truth covers? |
| **Helpfulness** | Holistic usefulness from the customer's perspective. The closest analog to the "Relevance" metric in the retrieve-only metric set, but measured on the end-to-end response. |

> **Why not `ContextRelevance`?** That metric exists only in Bedrock's retrieve-only evaluation set, which scores retrievers in isolation. The platform tests end-to-end RAG responses through the live Connect agent, so retrieve-and-generate evaluators apply. `Helpfulness` is the closest holistic-usefulness proxy in this metric set.

Each metric returns a `[0, 1]` score. They're persisted on `TestCaseResult.ragMetrics`:

```typescript
ragMetrics?: {
  faithfulness?: number;
  correctness?: number;
  completeness?: number;
  helpfulness?: number;
};
```

### Suite-level thresholds

Configurable on the `TestSuite` record:

```typescript
ragThresholds?: {
  faithfulness: number;   // [0, 1], default 0.7
  correctness: number;
  completeness: number;
  helpfulness: number;
}
```

Default values from `src/shared/types.ts` `DEFAULT_RAG_THRESHOLDS`. When a suite has no `ragThresholds`, defaults apply at read time.

### Pass/fail logic

For each RAG case:

1. **Faithfulness hard gate**: if `faithfulness < ragThresholds.faithfulness`, the case **fails** regardless of any other score.
2. Otherwise, AND across the remaining metrics: every threshold (`correctness`, `completeness`, `helpfulness`) must be met for `passed`.

The hard gate prevents the platform from passing a hallucinated answer just because it happened to be helpful and complete on paper.

## Error states for RAG cases

Beyond the standard `Evaluation_Error_State` codes used by the Bedrock judge for tool-sequence cases, RAG cases can carry these:

| Code | Meaning |
|---|---|
| `RAG_JOB_FAILED` | Bedrock's evaluation job returned a `FAILED` status. |
| `RAG_JOB_TIMEOUT` | The job didn't complete within the 30-minute hard cap. |
| `INSUFFICIENT_RAG_DATA` | Stage 1 produced an `error` for this case for reasons other than the case's own driver error (e.g. snapshot missing). |

When any of these are set, `ragMetrics` is absent and the case is marked `error`.

## Mixed suites

A suite may freely contain both `tool_sequence` and `rag` cases. The pipeline runs all cases through Stage 1 (the conversation driver branches on type), then runs Stage 2 only if at least one RAG case completed.

The Bedrock judge evaluation (Stage 3 — `goalSuccessScore`, `helpfulnessScore`, `toolAccuracyScore`) runs for tool-sequence cases regardless. RAG cases are not scored by the Bedrock judge in addition to their RAG metrics — `ragMetrics` is the canonical scoring for RAG cases.

## Cost

Bedrock RAG evaluation is more expensive per case than the Bedrock judge. Typical magnitude: $0.10–$0.30 per case depending on chunk count.

For cost-conscious runs:
- Keep RAG suite sizes modest (~10–30 cases).
- Use development-mode iteration on a small subset before running the full suite.
- The dataset is batched into one job per run, so suite size matters more than run frequency for this category.
