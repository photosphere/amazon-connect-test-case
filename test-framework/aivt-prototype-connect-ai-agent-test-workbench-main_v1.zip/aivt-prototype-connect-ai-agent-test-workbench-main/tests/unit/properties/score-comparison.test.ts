// Feature: platform-hosting-and-evaluations, Property 14: Score-delta classification is sign-consistent and not-comparable on absence
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { compareScores, METRIC_KEYS } from "@shared/utils/score-comparison";
import { CaseStatus } from "@shared/enums";
import type { TestCaseResult } from "@shared/types";

/**
 * Property tests for the score-comparison module
 * (`src/shared/utils/score-comparison.ts`).
 *
 * Property 14 lives in this file. Property 15 (task 20.3) will be appended
 * later as a sibling top-level `describe` block.
 *
 * The module under test is pure and has no AWS imports, so this test
 * exercises its real behaviour without any mocking.
 */

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/**
 * Small caseId space biases the two generated runs toward sharing many
 * caseIds, so the property exercises the "case present in both runs" branch
 * frequently rather than degenerating into mostly add/remove pairs (which
 * `compareScores` deliberately ignores — those are owned by `compareRuns`).
 */
const caseIdArb: fc.Arbitrary<string> = fc
  .integer({ min: 0, max: 20 })
  .map((n) => `case-${n}`);

/**
 * A finite score value in [0, 1] — the contract documented on
 * `TestCaseResult`'s three score fields.
 */
const finiteScoreArb: fc.Arbitrary<number> = fc.double({
  min: 0,
  max: 1,
  noNaN: true,
  noDefaultInfinity: true,
});

/**
 * Each metric is independently either present (a finite [0, 1] value) or
 * absent (`undefined`). Independent absence per metric is essential — the
 * helper classifies each metric in isolation.
 */
const optionalScoreArb: fc.Arbitrary<number | undefined> = fc.option(
  finiteScoreArb,
  { nil: undefined }
);

/**
 * A scored case: `evaluationError` is unset, and any subset of the three
 * score fields may be set. Score fields are conditionally assigned so
 * absent fields are structurally absent (mirroring how `removeUndefinedValues`
 * persists results).
 */
const scoredCaseArb = (caseId: string): fc.Arbitrary<TestCaseResult> =>
  fc
    .record({
      goalSuccessScore: optionalScoreArb,
      helpfulnessScore: optionalScoreArb,
      toolAccuracyScore: optionalScoreArb,
    })
    .map((scores) => {
      const result: TestCaseResult = {
        runId: "r",
        caseId,
        status: CaseStatus.PASSED,
        toolsInvoked: [],
        turnCount: 1,
        latencyMs: 100,
      };
      if (scores.goalSuccessScore !== undefined) {
        result.goalSuccessScore = scores.goalSuccessScore;
      }
      if (scores.helpfulnessScore !== undefined) {
        result.helpfulnessScore = scores.helpfulnessScore;
      }
      if (scores.toolAccuracyScore !== undefined) {
        result.toolAccuracyScore = scores.toolAccuracyScore;
      }
      return result;
    });

/**
 * An Evaluation_Error_State case: `evaluationError` is set and all three
 * score fields are unset (per Req 10.3, structurally enforced on
 * `TestCaseResult`). Each error-state case forces the not-comparable
 * branch for all three metrics whenever the same caseId is present on the
 * other side.
 */
const errorCaseArb = (caseId: string): fc.Arbitrary<TestCaseResult> =>
  fc
    .record({
      reason: fc.string({ minLength: 1, maxLength: 30 }),
      code: fc.constantFrom(
        "INSUFFICIENT_TRACE",
        "TIMEOUT",
        "JUDGE_ERROR",
        "UNMAPPABLE_RESULT",
        "MISSING_EVALUATOR"
      ) as fc.Arbitrary<
        NonNullable<TestCaseResult["evaluationError"]>["code"]
      >,
    })
    .map((err) => ({
      runId: "r",
      caseId,
      status: CaseStatus.ERROR,
      toolsInvoked: [],
      turnCount: 0,
      latencyMs: 0,
      evaluationError: { reason: err.reason, code: err.code },
      // Score fields deliberately unset — Evaluation_Error_State (Req 10.3).
    }));

/**
 * A `TestCaseResult` for a given caseId — usually scored, sometimes in the
 * Evaluation_Error_State, so the absence-handling branch (Req 15.3) is
 * exercised on a meaningful fraction of generated inputs.
 */
const caseResultArb = (caseId: string): fc.Arbitrary<TestCaseResult> =>
  fc.oneof(
    { weight: 4, arbitrary: scoredCaseArb(caseId) },
    { weight: 1, arbitrary: errorCaseArb(caseId) }
  );

/** A single `TestCaseResult` with an arbitrary caseId. */
const anyCaseResultArb: fc.Arbitrary<TestCaseResult> = caseIdArb.chain((id) =>
  caseResultArb(id)
);

/** A run is a list of `TestCaseResult`s with unique caseIds. */
const runArb: fc.Arbitrary<TestCaseResult[]> = fc.uniqueArray(
  anyCaseResultArb,
  {
    minLength: 0,
    maxLength: 15,
    selector: (r) => r.caseId,
  }
);

// ---------------------------------------------------------------------------
// Property 14
// ---------------------------------------------------------------------------

/** Local mirror of the helper's "is this a comparable numeric value" test. */
const isFiniteNumber = (v: unknown): v is number =>
  typeof v === "number" && Number.isFinite(v);

/**
 * **Validates: Requirements 15.1, 15.2, 15.3**
 *
 * Property 14: Score-delta classification is sign-consistent and
 * not-comparable on absence.
 *
 * For every pair of runs and every case present in both runs, and for each
 * metric (`goalSuccessScore`, `helpfulnessScore`, `toolAccuracyScore`):
 *
 *  - When both runs have a finite numeric value for the metric,
 *    `compareScores` sets `delta = later − earlier` and classifies the delta
 *    `improved` iff `delta > 0`, `regressed` iff `delta < 0`, and
 *    `unchanged` iff `delta == 0` (Reqs 15.1, 15.2).
 *  - When the metric is present in exactly one of the two runs — including
 *    the case where one side is in the Evaluation_Error_State and therefore
 *    has all three score fields unset — classification is `not-comparable`
 *    with no numeric delta (Req 15.3).
 *
 * The property also asserts the structural invariants the helper documents:
 * matching is by caseId, every emitted entry corresponds to a caseId present
 * in both runs, and conversely every shared caseId appears in `entries` (so
 * cases are never silently dropped).
 */
describe("Property 14: Score-delta classification is sign-consistent and not-comparable on absence", () => {
  it("classifies each metric by sign of (later − earlier) and not-comparable on either-side absence", () => {
    fc.assert(
      fc.property(runArb, runArb, (runA, runB) => {
        const result = compareScores(runA, runB);

        const mapA = new Map(runA.map((r) => [r.caseId, r]));
        const mapB = new Map(runB.map((r) => [r.caseId, r]));

        // Structural invariant: every emitted entry is a caseId present in
        // both runs. Added/removed cases are owned by `compareRuns`, not by
        // `compareScores`.
        for (const entry of result.entries) {
          expect(mapA.has(entry.caseId)).toBe(true);
          expect(mapB.has(entry.caseId)).toBe(true);
        }

        // And: every shared caseId appears in entries — no silent drops.
        const sharedIds = [...mapA.keys()].filter((id) => mapB.has(id));
        expect(result.entries.length).toBe(sharedIds.length);

        // Per-case, per-metric classification invariant (the heart of P14).
        for (const entry of result.entries) {
          const earlier = mapA.get(entry.caseId)!;
          const later = mapB.get(entry.caseId)!;

          for (const metric of METRIC_KEYS) {
            const md = entry.metrics[metric];
            expect(md.metric).toBe(metric);

            const earlierVal = earlier[metric];
            const laterVal = later[metric];
            const haveEarlier = isFiniteNumber(earlierVal);
            const haveLater = isFiniteNumber(laterVal);

            if (!haveEarlier || !haveLater) {
              // Req 15.3 — not-comparable on absence. This branch covers
              // both "scored case with this metric unset" and
              // "Evaluation_Error_State case with all metrics unset".
              expect(md.classification).toBe("not-comparable");
              expect(md.delta).toBeUndefined();
            } else {
              // Reqs 15.1, 15.2 — exact `later − earlier` delta with
              // sign-consistent classification.
              const expectedDelta =
                (laterVal as number) - (earlierVal as number);
              expect(md.delta).toBe(expectedDelta);

              if (expectedDelta > 0) {
                expect(md.classification).toBe("improved");
              } else if (expectedDelta < 0) {
                expect(md.classification).toBe("regressed");
              } else {
                expect(md.classification).toBe("unchanged");
              }
            }
          }
        }
      }),
      { numRuns: 100 }
    );
  });
});

// ---------------------------------------------------------------------------
// Property 15
// ---------------------------------------------------------------------------

// Feature: platform-hosting-and-evaluations, Property 15: Per-metric comparison summary counts are exhaustive

/**
 * **Validates: Requirements 15.4**
 *
 * Property 15: Per-metric comparison summary counts are exhaustive.
 *
 * For every pair of runs and every metric (`goalSuccessScore`,
 * `helpfulnessScore`, `toolAccuracyScore`):
 *
 *  - The four bucket counts on `summary.perMetric[metric]`
 *    (`improved` + `regressed` + `unchanged` + `notComparable`) sum to
 *    the number of cases present in both runs (i.e. `entries.length`).
 *    No case is silently dropped, and none is double-counted (Req 15.4).
 *  - Each bucket count exactly equals the number of `entries` whose
 *    `metrics[metric].classification` matches that bucket — so the summary
 *    is a faithful tally of the per-case classifications, not an
 *    independent count that could drift.
 *  - Every count is a non-negative integer (a basic sanity invariant on a
 *    counter-summary).
 */
describe("Property 15: Per-metric comparison summary counts are exhaustive", () => {
  it("per-metric bucket counts sum to shared-case count and tally entries exactly", () => {
    fc.assert(
      fc.property(runArb, runArb, (runA, runB) => {
        const result = compareScores(runA, runB);

        const sharedCount = result.entries.length;

        for (const metric of METRIC_KEYS) {
          const counts = result.summary.perMetric[metric];

          // Non-negative integer counts.
          expect(Number.isInteger(counts.improved)).toBe(true);
          expect(Number.isInteger(counts.regressed)).toBe(true);
          expect(Number.isInteger(counts.unchanged)).toBe(true);
          expect(Number.isInteger(counts.notComparable)).toBe(true);
          expect(counts.improved).toBeGreaterThanOrEqual(0);
          expect(counts.regressed).toBeGreaterThanOrEqual(0);
          expect(counts.unchanged).toBeGreaterThanOrEqual(0);
          expect(counts.notComparable).toBeGreaterThanOrEqual(0);

          // Exhaustiveness: the four buckets cover every comparable case
          // exactly once. No silent drops, no double-counting.
          expect(
            counts.improved +
              counts.regressed +
              counts.unchanged +
              counts.notComparable
          ).toBe(sharedCount);

          // Each bucket count exactly tallies the matching entries —
          // the summary is a faithful aggregate, not an independent count.
          const expectedImproved = result.entries.filter(
            (e) => e.metrics[metric].classification === "improved"
          ).length;
          const expectedRegressed = result.entries.filter(
            (e) => e.metrics[metric].classification === "regressed"
          ).length;
          const expectedUnchanged = result.entries.filter(
            (e) => e.metrics[metric].classification === "unchanged"
          ).length;
          const expectedNotComparable = result.entries.filter(
            (e) => e.metrics[metric].classification === "not-comparable"
          ).length;

          expect(counts.improved).toBe(expectedImproved);
          expect(counts.regressed).toBe(expectedRegressed);
          expect(counts.unchanged).toBe(expectedUnchanged);
          expect(counts.notComparable).toBe(expectedNotComparable);
        }
      }),
      { numRuns: 100 }
    );
  });
});
