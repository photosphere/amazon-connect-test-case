/**
 * Score mapping & aggregation — pure, standalone module.
 *
 * Reduces raw AgentCore evaluator results into the three numeric scores
 * persisted on a `TestCaseResult` and lists any requested-but-absent
 * evaluators so the caller can record an `Evaluation_Error_State`.
 *
 * Mapping rules (Requirements 8.3, 8.4, 8.7; design §2.3):
 * - `Builtin.GoalSuccessRate` is session-level: the single result's `value`
 *   passed through `clamp01` becomes `goalSuccessScore`.
 * - `Builtin.Helpfulness` is trace-level: each per-assistant-turn result
 *   contributes a numeric `value`; their unweighted arithmetic mean,
 *   clamped to `[0,1]`, becomes `helpfulnessScore`.
 * - `Builtin.ToolSelectionAccuracy` is tool-level: each per-tool-call
 *   result contributes a numeric `value`; their unweighted arithmetic mean,
 *   clamped to `[0,1]`, becomes `toolAccuracyScore`. This score must
 *   originate only from AgentCore — `calculateToolAccuracy` is never used
 *   here as a substitute (Requirement 10.6).
 * - Every emitted score passes through `clamp01` so out-of-range judge
 *   outputs (e.g. 1.4 from a misbehaving model) become `1.0` and negative
 *   outputs become `0.0` (Requirement 8.3).
 * - Non-finite values (`NaN`, `Infinity`, `-Infinity`) and entries without
 *   a numeric `value` are not "usable" and are excluded from aggregation.
 *   When a requested evaluator has no usable numeric result, its score is
 *   left unset and the evaluator id is added to `missingEvaluators`
 *   (Requirement 8.7).
 *
 * This module has no AWS imports so it is unit- and property-testable
 * without a deploy. The `EvaluationResultContent` interface mirrors the
 * subset of the AgentCore `EvaluationResultContent` shape this module
 * actually consumes; the thin AgentCore client wrapper (task 15.1) will
 * re-declare or re-export the same fields.
 *
 * @module evaluation-scoring
 */

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/** Built-in evaluator ids the platform requests for every test case. */
export const REQUESTED_EVALUATOR_IDS = [
  "Builtin.GoalSuccessRate",
  "Builtin.Helpfulness",
  "Builtin.ToolSelectionAccuracy",
] as const;

/** A literal of the three evaluator ids this module knows how to map. */
export type RequestedEvaluatorId = (typeof REQUESTED_EVALUATOR_IDS)[number];

/**
 * Minimal local mirror of the AgentCore `EvaluationResultContent` shape.
 *
 * Only `value` is used by this module; the other fields are accepted
 * (optionally) so callers can pass raw SDK responses through unchanged.
 * The AgentCore client wrapper (task 15.1) will define the fully-typed
 * interface; this declaration is intentionally minimal so this module
 * stays free of AWS SDK imports.
 */
export interface EvaluationResultContent {
  /** Numeric score on the evaluator's rating scale (0.0–1.0 for built-ins). */
  value?: number;
  /** Optional human-readable label produced by the evaluator. */
  label?: string;
  /** Optional explanation/reasoning string from the judge. */
  explanation?: string;
  /** Optional error code when the evaluator failed for this unit. */
  errorCode?: string;
  /** Optional error message accompanying `errorCode`. */
  errorMessage?: string;
}

/** Per-evaluator results returned by an AgentCore `Evaluate` call. */
export interface EvaluatorOutcome {
  /** Evaluator id, e.g. `"Builtin.GoalSuccessRate"`. */
  evaluatorId: string;
  /** Raw results array from the evaluator (1+ entries; may be empty on error). */
  results: EvaluationResultContent[];
}

/** Output of `aggregateScores` — what gets persisted on a `TestCaseResult`. */
export interface AggregatedScores {
  /** Session-level goal-success score, clamped to `[0,1]`; unset when missing. */
  goalSuccessScore?: number;
  /** Mean of per-turn helpfulness scores, clamped to `[0,1]`; unset when missing. */
  helpfulnessScore?: number;
  /** Mean of per-tool-call tool-selection scores, clamped to `[0,1]`; unset when missing. */
  toolAccuracyScore?: number;
  /**
   * Subset of the three requested evaluator ids whose outcome had no usable
   * numeric result (or was absent from the input entirely). The caller
   * records an `Evaluation_Error_State` naming these evaluators.
   */
  missingEvaluators: string[];
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

/**
 * Returns `true` iff `v` is a finite number — i.e. not `NaN`, not
 * `Infinity`, and not `-Infinity`. Non-numeric or missing values return
 * `false`. Used to filter raw evaluator `value` fields before aggregation.
 */
function isUsableNumber(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

/**
 * Pulls every usable finite numeric `value` out of an evaluator's results,
 * preserving order. Non-finite values and entries without a numeric
 * `value` are silently dropped.
 */
function usableValues(results: readonly EvaluationResultContent[] | undefined): number[] {
  if (!results) return [];
  const out: number[] = [];
  for (const r of results) {
    if (isUsableNumber(r.value)) {
      out.push(r.value);
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Clamps a numeric value into the inclusive range `[0, 1]`.
 *
 * - Values strictly less than `0` are stored as `0`.
 * - Values strictly greater than `1` are stored as `1`.
 * - Finite values within `[0, 1]` are returned unchanged.
 * - Non-finite inputs (`NaN`, `Infinity`, `-Infinity`) collapse to `0`,
 *   which keeps the function total: every emitted score is guaranteed to
 *   be a finite number in `[0, 1]`. Callers should filter out non-finite
 *   evaluator outputs before clamping if they want them treated as
 *   missing rather than as `0`.
 *
 * @param v - The raw evaluator value
 * @returns The clamped value in `[0, 1]`
 */
export function clamp01(v: number): number {
  if (!Number.isFinite(v)) return 0;
  if (v < 0) return 0;
  if (v > 1) return 1;
  return v;
}

/**
 * Computes the unweighted arithmetic mean of a list of numeric values.
 *
 * Returns `undefined` for an empty input list — there is no meaningful
 * mean of zero observations, and the caller should treat the absence as
 * "no usable result" (and add the evaluator to `missingEvaluators`).
 *
 * The mean is **not** clamped here; callers that need a clamped score
 * should compose `clamp01(aggregateMean(...) ?? NaN)` or check for
 * `undefined` before clamping.
 *
 * @param values - The numeric values to average (typically pre-filtered to finite numbers)
 * @returns The arithmetic mean, or `undefined` when `values` is empty
 */
export function aggregateMean(values: number[]): number | undefined {
  if (values.length === 0) return undefined;
  let sum = 0;
  for (const v of values) {
    sum += v;
  }
  return sum / values.length;
}

/**
 * Reduces the raw outcomes from the three requested AgentCore evaluators
 * into the three persisted scores plus a `missingEvaluators` list.
 *
 * Per Requirement 8.3 / 8.4:
 * - `Builtin.GoalSuccessRate` → `goalSuccessScore` is the **first usable
 *   numeric value** from that outcome's results, passed through
 *   `clamp01`. Multiple results are tolerated for robustness, but the
 *   evaluator is session-level so a single result is the expected case.
 * - `Builtin.Helpfulness` → `helpfulnessScore` is the unweighted
 *   arithmetic mean of every usable numeric `value` across all per-turn
 *   results, passed through `clamp01`.
 * - `Builtin.ToolSelectionAccuracy` → `toolAccuracyScore` is the
 *   unweighted arithmetic mean of every usable numeric `value` across
 *   all per-tool-call results, passed through `clamp01`.
 *
 * Per Requirement 8.7, an evaluator is reported as missing when:
 * - it is absent from `outcomes` entirely, OR
 * - it is present but has zero usable numeric results (every entry has a
 *   non-numeric / non-finite `value`).
 *
 * In either case the corresponding score field is left `undefined`, so
 * the structural invariant "an error state leaves all three scores
 * unset for that evaluator" holds (Property 12, Requirement 10.3).
 *
 * Outcomes for evaluator ids outside the three requested ones are
 * silently ignored — the platform does not request them and does not
 * map them anywhere.
 *
 * @param outcomes - One entry per evaluator returned by the AgentCore client
 * @returns The mapped scores and the missing-evaluator list
 */
export function aggregateScores(outcomes: EvaluatorOutcome[]): AggregatedScores {
  // Index outcomes by evaluator id; the LAST occurrence wins if a caller
  // (incorrectly) supplies duplicates. The three known ids are extracted
  // by lookup so the function does not depend on the input order.
  const byId = new Map<string, EvaluatorOutcome>();
  for (const outcome of outcomes) {
    byId.set(outcome.evaluatorId, outcome);
  }

  const aggregated: AggregatedScores = { missingEvaluators: [] };

  // -------------------------------------------------------------------------
  // Goal success — session-level, single value (Req 8.3)
  // -------------------------------------------------------------------------
  const goalOutcome = byId.get("Builtin.GoalSuccessRate");
  const goalValues = usableValues(goalOutcome?.results);
  if (goalValues.length > 0) {
    aggregated.goalSuccessScore = clamp01(goalValues[0]);
  } else {
    aggregated.missingEvaluators.push("Builtin.GoalSuccessRate");
  }

  // -------------------------------------------------------------------------
  // Helpfulness — per-turn arithmetic mean (Req 8.4)
  // -------------------------------------------------------------------------
  const helpfulnessOutcome = byId.get("Builtin.Helpfulness");
  const helpfulnessValues = usableValues(helpfulnessOutcome?.results);
  const helpfulnessMean = aggregateMean(helpfulnessValues);
  if (helpfulnessMean !== undefined) {
    aggregated.helpfulnessScore = clamp01(helpfulnessMean);
  } else {
    aggregated.missingEvaluators.push("Builtin.Helpfulness");
  }

  // -------------------------------------------------------------------------
  // Tool accuracy — per-tool-call arithmetic mean (Req 8.4, Req 10.6)
  // -------------------------------------------------------------------------
  const toolAccuracyOutcome = byId.get("Builtin.ToolSelectionAccuracy");
  const toolAccuracyValues = usableValues(toolAccuracyOutcome?.results);
  const toolAccuracyMean = aggregateMean(toolAccuracyValues);
  if (toolAccuracyMean !== undefined) {
    aggregated.toolAccuracyScore = clamp01(toolAccuracyMean);
  } else {
    aggregated.missingEvaluators.push("Builtin.ToolSelectionAccuracy");
  }

  return aggregated;
}

// ---------------------------------------------------------------------------
// Score_Scale tables — Bedrock-judge categorical-label → [0.0, 1.0] mappings
// ---------------------------------------------------------------------------

/**
 * Score_Scale for `Builtin.GoalSuccessRate` (Requirement 4.1, 4.2).
 *
 * Two-label categorical rubric mapped to the persisted `[0.0, 1.0]` range.
 * Source of truth: `.kiro/steering/bedrock-judge-prompts.md` § 1.
 *
 * Any label not present in this table is unmappable and SHALL surface as
 * `Evaluation_Error_State` code `UNMAPPABLE_RESULT`; callers MUST NOT
 * silently substitute a default value (Requirement 4.4).
 */
export const GOAL_SUCCESS_SCALE: Readonly<Record<string, number>> = {
  Yes: 1.0,
  No: 0.0,
};

/**
 * Score_Scale for `Builtin.ToolSelectionAccuracy` (Requirement 4.1, 4.2).
 *
 * Two-label categorical rubric mapped to the persisted `[0.0, 1.0]` range.
 * Source of truth: `.kiro/steering/bedrock-judge-prompts.md` § 3.
 *
 * Any label not present in this table is unmappable and SHALL surface as
 * `Evaluation_Error_State` code `UNMAPPABLE_RESULT` (Requirement 4.4).
 */
export const TOOL_SELECTION_SCALE: Readonly<Record<string, number>> = {
  Yes: 1.0,
  No: 0.0,
};

/**
 * Score_Scale for `Builtin.Helpfulness` (Requirement 4.1, 4.2).
 *
 * Seven-level ordinal categorical rubric mapped uniformly in steps of
 * `1/6` from `Not Helpful At All` (`0/6 = 0.0`) to `Above And Beyond`
 * (`6/6 = 1.0`). The values are written as literal `n / 6` divisions so
 * the constants are the exact IEEE-754 floats those divisions produce
 * rather than truncated decimals (matching the steering doc byte-for-byte).
 *
 * Source of truth: `.kiro/steering/bedrock-judge-prompts.md` § 2.
 *
 * Any label not present in this table is unmappable and SHALL surface as
 * `Evaluation_Error_State` code `UNMAPPABLE_RESULT` (Requirement 4.4).
 */
export const HELPFULNESS_SCALE: Readonly<Record<string, number>> = {
  "Not Helpful At All": 0 / 6,
  "Very Unhelpful": 1 / 6,
  "Somewhat Unhelpful": 2 / 6,
  "Neutral/Mixed": 3 / 6,
  "Somewhat Helpful": 4 / 6,
  "Very Helpful": 5 / 6,
  "Above And Beyond": 6 / 6,
};

/**
 * Looks up `label` in the supplied Score_Scale and returns its mapped
 * decimal value, or `undefined` when the label is not a known key.
 *
 * Per Requirement 4.4 the function does NOT throw, does NOT default to
 * zero, and does NOT trim or normalize the label — `undefined` is the
 * caller's signal to raise `Evaluation_Error_State` code
 * `UNMAPPABLE_RESULT`. The lookup uses `Object.prototype.hasOwnProperty`
 * so inherited names like `toString` or `constructor` cannot accidentally
 * resolve as valid scale entries.
 *
 * @param scale - One of `GOAL_SUCCESS_SCALE`, `TOOL_SELECTION_SCALE`, or `HELPFULNESS_SCALE`
 * @param label - The raw `score` label string returned by the Bedrock_Judge
 * @returns The mapped value in `[0.0, 1.0]`, or `undefined` when `label` is unknown
 */
export function mapScoreLabel(
  scale: Readonly<Record<string, number>>,
  label: string,
): number | undefined {
  return Object.prototype.hasOwnProperty.call(scale, label) ? scale[label] : undefined;
}
