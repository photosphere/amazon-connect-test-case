/**
 * Opportunistic Faithfulness Evaluator — inline Converse-based scorer for
 * tool-sequence cases that happen to invoke the Retrieve tool.
 *
 * Sends a single Bedrock Converse call with a focused Faithfulness prompt,
 * asking the judge to score groundedness on [0,1]. Designed to fit within
 * the ~3-5s per-case budget in Stage 1.
 *
 * Resolves the `judge_opportunistic_faithfulness` prompt for the
 * executing run via {@link resolvePromptForRun} (R11.2 / R11.3 — the
 * run's pinned snapshot is the source of truth, falling back to the
 * live registry for pre-feature runs). The Bedrock Converse
 * `inferenceConfig` is shaped by {@link buildInferenceConfig} to match
 * the resolved model's capability profile (R17.4).
 *
 * Migrated from the legacy `judgeModelId` argument and the inline
 * `inferenceConfig: { maxTokens, temperature: 0 }` construction to the
 * registry (Wave 2 — Task 17.6 of the prompt-management spec). The
 * legacy `JUDGE_MODEL_ID` env var is still set in
 * `lib/orchestration-construct.ts` as a Wave-2 safety net and is
 * removed in Wave 3.
 *
 * Failure mode: returns `undefined` and logs a warning — never throws,
 * never blocks the case. A {@link PromptResolutionError} from the
 * resolver is treated the same way (logged + returns undefined) so an
 * outage of the Prompts_Store cannot fail the run; the case still
 * completes, just without a faithfulness score.
 *
 * Validates: Requirements 12.1, 12.2, 12.3, 12.4, 12.5, 12.7, 12.9,
 * 12.10, 12.11, 1.3, 10.1, 10.3, 11.2, 11.3, 17.4.
 *
 * @module opportunistic-faithfulness
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ContentBlock,
  type ConverseCommandInput,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";
import { withThrottleRetry } from "../../shared/utils/backoff";
import type { RetrievedChunk } from "../../shared/types";
import {
  buildInferenceConfig,
  type ResolvedPrompt,
} from "./prompt-registry";
import { resolvePromptForRun } from "./prompt-registry/runtime";
import { fillTemplate } from "./bedrock-judge-client";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";

/** Per-call timeout for the Converse invocation (15s per design). */
const FAITHFULNESS_TIMEOUT_MS = 15_000;

/** Retry posture for ThrottlingException (R12.2). */
const RETRY_OPTIONS = { baseMs: 1000, capMs: 10000, maxRetries: 2 } as const;

// ---------------------------------------------------------------------------
// Bedrock client (lazy singleton; injectable for tests)
// ---------------------------------------------------------------------------

type SendableBedrockClient = Pick<BedrockRuntimeClient, "send">;

let bedrockClient: SendableBedrockClient | null = null;

function getBedrockClient(): SendableBedrockClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

/**
 * Test-only injector for the Bedrock runtime client.
 * @internal
 */
export function _setBedrockClient(client: SendableBedrockClient | null): void {
  bedrockClient = client;
}

/**
 * Test-only reset for the cached singleton.
 * @internal
 */
export function _resetBedrockClient(): void {
  bedrockClient = null;
}

// ---------------------------------------------------------------------------
// Prompt construction
// ---------------------------------------------------------------------------

/**
 * Render the registry-resolved faithfulness template against the
 * supplied passages and agent response. The prompt definition declares
 * `{passages}` and `{agent_response}` placeholders (matching the file
 * `src/backend/orchestration/prompt-registry/prompts/judge-opportunistic-faithfulness.ts`);
 * the embedded `{"score": <number ...>}` JSON sample in the template
 * tail is registered as a literal-brace region so the validation
 * pipeline does not flag it as an unknown placeholder, and the
 * `fillTemplate` helper's `split.join` semantics leave it untouched
 * because `score` is not a key in the vars map.
 */
function buildFaithfulnessVars(
  agentResponse: string,
  chunks: RetrievedChunk[],
): Record<string, string> {
  const passages = chunks
    .map((chunk, i) => `${i + 1}. ${chunk.text}`)
    .join("\n");
  return {
    passages,
    agent_response: agentResponse,
  };
}

// ---------------------------------------------------------------------------
// Response parsing
// ---------------------------------------------------------------------------

/**
 * Parse the model's JSON response to extract the score.
 * Returns undefined if the response is not a valid `{"score": <number>}`.
 */
function parseScoreResponse(rawText: string): number | undefined {
  try {
    // Try to extract JSON from fenced code blocks first, then raw text
    let jsonStr = rawText.trim();
    const fenceMatch = rawText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (fenceMatch) {
      jsonStr = fenceMatch[1].trim();
    } else {
      const start = rawText.indexOf("{");
      const end = rawText.lastIndexOf("}");
      if (start >= 0 && end > start) {
        jsonStr = rawText.slice(start, end + 1);
      }
    }

    const parsed = JSON.parse(jsonStr);
    if (
      parsed &&
      typeof parsed === "object" &&
      typeof parsed.score === "number" &&
      parsed.score >= 0 &&
      parsed.score <= 1
    ) {
      return parsed.score;
    }
    return undefined;
  } catch {
    return undefined;
  }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Evaluate the faithfulness of an agent's response against retrieved
 * chunks using a single Bedrock Converse call.
 *
 * Returns a score in [0,1] on success, or `undefined` on any failure
 * (parse error, throttle after retries, model error, timeout,
 * resolver error). Never throws — opportunistic faithfulness is
 * best-effort scoring that must never block the case.
 *
 * R11.2 / R11.3: the prompt is resolved exactly once at the top of
 * the function via {@link resolvePromptForRun}. The resolver's
 * per-warm cache (keyed by `runId`) means a fan-out over multiple
 * RAG-using cases inside the same Lambda warm reuses the cached
 * snapshot read without hitting DynamoDB again.
 *
 * @param agentResponse - The agent's terminal response text.
 * @param chunks - Retrieved passages from the Retrieve tool invocation.
 * @param runId - The run id whose pinned snapshot supplies the prompt
 *               (empty string falls back to the live registry — used
 *               by unit tests and the rare pre-feature run path).
 */
export async function evaluateOpportunisticFaithfulness(
  agentResponse: string,
  chunks: RetrievedChunk[],
  runId: string,
): Promise<number | undefined> {
  // R11.2 / R11.3: resolve the prompt once per call. The runtime
  // helper caches the snapshot read per warm so an outer caller
  // iterating over many cases issues at most one DDB read per
  // `runId`. Resolver failures are treated as best-effort (logged +
  // return undefined) so a Prompts_Store outage cannot block the
  // case — this scorer is opportunistic by design.
  let prompt: ResolvedPrompt;
  try {
    prompt = await resolvePromptForRun(
      "judge_opportunistic_faithfulness",
      runId,
    );
  } catch (err) {
    console.warn(
      "[opportunistic-faithfulness] Failed to resolve prompt:",
      err instanceof Error ? err.message : err,
    );
    return undefined;
  }

  try {
    const renderedPrompt = fillTemplate(
      prompt.text,
      buildFaithfulnessVars(agentResponse, chunks),
    );
    const messages: Message[] = [
      { role: "user", content: [{ text: renderedPrompt }] as ContentBlock[] },
    ];

    // The wire-shape helper places the resolved inference parameters
    // into the exact arguments the Converse SDK expects for the
    // resolved model's capability profile. Same pattern as
    // `bedrock-judge-client.ts`, `variant-generator.ts`, etc.
    const built = buildInferenceConfig(prompt);

    const command = new ConverseCommand({
      modelId: prompt.modelId,
      messages,
      inferenceConfig:
        built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
      ...(built.additionalModelRequestFields
        ? {
            additionalModelRequestFields:
              built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
          }
        : {}),
    });

    // Timeout via AbortController (same pattern as bedrock-judge-client.ts)
    const controller = new AbortController();
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, FAITHFULNESS_TIMEOUT_MS);

    let rawText: string;
    try {
      const response = await withThrottleRetry(
        () =>
          getBedrockClient().send(command, {
            abortSignal: controller.signal,
          }),
        RETRY_OPTIONS,
      );
      const content = response.output?.message?.content;
      rawText = content
        ?.map((b: ContentBlock) => ("text" in b ? b.text ?? "" : ""))
        .join("") ?? "";
    } catch (err) {
      if (timedOut) {
        console.warn(
          "[opportunistic-faithfulness] Converse call timed out after",
          FAITHFULNESS_TIMEOUT_MS,
          "ms",
        );
        return undefined;
      }
      console.warn(
        "[opportunistic-faithfulness] Converse call failed:",
        err instanceof Error ? err.message : err,
      );
      return undefined;
    } finally {
      clearTimeout(timer);
    }

    const score = parseScoreResponse(rawText);
    if (score === undefined) {
      console.warn(
        "[opportunistic-faithfulness] Failed to parse score from response:",
        rawText.slice(0, 200),
      );
    }
    return score;
  } catch (err) {
    console.warn(
      "[opportunistic-faithfulness] Unexpected error:",
      err instanceof Error ? err.message : err,
    );
    return undefined;
  }
}
