// Feature: connect-agent-test-platform, Property 7: Tool sequence accumulation preserves order
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { accumulateToolSequence } from "@backend/orchestration/conversation-driver";
import type { TranscriptTurn } from "@shared/types";

// ---------------------------------------------------------------------------
// Shared Arbitraries
// ---------------------------------------------------------------------------

/** Arbitrary for a turn role. */
const roleArb = fc.constantFrom<"customer" | "agent">("customer", "agent");

/** Arbitrary for non-empty text content. */
const textArb = fc.string({ minLength: 1, maxLength: 200 });

/** Arbitrary for a tool name (non-empty string). */
const toolNameArb = fc.string({ minLength: 1, maxLength: 50 });

/** Arbitrary for a TranscriptTurn WITH a toolSelected value. */
const turnWithToolArb = (turnNumber: number): fc.Arbitrary<TranscriptTurn> =>
  fc.record({
    turnNumber: fc.constant(turnNumber),
    role: roleArb,
    text: textArb,
    toolSelected: toolNameArb,
    timestamp: fc.constant(new Date().toISOString()),
    elapsedMs: fc.nat(10000),
  });

/** Arbitrary for a TranscriptTurn WITHOUT a toolSelected value. */
const turnWithoutToolArb = (turnNumber: number): fc.Arbitrary<TranscriptTurn> =>
  fc.record({
    turnNumber: fc.constant(turnNumber),
    role: roleArb,
    text: textArb,
    timestamp: fc.constant(new Date().toISOString()),
    elapsedMs: fc.nat(10000),
  });

/** Arbitrary for a TranscriptTurn that may or may not have a toolSelected. */
const mixedTurnArb = (turnNumber: number): fc.Arbitrary<TranscriptTurn> =>
  fc.oneof(turnWithToolArb(turnNumber), turnWithoutToolArb(turnNumber));

/** Arbitrary for a multi-turn conversation with 0–20 turns. */
const conversationArb: fc.Arbitrary<TranscriptTurn[]> = fc
  .integer({ min: 0, max: 20 })
  .chain((length) =>
    length === 0
      ? fc.constant([] as TranscriptTurn[])
      : fc.tuple(...Array.from({ length }, (_, i) => mixedTurnArb(i + 1))).map(
          (turns) => turns as TranscriptTurn[]
        )
  );

// ---------------------------------------------------------------------------
// Property 7: Tool sequence accumulation preserves order
// ---------------------------------------------------------------------------

describe("Property 7: Tool sequence accumulation preserves order", () => {
  /**
   * Validates: Requirements 7.8
   */

  it("result length equals the number of turns that have a defined toolSelected", () => {
    fc.assert(
      fc.property(conversationArb, (turns) => {
        const result = accumulateToolSequence(turns);
        const toolBearingCount = turns.filter(
          (t) => t.toolSelected !== undefined
        ).length;
        expect(result).toHaveLength(toolBearingCount);
      }),
      { numRuns: 100 }
    );
  });

  it("result preserves the relative order of tool selections", () => {
    fc.assert(
      fc.property(conversationArb, (turns) => {
        const result = accumulateToolSequence(turns);
        const expected = turns
          .filter((t) => t.toolSelected !== undefined)
          .map((t) => t.toolSelected!);
        expect(result).toEqual(expected);
      }),
      { numRuns: 100 }
    );
  });

  it("turns without toolSelected do not contribute to the result", () => {
    fc.assert(
      fc.property(conversationArb, (turns) => {
        const result = accumulateToolSequence(turns);
        const turnsWithoutTool = turns.filter(
          (t) => t.toolSelected === undefined
        );
        // If we remove all tool-bearing turns, the result should be empty
        const resultFromNonToolTurns = accumulateToolSequence(turnsWithoutTool);
        expect(resultFromNonToolTurns).toHaveLength(0);

        // Additionally: result should only contain values from tool-bearing turns
        const toolValues = new Set(
          turns
            .filter((t) => t.toolSelected !== undefined)
            .map((t) => t.toolSelected!)
        );
        result.forEach((tool) => {
          expect(toolValues.has(tool)).toBe(true);
        });
      }),
      { numRuns: 100 }
    );
  });
});
