/**
 * Exponential backoff with jitter for throttle retry logic.
 *
 * Used by the Conversation Driver when Q in Connect returns throttling
 * errors (HTTP 429, ThrottlingException, TooManyRequestsException), and by
 * Bedrock-calling Lambdas (`analysis.ts`, `suite-recommend.ts`) that wrap
 * their `Converse` invocations in {@link withThrottleRetry} to honor
 * R12.1 / R12.2.
 *
 * Formula:
 *   computedDelay = min(baseDelay * 2^attempt, maxDelay)
 *   actualDelay = random value in [0, computedDelay]
 *
 * Default base delay: 2 seconds (2000ms). Default max delay cap: 30 seconds
 * (30000ms). Both defaults are tuned for the Conversation Driver's Q in
 * Connect calls. The Bedrock Lambdas pass their own (`baseMs: 1000`,
 * `capMs: 10000`) via {@link withThrottleRetry} so the user-facing latency
 * stays bounded under throttling.
 *
 * @module backoff
 */

/** Base delay in milliseconds. */
const BASE_DELAY_MS = 2000;

/** Maximum delay cap in milliseconds. */
const MAX_DELAY_MS = 30000;

/**
 * Calculates the backoff delay for a given retry attempt.
 *
 * The delay uses full jitter: a random value between 0 and the computed
 * exponential delay. This spreads out retries to avoid thundering herd.
 *
 * @param attempt - The retry attempt number (0-indexed). Negative values are treated as 0.
 * @returns Delay in milliseconds, in the range [0, min(2000 * 2^attempt, 30000)]
 */
export function calculateBackoffDelay(attempt: number): number {
  const normalizedAttempt = Math.max(0, Math.floor(attempt));
  const computedDelay = Math.min(BASE_DELAY_MS * Math.pow(2, normalizedAttempt), MAX_DELAY_MS);
  return Math.random() * computedDelay;
}

/**
 * Configuration for {@link withThrottleRetry}. All three fields are
 * required so callers must explicitly state the retry posture.
 */
export interface ThrottleRetryOptions {
  /** Initial backoff base in milliseconds. */
  baseMs: number;
  /** Maximum backoff cap in milliseconds. */
  capMs: number;
  /**
   * Maximum number of retries AFTER the initial attempt. A `maxRetries`
   * of `2` means up to 3 total attempts (1 initial + 2 retries).
   */
  maxRetries: number;
}

/**
 * Names of throttling exceptions raised by the AWS SDK that the wrapper
 * recognizes and retries. Matches the AWS SDK v3 error name convention.
 */
const THROTTLING_ERROR_NAMES: ReadonlySet<string> = new Set([
  "ThrottlingException",
  "TooManyRequestsException",
]);

/**
 * Wrap an async function in a throttle-aware retry loop with exponential
 * backoff plus full jitter.
 *
 * Retries only when the thrown error's `name` matches a known throttling
 * exception ({@link THROTTLING_ERROR_NAMES}). All other errors propagate
 * to the caller on the first attempt — this wrapper is for backoff on
 * server-side rate limiting, not a general resilience helper.
 *
 * On terminal throttle (after `maxRetries` retries fail) the wrapper
 * re-throws the last error so the calling Lambda can map it to an HTTP 503
 * response with `retryable: true` per R12.1 / R12.2.
 *
 * @param fn - Async function to invoke.
 * @param opts - Retry options. See {@link ThrottleRetryOptions}.
 * @returns The resolved value of `fn` on success.
 * @throws The last throttle error after `maxRetries` retries, or any
 *   non-throttle error on its first occurrence.
 */
export async function withThrottleRetry<T>(
  fn: () => Promise<T>,
  opts: ThrottleRetryOptions,
): Promise<T> {
  const { baseMs, capMs, maxRetries } = opts;
  let attempt = 0;
  // Loop bound: the initial call (attempt=0) plus `maxRetries` retries.
  // We invert the loop into a while(true) with explicit break/throw so
  // the success path returns directly without an extra branch.
  // eslint-disable-next-line no-constant-condition
  while (true) {
    try {
      return await fn();
    } catch (err) {
      const errName = (err as { name?: string } | null)?.name ?? "";
      const isThrottle = THROTTLING_ERROR_NAMES.has(errName);
      if (!isThrottle || attempt >= maxRetries) {
        throw err;
      }
      // Full-jitter exponential backoff bounded by capMs.
      const computed = Math.min(baseMs * Math.pow(2, attempt), capMs);
      const delay = Math.random() * computed;
      await sleep(delay);
      attempt += 1;
    }
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
