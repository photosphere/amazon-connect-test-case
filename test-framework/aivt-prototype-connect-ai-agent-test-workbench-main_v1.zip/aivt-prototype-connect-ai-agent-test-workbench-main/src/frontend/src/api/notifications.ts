/**
 * Global notification system for API errors.
 *
 * Pages can subscribe to notifications and display them as Cloudscape Flashbar items.
 * The API client dispatches notifications automatically for 5xx errors and network timeouts.
 */

export interface ApiNotification {
  id: string;
  type: 'error' | 'warning' | 'info';
  message: string;
  dismissible: boolean;
  retryable: boolean;
  timestamp: number;
}

type NotificationListener = (notification: ApiNotification) => void;

const listeners: Set<NotificationListener> = new Set();
let notificationCounter = 0;

/**
 * Subscribe to API error notifications.
 * Returns an unsubscribe function.
 */
export function subscribeToNotifications(listener: NotificationListener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/**
 * Dispatch an error notification to all subscribers.
 * Called by the API client on 5xx errors and network timeouts.
 */
export function notifyError(message: string, retryable: boolean): void {
  const notification: ApiNotification = {
    id: `api-error-${++notificationCounter}`,
    type: 'error',
    message,
    dismissible: true,
    retryable,
    timestamp: Date.now(),
  };

  listeners.forEach((listener) => {
    try {
      listener(notification);
    } catch {
      // Don't let a bad listener break the notification system
    }
  });
}
