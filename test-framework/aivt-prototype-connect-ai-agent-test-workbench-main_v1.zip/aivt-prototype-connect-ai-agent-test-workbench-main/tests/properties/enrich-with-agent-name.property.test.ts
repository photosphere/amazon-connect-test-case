/**
 * Property tests for `buildAgentNameMap` + `enrichWithAgentName`
 * (agent-grouped-suites, Task 1.4).
 *
 * The Suites API (`GET /suites`) enriches each persisted {@link TestSuite}
 * with a resolved human-readable `agentName` computed at read time from the
 * Connect Q agent listing. The resolution rule is simple but load-bearing
 * for the agent-grouped frontend layout: when a suite's `agentId` matches a
 * known agent, the suite must carry that agent's display `name`; when it
 * does not match (agent deleted, empty listing, API failure → empty map),
 * the suite must fall back to the literal `agentId` so the UI can still
 * render and group. These two properties pin both halves of that rule:
 *
 *   - Property 1: Agent name enrichment correctness — for any suite whose
 *     `agentId` appears in the agent listing, the enriched `agentName`
 *     equals that agent's `name`.
 *   - Property 2: Agent name fallback to agentId — for any suite whose
 *     `agentId` does NOT appear in the agent listing, the enriched
 *     `agentName` equals the literal `agentId` string.
 *
 * The generators draw `agentId`s for both suites and agents from a small
 * shared pool so that matches and misses both occur frequently in the same
 * iteration: with wide-open id strings almost every suite would miss and
 * the enrichment (match) half of the rule would rarely be exercised. Agent
 * `name`s are drawn distinctly from the id pool so a correct enrichment is
 * never accidentally equal to the fallback `agentId`.
 *
 * **Validates: Requirements 1.1, 1.2**
 */

import fc from 'fast-check';
import { describe, expect, it } from 'vitest';

import {
  buildAgentNameMap,
  enrichWithAgentName,
} from '../../src/backend/handlers/suites';
import type { AgentSummary, TestSuite } from '../../src/shared/types';

// ---------------------------------------------------------------------------
// Generators
// ---------------------------------------------------------------------------

// A small pool of candidate agent ids. Keeping the pool small means suites
// and agents frequently share ids (matches) while still leaving room for
// misses, so both the enrichment and fallback halves of the rule are
// exercised within a single iteration.
const AGENT_ID_POOL: readonly string[] = [
  'agent-alpha',
  'agent-beta',
  'agent-gamma',
  'agent-delta',
  'agent-epsilon',
  'agent-zeta',
];

const agentIdArb: fc.Arbitrary<string> = fc.constantFrom(...AGENT_ID_POOL);

// Display names are drawn from a pool that is disjoint from the id pool, so
// a correctly enriched agentName (the agent's `name`) is never accidentally
// equal to the fallback value (the suite's `agentId`). This keeps the two
// properties cleanly distinguishable.
const AGENT_NAME_POOL: readonly string[] = [
  'Alpha Agent',
  'Beta Agent',
  'Gamma Agent',
  'Delta Agent',
  'Epsilon Agent',
  'Zeta Agent',
  'Renamed Agent',
];

const agentNameArb: fc.Arbitrary<string> = fc.constantFrom(...AGENT_NAME_POOL);

function suiteArb(suiteId: string): fc.Arbitrary<TestSuite> {
  return agentIdArb.map((agentId) => ({
    tenantId: 'tenant-1',
    suiteId,
    name: `suite-${suiteId}`,
    agentId,
    assistantId: 'assistant-1',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-01T00:00:00.000Z',
  }));
}

const suitesArb: fc.Arbitrary<TestSuite[]> = fc
  .integer({ min: 0, max: 30 })
  .chain((count) =>
    fc.tuple(
      ...Array.from({ length: count }, (_unused, i) => suiteArb(String(i))),
    ),
  )
  .map((suites) => [...suites]);

/**
 * A list of agents drawn from the shared id pool. Ids may repeat across the
 * generated list (the real `ListAIAgents` response is not guaranteed unique
 * in our model); `buildAgentNameMap` resolves such collisions last-write-
 * wins, and the properties below reason against the same map to stay
 * consistent with that behaviour.
 */
const agentsArb: fc.Arbitrary<AgentSummary[]> = fc.array(
  fc.tuple(agentIdArb, agentNameArb).map(
    ([agentId, name]): AgentSummary => ({
      agentId,
      name,
      type: 'ORCHESTRATION',
      toolCount: 0,
      modelId: 'model-1',
    }),
  ),
  { minLength: 0, maxLength: AGENT_ID_POOL.length },
);

// ---------------------------------------------------------------------------
// Properties
// ---------------------------------------------------------------------------

describe('enrichWithAgentName — Property 1: agent name enrichment correctness', () => {
  it('sets agentName to the matching agent\'s name for every suite whose agentId is in the listing', () => {
    fc.assert(
      fc.property(suitesArb, agentsArb, (suites, agents) => {
        const map = buildAgentNameMap(agents);
        const enriched = enrichWithAgentName(suites, map);

        expect(enriched.length).toBe(suites.length);

        for (let i = 0; i < suites.length; i++) {
          const suite = suites[i];
          if (map.has(suite.agentId)) {
            expect(enriched[i].agentName).toBe(map.get(suite.agentId));
          }
          // All original fields are preserved on the enriched record.
          expect(enriched[i].suiteId).toBe(suite.suiteId);
          expect(enriched[i].agentId).toBe(suite.agentId);
        }
      }),
      { numRuns: 200 },
    );
  });
});

describe('enrichWithAgentName — Property 2: agent name fallback to agentId', () => {
  it('sets agentName to the literal agentId for every suite whose agentId is not in the listing', () => {
    fc.assert(
      fc.property(suitesArb, agentsArb, (suites, agents) => {
        const map = buildAgentNameMap(agents);
        const enriched = enrichWithAgentName(suites, map);

        for (let i = 0; i < suites.length; i++) {
          const suite = suites[i];
          if (!map.has(suite.agentId)) {
            expect(enriched[i].agentName).toBe(suite.agentId);
          }
        }
      }),
      { numRuns: 200 },
    );
  });

  it('falls back to agentId for all suites when the agent listing is empty', () => {
    fc.assert(
      fc.property(suitesArb, (suites) => {
        const map = buildAgentNameMap([]);
        const enriched = enrichWithAgentName(suites, map);

        for (let i = 0; i < suites.length; i++) {
          expect(enriched[i].agentName).toBe(suites[i].agentId);
        }
      }),
      { numRuns: 200 },
    );
  });
});
