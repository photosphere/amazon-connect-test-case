/**
 * Bedrock Judge Client — thin wrapper over `@aws-sdk/client-bedrock-runtime`
 * `ConverseCommand` for the three AgentCore-template judges
 * (`Builtin.GoalSuccessRate`, `Builtin.Helpfulness`,
 * `Builtin.ToolSelectionAccuracy`).
 *
 * One module = one Converse call. The Evaluation Lambda and the local
 * Evaluation Harness share this module so they have one timeout policy,
 * one parsing policy, and one place to stub for tests. Score-Scale
 * mapping does NOT live here (Requirement 3.5) — this module returns
 * the raw `score` label from the model untouched and the consumer maps
 * the label through `evaluation-scoring.ts`.
 *
 * Migrated from the legacy `JUDGE_MODEL_ID` env-var fallback and the
 * inline `inferenceConfig: { maxTokens: 1024, temperature: 0 }`
 * construction to the registry (Wave 2 — Task 17.6 of the
 * prompt-management spec). The caller (Evaluation Lambda or local
 * harness) supplies the `runId` and the `promptKey` (one of the three
 * judge keys); this module resolves the prompt via
 * {@link resolvePromptForRun} (R11.2 / R11.3 — the run's pinned
 * snapshot is the source of truth, falling back to the live registry
 * for pre-feature runs) and shapes the Converse `inferenceConfig`
 * via {@link buildInferenceConfig} so the wire shape always matches
 * the resolved model's capability profile (R17.4).
 *
 * The legacy `JUDGE_MODEL_ID` env var is still set in
 * `lib/orchestration-construct.ts` as a Wave-2 safety net and is
 * removed in Wave 3. The judge templates module
 * (`judge-prompt-templates.ts`) is unchanged — the registry's
 * per-judge prompt-definition files import its constants for their
 * `defaultText` so the registry remains the runtime source of truth
 * while the byte-for-byte AWS-published copies stay in one place.
 *
 * Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 6.3, 1.3, 10.1,
 * 10.3, 11.2, 11.3.
 *
 * @module bedrock-judge-client
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ContentBlock,
  type ConverseCommandInput,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";

import {
  buildInferenceConfig,
  type PromptKey,
  type ResolvedPrompt,
} from "./prompt-registry";
import { resolvePromptForRun } from "./prompt-registry/runtime";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";

/**
 * Default per-call timeout for one Bedrock `Converse` invocation.
 *
 * 60 seconds matches Requirement 3.3 — exceeding this surfaces as
 * {@link JudgeTimeoutError}, which the caller maps to
 * `Evaluation_Error_State` code `TIMEOUT` without substituting local
 * scoring (Requirement 8.1).
 */
export const DEFAULT_JUDGE_TIMEOUT_MS = 60_000;

/**
 * The closed set of `promptKey` values the judge client resolves. Each
 * key maps to one of the three AgentCore-template judges in the
 * registry; the union narrows the public API so a typo at the call
 * site fails at compile time rather than at the next deployment.
 */
export type JudgePromptKey =
  | "judge_goal_success_rate"
  | "judge_helpfulness"
  | "judge_tool_selection";

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/**
 * Arguments for {@link judge}.
 *
 * `promptKey` selects which AgentCore template (and bundled
 * default-or-overridden `(text, modelId, inferenceParameters)` triple)
 * to dispatch. `vars` is the rendered `Judge_Prompt_Context` (subset
 * of `{available_tools}`, `{context}`, `{assistant_turn}`,
 * `{tool_turn}` per Requirement 2.1) produced by the pure
 * prompt-rendering module — the same vars map the AgentCore templates
 * declare as their placeholders. `runId` is the run whose pinned
 * snapshot supplies the prompt; the empty string falls back to the
 * live registry — used by unit tests and the rare pre-feature run
 * path where no snapshot was captured at run start.
 */
export interface JudgeInput {
  /** Which AgentCore-template judge to dispatch. */
  promptKey: JudgePromptKey;
  /** Substitution map for the resolved prompt's placeholders. */
  vars: Record<string, string>;
  /**
   * The run id whose pinned snapshot supplies the resolved prompt
   * (R11.2 / R11.3). The empty string falls back to the live registry.
   */
  runId: string;
  /**
   * Per-call timeout in milliseconds. Defaults to
   * {@link DEFAULT_JUDGE_TIMEOUT_MS} (60s, Requirement 3.3).
   */
  timeoutMs?: number;
}

/**
 * Result of {@link judge}.
 *
 * `score` is the **raw** rubric label string returned by the model — this
 * module does not interpret, normalize, or remap it (Requirement 3.5).
 * Score_Scale mapping happens in `src/shared/utils/evaluation-scoring.ts`.
 */
export interface JudgeOutput {
  /** Step-by-step reasoning the model emitted alongside the score. */
  reasoning: string;
  /** Raw rubric label (e.g. `"Yes"`, `"Very Helpful"`). Always non-empty. */
  score: string;
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/**
 * Thrown when a Bedrock Converse call exceeds the configured per-call
 * timeout (Requirement 3.3). Caller maps this to `Evaluation_Error_State`
 * code `TIMEOUT` (Requirement 8.1) without substituting local scoring.
 *
 * Carries the configured `timeoutMs` so the caller can populate a precise
 * error reason without re-deriving it.
 */
export class JudgeTimeoutError extends Error {
  /** Configured timeout in milliseconds. */
  readonly timeoutMs: number;

  constructor(timeoutMs: number) {
    super(`Bedrock judge call timed out after ${timeoutMs}ms`);
    this.name = "JudgeTimeoutError";
    this.timeoutMs = timeoutMs;
  }
}

/**
 * Thrown when the model response cannot be parsed into a conforming
 * `{ reasoning: string, score: non-empty string }` JSON object
 * (Requirement 3.4). Caller maps this to `Evaluation_Error_State` code
 * `UNMAPPABLE_RESULT` (Requirement 8.3) without substituting local
 * scoring.
 *
 * Carries a snippet of the raw response text so the error reason can
 * surface the offending payload for diagnosis without leaking the full
 * model output.
 */
export class JudgeResponseParseError extends Error {
  /** Short snippet of the raw response text (truncated). */
  readonly responseSnippet: string;

  constructor(reason: string, rawResponse: string) {
    const snippet = JudgeResponseParseError.snippet(rawResponse);
    super(`Bedrock judge response parse error: ${reason} | response: ${snippet}`);
    this.name = "JudgeResponseParseError";
    this.responseSnippet = snippet;
  }

  /** Truncate the raw response to a fixed-size snippet for diagnostics. */
  private static snippet(raw: string): string {
    const MAX = 500;
    const trimmed = raw.trim();
    return trimmed.length > MAX ? `${trimmed.slice(0, MAX)}…` : trimmed;
  }
}

// ---------------------------------------------------------------------------
// Bedrock client (lazy singleton; injectable for tests)
// ---------------------------------------------------------------------------

/**
 * Minimal duck-typed view of `BedrockRuntimeClient` — just the `send`
 * method this module uses. Tests inject a `{ send: vi.fn() }` matching this
 * shape via {@link _setBedrockClient}, mirroring the existing scaffold
 * Lambda pattern (`src/backend/handlers/scaffold.ts`).
 */
type SendableBedrockClient = Pick<BedrockRuntimeClient, "send">;

let bedrockClient: SendableBedrockClient | null = null;

function getBedrockClient(): SendableBedrockClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

/**
 * Test-only injector for the underlying Bedrock runtime client. Mirrors
 * the `_setBedrockClient` / `_setQConnectClient` pattern used elsewhere
 * (scaffold, conversation-driver). Pass `null` to clear the cached
 * singleton between tests.
 *
 * @internal
 */
export function _setBedrockClient(client: SendableBedrockClient | null): void {
  bedrockClient = client;
}

/**
 * Test-only reset for the cached singleton. Equivalent to
 * `_setBedrockClient(null)`; provided for symmetry with other modules
 * that expose a paired reset helper.
 *
 * @internal
 */
export function _resetBedrockClient(): void {
  bedrockClient = null;
}

// ---------------------------------------------------------------------------
// Internal helpers (mirror the probe's behavior byte-for-byte)
// ---------------------------------------------------------------------------

/**
 * Substitute `{key}`-style placeholders in `template` with values from
 * `vars`. Mirrors `scripts/bedrock-judge-probe.ts`'s `fillTemplate`:
 * uses `split(...).join(...)` so every occurrence of each `{key}` is
 * replaced (no regex escape concerns) and so embedded JSON-schema braces
 * (`{{` / `}}`) in the templates pass through untouched as long as their
 * keys are not in `vars`.
 *
 * Exported because `customer-simulator.ts` and the Prompts Lambda's
 * dry-render validator both reuse the same substitution semantics for
 * non-judge prompts.
 */
export function fillTemplate(
  template: string,
  vars: Record<string, string>
): string {
  return Object.entries(vars).reduce(
    (acc, [k, v]) => acc.split(`{${k}}`).join(v),
    template
  );
}

/**
 * Pull the JSON object out of a fenced ```` ``` ```` code block (the
 * shape every built-in template asks the model to produce). Mirrors
 * `scripts/bedrock-judge-probe.ts`'s `extractJson`:
 *
 * 1. If a fenced block (` ``` ... ``` ` or ` ```json ... ``` `) is
 *    present, return the trimmed inner content.
 * 2. Otherwise fall back to the substring between the first `{` and the
 *    last `}`.
 * 3. Otherwise return the raw response trimmed.
 *
 * The caller is still responsible for `JSON.parse` and shape validation;
 * this helper only locates the candidate JSON substring.
 *
 * @internal
 */
export function extractJson(raw: string): string {
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
  if (fenced) return fenced[1].trim();
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start >= 0 && end > start) return raw.slice(start, end + 1);
  return raw.trim();
}

/**
 * Concatenate the assistant text content blocks from a Converse response
 * `output.message.content` array. Mirrors the probe's flattening logic.
 */
function extractAssistantText(content: ContentBlock[] | undefined): string {
  if (!content) return "";
  return content
    .map((b) => ("text" in b ? b.text ?? "" : ""))
    .join("");
}

/**
 * Parse and validate a model response into a {@link JudgeOutput}. Throws
 * {@link JudgeResponseParseError} on any failure mode listed in
 * Requirement 3.4: missing fenced JSON, malformed JSON, or non-conforming
 * shape (missing `reasoning` string field, missing `score` string field,
 * empty `score`).
 *
 * Does NOT interpret, normalize, or remap the `score` label
 * (Requirement 3.5).
 */
function parseJudgeResponse(rawText: string): JudgeOutput {
  if (!rawText || rawText.trim().length === 0) {
    throw new JudgeResponseParseError(
      "model returned empty response",
      rawText
    );
  }

  const candidate = extractJson(rawText);

  let parsed: unknown;
  try {
    parsed = JSON.parse(candidate);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new JudgeResponseParseError(
      `JSON.parse failed: ${msg}`,
      rawText
    );
  }

  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new JudgeResponseParseError(
      "parsed value is not a JSON object",
      rawText
    );
  }

  const obj = parsed as Record<string, unknown>;
  const reasoning = obj.reasoning;
  const score = obj.score;

  if (typeof reasoning !== "string") {
    throw new JudgeResponseParseError(
      "missing or non-string `reasoning` field",
      rawText
    );
  }
  if (typeof score !== "string" || score.length === 0) {
    throw new JudgeResponseParseError(
      "missing, non-string, or empty `score` field",
      rawText
    );
  }

  return { reasoning, score };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Resolve the AgentCore-template judge identified by `promptKey` for
 * the executing run, render its template against the supplied `vars`,
 * send one Bedrock `ConverseCommand`, and return the parsed
 * `{ reasoning, score }`.
 *
 * Behaviour contract:
 *
 * - Resolves the prompt **once per call** via
 *   {@link resolvePromptForRun} (R11.2 / R11.3). The runtime helper's
 *   per-warm cache means repeated invocations for the same `runId`
 *   issue at most one DynamoDB read regardless of how many judge units
 *   the Evaluation Lambda fan-out dispatches. A
 *   {@link PromptResolutionError} from the resolver propagates
 *   unchanged (R16.3); the caller surfaces the structured error rather
 *   than have it re-wrapped as a Bedrock failure.
 * - Uses `prompt.text` from the resolver — the registry is the runtime
 *   source of truth for the AgentCore template body. The bundled
 *   default `prompt.text` is byte-for-byte equal to the corresponding
 *   constant in `judge-prompt-templates.ts` (verified by the
 *   prompt-registry build invariants test).
 * - Sends one user message with the rendered template as a single text
 *   block; the inference config is shaped by
 *   {@link buildInferenceConfig} to match the resolved model's
 *   capability profile (R17.4). For Anthropic Claude 4.x — the default
 *   judge family — this emits `{ inferenceConfig: { maxTokens } }`
 *   with no `temperature` / `topP` / `topK` / `stopSequences` (those
 *   keys are forbidden by the profile and silently dropped). For
 *   `amazon_nova` profile models the helper splits accepted keys
 *   between `inferenceConfig` and
 *   `additionalModelRequestFields.inferenceConfig`.
 * - Per-call timeout defaults to 60s (Requirement 3.3); on expiry
 *   throws {@link JudgeTimeoutError} and aborts the in-flight SDK call
 *   via `AbortController` so it does not linger.
 * - On any parse/validation failure throws
 *   {@link JudgeResponseParseError} carrying a snippet of the raw
 *   response (Requirement 3.4); never substitutes a synthesized or
 *   default `{ reasoning, score }` (Requirement 3.5).
 * - Does NOT interpret, normalize, or remap the `score` label — the
 *   raw string from the model is returned as-is (Requirement 3.5).
 *   Score mapping happens downstream in `evaluation-scoring.ts`.
 *
 * Other AWS SDK errors (`ThrottlingException`, `ValidationException`,
 * `AccessDeniedException`, network errors, etc.) propagate to the
 * caller for `Evaluation_Error_State` mapping to code `JUDGE_ERROR`
 * (Requirement 8.2).
 */
export async function judge(input: JudgeInput): Promise<JudgeOutput> {
  const timeoutMs = input.timeoutMs ?? DEFAULT_JUDGE_TIMEOUT_MS;

  // R11.2 / R11.3: resolve the prompt once per call. The runtime helper
  // caches the snapshot read per warm so a Lambda fan-out across many
  // judge units for the same `runId` issues at most one DDB read. A
  // `PromptResolutionError` thrown here propagates naturally so the
  // caller can surface the structured error without it being wrapped
  // as a Bedrock failure.
  const prompt: ResolvedPrompt = await resolvePromptForRun(
    input.promptKey as PromptKey,
    input.runId,
  );

  const renderedPrompt = fillTemplate(prompt.text, input.vars);
  const messages: Message[] = [
    { role: "user", content: [{ text: renderedPrompt }] as ContentBlock[] },
  ];

  // The wire-shape helper places the resolved inference parameters
  // into the exact arguments the Converse SDK expects for the
  // resolved model's capability profile. For Anthropic Claude 4.x
  // (the default judge family) this emits
  // `{ inferenceConfig: { maxTokens } }` with no `temperature`,
  // `topP`, `topK`, or `stopSequences`. Same pattern as
  // `variant-generator.ts`, `customer-simulator.ts`, etc.
  const built = buildInferenceConfig(prompt);

  // The casts on `inferenceConfig` and `additionalModelRequestFields`
  // bridge the SDK's strict types (`InferenceConfiguration` for the
  // top-level config, `DocumentType` for the additional fields) and
  // our runtime payload — `buildInferenceConfig` already enforced
  // the exact key set against the resolved capability profile, so
  // the values are guaranteed JSON-encodable at runtime.
  const command = new ConverseCommand({
    modelId: prompt.modelId,
    messages,
    inferenceConfig:
      built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(built.additionalModelRequestFields
      ? {
          additionalModelRequestFields:
            built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  let rawText: string;
  try {
    const client = getBedrockClient();
    const response = await client.send(command, {
      abortSignal: controller.signal,
    });
    rawText = extractAssistantText(response.output?.message?.content);
  } catch (err) {
    if (timedOut) {
      throw new JudgeTimeoutError(timeoutMs);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }

  return parseJudgeResponse(rawText);
}
