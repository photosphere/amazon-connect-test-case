/**
 * Audit Lambda — API Gateway handler for the audit trail.
 *
 * Routes:
 * - GET /audit  — List tenant's audit records in reverse chronological order,
 *                 paginated at 50 records per page with base64-encoded nextToken.
 *
 * Reads from DynamoDB: PK=TENANT#{tenantId}, SK begins_with AUDIT#
 * ScanIndexForward=false gives reverse chronological order since the SK
 * contains an ISO 8601 timestamp.
 *
 * @module audit
 */

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import type { AuditRecord } from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
const PAGE_SIZE = 50;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** API Gateway proxy event (subset relevant to this handler). */
export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  queryStringParameters?: Record<string, string> | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, string>;
    };
  };
}

/** Standard API Gateway proxy response. */
export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

/** Response shape for GET /audit. */
export interface AuditListResponse {
  records: AuditRecord[];
  nextToken?: string;
}

// ---------------------------------------------------------------------------
// DynamoDB client
// ---------------------------------------------------------------------------

let ddbDocClient: DynamoDBDocumentClient | null = null;

function getDDBClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setDDBClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Response helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(statusCode: number, body: unknown): APIGatewayResponse {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function extractTenantId(event: APIGatewayEvent): string | null {
  const claims = event.requestContext?.authorizer?.claims;
  // Interactive user: sub claim; Machine client: client_id claim
  return claims?.sub ?? claims?.client_id ?? null;
}

/**
 * Strip DynamoDB key attributes from an item.
 */
function stripKeys<T>(item: Record<string, unknown>): T {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { PK, SK, GSI1PK, GSI1SK, GSI2PK, GSI2SK, ...rest } = item;
  return rest as unknown as T;
}

// ---------------------------------------------------------------------------
// Route handler
// ---------------------------------------------------------------------------

/**
 * GET /audit
 * Returns the authenticated tenant's audit records in reverse chronological
 * order, paginated at 50 records per page.
 */
async function handleListAudit(
  tenantId: string,
  nextToken?: string,
): Promise<APIGatewayResponse> {
  // Decode pagination token if provided
  let exclusiveStartKey: Record<string, unknown> | undefined;
  if (nextToken) {
    try {
      exclusiveStartKey = JSON.parse(
        Buffer.from(nextToken, "base64").toString("utf-8"),
      );
    } catch {
      return jsonResponse(400, { error: "Invalid nextToken" });
    }
  }

  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.TENANT}${tenantId}`,
        ":skPrefix": SK_PATTERNS.AUDIT,
      },
      ScanIndexForward: false, // reverse chronological order
      Limit: PAGE_SIZE,
      ...(exclusiveStartKey && { ExclusiveStartKey: exclusiveStartKey }),
    }),
  );

  const records = (result.Items || []).map(
    (item) => stripKeys<AuditRecord>(item as Record<string, unknown>),
  );

  const response: AuditListResponse = { records };

  // Encode pagination token if there are more results
  if (result.LastEvaluatedKey) {
    response.nextToken = Buffer.from(
      JSON.stringify(result.LastEvaluatedKey),
    ).toString("base64");
  }

  return jsonResponse(200, response);
}

// ---------------------------------------------------------------------------
// Main handler — API Gateway proxy integration routing
// ---------------------------------------------------------------------------

/**
 * Lambda handler for Audit API.
 * Routes based on httpMethod + resource path.
 */
export async function handler(event: APIGatewayEvent): Promise<APIGatewayResponse> {
  const { httpMethod, queryStringParameters } = event;

  if (httpMethod !== "GET") {
    return jsonResponse(405, { error: "Method not allowed" });
  }

  // Extract tenant ID from Cognito authorizer claims
  const tenantId = extractTenantId(event);
  if (!tenantId) {
    return jsonResponse(401, { error: "Unauthorized: missing tenant identity" });
  }

  try {
    const nextToken = queryStringParameters?.nextToken;
    return await handleListAudit(tenantId, nextToken);
  } catch (error) {
    console.error(
      "[audit] Handler error:",
      error instanceof Error ? error.message : error,
    );
    return jsonResponse(500, { error: "Internal server error" });
  }
}
