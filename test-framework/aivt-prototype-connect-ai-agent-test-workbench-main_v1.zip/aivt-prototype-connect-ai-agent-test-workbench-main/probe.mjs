// Probe different CreateSession/SendMessage configs to find which one routes to
// the AnyBank ORCHESTRATION agent (d54d3dee) instead of the default SELF_SERVICE (529207fe).
import {
  QConnectClient,
  CreateSessionCommand,
  SendMessageCommand,
  GetNextMessageCommand,
  ListSpansCommand,
} from "@aws-sdk/client-qconnect";

const REGION = "us-east-1";
const ASSISTANT_ID = "5664eea5-381d-468e-bfba-302b69ae6dec";
const ANYBANK = "d54d3dee-b9ec-415a-9a4b-b4769426f365";
const UTTERANCE = "Hey can you pull up my mortgage and tell me what my current interest is?";

const client = new QConnectClient({ region: REGION });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function pollOnce(sessionId, token) {
  // poll a few times to let the agent produce its first span
  let cur = token;
  for (let i = 0; i < 8; i++) {
    const r = await client.send(
      new GetNextMessageCommand({ assistantId: ASSISTANT_ID, sessionId, nextMessageToken: cur })
    );
    const status = r.conversationState?.status;
    cur = r.nextMessageToken ?? cur;
    if (status === "READY" || status === "CLOSED") break;
    await sleep(400);
  }
}

async function spanAgentTypes(sessionId) {
  const types = new Set();
  let nextToken;
  do {
    const resp = await client.send(
      new ListSpansCommand({ assistantId: ASSISTANT_ID, sessionId, nextToken, maxResults: 100 })
    );
    for (const s of resp.spans ?? []) {
      const a = s.attributes ?? {};
      if (a.aiAgentType) types.add(`${a.aiAgentType}:${a.aiAgentName}:${a.aiAgentId}`);
    }
    nextToken = resp.nextToken;
  } while (nextToken);
  return [...types];
}

async function probe(label, createInput, sendExtra) {
  const name = `probe-${Math.random().toString(16).slice(2, 10)}`;
  try {
    const cs = await client.send(
      new CreateSessionCommand({ assistantId: ASSISTANT_ID, name, ...createInput })
    );
    const sessionId = cs.session?.sessionId;
    const sm = await client.send(
      new SendMessageCommand({
        assistantId: ASSISTANT_ID,
        sessionId,
        type: "TEXT",
        message: { value: { text: { value: UTTERANCE } } },
        ...sendExtra,
      })
    );
    await pollOnce(sessionId, sm.nextMessageToken);
    await sleep(1500);
    const types = await spanAgentTypes(sessionId);
    console.log(`\n### ${label}`);
    console.log(`session=${sessionId}`);
    console.log(`agentTypes=${JSON.stringify(types)}`);
  } catch (e) {
    console.log(`\n### ${label}`);
    console.log(`ERROR: ${e.name}: ${e.message}`);
  }
}

// A: prototype-exact — bare aiAgentId on SendMessage only
await probe("A: bare aiAgentId on SendMessage (current/prototype)", {}, { aiAgentId: ANYBANK });

// B: bind AnyBank to SELF_SERVICE slot on CreateSession
await probe(
  "B: aiAgentConfiguration SELF_SERVICE -> AnyBank",
  { aiAgentConfiguration: { SELF_SERVICE: { aiAgentId: ANYBANK } } },
  {}
);

// C: bind AnyBank to ORCHESTRATION slot on CreateSession
await probe(
  "C: aiAgentConfiguration ORCHESTRATION -> AnyBank",
  { aiAgentConfiguration: { ORCHESTRATION: { aiAgentId: ANYBANK } } },
  {}
);

// D: SELF_SERVICE slot binding + send with orchestratorUseCase Connect.SelfService
await probe(
  "D: SELF_SERVICE slot + orchestratorUseCase=Connect.SelfService",
  { aiAgentConfiguration: { SELF_SERVICE: { aiAgentId: ANYBANK } } },
  { orchestratorUseCase: "Connect.SelfService" }
);

// E: orchestratorConfigurationList mapping Connect.SelfService -> AnyBank
await probe(
  "E: orchestratorConfigurationList Connect.SelfService -> AnyBank",
  { orchestratorConfigurationList: [{ aiAgentId: ANYBANK, orchestratorUseCase: "Connect.SelfService" }] },
  { orchestratorUseCase: "Connect.SelfService" }
);

console.log("\nDONE");
