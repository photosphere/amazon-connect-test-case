import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as cr from 'aws-cdk-lib/custom-resources';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';

export interface AssistantDiscoveryProps {
  /**
   * The Connect instance ID (UUID) to discover the assistant for.
   */
  connectInstanceId: string;
}

/**
 * Custom resource that discovers the Q in Connect assistant ID at deploy time
 * by calling Connect's ListIntegrationAssociations (IntegrationType
 * WISDOM_ASSISTANT) for the specified Connect instance. This resolves the
 * assistant that is actually associated with the instance, rather than picking
 * an arbitrary assistant from the account.
 *
 * Fails the deployment if no assistant is associated with the instance.
 */
export class AssistantDiscovery extends Construct {
  /**
   * The discovered assistant ID, available as a deploy-time resolved token.
   */
  public readonly assistantId: string;

  constructor(scope: Construct, id: string, props: AssistantDiscoveryProps) {
    super(scope, id);

    const stack = cdk.Stack.of(this);
    const connectInstanceArn = `arn:aws:connect:${stack.region}:${stack.account}:instance/${props.connectInstanceId}`;

    // Lambda that resolves the assistant ID bound to the specific Connect
    // instance via Connect's integration associations.
    const discoveryFn = new lambda.Function(this, 'DiscoveryFunction', {
      runtime: lambda.Runtime.NODEJS_24_X,
      handler: 'index.handler',
      timeout: cdk.Duration.minutes(2),
      code: lambda.Code.fromInline(getDiscoveryLambdaCode()),
      description: 'Custom resource to discover Q in Connect assistant ID at deploy time',
    });

    // ListIntegrationAssociations is authorized against the Connect instance
    // resource — scope the grant to this instance (plus a child-resource ARN
    // for the integration associations themselves).
    discoveryFn.addToRolePolicy(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        actions: ['connect:ListIntegrationAssociations'],
        resources: [connectInstanceArn, `${connectInstanceArn}/*`],
      }),
    );

    // GetAssistant is used to confirm the resolved assistant is ACTIVE. It
    // authorizes against the assistant ARN; the assistant ID is only known at
    // runtime, so this is scoped to the account's assistants. Both wisdom and
    // qconnect action prefixes are granted for compatibility.
    discoveryFn.addToRolePolicy(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        actions: ['wisdom:GetAssistant', 'qconnect:GetAssistant'],
        resources: ['*'],
      }),
    );

    const provider = new cr.Provider(this, 'DiscoveryProvider', {
      onEventHandler: discoveryFn,
    });

    const customResource = new cdk.CustomResource(this, 'AssistantLookup', {
      serviceToken: provider.serviceToken,
      properties: {
        ConnectInstanceId: props.connectInstanceId,
        // Force re-evaluation on every deployment to detect assistant changes
        Timestamp: Date.now().toString(),
      },
    });

    this.assistantId = customResource.getAttString('AssistantId');
  }
}

/**
 * Returns the inline Lambda code for the assistant discovery custom resource.
 *
 * The Lambda resolves the assistant that is actually bound to the given Connect
 * instance by calling Connect's `ListIntegrationAssociations` filtered to
 * `IntegrationType=WISDOM_ASSISTANT`. The returned `IntegrationArn` is the Q in
 * Connect assistant ARN; the assistant ID is the last ARN segment. It then
 * calls `GetAssistant` to confirm the assistant is ACTIVE.
 *
 * Throws an error (failing the deployment) if no assistant is associated with
 * the instance, or if the associated assistant is not ACTIVE.
 */
function getDiscoveryLambdaCode(): string {
  return `
const { ConnectClient, ListIntegrationAssociationsCommand } = require('@aws-sdk/client-connect');
const { QConnectClient, GetAssistantCommand } = require('@aws-sdk/client-qconnect');

// Extracts the assistant ID from a Q in Connect assistant ARN such as
// arn:aws:wisdom:<region>:<account>:assistant/<assistantId>
function assistantIdFromArn(arn) {
  if (!arn) return null;
  const match = arn.match(/assistant\\/([^/]+)/);
  return match ? match[1] : null;
}

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));

  const requestType = event.RequestType;

  // On Delete, nothing to clean up
  if (requestType === 'Delete') {
    return {
      PhysicalResourceId: event.PhysicalResourceId || 'assistant-discovery',
      Data: {},
    };
  }

  const connectInstanceId = event.ResourceProperties.ConnectInstanceId;
  if (!connectInstanceId) {
    throw new Error('ConnectInstanceId property is required');
  }

  const connect = new ConnectClient({});

  // Find the WISDOM_ASSISTANT integration association for THIS instance.
  // This is the authoritative link between a Connect instance and its
  // Q in Connect assistant, so we no longer guess from a global list.
  let assistantArn = null;
  let nextToken = undefined;

  do {
    const params = {
      InstanceId: connectInstanceId,
      IntegrationType: 'WISDOM_ASSISTANT',
    };
    if (nextToken) {
      params.NextToken = nextToken;
    }

    const response = await connect.send(new ListIntegrationAssociationsCommand(params));

    const summaries = response.IntegrationAssociationSummaryList || [];
    console.log('ListIntegrationAssociations response summary:', {
      count: summaries.length,
      hasNextToken: !!response.NextToken,
    });

    for (const summary of summaries) {
      if (summary.IntegrationArn) {
        assistantArn = summary.IntegrationArn;
        console.log('Found WISDOM_ASSISTANT integration:', assistantArn);
        break;
      }
    }

    nextToken = response.NextToken;
  } while (nextToken && !assistantArn);

  const assistantId = assistantIdFromArn(assistantArn);

  if (!assistantId) {
    throw new Error(
      'No Q in Connect assistant is associated with Connect instance ' + connectInstanceId + '. ' +
      'Ensure Amazon Q in Connect is enabled and associated with this instance before deploying. ' +
      'The deployment cannot proceed without an associated assistant.'
    );
  }

  // Confirm the associated assistant is ACTIVE (best-effort guard that
  // preserves the previous behavior of only returning ACTIVE assistants).
  try {
    const qconnect = new QConnectClient({});
    const detail = await qconnect.send(new GetAssistantCommand({ assistantId }));
    const status = detail.assistant && detail.assistant.status;
    const name = detail.assistant && detail.assistant.name;
    console.log('GetAssistant:', { assistantId, status, name });
    if (status && status !== 'ACTIVE') {
      throw new Error(
        'Assistant ' + assistantId + ' associated with instance ' + connectInstanceId +
        ' is not ACTIVE (status: ' + status + ').'
      );
    }
  } catch (err) {
    // If the assistant explicitly reported a non-ACTIVE status, fail. For
    // other GetAssistant errors (e.g. transient/permission), proceed with the
    // associated assistant since the association itself is authoritative.
    if (err && /is not ACTIVE/.test(err.message || '')) {
      throw err;
    }
    console.warn('GetAssistant check skipped due to error:', err && err.message);
  }

  return {
    PhysicalResourceId: 'assistant-discovery-' + connectInstanceId,
    Data: {
      AssistantId: assistantId,
    },
  };
};
`;
}
