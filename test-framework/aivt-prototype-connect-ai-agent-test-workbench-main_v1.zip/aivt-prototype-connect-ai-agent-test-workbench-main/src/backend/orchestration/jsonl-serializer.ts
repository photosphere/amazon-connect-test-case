/**
 * BYOI retrieve-and-generate JSONL serializer for Bedrock RAG Evaluation.
 *
 * Pure module — no I/O, no AWS SDK dependencies. Produces single-line JSON
 * objects conforming to the Bedrock BYOI retrieve-and-generate schema and
 * assembles multiple lines into a complete JSONL file body.
 *
 * @module jsonl-serializer
 */

import type { RetrievedChunk } from "../../shared/types";

// ---------------------------------------------------------------------------
// Input interface
// ---------------------------------------------------------------------------

/**
 * Input data for serializing a single RAG case into a BYOI JSONL line.
 * All text fields are preserved byte-for-byte — no trimming or extra escaping
 * beyond standard JSON string escaping performed by JSON.stringify.
 */
export interface RagCaseInput {
  /** The customer's question (literal utterance sent to the agent). */
  question: string;
  /** The known-good agent reply for metric scoring. */
  groundTruthAnswer: string;
  /** The agent's actual terminal response captured in Stage 1. */
  agentResponse: string;
  /** Ordered passages the Retrieve tool returned during execution. */
  retrievedChunks: RetrievedChunk[];
  /**
   * Explicit knowledge base identifier for the case. When undefined, the
   * serializer derives it from the first chunk's knowledgeBaseId, falling
   * back to the sentinel "connect-orchestration-retrieve".
   */
  knowledgeBaseId: string | undefined;
  /** Agent model id from the AgentSnapshot (e.g. "us.anthropic.claude-sonnet-4-6"). */
  modelIdentifier: string;
}

// ---------------------------------------------------------------------------
// Serialization
// ---------------------------------------------------------------------------

/**
 * Serializes a single RAG case into a BYOI retrieve-and-generate JSONL line.
 *
 * Returns a single-line valid JSON string (no trailing newline). All text
 * fields (question, groundTruthAnswer, agentResponse, chunk texts) are
 * preserved byte-for-byte — no trimming, no escaping beyond standard JSON
 * string escaping.
 *
 * knowledgeBaseIdentifier derivation:
 *   1. input.knowledgeBaseId if explicitly provided
 *   2. First chunk's knowledgeBaseId if any chunk has one
 *   3. Sentinel "connect-orchestration-retrieve"
 */
export function serializeRagCaseToJsonl(input: RagCaseInput): string {
  const knowledgeBaseIdentifier =
    input.knowledgeBaseId ??
    input.retrievedChunks.find((c) => c.knowledgeBaseId)?.knowledgeBaseId ??
    "connect-orchestration-retrieve";

  const line = {
    conversationTurns: [
      {
        prompt: { content: [{ text: input.question }] },
        referenceResponses: [{ content: [{ text: input.groundTruthAnswer }] }],
        output: {
          text: input.agentResponse,
          knowledgeBaseIdentifier,
          modelIdentifier: input.modelIdentifier,
          retrievedPassages: {
            retrievalResults: input.retrievedChunks.map((chunk) => ({
              content: { text: chunk.text },
              ...(chunk.title ? { name: chunk.title } : {}),
              ...(chunk.contentId || chunk.knowledgeBaseId
                ? {
                    metadata: {
                      ...(chunk.contentId
                        ? { contentId: chunk.contentId }
                        : {}),
                      ...(chunk.knowledgeBaseId
                        ? { knowledgeBaseId: chunk.knowledgeBaseId }
                        : {}),
                    },
                  }
                : {}),
            })),
          },
        },
      },
    ],
  };

  return JSON.stringify(line);
}

// ---------------------------------------------------------------------------
// File assembly
// ---------------------------------------------------------------------------

/**
 * Assembles multiple JSONL lines into a complete file body suitable for S3
 * upload. Joins lines with `\n` separators — no leading or trailing blank
 * lines. Also builds the line-index → caseId mapping needed for joining
 * Bedrock's per-prompt output back to platform case IDs.
 *
 * @param cases - Ordered array of { caseId, line } where `line` is the output
 *               of serializeRagCaseToJsonl (single-line JSON, no newline).
 * @returns body  - The joined JSONL file content.
 * @returns indexMap - Zero-based line index → caseId mapping.
 */
export function assembleJsonlFile(
  cases: Array<{ caseId: string; line: string }>,
): { body: string; indexMap: Record<number, string> } {
  const indexMap: Record<number, string> = {};

  for (let i = 0; i < cases.length; i++) {
    indexMap[i] = cases[i].caseId;
  }

  const body = cases.map((c) => c.line).join("\n");

  return { body, indexMap };
}
