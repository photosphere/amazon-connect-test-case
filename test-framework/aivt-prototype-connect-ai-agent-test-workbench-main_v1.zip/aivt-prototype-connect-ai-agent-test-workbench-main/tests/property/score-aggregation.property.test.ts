// Feature: implement-recommendations, Property 8: Score aggregation correctness
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import { aggregateScores } from "@backend/orchestration/score-aggregation";
import type { TestCaseResult } from "@shared/types";
import { CaseStatus } from "@shared/enums";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** All valid CaseStatus values. */
const caseStatusArb: fc.Arbitrary<CaseStatus> = fc.constantFrom<CaseStatus>(
  CaseStatus.PASSED,
  CaseStatus.FAILED,
  CaseStatus.ERROR,
  CaseStatus.TIMED_OUT,
);

/** A score value between 0 and 1 (inclusive), or undefined. */
const optionalScoreArb: fc.Arbitrary<number | undefined> = fc.oneof(
  fc.constant(undefined),
  fc.double({ min: 0, max: 1, noNaN: true }),
);

/**
 * Arbitrary TestCaseResult with realistic structure.
 * Scores are optional (may be undefined) to test exclusion logic.
 */
const testCaseResultArb: fc.Arbitrary<TestCaseResult> = fc.record({
  runId: fc.string({ minLength: 1, maxLength: 10 }),
  caseId: fc.string({ minLength: 1, maxLength: 10 }),
  status: caseStatusArb,
  toolsInvoked: fc.array(fc.string({ minLength: 1, maxLength: 10 }), {
    minLength: 0,
    maxLength: 3,
  }),
  turnCount: fc.nat({ max: 20 }),
  latencyMs: fc.nat({ max: 10000 }),
  goalSuccessScore: optionalScoreArb,
  helpfulnessScore: optionalScoreArb,
  toolAccuracyScore: optionalScoreArb,
});

/** Non-empty arrays of TestCaseResult. */
const nonEmptyResultsArb: fc.Arbitrary<TestCaseResult[]> = fc.array(
  testCaseResultArb,
  { minLength: 1, maxLength: 50 },
);

// ---------------------------------------------------------------------------
// Property 8: Score aggregation correctness
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 8.2**
 *
 * Property 8: Score aggregation correctness
 *
 * The aggregateScores function correctly computes passRate as
 * (count of passed / total), and each average score as the mean of defined
 * values only (undefined excluded from both numerator and denominator).
 * An empty input always yields all zeros.
 */
describe("Feature: implement-recommendations, Property 8: Score aggregation correctness", () => {
  it("passRate is always between 0 and 1 (inclusive)", () => {
    fc.assert(
      fc.property(nonEmptyResultsArb, (results) => {
        const scores = aggregateScores(results);
        expect(scores.passRate).toBeGreaterThanOrEqual(0);
        expect(scores.passRate).toBeLessThanOrEqual(1);
      }),
      { numRuns: 100 },
    );
  });

  it("passRate equals count of PASSED / total length", () => {
    fc.assert(
      fc.property(nonEmptyResultsArb, (results) => {
        const scores = aggregateScores(results);
        const passedCount = results.filter(
          (r) => r.status === CaseStatus.PASSED,
        ).length;
        const expectedPassRate = passedCount / results.length;
        expect(scores.passRate).toBeCloseTo(expectedPassRate, 10);
      }),
      { numRuns: 100 },
    );
  });

  it("each average score is between 0 and 1 (inclusive)", () => {
    fc.assert(
      fc.property(nonEmptyResultsArb, (results) => {
        const scores = aggregateScores(results);
        expect(scores.avgGoalSuccessScore).toBeGreaterThanOrEqual(0);
        expect(scores.avgGoalSuccessScore).toBeLessThanOrEqual(1);
        expect(scores.avgHelpfulnessScore).toBeGreaterThanOrEqual(0);
        expect(scores.avgHelpfulnessScore).toBeLessThanOrEqual(1);
        expect(scores.avgToolAccuracyScore).toBeGreaterThanOrEqual(0);
        expect(scores.avgToolAccuracyScore).toBeLessThanOrEqual(1);
      }),
      { numRuns: 100 },
    );
  });

  it("if all cases have undefined goalSuccessScore, avgGoalSuccessScore is 0", () => {
    const allUndefinedGoalArb = fc.array(
      fc.record({
        runId: fc.string({ minLength: 1, maxLength: 10 }),
        caseId: fc.string({ minLength: 1, maxLength: 10 }),
        status: caseStatusArb,
        toolsInvoked: fc.array(fc.string({ minLength: 1, maxLength: 10 }), {
          minLength: 0,
          maxLength: 3,
        }),
        turnCount: fc.nat({ max: 20 }),
        latencyMs: fc.nat({ max: 10000 }),
        goalSuccessScore: fc.constant(undefined),
        helpfulnessScore: optionalScoreArb,
        toolAccuracyScore: optionalScoreArb,
      }),
      { minLength: 1, maxLength: 50 },
    );

    fc.assert(
      fc.property(allUndefinedGoalArb, (results) => {
        const scores = aggregateScores(results as TestCaseResult[]);
        expect(scores.avgGoalSuccessScore).toBe(0);
      }),
      { numRuns: 100 },
    );
  });

  it("if all cases have status PASSED, passRate is 1", () => {
    const allPassedArb = fc.array(
      fc.record({
        runId: fc.string({ minLength: 1, maxLength: 10 }),
        caseId: fc.string({ minLength: 1, maxLength: 10 }),
        status: fc.constant(CaseStatus.PASSED),
        toolsInvoked: fc.array(fc.string({ minLength: 1, maxLength: 10 }), {
          minLength: 0,
          maxLength: 3,
        }),
        turnCount: fc.nat({ max: 20 }),
        latencyMs: fc.nat({ max: 10000 }),
        goalSuccessScore: optionalScoreArb,
        helpfulnessScore: optionalScoreArb,
        toolAccuracyScore: optionalScoreArb,
      }),
      { minLength: 1, maxLength: 50 },
    );

    fc.assert(
      fc.property(allPassedArb, (results) => {
        const scores = aggregateScores(results as TestCaseResult[]);
        expect(scores.passRate).toBe(1);
      }),
      { numRuns: 100 },
    );
  });

  it("empty input always yields all zeros", () => {
    const scores = aggregateScores([]);
    expect(scores).toEqual({
      passRate: 0,
      avgGoalSuccessScore: 0,
      avgHelpfulnessScore: 0,
      avgToolAccuracyScore: 0,
    });
  });

  it("average scores are computed as mean of defined values only (undefined excluded)", () => {
    fc.assert(
      fc.property(nonEmptyResultsArb, (results) => {
        const scores = aggregateScores(results);

        // Manually compute expected averages
        const definedGoal = results
          .map((r) => r.goalSuccessScore)
          .filter((v): v is number => v !== undefined);
        const definedHelpfulness = results
          .map((r) => r.helpfulnessScore)
          .filter((v): v is number => v !== undefined);
        const definedToolAccuracy = results
          .map((r) => r.toolAccuracyScore)
          .filter((v): v is number => v !== undefined);

        const expectedGoal =
          definedGoal.length === 0
            ? 0
            : definedGoal.reduce((a, b) => a + b, 0) / definedGoal.length;
        const expectedHelpfulness =
          definedHelpfulness.length === 0
            ? 0
            : definedHelpfulness.reduce((a, b) => a + b, 0) /
              definedHelpfulness.length;
        const expectedToolAccuracy =
          definedToolAccuracy.length === 0
            ? 0
            : definedToolAccuracy.reduce((a, b) => a + b, 0) /
              definedToolAccuracy.length;

        expect(scores.avgGoalSuccessScore).toBeCloseTo(expectedGoal, 10);
        expect(scores.avgHelpfulnessScore).toBeCloseTo(expectedHelpfulness, 10);
        expect(scores.avgToolAccuracyScore).toBeCloseTo(
          expectedToolAccuracy,
          10,
        );
      }),
      { numRuns: 100 },
    );
  });
});
