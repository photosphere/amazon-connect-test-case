import { describe, it, expect } from "vitest";
import { aggregateScores } from "@backend/orchestration/score-aggregation";
import { CaseStatus } from "@shared/enums";
import type { TestCaseResult } from "@shared/types";

/** Helper to create a minimal TestCaseResult with the given overrides. */
function makeResult(overrides: Partial<TestCaseResult> = {}): TestCaseResult {
  return {
    runId: "run-1",
    caseId: "case-1",
    status: CaseStatus.PASSED,
    toolsInvoked: [],
    turnCount: 1,
    latencyMs: 100,
    ...overrides,
  };
}

describe("aggregateScores", () => {
  it("returns all zeros for an empty array", () => {
    const result = aggregateScores([]);
    expect(result).toEqual({
      passRate: 0,
      avgGoalSuccessScore: 0,
      avgHelpfulnessScore: 0,
      avgToolAccuracyScore: 0,
    });
  });

  it("computes passRate as passed / total", () => {
    const results: TestCaseResult[] = [
      makeResult({ caseId: "1", status: CaseStatus.PASSED }),
      makeResult({ caseId: "2", status: CaseStatus.FAILED }),
      makeResult({ caseId: "3", status: CaseStatus.PASSED }),
      makeResult({ caseId: "4", status: CaseStatus.ERROR }),
    ];
    const agg = aggregateScores(results);
    expect(agg.passRate).toBeCloseTo(0.5);
  });

  it("computes average scores excluding undefined values", () => {
    const results: TestCaseResult[] = [
      makeResult({ caseId: "1", goalSuccessScore: 0.8, helpfulnessScore: 0.6, toolAccuracyScore: 1.0 }),
      makeResult({ caseId: "2", goalSuccessScore: 0.4, helpfulnessScore: undefined, toolAccuracyScore: 0.5 }),
      makeResult({ caseId: "3", goalSuccessScore: undefined, helpfulnessScore: 0.9, toolAccuracyScore: undefined }),
    ];
    const agg = aggregateScores(results);
    // goalSuccessScore: (0.8 + 0.4) / 2 = 0.6
    expect(agg.avgGoalSuccessScore).toBeCloseTo(0.6);
    // helpfulnessScore: (0.6 + 0.9) / 2 = 0.75
    expect(agg.avgHelpfulnessScore).toBeCloseTo(0.75);
    // toolAccuracyScore: (1.0 + 0.5) / 2 = 0.75
    expect(agg.avgToolAccuracyScore).toBeCloseTo(0.75);
  });

  it("returns 0 for a score metric when no cases define it", () => {
    const results: TestCaseResult[] = [
      makeResult({ caseId: "1" }),
      makeResult({ caseId: "2" }),
    ];
    const agg = aggregateScores(results);
    expect(agg.avgGoalSuccessScore).toBe(0);
    expect(agg.avgHelpfulnessScore).toBe(0);
    expect(agg.avgToolAccuracyScore).toBe(0);
  });

  it("counts all statuses except PASSED as not passing", () => {
    const results: TestCaseResult[] = [
      makeResult({ caseId: "1", status: CaseStatus.PASSED }),
      makeResult({ caseId: "2", status: CaseStatus.FAILED }),
      makeResult({ caseId: "3", status: CaseStatus.ERROR }),
      makeResult({ caseId: "4", status: CaseStatus.TIMED_OUT }),
    ];
    const agg = aggregateScores(results);
    expect(agg.passRate).toBeCloseTo(0.25);
  });

  it("handles a single case with all scores defined", () => {
    const results: TestCaseResult[] = [
      makeResult({
        caseId: "1",
        status: CaseStatus.PASSED,
        goalSuccessScore: 0.9,
        helpfulnessScore: 0.7,
        toolAccuracyScore: 0.85,
      }),
    ];
    const agg = aggregateScores(results);
    expect(agg.passRate).toBe(1);
    expect(agg.avgGoalSuccessScore).toBeCloseTo(0.9);
    expect(agg.avgHelpfulnessScore).toBeCloseTo(0.7);
    expect(agg.avgToolAccuracyScore).toBeCloseTo(0.85);
  });

  it("handles all cases passed with 100% pass rate", () => {
    const results: TestCaseResult[] = [
      makeResult({ caseId: "1", status: CaseStatus.PASSED }),
      makeResult({ caseId: "2", status: CaseStatus.PASSED }),
      makeResult({ caseId: "3", status: CaseStatus.PASSED }),
    ];
    const agg = aggregateScores(results);
    expect(agg.passRate).toBe(1);
  });

  it("handles all cases failed with 0% pass rate", () => {
    const results: TestCaseResult[] = [
      makeResult({ caseId: "1", status: CaseStatus.FAILED }),
      makeResult({ caseId: "2", status: CaseStatus.ERROR }),
    ];
    const agg = aggregateScores(results);
    expect(agg.passRate).toBe(0);
  });
});
