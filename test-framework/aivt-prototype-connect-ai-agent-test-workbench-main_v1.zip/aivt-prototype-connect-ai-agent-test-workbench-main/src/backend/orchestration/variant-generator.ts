/**
 * Variant Generator Module
 *
 * Calls Bedrock Converse API to generate 3 diverse prompt/config variants
 * from a set of source recommendations. Each variant uses a distinct
 * rewrite strategy (conciseness, example-heavy, restructured).
 *
 * Validates each generated variant against:
 * - Structural constraints (valid targetField, non-empty targetName)
 * - Surface scope containment (variant surfaces ⊆ source surfaces)
 * - System prompt safety (R20: dynamic params, thinking/messaging blocks, no new examples)
 *
 * Retries once per failed variant before marking it as failed.
 *
 * Resolves the `variant_generation` prompt for the executing run via
 * {@link resolvePromptForRun} (R11.2 — the run's pinned snapshot is
 * the source of truth, falling back to the live registry for
 * pre-feature runs). The Bedrock Converse `inferenceConfig` is built
 * from the resolved prompt by {@link buildInferenceConfig} so the wire
 * shape always matches the resolved model's capability profile (R17.4).
 *
 * The default `variant_generation` model is Anthropic Claude Sonnet 4.6
 * (`anthropic_claude_4x` profile). The profile forbids `temperature`
 * so the registry's declared `temperature: 0.7` value is silently
 * dropped on the wire per R17.4 — the model runs at Anthropic's default
 * sampling temperature and diversity comes from the prompt's explicit
 * "DISTINCT rewrite strategy" instruction. Operators who want
 * temperature-driven diversity can switch the model to Nova Pro / Nova
 * Premier on the Prompts page; the registry's declared
 * `temperature: 0.7` value starts being honoured on the wire when a
 * `amazon_nova` profile model is resolved. See the registry definition
 * file's module header for the full decision rationale.
 *
 * Migrated from a hardcoded inline `SYSTEM_PROMPT` literal and a
 * `BEDROCK_MODEL_ID` env-var fallback to the registry (Wave 2 —
 * Task 17.4 of the prompt-management spec). The legacy
 * `BEDROCK_MODEL_ID` env var is still set in
 * `lib/orchestration-construct.ts` as a Wave-2 safety net and is
 * removed in Wave 3.
 *
 * Requirements: 5.1, 5.2, 5.3, 5.4, 13.3, 20.4, 10.1, 11.2, 11.3, 17.4
 *
 * @module variant-generator
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ContentBlock,
  type ConverseCommandInput,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";

import { validateRecommendations } from "./validation";
import { validateSystemPromptSafety } from "./system-prompt-safety";
import {
  buildInferenceConfig,
  type ResolvedPrompt,
} from "./prompt-registry";
import { resolvePromptForRun } from "./prompt-registry/runtime";
import type {
  VariantConfig,
  PerSuiteRecommendation,
  AgentSnapshot,
  Recommendation,
  RecommendationTarget,
} from "../../shared/types";

// ---------------------------------------------------------------------------
// Public Types
// ---------------------------------------------------------------------------

export interface VariantGenerationInput {
  sourceRecommendations: PerSuiteRecommendation[];
  agentSnapshot: AgentSnapshot;
  agentId: string;
  /**
   * The run id whose pinned snapshot supplies the `variant_generation`
   * prompt (R11.2 / R11.3). The empty string falls back to the live
   * registry — used by unit tests and the rare pre-feature run path
   * where no snapshot was captured at run start.
   */
  runId: string;
}

export interface VariantGenerationResult {
  variants: VariantConfig[];
  failedVariants: string[]; // variant letters that failed after retry
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";

/** Throttle retry configuration for Bedrock calls. */
const THROTTLE_MAX_RETRIES = 2;
const THROTTLE_BASE_MS = 1000;
const THROTTLE_CAP_MS = 10000;

// ---------------------------------------------------------------------------
// Bedrock Client (lazy singleton with test injection)
// ---------------------------------------------------------------------------

type SendableBedrockClient = Pick<BedrockRuntimeClient, "send">;

let bedrockClient: SendableBedrockClient | null = null;

function getBedrockClient(): SendableBedrockClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

/** @internal — allows test injection */
export function _setBedrockClient(client: SendableBedrockClient | null): void {
  bedrockClient = client;
}

// ---------------------------------------------------------------------------
// Prompt Templates
// ---------------------------------------------------------------------------

/**
 * Builds the user message for the Bedrock Converse call.
 *
 * The system prompt is supplied separately by the registry-resolved
 * {@link ResolvedPrompt.text}; this helper only constructs the
 * per-invocation user message that carries the source recommendations,
 * agent snapshot, and the per-variant output instructions.
 */
function buildUserMessage(input: VariantGenerationInput): string {
  const { sourceRecommendations, agentSnapshot } = input;

  const toolsSection = formatTools(agentSnapshot.tools);
  const systemPromptSection = agentSnapshot.systemPrompt || "(No system prompt configured)";
  const recsJson = JSON.stringify(
    sourceRecommendations.map((r) => ({
      targetField: r.targetField,
      targetName: r.targetName,
      currentText: r.currentText,
      suggestedText: r.suggestedText,
      rationale: r.rationale,
    })),
    null,
    2
  );

  return `## Source Recommendations
${recsJson}

## Current Agent Configuration
${toolsSection}

## Current System Prompt
${systemPromptSection}

## Instructions
For each of the 3 variants (A=conciseness, B=example-heavy, C=restructured), produce a complete set of recommendations that replace the source recommendations. Each variant's recommendations target the same Tool_Surface values as the source but with the variant's distinct strategy applied.

Output format:
{
  "variants": [
    {
      "variantLetter": "A",
      "strategy": "conciseness",
      "recommendations": [
        {
          "targetField": "tool_instruction" | "tool_description" | "tool_examples" | "system_prompt",
          "targetName": "<tool name or 'system_prompt'>",
          "currentText": "<exact existing text from the agent config>",
          "suggestedText": "<your rewritten text>",
          "rationale": "<brief explanation of the change>"
        }
      ]
    },
    { "variantLetter": "B", "strategy": "example-heavy", "recommendations": [...] },
    { "variantLetter": "C", "strategy": "restructured", "recommendations": [...] }
  ]
}`;
}

/**
 * Builds a retry prompt that includes the failure reason for a specific variant.
 */
function buildRetryUserMessage(
  input: VariantGenerationInput,
  variantLetter: string,
  strategy: string,
  failureReason: string
): string {
  const { sourceRecommendations, agentSnapshot } = input;

  const toolsSection = formatTools(agentSnapshot.tools);
  const systemPromptSection = agentSnapshot.systemPrompt || "(No system prompt configured)";
  const recsJson = JSON.stringify(
    sourceRecommendations.map((r) => ({
      targetField: r.targetField,
      targetName: r.targetName,
      currentText: r.currentText,
      suggestedText: r.suggestedText,
      rationale: r.rationale,
    })),
    null,
    2
  );

  return `## Source Recommendations
${recsJson}

## Current Agent Configuration
${toolsSection}

## Current System Prompt
${systemPromptSection}

## Retry Instructions
Your previous attempt for Variant ${variantLetter} (strategy: ${strategy}) was REJECTED because:
${failureReason}

Please regenerate ONLY Variant ${variantLetter} with strategy "${strategy}", fixing the issues above. The variant must pass all validation rules.

Output format (single variant only):
{
  "variants": [
    {
      "variantLetter": "${variantLetter}",
      "strategy": "${strategy}",
      "recommendations": [
        {
          "targetField": "tool_instruction" | "tool_description" | "tool_examples" | "system_prompt",
          "targetName": "<tool name or 'system_prompt'>",
          "currentText": "<exact existing text from the agent config>",
          "suggestedText": "<your rewritten text>",
          "rationale": "<brief explanation of the change>"
        }
      ]
    }
  ]
}`;
}

/**
 * Formats tool definitions for inclusion in the Bedrock prompt.
 */
function formatTools(tools: AgentSnapshot["tools"]): string {
  if (!tools || tools.length === 0) {
    return "(No tools configured)";
  }

  return tools
    .map((tool) => {
      const parts: string[] = [
        `### Tool: ${tool.toolName}`,
        `Type: ${tool.toolType}`,
        `Description: ${tool.description}`,
      ];
      if (tool.instruction) {
        parts.push(`Instruction: ${tool.instruction}`);
      }
      if (tool.examples && tool.examples.length > 0) {
        parts.push(`Examples:\n${tool.examples.map((e, i) => `  ${i + 1}. ${e}`).join("\n")}`);
      }
      return parts.join("\n");
    })
    .join("\n\n");
}

// ---------------------------------------------------------------------------
// Bedrock Call with Throttle Retry
// ---------------------------------------------------------------------------

/**
 * Issue a single Converse call against the registry-resolved prompt,
 * with bounded throttle retry. The `prompt` argument is the
 * {@link ResolvedPrompt} returned once per `generateVariants`
 * invocation by {@link resolvePromptForRun}; the resolver's per-warm
 * cache means a multi-call retry path inside a single `generateVariants`
 * invocation reuses the same triple without hitting DynamoDB again.
 */
async function callBedrock(
  prompt: ResolvedPrompt,
  userMessage: string,
): Promise<string> {
  const messages: Message[] = [
    {
      role: "user",
      content: [{ text: userMessage }] as ContentBlock[],
    },
  ];

  // The wire-shape helper places the resolved inference parameters
  // into the exact arguments the Converse SDK expects for the
  // resolved model's capability profile. For Anthropic Claude 4.x
  // (the default `variant_generation` model) this emits
  // `{ inferenceConfig: { maxTokens } }` with no `temperature`,
  // `topP`, `topK`, or `stopSequences` — those keys are forbidden by
  // the profile (R17.4) and are silently dropped here even though the
  // registry's `defaultInferenceValues` carries `temperature: 0.7`
  // for the Nova-friendly variants. For `amazon_nova` profile models
  // the helper emits `{ inferenceConfig: { maxTokens, temperature,
  // topP, stopSequences }, additionalModelRequestFields: { inferenceConfig: { topK } } }`
  // (with whichever subset of those keys the resolved prompt carries).
  // Same pattern as `customer-simulator.ts`, `comparison-summary.ts`,
  // `analysis.ts`, etc.
  const built = buildInferenceConfig(prompt);

  // The casts on `inferenceConfig` and `additionalModelRequestFields`
  // bridge the SDK's strict types (`InferenceConfiguration` for the
  // top-level config, `DocumentType` for the additional fields) and
  // our runtime payload — `buildInferenceConfig` already enforced
  // the exact key set against the resolved capability profile, so
  // the values are guaranteed JSON-encodable at runtime.
  const command = new ConverseCommand({
    modelId: prompt.modelId,
    system: [{ text: prompt.text }],
    messages,
    inferenceConfig:
      built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(built.additionalModelRequestFields
      ? {
          additionalModelRequestFields:
            built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  const client = getBedrockClient();

  let lastError: unknown = null;
  for (let attempt = 0; attempt <= THROTTLE_MAX_RETRIES; attempt++) {
    try {
      const resp = await client.send(command);
      const text = resp.output?.message?.content
        ?.map((b) => ("text" in b ? b.text ?? "" : ""))
        .join("");
      if (!text || text.trim().length === 0) {
        throw new Error("Bedrock returned an empty variant generation response.");
      }
      return text.trim();
    } catch (error) {
      lastError = error;
      const errorName = (error as { name?: string })?.name ?? "";
      if (errorName !== "ThrottlingException") {
        throw error;
      }
      if (attempt === THROTTLE_MAX_RETRIES) {
        throw error;
      }
      await sleepWithBackoff(attempt, THROTTLE_BASE_MS, THROTTLE_CAP_MS);
    }
  }

  throw lastError instanceof Error
    ? lastError
    : new Error("Bedrock retry loop exited without a result.");
}

// ---------------------------------------------------------------------------
// Response Parsing
// ---------------------------------------------------------------------------

interface ParsedVariantResponse {
  variants: Array<{
    variantLetter: string;
    strategy: string;
    recommendations: Array<{
      targetField: string;
      targetName: string;
      currentText: string;
      suggestedText: string;
      rationale: string;
    }>;
  }>;
}

/**
 * Parses the Bedrock response text into structured variant data.
 * Handles JSON potentially wrapped in code fences.
 */
function parseBedrockResponse(text: string): ParsedVariantResponse {
  // Strip code fences if the model wraps its output
  let cleaned = text;
  const fenceMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/);
  if (fenceMatch) {
    cleaned = fenceMatch[1];
  }

  try {
    const parsed = JSON.parse(cleaned);
    if (!parsed || !Array.isArray(parsed.variants)) {
      throw new Error("Response does not contain a 'variants' array.");
    }
    return parsed as ParsedVariantResponse;
  } catch (err) {
    throw new Error(
      `Failed to parse Bedrock variant generation response as JSON: ${(err as Error).message}`
    );
  }
}

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

interface ValidationFailure {
  variantLetter: string;
  reasons: string[];
}

/**
 * Validates a single parsed variant against:
 * 1. Structural constraints (via validateRecommendations)
 * 2. Surface scope containment (variant surfaces ⊆ source surfaces)
 * 3. System prompt safety (if system_prompt is targeted)
 */
function validateVariant(
  variant: ParsedVariantResponse["variants"][number],
  sourceSurfaces: ReadonlySet<RecommendationTarget>,
  originalSystemPrompt: string
): ValidationFailure | null {
  const reasons: string[] = [];

  // Convert parsed recommendations to typed Recommendation objects
  const recs: Recommendation[] = variant.recommendations.map((r) => ({
    targetField: r.targetField as RecommendationTarget,
    targetName: r.targetName,
    currentText: r.currentText ?? "",
    suggestedText: r.suggestedText ?? "",
    rationale: r.rationale ?? "",
  }));

  // 1. Structural validation
  const structuralResult = validateRecommendations(recs);
  if (!structuralResult.valid) {
    reasons.push(...structuralResult.errors);
  }

  // 2. Surface scope containment: variant's targetField set ⊆ source's targetField set
  const variantSurfaces = new Set(recs.map((r) => r.targetField));
  for (const surface of variantSurfaces) {
    if (!sourceSurfaces.has(surface)) {
      reasons.push(
        `Variant introduces changes to "${surface}" which is not present in the source recommendations. ` +
          `Variants must only target surfaces that were already recommended.`
      );
    }
  }

  // 3. System prompt safety (only if system_prompt is targeted)
  if (variantSurfaces.has("system_prompt") && originalSystemPrompt) {
    const systemPromptRecs = recs.filter((r) => r.targetField === "system_prompt");
    for (const rec of systemPromptRecs) {
      if (rec.suggestedText) {
        const safetyResult = validateSystemPromptSafety(
          originalSystemPrompt,
          rec.suggestedText
        );
        if (!safetyResult.valid) {
          reasons.push(
            ...safetyResult.violations.map(
              (v) => `System prompt safety violation: ${v}`
            )
          );
        }
      }
    }
  }

  if (reasons.length > 0) {
    return { variantLetter: variant.variantLetter, reasons };
  }
  return null;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Generates 3 diverse variants from the source recommendations by calling
 * Bedrock Converse against the run-pinned `variant_generation` prompt.
 *
 * Each variant is validated against structural constraints, surface scope
 * containment, and system prompt safety rules. Failed variants are retried
 * once with the failure reason injected into the user message.
 *
 * R11.2 / R11.3: the prompt is resolved exactly once at the top of the
 * function via {@link resolvePromptForRun}. The resolver's per-warm
 * cache (keyed by `runId`) means the retry path inside this invocation
 * reuses the cached snapshot read without hitting DynamoDB again. A
 * resolution failure propagates as a `PromptResolutionError` (R16.3) —
 * we intentionally do NOT catch it here so the caller can surface the
 * structured error rather than have it re-wrapped as a Bedrock failure.
 *
 * Requirements: 5.1, 5.2, 5.3, 5.4, 13.3, 20.4, 10.1, 11.2, 11.3, 17.4
 */
export async function generateVariants(
  input: VariantGenerationInput
): Promise<VariantGenerationResult> {
  const { sourceRecommendations, agentSnapshot, runId } = input;

  // R11.2 / R11.3: resolve the prompt once per call. The runtime
  // helper caches the snapshot read per warm so repeated invocations
  // for the same run issue at most one DDB read regardless of retry
  // count. A failure here propagates naturally as a
  // `PromptResolutionError` (R16.3); we do NOT catch it inside the
  // Bedrock try/catch below so the structured error surfaces with its
  // original shape rather than being re-wrapped.
  const prompt = await resolvePromptForRun("variant_generation", runId);

  // Compute the set of source surfaces for scope containment checks
  const sourceSurfaces = new Set<RecommendationTarget>(
    sourceRecommendations.map((r) => r.targetField)
  );

  // --- Initial generation: request all 3 variants ---
  const userMessage = buildUserMessage(input);
  const responseText = await callBedrock(prompt, userMessage);
  const parsed = parseBedrockResponse(responseText);

  // Map parsed variants to VariantConfig objects after validation
  const validVariants: VariantConfig[] = [];
  const failedVariants: string[] = [];
  const needsRetry: Array<{
    variantLetter: string;
    strategy: string;
    failureReason: string;
  }> = [];

  for (const parsedVariant of parsed.variants) {
    const failure = validateVariant(
      parsedVariant,
      sourceSurfaces,
      agentSnapshot.systemPrompt
    );

    if (!failure) {
      validVariants.push(toVariantConfig(parsedVariant));
    } else {
      needsRetry.push({
        variantLetter: parsedVariant.variantLetter,
        strategy: parsedVariant.strategy,
        failureReason: failure.reasons.join("\n"),
      });
    }
  }

  // --- Retry once per failed variant ---
  for (const retry of needsRetry) {
    try {
      const retryMessage = buildRetryUserMessage(
        input,
        retry.variantLetter,
        retry.strategy,
        retry.failureReason
      );
      const retryResponseText = await callBedrock(prompt, retryMessage);
      const retryParsed = parseBedrockResponse(retryResponseText);

      const retryVariant = retryParsed.variants.find(
        (v) => v.variantLetter === retry.variantLetter
      );

      if (!retryVariant) {
        failedVariants.push(retry.variantLetter);
        continue;
      }

      const retryFailure = validateVariant(
        retryVariant,
        sourceSurfaces,
        agentSnapshot.systemPrompt
      );

      if (!retryFailure) {
        validVariants.push(toVariantConfig(retryVariant));
      } else {
        failedVariants.push(retry.variantLetter);
      }
    } catch {
      // If the retry Bedrock call itself fails, mark variant as failed
      failedVariants.push(retry.variantLetter);
    }
  }

  return {
    variants: validVariants,
    failedVariants,
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Converts a parsed variant response object to a typed VariantConfig.
 */
function toVariantConfig(
  parsed: ParsedVariantResponse["variants"][number]
): VariantConfig {
  return {
    variantLetter: parsed.variantLetter as "A" | "B" | "C",
    strategy: parsed.strategy,
    recommendations: parsed.recommendations.map((r) => ({
      targetField: r.targetField as RecommendationTarget,
      targetName: r.targetName,
      currentText: r.currentText ?? "",
      suggestedText: r.suggestedText ?? "",
      rationale: r.rationale ?? "",
    })),
  };
}

/**
 * Full-jitter exponential backoff bounded by capMs.
 */
function sleepWithBackoff(
  attempt: number,
  baseMs: number,
  capMs: number
): Promise<void> {
  const computed = Math.min(baseMs * Math.pow(2, attempt), capMs);
  const delay = Math.random() * computed;
  return new Promise((resolve) => setTimeout(resolve, delay));
}
