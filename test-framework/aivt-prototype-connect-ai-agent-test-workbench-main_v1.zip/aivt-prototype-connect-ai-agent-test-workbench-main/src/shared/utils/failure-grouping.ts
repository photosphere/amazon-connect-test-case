/**
 * Failure-grouping utilities shared by the per-case Analysis Lambda
 * (`src/backend/handlers/analysis.ts`), the Failure Analysis page
 * (`src/frontend/src/pages/FailureAnalysis.tsx`), the Run Dashboard's
 * Recommended_Changes_Panel (`src/frontend/src/components/RecommendedChangesPanel.tsx`),
 * and the Case Detail page (`src/frontend/src/pages/CaseDetail.tsx`).
 *
 * The design's Reuse Map calls for "three call sites with one tested
 * implementation" — this module is that single canonical home so that the
 * per-case grouping behavior cannot drift between the backend writer and the
 * frontend consumers (R11.1, R13.1).
 *
 * Constraints on this module (R13.1, design "Reuse Map"):
 *   - Pure TypeScript only — no React, no AWS SDK, no I/O.
 *   - Imports the canonical {@link Recommendation} shape from
 *     `src/shared/types.ts` so there is exactly one Recommendation type
 *     across the codebase.
 *
 * @module utils/failure-grouping
 */

import type { Recommendation } from "../types";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/**
 * Analysis result for a single failed test case. The persisted shape under
 * `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` projects to this type after the
 * `generatedAt` and `modelId` fields are stripped (those metadata fields live
 * on the persisted record but are not part of the grouping input).
 */
export interface FailureCaseAnalysis {
  caseId: string;
  /** Root cause category (e.g. "overlapping_tool_descriptions"). */
  rootCauseCategory: string;
  /** Plain-language explanation incorporating reasoning trace evidence. */
  explanation: string;
  /** Whether reasoning trace was available for analysis. */
  traceAvailable: boolean;
  /** 1–5 actionable recommendations. */
  recommendations: Recommendation[];
}

/** A group of failures sharing the same root cause category. */
export interface FailureGroup {
  rootCauseCategory: string;
  /** All case IDs in this group (length >= 2; cases of length 1 stay individual). */
  caseIds: string[];
  /** Consolidated explanation for the group (taken from the first case). */
  explanation: string;
  /** Consolidated recommendations, deduplicated by `targetField + targetName`. */
  recommendations: Recommendation[];
}

// ---------------------------------------------------------------------------
// Grouping
// ---------------------------------------------------------------------------

/**
 * Maximum number of recommendations to surface per consolidated group. Caps
 * the deduplicated list so the panel does not flood the user with every
 * possible edit when many cases collapse into one root-cause bucket.
 */
const MAX_RECOMMENDATIONS_PER_GROUP = 5;

/**
 * Groups failure analyses by root cause category.
 *
 * Categories with 2+ failures collapse into a single {@link FailureGroup}
 * with deduplicated recommendations; categories with exactly one failure
 * remain as {@link FailureCaseAnalysis} entries in `individual`. The split
 * is total — every input record appears in exactly one of the two output
 * arrays (the grouping property test in `tests/unit/properties/failure-grouping.test.ts`
 * proves this invariant for any input).
 *
 * Pure function — no I/O, no clock, no globals (R13.1, R15.1).
 */
export function groupFailuresByRootCause(
  analyses: FailureCaseAnalysis[]
): { individual: FailureCaseAnalysis[]; grouped: FailureGroup[] } {
  // Count occurrences of each root cause category, preserving first-seen order.
  const categoryMap = new Map<string, FailureCaseAnalysis[]>();

  for (const analysis of analyses) {
    const existing = categoryMap.get(analysis.rootCauseCategory) || [];
    existing.push(analysis);
    categoryMap.set(analysis.rootCauseCategory, existing);
  }

  const individual: FailureCaseAnalysis[] = [];
  const grouped: FailureGroup[] = [];

  categoryMap.forEach((cases, category) => {
    if (cases.length >= 2) {
      // Consolidate into a group.
      grouped.push({
        rootCauseCategory: category,
        caseIds: cases.map((c) => c.caseId),
        // Use the first case's explanation as representative (it has the most evidence).
        explanation: cases[0].explanation,
        // Deduplicate recommendations by targetField + targetName.
        recommendations: deduplicateRecommendations(
          cases.flatMap((c) => c.recommendations)
        ),
      });
    } else {
      individual.push(...cases);
    }
  });

  return { individual, grouped };
}

/**
 * Deduplicate recommendations that target the same `targetField + targetName`
 * pair. Keeps the first occurrence (which typically has the most relevant
 * context) and caps the result at {@link MAX_RECOMMENDATIONS_PER_GROUP}.
 *
 * Pure function — no I/O, no clock, no globals (R13.1, R15.1).
 */
export function deduplicateRecommendations(
  recommendations: Recommendation[]
): Recommendation[] {
  const seen = new Set<string>();
  const deduped: Recommendation[] = [];

  for (const rec of recommendations) {
    const key = `${rec.targetField}::${rec.targetName}`;
    if (!seen.has(key)) {
      seen.add(key);
      deduped.push(rec);
    }
  }

  // Cap at MAX_RECOMMENDATIONS_PER_GROUP recommendations per group.
  return deduped.slice(0, MAX_RECOMMENDATIONS_PER_GROUP);
}
