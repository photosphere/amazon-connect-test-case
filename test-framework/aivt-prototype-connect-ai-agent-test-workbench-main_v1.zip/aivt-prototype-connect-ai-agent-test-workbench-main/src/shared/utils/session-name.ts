/**
 * Session name generation for Q in Connect sessions.
 *
 * CreateSession requires a `name` parameter. We generate names in the
 * format `test-{8 hex chars}` using crypto.randomBytes for cryptographic
 * randomness.
 *
 * @module session-name
 */

import { randomBytes } from "crypto";

/**
 * Generates a unique session name for a Q in Connect test session.
 *
 * Format: `test-{8 lowercase hex characters}`
 * Example: `test-a1b2c3d4`
 *
 * @returns A session name matching the regex `^test-[0-9a-f]{8}$`
 */
export function generateSessionName(): string {
  const hex = randomBytes(4).toString("hex");
  return `test-${hex}`;
}
