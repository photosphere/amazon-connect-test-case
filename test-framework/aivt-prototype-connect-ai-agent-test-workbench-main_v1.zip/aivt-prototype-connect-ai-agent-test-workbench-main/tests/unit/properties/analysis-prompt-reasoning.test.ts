// Feature: trace-reasoning-and-latency, Properties 14–15: Suite prompt reasoning
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import {
  buildUserMessage,
  formatCaseReasoningTrace,
} from "@backend/handlers/suite-recommend";
import type { PersistedCaseAnalysis } from "@backend/handlers/suite-recommend";
import type {
  AgentSnapshot,
  ExecutionStep,
  ExecutionTrace,
  TestCaseResult,
  ToolDefinition,
} from "@shared/types";
import { CaseStatus } from "@shared/enums";

// ---------------------------------------------------------------------------
// Shared Arbitraries
// ---------------------------------------------------------------------------

/** Non-empty alphanumeric string for IDs. */
const idArb = fc
  .string({ minLength: 1, maxLength: 30 })
  .filter((s) => /^[a-zA-Z0-9_-]+$/.test(s));

/** Non-empty printable string for reasoning text. */
const reasoningTextArb = fc
  .string({ minLength: 1, maxLength: 200 })
  .filter((s) => s.trim().length > 0);

/** ISO timestamp arbitrary. */
const timestampArb = fc
  .date({ min: new Date("2024-01-01"), max: new Date("2026-01-01") })
  .map((d) => d.toISOString());

/** Minimal valid ToolDefinition. */
const toolDefinitionArb: fc.Arbitrary<ToolDefinition> = fc.record({
  toolName: idArb,
  toolType: fc.constant("TOOL"),
  description: fc.string({ minLength: 1, maxLength: 100 }),
  instruction: fc.option(fc.string({ minLength: 1, maxLength: 100 }), { nil: undefined }),
  inputSchema: fc.constant({}),
  examples: fc.array(fc.string({ minLength: 1, maxLength: 50 }), { minLength: 0, maxLength: 3 }),
});

/** Minimal valid AgentSnapshot. */
const snapshotArb: fc.Arbitrary<AgentSnapshot> = fc.record({
  tools: fc.array(toolDefinitionArb, { minLength: 1, maxLength: 3 }),
  systemPrompt: fc.string({ minLength: 1, maxLength: 200 }),
  modelId: fc.constant("us.anthropic.claude-sonnet-4-20250514-v1:0"),
  capturedAt: timestampArb,
});

/** ExecutionStep WITH non-empty reasoning. */
const stepWithReasoningArb: fc.Arbitrary<ExecutionStep> = fc.record({
  index: fc.nat({ max: 50 }),
  type: fc.constant("inference" as const),
  spanName: fc.constant("inference"),
  text: fc.option(fc.string({ minLength: 1, maxLength: 100 }), { nil: undefined }),
  timestamp: fc.option(timestampArb, { nil: undefined }),
  durationMs: fc.option(fc.nat({ max: 86400000 }), { nil: undefined }),
  reasoning: reasoningTextArb,
});

/** ExecutionStep WITHOUT reasoning (undefined). */
const stepWithoutReasoningArb: fc.Arbitrary<ExecutionStep> = fc.record({
  index: fc.nat({ max: 50 }),
  type: fc.constantFrom("inference" as const, "tool" as const, "agent" as const),
  spanName: fc.constantFrom("inference", "execute_tool", "agent_step"),
  text: fc.option(fc.string({ minLength: 1, maxLength: 100 }), { nil: undefined }),
  timestamp: fc.option(timestampArb, { nil: undefined }),
  durationMs: fc.option(fc.nat({ max: 86400000 }), { nil: undefined }),
  reasoning: fc.constant(undefined),
});

/** ExecutionTrace with at least one step carrying reasoning. */
const traceWithReasoningArb: fc.Arbitrary<ExecutionTrace> = fc
  .tuple(
    fc.array(stepWithReasoningArb, { minLength: 1, maxLength: 3 }),
    fc.array(stepWithoutReasoningArb, { minLength: 0, maxLength: 3 }),
  )
  .map(([withReasoning, withoutReasoning]) => {
    // Merge and assign unique indices
    const allSteps = [...withReasoning, ...withoutReasoning].map((s, i) => ({
      ...s,
      index: i,
    }));
    return {
      sessionId: "sess-test-001",
      steps: allSteps,
      toolSequence: [],
      capturedAt: new Date().toISOString(),
    };
  });

/** ExecutionTrace with NO reasoning on any step. */
const traceWithoutReasoningArb: fc.Arbitrary<ExecutionTrace> = fc
  .array(stepWithoutReasoningArb, { minLength: 1, maxLength: 5 })
  .map((steps) => ({
    sessionId: "sess-test-002",
    steps: steps.map((s, i) => ({ ...s, index: i })),
    toolSequence: [],
    capturedAt: new Date().toISOString(),
  }));

/** Minimal PersistedCaseAnalysis. */
const caseAnalysisArb: fc.Arbitrary<PersistedCaseAnalysis> = fc.record({
  caseId: idArb,
  rootCauseCategory: fc.constantFrom("tool_misuse", "goal_misunderstanding", "hallucination"),
  explanation: fc.string({ minLength: 5, maxLength: 150 }),
  traceAvailable: fc.constant(true),
  recommendations: fc.array(
    fc.record({
      targetField: fc.constantFrom(
        "tool_description" as const,
        "tool_instruction" as const,
        "tool_examples" as const,
        "system_prompt" as const,
      ),
      targetName: idArb,
      currentText: fc.string({ minLength: 1, maxLength: 50 }),
      suggestedText: fc.string({ minLength: 1, maxLength: 50 }),
      rationale: fc.string({ minLength: 1, maxLength: 50 }),
    }),
    { minLength: 0, maxLength: 2 },
  ),
  generatedAt: timestampArb,
  modelId: fc.constant("us.anthropic.claude-sonnet-4-20250514-v1:0"),
});

// ---------------------------------------------------------------------------
// Helper: build valid buildUserMessage inputs
// ---------------------------------------------------------------------------

interface SuitePromptInputs {
  failedCaseIds: string[];
  snapshot: AgentSnapshot;
  failedResults: TestCaseResult[];
  perCaseAnalyses: Map<string, PersistedCaseAnalysis>;
}

/**
 * Builds a set of valid inputs for `buildUserMessage` with at least one
 * case carrying reasoning on at least one step.
 */
const inputsWithReasoningArb: fc.Arbitrary<SuitePromptInputs> = fc
  .tuple(
    fc.array(idArb, { minLength: 1, maxLength: 3 }).chain((ids) => {
      // Deduplicate
      const uniqueIds = [...new Set(ids)];
      return fc.constant(uniqueIds.length > 0 ? uniqueIds : [ids[0]]);
    }),
    snapshotArb,
    traceWithReasoningArb,
    caseAnalysisArb,
  )
  .map(([caseIds, snapshot, traceWithReasoning, caseAnalysisTemplate]) => {
    const failedCaseIds = caseIds;

    // Build failedResults — at least the first case gets a trace with reasoning
    const failedResults: TestCaseResult[] = failedCaseIds.map((caseId, idx) => ({
      runId: "run-001",
      caseId,
      status: CaseStatus.FAILED,
      toolsInvoked: [],
      turnCount: 3,
      latencyMs: 1000,
      errorMessage: `Test case ${caseId} failed`,
      executionTrace: idx === 0 ? traceWithReasoning : undefined,
    }));

    // Build perCaseAnalyses map
    const perCaseAnalyses = new Map<string, PersistedCaseAnalysis>();
    for (const caseId of failedCaseIds) {
      perCaseAnalyses.set(caseId, { ...caseAnalysisTemplate, caseId });
    }

    return { failedCaseIds, snapshot, failedResults, perCaseAnalyses };
  });

/**
 * Builds a set of valid inputs for `buildUserMessage` where NO case
 * carries reasoning on any step.
 */
const inputsWithoutReasoningArb: fc.Arbitrary<SuitePromptInputs> = fc
  .tuple(
    fc.array(idArb, { minLength: 1, maxLength: 3 }).chain((ids) => {
      const uniqueIds = [...new Set(ids)];
      return fc.constant(uniqueIds.length > 0 ? uniqueIds : [ids[0]]);
    }),
    snapshotArb,
    traceWithoutReasoningArb,
    caseAnalysisArb,
  )
  .map(([caseIds, snapshot, traceNoReasoning, caseAnalysisTemplate]) => {
    const failedCaseIds = caseIds;

    // All cases carry traces without reasoning
    const failedResults: TestCaseResult[] = failedCaseIds.map((caseId) => ({
      runId: "run-001",
      caseId,
      status: CaseStatus.FAILED,
      toolsInvoked: [],
      turnCount: 3,
      latencyMs: 1000,
      errorMessage: `Test case ${caseId} failed`,
      executionTrace: traceNoReasoning,
    }));

    const perCaseAnalyses = new Map<string, PersistedCaseAnalysis>();
    for (const caseId of failedCaseIds) {
      perCaseAnalyses.set(caseId, { ...caseAnalysisTemplate, caseId });
    }

    return { failedCaseIds, snapshot, failedResults, perCaseAnalyses };
  });

// ---------------------------------------------------------------------------
// Property 14: Suite prompt includes per-case reasoning
// ---------------------------------------------------------------------------

describe("Feature: trace-reasoning-and-latency, Property 14: Suite prompt includes per-case reasoning", () => {
  /**
   * **Validates: Requirements 10.1**
   *
   * For any set of failed cases where at least one case's trace contains
   * non-empty reasoning on at least one step, the rendered suite-recommendation
   * user message SHALL include that case's reasoning trace in chronological
   * order within the per-case section.
   */
  it("includes #### Reasoning trace sub-section for cases with reasoning", () => {
    fc.assert(
      fc.property(inputsWithReasoningArb, (inputs) => {
        const output = buildUserMessage(inputs);

        // The output must contain a "#### Reasoning trace" sub-section
        expect(output).toContain("#### Reasoning trace");

        // Find the case that has reasoning (first case by construction)
        const firstResult = inputs.failedResults[0];
        const trace = firstResult.executionTrace!;
        const reasoningSteps = trace.steps
          .filter((s) => typeof s.reasoning === "string" && s.reasoning.length > 0)
          .sort((a, b) => a.index - b.index);

        // The reasoning trace section is what formatCaseReasoningTrace produces.
        // Verify the section output matches the expected format.
        const expectedReasoningBlock = formatCaseReasoningTrace(trace);
        expect(expectedReasoningBlock).toBeDefined();

        // The expected block must appear in the output
        expect(output).toContain(expectedReasoningBlock!);

        // Verify chronological ordering by checking the formatted block
        // has steps in index order (step N appears before step M when N < M)
        const reasoningSection = output.slice(output.indexOf("#### Reasoning trace"));
        for (const step of reasoningSteps) {
          // Each step's reasoning text must be in the reasoning section
          expect(reasoningSection).toContain(step.reasoning!);
        }

        // Verify chronological order within the reasoning section using step markers
        if (reasoningSteps.length > 1) {
          let lastPos = -1;
          for (const step of reasoningSteps) {
            const marker = `[step ${step.index}`;
            const pos = reasoningSection.indexOf(marker);
            expect(pos).toBeGreaterThan(lastPos);
            lastPos = pos;
          }
        }
      }),
      { numRuns: 100 },
    );
  });

  it("output is deterministic (same input → same output)", () => {
    fc.assert(
      fc.property(inputsWithReasoningArb, (inputs) => {
        const output1 = buildUserMessage(inputs);
        const output2 = buildUserMessage(inputs);
        expect(output1).toBe(output2);
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 15: Suite prompt backward compatibility
// ---------------------------------------------------------------------------

describe("Feature: trace-reasoning-and-latency, Property 15: Suite prompt backward compatibility", () => {
  /**
   * **Validates: Requirements 10.2**
   *
   * For any set of failed cases where NO case carries reasoning on any step
   * (all steps have reasoning undefined), the output does NOT contain
   * `#### Reasoning trace` or `### Reasoning trace`.
   */
  it("does NOT contain reasoning trace markers when no case has reasoning", () => {
    fc.assert(
      fc.property(inputsWithoutReasoningArb, (inputs) => {
        const output = buildUserMessage(inputs);

        // Must NOT contain any reasoning trace heading
        expect(output).not.toContain("#### Reasoning trace");
        expect(output).not.toContain("### Reasoning trace");
      }),
      { numRuns: 100 },
    );
  });

  it("output is deterministic (same input → same output)", () => {
    fc.assert(
      fc.property(inputsWithoutReasoningArb, (inputs) => {
        const output1 = buildUserMessage(inputs);
        const output2 = buildUserMessage(inputs);
        expect(output1).toBe(output2);
      }),
      { numRuns: 100 },
    );
  });
});
