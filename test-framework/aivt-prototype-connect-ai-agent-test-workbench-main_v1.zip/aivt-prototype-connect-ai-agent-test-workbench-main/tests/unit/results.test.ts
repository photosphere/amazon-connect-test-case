/**
 * Unit tests for the Results Lambda handler.
 *
 * Tests route handling, progress calculation, pagination, and error cases
 * by mocking the DynamoDB document client.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { CaseStatus, RunStatus } from "../../src/shared/enums";
import type { TestCaseResult, TestRun, TranscriptTurn } from "../../src/shared/types";

// Mock DynamoDB client
const mockSend = vi.fn();
const mockClient = { send: mockSend } as unknown as DynamoDBDocumentClient;

// Import after mock setup
import {
  handler,
  _setDDBClient,
  type APIGatewayEvent,
} from "../../src/backend/handlers/results";

describe("Results Lambda", () => {
  beforeEach(() => {
    _setDDBClient(mockClient);
    mockSend.mockReset();
  });

  afterEach(() => {
    _setDDBClient(null);
  });

  // -------------------------------------------------------------------------
  // Route: GET /runs/{runId}
  // -------------------------------------------------------------------------

  describe("GET /runs/{runId}", () => {
    const baseEvent: APIGatewayEvent = {
      httpMethod: "GET",
      resource: "/runs/{runId}",
      pathParameters: { runId: "run-123" },
      queryStringParameters: { suiteId: "suite-abc" },
    };

    it("returns 400 when runId is missing", async () => {
      const event: APIGatewayEvent = {
        ...baseEvent,
        pathParameters: {},
      };
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
      expect(JSON.parse(response.body).error).toContain("runId");
    });

    it("returns 404 when run is not found", async () => {
      // GetCommand for SUMMARY — not found
      mockSend.mockResolvedValueOnce({ Item: undefined });
      // Query for run records returns empty
      mockSend.mockResolvedValueOnce({ Items: [] });
      // Query for results also returns empty (fallback)
      mockSend.mockResolvedValueOnce({ Items: [] });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(404);
    });

    it("returns run with progress for a completed run", async () => {
      const run: TestRun = {
        suiteId: "suite-abc",
        runId: "run-123",
        status: RunStatus.COMPLETED,
        totalCases: 3,
        passed: 2,
        failed: 1,
        errors: 0,
        concurrency: 9,
        startTime: "2024-01-01T00:00:00Z",
        endTime: "2024-01-01T00:05:00Z",
        sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:test",
      };

      const results: TestCaseResult[] = [
        {
          runId: "run-123",
          caseId: "case-1",
          status: CaseStatus.PASSED,
          toolsInvoked: ["SearchFlights"],
          turnCount: 4,
          latencyMs: 12000,
          goalSuccessScore: 1.0,
          helpfulnessScore: 0.9,
          toolAccuracyScore: 1.0,
        },
        {
          runId: "run-123",
          caseId: "case-2",
          status: CaseStatus.PASSED,
          toolsInvoked: ["BookFlight", "ConfirmBooking"],
          turnCount: 6,
          latencyMs: 18000,
          goalSuccessScore: 1.0,
          helpfulnessScore: 0.95,
          toolAccuracyScore: 1.0,
        },
        {
          runId: "run-123",
          caseId: "case-3",
          status: CaseStatus.FAILED,
          toolsInvoked: ["SearchFlights"],
          turnCount: 5,
          latencyMs: 15000,
          goalSuccessScore: 0.4,
          helpfulnessScore: 0.6,
          toolAccuracyScore: 0.5,
        },
      ];

      // First call: GetCommand for SUMMARY (not found — use suiteId fallback)
      mockSend.mockResolvedValueOnce({ Item: undefined });

      // Second call: query for run by suiteId (returns run items)
      mockSend.mockResolvedValueOnce({
        Items: [
          {
            PK: "SUITE#suite-abc",
            SK: "RUN#2024-01-01T00:00:00Z",
            ...run,
          },
        ],
      });

      // Third call: query for results
      mockSend.mockResolvedValueOnce({
        Items: results.map((r) => ({
          PK: `RUN#run-123`,
          SK: `CASE#${r.caseId}`,
          ...r,
        })),
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.run.runId).toBe("run-123");
      expect(body.run.status).toBe("completed");
      expect(body.progress.totalCases).toBe(3);
      expect(body.progress.completed).toBe(3);
      expect(body.progress.passed).toBe(2);
      expect(body.progress.failed).toBe(1);
      expect(body.progress.errors).toBe(0);
      expect(body.progress.accuracy).toBe(66.7);
      expect(body.results).toHaveLength(3);
    });

    it("returns partial results while run is in progress", async () => {
      const run: TestRun = {
        suiteId: "suite-abc",
        runId: "run-123",
        status: RunStatus.RUNNING,
        totalCases: 5,
        passed: 0,
        failed: 0,
        errors: 0,
        concurrency: 9,
        startTime: "2024-01-01T00:00:00Z",
        sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:test",
      };

      // Only 2 of 5 cases completed
      const results: TestCaseResult[] = [
        {
          runId: "run-123",
          caseId: "case-1",
          status: CaseStatus.PASSED,
          toolsInvoked: ["SearchFlights"],
          turnCount: 4,
          latencyMs: 12000,
        },
        {
          runId: "run-123",
          caseId: "case-2",
          status: CaseStatus.ERROR,
          toolsInvoked: [],
          turnCount: 1,
          latencyMs: 500,
          errorMessage: "Session creation failed",
        },
      ];

      // GetCommand for SUMMARY — not found (run in progress)
      mockSend.mockResolvedValueOnce({ Item: undefined });

      mockSend.mockResolvedValueOnce({
        Items: [{ PK: "SUITE#suite-abc", SK: "RUN#2024-01-01T00:00:00Z", ...run }],
      });
      mockSend.mockResolvedValueOnce({
        Items: results.map((r) => ({
          PK: `RUN#run-123`,
          SK: `CASE#${r.caseId}`,
          ...r,
        })),
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.run.status).toBe("running");
      expect(body.progress.totalCases).toBe(5);
      expect(body.progress.completed).toBe(2);
      expect(body.progress.passed).toBe(1);
      expect(body.progress.errors).toBe(1);
      // Results sorted: errors first
      expect(body.results[0].status).toBe("error");
      expect(body.results[1].status).toBe("passed");
    });

    it("sorts results with errors first, then failed, then passed", async () => {
      const run: TestRun = {
        suiteId: "suite-abc",
        runId: "run-123",
        status: RunStatus.COMPLETED,
        totalCases: 4,
        passed: 1,
        failed: 2,
        errors: 1,
        concurrency: 9,
        startTime: "2024-01-01T00:00:00Z",
        sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:test",
      };

      const results: TestCaseResult[] = [
        { runId: "run-123", caseId: "alpha", status: CaseStatus.PASSED, toolsInvoked: [], turnCount: 3, latencyMs: 1000 },
        { runId: "run-123", caseId: "beta", status: CaseStatus.FAILED, toolsInvoked: [], turnCount: 3, latencyMs: 1000 },
        { runId: "run-123", caseId: "gamma", status: CaseStatus.ERROR, toolsInvoked: [], turnCount: 1, latencyMs: 500 },
        { runId: "run-123", caseId: "delta", status: CaseStatus.FAILED, toolsInvoked: [], turnCount: 3, latencyMs: 1000 },
      ];

      // GetCommand for SUMMARY — not found
      mockSend.mockResolvedValueOnce({ Item: undefined });
      mockSend.mockResolvedValueOnce({
        Items: [{ PK: "SUITE#suite-abc", SK: "RUN#2024-01-01T00:00:00Z", ...run }],
      });
      mockSend.mockResolvedValueOnce({
        Items: results.map((r) => ({ PK: `RUN#run-123`, SK: `CASE#${r.caseId}`, ...r })),
      });

      const response = await handler(baseEvent);
      const body = JSON.parse(response.body);

      // Error first, then failed (alphabetical), then passed
      expect(body.results[0].caseId).toBe("gamma");
      expect(body.results[0].status).toBe("error");
      expect(body.results[1].status).toBe("failed");
      expect(body.results[2].status).toBe("failed");
      expect(body.results[3].caseId).toBe("alpha");
      expect(body.results[3].status).toBe("passed");
    });
  });

  // -------------------------------------------------------------------------
  // Route: GET /runs/{runId}/cases/{caseId}
  // -------------------------------------------------------------------------

  describe("GET /runs/{runId}/cases/{caseId}", () => {
    const baseEvent: APIGatewayEvent = {
      httpMethod: "GET",
      resource: "/runs/{runId}/cases/{caseId}",
      pathParameters: { runId: "run-123", caseId: "case-1" },
      queryStringParameters: null,
    };

    it("returns 400 when caseId is missing", async () => {
      const event: APIGatewayEvent = {
        ...baseEvent,
        pathParameters: { runId: "run-123" },
      };
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
    });

    it("returns 404 when result is not found", async () => {
      mockSend.mockResolvedValueOnce({ Item: undefined }); // getCaseResult
      mockSend.mockResolvedValueOnce({ Items: [] }); // getTranscript

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(404);
    });

    it("returns full result with transcript", async () => {
      const result: TestCaseResult = {
        runId: "run-123",
        caseId: "case-1",
        status: CaseStatus.PASSED,
        toolsInvoked: ["SearchFlights", "BookFlight"],
        turnCount: 6,
        latencyMs: 15000,
        goalSuccessScore: 1.0,
        helpfulnessScore: 0.9,
        toolAccuracyScore: 1.0,
      };

      const transcript: TranscriptTurn[] = [
        {
          turnNumber: 1,
          role: "customer",
          text: "I need to book a flight to Seattle",
          timestamp: "2024-01-01T00:00:01Z",
          elapsedMs: 0,
        },
        {
          turnNumber: 2,
          role: "agent",
          text: "Let me search for flights to Seattle.",
          toolSelected: "SearchFlights",
          timestamp: "2024-01-01T00:00:03Z",
          elapsedMs: 2000,
        },
        {
          turnNumber: 3,
          role: "customer",
          text: "I'd like the 9am option",
          timestamp: "2024-01-01T00:00:05Z",
          elapsedMs: 4000,
        },
        {
          turnNumber: 4,
          role: "agent",
          text: "I'll book that flight for you.",
          toolSelected: "BookFlight",
          timestamp: "2024-01-01T00:00:07Z",
          elapsedMs: 6000,
        },
      ];

      // GetCommand for result
      mockSend.mockResolvedValueOnce({
        Item: { PK: "RUN#run-123", SK: "CASE#case-1", ...result },
      });
      // QueryCommand for transcript
      mockSend.mockResolvedValueOnce({
        Items: transcript.map((t) => ({
          PK: "RUN#run-123#CASE#case-1",
          SK: `TURN#${String(t.turnNumber).padStart(4, "0")}`,
          ...t,
        })),
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.result.caseId).toBe("case-1");
      expect(body.result.status).toBe("passed");
      expect(body.result.toolsInvoked).toEqual(["SearchFlights", "BookFlight"]);
      expect(body.result.goalSuccessScore).toBe(1.0);
      expect(body.transcript).toHaveLength(4);
      expect(body.transcript[0].role).toBe("customer");
      expect(body.transcript[1].toolSelected).toBe("SearchFlights");
      expect(body.transcript[3].toolSelected).toBe("BookFlight");
    });
  });

  // -------------------------------------------------------------------------
  // Route: GET /suites/{suiteId}/runs
  // -------------------------------------------------------------------------

  describe("GET /suites/{suiteId}/runs", () => {
    const baseEvent: APIGatewayEvent = {
      httpMethod: "GET",
      resource: "/suites/{suiteId}/runs",
      pathParameters: { suiteId: "suite-abc" },
      queryStringParameters: null,
    };

    it("returns 400 when suiteId is missing", async () => {
      const event: APIGatewayEvent = {
        ...baseEvent,
        pathParameters: {},
      };
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
    });

    it("returns empty list when no runs exist", async () => {
      mockSend.mockResolvedValueOnce({ Items: [] });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.runs).toEqual([]);
      expect(body.nextToken).toBeUndefined();
    });

    it("returns runs in descending order", async () => {
      const runs: TestRun[] = [
        {
          suiteId: "suite-abc",
          runId: "run-3",
          status: RunStatus.COMPLETED,
          totalCases: 5,
          passed: 5,
          failed: 0,
          errors: 0,
          concurrency: 9,
          startTime: "2024-01-03T00:00:00Z",
          sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:run-3",
        },
        {
          suiteId: "suite-abc",
          runId: "run-2",
          status: RunStatus.COMPLETED,
          totalCases: 5,
          passed: 3,
          failed: 2,
          errors: 0,
          concurrency: 9,
          startTime: "2024-01-02T00:00:00Z",
          sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:run-2",
        },
        {
          suiteId: "suite-abc",
          runId: "run-1",
          status: RunStatus.FAILED,
          totalCases: 5,
          passed: 1,
          failed: 3,
          errors: 1,
          concurrency: 9,
          startTime: "2024-01-01T00:00:00Z",
          sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:run-1",
        },
      ];

      mockSend.mockResolvedValueOnce({
        Items: runs.map((r) => ({
          PK: `SUITE#suite-abc`,
          SK: `RUN#${r.startTime}`,
          ...r,
        })),
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.runs).toHaveLength(3);
      // Descending order
      expect(body.runs[0].runId).toBe("run-3");
      expect(body.runs[1].runId).toBe("run-2");
      expect(body.runs[2].runId).toBe("run-1");
    });

    it("includes nextToken when more results available", async () => {
      const lastKey = { PK: "SUITE#suite-abc", SK: "RUN#2024-01-01T00:00:00Z" };

      mockSend.mockResolvedValueOnce({
        Items: [
          {
            PK: "SUITE#suite-abc",
            SK: "RUN#2024-01-02T00:00:00Z",
            suiteId: "suite-abc",
            runId: "run-2",
            status: RunStatus.COMPLETED,
            totalCases: 5,
            passed: 5,
            failed: 0,
            errors: 0,
            concurrency: 9,
            startTime: "2024-01-02T00:00:00Z",
            sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:run-2",
          },
        ],
        LastEvaluatedKey: lastKey,
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.runs).toHaveLength(1);
      expect(body.nextToken).toBeDefined();

      // Decode the token to verify it's the last evaluated key
      const decoded = JSON.parse(
        Buffer.from(body.nextToken, "base64").toString("utf-8")
      );
      expect(decoded).toEqual(lastKey);
    });

    it("accepts nextToken for pagination", async () => {
      const lastKey = { PK: "SUITE#suite-abc", SK: "RUN#2024-01-01T00:00:00Z" };
      const token = Buffer.from(JSON.stringify(lastKey)).toString("base64");

      const event: APIGatewayEvent = {
        ...baseEvent,
        queryStringParameters: { nextToken: token },
      };

      mockSend.mockResolvedValueOnce({
        Items: [
          {
            PK: "SUITE#suite-abc",
            SK: "RUN#2023-12-31T00:00:00Z",
            suiteId: "suite-abc",
            runId: "run-1",
            status: RunStatus.COMPLETED,
            totalCases: 3,
            passed: 3,
            failed: 0,
            errors: 0,
            concurrency: 9,
            startTime: "2023-12-31T00:00:00Z",
            sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:run-1",
          },
        ],
      });

      const response = await handler(event);
      expect(response.statusCode).toBe(200);

      const body = JSON.parse(response.body);
      expect(body.runs).toHaveLength(1);
      expect(body.nextToken).toBeUndefined();
    });

    it("returns 400 for invalid nextToken", async () => {
      const event: APIGatewayEvent = {
        ...baseEvent,
        queryStringParameters: { nextToken: "not-valid-base64!!!" },
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(400);
      expect(JSON.parse(response.body).error).toContain("nextToken");
    });
  });

  // -------------------------------------------------------------------------
  // Method / Route errors
  // -------------------------------------------------------------------------

  describe("Error handling", () => {
    it("returns 405 for non-GET methods", async () => {
      const event: APIGatewayEvent = {
        httpMethod: "POST",
        resource: "/runs/{runId}",
        pathParameters: { runId: "run-123" },
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(405);
    });

    it("returns 404 for unknown routes", async () => {
      const event: APIGatewayEvent = {
        httpMethod: "GET",
        resource: "/unknown/route",
        pathParameters: null,
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(404);
    });

    it("returns 500 on unexpected DynamoDB errors", async () => {
      mockSend.mockRejectedValueOnce(new Error("DynamoDB connection timeout"));

      const event: APIGatewayEvent = {
        httpMethod: "GET",
        resource: "/runs/{runId}",
        pathParameters: { runId: "run-123" },
        queryStringParameters: { suiteId: "suite-abc" },
      };

      const response = await handler(event);
      expect(response.statusCode).toBe(500);
    });

    it("includes CORS headers on all responses", async () => {
      const event: APIGatewayEvent = {
        httpMethod: "GET",
        resource: "/unknown",
        pathParameters: null,
        queryStringParameters: null,
      };

      const response = await handler(event);
      expect(response.headers["Access-Control-Allow-Origin"]).toBe("*");
      expect(response.headers["Content-Type"]).toBe("application/json");
    });
  });

  // -------------------------------------------------------------------------
  // Route: GET /runs/{runId}/experiments
  // -------------------------------------------------------------------------

  describe("GET /runs/{runId}/experiments", () => {
    const baseEvent: APIGatewayEvent = {
      httpMethod: "GET",
      resource: "/runs/{runId}/experiments",
      pathParameters: { runId: "run-123" },
      queryStringParameters: null,
    };

    it("returns 400 when runId is missing", async () => {
      const event: APIGatewayEvent = {
        ...baseEvent,
        pathParameters: {},
      };
      const response = await handler(event);
      expect(response.statusCode).toBe(400);
      expect(JSON.parse(response.body).error).toContain("runId");
    });

    it("returns empty list (200, not 404) when run has no experiments", async () => {
      // Query returns no items.
      mockSend.mockResolvedValueOnce({ Items: [] });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.experiments).toEqual([]);
    });

    it("returns experiments sorted by createdAt descending (newest first)", async () => {
      mockSend.mockResolvedValueOnce({
        Items: [
          {
            PK: "RUN#run-123",
            SK: "EXPERIMENT#exp-old",
            experimentId: "exp-old",
            runId: "run-123",
            agentId: "agent-1",
            status: "completed",
            variantConfigs: [],
            temporaryAgentIds: { A: "", B: "", C: "" },
            variantRunIds: { A: "", B: "", C: "" },
            baselineRunId: "run-123",
            sfnExecutionArn: "arn:..",
            cleanupStatus: "success",
            createdAt: "2026-06-01T10:00:00Z",
          },
          {
            PK: "RUN#run-123",
            SK: "EXPERIMENT#exp-new",
            experimentId: "exp-new",
            runId: "run-123",
            agentId: "agent-1",
            status: "running",
            variantConfigs: [],
            temporaryAgentIds: { A: "", B: "", C: "" },
            variantRunIds: { A: "", B: "", C: "" },
            baselineRunId: "run-123",
            sfnExecutionArn: "arn:..",
            cleanupStatus: "pending",
            createdAt: "2026-06-08T10:00:00Z",
          },
        ],
      });

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.experiments).toHaveLength(2);
      // Newest first
      expect(body.experiments[0].experimentId).toBe("exp-new");
      expect(body.experiments[1].experimentId).toBe("exp-old");
    });

    it("strips DynamoDB key attributes from each experiment", async () => {
      mockSend.mockResolvedValueOnce({
        Items: [
          {
            PK: "RUN#run-123",
            SK: "EXPERIMENT#exp-1",
            GSI1PK: "x",
            experimentId: "exp-1",
            runId: "run-123",
            agentId: "agent-1",
            status: "completed",
            variantConfigs: [],
            temporaryAgentIds: { A: "", B: "", C: "" },
            variantRunIds: { A: "", B: "", C: "" },
            baselineRunId: "run-123",
            sfnExecutionArn: "arn:..",
            cleanupStatus: "success",
            createdAt: "2026-06-08T10:00:00Z",
          },
        ],
      });

      const response = await handler(baseEvent);
      const body = JSON.parse(response.body);
      expect(body.experiments[0].PK).toBeUndefined();
      expect(body.experiments[0].SK).toBeUndefined();
      expect(body.experiments[0].GSI1PK).toBeUndefined();
      expect(body.experiments[0].experimentId).toBe("exp-1");
    });

    it("returns 500 on unexpected DynamoDB errors", async () => {
      mockSend.mockRejectedValueOnce(new Error("DynamoDB connection timeout"));

      const response = await handler(baseEvent);
      expect(response.statusCode).toBe(500);
    });
  });
});
