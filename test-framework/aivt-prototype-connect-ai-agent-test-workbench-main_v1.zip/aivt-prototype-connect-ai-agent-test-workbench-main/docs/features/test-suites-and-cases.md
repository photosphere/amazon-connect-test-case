# Test suites and test cases

How tests are organized and authored.

## Suites

A **test suite** is a named bundle of test cases targeting one specific AI agent. Suites are the unit of execution: you run a suite, and the platform executes every case in it concurrently.

Suite fields (max sizes from `src/shared/constants.ts`):

| Field | Required | Limits |
|---|---|---|
| `name` | Yes | 1–128 characters |
| `description` | No | up to 500 characters |
| `agentId` | Yes | UUID of an `ORCHESTRATION` agent on the configured assistant |
| `ragThresholds` | No | one float in `[0,1]` per metric (faithfulness, correctness, completeness, helpfulness). Default 0.7 each. |

A suite belongs to a **tenant** (the authenticated Cognito principal). Suites are not visible across tenants.

## Test case types

The platform supports two test case types, discriminated by a required `type` field. A single suite may contain any mix.

### Tool-sequence cases

For multi-turn customer journeys where success means the agent invoked a specific ordered sequence of tools.

```typescript
interface ToolSequenceTestCase {
  type: "tool_sequence";
  name: string;                      // 1-100 chars
  description: string;               // 1-2000 chars
  goalDescription?: string;          // 1-2000 chars; drives both the simulator AND the AI scaffolder
  persona: string;
  style: "direct" | "indirect" | "colloquial" | "question" | "complaint";
  customerKnowledge: Record<string, string>;  // up to 20 pairs, each value <= 500 chars
  initialUtterance: string;          // up to 1000 chars
  successCriteria: ToolStep[];       // 1-30 steps
  sessionData?: Record<string, string>;       // optional, up to 20 pairs
  primingMessage?: string;           // optional opening system message
}

interface ToolStep {
  toolName: string;
  required: boolean;                 // defaults to true
  parameterChecks?: { paramName: string; expectedValue: string }[];  // up to 10 per step
}
```

**How execution works for these cases:**

1. The conversation driver creates a Q in Connect session.
2. If `primingMessage` is set, it's sent first (the agent's response is recorded but not treated as a customer turn).
3. If `sessionData` is set, it's pushed via `UpdateSessionData` before the customer turn.
4. The `initialUtterance` is sent as the first customer message.
5. The agent responds — either with a tool selection or a clarifying question.
6. If a clarifying question, the **customer simulator** (Bedrock Converse) responds in persona, using `customerKnowledge` as available facts. Repeats up to `MAX_TURNS` (default 20).
7. The platform extracts every tool selection from `conversationSessionData["Tool"]`.
8. After the conversation ends (final agent text or turn limit), `ListSpans` is called to capture the structured execution trace.

**Pass/fail logic:**
- The actual tool sequence is compared against `successCriteria`.
- Required steps must appear in order. Optional steps may be skipped.
- If `parameterChecks` are configured, each check is asserted against the actual tool call's arguments.
- The Bedrock judge separately scores `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` regardless of the deterministic pass/fail.

### RAG cases

For single-turn question/answer scenarios where success means the agent's natural-language response is grounded, correct, complete, and helpful.

```typescript
interface RagTestCase {
  type: "rag";
  name: string;                      // 1-100 chars
  description: string;               // 1-2000 chars
  question: string;                  // 1-1000 chars, the literal customer turn
  groundTruthAnswer: string;         // 1-4000 chars, the known-good agent reply
  sessionData?: Record<string, string>;
}
```

**How execution works for these cases:**

1. The conversation driver creates a session and sends `question` once.
2. The agent's terminal text response is captured.
3. `ListSpans` is called once after the response.
4. Retrieved chunks are extracted from every `execute_tool` span whose tool name matches the agent's `Retrieve` tool (resolved from the snapshot, typically `Retrieve` but the snapshot is authoritative).
5. Stage 2 of the run pipeline: a Bedrock RAG Evaluation job is submitted with the question, ground truth, agent response, and retrieved chunks for every RAG case in the run.
6. After the job completes, four metric scores per case are written to `TestCaseResult.ragMetrics`.

**Pass/fail logic:**
- AND across the four metrics: every threshold must be met.
- Faithfulness has a **hard gate** — falling below threshold fails the case regardless of other scores.

For the full RAG flow including Bedrock dataset format, see [rag-test-cases.md](rag-test-cases.md).

## AI-powered scaffolding

Authoring tool-sequence cases is tedious. The platform offers a one-click scaffold workflow.

**Endpoint:** `POST /suites/{suiteId}/cases/scaffold`

**Input:** the agent ID and a `goalDescription` (plain English).

**What happens:**
1. The Scaffold Lambda fetches the agent's full tool catalog via `GetAIAgent`.
2. It calls Bedrock with a structured prompt that includes every tool's name, description, instruction, and input schema, plus the goal description.
3. Bedrock returns an ordered tool sequence with each step labeled required or optional.
4. For each tool in the sequence, the Lambda analyzes the input schema and identifies all input parameters.
5. Bedrock generates a consolidated customer knowledge template with one field per unique parameter, mapping the technical parameter name to a customer-facing label.

**Output:** a `successCriteria` array and a `customerKnowledgeTemplate` array. The frontend pre-fills both into the case editor; the user fills in the actual values, edits/reorders steps, and saves.

**Failure modes:**
- Bedrock can't determine a sequence (ambiguous goal, no tool covers it) → `400 cannot_infer_sequence`. The user falls back to manual authoring.
- Bedrock returns malformed JSON → 500. Retry usually succeeds.

## Persistence

| Entity | DynamoDB key |
|---|---|
| Test suite | `PK=TENANT#{tenantId}, SK=SUITE#{suiteId}` |
| Test case | `PK=SUITE#{suiteId}, SK=CASE#{caseId}` |

Cases inherit tenant ownership through the parent suite — there's no direct tenant→case query.

GSI1 indexes suites by `PK=TENANT#{tenantId}, SK=updatedAt` for efficient list views sorted by recency.
GSI2 indexes suites by `PK=AGENT#{agentId}` for "find every suite that targets this agent" — useful when an agent is modified and you want to identify which suites should be re-run.

## Type extension contract

When persisted records predate a feature, the platform reads them gracefully:

- A `TestCase` with no `type` field is treated as `tool_sequence`.
- A `ToolDefinition` with no `examples` field is treated as having `examples: []`.

This allows feature evolution without backfill migrations — see how the actionable-recommendations feature added `tool_examples` support without touching prior records (`src/shared/types.ts` `ToolDefinition` documentation).
