// @vitest-environment jsdom
// Feature: actionable-recommendations, Property 2: No-failure empty state
/**
 * Property 2: No-failure empty state (over non-RUNNING statuses).
 *
 * **Validates: Requirements 15.2, 10.2, 10.3, 10.8 — with R10.8 taking
 * precedence over R15.2 in the RUNNING corner.**
 *
 * Spec resolution (R10.8 vs R15.2):
 *
 *   R15.2 specifies that for ANY run state where `failed === 0 &&
 *   errors === 0`, the Recommended_Changes_Panel render function SHALL
 *   return the empty-state element AND SHALL NOT call the
 *   Recommendation_Engine, regardless of any other run-state field
 *   values. R10.8 specifies that WHILE the run status is `running`, the
 *   panel SHALL render the placeholder "Recommendations will appear
 *   when the run completes" and SHALL NOT invoke the
 *   Recommendation_Engine. The two requirements collide when
 *   `runStatus === RUNNING && failedCount === 0 && errorCount === 0`:
 *   R10.8 mandates the RUNNING placeholder while R15.2 mandates the
 *   green empty-state Alert. The implementation (and the design's
 *   render-decision sequence) resolves this by checking RUNNING first,
 *   so R10.8 takes precedence over R15.2 in that corner. This property
 *   therefore covers the design's "Property 2" universally over the
 *   three non-RUNNING `RunStatus` values (COMPLETED, FAILED, ABORTED);
 *   the RUNNING placeholder behavior is covered separately by example
 *   tests for R10.8.
 *
 * Property statement (tightened):
 *
 *   For any non-RUNNING `runStatus` (COMPLETED, FAILED, or ABORTED)
 *   where `failedCount === 0 && errorCount === 0`, the
 *   `RecommendedChangesPanel` renders the green empty-state Alert
 *   ("No recommended changes — all cases passed") AND does not call
 *   `apiClient.post` — regardless of the values of any other run-state
 *   fields and regardless of whether the user activates "Re-analyze"
 *   (which surfaces the inline message "No analysis needed — all cases
 *   passed" instead per R10.3).
 *
 * The test renders the real `RecommendedChangesPanel` component with the
 * `apiClient` and `react-router-dom` seams mocked, and asserts the
 * universal predicate by enumerating 100 random
 * `RecommendedChangesPanelProps` objects whose `failedCount === 0 &&
 * errorCount === 0` while `runStatus` is drawn from
 * `{ COMPLETED, FAILED, ABORTED }` (RUNNING is excluded per the
 * resolution above) and `runId`/`suiteId` are drawn from arbitrary
 * domains. For each render the test asserts:
 *
 *   1. The rendered output contains the empty-state text
 *      `No recommended changes — all cases passed` (R10.2 / R15.2).
 *   2. The `apiClient.post` mock is called zero times
 *      (i.e. the Recommendation_Engine is not invoked on mount —
 *      R15.2).
 *   3. Clicking the "Re-analyze" button still results in zero
 *      `apiClient.post` calls (the inline message
 *      "No analysis needed — all cases passed" is shown instead per
 *      R10.3).
 */

import React from 'react';
import {
  describe,
  it,
  expect,
  beforeAll,
  beforeEach,
  afterEach,
  vi,
} from 'vitest';
import { render, screen, cleanup, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';
import fc from 'fast-check';

import { RunStatus } from '../../../src/shared/enums';

// ---------------------------------------------------------------------------
// Mock the apiClient and react-router-dom seams BEFORE importing the
// component module. `vi.mock` is hoisted above all imports, so the mock
// fns must be declared via `vi.hoisted` to be safely referenced from the
// factories.
// ---------------------------------------------------------------------------

const { apiGetMock, apiPostMock, apiPutMock, apiDeleteMock, navigateMock } =
  vi.hoisted(() => ({
    apiGetMock: vi.fn(),
    apiPostMock: vi.fn(),
    apiPutMock: vi.fn(),
    apiDeleteMock: vi.fn(),
    navigateMock: vi.fn(),
  }));

vi.mock('../../../src/frontend/src/api', () => {
  class MockApiClientError extends Error {
    public readonly status: number;
    public readonly retryable: boolean;
    constructor(status: number, message: string, retryable: boolean) {
      super(message);
      this.name = 'ApiClientError';
      this.status = status;
      this.retryable = retryable;
    }
  }
  class MockRuntimeConfigUnavailableError extends Error {
    constructor(message = 'Runtime configuration unavailable.') {
      super(message);
      this.name = 'RuntimeConfigUnavailableError';
    }
  }
  return {
    apiClient: {
      get: apiGetMock,
      post: apiPostMock,
      put: apiPutMock,
      delete: apiDeleteMock,
    },
    ApiClientError: MockApiClientError,
    RuntimeConfigUnavailableError: MockRuntimeConfigUnavailableError,
    loadConfig: vi.fn(),
    getConfig: vi.fn(),
    getConfigStatus: vi.fn(),
    subscribeToNotifications: vi.fn(() => () => {}),
    notifyError: vi.fn(),
  };
});

// react-router-dom: the panel imports `useNavigate` only (used by the
// per-suite recommendation card to navigate to a case-detail page). The
// empty-state branches never reach that code path, but the panel module
// imports the hook at the top level so it must resolve to a real (mock)
// implementation. Using a stub here also pins the import to a single
// React-aware copy via the vitest.config.ts alias (the frontend ships
// its own nested react-router-dom, which would otherwise pull in a
// second React copy and break hooks).
vi.mock('react-router-dom', () => ({
  useNavigate: () => navigateMock,
}));

// Import the component AFTER the vi.mock calls so the component module
// receives the mocked apiClient and the stubbed router hook.
import { RecommendedChangesPanel } from '../../../src/frontend/src/components/RecommendedChangesPanel';

// ---------------------------------------------------------------------------
// jsdom polyfills required by Cloudscape components
// ---------------------------------------------------------------------------

beforeAll(() => {
  const g = globalThis as unknown as {
    ResizeObserver?: unknown;
    IntersectionObserver?: unknown;
  };
  if (typeof g.ResizeObserver === 'undefined') {
    g.ResizeObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
    };
  }
  if (typeof g.IntersectionObserver === 'undefined') {
    g.IntersectionObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
      takeRecords(): unknown[] {
        return [];
      }
      readonly root = null;
      readonly rootMargin = '';
      readonly thresholds: ReadonlyArray<number> = [];
    };
  }
  if (typeof window.matchMedia !== 'function') {
    window.matchMedia = (query: string) =>
      ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => {},
        removeListener: () => {},
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => false,
      }) as MediaQueryList;
  }
});

beforeEach(() => {
  apiGetMock.mockReset();
  apiPostMock.mockReset();
  apiPutMock.mockReset();
  apiDeleteMock.mockReset();
  navigateMock.mockReset();
  // Default resolutions — if the component DID issue a request these
  // resolved promises keep the test from rejecting; the assertion that
  // catches the misbehavior is the call-count check below, not an
  // unhandled-rejection.
  apiGetMock.mockResolvedValue({
    snapshot: {
      tools: [],
      systemPrompt: '',
      modelId: 'mock-model',
      capturedAt: '1970-01-01T00:00:00.000Z',
    },
  });
  apiPostMock.mockResolvedValue({});
});

afterEach(() => {
  cleanup();
});

// ---------------------------------------------------------------------------
// Generators
// ---------------------------------------------------------------------------

/**
 * The three non-RUNNING `RunStatus` values, drawn uniformly. RUNNING is
 * excluded because R10.8 (RUNNING placeholder) takes precedence over
 * R15.2 (empty-state Alert) in that corner; see the file-level JSDoc.
 */
const runStatusArb = fc.constantFrom<RunStatus>(
  RunStatus.COMPLETED,
  RunStatus.FAILED,
  RunStatus.ABORTED,
);

/** Non-empty arbitrary string for `runId` (the panel renders it into URLs). */
const runIdArb = fc
  .string({ minLength: 1, maxLength: 64 })
  .filter((s) => s.trim().length > 0);

/** Optional arbitrary string for `suiteId` (the panel passes it through). */
const suiteIdArb = fc.option(
  fc.string({ minLength: 1, maxLength: 64 }).filter((s) => s.trim().length > 0),
  { nil: undefined },
);

// ---------------------------------------------------------------------------
// Property
// ---------------------------------------------------------------------------

describe('Property 2: No-failure empty state', () => {
  it(
    'renders the empty-state Alert AND never calls apiClient.post for ' +
      'any non-RUNNING (runStatus, runId, suiteId) when failedCount === 0 && errorCount === 0',
    () => {
      fc.assert(
        fc.property(
          runStatusArb,
          runIdArb,
          suiteIdArb,
          (runStatus, runId, suiteId) => {
            // Reset the call-count accumulators before each iteration so
            // the post-iteration assertions see only this iteration's
            // calls. `mockReset` would also wipe the resolved value the
            // beforeEach installed, so use `mockClear` to keep the
            // resolution while clearing the call history.
            apiPostMock.mockClear();
            apiGetMock.mockClear();

            // Render the panel with `failedCount === 0 && errorCount === 0`
            // and the randomly drawn other fields (R15.2: "regardless of
            // any other run-state field values").
            const { unmount } = render(
              React.createElement(RecommendedChangesPanel, {
                runId,
                suiteId,
                runStatus,
                failedCount: 0,
                errorCount: 0,
              }),
            );

            try {
              // (1) Empty-state element is rendered (R10.2 / R15.2). The
              // panel renders the requirement's text with a trailing
              // period, so use a regex anchored to the requirement text
              // and tolerate the optional terminal punctuation.
              const emptyText = screen.queryByText(
                /^No recommended changes — all cases passed\.?$/,
              );
              expect(emptyText).not.toBeNull();

              // (2) The Recommendation_Engine was not invoked on mount
              // (R15.2). The engine is reached only via apiClient.post on
              // either `/runs/{runId}/analyze` or
              // `/runs/{runId}/recommend-suite`; the mock guarantees a
              // single chokepoint to assert against.
              expect(apiPostMock).not.toHaveBeenCalled();

              // (3) Activating "Re-analyze" still does not call the
              // Recommendation_Engine (R10.3). The button is rendered in
              // the all-passed branch for every non-RUNNING `runStatus`
              // (RUNNING is excluded from this property's input space
              // per the file-level JSDoc — R10.8 takes precedence in
              // that corner).
              const reanalyzeButton = screen.queryByRole('button', {
                name: /re-analyze/i,
              });
              if (reanalyzeButton !== null) {
                fireEvent.click(reanalyzeButton);
                expect(apiPostMock).not.toHaveBeenCalled();
                // R10.3 — the inline no-op message surfaces in place of
                // an engine call. Same trailing-period tolerance as
                // assertion (1).
                expect(
                  screen.queryByText(
                    /^No analysis needed — all cases passed\.?$/,
                  ),
                ).not.toBeNull();
              }
            } finally {
              unmount();
            }
          },
        ),
        // Per the design's "Each property test runs minimum 100
        // iterations (consistent with the platform's existing
        // convention)" guidance, and the task's explicit "minimum 100
        // fast-check iterations".
        { numRuns: 100 },
      );
    },
  );
});
