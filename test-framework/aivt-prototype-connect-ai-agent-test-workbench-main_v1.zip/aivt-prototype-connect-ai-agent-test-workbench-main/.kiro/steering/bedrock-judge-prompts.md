---
inclusion: fileMatch
fileMatchPattern: ".kiro/specs/bedrock-judge-evaluations/**"
description: Verbatim AWS-published Bedrock-judge prompt templates and their score-scale tables (single source of truth for the bedrock-judge-evaluations feature).
---

# Bedrock Judge Prompt Templates (Source of Truth)

This file is the **single source of truth** for the three AWS-published built-in evaluator prompt templates the platform uses as its scoring rubric, plus the Score_Scale tables that map their categorical labels into the persisted `[0.0, 1.0]` score range. The templates below are committed **verbatim** so any drift against the AWS docs surfaces as a code-review diff.

The templates here MUST match, byte-for-byte, the corresponding constants in code (currently `GOAL_SUCCESS_RATE_TEMPLATE`, `HELPFULNESS_TEMPLATE`, `TOOL_SELECTION_TEMPLATE` in `scripts/bedrock-judge-probe.ts`, and — once the production module lands — the same constants used by `src/backend/orchestration/bedrock-judge-client.ts`). The Score_Scale tables here MUST match `GOAL_SUCCESS_SCALE`, `TOOL_SELECTION_SCALE`, and `HELPFULNESS_SCALE` in `src/shared/utils/evaluation-scoring.ts` (added under task 2.2).

A refresh — when AWS publishes a new revision of any template — is an explicit, reviewed change set that updates this file AND the corresponding `evaluation-scoring.ts` constants in the same PR if any rubric label moved.

## Per-case Converse-call cost

Every test case fans out to exactly `1 + N + M` `bedrock:Converse` calls:

- `1` Goal Success Rate evaluator (session-level)
- `N` Helpfulness evaluators, one per assistant turn in the Execution_Trace
- `M` Tool Selection Accuracy evaluators, one per `execute_tool` entry in the Execution_Trace

For the two committed Span_Fixtures that's 5 calls (`multi-tool-success`) and 7 calls (`failure-escalation`).

At current Bedrock pricing, with the default Judge_Model `us.anthropic.claude-sonnet-4-6` (the same model id used by `analysis.ts` and `scaffold.ts`) and typical per-call volumes (~3K input tokens, ~500 output tokens), this works out to **~$0.03–$0.05 per case**. A 100-case run is therefore on the order of **~$3–$5** of judge cost. Pin a different `judgeModelId` via CDK context to revise this envelope; the IAM grant on the Evaluation_Lambda role automatically tightens to whatever model id you configure.

---

## 1. Builtin.GoalSuccessRate

- **Source URL:** https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html
- **Date of copy:** 2026-06-05
- **Lifted from:** `scripts/bedrock-judge-probe.ts` constant `GOAL_SUCCESS_RATE_TEMPLATE` (which itself was copied verbatim from the URL above)

Placeholders substituted by the prompt-rendering module: `{available_tools}`, `{context}`. All other `{...}` braces inside the embedded JSON-schema block are part of the schema and pass through to the judge as literal text.

````text
You are an objective judge evaluating the quality of an AI assistant as to whether a conversation between a User and the AI assistant successfully completed all User goals. You will be provided with:
1. The list of available tools the AI assistant can use. There are descriptions for each tool about when to use it and how to use it.
2. The complete conversation record with multiple turns including:
    - User messages (User:)
    - Assistant responses (Assistant:)
    - Tool selected by the assistant (Action:)
    - Tool outputs (Tool:)
3. The final assistant response that concludes the conversation.

Your task is to carefully analyze the conversation and determine if all User goals were successfully achieved. In order to achieve a User goal, the AI assistant usually need to use some tools and respond to User about the outcome. Please assess the goals one by one, following the steps below:
1. First, analyze the list of available tools, reason about what tools the AI assistant should use, and what response it should provide to the User in order to achieve the goal;
2. Next, check the conversation record and the final assistant response to decide whether the AI assistant used the expected tools and got the expected output, got the expected information, and responded to the User in the expected way. If the AI assistant did all expected work in the conversation record and provided an appropriate final response, the goal was achieved.
3. After judging about all the goals, decide whether the conversation achieved all user goals or not.

## Evaluation Rubric
- Yes: All user goals were achieved. The agent successfully completed all requested tasks, provided accurate information, and the user received satisfactory outcomes.
- No: Not all user goals were achieved. The agent failed to complete one or more requested tasks, provided incomplete/incorrect information, or the user's needs were not fully met.

**IMPORTANT**: The tool output ALWAYS takes priority over your own knowledge.

## Available tools
{available_tools}

## Conversation record
{context}

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Yes' or 'No'", "enum": ["Yes", "No"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}
Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (```).
````

### Score_Scale — GoalSuccessRate

Two-label categorical → `[0.0, 1.0]`:

| Label | Mapped value |
|---|---|
| `Yes` | `1.0` |
| `No`  | `0.0` |

Any other label is unmappable and SHALL surface as `Evaluation_Error_State` code `UNMAPPABLE_RESULT` (no silent zero, no default).

The session-level GoalSuccessRate value maps **directly** to `goalSuccessScore` on the `TestCaseResult` (no aggregation; there is exactly one Goal Success Rate evaluator unit per case).

---

## 2. Builtin.Helpfulness

- **Source URL:** https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html
- **Date of copy:** 2026-06-05
- **Lifted from:** `scripts/bedrock-judge-probe.ts` constant `HELPFULNESS_TEMPLATE` (which itself was copied verbatim from the URL above)

Placeholders substituted by the prompt-rendering module: `{context}`, `{assistant_turn}`. The `{context}` rendered for the i-th assistant turn MUST be **prefix-only** — the conversation up to and including the unit being evaluated, with no future steps leaked in.

````text
You are an objective judge evaluating the helpfulness of an AI assistant's response from the user's perspective. Your task is to assess whether the assistant's turn moves the user closer to achieving or formulating their goals.

IMPORTANT: Evaluate purely from the user's perspective, without considering the factual accuracy or backend operations. Focus only on how the response helps the user progress towards their goals.

**IMPORTANT**: The tool output ALWAYS takes priority over your own knowledge.

Infer the user's goals purely based on the user's initial request, and any additional context they may provide afterwards.

# Conversation Context:
## Previous turns:
{context}

## Target turn to evaluate:
{assistant_turn}

# Evaluation Guidelines:
Rate the helpfulness of the assistant's turn using this scale:

0. Not Helpful At All
1. Very Unhelpful
2. Somewhat Unhelpful
3. Neutral/Mixed
4. Somewhat Helpful
5. Very Helpful
6. Above And Beyond

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Not Helpful At All', 'Very Unhelpful', 'Somewhat Unhelpful', 'Neutral/Mixed', 'Somewhat Helpful', 'Very Helpful' or 'Above And Beyond'", "enum": ["Not Helpful At All", "Very Unhelpful", "Somewhat Unhelpful", "Neutral/Mixed", "Somewhat Helpful", "Very Helpful", "Above And Beyond"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}

Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (```).
````

### Score_Scale — Helpfulness

Seven-level ordinal categorical → `[0.0, 1.0]`, **uniformly spaced in steps of `1/6`**:

| Label                  | Mapped value |
|---|---|
| `Not Helpful At All`   | `0/6` = `0.0`            |
| `Very Unhelpful`       | `1/6` ≈ `0.16666666...`  |
| `Somewhat Unhelpful`   | `2/6` ≈ `0.33333333...`  |
| `Neutral/Mixed`        | `3/6` = `0.5`            |
| `Somewhat Helpful`     | `4/6` ≈ `0.66666666...`  |
| `Very Helpful`         | `5/6` ≈ `0.83333333...`  |
| `Above And Beyond`     | `6/6` = `1.0`            |

Any other label is unmappable and SHALL surface as `Evaluation_Error_State` code `UNMAPPABLE_RESULT` (no silent default).

The N per-assistant-turn Helpfulness values are reduced to `helpfulnessScore` on the `TestCaseResult` by **unweighted arithmetic mean**, then clamped to `[0.0, 1.0]`.

---

## 3. Builtin.ToolSelectionAccuracy

- **Source URL:** https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html
- **Date of copy:** 2026-06-05
- **Lifted from:** `scripts/bedrock-judge-probe.ts` constant `TOOL_SELECTION_TEMPLATE` (which itself was copied verbatim from the URL above)

Placeholders substituted by the prompt-rendering module: `{available_tools}`, `{context}`, `{tool_turn}`. As with Helpfulness, `{context}` MUST be prefix-only — only the steps strictly preceding the tool call being evaluated (plus any in-turn steps that occurred before it within the same assistant turn).

````text
You are an objective judge evaluating if an AI assistant's action is justified at this specific point in the conversation.
## Available tool-calls
{available_tools}
## Previous conversation history
{context}
## Target tool-call to evaluate
{tool_turn}
## Evaluation Question:
Given the current state of the conversation, is the Agent justified in calling this specific action at this point in the conversation?
Consider:
1. Does this action reasonably address the user's current request or implied need?
2. Is the action aligned with the user's expressed or implied intent?
3. Are the minimum necessary parameters available to make the call useful?
4. Would a helpful assistant reasonably take this action to serve the user?
## Output Format:
First, provide a brief analysis of why this action is or is not justified at this point in the conversation.
Then, answer the evaluation question with EXACTLY ONE of these responses:
- Yes (if the action reasonably serves the user's intention at this point)
- No (if the action clearly does not serve the user's intention at this point)

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Yes' or 'No'", "enum": ["Yes", "No"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}
Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (```).
````

### Score_Scale — ToolSelectionAccuracy

Two-label categorical → `[0.0, 1.0]`:

| Label | Mapped value |
|---|---|
| `Yes` | `1.0` |
| `No`  | `0.0` |

Any other label is unmappable and SHALL surface as `Evaluation_Error_State` code `UNMAPPABLE_RESULT`.

The M per-tool-call ToolSelectionAccuracy values are reduced to `toolAccuracyScore` on the `TestCaseResult` by **unweighted arithmetic mean**, then clamped to `[0.0, 1.0]`. The platform never substitutes the local `calculateToolAccuracy` heuristic for a Bedrock_Judge result.

---

## Refresh procedure

1. Diff each template above against the live AWS docs at the source URL.
2. If any template byte differs, open a PR that:
   - Updates the template in this file verbatim.
   - Updates the source code constant (`bedrock-judge-client.ts` or, until that lands, `scripts/bedrock-judge-probe.ts`) byte-for-byte.
   - Updates the corresponding Score_Scale entry in `src/shared/utils/evaluation-scoring.ts` if the rubric labels changed.
   - Bumps the **Date of copy** above the affected template.
3. Re-run the golden-prompt snapshot tests (`tests/unit/judge-prompt-rendering.fixtures.test.ts`); accept the snapshot diff in the same PR.
