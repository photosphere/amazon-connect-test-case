/**
 * WriteCaseResult Lambda handler — writes a single test case result to DynamoDB
 * immediately after it completes within the Map state.
 *
 * This enables progressive/partial result reads: the Results Lambda can return
 * completed case results while the run is still in progress.
 *
 * Called after RecordTranscript in the per-case chain:
 *   ConversationDriver → RecordTranscript → WriteCaseResult
 *
 * DynamoDB key pattern: PK=RUN#{runId}, SK=CASE#{caseId}
 *
 * @module write-case-result
 */

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import {
  DynamoDBService,
  createDynamoDBService,
} from "../../services/dynamodb";
import { CaseStatus } from "../../../shared/enums";
import type { TestCaseResult } from "../../../shared/types";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface WriteCaseResultInput {
  runId: string;
  caseId: string;
  status: string;
  toolsInvoked: string[];
  turnCount: number;
  latencyMs: number;
  errorMessage?: string;
  goalSuccessScore?: number;
  helpfulnessScore?: number;
  toolAccuracyScore?: number;
  /** Agent's terminal response — persisted for Stage 2 RAG evaluation. */
  agentResponse?: string;
  /** Retrieved chunks from the Retrieve tool — persisted for Stage 2 RAG evaluation. */
  retrievedChunks?: unknown[];
  /** Case type discriminator ("rag" | "tool_sequence"). */
  caseType?: string;
}

export interface WriteCaseResultOutput {
  runId: string;
  caseId: string;
  status: string;
  toolsInvoked: string[];
  turnCount: number;
  latencyMs: number;
  resultWritten: boolean;
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------

let dynamoService: DynamoDBService | null = null;

function getDynamoService(): DynamoDBService {
  if (!dynamoService) {
    const ddbClient = new DynamoDBClient({});
    const docClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
    dynamoService = createDynamoDBService(
      process.env.TABLE_NAME ?? "ConnectAgentTestPlatform",
      docClient
    );
  }
  return dynamoService;
}

/** @internal — allows test injection */
export function _setDynamoService(service: DynamoDBService | null): void {
  dynamoService = service;
}

// ---------------------------------------------------------------------------
// Handler
// ---------------------------------------------------------------------------

/**
 * Writes a single test case result to DynamoDB immediately after the case
 * completes. This enables the Results Lambda to serve partial results
 * while the run is still in progress.
 */
export async function handler(
  event: WriteCaseResultInput
): Promise<WriteCaseResultOutput> {
  const db = getDynamoService();

  // Map the string status to a CaseStatus enum value
  let caseStatus = mapStatus(event.status);

  // RAG cases: don't mark as "passed" during Stage 1 — evaluation hasn't
  // happened yet. Set to "pending_evaluation" so the UI doesn't show a
  // premature green status. Stage 2 (ReadRagResults) overwrites with the
  // real pass/fail based on metric thresholds.
  if (event.caseType === "rag" && caseStatus === CaseStatus.PASSED) {
    caseStatus = CaseStatus.PENDING_EVALUATION;
  }

  const result: TestCaseResult = {
    runId: event.runId,
    caseId: event.caseId,
    status: caseStatus,
    toolsInvoked: event.toolsInvoked ?? [],
    turnCount: event.turnCount ?? 0,
    latencyMs: event.latencyMs ?? 0,
    ...(event.errorMessage && { errorMessage: event.errorMessage }),
    ...(event.goalSuccessScore !== undefined && {
      goalSuccessScore: event.goalSuccessScore,
    }),
    ...(event.helpfulnessScore !== undefined && {
      helpfulnessScore: event.helpfulnessScore,
    }),
    ...(event.toolAccuracyScore !== undefined && {
      toolAccuracyScore: event.toolAccuracyScore,
    }),
    ...(event.agentResponse !== undefined && {
      agentResponse: event.agentResponse,
    }),
    ...(event.retrievedChunks !== undefined && {
      retrievedChunks: event.retrievedChunks as TestCaseResult["retrievedChunks"],
    }),
    ...(event.caseType && {
      caseType: event.caseType as TestCaseResult["caseType"],
    }),
  };

  await db.writeResult(result);

  return {
    runId: event.runId,
    caseId: event.caseId,
    status: event.status,
    toolsInvoked: event.toolsInvoked ?? [],
    turnCount: event.turnCount ?? 0,
    latencyMs: event.latencyMs ?? 0,
    resultWritten: true,
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Map a string status from the state machine to a CaseStatus enum value.
 * Handles both enum values and raw strings from the conversation driver.
 */
function mapStatus(status: string): CaseStatus {
  switch (status.toLowerCase()) {
    case "passed":
      return CaseStatus.PASSED;
    case "failed":
      return CaseStatus.FAILED;
    case "error":
      return CaseStatus.ERROR;
    case "timed_out":
    case "timedout":
      return CaseStatus.TIMED_OUT;
    case "completed":
      // "completed" from the conversation driver means the case ran to completion
      // but hasn't been evaluated yet — treat as passed until evaluation overrides
      return CaseStatus.PASSED;
    default:
      return CaseStatus.ERROR;
  }
}
