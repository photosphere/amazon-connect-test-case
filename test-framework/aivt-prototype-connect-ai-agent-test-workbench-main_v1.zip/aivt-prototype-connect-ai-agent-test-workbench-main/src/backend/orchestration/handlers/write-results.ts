/**
 * WriteResults Lambda handler — writes final scores, updates run status, and
 * persists the run summary to DynamoDB.
 *
 * Called as the final step in the Step Functions state machine.
 * Aggregates pass/fail/error counts, determines terminal run status
 * (completed or failed), updates the run record, and writes a summary.
 *
 * Run status transitions handled here:
 *   running → completed (all cases finished normally)
 *   running → failed (all cases errored / execution-level error)
 *
 * The "running → aborted" transition is handled by the Run Trigger Lambda's
 * abort endpoint (StopExecution + status update).
 *
 * @module write-results
 */

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  PutCommand,
  UpdateCommand,
  GetCommand,
} from "@aws-sdk/lib-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../../shared/constants";
import { RunStatus } from "../../../shared/enums";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface WriteResultsInput {
  runId: string;
  suiteId: string;
  startTime: string;
  caseResults: Array<{
    caseId: string;
    status: string;
    toolsInvoked: string[];
    turnCount: number;
    latencyMs: number;
    goalSuccessScore?: number;
    helpfulnessScore?: number;
    toolAccuracyScore?: number;
    errorMessage?: string;
  }>;
  evaluated?: number;
  fallback?: number;
  errors?: number;
}

export interface WriteResultsOutput {
  runId: string;
  status: string;
  totalCases: number;
  passed: number;
  failed: number;
  errors: number;
  endTime: string;
}

// ---------------------------------------------------------------------------
// DynamoDB client
// ---------------------------------------------------------------------------

const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";

let ddbDocClient: DynamoDBDocumentClient | null = null;

function getDDBClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setDDBClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Handler
// ---------------------------------------------------------------------------

export async function handler(
  event: WriteResultsInput
): Promise<WriteResultsOutput> {
  const { runId, suiteId, startTime, caseResults } = event;
  // Evaluation output is nested under evaluationOutput.Payload when using resultPath
  const evalOutput = (event as any).evaluationOutput?.Payload ?? {};
  const client = getDDBClient();

  // Aggregate results — for RAG cases that were pending evaluation, read
  // the actual status from DDB (written by ReadRagResults in Stage 2).
  let passed = 0;
  let failed = 0;
  let errors = 0;

  const pendingCaseIds: string[] = [];

  for (const result of caseResults) {
    switch (result.status.toLowerCase()) {
      case "passed":
        passed++;
        break;
      case "failed":
        failed++;
        break;
      case "error":
      case "timed_out":
        errors++;
        break;
      case "pending_evaluation":
        // RAG case — need to read actual status from DDB
        pendingCaseIds.push(result.caseId);
        break;
      default:
        passed++;
        break;
    }
  }

  // Resolve pending RAG cases from DDB (ReadRagResults already wrote the real status)
  if (pendingCaseIds.length > 0 && runId) {
    for (const caseId of pendingCaseIds) {
      try {
        const caseResult = await client.send(
          new GetCommand({
            TableName: TABLE_NAME,
            Key: {
              PK: `${PK_PATTERNS.RUN}${runId}`,
              SK: `CASE#${caseId}`,
            },
            ProjectionExpression: "#s",
            ExpressionAttributeNames: { "#s": "status" },
          }),
        );
        const actualStatus = (caseResult.Item?.status as string) ?? "error";
        switch (actualStatus.toLowerCase()) {
          case "passed": passed++; break;
          case "failed": failed++; break;
          default: errors++; break;
        }
      } catch {
        // DDB read failure — count as error conservatively
        errors++;
      }
    }
  }

  const endTime = new Date().toISOString();
  const totalCases = caseResults.length;

  // Determine terminal run status:
  // - If ALL cases errored → FAILED
  // - Otherwise → COMPLETED (mix of passed/failed is still a completed run)
  const runStatus =
    errors === totalCases && totalCases > 0
      ? RunStatus.FAILED
      : RunStatus.COMPLETED;

  // Update the run record in DynamoDB with final counts and status
  // Run record lives at PK=SUITE#{suiteId}, SK=RUN#{startTime}
  if (suiteId && startTime) {
    await client.send(
      new UpdateCommand({
        TableName: TABLE_NAME,
        Key: {
          PK: `${PK_PATTERNS.SUITE}${suiteId}`,
          SK: `${SK_PATTERNS.RUN}${startTime}`,
        },
        UpdateExpression:
          "SET #s = :s, passed = :p, failed = :f, errors = :e, endTime = :et",
        ExpressionAttributeNames: { "#s": "status" },
        ExpressionAttributeValues: {
          ":s": runStatus,
          ":p": passed,
          ":f": failed,
          ":e": errors,
          ":et": endTime,
        },
      })
    );
  }

  // Also write a run summary item at PK=RUN#{runId}, SK=SUMMARY for fast
  // lookup when querying by runId directly
  await client.send(
    new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: "SUMMARY",
        runId,
        suiteId,
        status: runStatus,
        totalCases,
        passed,
        failed,
        errors,
        // Persist BOTH startTime and endTime on the SUMMARY record so the
        // Run Dashboard's `Elapsed Time` field can compute end - start
        // without re-querying the suite-keyed run record. Without
        // startTime here, `getRunByRunId`'s Stage 1 path returns an
        // empty string and the dashboard renders 00:00.
        startTime,
        endTime,
        evaluationSummary: {
          evaluated: evalOutput.evaluated ?? 0,
          // The rewritten Evaluation Lambda exposes
          //   - `evaluationErrors`: cases persisted with an
          //     `evaluationError` (timeout / agentcore-error /
          //     unmappable / missing evaluator / insufficient trace).
          //   - `errors`: cases that could not be processed at all
          //     (e.g. unmatched caseId, DDB write failure).
          // Older deploys returned `fallback` in this slot; the field is
          // tolerated as `0` for backward compatibility with replayed
          // events but is no longer produced.
          fallback: (evalOutput as { fallback?: number }).fallback ?? 0,
          evaluationErrors:
            evalOutput.evaluationErrors ?? evalOutput.errors ?? 0,
        },
      },
    })
  );

  return {
    runId,
    status: runStatus,
    totalCases,
    passed,
    failed,
    errors,
    endTime,
  };
}
