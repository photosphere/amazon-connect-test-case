import type { VariantScore } from "@shared/types";

/**
 * Deterministic, idempotent selection function (R18.5).
 *
 * Returns the variant with the highest pass rate.
 * Ties broken by avg goal success score (higher wins).
 * Errored variants are excluded from selection.
 * Returns null if all variants errored.
 */
export function selectWinningVariant(
  scores: VariantScore[]
): "A" | "B" | "C" | null {
  const eligible = scores.filter((s) => s.status === "completed");

  if (eligible.length === 0) {
    return null;
  }

  // Sort descending by passRate, then by avgGoalSuccessScore as tiebreak.
  // Stable sort ensures determinism when both metrics are equal — the first
  // encountered in the original array wins, preserving input order.
  const sorted = [...eligible].sort((a, b) => {
    if (b.passRate !== a.passRate) {
      return b.passRate - a.passRate;
    }
    return b.avgGoalSuccessScore - a.avgGoalSuccessScore;
  });

  return sorted[0].variant;
}
