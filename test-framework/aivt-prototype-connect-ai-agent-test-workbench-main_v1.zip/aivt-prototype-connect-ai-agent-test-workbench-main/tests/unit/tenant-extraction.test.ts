import { describe, it, expect } from 'vitest';
import {
  extractTenantId,
  extractTenantIdFromEvent,
} from '../../src/shared/utils/tenant-extraction';

describe('Tenant Extraction Utility', () => {
  describe('extractTenantId', () => {
    it('should return sub for interactive user tokens', () => {
      const claims = { sub: 'user-uuid-123', email: 'test@example.com' };
      expect(extractTenantId(claims)).toBe('user-uuid-123');
    });

    it('should return machine:{client_id} for machine client tokens', () => {
      const claims = { client_id: 'abc123def456' };
      expect(extractTenantId(claims)).toBe('machine:abc123def456');
    });

    it('should prefer sub over client_id when both are present', () => {
      // User pool tokens may have both sub and client_id
      const claims = { sub: 'user-uuid-456', client_id: 'client-xyz' };
      expect(extractTenantId(claims)).toBe('user-uuid-456');
    });

    it('should throw when claims is null', () => {
      expect(() => extractTenantId(null)).toThrow(
        'Unable to determine tenant identity: no claims present'
      );
    });

    it('should throw when claims is undefined', () => {
      expect(() => extractTenantId(undefined)).toThrow(
        'Unable to determine tenant identity: no claims present'
      );
    });

    it('should throw when neither sub nor client_id is present', () => {
      const claims = { email: 'test@example.com' };
      expect(() => extractTenantId(claims)).toThrow(
        'Unable to determine tenant identity from token'
      );
    });

    it('should throw when sub is empty string', () => {
      const claims = { sub: '' };
      expect(() => extractTenantId(claims)).toThrow(
        'Unable to determine tenant identity from token'
      );
    });

    it('should throw when client_id is empty string and no sub', () => {
      const claims = { client_id: '' };
      expect(() => extractTenantId(claims)).toThrow(
        'Unable to determine tenant identity from token'
      );
    });
  });

  describe('extractTenantIdFromEvent', () => {
    it('should extract tenant from a full API Gateway event', () => {
      const event = {
        requestContext: {
          authorizer: {
            claims: { sub: 'event-user-id' },
          },
        },
      };
      expect(extractTenantIdFromEvent(event)).toBe('event-user-id');
    });

    it('should extract machine tenant from event', () => {
      const event = {
        requestContext: {
          authorizer: {
            claims: { client_id: 'machine-client-id' },
          },
        },
      };
      expect(extractTenantIdFromEvent(event)).toBe('machine:machine-client-id');
    });

    it('should return null when requestContext is missing', () => {
      const event = {};
      expect(extractTenantIdFromEvent(event)).toBeNull();
    });

    it('should return null when authorizer is missing', () => {
      const event = { requestContext: {} };
      expect(extractTenantIdFromEvent(event)).toBeNull();
    });

    it('should return null when claims is missing', () => {
      const event = { requestContext: { authorizer: {} } };
      expect(extractTenantIdFromEvent(event)).toBeNull();
    });

    it('should return null when claims has no identity fields', () => {
      const event = {
        requestContext: {
          authorizer: {
            claims: { email: 'test@example.com' },
          },
        },
      };
      expect(extractTenantIdFromEvent(event)).toBeNull();
    });
  });
});
