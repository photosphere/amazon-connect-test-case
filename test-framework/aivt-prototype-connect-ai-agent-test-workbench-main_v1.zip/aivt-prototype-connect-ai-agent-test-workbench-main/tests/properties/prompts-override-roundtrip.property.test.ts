/**
 * Property 1: Override round-trip.
 *
 * For any `(promptKey, text, modelKey, inferenceParameters)` tuple where:
 *
 *   - the text satisfies the prompt's placeholder schema, fits under
 *     the size cap, and contains no unknown placeholders;
 *   - `modelKey` is in the prompt's `allowedModels[]`;
 *   - `inferenceParameters` is valid for the resolved model's
 *     capability profile,
 *
 * a `putPromptOverride(...)` followed by a `getPromptOverride(...)`
 * MUST return the same triple element-wise. Equivalently, the persisted
 * override is a faithful round-trip of the caller's input — no field is
 * silently dropped, normalised, re-quoted, or merged with bundled
 * defaults at the persistence layer.
 *
 * The persistence layer under test is the {@link DynamoDBService}'s
 * Prompts_Store CRUD methods (Task 5.1). The real DDB document client
 * is replaced with an in-memory mock keyed by `PK#SK` that implements
 * the subset of behaviour the prompt-store paths exercise:
 * `TransactWriteCommand` (with `ConditionExpression` evaluation for
 * `attribute_not_exists(version)` and `version = :priorVersion`),
 * `GetCommand`, and `ScanCommand`. The mock is intentionally minimal —
 * the `ConditionExpression` shapes it understands are exactly the two
 * the service emits, so an accidental change to the service's condition
 * expression surfaces as a test failure here rather than as a silent
 * pass.
 *
 * Each iteration uses a fresh in-memory store so the
 * `attribute_not_exists(version)` condition on the priorVersion=0 path
 * always succeeds and the property reduces cleanly to "what we put is
 * what we get". The Property 2 (reset idempotence) test exercises the
 * sequenced PUT/RESET path; this test deliberately stays at the
 * one-shot boundary so a counter-example points unambiguously at the
 * round-trip itself.
 *
 * Generators are the shared `promptKeyArb`, `validTextArb`, and
 * `validInferenceParametersArb` from `tests/properties/generators.ts`
 * so the valid-input distribution stays consistent with the other
 * property tests in the wave.
 *
 * **Validates: Requirements 4.4, 15.1**
 */

import fc from "fast-check";
import { describe, expect, it } from "vitest";
import type { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

import {
  PROMPT_REGISTRY,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";
import type {
  PromptKey,
  PromptOverride,
} from "../../src/backend/orchestration/prompt-registry";
import { createDynamoDBService } from "../../src/backend/services/dynamodb";

import {
  promptKeyArb,
  validInferenceParametersArb,
  validTextArb,
} from "./generators";

const TABLE_NAME = "PropertyTestTable";

// ---------------------------------------------------------------------------
// In-memory DynamoDB document client mock.
//
// Stores items in a `Map<string, Record<string, unknown>>` keyed by the
// composite `PK#SK` string. Implements only the subset of operations
// the Prompts_Store CRUD paths use: `TransactWriteCommand`,
// `GetCommand`, and `ScanCommand`. Condition-expression evaluation is
// scoped to the exact two shapes `putPromptOverride` /
// `deletePromptOverride` emit — anything else throws so a test would
// surface the divergence directly.
//
// Returning a fresh client per-iteration keeps the property pure: no
// state leaks between iterations, no fast-check shrinker artefact can
// accidentally re-use a stale row.
// ---------------------------------------------------------------------------

interface PutAction {
  TableName?: string;
  Item: Record<string, unknown>;
  ConditionExpression?: string;
  ExpressionAttributeValues?: Record<string, unknown>;
}

interface DeleteAction {
  TableName?: string;
  Key: { PK: string; SK: string };
  ConditionExpression?: string;
  ExpressionAttributeValues?: Record<string, unknown>;
}

interface TransactItem {
  Put?: PutAction;
  Delete?: DeleteAction;
}

function conditionalCheckFailed(): Error {
  // Mirrors the shape `putPromptOverride` / `deletePromptOverride`
  // catch — wrapped `TransactionCanceledException` with a per-item
  // `CancellationReasons[].Code === "ConditionalCheckFailed"`.
  const err = Object.assign(new Error("Transaction cancelled"), {
    name: "TransactionCanceledException",
    CancellationReasons: [{ Code: "ConditionalCheckFailed" }],
  });
  return err;
}

function evaluatePutCondition(
  store: Map<string, Record<string, unknown>>,
  put: PutAction,
): void {
  const condition = put.ConditionExpression;
  if (!condition) return;
  const key = `${put.Item.PK}#${put.Item.SK}`;
  const existing = store.get(key);
  if (condition === "attribute_not_exists(version)") {
    if (existing && existing.version !== undefined) {
      throw conditionalCheckFailed();
    }
    return;
  }
  if (condition === "version = :priorVersion") {
    const priorVersion = put.ExpressionAttributeValues?.[":priorVersion"];
    if (!existing || existing.version !== priorVersion) {
      throw conditionalCheckFailed();
    }
    return;
  }
  throw new Error(
    `In-memory mock does not understand ConditionExpression: ${condition}`,
  );
}

function evaluateDeleteCondition(
  store: Map<string, Record<string, unknown>>,
  del: DeleteAction,
): void {
  const condition = del.ConditionExpression;
  if (!condition) return;
  const key = `${del.Key.PK}#${del.Key.SK}`;
  const existing = store.get(key);
  if (condition === "version = :priorVersion") {
    const priorVersion = del.ExpressionAttributeValues?.[":priorVersion"];
    if (!existing || existing.version !== priorVersion) {
      throw conditionalCheckFailed();
    }
    return;
  }
  throw new Error(
    `In-memory mock does not understand ConditionExpression: ${condition}`,
  );
}

function makeInMemoryDocClient(): DynamoDBDocumentClient {
  const store = new Map<string, Record<string, unknown>>();

  const send = async (cmd: unknown): Promise<unknown> => {
    const name = (cmd as object).constructor.name;
    const input = (cmd as { input: Record<string, unknown> }).input;

    if (name === "TransactWriteCommand") {
      const items = (input.TransactItems ?? []) as TransactItem[];
      // Two-phase apply: validate every condition first, only mutate
      // once every condition holds. Mirrors DDB's all-or-nothing
      // transactional semantics — a failed condition on the second
      // item must not leave the first item written.
      for (const item of items) {
        if (item.Put) evaluatePutCondition(store, item.Put);
        if (item.Delete) evaluateDeleteCondition(store, item.Delete);
      }
      for (const item of items) {
        if (item.Put) {
          const k = `${item.Put.Item.PK}#${item.Put.Item.SK}`;
          // Shallow-clone on write so callers cannot mutate the stored
          // row by holding a reference to the input Item.
          store.set(k, { ...item.Put.Item });
        }
        if (item.Delete) {
          const k = `${item.Delete.Key.PK}#${item.Delete.Key.SK}`;
          store.delete(k);
        }
      }
      return {};
    }

    if (name === "GetCommand") {
      const key = input.Key as { PK: string; SK: string };
      const item = store.get(`${key.PK}#${key.SK}`);
      // Shallow-clone on read so the service's `stripKeys` cannot
      // mutate the underlying stored row.
      return item ? { Item: { ...item } } : {};
    }

    if (name === "ScanCommand") {
      const filter = input.FilterExpression as string | undefined;
      const eav = (input.ExpressionAttributeValues ?? {}) as Record<
        string,
        unknown
      >;
      const matches: Array<Record<string, unknown>> = [];
      for (const row of store.values()) {
        if (filter === "begins_with(PK, :pkPrefix) AND SK = :sk") {
          if (
            typeof row.PK === "string" &&
            row.PK.startsWith(String(eav[":pkPrefix"])) &&
            row.SK === eav[":sk"]
          ) {
            matches.push({ ...row });
          }
        } else if (!filter) {
          matches.push({ ...row });
        } else {
          throw new Error(
            `In-memory mock does not understand FilterExpression: ${filter}`,
          );
        }
      }
      return { Items: matches };
    }

    throw new Error(
      `In-memory mock received unexpected command: ${name}. ` +
        `Extend the mock to handle it explicitly.`,
    );
  };

  return { send } as unknown as DynamoDBDocumentClient;
}

// ---------------------------------------------------------------------------
// Round-trip property
// ---------------------------------------------------------------------------

/**
 * Composite arbitrary that draws a `promptKey`, then a `modelKey` from
 * that prompt's `allowedModels[]`, then a `(text, inferenceParameters)`
 * pair valid for the resolved `(prompt, model)` pair. Sourced from the
 * shared generators so the valid-input distribution stays in sync with
 * the other property tests.
 *
 * The chain is wired top-down (promptKey → modelKey → text/params)
 * rather than independent draws because `validTextArb` and
 * `validInferenceParametersArb` both depend on the prompt definition,
 * and `validInferenceParametersArb` additionally depends on the
 * resolved model's capability profile.
 */
const inputArb: fc.Arbitrary<{
  promptKey: PromptKey;
  text: string;
  modelKey: PromptOverride["modelKey"];
  inferenceParameters: Readonly<Record<string, unknown>>;
}> = promptKeyArb.chain((promptKey) => {
  const prompt = PROMPT_REGISTRY[promptKey];
  return fc.constantFrom(...prompt.allowedModels).chain((modelKey) => {
    const model = SUPPORTED_MODELS[modelKey];
    return fc
      .tuple(validTextArb(prompt), validInferenceParametersArb(prompt, model))
      .map(([text, inferenceParameters]) => ({
        promptKey,
        text,
        modelKey,
        inferenceParameters,
      }));
  });
});

describe("Property 1 — Override round-trip", () => {
  it("PUT followed by GET returns the persisted override element-wise equal to the input", async () => {
    await fc.assert(
      fc.asyncProperty(inputArb, async (input) => {
        const client = makeInMemoryDocClient();
        const service = createDynamoDBService(TABLE_NAME, client);

        const expectedVersion = 1;
        const expectedTimestamp = "2024-06-01T12:00:00.000Z";
        const expectedUser = "property-test";

        const override: PromptOverride = {
          promptKey: input.promptKey,
          text: input.text,
          modelKey: input.modelKey,
          inferenceParameters: input.inferenceParameters,
          version: expectedVersion,
          lastModifiedAt: expectedTimestamp,
          lastModifiedBy: expectedUser,
        };

        // PUT a fresh override (priorVersion=0, no priorOverride).
        await service.putPromptOverride(override, 0, null, "edit");

        // GET it back.
        const got = await service.getPromptOverride(input.promptKey);

        // Assert the persisted record round-trips element-wise. Each
        // field is asserted individually rather than via a single
        // `toEqual` so a shrinker counter-example points at the
        // specific field that diverged.
        expect(got).not.toBeNull();
        expect(got?.promptKey).toBe(input.promptKey);
        expect(got?.text).toBe(input.text);
        expect(got?.modelKey).toBe(input.modelKey);
        expect(got?.inferenceParameters).toEqual(input.inferenceParameters);
        expect(got?.version).toBe(expectedVersion);
        expect(got?.lastModifiedAt).toBe(expectedTimestamp);
        expect(got?.lastModifiedBy).toBe(expectedUser);
      }),
      // R15.6 requires ≥100 iterations; 100 is the explicit task
      // requirement and gives the fast-check shrinker enough budget to
      // produce a minimal counter-example without bloating CI runtime.
      { numRuns: 100 },
    );
  });
});
