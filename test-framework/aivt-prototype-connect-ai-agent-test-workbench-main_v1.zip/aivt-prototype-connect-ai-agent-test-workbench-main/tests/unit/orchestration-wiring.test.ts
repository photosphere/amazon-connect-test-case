/**
 * Unit tests for State Machine ↔ Results Lambda wiring.
 *
 * Verifies:
 * 1. WriteCaseResult Lambda writes results in correct DynamoDB format (PK=RUN#{runId}, SK=CASE#{caseId})
 * 2. Results Lambda can read partial results during execution
 * 3. WriteResults Lambda correctly transitions run status: running → completed/failed
 * 4. Run status transitions: running → aborted (via abort handler)
 *
 * Requirements: 10.6, 10.8, 11.2
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { CaseStatus, RunStatus } from "../../src/shared/enums";

// ---------------------------------------------------------------------------
// Mock DynamoDB client
// ---------------------------------------------------------------------------
const mockSend = vi.fn();
const mockClient = { send: mockSend } as unknown as DynamoDBDocumentClient;

// ---------------------------------------------------------------------------
// Tests: WriteCaseResult Lambda
// ---------------------------------------------------------------------------

describe("WriteCaseResult Lambda", () => {
  let writeCaseResultHandler: typeof import("../../src/backend/orchestration/handlers/write-case-result").handler;
  let setDynamoService: typeof import("../../src/backend/orchestration/handlers/write-case-result")._setDynamoService;

  beforeEach(async () => {
    vi.resetModules();
    mockSend.mockReset();

    const module = await import(
      "../../src/backend/orchestration/handlers/write-case-result"
    );
    writeCaseResultHandler = module.handler;
    setDynamoService = module._setDynamoService;
  });

  it("writes result in correct DynamoDB format (PK=RUN#{runId}, SK=CASE#{caseId})", async () => {
    // Create a mock DynamoDBService
    const mockWriteResult = vi.fn().mockResolvedValue(undefined);
    const mockService = { writeResult: mockWriteResult } as any;
    setDynamoService(mockService);

    const input = {
      runId: "run-abc-123",
      caseId: "case-001",
      status: "passed",
      toolsInvoked: ["SearchFlights", "BookFlight"],
      turnCount: 6,
      latencyMs: 15000,
    };

    const output = await writeCaseResultHandler(input);

    expect(mockWriteResult).toHaveBeenCalledOnce();
    const writtenResult = mockWriteResult.mock.calls[0][0];

    // Verify correct format
    expect(writtenResult.runId).toBe("run-abc-123");
    expect(writtenResult.caseId).toBe("case-001");
    expect(writtenResult.status).toBe(CaseStatus.PASSED);
    expect(writtenResult.toolsInvoked).toEqual(["SearchFlights", "BookFlight"]);
    expect(writtenResult.turnCount).toBe(6);
    expect(writtenResult.latencyMs).toBe(15000);

    // Verify output
    expect(output.resultWritten).toBe(true);
    expect(output.runId).toBe("run-abc-123");
    expect(output.caseId).toBe("case-001");
  });

  it("maps 'completed' status to PASSED", async () => {
    const mockWriteResult = vi.fn().mockResolvedValue(undefined);
    const mockService = { writeResult: mockWriteResult } as any;
    setDynamoService(mockService);

    await writeCaseResultHandler({
      runId: "run-1",
      caseId: "case-1",
      status: "completed",
      toolsInvoked: [],
      turnCount: 3,
      latencyMs: 5000,
    });

    const writtenResult = mockWriteResult.mock.calls[0][0];
    expect(writtenResult.status).toBe(CaseStatus.PASSED);
  });

  it("maps 'error' status correctly", async () => {
    const mockWriteResult = vi.fn().mockResolvedValue(undefined);
    const mockService = { writeResult: mockWriteResult } as any;
    setDynamoService(mockService);

    await writeCaseResultHandler({
      runId: "run-1",
      caseId: "case-1",
      status: "error",
      toolsInvoked: [],
      turnCount: 1,
      latencyMs: 500,
      errorMessage: "Session creation failed",
    });

    const writtenResult = mockWriteResult.mock.calls[0][0];
    expect(writtenResult.status).toBe(CaseStatus.ERROR);
    expect(writtenResult.errorMessage).toBe("Session creation failed");
  });

  it("maps 'timed_out' status correctly", async () => {
    const mockWriteResult = vi.fn().mockResolvedValue(undefined);
    const mockService = { writeResult: mockWriteResult } as any;
    setDynamoService(mockService);

    await writeCaseResultHandler({
      runId: "run-1",
      caseId: "case-1",
      status: "timed_out",
      toolsInvoked: ["Auth"],
      turnCount: 2,
      latencyMs: 60000,
    });

    const writtenResult = mockWriteResult.mock.calls[0][0];
    expect(writtenResult.status).toBe(CaseStatus.TIMED_OUT);
  });

  it("includes evaluation scores when provided", async () => {
    const mockWriteResult = vi.fn().mockResolvedValue(undefined);
    const mockService = { writeResult: mockWriteResult } as any;
    setDynamoService(mockService);

    await writeCaseResultHandler({
      runId: "run-1",
      caseId: "case-1",
      status: "passed",
      toolsInvoked: ["SearchFlights"],
      turnCount: 4,
      latencyMs: 12000,
      goalSuccessScore: 1.0,
      helpfulnessScore: 0.9,
      toolAccuracyScore: 1.0,
    });

    const writtenResult = mockWriteResult.mock.calls[0][0];
    expect(writtenResult.goalSuccessScore).toBe(1.0);
    expect(writtenResult.helpfulnessScore).toBe(0.9);
    expect(writtenResult.toolAccuracyScore).toBe(1.0);
  });
});

// ---------------------------------------------------------------------------
// Tests: WriteResults Lambda (run status transitions)
// ---------------------------------------------------------------------------

describe("WriteResults Lambda — run status transitions", () => {
  let writeResultsHandler: typeof import("../../src/backend/orchestration/handlers/write-results").handler;
  let setDDBClient: typeof import("../../src/backend/orchestration/handlers/write-results")._setDDBClient;

  beforeEach(async () => {
    vi.resetModules();
    mockSend.mockReset();
    mockSend.mockResolvedValue({}); // Default: all DDB operations succeed

    const module = await import(
      "../../src/backend/orchestration/handlers/write-results"
    );
    writeResultsHandler = module.handler;
    setDDBClient = module._setDDBClient;
    setDDBClient(mockClient);
  });

  it("transitions status to COMPLETED when all cases pass", async () => {
    const output = await writeResultsHandler({
      runId: "run-123",
      suiteId: "suite-abc",
      startTime: "2024-01-01T00:00:00Z",
      caseResults: [
        { caseId: "c1", status: "passed", toolsInvoked: [], turnCount: 3, latencyMs: 5000 },
        { caseId: "c2", status: "passed", toolsInvoked: [], turnCount: 4, latencyMs: 6000 },
        { caseId: "c3", status: "passed", toolsInvoked: [], turnCount: 5, latencyMs: 7000 },
      ],
    });

    expect(output.status).toBe(RunStatus.COMPLETED);
    expect(output.passed).toBe(3);
    expect(output.failed).toBe(0);
    expect(output.errors).toBe(0);
    expect(output.totalCases).toBe(3);
    expect(output.endTime).toBeDefined();
  });

  it("transitions status to COMPLETED with mixed pass/fail results", async () => {
    const output = await writeResultsHandler({
      runId: "run-456",
      suiteId: "suite-abc",
      startTime: "2024-01-01T00:00:00Z",
      caseResults: [
        { caseId: "c1", status: "passed", toolsInvoked: [], turnCount: 3, latencyMs: 5000 },
        { caseId: "c2", status: "failed", toolsInvoked: [], turnCount: 4, latencyMs: 6000 },
        { caseId: "c3", status: "error", toolsInvoked: [], turnCount: 1, latencyMs: 500 },
      ],
    });

    // Mixed results → COMPLETED (not FAILED)
    expect(output.status).toBe(RunStatus.COMPLETED);
    expect(output.passed).toBe(1);
    expect(output.failed).toBe(1);
    expect(output.errors).toBe(1);
  });

  it("transitions status to FAILED when ALL cases are errors", async () => {
    const output = await writeResultsHandler({
      runId: "run-789",
      suiteId: "suite-abc",
      startTime: "2024-01-01T00:00:00Z",
      caseResults: [
        { caseId: "c1", status: "error", toolsInvoked: [], turnCount: 0, latencyMs: 100 },
        { caseId: "c2", status: "timed_out", toolsInvoked: [], turnCount: 1, latencyMs: 60000 },
        { caseId: "c3", status: "error", toolsInvoked: [], turnCount: 0, latencyMs: 200 },
      ],
    });

    expect(output.status).toBe(RunStatus.FAILED);
    expect(output.errors).toBe(3);
    expect(output.passed).toBe(0);
    expect(output.failed).toBe(0);
  });

  it("updates the run record in DynamoDB with final status", async () => {
    await writeResultsHandler({
      runId: "run-abc",
      suiteId: "suite-xyz",
      startTime: "2024-01-01T12:00:00Z",
      caseResults: [
        { caseId: "c1", status: "passed", toolsInvoked: [], turnCount: 3, latencyMs: 5000 },
      ],
    });

    // The handler should make two DDB calls: UpdateCommand (run record) + PutCommand (SUMMARY)
    expect(mockSend).toHaveBeenCalledTimes(2);

    // First call: UpdateCommand to update the run record
    const updateCall = mockSend.mock.calls[0][0];
    expect(updateCall.input.TableName).toBe("ConnectAgentTestPlatform");
    expect(updateCall.input.Key.PK).toBe("SUITE#suite-xyz");
    expect(updateCall.input.Key.SK).toBe("RUN#2024-01-01T12:00:00Z");
    expect(updateCall.input.ExpressionAttributeValues[":s"]).toBe(RunStatus.COMPLETED);

    // Second call: PutCommand for SUMMARY item
    const putCall = mockSend.mock.calls[1][0];
    expect(putCall.input.Item.PK).toBe("RUN#run-abc");
    expect(putCall.input.Item.SK).toBe("SUMMARY");
    expect(putCall.input.Item.status).toBe(RunStatus.COMPLETED);
  });
});

// ---------------------------------------------------------------------------
// Tests: Results Lambda — partial results during execution
// ---------------------------------------------------------------------------

describe("Results Lambda — partial results during execution", () => {
  let resultsHandler: typeof import("../../src/backend/handlers/results").handler;
  let setDDBClientResults: typeof import("../../src/backend/handlers/results")._setDDBClient;

  beforeEach(async () => {
    vi.resetModules();
    mockSend.mockReset();

    const module = await import("../../src/backend/handlers/results");
    resultsHandler = module.handler;
    setDDBClientResults = module._setDDBClient;
    setDDBClientResults(mockClient);
  });

  it("returns partial results for an in-progress run (via suiteId hint)", async () => {
    const runRecord = {
      PK: "SUITE#suite-abc",
      SK: "RUN#2024-01-01T00:00:00Z",
      suiteId: "suite-abc",
      runId: "run-progress-1",
      status: RunStatus.RUNNING,
      totalCases: 5,
      passed: 0,
      failed: 0,
      errors: 0,
      concurrency: 9,
      startTime: "2024-01-01T00:00:00Z",
      sfnExecutionArn: "arn:aws:states:us-east-1:123:execution:test",
    };

    // Only 2 of 5 results written so far (progressive writes from WriteCaseResult)
    const partialResults = [
      {
        PK: "RUN#run-progress-1",
        SK: "CASE#case-1",
        runId: "run-progress-1",
        caseId: "case-1",
        status: CaseStatus.PASSED,
        toolsInvoked: ["SearchFlights"],
        turnCount: 4,
        latencyMs: 12000,
      },
      {
        PK: "RUN#run-progress-1",
        SK: "CASE#case-2",
        runId: "run-progress-1",
        caseId: "case-2",
        status: CaseStatus.FAILED,
        toolsInvoked: ["SearchFlights"],
        turnCount: 5,
        latencyMs: 15000,
      },
    ];

    // Call 1: GetCommand for SUMMARY (not found — run still in progress)
    mockSend.mockResolvedValueOnce({ Item: undefined });
    // Call 2: QueryCommand for run records by suiteId
    mockSend.mockResolvedValueOnce({ Items: [runRecord] });
    // Call 3: QueryCommand for results (partial)
    mockSend.mockResolvedValueOnce({ Items: partialResults });

    const response = await resultsHandler({
      httpMethod: "GET",
      resource: "/runs/{runId}",
      pathParameters: { runId: "run-progress-1" },
      queryStringParameters: { suiteId: "suite-abc" },
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body);

    // Run is still in progress
    expect(body.run.status).toBe("running");
    expect(body.run.totalCases).toBe(5);

    // But we can see partial results
    expect(body.progress.completed).toBe(2);
    expect(body.progress.passed).toBe(1);
    expect(body.progress.failed).toBe(1);
    expect(body.results).toHaveLength(2);
  });

  it("returns completed run from SUMMARY record", async () => {
    // After WriteResults completes, SUMMARY record exists
    const summaryItem = {
      PK: "RUN#run-done-1",
      SK: "SUMMARY",
      runId: "run-done-1",
      suiteId: "suite-abc",
      status: RunStatus.COMPLETED,
      totalCases: 3,
      passed: 2,
      failed: 1,
      errors: 0,
      concurrency: 9,
      startTime: "2024-01-01T00:00:00Z",
      endTime: "2024-01-01T00:05:00Z",
    };

    const results = [
      {
        PK: "RUN#run-done-1",
        SK: "CASE#case-1",
        runId: "run-done-1",
        caseId: "case-1",
        status: CaseStatus.PASSED,
        toolsInvoked: ["Search"],
        turnCount: 3,
        latencyMs: 5000,
      },
      {
        PK: "RUN#run-done-1",
        SK: "CASE#case-2",
        runId: "run-done-1",
        caseId: "case-2",
        status: CaseStatus.PASSED,
        toolsInvoked: ["Book"],
        turnCount: 4,
        latencyMs: 6000,
      },
      {
        PK: "RUN#run-done-1",
        SK: "CASE#case-3",
        runId: "run-done-1",
        caseId: "case-3",
        status: CaseStatus.FAILED,
        toolsInvoked: ["Search"],
        turnCount: 5,
        latencyMs: 8000,
      },
    ];

    // Call 1: GetCommand for SUMMARY — found!
    mockSend.mockResolvedValueOnce({ Item: summaryItem });
    // Call 2: QueryCommand for results
    mockSend.mockResolvedValueOnce({ Items: results });

    const response = await resultsHandler({
      httpMethod: "GET",
      resource: "/runs/{runId}",
      pathParameters: { runId: "run-done-1" },
      queryStringParameters: null,
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body);

    expect(body.run.status).toBe("completed");
    expect(body.run.totalCases).toBe(3);
    expect(body.progress.completed).toBe(3);
    expect(body.progress.passed).toBe(2);
    expect(body.progress.failed).toBe(1);
  });

  it("returns run data without suiteId when results exist (partial lookup)", async () => {
    // No SUMMARY, no suiteId hint — but results exist (progressive writes)
    const partialResult = {
      PK: "RUN#run-orphan-1",
      SK: "CASE#case-1",
      runId: "run-orphan-1",
      caseId: "case-1",
      status: CaseStatus.PASSED,
      toolsInvoked: ["Tool1"],
      turnCount: 3,
      latencyMs: 5000,
    };

    // Call 1: GetCommand for SUMMARY — not found
    mockSend.mockResolvedValueOnce({ Item: undefined });
    // Call 2: QueryCommand for results (Limit: 1) — found!
    mockSend.mockResolvedValueOnce({ Items: [partialResult] });
    // Call 3: Full results query
    mockSend.mockResolvedValueOnce({ Items: [partialResult] });

    const response = await resultsHandler({
      httpMethod: "GET",
      resource: "/runs/{runId}",
      pathParameters: { runId: "run-orphan-1" },
      queryStringParameters: null,
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body);

    // We can still serve partial results even without the full run record
    expect(body.run.status).toBe("running");
    expect(body.results).toHaveLength(1);
    expect(body.results[0].caseId).toBe("case-1");
  });
});
