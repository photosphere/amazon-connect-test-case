import * as cdk from "aws-cdk-lib";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as iam from "aws-cdk-lib/aws-iam";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { NodejsFunction } from "aws-cdk-lib/aws-lambda-nodejs";
import { Construct } from "constructs";
import { TestRunStateMachine } from "../src/backend/orchestration/state-machine";
import { computeBedrockGrants } from "./bedrock-grants";
import type { ModelKey } from "../src/backend/orchestration/prompt-registry";

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface OrchestrationConstructProps {
  /** The Amazon Connect instance ID (UUID). */
  connectInstanceId: string;
  /** The Q in Connect assistant ID. */
  assistantId: string;
  /** DynamoDB table for storage (single-table design). */
  table: dynamodb.ITable;
  /** The dummy contact-creator flow ID used to mint contacts for test runs. */
  contactCreatorFlowId: string;
  /**
   * Optional explicit name for the RAG evaluation artifacts S3 bucket.
   *
   * S3 bucket names are GLOBALLY unique. When omitted, CloudFormation
   * auto-generates a unique name, so every deployment (account/region/stack)
   * is collision-free by default. Provide this only when an existing bucket
   * must be reused or a specific name is required; supplying a name that
   * already exists in any account will fail the deployment.
   */
  ragJobBucketName?: string;
}

// ---------------------------------------------------------------------------
// Judge_Model resolver — single source of truth for IAM grant derivation
// ---------------------------------------------------------------------------
//
// The Judge_Model is identified by either a cross-region inference-profile id
// (e.g. `us.anthropic.claude-sonnet-4-6`) or a bare foundation-model id
// (e.g. `anthropic.claude-sonnet-4-6-20250115-v1:0`). The IAM grant on the
// Evaluation Lambda is derived deterministically from this id at synth time
// (Requirements 6.4, 6.5, 6.8).
//
// JUDGE_MODEL_ROUTING_REGIONS encodes the AWS regions a cross-region inference
// profile may route a Converse call to. Adding support for a new prefix is a
// focused diff to this table.

const DEFAULT_JUDGE_MODEL_ID = "us.anthropic.claude-sonnet-4-6";

const JUDGE_MODEL_ROUTING_REGIONS: Readonly<Record<string, readonly string[]>> = {
  "us.": ["us-east-1", "us-east-2", "us-west-2"],
  "eu.": ["eu-central-1", "eu-west-1", "eu-west-3", "eu-north-1"],
  "apac.": [
    "ap-northeast-1",
    "ap-northeast-2",
    "ap-south-1",
    "ap-southeast-1",
    "ap-southeast-2",
  ],
};

// Recognized Bedrock foundation-model vendor prefixes. A `judgeModelId` whose
// first dot-separated segment is one of these — and is not one of the
// inference-profile prefixes above — is treated as a bare foundation-model id
// (Requirement 6.4(b), single-region grant). Any id that matches neither a
// supported inference-profile prefix nor a known vendor prefix fails synth
// (Requirement 6.8).
const FOUNDATION_MODEL_VENDOR_PREFIXES: readonly string[] = [
  "anthropic.",
  "amazon.",
  "meta.",
  "mistral.",
  "cohere.",
  "ai21.",
  "stability.",
];

interface ResolvedJudgeModelGrants {
  /** The (trimmed) judgeModelId that the Lambda will see in JUDGE_MODEL_ID. */
  readonly modelId: string;
  /** The list of resource ARNs the bedrock:Converse / bedrock:InvokeModel grant scopes to. */
  readonly resourceArns: readonly string[];
}

/**
 * Resolve the IAM resource ARNs the Evaluation Lambda's role needs in order to
 * invoke the configured Judge_Model via `bedrock:Converse` /
 * `bedrock:InvokeModel`.
 *
 * The resolution is deterministic and validated at synth time:
 * - Empty / whitespace-only `judgeModelIdRaw` fails synth (Req 6.7).
 * - Unrecognized inference-profile prefix (and not a bare foundation-model
 *   vendor id) fails synth (Req 6.8).
 *
 * For a cross-region inference-profile id (e.g. `us.anthropic.claude-sonnet-4-6`):
 *   - one inference-profile ARN per region in JUDGE_MODEL_ROUTING_REGIONS[prefix]
 *   - one foundation-model ARN per region in the same set, where the
 *     underlying model id is derived deterministically by stripping the
 *     profile prefix from `judgeModelId` (e.g. `us.anthropic.claude-sonnet-4-6`
 *     → `anthropic.claude-sonnet-4-6`). This is the documented strip behavior
 *     used to grant the underlying model id the cross-region profile routes to.
 *
 * For a bare foundation-model id (e.g. `anthropic.claude-3-5-sonnet-20241022-v2:0`):
 *   - a single foundation-model ARN in `deployRegion`.
 *
 * No ARN contains a wildcard segment in the model-id portion (Requirement 6.5).
 */
export function resolveJudgeModelGrants(
  judgeModelIdRaw: string | undefined,
  deployRegion: string,
  account: string,
): ResolvedJudgeModelGrants {
  // Req 6.7: empty / whitespace-only context value fails synth.
  if (judgeModelIdRaw === undefined || judgeModelIdRaw === null) {
    throw new Error(
      "judgeModelId CDK context value is undefined; cannot resolve Judge_Model. " +
        `Either omit the context key (defaults to '${DEFAULT_JUDGE_MODEL_ID}') ` +
        "or provide a non-empty Bedrock model id.",
    );
  }
  const modelId = judgeModelIdRaw.trim();
  if (modelId.length === 0) {
    throw new Error(
      `judgeModelId CDK context value is empty or whitespace-only ('${judgeModelIdRaw}'); ` +
        "cannot deploy the Evaluation Lambda with an empty JUDGE_MODEL_ID. " +
        `Either omit the context key (defaults to '${DEFAULT_JUDGE_MODEL_ID}') ` +
        "or provide a non-empty Bedrock model id.",
    );
  }

  // Cross-region inference-profile id path (Req 6.4(a)).
  for (const [prefix, regions] of Object.entries(JUDGE_MODEL_ROUTING_REGIONS)) {
    if (modelId.startsWith(prefix)) {
      // Derive the underlying foundation-model id by stripping the profile
      // prefix. Documented strip behavior: `us.anthropic.claude-sonnet-4-6`
      // → `anthropic.claude-sonnet-4-6`. The cross-region profile's grant
      // covers BOTH the profile ARN (for the model-id Bedrock validates on
      // input) and the underlying foundation-model ARN per region (for the
      // model invocation Bedrock authorizes against the resolved foundation
      // model after profile resolution).
      const baseModelId = modelId.slice(prefix.length);
      if (baseModelId.length === 0) {
        // e.g. raw value of `us.` with no model id after the prefix.
        throw new Error(
          `judgeModelId '${modelId}' has the inference-profile prefix '${prefix}' ` +
            "but no underlying model id after the prefix.",
        );
      }
      const arns: string[] = [];
      for (const region of regions) {
        arns.push(
          `arn:aws:bedrock:${region}:${account}:inference-profile/${modelId}`,
        );
        arns.push(
          `arn:aws:bedrock:${region}::foundation-model/${baseModelId}`,
        );
      }
      return { modelId, resourceArns: arns };
    }
  }

  // Bare foundation-model id path (Req 6.4(b)) — single-region grant.
  for (const vendor of FOUNDATION_MODEL_VENDOR_PREFIXES) {
    if (modelId.startsWith(vendor)) {
      return {
        modelId,
        resourceArns: [
          `arn:aws:bedrock:${deployRegion}::foundation-model/${modelId}`,
        ],
      };
    }
  }

  // Req 6.8: unrecognized prefix → fail synth with an explicit message.
  throw new Error(
    `Unrecognized judgeModelId '${modelId}': prefix is not one of the supported ` +
      `inference-profile prefixes (${Object.keys(JUDGE_MODEL_ROUTING_REGIONS).join(", ")}) ` +
      "and the id is not a bare foundation-model id from a known vendor " +
      `(${FOUNDATION_MODEL_VENDOR_PREFIXES.join(", ")}). ` +
      "Either pin a supported cross-region inference profile or a bare foundation-model id.",
  );
}

// ---------------------------------------------------------------------------
// Construct
// ---------------------------------------------------------------------------

/**
 * CDK construct that provisions the test orchestration infrastructure:
 * - Conversation Driver Lambda (Q in Connect + Bedrock permissions)
 * - Evaluation Lambda (Bedrock_Judge — Converse against the configured Judge_Model)
 * - Supporting Lambdas (PrepareRun, RecordTranscript, WriteCaseResult, WriteResults)
 * - Step Functions state machine wiring them together
 *
 * Validates Requirements 7.1 and 14.1 (orchestration); Requirement 6.1–6.9
 * (configurable Judge_Model with tightly-scoped IAM grant on the Evaluation
 * Lambda).
 */
export class OrchestrationConstruct extends Construct {
  /** The Step Functions state machine for test run orchestration. */
  public readonly stateMachine: sfn.StateMachine;
  /** The Conversation Driver Lambda function. */
  public readonly conversationDriverFn: lambda.Function;
  /** The Evaluation Lambda function. */
  public readonly evaluationFn: lambda.Function;
  /** The resolved Judge_Model id passed through to the Evaluation Lambda. */
  public readonly judgeModelId: string;

  constructor(scope: Construct, id: string, props: OrchestrationConstructProps) {
    super(scope, id);

    const { connectInstanceId, assistantId, table, contactCreatorFlowId } = props;
    const stack = cdk.Stack.of(this);
    const region = stack.region;
    const account = stack.account;

    // Connect instance ARN used for IAM scoping
    const connectInstanceArn = `arn:aws:connect:${region}:${account}:instance/${connectInstanceId}`;

    // Common environment variables for all orchestration Lambdas
    const commonEnv: Record<string, string> = {
      CONNECT_INSTANCE_ID: connectInstanceId,
      ASSISTANT_ID: assistantId,
      TABLE_NAME: table.tableName,
      // Account ID so the Conversation Driver can build the fully-qualified
      // AI Agent ARN that Connect uses on SendMessage.
      // (AWS_ prefix is reserved by Lambda, so use a custom name.)
      ACCOUNT_ID: account,
      // Dummy contact-creator flow used to mint a real contact per test case so
      // the session has a bindable ContactARN for ORCHESTRATION agent tools.
      CONTACT_CREATOR_FLOW_ID: contactCreatorFlowId,
    };

    // Common Lambda props
    const commonLambdaProps: Partial<lambda.FunctionProps> = {
      runtime: lambda.Runtime.NODEJS_24_X,
      architecture: lambda.Architecture.ARM_64,
      memorySize: 512,
      tracing: lambda.Tracing.ACTIVE,
      environment: commonEnv,
    };

    // esbuild bundling config shared by the orchestration Lambdas that call
    // newer Q in Connect APIs.
    //
    // CRITICAL: NodejsFunction marks `@aws-sdk/*` as EXTERNAL by default, which
    // makes the Lambda use the SDK version bundled into the nodejs24.x runtime.
    // That runtime SDK is older than our pinned @aws-sdk/client-qconnect
    // (3.1060.0) and does NOT serialize the `aiAgentId` field on SendMessage —
    // so the agent override is silently dropped and messages fall through to the
    // assistant's default SELF_SERVICE agent (confirmed via ListSpans).
    //
    // We bundle ONLY @aws-sdk/client-qconnect from this project's node_modules
    // (matching the API construct's proven pattern) so newer fields like
    // SendMessage.aiAgentId and ListSpans are actually sent. The other SDK
    // clients are fine to use from the runtime.
    const commonBundling = {
      externalModules: [
        "@aws-sdk/client-dynamodb",
        "@aws-sdk/lib-dynamodb",
        "@aws-sdk/client-sfn",
        "@aws-sdk/client-bedrock-runtime",
        // Deliberately NOT excluding @aws-sdk/client-qconnect — bundle our pinned version.
      ],
    };

    // esbuild bundling config for the Evaluation Lambda.
    //
    // The Evaluation Lambda uses `@aws-sdk/client-bedrock-runtime`
    // `ConverseCommand` directly via the Bedrock_Judge_Client (Requirement 3.1,
    // 3.2). Pin and bundle that client at the version locked in this project's
    // node_modules so the deployed Lambda does not silently pick up whatever
    // runtime SDK version is in nodejs24.x; this mirrors the existing
    // `@aws-sdk/client-qconnect` bundling pattern in `lib/api-construct.ts`.
    //
    // The AgentCore Evaluate SDK client is no longer referenced anywhere in
    // this project — the AgentCore Evaluate path was abandoned (see TODO.md
    // "AgentCore Evaluate → Bedrock-judge pivot") and the Lambda no longer
    // imports it. The npm dependency has been dropped from `package.json`.
    const evaluationBundling = {
      externalModules: [
        "@aws-sdk/client-dynamodb",
        "@aws-sdk/lib-dynamodb",
        "@aws-sdk/client-sfn",
        // Deliberately NOT excluding @aws-sdk/client-bedrock-runtime — bundle our pinned version.
      ],
    };

    // -----------------------------------------------------------------
    // Bedrock grant summary — populated as each Bedrock-calling Lambda
    // is wired below via `computeBedrockGrants`. Surfaced on the
    // `OrchestrationBedrockGrantSummary` CFN output (R19.6) so a
    // deployment review can read off which models each Lambda is
    // permitted to invoke without parsing the synthesised IAM JSON.
    // Keyed by the Lambda construct's logical id (the second argument
    // to `new NodejsFunction(this, ...)`) so the output's keys match
    // what shows up in the CFN template.
    //
    // Post-Wave-3 posture (Task 20.2): the helper-derived
    // `iam.PolicyStatement` from `computeBedrockGrants` is now the
    // ONLY `bedrock:InvokeModel` / `bedrock:Converse` grant on each
    // Lambda role. The Wave 0 dual-grant safety overlap (registry-
    // derived statement attached alongside a legacy inline
    // `bedrock:InvokeModel` / `bedrock:Converse` block, kept while
    // Waves 0–2 burned in) has been removed — the registry has been
    // the production resolution path long enough that a regression in
    // `allowedModels[]` is caught by the CDK assertion test in
    // `tests/cdk/bedrock-grants.test.ts` rather than a dual grant.
    // The RAG Evaluate Lambda still carries an inline statement for
    // `bedrock:CreateEvaluationJob` / `GetEvaluationJob` /
    // `StopEvaluationJob` because those evaluation-job lifecycle APIs
    // are outside the helper's `InvokeModel` / `Converse` scope and
    // must remain `Resource: *` per Bedrock's service docs.
    //
    // Output naming: `api-construct.ts` already emits a
    // `BedrockGrantSummary` CFN output for the four Bedrock-calling
    // Lambdas it owns. Each construct emits its own — there can only
    // be one CfnOutput per logical id per stack — so this construct
    // uses `OrchestrationBedrockGrantSummary` to keep the two
    // summaries side-by-side in the CFN template without colliding.
    const bedrockGrantSummary: Record<string, readonly ModelKey[]> = {};

    // -----------------------------------------------------------------
    // Resolve the Judge_Model id and its IAM resource scope
    // -----------------------------------------------------------------
    //
    // Read the `judgeModelId` CDK context key with the platform default
    // (matches `src/backend/handlers/analysis.ts` and
    // `src/backend/handlers/scaffold.ts`). Validate the value at synth and
    // derive the IAM resource list deterministically.

    const judgeModelIdContext = this.node.tryGetContext("judgeModelId") as
      | string
      | undefined;
    const judgeModelIdRaw =
      judgeModelIdContext !== undefined ? judgeModelIdContext : DEFAULT_JUDGE_MODEL_ID;

    // Resolve and validate the configured Judge_Model id at synth time.
    // The returned `resourceArns` were historically used to scope an inline
    // `bedrock:InvokeModel` / `bedrock:Converse` block on the Evaluation
    // Lambda's role; that block has been retired (Task 20.2 — registry-
    // derived `computeBedrockGrants` is now the single source of truth for
    // the catalog grant on this Lambda). The synth-time validation in
    // `resolveJudgeModelGrants` is retained because it still enforces
    // Reqs 6.7 (empty / whitespace-only context fails synth) and 6.8
    // (unrecognized prefix fails synth) — without it a misconfigured
    // `judgeModelId` would silently propagate to deployment, and Wave 3
    // (Task 20.3) removed the runtime `JUDGE_MODEL_ID` env var so the
    // synth-time gate is the only signal an operator gets that their
    // context override is malformed.
    const { modelId: judgeModelId } = resolveJudgeModelGrants(
      judgeModelIdRaw,
      region,
      account,
    );

    this.judgeModelId = judgeModelId;

    // -----------------------------------------------------------------
    // PrepareRun Lambda
    // Writes initial run record to DDB, snapshots agent config.
    // -----------------------------------------------------------------
    const prepareRunFn = new NodejsFunction(this, "PrepareRunFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/handlers/prepare-run.ts",
      handler: "handler",
      description: "Prepares a test run: writes initial DDB record and snapshots agent config",
      timeout: cdk.Duration.seconds(30),
      functionName: `${stack.stackName}-PrepareRun`,
    });
    table.grantReadWriteData(prepareRunFn);

    // -----------------------------------------------------------------
    // Conversation Driver Lambda
    // Drives multi-turn test conversations against Q in Connect AI Agents.
    // Needs: Q in Connect session APIs, Bedrock Converse (for customer sim),
    //        DynamoDB write (transcripts)
    // -----------------------------------------------------------------
    this.conversationDriverFn = new NodejsFunction(this, "ConversationDriverFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/conversation-driver.ts",
      handler: "handler",
      description: "Drives multi-turn test conversations against Q in Connect AI Agents",
      timeout: cdk.Duration.minutes(15), // Max turn conversation
      memorySize: 1024,
      functionName: `${stack.stackName}-ConversationDriver`,
      bundling: commonBundling,
    });

    // Q in Connect session permissions (both wisdom: and qconnect: prefixes)
    this.conversationDriverFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "QConnectSessionAPIs",
        effect: iam.Effect.ALLOW,
        actions: [
          "wisdom:CreateSession",
          "wisdom:SendMessage",
          "wisdom:GetNextMessage",
          "wisdom:UpdateSessionData",
          "wisdom:ListSpans",
          "qconnect:CreateSession",
          "qconnect:SendMessage",
          "qconnect:GetNextMessage",
          "qconnect:UpdateSessionData",
          "qconnect:ListSpans",
        ],
        resources: [
          `${connectInstanceArn}/*`,
          `arn:aws:wisdom:${region}:${account}:assistant/*`,
          `arn:aws:wisdom:${region}:${account}:session/*`,
          `arn:aws:wisdom:${region}:${account}:ai-agent/*`,
          `arn:aws:qconnect:${region}:${account}:assistant/*`,
          `arn:aws:qconnect:${region}:${account}:session/*`,
          `arn:aws:qconnect:${region}:${account}:ai-agent/*`,
        ],
      })
    );

    // Bedrock Converse permissions (for customer simulator + Opportunistic
    // Faithfulness scorer) are produced by `computeBedrockGrants` from the
    // Prompt_Registry — see the registry-derived block immediately below.
    // The Conversation Driver Lambda invokes the Customer_Simulator inline
    // (`customer-simulator.ts` is imported and called per turn for
    // text-mode test cases) and the Opportunistic_Faithfulness scorer
    // inline (`opportunistic-faithfulness.ts` is invoked after the trace
    // is captured for tool-sequence cases that hit the Retrieve tool), so
    // the grant is the union of `allowedModels[]` for both promptKeys.
    {
      const grant = computeBedrockGrants({
        promptKeys: ["customer_simulator", "judge_opportunistic_faithfulness"],
        stack,
      });
      this.conversationDriverFn.addToRolePolicy(grant.statement);
      bedrockGrantSummary.ConversationDriverFn = grant.modelKeys;
    }

    // DynamoDB write for transcripts
    table.grantReadWriteData(this.conversationDriverFn);

    // Amazon Connect contact lifecycle permissions — the driver mints a real
    // contact per test case (StartChatContact) so the session has a bindable
    // ContactARN, then stops it (StopContact) when the test completes.
    // DescribeContact is required because CreateSession.contactArn triggers Q in
    // Connect to look up the bound contact's details on the caller's behalf.
    this.conversationDriverFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "ConnectContactLifecycle",
        effect: iam.Effect.ALLOW,
        actions: [
          "connect:StartChatContact",
          "connect:StopContact",
          "connect:DescribeContact",
        ],
        resources: [
          connectInstanceArn,
          `${connectInstanceArn}/*`,
        ],
      })
    );

    // -----------------------------------------------------------------
    // RecordTranscript Lambda
    // Writes conversation transcript to DDB.
    // -----------------------------------------------------------------
    const recordTranscriptFn = new NodejsFunction(this, "RecordTranscriptFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/handlers/record-transcript.ts",
      handler: "handler",
      description: "Records conversation transcript to DynamoDB",
      timeout: cdk.Duration.seconds(30),
      functionName: `${stack.stackName}-RecordTranscript`,
    });
    table.grantWriteData(recordTranscriptFn);

    // -----------------------------------------------------------------
    // WriteCaseResult Lambda
    // Writes individual test case results to DDB immediately after each
    // case completes, enabling the Results Lambda to serve partial results
    // while the run is still in progress.
    // -----------------------------------------------------------------
    const writeCaseResultFn = new NodejsFunction(this, "WriteCaseResultFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/handlers/write-case-result.ts",
      handler: "handler",
      description: "Writes individual test case result to DynamoDB for progressive reads",
      timeout: cdk.Duration.seconds(30),
      functionName: `${stack.stackName}-WriteCaseResult`,
    });
    table.grantWriteData(writeCaseResultFn);

    // -----------------------------------------------------------------
    // Evaluation Lambda
    // Scores test results using the Bedrock_Judge — direct Bedrock Converse
    // calls against the configured Judge_Model with the AWS-published
    // built-in evaluator prompt templates as its rubric.
    //
    // Needs: bedrock:InvokeModel + bedrock:Converse on EXACTLY the configured
    // Judge_Model (no AgentCore permissions, no `bedrock:*` wildcard); DynamoDB
    // read/write for run/case records.
    // -----------------------------------------------------------------
    this.evaluationFn = new NodejsFunction(this, "EvaluationFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/evaluation.ts",
      handler: "handler",
      description:
        "Evaluates test results via the Bedrock_Judge (direct bedrock:Converse against the configured Judge_Model)",
      timeout: cdk.Duration.minutes(5),
      memorySize: 1024,
      functionName: `${stack.stackName}-Evaluation`,
      // Wave 3 (Task 20.3) retired the legacy `JUDGE_MODEL_ID` env var:
      // `bedrock-judge-client.ts` resolves the per-judge model id and
      // inference parameters through the Prompt_Registry's run-pinned
      // snapshot (`resolvePromptForRun`) instead of reading an env var.
      // The Lambda inherits `commonEnv` (CONNECT_INSTANCE_ID,
      // ASSISTANT_ID, TABLE_NAME) from `commonLambdaProps`; no per-
      // Lambda environment override is needed.
      bundling: evaluationBundling,
    });

    // Bedrock Converse permissions for the Bedrock_Judge are produced by
    // `computeBedrockGrants` from the Prompt_Registry — see the
    // registry-derived block immediately below. The Evaluation Lambda
    // invokes the four AgentCore-template judges
    // (`judge_goal_success_rate`, `judge_helpfulness`,
    // `judge_tool_selection`, `judge_opportunistic_faithfulness`) through
    // the Bedrock_Judge_Client, so the IAM grant is the union of every
    // `allowedModels[]` for those promptKeys. The runtime model selection
    // is driven by the registry's `defaultModelKey` (override-able via
    // `PUT /prompts/{key}`); the catalog grant bounds the set of models
    // an override is allowed to resolve to.
    {
      const grant = computeBedrockGrants({
        promptKeys: [
          "judge_goal_success_rate",
          "judge_helpfulness",
          "judge_tool_selection",
          "judge_opportunistic_faithfulness",
        ],
        stack,
      });
      this.evaluationFn.addToRolePolicy(grant.statement);
      bedrockGrantSummary.EvaluationFn = grant.modelKeys;
    }

    // DynamoDB write for scores
    table.grantReadWriteData(this.evaluationFn);

    // -----------------------------------------------------------------
    // WriteResults Lambda
    // Writes final scores and run summary to DDB.
    // -----------------------------------------------------------------
    const writeResultsFn = new NodejsFunction(this, "WriteResultsFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/handlers/write-results.ts",
      handler: "handler",
      description: "Writes final run summary and scores to DynamoDB",
      timeout: cdk.Duration.seconds(30),
      functionName: `${stack.stackName}-WriteResults`,
    });
    table.grantReadWriteData(writeResultsFn);

    // -----------------------------------------------------------------
    // RAG Job Bucket (Stage 2)
    // Stores BYOI input JSONL and Bedrock RAG Evaluation output per run.
    // S3-managed encryption, all public access blocked, 90-day lifecycle.
    //
    // Bucket names are GLOBALLY unique. We only set an explicit `bucketName`
    // when the caller provides one (via the `ragJobBucketName` deploy-time
    // parameter); otherwise we let CloudFormation auto-generate a unique name
    // so every account/region/stack deploys without collision. The previous
    // hardcoded `${stackName}-rag-eval` name collided on any second
    // deployment because that string is fixed per stack name.
    // -----------------------------------------------------------------
    const ragJobBucket = new s3.Bucket(this, "RagJobBucket", {
      ...(props.ragJobBucketName
        ? { bucketName: props.ragJobBucketName }
        : {}),
      encryption: s3.BucketEncryption.S3_MANAGED,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
      lifecycleRules: [{ expiration: cdk.Duration.days(90) }],
    });

    // -----------------------------------------------------------------
    // RAG Submit Job Lambda (Stage 2, Step 1)
    // Loads cases, serializes JSONL, uploads to S3, calls
    // CreateEvaluationJob, persists initial RAGJOB record.
    // -----------------------------------------------------------------
    const submitRagJobFn = new NodejsFunction(this, "SubmitRagJobFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/rag-submit-job.ts",
      handler: "handler",
      description:
        "RAG Stage 2 Step 1: Load cases → JSONL → S3 → CreateEvaluationJob",
      timeout: cdk.Duration.seconds(60),
      memorySize: 512,
      functionName: `${stack.stackName}-SubmitRagJob`,
      environment: {
        ...commonEnv,
        RAG_JOB_BUCKET: ragJobBucket.bucketName,
      },
      bundling: evaluationBundling,
    });

    // IAM: S3 read/write for JSONL input
    ragJobBucket.grantReadWrite(submitRagJobFn);

    // -----------------------------------------------------------------
    // RAG Check Status Lambda (Stage 2, Step 2 — poll loop)
    // Calls GetEvaluationJob, returns status for the SFN Choice state.
    // -----------------------------------------------------------------
    const checkRagJobFn = new NodejsFunction(this, "CheckRagJobFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/rag-check-status.ts",
      handler: "handler",
      description:
        "RAG Stage 2 Step 2: GetEvaluationJob poll (called by SFN Wait/Choice loop)",
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
      functionName: `${stack.stackName}-CheckRagJob`,
      bundling: evaluationBundling,
    });

    // -----------------------------------------------------------------
    // RAG Read Results Lambda (Stage 2, Step 3)
    // Reads per-prompt output from S3, applies thresholds, writes
    // metrics to DDB. Also handles the error path.
    // -----------------------------------------------------------------
    const readRagResultsFn = new NodejsFunction(this, "ReadRagResultsFn", {
      ...commonLambdaProps,
      entry: "src/backend/orchestration/rag-read-results.ts",
      handler: "handler",
      description:
        "RAG Stage 2 Step 3: Read S3 output → parse metrics → apply thresholds → write DDB",
      timeout: cdk.Duration.seconds(120),
      memorySize: 512,
      functionName: `${stack.stackName}-ReadRagResults`,
      environment: {
        ...commonEnv,
        RAG_JOB_BUCKET: ragJobBucket.bucketName,
      },
      bundling: evaluationBundling,
    });

    // IAM: S3 read for evaluation output
    ragJobBucket.grantRead(readRagResultsFn);

    // -----------------------------------------------------------------
    // Bedrock Evaluation Service Role
    // CreateEvaluationJob requires a roleArn that Bedrock assumes to
    // read JSONL input and write evaluation output in the RAG_Job_Bucket.
    // -----------------------------------------------------------------
    const bedrockEvalRole = new iam.Role(this, "BedrockEvalRole", {
      assumedBy: new iam.ServicePrincipal("bedrock.amazonaws.com"),
      description:
        "Service role assumed by Bedrock CreateEvaluationJob to read/write RAG evaluation S3 artifacts and invoke the evaluator model",
    });
    ragJobBucket.grantReadWrite(bedrockEvalRole);

    // The evaluation role also needs permission to invoke the evaluator model.
    // Bedrock RAG evaluation uses foundation models directly (not inference
    // profiles), so we grant broad Bedrock invoke access scoped to the role's
    // trust (only Bedrock can assume it).
    bedrockEvalRole.addToPolicy(
      new iam.PolicyStatement({
        sid: "BedrockInvokeEvaluatorModel",
        effect: iam.Effect.ALLOW,
        actions: [
          "bedrock:InvokeModel",
          "bedrock:InvokeModelWithResponseStream",
        ],
        resources: ["*"],
      })
    );

    // Pass the role ARN to SubmitRagJob (it calls CreateEvaluationJob)
    submitRagJobFn.addEnvironment("BEDROCK_EVAL_ROLE_ARN", bedrockEvalRole.roleArn);

    // SubmitRagJob needs iam:PassRole to pass this role to Bedrock
    submitRagJobFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "PassBedrockEvalRole",
        effect: iam.Effect.ALLOW,
        actions: ["iam:PassRole"],
        resources: [bedrockEvalRole.roleArn],
        conditions: {
          StringEquals: {
            "iam:PassedToService": "bedrock.amazonaws.com",
          },
        },
      })
    );

    // IAM: Bedrock RAG Evaluation APIs on SubmitRagJob (CreateEvaluationJob)
    submitRagJobFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "BedrockRagEvaluationCreate",
        effect: iam.Effect.ALLOW,
        actions: [
          "bedrock:CreateEvaluationJob",
        ],
        resources: ["*"],
      })
    );

    // IAM: Bedrock GetEvaluationJob on CheckRagJobFn (poll only)
    checkRagJobFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: "BedrockRagEvaluationGet",
        effect: iam.Effect.ALLOW,
        actions: [
          "bedrock:GetEvaluationJob",
        ],
        resources: ["*"],
      })
    );
    // Bedrock Converse / InvokeModel permissions for the RAG evaluation
    // job's evaluator model are produced by `computeBedrockGrants` from
    // the Prompt_Registry. This grant goes on SubmitRagJob since it
    // resolves the model and passes it to CreateEvaluationJob.
    {
      const grant = computeBedrockGrants({
        promptKeys: ["rag_evaluation_job"],
        stack,
      });
      submitRagJobFn.addToRolePolicy(grant.statement);
      bedrockGrantSummary.SubmitRagJobFn = grant.modelKeys;
    }

    // IAM: DynamoDB read/write for SubmitRagJob (reads cases, persists RAGJOB record)
    table.grantReadWriteData(submitRagJobFn);

    // IAM: DynamoDB read/write for ReadRagResults (writes metrics/errors, persists final RAGJOB)
    table.grantReadWriteData(readRagResultsFn);

    // -----------------------------------------------------------------
    // Step Functions State Machine
    // Wires: PrepareRun → Map(ConversationDriver → RecordTranscript → WriteCaseResult)
    //        → Choice{hasRagCases?} → [RAG_Evaluate | EvaluateResults] → WriteResults
    // -----------------------------------------------------------------
    const stateMachineConstruct = new TestRunStateMachine(this, "StateMachine", {
      prepareRunFn,
      conversationDriverFn: this.conversationDriverFn,
      recordTranscriptFn,
      writeCaseResultFn,
      evaluateResultsFn: this.evaluationFn,
      writeResultsFn,
      submitRagJobFn,
      checkRagJobFn,
      readRagResultsFn,
    });

    this.stateMachine = stateMachineConstruct.stateMachine;

    // -----------------------------------------------------------------
    // Outputs
    // -----------------------------------------------------------------
    new cdk.CfnOutput(this, "StateMachineArn", {
      value: this.stateMachine.stateMachineArn,
      description: "Step Functions state machine ARN for test run orchestration",
    });

    new cdk.CfnOutput(this, "ConversationDriverFnArn", {
      value: this.conversationDriverFn.functionArn,
      description: "Conversation Driver Lambda ARN",
    });

    new cdk.CfnOutput(this, "EvaluationFnArn", {
      value: this.evaluationFn.functionArn,
      description: "Evaluation Lambda ARN",
    });

    new cdk.CfnOutput(this, "JudgeModelId", {
      value: judgeModelId,
      description: "The Bedrock Judge_Model id the Evaluation Lambda invokes via Converse",
    });

    new cdk.CfnOutput(this, "SubmitRagJobFnArn", {
      value: submitRagJobFn.functionArn,
      description: "SubmitRagJob Lambda ARN (Stage 2, Step 1)",
    });

    new cdk.CfnOutput(this, "CheckRagJobFnArn", {
      value: checkRagJobFn.functionArn,
      description: "CheckRagJobStatus Lambda ARN (Stage 2, Step 2 — poll)",
    });

    new cdk.CfnOutput(this, "ReadRagResultsFnArn", {
      value: readRagResultsFn.functionArn,
      description: "ReadRagResults Lambda ARN (Stage 2, Step 3)",
    });

    new cdk.CfnOutput(this, "RagJobBucketName", {
      value: ragJobBucket.bucketName,
      description: "S3 bucket for RAG Evaluation job input/output artifacts",
    });

    // R19.6: surface the helper-derived Bedrock grant summary on the CFN
    // template as a single JSON map keyed by Lambda logical id with the
    // alphabetically-sorted `modelKeys[]` each Lambda is permitted to
    // invoke. Lets a deployment review answer "which models can this
    // Lambda call?" without parsing the IAM policy JSON, and gives the
    // Task 10.6 assertion test a stable on-template artifact to compare
    // against the registry's expected union.
    //
    // Named `OrchestrationBedrockGrantSummary` (not `BedrockGrantSummary`)
    // because `api-construct.ts` already emits a `BedrockGrantSummary`
    // output for the four Bedrock-calling Lambdas it owns; CFN allows
    // only one output per logical id per stack, so each construct
    // emits its own per-construct summary.
    new cdk.CfnOutput(this, "OrchestrationBedrockGrantSummary", {
      value: JSON.stringify(bedrockGrantSummary),
      description:
        "Map of orchestration-construct Bedrock-calling Lambda logical id -> readonly ModelKey[] derived from computeBedrockGrants (R19.6).",
    });
  }
}
