# Deployment

This guide walks through deploying the platform into an AWS account.

## Table of contents

1. [Prerequisites](#prerequisites)
2. [Quick deploy](#quick-deploy)
3. [Context parameters](#context-parameters)
4. [What gets created](#what-gets-created)
5. [Stack outputs](#stack-outputs)
6. [Updating an existing deployment](#updating-an-existing-deployment)
7. [Tearing down](#tearing-down)
8. [Multi-environment patterns](#multi-environment-patterns)
9. [CI/CD with the machine client](#cicd-with-the-machine-client)

---

## Prerequisites

### AWS account

- An account with permissions to create CDK-managed infrastructure: API Gateway, Lambda, DynamoDB, S3, CloudFront, Cognito, Step Functions, IAM, Secrets Manager, EventBridge.
- The account must be **CDK-bootstrapped** for the target region. If you've never run CDK in this account/region:
  ```bash
  npx cdk bootstrap aws://ACCOUNT-ID/us-east-1
  ```

### Amazon Connect

- An existing Amazon Connect instance with a Q in Connect assistant attached.
- The Connect instance ID (UUID, 36 characters) — find it in the Connect console URL or via `aws connect list-instances`.

The platform does **not** create the Connect instance or the assistant. It discovers them at deploy time. If your Connect instance has no Q in Connect assistant, the deploy fails with an explicit error.

### Bedrock model access

The platform uses Anthropic Claude models via Bedrock for:

- Customer simulation (test execution).
- Test case scaffolding.
- Failure analysis and recommendations.
- RAG case judging.
- Comparison summaries.
- Variant generation and tournament summaries.

You need **inference profile access** to one of:
- `us.anthropic.claude-sonnet-4-6` (default)
- Or another Anthropic Claude variant; override via the `judgeModelId` context parameter.

Request access in the Bedrock console under Model Access in your deployment region (`us-east-1`, `us-east-2`, or `us-west-2` for the US inference profiles).

### Local toolchain

- Node 20.x or later.
- npm 10.x.
- AWS credentials configured locally (`aws configure`, SSO, or environment variables).
- For Amazon employees: see the AWS workflows steering file for Isengard credential shortcuts.

## Quick deploy

```bash
# Install dependencies
npm install

# Build the frontend bundle (CDK uploads `src/frontend/dist` on deploy).
# This installs the frontend's own dependencies under `src/frontend/node_modules`
# and runs Vite. It does NOT compile the CDK / backend TypeScript — `cdk deploy`
# uses `ts-node` directly. Run `npm run typecheck` if you want to typecheck.
npm run build

# Deploy
npx cdk deploy \
  --context connectInstanceId=YOUR-CONNECT-INSTANCE-UUID \
  --context adminEmail=you@example.com \
  --context instanceMode=development \
  --context callbackUrls='["http://localhost:5173"]'
```

The first deploy takes around 6-8 minutes. It creates roughly 30 resources.

When the deploy finishes, look for these outputs:
- `CloudFrontUrl` — your application URL.
- `UserPoolClientId`, `UserPoolId` — for verifying the auth setup.
- `ApiUrl` — API Gateway endpoint (the frontend's `config.json` references this).

If you supplied an `adminEmail`, Cognito will email a temporary password to that address. Open the CloudFront URL, sign in with the admin email and temporary password, set a permanent password, and you're in.

## Context parameters

CDK context parameters are passed via `--context key=value` flags or written into `cdk.json`'s `context` block.

| Parameter | Required | Default | Description |
|---|---|---|---|
| `connectInstanceId` | **Yes** | — | UUID of the Amazon Connect instance the platform tests agents on. The platform fails synth if this is empty or non-UUID. |
| `adminEmail` | No | none | Email of the first Cognito user to create at deploy time. If omitted, no user is created and you'll need to add one manually via the Cognito console or AWS CLI. |
| `instanceMode` | No | `development` | `production` or `development`. Production mode disables agent-write capabilities at UI, API, and IAM layers. See [operations.md](operations.md). |
| `callbackUrls` | No | `["http://localhost:5173"]` | JSON array of additional URLs the Cognito hosted UI may redirect back to after login. The deployed CloudFront URL is **always** appended automatically. |
| `judgeModelId` | No | `us.anthropic.claude-sonnet-4-6` | Bedrock inference profile or foundation model ID for the LLM judge. The IAM grant on the evaluation Lambda role tightens automatically to whatever you set. |
| `frontendBuildDir` | No | `src/frontend/dist` | Override for the frontend build output directory. Used by tests and CI; real deploys leave this unset. |

### Example: deploy to production mode

```bash
npx cdk deploy \
  --context connectInstanceId=11111111-2222-3333-4444-555555555555 \
  --context adminEmail=ops@example.com \
  --context instanceMode=production \
  --context 'callbackUrls=["https://app.example.com"]'
```

Production mode:
- Hides the **Implement Recommendations** button in the UI.
- Returns 403 from `/runs/{id}/apply-recommendations`, `/runs/{id}/experiments`, `/runs/{id}/experiments/{id}/apply`.
- Strips `Update*AIAgent`, `Update*AIPrompt`, `Create*AIAgent`, `Delete*AIAgent` from the Lambda IAM policies.

Read operations and test execution are unaffected.

### Example: pin a different judge model

```bash
npx cdk deploy \
  --context connectInstanceId=... \
  --context judgeModelId=anthropic.claude-3-5-sonnet-20241022-v2:0
```

For inference profile IDs (with `us.`/`eu.`/`apac.` prefixes), the IAM grant covers all routing regions. For bare foundation-model IDs, the grant covers only the deploy region.

## What gets created

| Resource type | Count | Notes |
|---|---|---|
| Lambda functions | 14 | All Node 20.x ARM64, X-Ray enabled. |
| Step Functions state machines | 2 | TestRun + Experiment. |
| API Gateway REST API | 1 | Cognito-protected, `prod` stage. |
| Cognito User Pool | 1 | + Resource Server, Web Client, Machine Client. |
| Cognito Identity Pool | 1 | Authenticated role with Q in Connect + Bedrock permissions. |
| DynamoDB table | 1 | Single-table, 2 GSIs, point-in-time recovery, TTL. |
| S3 buckets | 2 | Frontend bucket + RAG evaluation bucket (created on demand). |
| CloudFront distribution | 1 | OAI-protected, SPA fallback for client routing. |
| Secrets Manager secret | 1 | Machine client secret for CI/CD. |
| Connect contact flow | 1 | Synthetic contact-creator flow used by orchestration tools. |
| Custom resources | 2-3 | Assistant discovery, optional admin user bootstrap, frontend deployment. |

Total: approximately 30 CloudFormation resources.

## Stack outputs

After a successful deploy, these are surfaced as CloudFormation outputs:

| Output | Purpose |
|---|---|
| `CloudFrontUrl` | The application URL. Open this to use the platform. |
| `ApiUrl` | API Gateway endpoint. Embedded in the frontend's `config.json`. |
| `UserPoolId` | Cognito User Pool ID. |
| `UserPoolClientId` | The Web Client ID. The frontend's `config.json` uses this — never the machine client. |
| `IdentityPoolId` | Cognito Identity Pool ID. |
| `MachineClientId` | The machine client (client_credentials grant) ID. |
| `MachineClientSecretArn` | Secrets Manager ARN of the machine client secret. |
| `TokenEndpoint` | Cognito token endpoint URL for `client_credentials` grant. |
| `TableName` | DynamoDB table name. |
| `AssistantId` | The discovered Q in Connect assistant ID. |
| `ConnectInstanceId` | Echo of the deploy-time context value. |
| `ContactCreatorFlowId` | The synthetic contact-creator flow ID. |
| `ExperimentStateMachineArn` | The experiment state machine ARN. |

You can list them after the fact with:

```bash
aws cloudformation describe-stacks \
  --stack-name ConnectAgentTestPlatformStack \
  --query 'Stacks[0].Outputs'
```

## Updating an existing deployment

After code changes, redeploy with the same command. CDK computes a delta and only updates changed resources.

```bash
npm run build && npx cdk deploy --context connectInstanceId=... --context adminEmail=...
```

`npm run build` rebuilds the frontend bundle into `src/frontend/dist`; the CDK `BucketDeployment` then uploads it and invalidates CloudFront. Skipping the build and editing only frontend code will deploy stale assets — the CDK custom-resource diff is keyed on the asset hash, so without a fresh `dist` the upload is a no-op.

CDK preserves DynamoDB data, Cognito users, and Step Functions execution history across updates. The frontend bucket contents are replaced; CloudFront cache is invalidated automatically.

If you change `instanceMode`, IAM policies on the apply/experiment Lambdas are re-synthesized — production mode strips the write actions, development mode adds them.

## Tearing down

```bash
npx cdk destroy --context connectInstanceId=...
```

This deletes everything CDK created, including:
- The DynamoDB table (data is **not** preserved — `removalPolicy: DESTROY`).
- The S3 buckets and their contents (`autoDeleteObjects: true`).
- The Cognito User Pool and all users.

For destructive ops in real customer accounts, double-check before running. The default policies are tuned for development environments.

## Multi-environment patterns

Three patterns we've seen work well:

### Pattern A — single development account, multiple stacks

Append a `--stack-name` suffix per environment to deploy multiple isolated copies into the same account:

```bash
npx cdk deploy ConnectAgentTestPlatformStack-dev --context connectInstanceId=...
npx cdk deploy ConnectAgentTestPlatformStack-staging --context connectInstanceId=...
```

Modify `bin/app.ts` to read a stack-suffix context parameter for cleaner separation.

### Pattern B — per-customer accounts

For SAs working with customers, each customer engagement gets its own AWS account. Deploy once per account with the customer's Connect instance ID. Use `instanceMode=production` if the Connect instance is the customer's live production system.

### Pattern C — local development

For frontend-only iteration, run `npm run dev` in `src/frontend/` against a deployed backend:

```bash
# In the deployed environment, add http://localhost:5173 to callbackUrls
# Then:
cd src/frontend
npm run dev
# Open http://localhost:5173
```

The frontend will fetch `/config.json` from the dev server (you'll need to copy the deployed `config.json` to `src/frontend/public/`) but make API calls to the deployed API Gateway.

## CI/CD with the machine client

For automated test runs from a CI pipeline, use the machine client (Client Credentials grant). It can call any API endpoint a regular user can.

```bash
# 1. Get the machine client secret from Secrets Manager
SECRET_ARN=$(aws cloudformation describe-stacks --stack-name ConnectAgentTestPlatformStack \
  --query 'Stacks[0].Outputs[?OutputKey==`MachineClientSecretArn`].OutputValue' --output text)

CLIENT_SECRET=$(aws secretsmanager get-secret-value --secret-id "$SECRET_ARN" \
  --query SecretString --output text)

CLIENT_ID=$(aws cloudformation describe-stacks --stack-name ConnectAgentTestPlatformStack \
  --query 'Stacks[0].Outputs[?OutputKey==`MachineClientId`].OutputValue' --output text)

TOKEN_ENDPOINT=$(aws cloudformation describe-stacks --stack-name ConnectAgentTestPlatformStack \
  --query 'Stacks[0].Outputs[?OutputKey==`TokenEndpoint`].OutputValue' --output text)

# 2. Get an access token
ACCESS_TOKEN=$(curl -s -X POST "$TOKEN_ENDPOINT" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials&client_id=$CLIENT_ID&client_secret=$CLIENT_SECRET&scope=test-platform/run" \
  | jq -r '.access_token')

# 3. Call the API
API_URL=$(aws cloudformation describe-stacks --stack-name ConnectAgentTestPlatformStack \
  --query 'Stacks[0].Outputs[?OutputKey==`ApiUrl`].OutputValue' --output text)

curl -H "Authorization: Bearer $ACCESS_TOKEN" "$API_URL/agents"
```

In a CI pipeline (CodeBuild, GitHub Actions, etc.), store the secret ARN as a config value, fetch the secret at runtime, exchange it for a token, and call the platform API. Typical use cases:

- Trigger a regression run after every agent config commit.
- Block PRs that drop pass rate below a threshold.
- Notify a Slack channel when a run regresses.

## Troubleshooting deploys

| Symptom | Likely cause | Fix |
|---|---|---|
| `cdk deploy` fails: "no Q in Connect assistant found for this instance" | The Connect instance has no assistant. | Create a Q in Connect assistant in the Connect console for this instance, then redeploy. |
| `cdk synth` fails with empty `connectInstanceId` | Required context parameter missing. | Pass `--context connectInstanceId=UUID`. |
| Frontend loads but shows "Runtime configuration unavailable" | `config.json` failed to upload. | Check the `FrontendDeploymentConstruct` custom resource logs in CloudFormation. Re-run the deploy. |
| Login redirects to a 400 page | The CloudFront URL isn't in the Cognito callback URLs. | This shouldn't happen — the CloudFront URL is always appended. If using a custom domain, add it to `callbackUrls`. |
| CloudFront returns stale content | Cache invalidation didn't complete. | Wait 5 minutes; CloudFront propagates globally. Or invalidate manually: `aws cloudfront create-invalidation --distribution-id ... --paths '/*'`. |
| Test runs hang in `running` status | Step Functions execution is stuck. | Check the state machine execution history in the Step Functions console. Common cause: Q in Connect throttling beyond the retry envelope. |
| `Bedrock model not accessible` errors during scaffold/analysis | Model access not granted in Bedrock console. | Request access at Bedrock → Model Access in the deployment region. |
