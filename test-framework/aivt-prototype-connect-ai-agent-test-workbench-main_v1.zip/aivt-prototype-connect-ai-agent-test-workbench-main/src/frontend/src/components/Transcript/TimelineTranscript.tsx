/**
 * TimelineTranscript — single chronological timeline interleaving the
 * customer ↔ agent message exchange with the agent's reasoning steps
 * and tool calls captured from ListSpans.
 *
 * Why interleaved (not two side-by-side flows): the previous "Conversation"
 * and "Reasoning trace" sections forced the user to mentally zip two
 * ordered lists together to follow the case. A single timestamp-ordered
 * timeline matches how testers think about a run ("the customer asked
 * X, the agent thought Y, called tool Z, replied W").
 *
 * Dedup rule: when an execution trace is available, every customer turn
 * from the transcript is rendered, but the transcript's `role: "agent"`
 * entries are *skipped* — the trace's `inference` step is the richer
 * version of the same agent activity (carries timestamps and surfaces
 * co-occurring tool calls), and rendering both would duplicate the
 * agent's text in the timeline.
 *
 * This component is consumed by both the per-case detail page
 * (`CaseDetail.tsx`) and the run results viewer's expandable transcript
 * (`ResultsViewer.tsx`) so the two surfaces stay in sync structurally
 * — every rendering invariant (noise-span filtering, synthetic
 * control-tool placeholder, args/result blocks) lives here.
 */
import Box from '@cloudscape-design/components/box';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import SpaceBetween from '@cloudscape-design/components/space-between';
import type {
  TranscriptTurn,
  ExecutionTrace,
  ExecutionStep,
  InferenceMetadata,
} from '../../../../shared/types';

// ---------------------------------------------------------------------------
// Row components
// ---------------------------------------------------------------------------

/**
 * Renders one customer turn from the transcript. Distinct visual style
 * (no background, light "Customer" label) so the customer's voice is
 * easy to scan top-to-bottom in a long mixed timeline.
 */
export function CustomerTurnRow({ turn }: { turn: TranscriptTurn }): JSX.Element {
  const ts = turn.timestamp ? new Date(turn.timestamp).toLocaleTimeString() : '';
  return (
    <div
      style={{
        padding: '8px 12px',
        borderRadius: 4,
        borderLeft: '4px solid #687078', // neutral grey for customer
      }}
    >
      <Box variant="awsui-key-label">
        {`Customer · turn ${turn.turnNumber}`}
        {ts ? ` · ${ts}` : ''}
        {`  · ${turn.elapsedMs}ms`}
      </Box>
      <Box variant="p">{turn.text}</Box>
    </div>
  );
}

/**
 * Renders an agent text turn from the transcript. Only used as a
 * fallback when no execution trace is available — when a trace exists,
 * the trace's `inference` step is shown instead via {@link
 * ReasoningStepRow} (richer, includes tool calls in the same window).
 */
export function AgentTextRow({ turn }: { turn: TranscriptTurn }): JSX.Element {
  const ts = turn.timestamp ? new Date(turn.timestamp).toLocaleTimeString() : '';
  return (
    <div
      style={{
        background: '#f4f4f4',
        padding: '8px 12px',
        borderRadius: 4,
        borderLeft: '4px solid #5f6b7a',
      }}
    >
      <Box variant="awsui-key-label">
        {`Agent · turn ${turn.turnNumber}`}
        {turn.toolSelected ? ` · Tool: ${turn.toolSelected}` : ''}
        {ts ? ` · ${ts}` : ''}
        {`  · ${turn.elapsedMs}ms`}
      </Box>
      <Box variant="p">{turn.text}</Box>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Duration formatting
// ---------------------------------------------------------------------------

/**
 * Formats a duration in milliseconds to a human-readable label.
 * Returns `"${d} ms"` for values < 1000, `"${(d/1000).toFixed(1)} s"` for values >= 1000.
 * Returns `null` if durationMs is undefined, null, negative, non-numeric,
 * or > 86,400,000 (24 hours).
 *
 * Exported as a pure function for direct testing.
 */
export function formatDuration(durationMs: number | undefined | null): string | null {
  if (durationMs === undefined || durationMs === null) return null;
  if (typeof durationMs !== 'number' || !Number.isFinite(durationMs)) return null;
  if (durationMs < 0 || durationMs > 86_400_000) return null;
  if (durationMs < 1000) return `${Math.round(durationMs)} ms`;
  return `${(durationMs / 1000).toFixed(1)} s`;
}

/**
 * Formats `timeToFirstTokenMs` for display.
 * Returns `null` if value is undefined, null, negative, non-numeric, or > 600,000.
 */
export function formatTtft(timeToFirstTokenMs: number | undefined | null): string | null {
  if (timeToFirstTokenMs === undefined || timeToFirstTokenMs === null) return null;
  if (typeof timeToFirstTokenMs !== 'number' || !Number.isFinite(timeToFirstTokenMs)) return null;
  if (timeToFirstTokenMs < 0 || timeToFirstTokenMs > 600_000) return null;
  return `ttft ${Math.round(timeToFirstTokenMs)} ms`;
}

/**
 * DurationLabel — renders a formatted duration badge.
 * Returns null when durationMs is outside the valid range [0, 86400000].
 */
export function DurationLabel({ durationMs }: { durationMs?: number }): JSX.Element | null {
  const label = formatDuration(durationMs);
  if (label === null) return null;
  return <span>{label}</span>;
}

/**
 * TtftLabel — renders the time-to-first-token badge.
 * Returns null when timeToFirstTokenMs is outside [0, 600000].
 */
export function TtftLabel({ timeToFirstTokenMs }: { timeToFirstTokenMs?: number }): JSX.Element | null {
  const label = formatTtft(timeToFirstTokenMs);
  if (label === null) return null;
  return <span>{label}</span>;
}

// ---------------------------------------------------------------------------
// Reasoning row
// ---------------------------------------------------------------------------

/**
 * ReasoningRow — renders the agent's chain-of-thought reasoning in a visually
 * distinct row (lavender background, purple left border) so it's clearly
 * differentiated from the customer-facing agent reply.
 */
export function ReasoningRow({
  reasoning,
  agentName,
}: {
  reasoning: string;
  agentName?: string;
}): JSX.Element {
  const label = agentName ? `Reasoning · ${agentName}` : 'Reasoning';
  return (
    <div
      style={{
        borderLeft: '4px solid #9333ea',
        padding: '8px 12px',
        background: '#f3e8ff',
        borderRadius: 4,
      }}
    >
      <Box variant="awsui-key-label">{label}</Box>
      <div style={{ whiteSpace: 'pre-wrap', margin: 0 }}>
        {reasoning === '' ? <em>(empty)</em> : reasoning}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// System prompt disclosure
// ---------------------------------------------------------------------------

/**
 * SystemPromptDisclosure — nested collapsed disclosure for `systemInstructions`.
 * Returns null if systemInstructions is undefined.
 */
export function SystemPromptDisclosure({
  systemInstructions,
}: {
  systemInstructions?: string;
}): JSX.Element | null {
  if (systemInstructions === undefined) return null;
  return (
    <ExpandableSection headerText="System prompt" defaultExpanded={false}>
      <div style={{ whiteSpace: 'pre-wrap', fontFamily: 'monospace', fontSize: '12px' }}>
        {systemInstructions}
      </div>
    </ExpandableSection>
  );
}

// ---------------------------------------------------------------------------
// Inference details disclosure
// ---------------------------------------------------------------------------

/**
 * InferenceDetailsDisclosure — Cloudscape ExpandableSection showing key-value
 * inference metadata. Collapsed by default.
 * Returns null if inferenceMetadata is undefined.
 */
export function InferenceDetailsDisclosure({
  inferenceMetadata,
}: {
  inferenceMetadata?: InferenceMetadata;
}): JSX.Element | null {
  if (inferenceMetadata === undefined) return null;

  const entries: Array<{ label: string; value: string }> = [];

  if (inferenceMetadata.requestModel !== undefined) {
    entries.push({ label: 'Model', value: inferenceMetadata.requestModel });
  }

  if (
    inferenceMetadata.usageInputTokens !== undefined ||
    inferenceMetadata.usageOutputTokens !== undefined ||
    inferenceMetadata.usageTotalTokens !== undefined
  ) {
    const parts: string[] = [];
    if (inferenceMetadata.usageInputTokens !== undefined) parts.push(`${inferenceMetadata.usageInputTokens} in`);
    if (inferenceMetadata.usageOutputTokens !== undefined) parts.push(`${inferenceMetadata.usageOutputTokens} out`);
    if (inferenceMetadata.usageTotalTokens !== undefined) parts.push(`${inferenceMetadata.usageTotalTokens} total`);
    entries.push({ label: 'Tokens', value: parts.join(' / ') });
  }

  if (inferenceMetadata.responseFinishReasons !== undefined && inferenceMetadata.responseFinishReasons.length > 0) {
    entries.push({ label: 'Finish reason', value: inferenceMetadata.responseFinishReasons.join(', ') });
  }

  // Prompt: <promptName> v<promptVersion> (<promptId>)
  if (
    inferenceMetadata.promptName !== undefined ||
    inferenceMetadata.promptVersion !== undefined ||
    inferenceMetadata.promptId !== undefined
  ) {
    let promptLabel = '';
    if (inferenceMetadata.promptName !== undefined) promptLabel += inferenceMetadata.promptName;
    if (inferenceMetadata.promptVersion !== undefined) {
      promptLabel += promptLabel ? ` v${inferenceMetadata.promptVersion}` : `v${inferenceMetadata.promptVersion}`;
    }
    if (inferenceMetadata.promptId !== undefined) {
      promptLabel += promptLabel ? ` (${inferenceMetadata.promptId})` : inferenceMetadata.promptId;
    }
    entries.push({ label: 'Prompt', value: promptLabel });
  }

  if (inferenceMetadata.aiAgentVersion !== undefined) {
    entries.push({ label: 'AI Agent version', value: String(inferenceMetadata.aiAgentVersion) });
  }

  if (inferenceMetadata.temperature !== undefined) {
    entries.push({ label: 'Temperature', value: String(inferenceMetadata.temperature) });
  }

  if (inferenceMetadata.requestMaxTokens !== undefined) {
    entries.push({ label: 'Max tokens', value: String(inferenceMetadata.requestMaxTokens) });
  }

  if (inferenceMetadata.timeToFirstTokenMs !== undefined) {
    entries.push({ label: 'Time to first token', value: `${inferenceMetadata.timeToFirstTokenMs} ms` });
  }

  return (
    <ExpandableSection headerText="Inference details" variant="footer" defaultExpanded={false}>
      <SpaceBetween size="xxs">
        {entries.map((entry) => (
          <div key={entry.label}>
            <Box variant="awsui-key-label">{entry.label}</Box>
            <Box variant="p">{entry.value}</Box>
          </div>
        ))}
        <SystemPromptDisclosure systemInstructions={inferenceMetadata.systemInstructions} />
      </SpaceBetween>
    </ExpandableSection>
  );
}

// ---------------------------------------------------------------------------
// Noise-span filter
// ---------------------------------------------------------------------------

/**
 * Predicate identifying scaffolding / handoff marker spans that carry no
 * renderable content. Q in Connect emits `invoke_agent` spans (type:
 * "agent") at the start of every assistant turn and `*_agent` spans
 * (type: "other"), e.g. `escalate_agent` / `complete_agent`, when the
 * orchestrator hands off control via a RETURN_TO_CONTROL tool. Neither
 * carries `inputMessages` / `outputMessages` we can render — the
 * meaningful content lives on the surrounding `inference` and tool
 * steps. Filtering these out keeps the Transcript timeline focused on
 * the customer ↔ agent exchange and the agent's reasoning / tool calls.
 *
 * Intentionally conservative — only `"agent"` and `"other"` step types
 * are filtered. Real reasoning (`"inference"`) and real / synthetic
 * tool steps (`"tool"`) are always preserved.
 */
export function isNoiseStep(step: ExecutionStep): boolean {
  return step.type === 'agent' || step.type === 'other';
}

export function ReasoningStepRow({ step }: { step: ExecutionStep }): JSX.Element {
  // ANSI-free pretty print bounded by length — long results get
  // collapsed with a tail truncation marker so a 10KB JSON blob
  // doesn't blow up the layout.
  const fmt = (v: unknown, max = 600): string => {
    let s: string;
    try {
      s = JSON.stringify(v, null, 2);
    } catch {
      s = String(v);
    }
    if (typeof s !== 'string') s = String(s);
    return s.length > max ? `${s.slice(0, max)}…` : s;
  };

  const ts = step.timestamp ? new Date(step.timestamp).toLocaleTimeString() : '';

  // Build the duration and TTFT label segments for the header strip.
  const durationLabel = formatDuration(step.durationMs);
  const ttftLabel =
    step.type === 'inference'
      ? formatTtft(step.inferenceMetadata?.timeToFirstTokenMs)
      : null;

  if (step.type === 'tool' && step.tool) {
    // RETURN_TO_CONTROL tools (Escalate, Complete, custom control
    // tools) are surfaced as `synthetic_control_tool` steps when
    // ListSpans did not expose their toolUse on the inference span.
    // Their `arguments` and `result` are empty placeholders — the
    // platform consumes the actual payload upstream (see
    // `augmentTraceWithControlTools` in
    // `src/backend/orchestration/span-parser.ts`). Render them with
    // the same explanatory parenthetical the Bedrock judge sees (see
    // `SYNTHETIC_CONTROL_TOOL_NOTE` in
    // `src/shared/utils/judge-prompt-rendering.ts`) instead of
    // misleading `args {}` / `result {}` blocks.
    const isSynthetic = step.spanName === 'synthetic_control_tool';
    if (isSynthetic) {
      return (
        <div
          style={{
            // Neutral grey — this is a marker, not a tool execution
            // (no observable success/failure status to colour-code).
            borderLeft: '4px solid #5f6b7a',
            padding: '8px 12px',
            background: '#fff8e1',
            borderRadius: 4,
          }}
        >
          <Box variant="awsui-key-label">
            {`Tool · ${step.tool.toolName}`}
            {ts ? `  · ${ts}` : ''}
            {`  · step ${step.index}`}
            {durationLabel ? `  · ${durationLabel}` : ''}
          </Box>
          <Box variant="p">
            <em>
              RETURN_TO_CONTROL — call arguments and result not surfaced
              by ListSpans.
            </em>
          </Box>
        </div>
      );
    }
    const ok = step.tool.success !== false;
    return (
      <div
        style={{
          borderLeft: `4px solid ${ok ? '#2e7d32' : '#c62828'}`,
          padding: '8px 12px',
          background: '#fff8e1',
          borderRadius: 4,
        }}
      >
        <Box variant="awsui-key-label">
          {`Tool · ${step.tool.toolName}${ok ? '' : ' (failed)'}`}
          {ts ? `  · ${ts}` : ''}
          {`  · step ${step.index}`}
          {durationLabel ? `  · ${durationLabel}` : ''}
        </Box>
        {step.tool.arguments !== undefined && (
          <Box variant="code" fontSize="body-s">
            <pre style={{ margin: 0, whiteSpace: 'pre-wrap' }}>
              {`args ${fmt(step.tool.arguments)}`}
            </pre>
          </Box>
        )}
        {step.tool.result !== undefined && (
          <Box variant="code" fontSize="body-s">
            <pre style={{ margin: 0, whiteSpace: 'pre-wrap' }}>
              {`result ${fmt(step.tool.result)}`}
            </pre>
          </Box>
        )}
      </div>
    );
  }

  // Inference steps: render reasoning-first / agent-reply split when
  // reasoning is present, relabel from "Inference" to "Agent reply",
  // and include InferenceDetailsDisclosure below.
  if (step.type === 'inference') {
    const hasReasoning = step.reasoning !== undefined;
    const agentReplyRow = (
      <div
        style={{
          borderLeft: '4px solid #1976d2',
          padding: '8px 12px',
          background: '#e8f4fd',
          borderRadius: 4,
        }}
      >
        <Box variant="awsui-key-label">
          {`Agent reply`}
          {step.aiAgentName ? ` · ${step.aiAgentName}` : ''}
          {ts ? `  · ${ts}` : ''}
          {`  · step ${step.index}`}
          {durationLabel ? `  · ${durationLabel}` : ''}
          {ttftLabel ? `  · ${ttftLabel}` : ''}
        </Box>
        <Box variant="p">
          {step.text ?? <em>(no text recorded for this span)</em>}
        </Box>
        <InferenceDetailsDisclosure inferenceMetadata={step.inferenceMetadata} />
      </div>
    );

    if (hasReasoning) {
      return (
        <>
          <ReasoningRow reasoning={step.reasoning!} agentName={step.aiAgentName} />
          {agentReplyRow}
        </>
      );
    }
    return agentReplyRow;
  }

  // Any other span type (non-inference, non-tool) falls through to a
  // neutral text row.
  return (
    <div
      style={{
        borderLeft: '4px solid #1976d2',
        padding: '8px 12px',
        background: '#e8f4fd',
        borderRadius: 4,
      }}
    >
      <Box variant="awsui-key-label">
        {step.spanName}
        {ts ? `  · ${ts}` : ''}
        {`  · step ${step.index}`}
        {durationLabel ? `  · ${durationLabel}` : ''}
        {step.aiAgentName ? `  · ${step.aiAgentName}` : ''}
      </Box>
      <Box variant="p">
        {step.text ?? <em>(no text recorded for this span)</em>}
      </Box>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Timeline assembly
// ---------------------------------------------------------------------------

type TimelineItem =
  | { kind: 'customer'; ts: number; turn: TranscriptTurn }
  | { kind: 'agent-text'; ts: number; turn: TranscriptTurn }
  | { kind: 'trace-step'; ts: number; step: ExecutionStep };

/**
 * Build the chronological timeline by interleaving transcript turns
 * with execution-trace steps. When a trace is present, agent turns
 * from the transcript are dropped (the trace's `inference` step
 * supersedes them); customer turns are always preserved. Noise spans
 * (`invoke_agent`, `*_agent` markers) are filtered out via
 * {@link isNoiseStep}. Items are stable-sorted by timestamp, with
 * customer turns ordered before agent activity at tied timestamps.
 */
export function buildTimeline(
  transcript: TranscriptTurn[],
  executionTrace?: ExecutionTrace | null,
): TimelineItem[] {
  const items: TimelineItem[] = [];
  const haveTrace = !!executionTrace && executionTrace.steps.length > 0;
  for (const turn of transcript) {
    // Skip agent turns from the transcript when we have a richer
    // trace; the trace's inference step covers the same content with
    // better metadata (timestamps, agent name, tool calls).
    if (turn.role === 'agent' && haveTrace) continue;
    const ts = turn.timestamp ? new Date(turn.timestamp).getTime() : NaN;
    items.push({
      kind: turn.role === 'agent' ? 'agent-text' : 'customer',
      ts: Number.isFinite(ts) ? ts : 0,
      turn,
    });
  }
  if (executionTrace) {
    for (const step of executionTrace.steps) {
      // Skip scaffolding / handoff marker spans — they carry no
      // renderable content. Without this filter the timeline shows
      // rows like `invoke_agent` and `escalate_agent` annotated with
      // `(no text recorded for this span)` which is pure noise. The
      // meaningful content is on the surrounding `inference` and
      // tool steps. See {@link isNoiseStep} for the full rule.
      if (isNoiseStep(step)) continue;
      const ts = step.timestamp ? new Date(step.timestamp).getTime() : NaN;
      items.push({
        kind: 'trace-step',
        ts: Number.isFinite(ts) ? ts : 0,
        step,
      });
    }
  }
  // Stable sort by timestamp, then by source preference (transcript
  // first when ties, since the customer turn that caused an inference
  // is logically *before* the inference even when their timestamps
  // collapse to the same millisecond).
  items.sort((a, b) => {
    if (a.ts !== b.ts) return a.ts - b.ts;
    const sourcePriority = (i: TimelineItem) =>
      i.kind === 'customer' ? 0 : i.kind === 'agent-text' ? 1 : 2;
    return sourcePriority(a) - sourcePriority(b);
  });
  return items;
}

// ---------------------------------------------------------------------------
// Public component
// ---------------------------------------------------------------------------

interface TimelineTranscriptProps {
  transcript: TranscriptTurn[];
  executionTrace?: ExecutionTrace | null;
}

/**
 * Render the interleaved customer ↔ agent timeline. Caller is
 * responsible for the surrounding container / header chrome — this
 * component renders only the timeline rows themselves. When neither a
 * transcript nor a trace is available a neutral empty-state row is
 * shown so the caller does not need to special-case the empty path.
 */
export function TimelineTranscript({
  transcript,
  executionTrace,
}: TimelineTranscriptProps): JSX.Element {
  if (transcript.length === 0 && !executionTrace) {
    return (
      <Box variant="p" color="text-status-inactive">
        No transcript or reasoning trace was captured for this case.
      </Box>
    );
  }

  const timeline = buildTimeline(transcript, executionTrace);

  return (
    <SpaceBetween size="xs">
      {timeline.map((item, i) => {
        if (item.kind === 'customer') {
          return (
            <CustomerTurnRow
              key={`c-${item.turn.turnNumber}-${i}`}
              turn={item.turn}
            />
          );
        }
        if (item.kind === 'agent-text') {
          // Only reachable when we have NO trace; renders the
          // transcript's agent reply verbatim.
          return (
            <AgentTextRow
              key={`a-${item.turn.turnNumber}-${i}`}
              turn={item.turn}
            />
          );
        }
        return (
          <ReasoningStepRow
            key={`s-${item.step.index}-${i}`}
            step={item.step}
          />
        );
      })}
    </SpaceBetween>
  );
}
