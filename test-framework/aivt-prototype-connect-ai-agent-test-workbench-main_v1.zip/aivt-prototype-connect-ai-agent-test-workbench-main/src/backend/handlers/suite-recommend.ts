/**
 * Suite Recommend Lambda — POST /runs/{runId}/recommend-suite
 *
 * Produces a 0..N ordered, prioritized list of consolidated edits to the
 * agent's editable surfaces (tool description / instruction / examples /
 * system prompt) that, if applied, are predicted to lift the largest set
 * of failed cases. Sibling to the per-case Analysis Lambda
 * (`analysis.ts`) and structurally mirrors `comparison-summary.ts` —
 * same client caching, same JSON helpers, same `_set*` test injectors.
 *
 * Flow:
 *   1. Validate the path parameter (`runId`).
 *   2. Read the persisted record at `PK=RUN#{runId}, SK=ANALYSIS#SUITE`
 *      first; if present and `force !== true`, return it unchanged so
 *      repeated reads return identical ordering (R8.8, R9.3).
 *   3. Load the failed `TestCaseResult[]`, the `AgentSnapshot`, and any
 *      persisted per-case analyses. Snapshot missing → 404
 *      (R12.3); snapshot examples malformed → 500 (R5.8).
 *   4. Build the per-suite prompt (system + user message with Run
 *      Summary, Agent Configuration, Agent System Prompt, Per-Case
 *      Failures, Instructions block) and call Bedrock Converse with
 *      `temperature: 0`, `topP: 1`, `maxTokens: 2048` against the same
 *      Sonnet 4.6 inference profile as `analysis.ts` and
 *      `comparison-summary.ts`.
 *   5. Filter and validate the parsed recommendations (drop invalid
 *      `targetField` per R5.9; drop empty `targetName` and no-op /
 *      operation-shape violations per R13.3; drop entries whose
 *      `predictedImpact.liftedCaseIds` references unknown case IDs and
 *      deduplicate the remaining IDs per R8.6).
 *   6. Sort by the comparator from the design's "Server-Side Ordering
 *      Enforcement" section: `(priority asc, liftedCaseIds.length desc,
 *      lex(targetField + "|" + targetName) asc)` and renumber `priority`
 *      to a 1-based dense rank (R9.1).
 *   7. Persist the sorted, renumbered array to
 *      `PK=RUN#{runId}, SK=ANALYSIS#SUITE` with `generatedAt` and
 *      `modelId`. Persistence-on-success only — DDB write failure logs
 *      and still returns the response (self-healing R6.6 semantics).
 *   8. Return HTTP 200 with the recommendations array (zero-length when
 *      the model judged no actionable recommendations exist, per R8.1).
 *
 * Retry posture mirrors the per-case analysis Lambda: `ThrottlingException`
 * is retried with exponential backoff (`baseMs: 1000, capMs: 10000,
 * maxRetries: 2`); terminal throttle returns HTTP 503 with
 * `retryable: true` (R12.1, R12.2).
 *
 * @module suite-recommend
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ContentBlock,
  type ConverseCommandInput,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";

import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import { CaseStatus } from "../../shared/enums";
import type {
  AgentSnapshot,
  ExecutionStep,
  ExecutionTrace,
  PerSuiteRecommendation,
  Recommendation,
  RecommendationTarget,
  TestCaseResult,
  TestCaseTargetField,
  ToolDefinition,
} from "../../shared/types";
import {
  buildInferenceConfig,
  type ResolvedPrompt,
} from "../orchestration/prompt-registry";
import { resolvePromptLive } from "../orchestration/prompt-registry/runtime";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";
const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
// The model id, system prompt text, and `maxTokens` cap for this Lambda
// all come from the Prompt_Registry via `resolvePromptLive("suite_recommendation")`.
// The legacy `SUITE_RECOMMEND_MODEL_ID` env var is still set in
// `lib/api-construct.ts` as a Wave-1 safety net and is removed in Wave 3
// (per the prompt-management migration plan).

/** Retry posture for Bedrock throttling — matches the per-case path (R12.1). */
const THROTTLE_BASE_MS = 1000;
const THROTTLE_CAP_MS = 10_000;
const THROTTLE_MAX_RETRIES = 2;

/** SK prefix for persisted per-case analyses (one row per failed case). */
const ANALYSIS_CASE_SK_PREFIX = "ANALYSIS#CASE#";
/** SK literal for the persisted per-suite analysis (one row per run). */
const ANALYSIS_SUITE_SK = "ANALYSIS#SUITE";

/** The five valid {@link RecommendationTarget} values (includes `test_case`). */
const VALID_TARGET_FIELDS: ReadonlySet<RecommendationTarget> = new Set<RecommendationTarget>([
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
  "test_case",
]);

/** The five valid {@link TestCaseTargetField} values for `test_case` recs. */
const VALID_TEST_CASE_FIELDS: ReadonlySet<TestCaseTargetField> = new Set<TestCaseTargetField>([
  "successCriteria",
  "initialUtterance",
  "persona",
  "customerKnowledge",
  "goalDescription",
]);

// ---------------------------------------------------------------------------
// Clients (cached across warm invocations)
// ---------------------------------------------------------------------------

let bedrockClient: BedrockRuntimeClient | null = null;
let ddbDocClient: DynamoDBDocumentClient | null = null;

function getBedrockClient(): BedrockRuntimeClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

function getDDBDocClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const base = new DynamoDBClient({ region: REGION });
    ddbDocClient = DynamoDBDocumentClient.from(base, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setBedrockClient(client: BedrockRuntimeClient | null): void {
  bedrockClient = client;
}

/** @internal — allows test injection */
export function _setDDBDocClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Response helpers (mirror comparison-summary.ts)
// ---------------------------------------------------------------------------

const CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(
  statusCode: number,
  body: unknown,
): { statusCode: number; body: string; headers: Record<string, string> } {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/** Request body for `POST /runs/{runId}/recommend-suite`. */
export interface SuiteRecommendRequest {
  /**
   * When true, bypass the persisted-read shortcut and re-invoke Bedrock
   * even when a persisted per-suite record exists. The persisted record
   * is overwritten and `generatedAt` is updated (R8.8 inverse / R6.3
   * semantics).
   */
  force?: boolean;
}

/** Response body for `POST /runs/{runId}/recommend-suite`. */
export interface SuiteRecommendResponse {
  /**
   * Ordered, prioritized consolidated recommendations. Length 0 is a
   * valid response — it means the model determined no actionable
   * consolidated recommendations exist for this run (R8.1).
   *
   * Ordering contract (R9.1): `recommendations[i].priority <=
   * recommendations[j].priority` for all `i < j`.
   */
  recommendations: PerSuiteRecommendation[];
  /** ISO 8601 timestamp the per-suite analysis was produced. */
  generatedAt: string;
  /** Model ID that produced the recommendations. */
  modelId: string;
}

// ---------------------------------------------------------------------------
// DDB loaders
// ---------------------------------------------------------------------------

/**
 * Strips the DynamoDB `PK` / `SK` keys (and the GSI keys, when present)
 * from an item so the caller sees only domain data.
 */
function stripKeys<T>(item: Record<string, unknown>): T {
  const {
    PK: _PK,
    SK: _SK,
    GSI1PK: _GSI1PK,
    GSI1SK: _GSI1SK,
    GSI2PK: _GSI2PK,
    GSI2SK: _GSI2SK,
    ...rest
  } = item as Record<string, unknown>;
  void _PK;
  void _SK;
  void _GSI1PK;
  void _GSI1SK;
  void _GSI2PK;
  void _GSI2SK;
  return rest as T;
}

/** Persisted per-suite record shape under `PK=RUN#{runId}, SK=ANALYSIS#SUITE`. */
interface PersistedSuiteAnalysis {
  recommendations: PerSuiteRecommendation[];
  generatedAt: string;
  modelId: string;
  /**
   * Resolved `suite_recommendation` prompt version that produced this analysis.
   * `0` means the bundled default was used (no override in effect).
   * Absent on records persisted before the trace-reasoning-and-latency
   * feature deployed (R10.4).
   */
  suiteRecommendationPromptVersion?: number;
}

/** Persisted per-case record shape under `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}`. */
export interface PersistedCaseAnalysis {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;
  recommendations: Recommendation[];
  generatedAt: string;
  modelId: string;
}

/** Read the failed test case results for a run. */
async function getFailedResults(runId: string): Promise<TestCaseResult[]> {
  const client = getDDBDocClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :sk)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}`,
        ":sk": SK_PATTERNS.CASE,
      },
    }),
  );
  const all = (result.Items ?? []).map((it) =>
    stripKeys<TestCaseResult>(it as Record<string, unknown>),
  );
  return all.filter((r) => r.status === CaseStatus.FAILED);
}

/** Read the agent snapshot for a run, or `null` if absent. */
async function getAgentSnapshot(runId: string): Promise<AgentSnapshot | null> {
  const client = getDDBDocClient();
  const result = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: SK_PATTERNS.SNAPSHOT,
      },
    }),
  );
  if (!result.Item) return null;
  return stripKeys<AgentSnapshot>(result.Item as Record<string, unknown>);
}

/** Read all persisted per-case analyses for a run, keyed by case id. */
async function getPersistedCaseAnalyses(
  runId: string,
): Promise<Map<string, PersistedCaseAnalysis>> {
  const client = getDDBDocClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :sk)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}`,
        ":sk": ANALYSIS_CASE_SK_PREFIX,
      },
    }),
  );
  const map = new Map<string, PersistedCaseAnalysis>();
  for (const item of result.Items ?? []) {
    const rec = stripKeys<PersistedCaseAnalysis>(
      item as Record<string, unknown>,
    );
    if (rec && typeof rec.caseId === "string" && rec.caseId.length > 0) {
      map.set(rec.caseId, rec);
    }
  }
  return map;
}

/**
 * Read the persisted per-suite record, or `null` if absent. Returns the
 * raw persisted shape so the caller can re-package it into the API
 * response without any client-side reordering (R9.3).
 */
async function getPersistedSuiteAnalysis(
  runId: string,
): Promise<PersistedSuiteAnalysis | null> {
  const client = getDDBDocClient();
  const result = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: ANALYSIS_SUITE_SK,
      },
    }),
  );
  if (!result.Item) return null;
  return stripKeys<PersistedSuiteAnalysis>(
    result.Item as Record<string, unknown>,
  );
}

/**
 * Persist the sorted, renumbered per-suite analysis. Persistence-on-success
 * only — write failures are logged and re-thrown to the caller, which
 * downgrades the failure to a non-blocking warning (R6.6 semantics).
 */
async function writePersistedSuiteAnalysis(
  runId: string,
  payload: PersistedSuiteAnalysis,
): Promise<void> {
  const client = getDDBDocClient();
  await client.send(
    new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: ANALYSIS_SUITE_SK,
        ...payload,
      },
    }),
  );
}

// ---------------------------------------------------------------------------
// Snapshot validation
// ---------------------------------------------------------------------------

/**
 * Asserts that every tool's `examples` field is a JSON array (or
 * absent / null — both collapse to `[]` per R3.3). Returns the offending
 * tool name on the first malformed entry; `null` when the snapshot is
 * structurally valid.
 *
 * Mirrors the per-case Lambda's read-time validation per R5.8: the field
 * being present-but-not-an-array is a hard error, not a silent
 * degradation, so the malformed record surfaces rather than producing
 * lower-quality recommendations.
 */
function findMalformedExamplesTool(snapshot: AgentSnapshot): string | null {
  for (const tool of snapshot.tools ?? []) {
    const raw = (tool as unknown as { examples?: unknown }).examples;
    if (raw === undefined || raw === null) continue;
    if (!Array.isArray(raw)) {
      return tool.toolName ?? "(unnamed tool)";
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Prompt construction
// ---------------------------------------------------------------------------

/**
 * Renders a numbered list of examples for a single tool, indented under
 * the `Examples:` label. Empty arrays render as the literal `(none)`
 * marker on the same line, distinguishable from a real example with text
 * `(none)` because the latter would render as `1. (none)` with the
 * numbered prefix (R5.7, R14.2).
 */
function formatExamplesBlock(examples: string[]): string {
  if (!Array.isArray(examples) || examples.length === 0) {
    return "  Examples: (none)";
  }
  const numbered = examples
    .map((ex, idx) => `    ${idx + 1}. ${ex}`)
    .join("\n");
  return `  Examples:\n${numbered}`;
}

/**
 * Format tool definitions for inclusion in the per-suite prompt. Mirrors
 * the per-case `formatTools` from `analysis.ts` (task 6) — Examples block
 * placed immediately after `Instruction:` so both Lambdas describe the
 * same tool surface to the model. Implemented locally rather than
 * imported so this Lambda compiles independently of task 6's progress
 * (per the task's coupling-avoidance directive).
 */
function formatTools(tools: ToolDefinition[]): string {
  return tools
    .map((t) => {
      const parts: string[] = [
        `Tool: ${t.toolName}`,
        `  Description: ${t.description}`,
      ];
      if (t.instruction) parts.push(`  Instruction: ${t.instruction}`);
      parts.push(formatExamplesBlock(t.examples ?? []));
      return parts.join("\n");
    })
    .join("\n\n");
}

/** System prompt for the per-suite consolidation call.
 *
 * The literal lives in the Prompt_Registry as `suite_recommendation`
 * (`src/backend/orchestration/prompt-registry/prompts/suite-recommendation.ts`)
 * and is resolved at request time via `resolvePromptLive("suite_recommendation")`.
 */

/**
 * Format a case's reasoning trace as a chronological enumeration of
 * inference steps that carry non-empty `reasoning`. Returns `undefined`
 * when no step carries reasoning, guaranteeing byte-identical output
 * to the prior renderer when appended conditionally.
 *
 * Format per entry: `[step {index} · {timestamp}]\n{reasoning}\n`
 * Entries separated by a blank line. Chronological (sorted by index).
 */
export function formatCaseReasoningTrace(trace: ExecutionTrace | undefined): string | undefined {
  if (!trace || !trace.steps || trace.steps.length === 0) return undefined;

  const reasoningSteps = trace.steps
    .filter((step: ExecutionStep) => typeof step.reasoning === "string" && step.reasoning.length > 0)
    .sort((a: ExecutionStep, b: ExecutionStep) => a.index - b.index);

  if (reasoningSteps.length === 0) return undefined;

  const entries = reasoningSteps.map((step: ExecutionStep) => {
    const ts = step.timestamp ?? "";
    return `[step ${step.index} · ${ts}]\n${step.reasoning}`;
  });

  return entries.join("\n\n");
}

/**
 * Render failure blocks for a subset of case IDs. Shared between the
 * agent-deficiency and test-case-defect sections.
 */
function renderFailureBlocks(
  caseIds: string[],
  failuresByCaseId: Map<string, TestCaseResult>,
  perCaseAnalyses: Map<string, PersistedCaseAnalysis>,
): string {
  const truncate = (s: string, n: number): string =>
    s.length > n ? `${s.slice(0, n)}…` : s;

  const blocks = caseIds.map((caseId) => {
    const result = failuresByCaseId.get(caseId);
    const persisted = perCaseAnalyses.get(caseId);
    const rootCause =
      persisted?.rootCauseCategory ?? "(no per-case analysis)";
    const failureSummary = persisted?.explanation
      ? truncate(persisted.explanation, 200)
      : result?.errorMessage
        ? truncate(result.errorMessage, 200)
        : "(no failure summary available)";
    const recsLine =
      persisted && persisted.recommendations.length > 0
        ? persisted.recommendations
            .map(
              (r) =>
                `    - (${r.targetField}, ${r.targetName})`,
            )
            .join("\n")
        : "    - (none)";
    const lines = [
      `### Case ${caseId}`,
      `- Root cause: ${rootCause}`,
      `- Failure summary: ${failureSummary}`,
      `- Per-case recommendations:`,
      recsLine,
    ];

    // Append reasoning trace sub-section when at least one step carries reasoning
    const reasoningBlock = formatCaseReasoningTrace(result?.executionTrace);
    if (reasoningBlock !== undefined) {
      lines.push(`#### Reasoning trace`);
      lines.push(reasoningBlock);
    }

    return lines.join("\n");
  });

  return blocks.join("\n");
}

/**
 * Build the user message body. Composed of sections: Run Summary,
 * Agent Configuration, Agent System Prompt, Per-Case Failures
 * (partitioned into Agent Deficiency and Test Case Defect sections),
 * and Instructions.
 *
 * The per-case failures are partitioned by `rootCauseCategory`:
 * - Cases with `rootCauseCategory === "test_case_defect"` go into
 *   the `## Test Case Defect Failures` section.
 * - All other cases go into the `## Agent Deficiency Failures` section.
 * - Only sections with cases are rendered.
 */
export function buildUserMessage(params: {
  failedCaseIds: string[];
  snapshot: AgentSnapshot;
  failedResults: TestCaseResult[];
  perCaseAnalyses: Map<string, PersistedCaseAnalysis>;
}): string {
  const { failedCaseIds, snapshot, failedResults, perCaseAnalyses } = params;

  // --- Partition by root cause category --------------------------------
  const testCaseDefectIds: string[] = [];
  const agentDeficiencyIds: string[] = [];
  for (const caseId of failedCaseIds) {
    const analysis = perCaseAnalyses.get(caseId);
    if (analysis?.rootCauseCategory === "test_case_defect") {
      testCaseDefectIds.push(caseId);
    } else {
      agentDeficiencyIds.push(caseId);
    }
  }

  // --- Run Summary -----------------------------------------------------
  const runSummary = [
    "## Run Summary",
    `- Total failed cases: ${failedCaseIds.length}`,
    `- Failed case IDs: ${failedCaseIds.join(", ")}`,
  ].join("\n");

  // --- Agent Configuration --------------------------------------------
  const agentConfig = [
    "## Agent Configuration",
    formatTools(snapshot.tools ?? []),
  ].join("\n");

  // --- Agent System Prompt --------------------------------------------
  const systemPromptSection = [
    "## Agent System Prompt",
    snapshot.systemPrompt ?? "",
  ].join("\n");

  // --- Per-Case Failures (partitioned) --------------------------------
  const failuresByCaseId = new Map(failedResults.map((r) => [r.caseId, r]));

  let perCaseSection = "";

  if (agentDeficiencyIds.length > 0) {
    perCaseSection += "## Agent Deficiency Failures\n";
    perCaseSection += renderFailureBlocks(agentDeficiencyIds, failuresByCaseId, perCaseAnalyses);
    perCaseSection += "\n";
  }

  if (testCaseDefectIds.length > 0) {
    if (perCaseSection.length > 0) {
      perCaseSection += "\n";
    }
    perCaseSection += "## Test Case Defect Failures\n";
    perCaseSection += renderFailureBlocks(testCaseDefectIds, failuresByCaseId, perCaseAnalyses);
    perCaseSection += "\n";
  }

  // --- Instructions ----------------------------------------------------
  const instructions = [
    "## Instructions",
    "Produce a JSON object matching this schema:",
    "{",
    '  "recommendations": [',
    "    {",
    '      "targetField": "tool_description" | "tool_instruction" | "tool_examples" | "system_prompt" | "test_case",',
    '      "targetName": "<tool name, \'system_prompt\', or case_id>",',
    '      "currentText": "<exact existing text>",',
    '      "suggestedText": "<replacement text>",',
    '      "rationale": "<why this change helps>",',
    '      "priority": <positive integer; 1 = highest priority, increasing means lower priority>,',
    '      "testCaseField": "<only when targetField is test_case: successCriteria|initialUtterance|persona|customerKnowledge|goalDescription>",',
    '      "predictedImpact": {',
    '        "liftedCaseIds": ["<case_id>", ...],',
    '        "rationale": "<why this change is expected to lift those cases>"',
    "      }",
    "    }",
    "  ]",
    "}",
    "",
    "Constraints:",
    "- Agent-targeted recommendations (tool_description, tool_instruction, tool_examples, system_prompt) should address cases from the \"Agent Deficiency Failures\" section only. Their liftedCaseIds MUST only reference case IDs from that section.",
    "- Test-case-targeted recommendations (test_case) should address cases from the \"Test Case Defect Failures\" section only. Their liftedCaseIds MUST only reference case IDs from that section.",
    "- Maintain a unified priority ordering across both recommendation types — relative impact determines priority regardless of target type.",
    "- Return ONLY recommendations you judge actionable. Do not pad. Returning an empty array is valid if the failures do not share consolidatable root causes.",
    "- Order the array such that index 0 is the highest-leverage change. The \"priority\" field of recommendation[i] MUST be ≤ priority of recommendation[i+1].",
    "- Every entry in liftedCaseIds MUST appear in the \"Failed case IDs\" list above. No duplicates within a single liftedCaseIds array.",
    "- Each tool_examples operation follows the add/remove/replace conventions: remove → currentText is the exact existing example, suggestedText is empty; add → currentText is empty, suggestedText is the new example; replace → both are non-empty.",
    "- Output ONLY the JSON object. No markdown fences, no preamble, no commentary.",
  ].join("\n");

  return [
    runSummary,
    "",
    agentConfig,
    "",
    systemPromptSection,
    "",
    perCaseSection,
    instructions,
  ].join("\n");
}

// ---------------------------------------------------------------------------
// Bedrock invocation with throttle retry
// ---------------------------------------------------------------------------

/** Sleep with exponential backoff and full jitter, capped at `capMs`. */
async function sleepWithBackoff(
  attempt: number,
  baseMs: number,
  capMs: number,
): Promise<void> {
  const computedDelay = Math.min(baseMs * Math.pow(2, attempt), capMs);
  const actualDelay = Math.random() * computedDelay;
  await new Promise<void>((resolve) => setTimeout(resolve, actualDelay));
}

/**
 * Invoke Bedrock Converse with the throttle retry posture from R12.1
 * (`baseMs: 1000, capMs: 10000, maxRetries: 2` on `ThrottlingException`).
 * Throws the underlying error unchanged so the handler can map terminal
 * throttle to HTTP 503 with `retryable: true` (R12.2).
 */
async function callBedrockWithRetry(
  prompt: ResolvedPrompt,
  userMessage: string,
): Promise<string> {
  const messages: Message[] = [
    {
      role: "user",
      content: [{ text: userMessage }] as ContentBlock[],
    },
  ];

  // The wire-shape helper places `maxTokens` (and any future
  // capability-profile-accepted keys) into the exact arguments the
  // Converse SDK expects. For the `anthropic_claude_4x` profile this
  // emits `{ inferenceConfig: { maxTokens } }` with no `temperature`,
  // `topP`, `topK`, or `stopSequences` — those keys are forbidden by
  // the profile (R17.4) and the legacy literal `temperature: 0` value
  // would have been silently dropped at edit time by the validation
  // pipeline. Determinism is preserved in the typical Anthropic case
  // because Claude 4.x's deterministic-decode behaviour for short,
  // fully-grounded inputs is what backs this endpoint's repeatability
  // contract.
  const built = buildInferenceConfig(prompt);

  // The casts on `inferenceConfig` and `additionalModelRequestFields`
  // bridge the SDK's strict types (`InferenceConfiguration` for the
  // top-level config, `DocumentType` for the additional fields) and
  // our runtime payload — `buildInferenceConfig` already enforced the
  // exact key set against the resolved capability profile, so the
  // values are guaranteed JSON-encodable at runtime.
  const command = new ConverseCommand({
    modelId: prompt.modelId,
    system: [{ text: prompt.text }],
    messages,
    inferenceConfig:
      built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(built.additionalModelRequestFields
      ? {
          additionalModelRequestFields:
            built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  const client = getBedrockClient();

  let lastError: unknown = null;
  for (let attempt = 0; attempt <= THROTTLE_MAX_RETRIES; attempt++) {
    try {
      const resp = await client.send(command);
      const text = resp.output?.message?.content
        ?.map((b) => ("text" in b ? b.text ?? "" : ""))
        .join("");
      if (!text || text.trim().length === 0) {
        throw new Error("Bedrock returned an empty per-suite response.");
      }
      return text.trim();
    } catch (error) {
      lastError = error;
      const errorName = (error as { name?: string })?.name ?? "";
      // Only retry on throttling. Other errors fail fast so the handler
      // can map them to the correct HTTP status without further delay.
      if (errorName !== "ThrottlingException") {
        throw error;
      }
      if (attempt === THROTTLE_MAX_RETRIES) {
        // Out of retries — surface the throttle to the handler.
        throw error;
      }
      await sleepWithBackoff(attempt, THROTTLE_BASE_MS, THROTTLE_CAP_MS);
    }
  }
  // Unreachable — the loop either returns or throws — but TypeScript's
  // control-flow analysis is conservative here.
  throw lastError instanceof Error
    ? lastError
    : new Error("Bedrock retry loop exited without a result.");
}

// ---------------------------------------------------------------------------
// Response parsing, validation, sorting, renumbering
// ---------------------------------------------------------------------------

/**
 * Parse the raw model output into a list of candidate
 * {@link PerSuiteRecommendation} records. Tolerant of markdown code fences
 * even though the prompt forbids them. Returns `null` when the payload is
 * unrecognizable; in that case the handler treats the run as having no
 * actionable recommendations (empty array, R8.1 — same surface the panel's
 * empty state consumes).
 */
export function parseSuiteRecommendResponse(
  responseText: string,
): PerSuiteRecommendation[] | null {
  try {
    let jsonStr = responseText.trim();
    const fenceMatch = jsonStr.match(
      /```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/,
    );
    if (fenceMatch) {
      jsonStr = fenceMatch[1];
    }
    const parsed: unknown = JSON.parse(jsonStr);
    const recs = (parsed as { recommendations?: unknown }).recommendations;
    if (!Array.isArray(recs)) return null;
    return recs as PerSuiteRecommendation[];
  } catch {
    return null;
  }
}

/**
 * Filter candidates against the validation rules layered on top of the
 * model's output:
 *
 *   - Drop any recommendation whose `targetField` is not one of the five
 *     valid {@link RecommendationTarget} values (R5.9, extended for test_case).
 *   - Drop any recommendation whose `targetName` is empty (R13.3).
 *   - Drop any recommendation that violates the no-op or per-surface
 *     operation-shape rules (R13.3 — see the {@link Recommendation}
 *     JSDoc for the full table).
 *   - For `test_case` recommendations: validate `testCaseField` is present
 *     and one of the five valid values; drop if missing/invalid (R3.4, R3.5).
 *   - For `test_case` recommendations: filter `liftedCaseIds` to only
 *     include IDs in the `testCaseDefectCaseIds` set (R6.3).
 *   - For agent recommendations: filter `liftedCaseIds` to only include
 *     IDs NOT in `testCaseDefectCaseIds` (agent-deficiency IDs) (R6.3).
 *   - Drop any recommendation whose `predictedImpact.liftedCaseIds`
 *     references case IDs that are not in the failed-case-IDs list for
 *     this run; deduplicate the surviving IDs within each recommendation
 *     (R8.6).
 *
 * Logs each dropped record so the diagnostic trail is preserved without
 * surfacing the contract violation to the caller.
 */
export function filterAndNormalizeSuiteRecommendations(
  candidates: PerSuiteRecommendation[],
  failedCaseIds: ReadonlySet<string>,
  testCaseDefectCaseIds: ReadonlySet<string>,
): PerSuiteRecommendation[] {
  const out: PerSuiteRecommendation[] = [];

  for (let i = 0; i < candidates.length; i++) {
    const raw = candidates[i] as unknown as Record<string, unknown>;
    const targetField = raw.targetField as RecommendationTarget | undefined;
    const targetName =
      typeof raw.targetName === "string" ? (raw.targetName as string) : "";
    const currentText =
      typeof raw.currentText === "string" ? (raw.currentText as string) : "";
    const suggestedText =
      typeof raw.suggestedText === "string"
        ? (raw.suggestedText as string)
        : "";
    const rationale =
      typeof raw.rationale === "string" ? (raw.rationale as string) : "";
    const priorityRaw = raw.priority;
    const priority =
      typeof priorityRaw === "number" && Number.isFinite(priorityRaw)
        ? Math.max(1, Math.floor(priorityRaw))
        : i + 1;

    // 1. Invalid targetField (R5.9, extended to include test_case).
    if (
      targetField === undefined ||
      !VALID_TARGET_FIELDS.has(targetField)
    ) {
      console.warn(
        `[suite-recommend] dropping recommendation at index ${i}: invalid targetField=${String(
          targetField,
        )}`,
      );
      continue;
    }

    // 2. Empty targetName (R13.3).
    if (targetName.trim().length === 0) {
      console.warn(
        `[suite-recommend] dropping recommendation at index ${i}: empty targetName (targetField=${targetField})`,
      );
      continue;
    }

    // 3. Per-surface operation-shape rules (R13.3).
    //    - For tool_examples:
    //        add     → currentText empty, suggestedText non-empty
    //        remove  → currentText non-empty, suggestedText empty
    //        replace → both non-empty
    //      A no-op (both empty) is invalid for every surface, including
    //      the non-tool_examples surfaces.
    //    - For all surfaces: at least one of currentText / suggestedText
    //      MUST be non-empty (no-op rejection).
    if (currentText.length === 0 && suggestedText.length === 0) {
      console.warn(
        `[suite-recommend] dropping recommendation at index ${i}: both currentText and suggestedText are empty (targetField=${targetField}, targetName=${targetName})`,
      );
      continue;
    }

    // 4. test_case-specific validation (R3.4, R3.5).
    const testCaseFieldRaw = raw.testCaseField as TestCaseTargetField | undefined;
    let testCaseField: TestCaseTargetField | undefined;
    if (targetField === "test_case") {
      if (!testCaseFieldRaw || !VALID_TEST_CASE_FIELDS.has(testCaseFieldRaw)) {
        console.warn(
          `[suite-recommend] dropping recommendation at index ${i}: test_case rec missing/invalid testCaseField=${String(testCaseFieldRaw)}`,
        );
        continue;
      }
      testCaseField = testCaseFieldRaw;
    } else {
      // Non-test_case recs should not carry testCaseField (strip hallucination).
      testCaseField = undefined;
    }

    // 5. liftedCaseIds validation + dedupe (R8.6) with partition awareness (R6.3).
    const impactRaw = (raw.predictedImpact ?? {}) as Record<string, unknown>;
    const impactRationale =
      typeof impactRaw.rationale === "string"
        ? (impactRaw.rationale as string)
        : "";
    const liftedRaw = impactRaw.liftedCaseIds;
    const liftedInput = Array.isArray(liftedRaw)
      ? (liftedRaw as unknown[]).filter(
          (id): id is string => typeof id === "string",
        )
      : [];
    const seen = new Set<string>();
    const liftedCaseIds: string[] = [];
    for (const id of liftedInput) {
      // Must be a known failed case ID.
      if (!failedCaseIds.has(id)) {
        continue;
      }
      // Partition constraint (R6.3):
      // - test_case recs: liftedCaseIds must be subset of testCaseDefectCaseIds
      // - agent recs: liftedCaseIds must be subset of non-defect case IDs
      if (targetField === "test_case") {
        if (!testCaseDefectCaseIds.has(id)) {
          continue;
        }
      } else {
        if (testCaseDefectCaseIds.has(id)) {
          continue;
        }
      }
      if (seen.has(id)) continue;
      seen.add(id);
      liftedCaseIds.push(id);
    }

    const rec: PerSuiteRecommendation = {
      targetField,
      targetName,
      currentText,
      suggestedText,
      rationale,
      priority,
      predictedImpact: {
        liftedCaseIds,
        rationale: impactRationale,
      },
    };
    if (testCaseField !== undefined) {
      rec.testCaseField = testCaseField;
    }
    out.push(rec);
  }

  return out;
}

/**
 * Compare two recommendations using the design's "Server-Side Ordering
 * Enforcement" comparator: `(priority asc, liftedCaseIds.length desc,
 * lex(targetField + "|" + targetName) asc)`. Stable, deterministic,
 * total over valid input.
 */
function compareSuiteRecommendations(
  a: PerSuiteRecommendation,
  b: PerSuiteRecommendation,
): number {
  if (a.priority !== b.priority) return a.priority - b.priority;
  const aLen = a.predictedImpact.liftedCaseIds.length;
  const bLen = b.predictedImpact.liftedCaseIds.length;
  if (aLen !== bLen) return bLen - aLen;
  const aKey = `${a.targetField}|${a.targetName}`;
  const bKey = `${b.targetField}|${b.targetName}`;
  if (aKey < bKey) return -1;
  if (aKey > bKey) return 1;
  return 0;
}

/**
 * Sort and dense-rank the surviving recommendations (R9.1, R15.3). After
 * sorting, `priority` is renumbered to a 1-based dense rank that respects
 * the comparator: items with the same model-assigned priority collapse
 * into the same priority value, but tiebreakers determine their array
 * order. This guarantees `recommendations[i].priority <=
 * recommendations[j].priority` for all `i < j` regardless of what the
 * model emitted.
 */
export function sortAndDenseRankSuiteRecommendations(
  recs: PerSuiteRecommendation[],
): PerSuiteRecommendation[] {
  // Copy first so the caller's array is not mutated.
  const sorted = [...recs].sort(compareSuiteRecommendations);
  let currentRank = 0;
  let prevOriginalPriority: number | null = null;
  return sorted.map((rec) => {
    if (
      prevOriginalPriority === null ||
      rec.priority !== prevOriginalPriority
    ) {
      currentRank += 1;
      prevOriginalPriority = rec.priority;
    }
    return { ...rec, priority: currentRank };
  });
}

// ---------------------------------------------------------------------------
// Lambda handler
// ---------------------------------------------------------------------------

interface APIGatewayEventLite {
  httpMethod?: string;
  body?: string | null;
  pathParameters?: { runId?: string } | null;
  resource?: string;
}

export async function handler(
  event: APIGatewayEventLite,
): Promise<{
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}> {
  // Preflight
  if (event.httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  if (event.httpMethod && event.httpMethod !== "POST") {
    return jsonResponse(405, {
      error: "MethodNotAllowed",
      message: `Method ${event.httpMethod} not supported.`,
    });
  }

  const runId = event.pathParameters?.runId;
  if (!runId) {
    return jsonResponse(400, {
      error: "MissingRunId",
      message: "Missing runId path parameter.",
    });
  }

  // --- Parse body -------------------------------------------------------
  let body: SuiteRecommendRequest = {};
  if (event.body) {
    try {
      body = JSON.parse(event.body) as SuiteRecommendRequest;
    } catch {
      return jsonResponse(400, {
        error: "InvalidJson",
        message: "Request body must be valid JSON.",
      });
    }
  }
  const force = body.force === true;

  try {
    // --- 1. Persisted-read shortcut (R8.8, R9.3) ------------------------
    if (!force) {
      const persisted = await getPersistedSuiteAnalysis(runId);
      if (persisted) {
        const response: SuiteRecommendResponse = {
          recommendations: persisted.recommendations ?? [],
          generatedAt: persisted.generatedAt,
          modelId: persisted.modelId,
        };
        return jsonResponse(200, response);
      }
    }

    // --- 2. Load run state ---------------------------------------------
    const [failedResults, snapshot, perCaseAnalyses] = await Promise.all([
      getFailedResults(runId),
      getAgentSnapshot(runId),
      getPersistedCaseAnalyses(runId),
    ]);

    if (!snapshot) {
      // R12.3: snapshot missing.
      return jsonResponse(404, {
        error: "snapshot_missing",
        message: `Agent snapshot not found for run ${runId}.`,
      });
    }

    const malformedTool = findMalformedExamplesTool(snapshot);
    if (malformedTool !== null) {
      // R5.8: snapshot examples malformed.
      return jsonResponse(500, {
        error: "snapshot_examples_malformed",
        toolName: malformedTool,
        message: `Tool "${malformedTool}" has a non-array \`examples\` field on the persisted snapshot.`,
      });
    }

    const failedCaseIds = failedResults.map((r) => r.caseId);
    const failedCaseIdSet = new Set(failedCaseIds);
    const generatedAt = new Date().toISOString();

    // Resolve the live prompt (text, model id, and `maxTokens`) from
    // the registry. Fail-closed: if the override store read fails the
    // resolver throws `PromptResolutionError` and the catch below maps
    // it to a 500. Done after the DDB run-state reads so we don't pay
    // the registry round-trip on input-validation failures.
    const prompt = await resolvePromptLive("suite_recommendation");

    // --- 3. Empty-failures shortcut ------------------------------------
    // The Recommended Changes Panel never reaches this Lambda when there
    // are no failed cases (R10.2 short-circuits on the client). A direct
    // API caller still gets a coherent empty result without paying for
    // Bedrock — same shape the empty-recommendations branch produces.
    if (failedCaseIds.length === 0) {
      const empty: PersistedSuiteAnalysis = {
        recommendations: [],
        generatedAt,
        modelId: prompt.modelId,
        suiteRecommendationPromptVersion: prompt.version,
      };
      try {
        await writePersistedSuiteAnalysis(runId, empty);
      } catch (err) {
        console.warn(
          `[suite-recommend] DDB write failed for empty (no-failures) record runId=${runId}: ${
            err instanceof Error ? err.message : String(err)
          }`,
        );
      }
      const response: SuiteRecommendResponse = {
        recommendations: empty.recommendations,
        generatedAt: empty.generatedAt,
        modelId: empty.modelId,
      };
      return jsonResponse(200, response);
    }

    // --- 4. Build prompt and call Bedrock ------------------------------
    const userMessage = buildUserMessage({
      failedCaseIds,
      snapshot,
      failedResults,
      perCaseAnalyses,
    });

    const responseText = await callBedrockWithRetry(prompt, userMessage);
    const parsed = parseSuiteRecommendResponse(responseText);
    const candidates = parsed ?? [];

    // --- 5. Filter / normalize -----------------------------------------
    // Compute the set of case IDs classified as test_case_defect for
    // partition-aware liftedCaseIds validation (R6.3).
    const testCaseDefectCaseIds = new Set<string>();
    for (const [caseId, analysis] of perCaseAnalyses) {
      if (analysis.rootCauseCategory === "test_case_defect") {
        testCaseDefectCaseIds.add(caseId);
      }
    }

    const filtered = filterAndNormalizeSuiteRecommendations(
      candidates,
      failedCaseIdSet,
      testCaseDefectCaseIds,
    );

    // --- RAG-only scoping: if all failed cases are RAG type, drop recs ---
    // --- targeting tools other than the Retrieve tool. -------------------
    const allFailedAreRag = failedResults.every(
      (r) => r.caseType === "rag",
    );
    let scopedFiltered = filtered;
    if (allFailedAreRag && filtered.length > 0) {
      const retrieveToolName = snapshot.tools.find(
        (t) => t.toolName.toLowerCase() === "retrieve" ||
               (t.toolType && t.toolType.toUpperCase().includes("RETRIEVE")),
      )?.toolName ?? "Retrieve";

      scopedFiltered = filtered.filter((rec) => {
        if (rec.targetField === "system_prompt") return true;
        if (rec.targetField === "test_case") return true;
        // Only keep tool-targeted recs for the Retrieve tool
        return rec.targetName === retrieveToolName;
      });
    }

    // --- 6. Sort + dense-rank ------------------------------------------
    const sorted = sortAndDenseRankSuiteRecommendations(scopedFiltered);

    // --- 7. Persist (self-healing on failure, R6.6) --------------------
    const payload: PersistedSuiteAnalysis = {
      recommendations: sorted,
      generatedAt,
      modelId: prompt.modelId,
      suiteRecommendationPromptVersion: prompt.version,
    };
    try {
      await writePersistedSuiteAnalysis(runId, payload);
    } catch (err) {
      console.warn(
        `[suite-recommend] DDB write failed runId=${runId}: ${
          err instanceof Error ? err.message : String(err)
        }`,
      );
    }

    // --- 8. Return -----------------------------------------------------
    const response: SuiteRecommendResponse = {
      recommendations: payload.recommendations,
      generatedAt: payload.generatedAt,
      modelId: payload.modelId,
    };
    return jsonResponse(200, response);
  } catch (error) {
    const errorName = (error as { name?: string })?.name ?? "";
    const message =
      error instanceof Error ? error.message : "Unknown error";
    console.error(
      `[suite-recommend] failed runId=${runId} name=${errorName} message=${message}`,
    );
    if (errorName === "ThrottlingException") {
      // R12.2: terminal throttle after retries → 503 retryable.
      return jsonResponse(503, {
        error: "ThrottlingException",
        message: "Bedrock rate limit hit; please retry shortly.",
        retryable: true,
        retryAfterSeconds: 5,
      });
    }
    if (errorName === "AccessDeniedException") {
      return jsonResponse(403, {
        error: "AccessDenied",
        message:
          "Suite-recommend Lambda lacks Bedrock permissions for the configured model.",
      });
    }
    return jsonResponse(500, {
      error: "InternalError",
      message,
      retryable: true,
    });
  }
}
