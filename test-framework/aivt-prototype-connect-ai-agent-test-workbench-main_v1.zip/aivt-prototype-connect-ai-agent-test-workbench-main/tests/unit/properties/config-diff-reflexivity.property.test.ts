// Feature: actionable-recommendations, Property 6: diffAgentConfigs reflexivity over examples
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { diffAgentConfigs } from "@shared/utils/config-diff";
import type { AgentSnapshot, ToolDefinition } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/**
 * Generator for individual example strings exercising the verbatim-preservation
 * contract from R1.4: empty strings, embedded whitespace, embedded newlines,
 * embedded quote characters, and ordinary Unicode-aware text. The reflexivity
 * property must hold across every shape the production system might persist.
 */
const exampleStringArb: fc.Arbitrary<string> = fc.oneof(
  fc.constant(""),
  fc.constant("   "),
  fc.constant("line1\nline2"),
  fc.constant("with\ttab"),
  fc.constant('contains "double" and \'single\' quotes'),
  fc.constant("trailing whitespace   "),
  fc.constant("   leading whitespace"),
  fc.constant("multi\nline\nwith\n\"quotes\""),
  fc.string({ maxLength: 80 }),
  fc.unicodeString({ maxLength: 80 })
);

/**
 * Generator for the per-tool `examples` array. The task explicitly calls for
 * a mix of empty arrays for some tools and non-empty for others, so we let
 * fast-check explore both ends of the spectrum (minLength: 0, maxLength: 8).
 */
const examplesArb: fc.Arbitrary<string[]> = fc.array(exampleStringArb, {
  minLength: 0,
  maxLength: 8,
});

/** Generator for a single ToolDefinition with arbitrary examples. */
const toolDefinitionArb: fc.Arbitrary<ToolDefinition> = fc.record({
  toolName: fc
    .string({ minLength: 1, maxLength: 30 })
    .filter((s) => s.trim().length > 0),
  toolType: fc.constantFrom("function", "action", "query", "CUSTOM"),
  description: fc.string({ minLength: 0, maxLength: 100 }),
  instruction: fc.option(fc.string({ maxLength: 100 }), { nil: undefined }),
  inputSchema: fc.constant({}),
  examples: examplesArb,
});

/**
 * Generator for an `AgentSnapshot` with at-least-one tool guaranteed via the
 * outer minLength so the reflexivity property is exercised against snapshots
 * that actually have an examples surface to compare. Tool names are
 * deduplicated post-generation because `diffAgentConfigs` keys its per-tool
 * comparison off `toolName` via a Map and a duplicate name in the input would
 * collapse silently inside the diff (production agents have unique tool
 * names).
 */
const agentSnapshotArb: fc.Arbitrary<AgentSnapshot> = fc
  .record({
    tools: fc.array(toolDefinitionArb, { minLength: 0, maxLength: 8 }),
    systemPrompt: fc.string({ maxLength: 200 }),
    modelId: fc.string({ minLength: 1, maxLength: 50 }),
    capturedAt: fc.constant("2024-01-01T00:00:00Z"),
  })
  .map((snapshot) => {
    const seen = new Set<string>();
    const uniqueTools = snapshot.tools.filter((t) => {
      if (seen.has(t.toolName)) return false;
      seen.add(t.toolName);
      return true;
    });
    return { ...snapshot, tools: uniqueTools };
  });

/** Deep clone via JSON round-trip (snapshots contain only JSON-safe values). */
function deepCopy<T>(value: T): T {
  return JSON.parse(JSON.stringify(value));
}

// ---------------------------------------------------------------------------
// Property 6: diffAgentConfigs reflexivity over examples
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 15.6, 4.2**
 *
 * Property 6: diffAgentConfigs reflexivity over examples
 *
 * For any `AgentSnapshot` value `s`, `diffAgentConfigs(s, deepCopy(s))`
 * returns a result whose `hasChanges` is `false` and whose `changes` array
 * is empty — including when `s.tools[].examples` arrays are non-empty,
 * contain strings with embedded whitespace, or are intentionally identical
 * between the two operands. The diff function is reflexive over equal-by-value
 * snapshots, including the new `examples` field on each tool.
 */
describe("Property 6: diffAgentConfigs reflexivity over examples", () => {
  it("returns hasChanges=false and an empty changes array when comparing a snapshot to a deep copy of itself", () => {
    fc.assert(
      fc.property(agentSnapshotArb, (snapshot) => {
        const clone = deepCopy(snapshot);
        const result = diffAgentConfigs(snapshot, clone);

        expect(result.hasChanges).toBe(false);
        expect(result.changes).toEqual([]);
        expect(result.changes).toHaveLength(0);
      }),
      { numRuns: 100 }
    );
  });

  it("returns hasChanges=false and an empty changes array when comparing a snapshot to itself by reference", () => {
    // Reflexivity in the strict sense: identity comparison must also collapse
    // to zero changes. This catches any accidental mutation in the diff path.
    fc.assert(
      fc.property(agentSnapshotArb, (snapshot) => {
        const result = diffAgentConfigs(snapshot, snapshot);

        expect(result.hasChanges).toBe(false);
        expect(result.changes).toEqual([]);
        expect(result.changes).toHaveLength(0);
      }),
      { numRuns: 100 }
    );
  });
});
