# Design Document: Actionable Recommendations

## Overview

This feature turns the platform's existing per-case Bedrock-driven failure analysis into a persisted, multi-tier recommendation system that lands on the Run Dashboard rather than being tucked behind the Results Viewer. It does this without replacing any existing module: every backend handler, every shared type, every frontend page named in the requirements is extended in place, and one new sibling Lambda (`suite-recommend.ts`) plus two pure shared utilities (`recommendation-bucketing.ts` and an additional change type in `config-diff.ts`) carry the new functionality.

There are four shipped behavior changes:

1. **Tool examples flow end-to-end**: `examples` is added to `ToolDefinition`, populated by `discovery.ts` from the QConnect `ToolConfiguration`, captured by `runs.snapshotAgent`, surfaced on the Agent Browser and Comparison page, and fed into the per-case analysis prompt as a labeled `Examples:` block.
2. **Per-case recommendations are persisted and bucketed by Tool_Surface**: `analysis.ts` writes its result to `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` and reads it back on subsequent calls. A new `tool_examples` Tool_Surface is added to the four-way bucketing.
3. **Per-suite consolidated recommendations**: A new Lambda at `POST /runs/{runId}/recommend-suite` produces a 0..N ordered, prioritized list of consolidated edits with `predictedImpact.liftedCaseIds`. Persistence at `PK=RUN#{runId}, SK=ANALYSIS#SUITE` mirrors the per-case path.
4. **Recommended Changes Panel on the Run Dashboard**: A new component renders the persisted records above the results table with three explicit empty states (no failures, no recommendations identified, run still running), deep-links to the canonical Failure Analysis view, and a "Re-analyze" action that POSTs `force: true` to both endpoints.

The design choices are conservative on purpose. Persistence keys reuse the existing `RUN#{runId}` partition the Analysis Lambda already reads from. Bedrock client setup, retry posture, and IAM grants for the new `suite-recommend` Lambda mirror `comparison-summary.ts` byte-for-byte so the stack only adds one inference profile family worth of grants. The bucketing helper is a pure function so property tests cover it without infra. Backward compatibility is handled at read time (missing `examples` becomes `[]`, missing persisted analyses fall through to a fresh Bedrock call) so old runs render correctly the moment the feature ships.

### Design Rationale Summary

- **Why persist instead of recompute**: Per-case analysis costs ~$0.05/case at current Sonnet pricing and 5–15 seconds wall clock. Running it on every Run Dashboard visit, every Failure Analysis open, and every case-detail open compounds that cost into double-digit dollars per run for users who pivot back and forth. Persistence is keyed under `RUN#{runId}` (the partition already used for the snapshot, transcripts, and traces) so the access pattern is a single Get or Query, not a cross-partition scan.
- **Why a separate per-suite Lambda instead of an option flag on `/analyze`**: The per-suite call needs a fundamentally different prompt (consolidate, prioritize, predict impact across cases), a different output schema (ordered array with `priority` and `predictedImpact`), and a different persistence key. Co-locating the two would require ~30% of `analysis.ts` to fork on the request flag. A sibling handler keeps each prompt and schema simple and lets the per-case path stay backward compatible (Requirement 6.4).
- **Why `recommendation-bucketing.ts` is a pure shared util**: Both the Recommended Changes Panel and the per-case detail page (Requirement 7.1) need to group recommendations by Tool_Surface. Putting the partition logic in a single tested function keeps the rendering code dumb and gives Property 1 (R15.1) a real target.
- **Why server-side ordering enforcement for per-suite**: Requirement 9.1 mandates monotonic priority ordering on read. The model is non-deterministic enough that asking it to sort and trusting the result is fragile; the Lambda sorts once before persisting. Requirement 9.3 then becomes trivial — the persisted record is already sorted, and clients return it untouched.

## Architecture

```mermaid
graph TB
    subgraph Capture["Snapshot Capture (run start)"]
        RT[Run Trigger Lambda<br/>runs.ts]
        Disc[Discovery Lambda<br/>discovery.ts]
        QiC[Q in Connect<br/>GetAIAgent]
    end

    subgraph Storage["DynamoDB"]
        SnapDDB[("PK=RUN#runId<br/>SK=SNAPSHOT<br/>(extended: tools[].examples)")]
        CaseDDB[("PK=RUN#runId<br/>SK=ANALYSIS#CASE#caseId<br/>(new)")]
        SuiteDDB[("PK=RUN#runId<br/>SK=ANALYSIS#SUITE<br/>(new)")]
        ResultsDDB[("PK=RUN#runId<br/>SK=CASE#caseId<br/>(existing)")]
    end

    subgraph Analysis["Recommendation Engine"]
        AnaL[Analysis Lambda<br/>analysis.ts<br/>POST /runs/runId/analyze]
        SuiteL[Suite Recommend Lambda<br/>suite-recommend.ts<br/>POST /runs/runId/recommend-suite]
        BR[Bedrock Converse<br/>Sonnet 4.6 inference profile]
    end

    subgraph Frontend["Frontend (React + Cloudscape)"]
        AB[Agent Browser<br/>per-tool Examples block]
        Cmp[Comparison Page<br/>tool-examples-changed rows]
        RD[Run Dashboard<br/>RecommendedChangesPanel]
        FA[Failure Analysis View<br/>read persisted, Re-analyze]
        CD[Case Detail Page<br/>per-case persisted recs]
    end

    QiC --> Disc
    QiC --> RT
    Disc --> AB
    RT --> SnapDDB

    SnapDDB --> AnaL
    SnapDDB --> SuiteL
    ResultsDDB --> AnaL
    ResultsDDB --> SuiteL
    CaseDDB -.read first.-> AnaL
    SuiteDDB -.read first.-> SuiteL

    AnaL <--> BR
    SuiteL <--> BR
    AnaL --> CaseDDB
    SuiteL --> SuiteDDB
    CaseDDB --> SuiteL

    SnapDDB --> Cmp
    CaseDDB --> RD
    SuiteDDB --> RD
    CaseDDB --> FA
    SuiteDDB --> FA
    CaseDDB --> CD

    RD -.deep link.-> FA
    CD -.deep link.-> FA
```

The two recommendation paths (per-case and per-suite) are independent: a client can call them in any order, and the per-suite Lambda reads the persisted per-case records when they exist (so prompt context is richer) but does not require them. Persistence-on-success means a Bedrock failure leaves the previous record intact rather than overwriting it with a partial result.

### Reuse Map (no rewrites)

| Module | Change scope |
|---|---|
| `src/shared/types.ts` | Add `examples: string[]` to `ToolDefinition`. Default `[]` on read; required on write. Add shared `Recommendation` type and `PerSuiteRecommendation` extension. |
| `src/backend/handlers/discovery.ts` | Map `tool.examples` from QConnect `ToolConfiguration` into the returned `ToolDefinition`. |
| `src/backend/handlers/runs.ts` (`snapshotAgent`) | Include `examples` in each per-tool record persisted at `PK=RUN#{runId}, SK=SNAPSHOT`. |
| `src/backend/handlers/analysis.ts` | Extend prompt to include each tool's examples. Persist at `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}`. Honor `force: true` request flag. Add `tool_examples` to the `targetField` enum. Drop malformed recommendations (R5.9). Return HTTP 500 on snapshot examples malformation (R5.8). |
| `src/backend/handlers/suite-recommend.ts` (NEW) | `POST /runs/{runId}/recommend-suite`. Mirror `comparison-summary.ts` Bedrock setup, retry/throttle handling, persistence-on-success. |
| `src/shared/utils/config-diff.ts` | Add `tool-examples-changed` change type, emitted independently of `tool-modified`. Treat missing `examples` on either snapshot as `[]`. |
| `src/shared/utils/recommendation-bucketing.ts` (NEW) | Pure `bucketByTargetField(recommendations)` returning four-key partition. |
| `src/frontend/src/pages/FailureAnalysis.tsx` | Read from persisted record on mount instead of recomputing. Add "Re-analyze" button (POST `force: true`). |
| `src/frontend/src/pages/RunDashboard.tsx` | Add `RecommendedChangesPanel` between progress and results sections. |
| `src/frontend/src/pages/AgentBrowser.tsx` | Add per-tool "Examples" section with count badge, "No examples configured" empty state, monospace block. |
| `src/frontend/src/pages/Comparison.tsx` | Render `tool-examples-changed` rows with added/removed/reordered indicators. |
| `lib/api-construct.ts` | Define new `suite-recommend` Lambda with same IAM grants as analysis Lambda. Wire `POST /runs/{runId}/recommend-suite`. |

## Components and Interfaces

### Backend: Discovery Lambda (extension)

```typescript
// src/backend/handlers/discovery.ts (extension)
const tools: ToolDefinition[] = (orchestrationConfig?.toolConfigurations ?? []).map(
  (tool: any) => ({
    toolName: tool.toolName ?? "",
    toolType: tool.toolType ?? "",
    description: tool.description ?? "",
    ...(tool.instruction?.instruction && { instruction: tool.instruction.instruction }),
    inputSchema: tool.inputSchema ?? {},
    // NEW — preserves order, never null/undefined.
    examples: Array.isArray(tool.examples) ? [...tool.examples] : [],
  })
);
```

The QConnect SDK models `examples` as `string[] | undefined` on `AIAgentToolConfiguration`. The mapping treats absent, null, and empty arrays identically (R1.2) and preserves order verbatim including embedded whitespace and newlines (R1.3, R1.4). The field is always present on the response — never omitted — so all downstream consumers can read it without optional-chaining (R1.5).

### Backend: Run Trigger Lambda (`snapshotAgent` extension)

```typescript
// src/backend/handlers/runs.ts (snapshotAgent extension)
const tools: ToolDefinition[] = (orchestrationConfig?.toolConfigurations ?? []).map(
  (tool) => ({
    toolName: tool.toolName!,
    toolType: tool.toolType!,
    description: tool.description ?? "",
    ...(tool.instruction?.instruction && { instruction: tool.instruction.instruction }),
    inputSchema: (tool.inputSchema as Record<string, unknown>) ?? {},
    examples: Array.isArray(tool.examples) ? [...tool.examples] : [],
  })
);
```

Captured at run start, the snapshot is the source of truth for analysis. The snapshot's existing top-level shape (`tools[]`, `systemPrompt`, `modelId`, `capturedAt`) is unchanged; `examples` is added only as a per-tool field within `tools[]` (R3.2).

### Backend: Analysis Lambda (extension)

The Analysis Lambda gains four behaviors:

1. **Persisted-read shortcut**: On entry, query `PK=RUN#{runId}, SK begins_with ANALYSIS#CASE#`. If the result count equals the count of failed cases for the run AND the request body does not include `force: true`, return the persisted records without invoking Bedrock (R6.2).
2. **Prompt extension with examples**: For each tool in the snapshot, render the `Examples:` block immediately after the `Instruction:` line. Render `Examples: (none)` literally when `tool.examples.length === 0` (R5.7, R14.2).
3. **`tool_examples` target field**: The schema in the prompt and in the parser is extended to include `tool_examples`, with the three operations (add, remove, replace) described in R5.2–5.5. Recommendations whose `targetField` is not one of the four valid Tool_Surface values are dropped before persistence and logged (R5.9, R6.5).
4. **Persistence-on-success**: After the analysis result is built (and before returning to the client), each per-case record is written to `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` with `generatedAt` and `modelId`. Persistence failure logs but does not fail the response (R6.6).

The `force: true` flag bypasses the persisted-read shortcut: every failed case is re-analyzed and the persisted records are overwritten with new `generatedAt` timestamps (R6.3).

```typescript
// src/backend/handlers/analysis.ts (request body extension)
export interface AnalysisRequest {
  suiteId?: string;
  /** When true, bypass the persisted-read shortcut and re-invoke Bedrock for every failed case. */
  force?: boolean;
}

// src/backend/handlers/analysis.ts (response shape — extended)
export interface PerCaseAnalysis {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;
  recommendations: Recommendation[];   // shared type from src/shared/types.ts
  generatedAt: string;                 // ISO 8601
  modelId: string;                     // model that produced this analysis
}

export interface AnalysisResponse {
  caseAnalyses: PerCaseAnalysis[];
  generatedAt: string;                 // newest of caseAnalyses[].generatedAt
  modelId: string;                     // model used (consistent across cases in one call)
}
```

The previous `individualAnalyses` / `groupedAnalyses` shape is retired in favor of a flat `caseAnalyses[]`. Grouping by root cause category remains a frontend concern; the Recommended Changes Panel groups for display, the Failure Analysis View groups for display, and the persisted record is the flat list. This keeps the persistence schema simple and the bucketing function pure.

### Backend: Suite Recommend Lambda (new)

```typescript
// src/backend/handlers/suite-recommend.ts
export interface SuiteRecommendRequest {
  force?: boolean;
}

export interface PerSuiteRecommendation extends Recommendation {
  priority: number;                    // positive integer, 1 = highest
  predictedImpact: {
    liftedCaseIds: string[];           // failed case IDs expected to flip
    rationale: string;                 // plain-language prediction explanation
  };
}

export interface SuiteRecommendResponse {
  recommendations: PerSuiteRecommendation[];
  generatedAt: string;
  modelId: string;
}
```

The Lambda flow mirrors `comparison-summary.ts`:

1. Load the failed `TestCaseResult[]`, the `AgentSnapshot`, and any persisted per-case analyses (`PK=RUN#{runId}, SK begins_with ANALYSIS#CASE#`).
2. Read the persisted per-suite record (`PK=RUN#{runId}, SK=ANALYSIS#SUITE`). If present and `force` is not true, return it unchanged (R8.8, R9.3).
3. Build the per-suite prompt (see "Per-Suite Prompt Template" below).
4. Call Bedrock Converse with `temperature: 0`, `maxTokens: 2048`, the same Sonnet 4.6 inference profile as `comparison-summary.ts` and `analysis.ts`.
5. Parse the response, drop any recommendation with an invalid `targetField` or with `liftedCaseIds` referencing case IDs that are not failed cases in this run (R8.6).
6. Sort the parsed array by `(priority asc, liftedCaseIds.length desc, lexicographic targetField+targetName)` — the comparator described under "Server-Side Ordering Enforcement" — and renumber `priority` to be a 1-based dense rank that respects the comparator (so priority always increases monotonically with array index, R9.1).
7. Write to `PK=RUN#{runId}, SK=ANALYSIS#SUITE` with `generatedAt`, `modelId`, and the ordered recommendations array. Persistence-on-success only.
8. Return the persisted record.

Retry posture (R12.1): on `ThrottlingException`, retry with exponential backoff (base 1s, cap 10s, max 2 retries). On terminal failure, return HTTP 503 with `retryable: true`. Snapshot missing returns HTTP 404 with `error: "snapshot_missing"` (R12.3). Snapshot examples malformed returns HTTP 500 with `error: "snapshot_examples_malformed"` (R5.8) — same posture as the per-case path.

### Frontend: RecommendedChangesPanel (new)

```typescript
// src/frontend/src/components/RecommendedChangesPanel.tsx
export interface RecommendedChangesPanelProps {
  runId: string;
  suiteId?: string;
  runStatus: RunStatus;
  failedCount: number;
  errorCount: number;
}
```

Render decisions, in order:

1. `runStatus === RUNNING` → render placeholder "Recommendations will appear when the run completes". Do NOT call the engine (R10.8).
2. `failedCount === 0 && errorCount === 0` → render the green success empty state "No recommended changes — all cases passed". Do NOT call the engine (R10.2). The "Re-analyze" action on this state shows the inline message "No analysis needed — all cases passed" without an engine call (R10.3).
3. Otherwise, on mount, GET-equivalent (POST without `force`) to both `/runs/{runId}/analyze` and `/runs/{runId}/recommend-suite`. Both calls return persisted records if available; if not, both compute and persist (R10.9, R11.1, R11.2).
4. If both calls return non-empty arrays → render per-suite first (top), per-case grouped by root cause and bucketed by Tool_Surface beneath (R10.4, R10.6).
5. If both calls return empty → render "No actionable recommendations were identified for the failed cases in this run" with a "Re-analyze" action that POSTs `force: true` to both endpoints (R10.5).
6. If the per-suite call fails after retry → render the per-suite error state with a "Retry" button; per-case section renders independently (R12.2, R12.5).
7. If a subset of per-case analyses fails inside the per-case Lambda → render an inline notice listing the failed case IDs while still showing the per-suite recommendations and the per-case successes (R12.5).

Footer of the panel always shows a "View full failure analysis" link to `/runs/{runId}/results` (Results Viewer entry, where Failure_Analysis_View lives) — single source of truth (R10.7).

### Frontend: FailureAnalysis.tsx (changes)

The current page calls `runAnalysis()` on mount unconditionally, paying the Bedrock cost on every visit. The change:

1. Replace the auto-mount call with a fetch of the persisted record. The fetch is a POST without `force` to `/runs/{runId}/analyze` — the Lambda's persisted-read shortcut returns the record without re-invoking Bedrock (R11.1).
2. Replace the existing "Re-analyze" button (which currently re-triggers the same call) with one that POSTs `{ force: true }`. After success, update local state with the new response so the next render shows the regenerated content (R11.3).
3. Render now reads from the new flat `caseAnalyses[]` shape; grouping for display happens client-side using the same Tool_Surface bucketing utility as the panel.

### Frontend: AgentBrowser.tsx (per-tool Examples section)

Within each tool's container, immediately below the "Instruction" key/value, add an "Examples" section:

- Section header: `Examples` followed by a count `Badge` showing `tool.examples.length` (rendered even when zero, per R2.4).
- When `tool.examples.length === 0`: render `<Box color="text-status-inactive">No examples configured</Box>` next to the badge (R2.2).
- When non-empty: render an ordered `<ol>` list, each `<li>` a monospace `<pre>` preserving whitespace and newlines (R2.3). The `<pre>` uses `whiteSpace: 'pre-wrap'` and `wordBreak: 'break-word'` to match the existing input-schema rendering pattern.

### Frontend: Comparison.tsx (`tool-examples-changed` rendering)

Adds one row type to the configuration-diff section:

- Row label: `Tool examples changed` with the tool name.
- Layout: side-by-side two-column. Left column shows the prior `examples[]` array; right column shows the new array.
- Item-level highlighting: an item present in `new` but not `prior` renders with a green background (`#f2fcf3`); an item present in `prior` but not `new` renders with a red background (`#fdf0f0`); items present in both with the same string render plain. When the same string appears in both arrays but at different indices (and both arrays are otherwise equal in length and content), the row is annotated with an "order changed" badge per R4.3.

Empty-string items render as `<empty>` literally so users can see deletions are real, not invisible.

## Data Models

### Persisted Record Schemas

**(extended) `PK=RUN#{runId}, SK=SNAPSHOT`** — one record per run, written by `runs.snapshotAgent` at run start.

```typescript
{
  PK: `RUN#${runId}`,
  SK: "SNAPSHOT",
  tools: [
    {
      toolName: string,
      toolType: string,
      description: string,
      instruction?: string,
      inputSchema: Record<string, unknown>,
      examples: string[],          // NEW — element-wise verbatim, order preserved
    },
    ...
  ],
  systemPrompt: string,
  modelId: string,
  capturedAt: string,              // ISO 8601
}
```

Backward compatibility (R3.3): pre-feature snapshots have no `examples` field on any tool. Read code treats absence as `[]` and never throws. The transformation lives in a single read helper so all consumers (analysis, suite-recommend, comparison) see a normalized shape.

**(new) `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}`** — one record per failed case per run, written by `analysis.handler`.

```typescript
{
  PK: `RUN#${runId}`,
  SK: `ANALYSIS#CASE#${caseId}`,
  caseId: string,
  rootCauseCategory: string,       // one of the 8 categories from analysis.ts
  explanation: string,
  traceAvailable: boolean,
  recommendations: Recommendation[],   // shared shape — see "Shared Recommendation Type"
  generatedAt: string,             // ISO 8601
  modelId: string,                 // e.g. "us.anthropic.claude-sonnet-4-6"
}
```

The recommendations array is stored directly (not stringified). Each recommendation's `targetField` is constrained to one of the four Tool_Surface values at write time; entries with invalid `targetField` are dropped before this record is persisted (R5.9).

**(new) `PK=RUN#{runId}, SK=ANALYSIS#SUITE`** — one record per run, written by `suite-recommend.handler`.

```typescript
{
  PK: `RUN#${runId}`,
  SK: "ANALYSIS#SUITE",
  recommendations: PerSuiteRecommendation[],   // already sorted by priority asc
  generatedAt: string,
  modelId: string,
}
```

The recommendations array is sorted server-side before persistence and never reordered on read (R9.3). Length 0 is a valid persisted state — it means the model determined no actionable consolidated recommendations exist for this run (R8.1, R10.5).

### Shared `Recommendation` Type (R13)

```typescript
// src/shared/types.ts (new exports)

/** The four editable Tool_Surface values the orchestration runtime injects at inference time. */
export type ToolSurface =
  | "tool_description"
  | "tool_instruction"
  | "tool_examples"
  | "system_prompt";

/** Operation kind for tool_examples recommendations. Discriminator only — the (currentText, suggestedText) pair encodes the operation per R5.2–5.5. */
export type ToolExamplesOperation = "add" | "remove" | "replace";

/**
 * Shared recommendation shape used by both per-case and per-suite paths.
 * Required-field invariants enforced at persistence time (R13.3):
 *   - targetField is one of the four ToolSurface values
 *   - targetName is non-empty
 *   - at least one of currentText or suggestedText is non-empty
 *   - for tool_examples remove: currentText non-empty, suggestedText empty
 *   - for tool_examples add:    currentText empty,     suggestedText non-empty
 *   - for tool_examples replace: both non-empty
 */
export interface Recommendation {
  targetField: ToolSurface;
  /** Tool name for tool_* fields, or the literal "system_prompt" for system_prompt. */
  targetName: string;
  currentText: string;
  suggestedText: string;
  rationale: string;
}

/** Per-suite extension: priority and predicted impact. */
export interface PerSuiteRecommendation extends Recommendation {
  /** Positive integer, lower is higher priority. 1 = highest. Monotonic with array index. */
  priority: number;
  predictedImpact: {
    /** Failed case IDs the recommendation is expected to flip from failing to passing. */
    liftedCaseIds: string[];
    /** Plain-language explanation of the prediction. */
    rationale: string;
  };
}
```

The `targetName` for a `tool_examples` operation is the tool name (R5.2), never the example string itself. The example text lives in `currentText`/`suggestedText` according to the operation, so the rendering component does not need to know the operation kind to render the diff — it just shows current vs suggested as it does today.

### Tool Definition Extension

```typescript
// src/shared/types.ts (extension)
export interface ToolDefinition {
  toolName: string;
  toolType: string;
  description: string;
  instruction?: string;
  inputSchema: Record<string, unknown>;
  /** Few-shot examples injected by the orchestration runtime. Required field; default [] on read; required-non-null on write. */
  examples: string[];
}
```

The field is required on the type but defaults to `[]` everywhere it is read (R1.2, R1.5, R3.3). Writes (snapshot persistence, discovery response construction) always include the field; the type system makes the field-omission bug uncatchable at compile time, which is the contract stated in the requirement.

## Per-Case Prompt Extension

The existing per-case prompt builds an "Agent Configuration — Tool Descriptions" block via `formatTools(snapshot.tools)`. The block is extended so each tool's entry includes the examples after the instruction line:

```
Tool: getAccountBalance
  Description: Returns the customer's current account balance.
  Instruction: Use only after identity verification.
  Examples:
    1. "What's my balance?"
    2. "How much do I have in checking?"
    3. "Tell me my account total"
```

When a tool has no examples (R5.7, R14.2):

```
Tool: transferFunds
  Description: Transfers money between the customer's accounts.
  Instruction: Confirm both source and destination accounts before invoking.
  Examples: (none)
```

The Examples block is rendered immediately after `Instruction:` (R14.1). When `instruction` is absent the Examples block follows `Description:` directly. The literal `(none)` is the empty marker — distinguishable from a real example with text `(none)` because the latter would render as `1. (none)` with the numbered prefix.

The instructions block at the bottom of the prompt is extended with one paragraph (R14.3):

> The four valid `targetField` values are `tool_description`, `tool_instruction`, `tool_examples`, and `system_prompt`. For `tool_examples`, structure your recommendation as one of three operations: (1) **add** — set `currentText` to empty and `suggestedText` to the new example; (2) **remove** — set `currentText` to the exact existing example and `suggestedText` to empty; (3) **replace** — set `currentText` to the exact existing example and `suggestedText` to its replacement. The `targetName` is always the tool name. For exact-string operations, the existing example text in `currentText` MUST match an entry in the tool's Examples block character-for-character.

## Per-Suite Prompt Template

Distinct from the per-case prompt (R8.3). System prompt:

> You are an expert at consolidating AI agent test failures into a small, prioritized set of high-leverage recommendations. You receive (a) a list of failed test cases with their root cause categories and per-case recommendations, (b) the agent's tool configuration including each tool's description, instruction, and examples, and (c) the agent's system prompt. Produce zero or more consolidated recommendations, ordered such that index 0 is the highest-leverage change. Each recommendation targets exactly one Tool_Surface (`tool_description`, `tool_instruction`, `tool_examples`, or `system_prompt`). For each recommendation, predict which failed case IDs it would flip to passing if applied, and provide a brief rationale for that prediction.

User message structure:

```
## Run Summary
- Total failed cases: {N}
- Failed case IDs: {comma-separated}

## Agent Configuration
{formatTools(snapshot.tools) including Examples blocks — same renderer as per-case}

## Agent System Prompt
{snapshot.systemPrompt}

## Per-Case Failures
{for each failed case}:
  ### Case {caseId}
  - Root cause: {rootCauseCategory or "(no per-case analysis)"}
  - Failure summary: {first 200 chars of explanation, or transcript-derived summary}
  - Per-case recommendations: {bulleted list of (targetField, targetName) pairs from the persisted per-case analysis, when available}

## Instructions
Produce a JSON object matching this schema:
{
  "recommendations": [
    {
      "targetField": "tool_description" | "tool_instruction" | "tool_examples" | "system_prompt",
      "targetName": "<tool name or 'system_prompt'>",
      "currentText": "<exact existing text>",
      "suggestedText": "<replacement text>",
      "rationale": "<why this change helps>",
      "priority": <positive integer; 1 = highest priority, increasing means lower priority>,
      "predictedImpact": {
        "liftedCaseIds": ["<case_id>", ...],
        "rationale": "<why this change is expected to lift those cases>"
      }
    }
  ]
}

Constraints:
- Return ONLY recommendations you judge actionable. Do not pad. Returning an empty array is valid if the failures do not share consolidatable root causes.
- Order the array such that index 0 is the highest-leverage change. The "priority" field of recommendation[i] MUST be ≤ priority of recommendation[i+1].
- Every entry in liftedCaseIds MUST appear in the "Failed case IDs" list above. No duplicates within a single liftedCaseIds array.
- Each tool_examples operation follows the add/remove/replace conventions: remove → currentText is the exact existing example, suggestedText is empty; add → currentText is empty, suggestedText is the new example; replace → both are non-empty.
- Output ONLY the JSON object. No markdown fences, no preamble, no commentary.
```

`predictedImpact` rules (R8.5, R8.6): `liftedCaseIds` references only failed case IDs from the current run. Server-side validation drops any recommendation whose `liftedCaseIds` array contains an unknown ID; this prevents the model from hallucinating case IDs from prior runs.

The model is explicitly told zero is valid (R8.1) and the array is not capped at any maximum. The prompt's "do not pad" instruction is paired with an empty-array example to keep the model from filling space.

## Server-Side Ordering Enforcement

After parsing, before persistence, the Lambda sorts the recommendations array. The comparator (pseudocode):

```
function compareSuiteRecommendations(a, b):
  // Primary: model-assigned priority, ascending (lower = higher priority)
  if a.priority != b.priority:
    return sign(a.priority - b.priority)
  // Tiebreak 1: longer liftedCaseIds first (more impact wins)
  if a.predictedImpact.liftedCaseIds.length != b.predictedImpact.liftedCaseIds.length:
    return sign(b.predictedImpact.liftedCaseIds.length - a.predictedImpact.liftedCaseIds.length)
  // Tiebreak 2: lexicographic (targetField + "|" + targetName), ascending — stable, deterministic
  return compareLex(a.targetField + "|" + a.targetName, b.targetField + "|" + b.targetName)
```

After sorting, `priority` is renumbered to be a dense 1-based rank that respects the comparator: items with the same model-assigned priority are collapsed into the same priority value, but tiebreakers determine their array order. This guarantees Property 3 (R15.3): `recommendations[i].priority <= recommendations[j].priority` for all `i < j`.

The client never reorders. The Recommended Changes Panel and the Failure Analysis View render the persisted array as-is (R9.3, R15.4).

## Bucketing Helper Signature

```typescript
// src/shared/utils/recommendation-bucketing.ts

export interface BucketedRecommendations<T extends Pick<Recommendation, "targetField">> {
  tool_description: T[];
  tool_instruction: T[];
  tool_examples: T[];
  system_prompt: T[];
}

/**
 * Pure partition of recommendations by Tool_Surface.
 * Each input recommendation appears in exactly one output bucket — the one
 * keyed by its targetField. The union of the four buckets equals the input
 * array (with duplicates preserved). Order within each bucket matches input order.
 *
 * Throws if any recommendation has a targetField outside the four valid values.
 * Callers are expected to filter invalid recommendations before bucketing
 * (analysis.ts and suite-recommend.ts both do this at parse time per R5.9).
 */
export function bucketByTargetField<T extends Pick<Recommendation, "targetField">>(
  recommendations: T[],
): BucketedRecommendations<T>;
```

The function is pure and total over valid input. It is called by the Recommended Changes Panel, the per-case detail page, and the Failure Analysis View — three call sites with one tested implementation.

## Backward Compatibility

| Scenario | Read behavior |
|---|---|
| Pre-feature `SNAPSHOT` (no `examples` per tool) | Read helper returns `examples: []` for every tool. No exception. (R3.3) |
| Pre-feature persisted `ANALYSIS#CASE#*` records | None exist (the partition is new). The persisted-read shortcut sees zero records, falls through to a fresh Bedrock call. |
| Persisted analysis written against a pre-feature snapshot | The record has no `tool_examples` recommendations because the prompt did not see examples. The Recommendation Engine returns it unchanged and renders a banner "Re-analyze to incorporate the now-captured examples" (R12.6). The "Re-analyze" action POSTs `force: true`, regenerates against the up-to-date snapshot. |
| Failed case has no per-case analysis (mid-rollout race) | The per-suite Lambda omits that case's "Per-Case Failures" entry from the prompt and proceeds. The case is still listed in "Failed case IDs" so the model can reference it in `liftedCaseIds`. |
| Partial per-case failures (some cases analyzed, some Bedrock-failed) | The per-case Lambda persists the successful records and returns a response that includes the failed case IDs in a separate `partialFailures` field. The Recommended Changes Panel shows the successes plus an inline notice listing the failed IDs (R12.5). |
| `tool.examples` empty for some tools | The Examples block renders `(none)` for those tools. The analysis proceeds for the other three Tool_Surface values for that tool (R12.4). |
| Snapshot examples malformed (field present but not an array) | Both Lambdas return HTTP 500 with `error: "snapshot_examples_malformed"` and the offending tool name (R5.8). The frontend renders a clear error rather than silently degrading. |

## Frontend Component Design

### `RecommendedChangesPanel` (new component)

File: `src/frontend/src/components/RecommendedChangesPanel.tsx`. Used by `RunDashboard.tsx`. Render order, top to bottom:

1. **Title row**: `Recommended changes` header with optional `generatedAt` timestamp and "Re-analyze" button (POST `force: true` to both endpoints, refetch on success).
2. **Per-suite section**: Up to N cards, one per `PerSuiteRecommendation`. Each card shows (a) a circled priority indicator with the recommendation's 1-based array position, (b) a `Tool_Surface` badge, (c) the diff view (current text in red, suggested in green — same renderer used by `FailureAnalysis.tsx`), (d) the `predictedImpact.rationale` text, (e) a clickable list of `liftedCaseIds` rendered as `Button variant="inline-link"` items navigating to `/runs/{runId}/cases/{caseId}` (R10.6).
3. **Per-case section**: Recommendations from the persisted per-case records, grouped by `rootCauseCategory` and bucketed by Tool_Surface within each group. Same diff renderer as above. Each group's header shows the case IDs participating and links to the case detail page.
4. **Footer**: "View full failure analysis →" deep-link to `/runs/{runId}/results` (R10.7).

Three explicit empty states (R10.2, R10.3, R10.5):

- **No failures**: Single green Alert "No recommended changes — all cases passed". No engine call. No "Re-analyze" call when the user clicks "Re-analyze" — instead an inline message reads "No analysis needed — all cases passed".
- **No recommendations identified**: Single info Alert "No actionable recommendations were identified for the failed cases in this run", with a "Re-analyze" action that POSTs `force: true`.
- **Run still running**: Single placeholder card "Recommendations will appear when the run completes". No engine call (R10.8).

Plus error states from R12.2 — one for per-suite failure, one for per-case failure, both with a "Retry" button that re-triggers the call without forcing a full page reload.

### `FailureAnalysis.tsx` updates

- Replace auto-mount `runAnalysis()` with `fetchPersistedAnalysis()` that POSTs without `force` and consumes the persisted record. The Lambda's persisted-read shortcut returns it unchanged.
- "Re-analyze" button POSTs `{ force: true }`. Update local state on success.
- Render switches from the legacy `individualAnalyses`/`groupedAnalyses` shape to the new flat `caseAnalyses[]`. Group-by-root-cause runs client-side using `groupFailuresByRootCause` (existing function — moved to `src/shared/utils/failure-grouping.ts` so it can be shared with the panel).

### `AgentBrowser.tsx` per-tool examples block

Within each tool `Container`, after the Instruction `Box`:

```jsx
<div>
  <Box variant="awsui-key-label">
    <SpaceBetween direction="horizontal" size="xs">
      Examples
      <Badge color={tool.examples.length === 0 ? 'grey' : 'blue'}>
        {tool.examples.length}
      </Badge>
    </SpaceBetween>
  </Box>
  {tool.examples.length === 0 ? (
    <Box color="text-status-inactive">No examples configured</Box>
  ) : (
    <ol style={{ paddingLeft: '20px', margin: 0 }}>
      {tool.examples.map((example, idx) => (
        <li key={idx} style={{ marginBottom: '4px' }}>
          <pre style={{
            margin: 0,
            fontFamily: 'monospace',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
            backgroundColor: '#f4f4f4',
            padding: '6px 8px',
            borderRadius: '4px',
          }}>{example}</pre>
        </li>
      ))}
    </ol>
  )}
</div>
```

Count badge renders even at zero (R2.4). Empty state reads literally "No examples configured" (R2.2). Whitespace and newlines preserved via `whiteSpace: 'pre-wrap'` (R2.3).

### `Comparison.tsx` rendering of `tool-examples-changed`

Adds one row type to the configuration-diff table. Layout:

```
┌─────────────────────────────────────────────────────────┐
│ Tool: getAccountBalance                                 │
│ ┌────────────────────────┬─────────────────────────────┐│
│ │ Prior (3 examples)     │ New (4 examples)            ││
│ ├────────────────────────┼─────────────────────────────┤│
│ │ 1. "What's my balance?"│ 1. "What's my balance?"     ││
│ │ 2. "How much do I have"│ 2. "How much in checking?"  ││ ← reordered (red border)
│ │ 3. "Tell me my total"  │ 3. "How much do I have"     ││ ← reordered (red border)
│ │                        │ 4. "Tell me my account"     ││ ← added (green bg)
│ └────────────────────────┴─────────────────────────────┘│
└─────────────────────────────────────────────────────────┘
```

Per-item highlighting:

- Item present in `new` but not `prior` → green background.
- Item present in `prior` but not `new` → red background, struck through.
- Items present in both with different positions → both rendered with a yellow "order changed" indicator.

The diff is computed client-side from the `priorExamples` and `newExamples` arrays carried on the change record — no extra API call.


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

The feature is suitable for property-based testing because the surface area added by this design is dominated by pure functions: the bucketing utility, the diff utility, the priority comparator, and the snapshot read/write helpers are all input-output computations whose universal behavior matters. The six properties below are the canonical predicates from R15 and are sufficient to cover the design's invariants without redundancy. Backend handler integration paths (Bedrock invocation count, persistence-on-success, retry posture) are covered by example-based unit and integration tests rather than properties because their behavior does not vary meaningfully with input shape.

### Property 1: Bucketing partitions

*For any* finite list of recommendations whose `targetField` is one of the four valid Tool_Surface values, `bucketByTargetField` returns four arrays whose concatenation contains exactly the same multiset of elements as the input array, with each input element appearing in exactly one of the four output arrays — namely the one keyed by its `targetField`.

**Validates: Requirements 15.1, 5.1**

### Property 2: No-failure empty state

*For any* run-state value where `failed === 0` and `errors === 0`, the `RecommendedChangesPanel` render function returns the empty-state element ("No recommended changes — all cases passed") AND does not call the Recommendation Engine — regardless of the values of any other run-state fields, regardless of `runStatus`, and regardless of whether the user activates "Re-analyze".

**Validates: Requirements 15.2, 10.2, 10.3, 10.8**

### Property 3: Monotonic priority ordering

*For any* run, *for any* `PerSuiteRecommendation[]` returned by the `POST /runs/{runId}/recommend-suite` endpoint, *for any* indices `i` and `j` such that `i < j` and both indices are within the array bounds, `recommendations[i].priority <= recommendations[j].priority`.

**Validates: Requirements 15.3, 9.1**

### Property 4: Persisted-read determinism

*For any* persisted per-suite analysis record at `PK=RUN#{runId}, SK=ANALYSIS#SUITE`, two consecutive reads of that record return `recommendations` arrays that are element-wise equal in length, in element order, and in every field of every element (including `priority`, `targetField`, `targetName`, `currentText`, `suggestedText`, `rationale`, `predictedImpact.liftedCaseIds`, and `predictedImpact.rationale`).

**Validates: Requirements 15.4, 9.3**

### Property 5: Snapshot examples round-trip

*For any* `AgentSnapshot` value whose `tools[].examples` arrays contain arbitrary strings (including empty strings, strings with embedded whitespace, strings with embedded newlines, and strings with embedded quote characters), persisting the snapshot to DynamoDB at `PK=RUN#{runId}, SK=SNAPSHOT` and reading it back via the snapshot read helper produces a snapshot whose `tools[].examples` arrays are element-wise equal to the input — in length, in order, and in string content.

**Validates: Requirements 15.5, 3.4, 1.3, 1.4**

### Property 6: `diffAgentConfigs` reflexivity over examples

*For any* `AgentSnapshot` value `s`, `diffAgentConfigs(s, s)` returns a result whose `hasChanges` is `false` and whose `changes` array is empty — including when `s.tools[].examples` arrays are non-empty, contain strings with embedded whitespace, or are intentionally identical between the two operands.

**Validates: Requirements 15.6, 4.2**

## Error Handling

The feature inherits the platform's existing error handling posture and adds three new error states unique to this feature:

| Error | HTTP | Body | Handler |
|---|---|---|---|
| Snapshot missing for runId | 404 | `{ error: "snapshot_missing", message }` | Both Lambdas (R12.3) |
| Snapshot examples malformed (field present but not an array) | 500 | `{ error: "snapshot_examples_malformed", toolName, message }` | Both Lambdas (R5.8) |
| Bedrock terminal failure after retries | 503 | `{ error, message, retryable: true, retryAfterSeconds }` | Both Lambdas (R12.2) |

The retry posture for Bedrock throttle (R12.1) reuses the existing `src/shared/utils/backoff.ts` utility with parameters `(baseMs: 1000, capMs: 10000, maxRetries: 2)`. The same parameters are used by `comparison-summary.ts` today; no new code path is introduced.

Persistence failures (DDB write fails after the Bedrock call succeeds) log the failure but return the analysis content to the caller (R6.6). The next call sees no persisted record and re-invokes Bedrock — the failure is self-healing, the user is not blocked.

Partial per-case failures inside `analysis.handler` are reported to the client via a new optional `partialFailures: string[]` field on the response. The Recommended Changes Panel renders the successful analyses plus an inline notice listing the failed case IDs (R12.5).

Pre-feature persisted analyses (records written before this feature shipped that lack `tool_examples` recommendations) are returned unchanged and rendered with a banner advising "Re-analyze to incorporate the now-captured examples" (R12.6, R6.4). The banner's "Re-analyze" action POSTs `force: true` and regenerates against the current snapshot.

## Failure Modes

| Failure | Detection | Recovery |
|---|---|---|
| Bedrock throttle (`ThrottlingException`) | Lambda catches, identifies by `error.name` | Exponential backoff (1s base, 10s cap, 2 retries from R12.1). On terminal failure return 503 with `retryable: true`. |
| Bedrock terminal error (non-throttle, non-recoverable) | Lambda catches | Return 500 with `retryable: false`. UI shows error state with no auto-retry. |
| Bedrock returns malformed JSON | Parser returns `null` | Per-case path: synthesize a fallback "analysis_unavailable" record (existing behavior). Per-suite path: return 200 with empty `recommendations` array — same surface as "model judged no recommendations needed", and the empty state UI is identical. |
| DDB persistence failure (per-case) | Lambda catches DDB error | Log failure, return 200 with the analysis content (R6.6). Self-heals on next call. |
| DDB persistence failure (per-suite) | Lambda catches DDB error | Log failure, return 200 with the recommendations. Self-heals on next call. |
| Snapshot missing | DDB Get returns no Item | Return 404 with `error: "snapshot_missing"`. UI renders the snapshot-missing empty state. |
| Snapshot examples malformed | Read helper detects non-array `examples` field | Return 500 with `error: "snapshot_examples_malformed"` and the offending tool name (R5.8). |
| Pre-feature persisted analysis | Read helper detects absence of `tool_examples` recommendations or schema markers | Return record unchanged. UI renders the "Re-analyze" banner (R12.6). |
| Partial per-case failures | Per-case Lambda tracks per-case Bedrock outcomes | Persist successes, return them plus `partialFailures: string[]`. UI renders successes plus an inline notice (R12.5). |
| Tool with no examples | Read helper / prompt builder detects `examples.length === 0` | Render `Examples: (none)` in the prompt. Analysis proceeds for the other three Tool_Surface values for that tool (R12.4). |
| `liftedCaseIds` references unknown case IDs | Lambda validates against the failed-case-IDs list | Drop the offending recommendation from the array before persistence. Log the dropped recommendation. |
| Model returns invalid `targetField` | Parser/filter detects | Drop the recommendation before persistence (R5.9). Log the dropped recommendation. |

## Testing Strategy

The feature uses both example-based unit/integration tests and the six property-based tests defined in the Correctness Properties section.

**Property-Based Tests** (using `fast-check`, the platform's existing PBT library):

| Property | Module Under Test | Generator Strategy |
|---|---|---|
| 1: Bucketing partitions | `src/shared/utils/recommendation-bucketing.ts` | Random arrays of recommendations with `targetField` drawn uniformly from the four Tool_Surface values; sizes 0..50. |
| 2: No-failure empty state | `RecommendedChangesPanel` (component test with mocked engine) | Random run-state objects with `failed === 0 && errors === 0`, varying everything else. Assert engine mock has 0 calls AND the rendered output contains the empty-state text. |
| 3: Monotonic priority | `src/backend/handlers/suite-recommend.ts` (sort step) | Random `PerSuiteRecommendation[]` with arbitrary `priority` integers. Run through the sort-and-renumber step. Assert priorities are non-decreasing across indices. |
| 4: Persisted-read determinism | DDB read helper for `ANALYSIS#SUITE` (against DynamoDB Local) | Random `PerSuiteRecommendation[]` written and re-read twice. Assert element-wise equality. |
| 5: Snapshot examples round-trip | DDB write/read for `SNAPSHOT` (against DynamoDB Local) | Random `AgentSnapshot` with `tools[].examples` containing strings drawn from a Unicode-aware string generator including whitespace, newlines, quotes. Assert element-wise equality after round-trip. |
| 6: `diffAgentConfigs` reflexivity over examples | `src/shared/utils/config-diff.ts` | Random `AgentSnapshot` with non-trivial `tools[].examples`. Assert `diffAgentConfigs(s, s).hasChanges === false`. |

Each property test runs minimum 100 iterations (consistent with the platform's existing convention). Each test is tagged with the comment `Feature: actionable-recommendations, Property {N}: {title}` per the platform's tagging convention.

**Example-Based Unit Tests** (Vitest):

- Discovery mapping: malformed `examples` (non-array), null, undefined, empty array all map to `[]`.
- Snapshot persistence: pre-feature record with no `examples` field reads as `tools[].examples = []` for every tool (R3.3).
- Analysis Lambda: pre-feature persisted analysis record returned unchanged (R6.4); persistence failure returns 200 with content (R6.6); `force: true` overrides the persisted-read shortcut (R6.3).
- Suite-recommend Lambda: snapshot missing → 404 (R12.3); snapshot examples malformed → 500 (R5.8); Bedrock throttle terminal → 503 with `retryable: true` (R12.2); empty model output → 200 with empty array (R8.1).
- Per-suite prompt: contains the four Tool_Surface enum, contains the failed case IDs list, contains the Examples blocks, instructs to consolidate, instructs to predict impact (R8.2, R8.3).
- Per-case prompt: `Examples:` block placed immediately after `Instruction:` (R14.1); empty examples renders `Examples: (none)` literally (R14.2); prompt instructions include the tool_examples three-operations clause (R14.3).
- `liftedCaseIds` filter: drop entries with unknown IDs; deduplicate within a single recommendation (R8.6).
- Recommendation filter: drop entries with invalid `targetField`; reject no-op recommendations (both texts empty); reject empty `targetName` (R5.9, R13.3).

**Component Tests** (Vitest + React Testing Library):

- `RecommendedChangesPanel`: three empty states render correctly (R10.2, R10.5, R10.8); per-suite cards precede per-case groups (R10.4); priority indicator, Tool_Surface badge, diff view, predicted-impact rationale, clickable liftedCaseIds (R10.6); footer "View full failure analysis" link (R10.7); error states with retry button (R12.2, R12.5); banner for pre-feature persisted analysis (R12.6).
- `AgentBrowser`: per-tool Examples section renders below Instruction; count badge present at zero and non-zero; "No examples configured" empty state (R2.1, R2.2, R2.4); monospace block preserves whitespace (R2.3).
- `Comparison`: `tool-examples-changed` row renders prior/new side-by-side; added items green; removed items red; reordered items annotated (R4.3).
- `FailureAnalysis`: reads from persisted record on mount (no Bedrock call when persisted); "Re-analyze" button POSTs `force: true`; case detail page link present.

**Integration Tests** (against deployed test stack):

- End-to-end per-case path: trigger run → wait for completion → POST `/analyze` → verify persistence → POST again without `force` → verify no Bedrock call (mock counter on a test deployment) → POST with `force: true` → verify Bedrock re-invocation and overwrite.
- End-to-end per-suite path: same as above against `/recommend-suite`.
- Snapshot round-trip: trigger run with an agent that has tool examples → verify `examples` flow through the snapshot → analysis prompt contains them → recommendations may target `tool_examples`.

## Requirement → Design Section Traceability

| Requirement | Design Section(s) |
|---|---|
| R1 (Capture Tool Examples Through Discovery) | Components: Backend: Discovery Lambda extension; Data Models: Tool Definition Extension |
| R2 (Display Tool Examples in the Agent Browser) | Components: Frontend: AgentBrowser per-tool examples block |
| R3 (Capture Tool Examples in the Agent Snapshot) | Components: Backend: Run Trigger Lambda snapshotAgent extension; Data Models: Persisted Record Schemas (extended SNAPSHOT); Backward Compatibility |
| R4 (Extend Configuration Diff to Detect Example Changes) | Reuse Map (config-diff.ts row); Components: Frontend: Comparison.tsx tool-examples-changed rendering |
| R5 (Per-Case Recommendation Surface Bucketing) | Components: Backend: Analysis Lambda extension; Data Models: Shared Recommendation Type; Per-Case Prompt Extension |
| R6 (Per-Case Recommendation Persistence) | Components: Backend: Analysis Lambda extension; Data Models: Persisted Record Schemas (ANALYSIS#CASE) |
| R7 (Per-Case Recommendation Visibility) | Components: Frontend: FailureAnalysis.tsx updates; Frontend Component Design (case-detail page projection); Bucketing Helper Signature |
| R8 (Per-Suite Recommendation Generation) | Components: Backend: Suite Recommend Lambda; Data Models: Persisted Record Schemas (ANALYSIS#SUITE); Per-Suite Prompt Template |
| R9 (Per-Suite Recommendation Ordering and Determinism) | Server-Side Ordering Enforcement; Correctness Properties 3 and 4 |
| R10 (Recommended Changes Panel on the Run Dashboard) | Components: Frontend: RecommendedChangesPanel; Frontend Component Design |
| R11 (Recommendation Source-of-Truth Unification) | Components: Frontend: FailureAnalysis.tsx updates; Frontend Component Design (RecommendedChangesPanel section) |
| R12 (Graceful Degradation) | Error Handling; Failure Modes |
| R13 (Recommendation Payload Field Constraints) | Data Models: Shared Recommendation Type |
| R14 (Failure Analysis Prompt Includes Examples) | Per-Case Prompt Extension |
| R15 (Property-Testable Behaviors) | Correctness Properties 1–6; Testing Strategy |
