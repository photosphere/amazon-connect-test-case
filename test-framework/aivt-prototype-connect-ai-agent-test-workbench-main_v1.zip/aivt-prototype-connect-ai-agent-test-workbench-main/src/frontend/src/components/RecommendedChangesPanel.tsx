/**
 * RecommendedChangesPanel — the new actionable-recommendations surface that
 * lands on the Run Dashboard above the test case results table.
 *
 * Reads only persisted records (R11.1, R11.2):
 *   - per-case analyses via POST /runs/{runId}/analyze (without `force` →
 *     persisted-read shortcut returns the records without invoking Bedrock)
 *   - per-suite consolidated recommendations via
 *     POST /runs/{runId}/recommend-suite (same shortcut posture)
 *   - the agent snapshot via GET /runs/{runId}/snapshot, used to detect
 *     pre-feature snapshots (no `examples` per tool) so the
 *     "Re-analyze to incorporate the now-captured examples" banner can
 *     surface (R12.6)
 *
 * Render decisions follow the design's render-decision sequence verbatim:
 *
 *   1. `runStatus === RUNNING` → placeholder "Recommendations will appear
 *      when the run completes" with NO engine call (R10.8).
 *   2. `failedCount === 0 && errorCount === 0` → green success Alert
 *      "No recommended changes — all cases passed" with NO engine call;
 *      Re-analyze on this state surfaces the inline message
 *      "No analysis needed — all cases passed" without an engine call
 *      (R10.2, R10.3).
 *   3. Otherwise, on mount, POST without `force` to both endpoints in
 *      parallel; render per-suite first, then per-case grouped by
 *      root-cause category and bucketed by Tool_Surface (R10.4, R10.6,
 *      R10.9, R11.1, R11.2).
 *
 * Re-analyze in the panel header POSTs `{ force: true }` to both endpoints
 * concurrently and refreshes local state on success (R11.3). Per-suite and
 * per-case error states render independently with their own Retry buttons
 * (R12.2). When the analyze response carries `partialFailures`, render the
 * inline notice listing the affected case IDs (R12.5).
 *
 * The footer always carries a "View full failure analysis" link to
 * `/runs/{runId}/results` so that page remains the canonical full-detail
 * view (R10.7).
 *
 * @module components/RecommendedChangesPanel
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@cloudscape-design/components/header';
import Container from '@cloudscape-design/components/container';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import Alert from '@cloudscape-design/components/alert';
import Spinner from '@cloudscape-design/components/spinner';
import Badge from '@cloudscape-design/components/badge';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import Link from '@cloudscape-design/components/link';
import { apiClient, ApiClientError } from '../api';
import type {
  AgentSnapshot,
  PerSuiteRecommendation,
  Recommendation,
  ToolSurface,
} from '../../../shared/types';
import { RunStatus } from '../../../shared/enums';
import {
  bucketByTargetField,
  partitionByTargetType,
} from '../../../shared/utils/recommendation-bucketing';
import {
  groupFailuresByRootCause,
  type FailureCaseAnalysis,
} from '../../../shared/utils/failure-grouping';

// ---------------------------------------------------------------------------
// Public props
// ---------------------------------------------------------------------------

/**
 * Props for {@link RecommendedChangesPanel}. The Run Dashboard wires every
 * field from values it already holds in state (run record, progress
 * counts) so the panel is fully prop-driven and does not prop-drill.
 */
export interface RecommendedChangesPanelProps {
  runId: string;
  suiteId?: string;
  runStatus: RunStatus;
  failedCount: number;
  errorCount: number;
}

// ---------------------------------------------------------------------------
// Wire-format response types (mirror backend handler shapes)
// ---------------------------------------------------------------------------

/**
 * Per-case analysis as persisted under
 * `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` and returned in the
 * `caseAnalyses[]` array of {@link AnalyzeResponse}. Mirrors
 * `PerCaseAnalysis` exported by `src/backend/handlers/analysis.ts`.
 */
interface PerCaseAnalysis {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;
  recommendations: Recommendation[];
  generatedAt: string;
  modelId: string;
}

/** Response body for `POST /runs/{runId}/analyze`. */
interface AnalyzeResponse {
  caseAnalyses: PerCaseAnalysis[];
  generatedAt: string;
  modelId: string;
  /** Case IDs whose Bedrock analysis succeeded but DDB persistence failed (R6.6). */
  partialFailures?: string[];
}

/** Response body for `POST /runs/{runId}/recommend-suite`. */
interface SuiteRecommendResponse {
  recommendations: PerSuiteRecommendation[];
  generatedAt: string;
  modelId: string;
}

/** Response body for `GET /runs/{runId}/snapshot`. */
interface SnapshotResponse {
  snapshot: AgentSnapshot;
}

// ---------------------------------------------------------------------------
// Display helpers
// ---------------------------------------------------------------------------

/**
 * Human-readable label for a {@link ToolSurface} value. Mirrors the
 * label used by `FailureAnalysis.tsx` so the bucket headers read the
 * same way across both surfaces.
 */
function targetFieldLabel(field: ToolSurface | string): string {
  switch (field) {
    case 'tool_description':
      return 'Tool Description';
    case 'tool_instruction':
      return 'Tool Instruction';
    case 'tool_examples':
      return 'Tool Examples';
    case 'system_prompt':
      return 'System Prompt';
    case 'test_case':
      return 'Test Case';
    default:
      return String(field);
  }
}

/**
 * Human-readable label for a root-cause category. The backend emits
 * snake_case category names; the GUI renders them as Title Case so they
 * read naturally next to the section header.
 */
function formatCategory(category: string): string {
  return category
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

// ---------------------------------------------------------------------------
// Recommendation type badge (R7.1, R7.2)
// ---------------------------------------------------------------------------

/**
 * Badge indicating whether a recommendation targets the test case (blue
 * "Fix test") or the agent configuration (orange "Fix agent").
 *
 * - `test_case` → blue "Fix test" badge (R7.1)
 * - All other targetField values → orange "Fix agent" badge (R7.2)
 */
export function RecommendationBadge({
  targetField,
}: {
  targetField: string;
}): JSX.Element {
  if (targetField === 'test_case') {
    return <Badge color="blue">Fix test</Badge>;
  }
  return <Badge color="severity-medium">Fix agent</Badge>;
}

// ---------------------------------------------------------------------------
// Diff view — mirrors the existing `FailureAnalysis.tsx` DiffView styling
// ---------------------------------------------------------------------------

/**
 * Two-row diff with current text on a red-bordered light-red background
 * and suggested text on a green-bordered light-green background. Styling
 * matches the existing `DiffView` in `FailureAnalysis.tsx` byte-for-byte
 * (`#fdf0f0` / `#d91515` for current, `#f2fcf3` / `#037f0c` for
 * suggested) so the two surfaces look like the same component to a user
 * pivoting between them.
 */
function DiffView({
  recommendation,
}: {
  recommendation: Recommendation;
}): JSX.Element {
  return (
    <SpaceBetween size="xs">
      <Box variant="small">
        <strong>{targetFieldLabel(recommendation.targetField)}</strong>
        {recommendation.targetName !== 'system_prompt' && (
          <span style={{ marginLeft: '8px', color: '#5f6b7a' }}>
            ({recommendation.targetName})
          </span>
        )}
      </Box>
      {/* Current text — red-bordered tinted block. */}
      <div
        style={{
          backgroundColor: '#fdf0f0',
          border: '1px solid #d91515',
          borderRadius: '4px',
          padding: '8px 12px',
          fontFamily: 'monospace',
          fontSize: '13px',
          whiteSpace: 'pre-wrap',
          wordBreak: 'break-word',
        }}
      >
        <Box variant="small" color="text-status-error">
          <strong>− Current</strong>
        </Box>
        {recommendation.currentText || (
          <Box variant="small" color="text-status-inactive">
            (empty)
          </Box>
        )}
      </div>
      {/* Suggested text — green-bordered tinted block. */}
      <div
        style={{
          backgroundColor: '#f2fcf3',
          border: '1px solid #037f0c',
          borderRadius: '4px',
          padding: '8px 12px',
          fontFamily: 'monospace',
          fontSize: '13px',
          whiteSpace: 'pre-wrap',
          wordBreak: 'break-word',
        }}
      >
        <Box variant="small" color="text-status-success">
          <strong>+ Suggested</strong>
        </Box>
        {recommendation.suggestedText || (
          <Box variant="small" color="text-status-inactive">
            (empty)
          </Box>
        )}
      </div>
      {recommendation.rationale && (
        <Box variant="small" color="text-body-secondary">
          <em>Rationale: {recommendation.rationale}</em>
        </Box>
      )}
    </SpaceBetween>
  );
}

/**
 * Circled 1-based priority indicator for a per-suite recommendation
 * (R10.6.a). Renders a 28px circle with the index inside, matching the
 * visual weight of a Cloudscape Badge but with a fixed circular shape
 * the spec calls out explicitly.
 */
function PriorityCircle({ index }: { index: number }): JSX.Element {
  return (
    <span
      aria-label={`Priority ${index}`}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: '28px',
        height: '28px',
        borderRadius: '50%',
        backgroundColor: '#0972d3',
        color: '#ffffff',
        fontWeight: 700,
        fontSize: '13px',
        flexShrink: 0,
      }}
    >
      {index}
    </span>
  );
}

// ---------------------------------------------------------------------------
// Per-suite recommendation card
// ---------------------------------------------------------------------------

/**
 * A single per-suite recommendation card. Renders (a) the circled
 * 1-based array-index priority indicator, (b) the Tool_Surface badge,
 * (c) the diff view (current vs suggested), (d) the predictedImpact
 * rationale, and (e) the lifted case IDs as inline-link buttons that
 * navigate to the per-case detail page (R10.6).
 */
function PerSuiteRecommendationCard({
  recommendation,
  index,
  runId,
  suiteId,
}: {
  recommendation: PerSuiteRecommendation;
  index: number;
  runId: string;
  suiteId?: string;
}): JSX.Element {
  const navigate = useNavigate();
  const caseHref = (caseId: string): string => {
    const qs = suiteId ? `?suiteId=${encodeURIComponent(suiteId)}` : '';
    return `/runs/${runId}/cases/${caseId}${qs}`;
  };
  return (
    <Container
      header={
        <Header
          variant="h3"
          actions={
            <SpaceBetween direction="horizontal" size="xs">
              <RecommendationBadge targetField={recommendation.targetField} />
              <Badge color="blue">
                {targetFieldLabel(recommendation.targetField)}
              </Badge>
            </SpaceBetween>
          }
        >
          <SpaceBetween direction="horizontal" size="xs" alignItems="center">
            <PriorityCircle index={index} />
            <span>
              {recommendation.targetName === 'system_prompt'
                ? 'System Prompt'
                : recommendation.targetName}
            </span>
          </SpaceBetween>
        </Header>
      }
    >
      <SpaceBetween size="m">
        <DiffView recommendation={recommendation} />

        {recommendation.predictedImpact.rationale && (
          <div>
            <Box variant="awsui-key-label">Predicted Impact</Box>
            <Box variant="p">{recommendation.predictedImpact.rationale}</Box>
          </div>
        )}

        {recommendation.predictedImpact.liftedCaseIds.length > 0 && (
          <div>
            <Box variant="awsui-key-label">
              Cases expected to lift (
              {recommendation.predictedImpact.liftedCaseIds.length})
            </Box>
            <SpaceBetween direction="horizontal" size="xs">
              {recommendation.predictedImpact.liftedCaseIds.map((caseId) => (
                <Button
                  key={caseId}
                  variant="inline-link"
                  onClick={() => navigate(caseHref(caseId))}
                  ariaLabel={`Open detail for case ${caseId}`}
                >
                  {caseId}
                </Button>
              ))}
            </SpaceBetween>
          </div>
        )}
      </SpaceBetween>
    </Container>
  );
}

// ---------------------------------------------------------------------------
// Per-case bucketed-by-Tool_Surface render
// ---------------------------------------------------------------------------

/**
 * Render the recommendations from one per-case-grouping cohort
 * (`individual` or `grouped`) as a list of Tool_Surface buckets.
 *
 * Produces a ColumnLayout-equivalent of small cards per bucket so the
 * user can scan "what would I edit on the system prompt across these
 * failures" without re-reading every recommendation. The bucketing
 * helper is the shared pure util from
 * `src/shared/utils/recommendation-bucketing.ts` (task 4).
 */
function ToolSurfaceBuckets({
  recommendations,
}: {
  recommendations: Recommendation[];
}): JSX.Element {
  // Partition into agent vs test case first; bucketByTargetField only
  // handles the four ToolSurface values and throws on "test_case".
  const { agent, testCase } = partitionByTargetType(recommendations);

  let buckets;
  try {
    buckets = bucketByTargetField(agent);
  } catch (err) {
    return (
      <Alert
        type="warning"
        statusIconAriaLabel="Warning"
        header="Malformed recommendations"
      >
        {err instanceof Error ? err.message : 'Unknown bucketing error.'}
      </Alert>
    );
  }
  const surfaces: ToolSurface[] = [
    'system_prompt',
    'tool_description',
    'tool_instruction',
    'tool_examples',
  ];
  const nonEmpty = surfaces.filter((s) => buckets[s].length > 0);

  const hasAgentRecs = nonEmpty.length > 0;
  const hasTestCaseRecs = testCase.length > 0;

  if (!hasAgentRecs && !hasTestCaseRecs) {
    return (
      <Box variant="small" color="text-status-inactive">
        No recommendations.
      </Box>
    );
  }

  return (
    <SpaceBetween size="m">
      {/* Agent recommendations (orange tint section) */}
      {hasAgentRecs && (
        <div
          style={
            hasTestCaseRecs
              ? { backgroundColor: '#fef8f0', borderRadius: '8px', padding: '12px' }
              : undefined
          }
        >
          <SpaceBetween size="m">
            {hasTestCaseRecs && (
              <Box variant="small" fontWeight="bold">
                <RecommendationBadge targetField="tool_description" /> Agent
                recommendations
              </Box>
            )}
            {nonEmpty.map((surface) => (
              <ExpandableSection
                key={surface}
                variant="footer"
                defaultExpanded
                headerText={`${targetFieldLabel(surface)} (${buckets[surface].length})`}
              >
                <SpaceBetween size="m">
                  {buckets[surface].map((rec, idx) => (
                    <DiffView key={`${surface}-${idx}`} recommendation={rec} />
                  ))}
                </SpaceBetween>
              </ExpandableSection>
            ))}
          </SpaceBetween>
        </div>
      )}

      {/* Test case recommendations (blue tint section) */}
      {hasTestCaseRecs && (
        <div
          style={
            hasAgentRecs
              ? { backgroundColor: '#f0f5ff', borderRadius: '8px', padding: '12px' }
              : undefined
          }
        >
          <SpaceBetween size="m">
            {hasAgentRecs && (
              <Box variant="small" fontWeight="bold">
                <RecommendationBadge targetField="test_case" /> Test case
                recommendations
              </Box>
            )}
            {testCase.map((rec, idx) => (
              <DiffView key={`testcase-${idx}`} recommendation={rec} />
            ))}
          </SpaceBetween>
        </div>
      )}
    </SpaceBetween>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

/** True iff every tool in the snapshot has no `examples` field on its
 * persisted record (R12.6 cue — pre-feature snapshots). After task 2.2
 * ships, all newly-captured snapshots include the field (possibly empty
 * arrays); only records persisted before this feature shipped lack it. */
function snapshotPredatesExamples(snapshot: AgentSnapshot | null): boolean {
  if (!snapshot) return false;
  const tools = snapshot.tools ?? [];
  if (tools.length === 0) return false;
  // The runtime snapshot read normalizes missing/null to []. We can only
  // detect "predates" by checking if EVERY tool has an empty examples
  // array. False positives are possible (an agent might genuinely have
  // no examples on any tool) but the banner action is non-destructive
  // (it offers a Re-analyze) so a false positive is recoverable.
  return tools.every(
    (t) => !Array.isArray(t.examples) || t.examples.length === 0,
  );
}

/**
 * The Recommended_Changes_Panel. Mounts on the Run Dashboard above the
 * results table and renders the persisted recommendations for the run.
 *
 * The panel never computes recommendations independently — both backing
 * Lambdas are persistence-aware and return cached records on the
 * non-`force` path (R11.1, R11.2).
 */
export function RecommendedChangesPanel({
  runId,
  suiteId,
  runStatus,
  failedCount,
  errorCount,
}: RecommendedChangesPanelProps): JSX.Element {
  // Per-case state.
  const [analyzeData, setAnalyzeData] = useState<AnalyzeResponse | null>(null);
  const [analyzeLoading, setAnalyzeLoading] = useState(false);
  const [analyzeError, setAnalyzeError] = useState<string | null>(null);

  // Per-suite state.
  const [suiteData, setSuiteData] = useState<SuiteRecommendResponse | null>(
    null,
  );
  const [suiteLoading, setSuiteLoading] = useState(false);
  const [suiteError, setSuiteError] = useState<string | null>(null);

  // Snapshot (read for the R12.6 banner cue only).
  const [snapshot, setSnapshot] = useState<AgentSnapshot | null>(null);

  // "Re-analyze" inline message for the green empty state (R10.3).
  const [reanalyzeNoOpMessage, setReanalyzeNoOpMessage] = useState(false);

  // Mount-time fetch is gated behind the runStatus/empty-state checks so
  // the panel never invokes the engine unless we're outside the explicit
  // empty states.
  const isRunning = runStatus === RunStatus.RUNNING;
  const isAllPassed = failedCount === 0 && errorCount === 0;
  const shouldFetch = !isRunning && !isAllPassed;

  // Guard against re-fetch on every parent re-render. The Run Dashboard
  // polls progress every 3s; we want exactly one mount-time fetch per
  // (runId, shouldFetch) tuple — not one per progress refresh.
  const fetchedKeyRef = useRef<string | null>(null);

  // ---------------------------------------------------------------------
  // Fetch helpers
  // ---------------------------------------------------------------------

  /**
   * Fetch the per-case analysis. `force` triggers full Bedrock
   * regeneration; without `force` the Lambda returns persisted records
   * if the count matches the failed-case count (R6.2, R10.9).
   */
  const fetchAnalyze = useCallback(
    async (force: boolean): Promise<void> => {
      setAnalyzeLoading(true);
      setAnalyzeError(null);
      try {
        const body: Record<string, unknown> = {};
        if (suiteId) body.suiteId = suiteId;
        if (force) body.force = true;
        const response = await apiClient.post<AnalyzeResponse>(
          `/runs/${runId}/analyze`,
          body,
        );
        setAnalyzeData(response);
      } catch (err) {
        if (err instanceof ApiClientError) {
          setAnalyzeError(err.message);
        } else {
          setAnalyzeError('Failed to load per-case recommendations.');
        }
      } finally {
        setAnalyzeLoading(false);
      }
    },
    [runId, suiteId],
  );

  /**
   * Fetch the per-suite recommendations. `force` triggers full Bedrock
   * regeneration; without `force` the Lambda returns the persisted
   * record if present (R8.8, R9.3).
   */
  const fetchSuite = useCallback(
    async (force: boolean): Promise<void> => {
      setSuiteLoading(true);
      setSuiteError(null);
      try {
        const body: Record<string, unknown> = {};
        if (force) body.force = true;
        const response = await apiClient.post<SuiteRecommendResponse>(
          `/runs/${runId}/recommend-suite`,
          body,
        );
        setSuiteData(response);
      } catch (err) {
        if (err instanceof ApiClientError) {
          setSuiteError(err.message);
        } else {
          setSuiteError('Failed to load consolidated recommendations.');
        }
      } finally {
        setSuiteLoading(false);
      }
    },
    [runId],
  );

  /**
   * Fetch the agent snapshot used to detect the pre-feature
   * "no examples per tool" condition (R12.6). The snapshot is GET-only
   * and cached in component state; failures are silent (the banner
   * just won't surface, which is the right fallback).
   */
  const fetchSnapshot = useCallback(async (): Promise<void> => {
    try {
      const response = await apiClient.get<SnapshotResponse>(
        `/runs/${runId}/snapshot`,
      );
      setSnapshot(response.snapshot);
    } catch {
      // Silent — banner just stays hidden.
    }
  }, [runId]);

  // ---------------------------------------------------------------------
  // Mount-time fetch (gated)
  // ---------------------------------------------------------------------

  useEffect(() => {
    if (!shouldFetch) return;
    const key = `${runId}|${shouldFetch}`;
    if (fetchedKeyRef.current === key) return;
    fetchedKeyRef.current = key;
    void Promise.all([fetchAnalyze(false), fetchSuite(false), fetchSnapshot()]);
  }, [shouldFetch, runId, fetchAnalyze, fetchSuite, fetchSnapshot]);

  // ---------------------------------------------------------------------
  // Re-analyze action
  // ---------------------------------------------------------------------

  /** "Re-analyze" handler that POSTs `force: true` to both endpoints
   * concurrently and refreshes local state on success (R11.3). */
  const handleReanalyze = useCallback(async (): Promise<void> => {
    if (isAllPassed) {
      // R10.3: no engine call; surface the inline no-op message.
      setReanalyzeNoOpMessage(true);
      return;
    }
    if (isRunning) {
      // Defensive: the button isn't rendered while running, but skip
      // the engine call regardless.
      return;
    }
    await Promise.all([fetchAnalyze(true), fetchSuite(true), fetchSnapshot()]);
  }, [isAllPassed, isRunning, fetchAnalyze, fetchSuite, fetchSnapshot]);

  // ---------------------------------------------------------------------
  // Derived render data
  // ---------------------------------------------------------------------

  /** Per-case analyses grouped by root-cause category for display. */
  const grouping = useMemo(() => {
    if (!analyzeData) {
      return {
        individual: [] as FailureCaseAnalysis[],
        grouped: [] as ReturnType<typeof groupFailuresByRootCause>['grouped'],
      };
    }
    // The backend `PerCaseAnalysis` shape carries `generatedAt` /
    // `modelId` metadata that the grouping util doesn't need; pass
    // through the relevant fields by name so the type narrows.
    const inputs: FailureCaseAnalysis[] = analyzeData.caseAnalyses.map((a) => ({
      caseId: a.caseId,
      rootCauseCategory: a.rootCauseCategory,
      explanation: a.explanation,
      traceAvailable: a.traceAvailable,
      recommendations: a.recommendations,
    }));
    return groupFailuresByRootCause(inputs);
  }, [analyzeData]);

  const showExamplesBanner =
    snapshotPredatesExamples(snapshot) &&
    (analyzeData !== null || suiteData !== null);

  // ---------------------------------------------------------------------
  // Render branches
  // ---------------------------------------------------------------------

  // (1) RUNNING — placeholder, no engine call (R10.8).
  if (isRunning) {
    return (
      <Container header={<Header variant="h2">Recommended changes</Header>}>
        <Box textAlign="center" padding="l" color="text-status-inactive">
          <SpaceBetween size="s" alignItems="center">
            <Spinner />
            <Box variant="p">
              Recommendations will appear when the run completes.
            </Box>
          </SpaceBetween>
        </Box>
      </Container>
    );
  }

  // (2) failedCount === 0 && errorCount === 0 — green success Alert
  // with a Re-analyze action that surfaces the no-op inline message
  // (R10.2, R10.3). No engine call on either path.
  if (isAllPassed) {
    return (
      <Container
        header={
          <Header
            variant="h2"
            actions={
              <Button onClick={handleReanalyze} iconName="refresh">
                Re-analyze
              </Button>
            }
          >
            Recommended changes
          </Header>
        }
      >
        <SpaceBetween size="s">
          <Alert type="success" statusIconAriaLabel="Success">
            No recommended changes — all cases passed.
          </Alert>
          {reanalyzeNoOpMessage && (
            <Alert
              type="info"
              statusIconAriaLabel="Info"
              dismissible
              onDismiss={() => setReanalyzeNoOpMessage(false)}
            >
              No analysis needed — all cases passed.
            </Alert>
          )}
        </SpaceBetween>
      </Container>
    );
  }

  // (3) Otherwise: render persisted records.
  const isInitialLoading =
    analyzeLoading && suiteLoading && !analyzeData && !suiteData;

  const hasSuiteRecs =
    suiteData !== null && suiteData.recommendations.length > 0;
  const hasCaseRecs = analyzeData !== null && analyzeData.caseAnalyses.length > 0;
  const bothEmptyAndSucceeded =
    analyzeData !== null &&
    suiteData !== null &&
    !hasSuiteRecs &&
    !hasCaseRecs;

  const partialFailureIds = analyzeData?.partialFailures ?? [];

  const reanalyzeBusy = analyzeLoading || suiteLoading;

  return (
    <Container
      header={
        <Header
          variant="h2"
          description={
            failedCount + errorCount > 0
              ? `${failedCount} failed${
                  errorCount > 0 ? `, ${errorCount} error${errorCount === 1 ? '' : 's'}` : ''
                } in this run`
              : undefined
          }
          actions={
            <Button
              onClick={handleReanalyze}
              iconName="refresh"
              loading={reanalyzeBusy}
            >
              Re-analyze
            </Button>
          }
        >
          Recommended changes
        </Header>
      }
    >
      <SpaceBetween size="l">
        {/* R12.6 — banner for pre-feature snapshots. Suppressed for
            RAG-only runs where no tool-sequence recommendations exist
            (the banner only helps when examples could improve recs). */}
        {showExamplesBanner && (hasSuiteRecs || hasCaseRecs) && (
          <Alert
            type="info"
            statusIconAriaLabel="Info"
            header="Examples not captured for this run"
            action={
              <Button onClick={handleReanalyze} loading={reanalyzeBusy}>
                Re-analyze
              </Button>
            }
          >
            This run was captured before tool examples were tracked. Re-analyze
            to incorporate the now-captured examples into the recommendations.
          </Alert>
        )}

        {/* R12.5 — partial-failures notice for per-case persistence. */}
        {partialFailureIds.length > 0 && (
          <Alert type="warning" statusIconAriaLabel="Warning">
            Per-case analysis failed for cases: {partialFailureIds.join(', ')}
          </Alert>
        )}

        {/* Initial loading spinner (rendered once, while both calls
            are in-flight and we have no data yet). */}
        {isInitialLoading && (
          <Box textAlign="center" padding="l">
            <SpaceBetween size="s" alignItems="center">
              <Spinner size="large" />
              <Box variant="p">Loading recommendations…</Box>
            </SpaceBetween>
          </Box>
        )}

        {/* Per-suite section (top of panel, R10.4). */}
        <PerSuiteSection
          loading={suiteLoading && !suiteData}
          data={suiteData}
          error={suiteError}
          onRetry={() => void fetchSuite(false)}
          runId={runId}
          suiteId={suiteId}
        />

        {/* Per-case section (bottom of panel, R10.4). */}
        <PerCaseSection
          loading={analyzeLoading && !analyzeData}
          grouping={grouping}
          error={analyzeError}
          onRetry={() => void fetchAnalyze(false)}
        />

        {/* R10.5 — both succeeded but returned zero recommendations. */}
        {bothEmptyAndSucceeded && (
          <Alert
            type="info"
            statusIconAriaLabel="Info"
            action={
              <Button onClick={handleReanalyze} loading={reanalyzeBusy}>
                Re-analyze
              </Button>
            }
          >
            No actionable recommendations were identified for the failed cases
            in this run.
          </Alert>
        )}

        {/* R10.7 — footer link to the canonical Failure Analysis View. */}
        <Box textAlign="right">
          <Link href={`/runs/${runId}/results`} external={false}>
            View full failure analysis →
          </Link>
        </Box>
      </SpaceBetween>
    </Container>
  );
}

// ---------------------------------------------------------------------------
// Per-suite section (independent error / retry surface, R12.2)
// ---------------------------------------------------------------------------

function PerSuiteSection({
  loading,
  data,
  error,
  onRetry,
  runId,
  suiteId,
}: {
  loading: boolean;
  data: SuiteRecommendResponse | null;
  error: string | null;
  onRetry: () => void;
  runId: string;
  suiteId?: string;
}): JSX.Element | null {
  if (loading) {
    return (
      <Container
        header={<Header variant="h3">Top recommended changes</Header>}
      >
        <Box textAlign="center" padding="m">
          <Spinner />
        </Box>
      </Container>
    );
  }
  if (error) {
    return (
      <Alert
        type="error"
        statusIconAriaLabel="Error"
        header="Could not load consolidated recommendations"
        action={<Button onClick={onRetry}>Retry</Button>}
      >
        {error}
      </Alert>
    );
  }
  if (!data || data.recommendations.length === 0) {
    return null;
  }

  // R7.3, R7.4, R10.5: Partition recommendations by target type and render
  // in two visual sections (agent first, test case second). Only render
  // the relevant section when recommendations are single-type.
  const { agent, testCase } = partitionByTargetType(data.recommendations);
  const hasAgent = agent.length > 0;
  const hasTestCase = testCase.length > 0;

  return (
    <SpaceBetween size="m">
      <Header
        variant="h3"
        description="Highest-leverage edits across all failed cases"
      >
        Top recommended changes
      </Header>

      {/* Agent recommendations section (orange tint, rendered first, R7.3) */}
      {hasAgent && (
        <div
          style={{
            backgroundColor: '#fef8f0',
            borderRadius: '8px',
            padding: '16px',
          }}
        >
          <SpaceBetween size="m">
            {/* Only show section header when both types present (R7.4) */}
            {hasTestCase && (
              <Header variant="h3">Agent recommendations</Header>
            )}
            {agent.map((rec, idx) => (
              <PerSuiteRecommendationCard
                key={`agent-${rec.targetField}-${rec.targetName}-${idx}`}
                recommendation={rec as PerSuiteRecommendation}
                index={idx + 1}
                runId={runId}
                suiteId={suiteId}
              />
            ))}
          </SpaceBetween>
        </div>
      )}

      {/* Test case recommendations section (blue tint, rendered second, R7.3) */}
      {hasTestCase && (
        <div
          style={{
            backgroundColor: '#f0f5ff',
            borderRadius: '8px',
            padding: '16px',
          }}
        >
          <SpaceBetween size="m">
            {/* Only show section header when both types present (R7.4) */}
            {hasAgent && (
              <Header variant="h3">Test case recommendations</Header>
            )}
            {testCase.map((rec, idx) => (
              <PerSuiteRecommendationCard
                key={`testcase-${rec.targetField}-${rec.targetName}-${idx}`}
                recommendation={rec as PerSuiteRecommendation}
                index={agent.length + idx + 1}
                runId={runId}
                suiteId={suiteId}
              />
            ))}
          </SpaceBetween>
        </div>
      )}
    </SpaceBetween>
  );
}

// ---------------------------------------------------------------------------
// Per-case section (independent error / retry surface, R12.2)
// ---------------------------------------------------------------------------

function PerCaseSection({
  loading,
  grouping,
  error,
  onRetry,
}: {
  loading: boolean;
  grouping: ReturnType<typeof groupFailuresByRootCause>;
  error: string | null;
  onRetry: () => void;
}): JSX.Element | null {
  if (loading) {
    return (
      <Container header={<Header variant="h3">Per-case recommendations</Header>}>
        <Box textAlign="center" padding="m">
          <Spinner />
        </Box>
      </Container>
    );
  }
  if (error) {
    return (
      <Alert
        type="error"
        statusIconAriaLabel="Error"
        header="Could not load per-case recommendations"
        action={<Button onClick={onRetry}>Retry</Button>}
      >
        {error}
      </Alert>
    );
  }
  const totalCases =
    grouping.individual.length +
    grouping.grouped.reduce((acc, g) => acc + g.caseIds.length, 0);
  if (totalCases === 0) {
    return null;
  }
  return (
    <SpaceBetween size="m">
      <Header
        variant="h3"
        description="Grouped by root-cause category and bucketed by Tool_Surface"
      >
        Per-case recommendations
      </Header>

      {/* Grouped (multi-case) cohorts first — they consolidate edits
          across multiple cases that share a root cause. */}
      {grouping.grouped.map((group) => (
        <Container
          key={`grouped-${group.rootCauseCategory}`}
          header={
            <Header
              variant="h3"
              description={
                <Badge color="blue">
                  {formatCategory(group.rootCauseCategory)}
                </Badge>
              }
            >
              {`${group.caseIds.length} cases — shared root cause`}
            </Header>
          }
        >
          <SpaceBetween size="m">
            <div>
              <Box variant="awsui-key-label">Affected cases</Box>
              <SpaceBetween direction="horizontal" size="xs">
                {group.caseIds.map((cid) => (
                  <Box key={cid} variant="code" fontSize="body-s">
                    {cid}
                  </Box>
                ))}
              </SpaceBetween>
            </div>
            <ToolSurfaceBuckets recommendations={group.recommendations} />
          </SpaceBetween>
        </Container>
      ))}

      {/* Then individual (single-case) cohorts. */}
      {grouping.individual.map((analysis) => (
        <Container
          key={`individual-${analysis.caseId}`}
          header={
            <Header
              variant="h3"
              description={
                <Badge color="grey">
                  {formatCategory(analysis.rootCauseCategory)}
                </Badge>
              }
            >
              {analysis.caseId}
            </Header>
          }
        >
          <SpaceBetween size="m">
            <Box variant="p">{analysis.explanation}</Box>
            <ToolSurfaceBuckets recommendations={analysis.recommendations} />
          </SpaceBetween>
        </Container>
      ))}
    </SpaceBetween>
  );
}

export default RecommendedChangesPanel;
