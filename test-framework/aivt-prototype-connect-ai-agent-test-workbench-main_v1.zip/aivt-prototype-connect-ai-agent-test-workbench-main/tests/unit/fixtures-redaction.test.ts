/**
 * Fixture redaction guard — every checked-in `Span_Fixture` under
 * `tests/fixtures/spans/` AND every Golden_Prompt_Snapshot under
 * `tests/fixtures/golden-prompts/` MUST use non-production placeholder
 * values for sensitive customer data (phone numbers, SSN-last-four,
 * customer names).
 *
 * Validates: Requirement 16.5 (Span_Fixtures) and Requirement 11.5
 * (Golden_Prompt_Snapshots derived from those fixtures).
 *
 * Span_Fixtures committed to the repo are derived from real test
 * sessions (Req 16.5 / Req 11.1) and the Golden_Prompt_Snapshots
 * generated from them by `scripts/generate-golden-prompts.ts` are
 * checked in alongside (Req 11.2). If any sensitive value were present
 * in the source fixture it would also leak into the committed
 * `.txt` snapshots, so this guard scans both directories with the same
 * forbidden-pattern checks. Adding a new fixture or snapshot is
 * automatically covered: the test discovers files via the filesystem
 * rather than enumerating them by name.
 *
 * Conventions enforced (mirroring `tests/fixtures/spans/README.md` and
 * the steering doc `.kiro/steering/bedrock-judge-prompts.md`):
 *
 *   - Phone numbers must use the NANP "555-01XX" reserved-fictitious
 *     block, i.e. `+15555550100` … `+15555550199`. Any other E.164
 *     `+1XXXXXXXXXX`-shaped string in the fixture is rejected.
 *   - The `ssn_last_four` field (wherever it appears, including inside
 *     JSON-stringified tool-call arguments) must be the literal `0000`.
 *   - Each Span_Fixture must reference at least one approved placeholder
 *     customer name (e.g. `Alice Example`, `Pat Sample`), proving that
 *     the redaction substitution was actually performed in name-bearing
 *     fields. Golden_Prompt_Snapshot files are not name-checked
 *     individually — the per-snapshot files are small slices of the
 *     fixture (e.g. a single tool turn) and may legitimately not
 *     contain a customer name; the placeholder-name assertion runs at
 *     the `Span_Fixture` level only, where the source-of-truth lives.
 *
 * Failures name the offending file and the matched substring so the
 * author can see exactly what to redact.
 */

import { readdirSync, readFileSync, statSync } from "node:fs";
import * as path from "node:path";
import { describe, expect, it } from "vitest";

// Resolve the fixtures directories relative to this test file so the
// suite works under any working directory (vitest is normally invoked
// from the repo root, but `tsx`-style ad-hoc runs may not be).
const FIXTURES_DIR = path.resolve(__dirname, "../fixtures/spans");
const GOLDEN_PROMPTS_DIR = path.resolve(__dirname, "../fixtures/golden-prompts");

/**
 * The reserved NANP fictitious block: +1 (555) 555-0100 through
 * +1 (555) 555-0199. As an E.164 string, every allowed value matches
 * `^\+155555501\d{2}$` (literal prefix `+155555501` followed by exactly
 * two more digits).
 */
const RESERVED_FICTITIOUS_PHONE = /^\+155555501\d{2}$/;

/**
 * Any E.164 US-shaped phone number in the fixture text: a `+1` prefix
 * followed by exactly ten digits. The trailing `\b` anchors to a
 * non-digit boundary so an 11-digit string is not partially matched as
 * if it were a valid 10-digit number.
 */
const E164_US_PHONE_GLOBAL = /\+1\d{10}\b/g;

/**
 * Captures the value following an `ssn_last_four` key. The value may be
 * surrounded by either plain JSON quoting (`"0000"`) or the
 * backslash-escaped form (`\"0000\"`) that arises when a JSON document
 * contains a JSON-stringified payload (as the fixture's tool-call
 * `arguments` field does). The character class permits any combination
 * of `:`, `"`, backslash, and whitespace between the key and the
 * captured 4-digit run.
 */
const SSN_LAST_FOUR_VALUE_GLOBAL = /ssn_last_four[\\":\s]+(\d{4})/g;

/**
 * Approved placeholder names that fixtures MAY use in name-bearing
 * fields. Extending this list requires updating the fixture README so
 * the redaction policy stays in sync with what the guard accepts.
 */
const APPROVED_PLACEHOLDER_NAMES = ["Alice Example", "Pat Sample"] as const;

// Discover fixtures dynamically so newly-added files are scanned without
// needing to update this test. We sort for determinism so test output is
// stable across platforms.
const fixtureFiles = readdirSync(FIXTURES_DIR)
  .filter((entry) => entry.endsWith(".json"))
  .sort()
  .map((entry) => path.join(FIXTURES_DIR, entry));

/**
 * Recursively discovers every `*.txt` Golden_Prompt_Snapshot under
 * `tests/fixtures/golden-prompts/`. The directory layout is
 * `{fixture-name}/...txt` (one subdirectory per Span_Fixture) so a flat
 * walk is sufficient. The directory may not yet exist on a freshly
 * cloned repo (the generator at `scripts/generate-golden-prompts.ts`
 * has to be run once); in that case the function returns an empty
 * array and the per-snapshot describe block silently skips.
 */
function discoverGoldenPromptFiles(): string[] {
  const out: string[] = [];
  let entries: string[];
  try {
    entries = readdirSync(GOLDEN_PROMPTS_DIR);
  } catch {
    return out;
  }
  for (const entry of entries.sort()) {
    const entryPath = path.join(GOLDEN_PROMPTS_DIR, entry);
    let stats;
    try {
      stats = statSync(entryPath);
    } catch {
      continue;
    }
    if (!stats.isDirectory()) continue;
    const inner = readdirSync(entryPath)
      .filter((f) => f.endsWith(".txt"))
      .sort();
    for (const f of inner) out.push(path.join(entryPath, f));
  }
  return out;
}

const goldenPromptFiles = discoverGoldenPromptFiles();

describe("Fixture redaction guard — tests/fixtures/spans/ (Req 16.5)", () => {
  it("discovers at least one fixture to scan", () => {
    // A guard against an accidental directory move that would otherwise
    // make every per-fixture assertion below silently disappear.
    expect(
      fixtureFiles.length,
      `Expected to find at least one *.json fixture in ${FIXTURES_DIR}`
    ).toBeGreaterThan(0);
  });

  describe.each(fixtureFiles)("%s", (fixturePath) => {
    // Read the raw file bytes once per fixture. The redaction checks all
    // operate on the raw text rather than the parsed JSON tree because
    // some sensitive values (e.g. tool-call `arguments`) live inside
    // doubly-encoded JSON strings; scanning the raw bytes catches them
    // regardless of nesting depth without bespoke walkers.
    const raw = readFileSync(fixturePath, "utf8");
    const fixtureLabel = path.relative(process.cwd(), fixturePath);

    it("uses only NANP +1 555-01XX reserved phone numbers", () => {
      const allMatches = Array.from(raw.matchAll(E164_US_PHONE_GLOBAL)).map(
        (m) => m[0]
      );
      const offenders = allMatches.filter(
        (phone) => !RESERVED_FICTITIOUS_PHONE.test(phone)
      );
      expect(
        offenders,
        `Fixture ${fixtureLabel} contains E.164 phone numbers outside the ` +
          `reserved +1 555-01XX block (+15555550100..+15555550199): ` +
          `${JSON.stringify(offenders)}`
      ).toEqual([]);
    });

    it('uses only the literal "0000" placeholder for ssn_last_four', () => {
      const offenders: string[] = [];
      for (const match of raw.matchAll(SSN_LAST_FOUR_VALUE_GLOBAL)) {
        const value = match[1];
        if (value !== "0000") {
          offenders.push(value);
        }
      }
      expect(
        offenders,
        `Fixture ${fixtureLabel} has non-placeholder ssn_last_four values ` +
          `(must be the literal "0000"): ${JSON.stringify(offenders)}`
      ).toEqual([]);
    });

    it("uses an approved placeholder customer name", () => {
      const present = APPROVED_PLACEHOLDER_NAMES.filter((name) =>
        raw.includes(name)
      );
      expect(
        present.length,
        `Fixture ${fixtureLabel} does not reference any approved ` +
          `placeholder name. Approved names: ` +
          `${JSON.stringify(APPROVED_PLACEHOLDER_NAMES)}. ` +
          `Either redact the customer name to one of these placeholders ` +
          `or extend the approved list in this guard and the fixture README.`
      ).toBeGreaterThan(0);
    });
  });
});

describe("Golden-prompt redaction guard — tests/fixtures/golden-prompts/ (Req 11.5)", () => {
  it("discovers at least one snapshot to scan", () => {
    // A guard so a future move/rename of `golden-prompts/` (or a forgotten
    // generator run on a fresh clone) does not silently bypass the
    // redaction check. The generator at
    // `scripts/generate-golden-prompts.ts` must be run for at least one
    // fixture before this guard becomes useful.
    expect(
      goldenPromptFiles.length,
      `Expected to find at least one *.txt snapshot under ${GOLDEN_PROMPTS_DIR}. ` +
        `Run \`npx tsx scripts/generate-golden-prompts.ts\` to generate them.`
    ).toBeGreaterThan(0);
  });

  describe.each(goldenPromptFiles)("%s", (snapshotPath) => {
    // Read the raw bytes once per snapshot. The redaction checks
    // operate on the raw text — golden snapshots are flat strings (one
    // rendered prompt-context surface per file), so a tree walker is
    // unnecessary.
    const raw = readFileSync(snapshotPath, "utf8");
    const snapshotLabel = path.relative(process.cwd(), snapshotPath);

    it("uses only NANP +1 555-01XX reserved phone numbers", () => {
      const allMatches = Array.from(raw.matchAll(E164_US_PHONE_GLOBAL)).map(
        (m) => m[0]
      );
      const offenders = allMatches.filter(
        (phone) => !RESERVED_FICTITIOUS_PHONE.test(phone)
      );
      expect(
        offenders,
        `Golden-prompt snapshot ${snapshotLabel} contains E.164 phone ` +
          `numbers outside the reserved +1 555-01XX block ` +
          `(+15555550100..+15555550199): ${JSON.stringify(offenders)}. ` +
          `Redact the source Span_Fixture and re-run ` +
          `\`npx tsx scripts/generate-golden-prompts.ts\`.`
      ).toEqual([]);
    });

    it('uses only the literal "0000" placeholder for ssn_last_four', () => {
      const offenders: string[] = [];
      for (const match of raw.matchAll(SSN_LAST_FOUR_VALUE_GLOBAL)) {
        const value = match[1];
        if (value !== "0000") {
          offenders.push(value);
        }
      }
      expect(
        offenders,
        `Golden-prompt snapshot ${snapshotLabel} has non-placeholder ` +
          `ssn_last_four values (must be the literal "0000"): ` +
          `${JSON.stringify(offenders)}. Redact the source Span_Fixture ` +
          `and re-run \`npx tsx scripts/generate-golden-prompts.ts\`.`
      ).toEqual([]);
    });
  });
});
