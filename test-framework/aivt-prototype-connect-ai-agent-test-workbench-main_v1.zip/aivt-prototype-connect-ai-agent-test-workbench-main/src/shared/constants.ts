/**
 * Shared constants for the Connect Agent Test Platform.
 *
 * @module constants
 */

// ---------------------------------------------------------------------------
// Configuration defaults
// ---------------------------------------------------------------------------

/** Maximum conversation turns before ending a test case. */
export const MAX_TURNS = 20;

/** Polling interval in milliseconds for async operations. */
export const POLL_INTERVAL_MS = 300;

/** Polling timeout in milliseconds before aborting. */
export const POLL_TIMEOUT_MS = 60_000;

/** Default concurrency for parallel test case execution. */
export const CONCURRENCY = 9;

/** Maximum retry attempts for transient failures. */
export const MAX_RETRIES = 3;

// ---------------------------------------------------------------------------
// Backoff configuration
// ---------------------------------------------------------------------------

/** Base delay in milliseconds for exponential backoff. */
export const BACKOFF_BASE_DELAY_MS = 2_000;

/** Maximum delay in milliseconds for exponential backoff. */
export const BACKOFF_MAX_DELAY_MS = 30_000;

// ---------------------------------------------------------------------------
// DynamoDB key patterns
// ---------------------------------------------------------------------------

/** Partition key prefixes. */
export const PK_PATTERNS = {
  TENANT: "TENANT#",
  SUITE: "SUITE#",
  RUN: "RUN#",
  PROMPT: "PROMPT#",
} as const;

/** Sort key prefixes. */
export const SK_PATTERNS = {
  SUITE: "SUITE#",
  CASE: "CASE#",
  RUN: "RUN#",
  TURN: "TURN#",
  TRACE: "TRACE",
  SNAPSHOT: "SNAPSHOT",
  EXPERIMENT: "EXPERIMENT#",
  APPLY_DIRECT: "APPLY#DIRECT#",
  AUDIT: "AUDIT#",
  OVERRIDE: "OVERRIDE",
  HISTORY: "HISTORY#",
} as const;

// ---------------------------------------------------------------------------
// Field limits
// ---------------------------------------------------------------------------

/** Maximum length of a test suite name. */
export const SUITE_NAME_MAX = 128;

/** Maximum length of a test suite description. */
export const SUITE_DESCRIPTION_MAX = 500;

/** Maximum length of a test case name. */
export const CASE_NAME_MAX = 100;

/** Maximum length of a test case description. */
export const CASE_DESCRIPTION_MAX = 2_000;

/** Maximum length of the initial utterance. */
export const INITIAL_UTTERANCE_MAX = 1_000;

/** Maximum number of customer knowledge key-value pairs. */
export const CUSTOMER_KNOWLEDGE_MAX_PAIRS = 20;

/** Maximum length of a customer knowledge key. */
export const CUSTOMER_KNOWLEDGE_KEY_MAX = 100;

/** Maximum length of a customer knowledge value. */
export const CUSTOMER_KNOWLEDGE_VALUE_MAX = 500;

/** Maximum number of success criteria tool steps. */
export const SUCCESS_CRITERIA_MAX_STEPS = 30;

/** Minimum number of success criteria tool steps. */
export const SUCCESS_CRITERIA_MIN_STEPS = 1;

/** Maximum number of parameter checks per tool step. */
export const PARAMETER_CHECKS_MAX = 10;

// ---------------------------------------------------------------------------
// RAG Test Case limits and configuration
// ---------------------------------------------------------------------------

/** Maximum length of a RAG case question field. */
export const RAG_QUESTION_MAX = 1_000;

/** Maximum length of a RAG case ground truth answer field. */
export const RAG_GROUND_TRUTH_MAX = 4_000;

/** Polling interval in milliseconds for Bedrock RAG evaluation jobs. */
export const RAG_JOB_POLL_INTERVAL_MS = 30_000;

/** Hard timeout in milliseconds for Bedrock RAG evaluation job polling (30 min). */
export const RAG_JOB_TIMEOUT_MS = 1_800_000;

// ---------------------------------------------------------------------------
// Prompt management
// ---------------------------------------------------------------------------

/**
 * Default per-prompt cap on persisted prompt text size in UTF-8 bytes.
 * Used when a prompt definition does not declare a tighter `maxTextBytes`.
 */
export const PROMPT_TEXT_DEFAULT_MAX_BYTES = 65_536;

/** Maximum number of prior versions retained per prompt in the history table. */
export const PROMPT_HISTORY_MAX_ENTRIES = 10;
