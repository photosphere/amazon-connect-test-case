# Design Document: Implement Recommendations

## Overview

This feature closes the recommendation-to-action gap by adding two execution paths from the platform's persisted recommendations to the live agent configuration:

1. **Direct Apply** — a confirmation-gated write that applies the recommended `currentText → suggestedText` edits to the live agent via `UpdateAIAgent`/`UpdateAIPrompt`, with drift detection and an audit trail.

2. **Multi-Variant Experiment** — generates 3 diverse prompt/config variants from the recommendations via Bedrock, creates temporary cloned agents, runs the test suite against all 3 in parallel via Step Functions, presents a tournament comparison view with AI-generated summary, and allows the user to apply the winning variant.

Both paths are gated by `INSTANCE_MODE` at UI, API, and IAM layers. Temporary agents are never routed to by the assistant's production config. Every write is auditable and reversible (new agent version = rollback target).

### Design Rationale Summary

- **Why drift detection before write**: The recommendation's `currentText` was captured at analysis time. A colleague (or the user themselves) may have edited the agent since. Character-for-character comparison ensures we never silently overwrite intervening edits. The cost is one `GetAIAgent` call per apply — negligible.
- **Why 3 variants, not N**: 3 is enough to explore diverse strategies (conciseness, example-heavy, restructured) without multiplying temporary agent cost or test execution time. The UI reserves an extensibility point for future N-variant support.
- **Why server-side cleanup, not frontend-triggered**: Users navigate away. Browser crashes. Cleanup must be guaranteed. A Step Functions post-execution hook ensures deletion regardless of client state.
- **Why a separate Experiment State Machine**: The existing `TestRunStateMachine` is optimized for single-suite runs. The experiment orchestrator coordinates 3 independent run triggers + cleanup — a fundamentally different control flow that would pollute the existing machine's error-handling semantics.
- **Why IAM removal in production mode**: Defense-in-depth. Application-layer checks can be bypassed by a compromised Lambda. Removing the IAM actions from the role means even direct SDK calls from within the Lambda would fail with AccessDenied.

## Architecture

```mermaid
graph TB
    subgraph Frontend["Frontend (React + Cloudscape)"]
        RD[Run Dashboard<br/>RecommendedChangesPanel<br/>+ Implement Button]
        FA[Failure Analysis View<br/>+ Implement Button]
        CD[Confirmation Dialog<br/>Diff Viewer]
        TV[Tournament View<br/>4-column comparison]
    end

    subgraph API["API Gateway + Cognito"]
        ApplyEP["POST /runs/{runId}/apply-recommendations"]
        ExpCreateEP["POST /runs/{runId}/experiments"]
        ExpGetEP["GET /runs/{runId}/experiments/{experimentId}"]
        ExpApplyEP["POST /runs/{runId}/experiments/{experimentId}/apply"]
        AuditEP["GET /audit"]
    end

    subgraph Lambdas["Lambda Handlers"]
        ApplyL[Apply Recommendations<br/>apply-recommendations.ts]
        ExpCreateL[Create Experiment<br/>experiment-create.ts]
        ExpGetL[Get Experiment<br/>experiment-get.ts]
        ExpApplyL[Apply Variant<br/>experiment-apply.ts]
        AuditL[Audit Trail<br/>audit.ts]
        CleanupL[Experiment Cleanup<br/>experiment-cleanup.ts]
        VariantGenL[Variant Generator<br/>(orchestration module)]
    end

    subgraph Orchestration["Step Functions"]
        ExperimentSM[Experiment State Machine<br/>GenerateVariants → CreateAgents<br/>→ Parallel(3×RunSuite)<br/>→ Summarize → Cleanup]
        ExistingSM[Existing TestRun SM<br/>(reused per variant)]
    end

    subgraph External["AWS Services"]
        QiC[Q in Connect<br/>CreateAIAgent / UpdateAIAgent<br/>UpdateAIPrompt / DeleteAIAgent<br/>GetAIAgent / GetAIPrompt]
        BR[Bedrock Converse<br/>Variant Generation<br/>+ Tournament Summary]
        DDB[(DynamoDB<br/>Single Table)]
    end

    RD --> ApplyEP
    RD --> ExpCreateEP
    FA --> ApplyEP
    TV --> ExpApplyEP
    TV --> ExpGetEP

    ApplyEP --> ApplyL
    ExpCreateEP --> ExpCreateL
    ExpGetEP --> ExpGetL
    ExpApplyEP --> ExpApplyL
    AuditEP --> AuditL

    ApplyL --> QiC
    ApplyL --> DDB
    ExpCreateL --> ExperimentSM
    ExpCreateL --> DDB
    ExpApplyL --> QiC
    ExpApplyL --> DDB

    ExperimentSM --> VariantGenL
    ExperimentSM --> QiC
    ExperimentSM --> ExistingSM
    ExperimentSM --> CleanupL
    ExperimentSM --> BR

    VariantGenL --> BR
    CleanupL --> QiC
    CleanupL --> DDB
```

### Experiment State Machine Detail

```mermaid
stateDiagram-v2
    [*] --> GenerateVariants
    GenerateVariants --> ValidateVariants
    ValidateVariants --> CreateTempAgents
    ValidateVariants --> FallbackOrFail: validation_failed
    CreateTempAgents --> RunParallel
    CreateTempAgents --> RollbackAgents: creation_failed
    RollbackAgents --> [*]

    state RunParallel {
        [*] --> RunVariantA
        [*] --> RunVariantB
        [*] --> RunVariantC
        RunVariantA --> [*]
        RunVariantB --> [*]
        RunVariantC --> [*]
    }

    RunParallel --> GenerateSummary
    GenerateSummary --> Cleanup
    Cleanup --> MarkCompleted
    MarkCompleted --> [*]
    FallbackOrFail --> [*]
```

## Components and Interfaces

### Backend: Apply Recommendations Handler

```typescript
// src/backend/handlers/apply-recommendations.ts

export interface ApplyRecommendationsRequest {
  mode: "direct";
  agentId: string;
  /** Indices into the run's per-suite recommendations array to apply. */
  recommendationIndices: number[];
}

export interface ApplyRecommendationsResponse {
  success: boolean;
  newVersionId?: string;
  error?: string;
  /** Fields where drift was detected (populated on conflict). */
  driftedFields?: DriftedField[];
}

export interface DriftedField {
  targetField: ToolSurface;
  targetName: string;
  expectedText: string;
  actualText: string;
}
```

**Flow:**
1. Validate `INSTANCE_MODE !== "production"` → 403 if blocked.
2. Load persisted per-suite recommendations from `PK=RUN#{runId}, SK=ANALYSIS#SUITE`.
3. Resolve the selected indices into `Recommendation[]`.
4. Call `GetAIAgent` to fetch the live agent config.
5. Run drift detection: for each recommendation, compare `currentText` against the live field value.
6. If drift detected → return `{ success: false, driftedFields }`.
7. Build the update payloads (one `UpdateAIAgent` for tool surfaces, one `UpdateAIPrompt` for system_prompt).
8. Execute writes atomically per API call.
9. Persist audit record at `PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}`.
10. Persist apply record at `PK=RUN#{runId}, SK=APPLY#DIRECT#{timestamp}`.
11. Return `{ success: true, newVersionId }`.

### Backend: Drift Detection Module

```typescript
// src/backend/orchestration/drift-detection.ts

export interface DriftCheckInput {
  recommendations: Recommendation[];
  liveAgentConfig: AgentDetail;
}

export interface DriftCheckResult {
  hasDrift: boolean;
  driftedFields: DriftedField[];
  cleanFields: Recommendation[];
}

/**
 * Pure function: compares each recommendation's currentText against the live
 * agent's corresponding field value. Character-for-character comparison.
 *
 * For tool_description/tool_instruction/tool_examples:
 *   - Finds the tool by targetName in liveAgentConfig.tools
 *   - Compares currentText against the live value of that field
 *
 * For system_prompt:
 *   - Compares currentText against liveAgentConfig.systemPrompt
 *
 * Returns the set of drifted fields and the set of clean recommendations.
 */
export function checkDrift(input: DriftCheckInput): DriftCheckResult;
```

### Backend: Config Writer Module

```typescript
// src/backend/orchestration/config-writer.ts

export interface WritePayload {
  agentId: string;
  assistantId: string;
  /** Recommendations to apply, grouped by target. */
  recommendations: Recommendation[];
  /** The current live agent config (already fetched for drift check). */
  currentConfig: AgentDetail;
}

export interface WriteResult {
  success: boolean;
  newAgentVersionId?: string;
  newPromptVersionId?: string;
  error?: string;
}

/**
 * Pure function that builds the UpdateAIAgent/UpdateAIPrompt payloads from
 * (currentConfig + recommendations), then executes the writes.
 *
 * Applies all tool-surface changes in a single UpdateAIAgent call.
 * Applies all system_prompt changes in a single UpdateAIPrompt call.
 * The resulting payload contains exactly the suggestedText values mapped to
 * their correct fields — no other modifications (R18.2).
 */
export async function writeConfig(payload: WritePayload): Promise<WriteResult>;
```

### Backend: Experiment Create Handler

```typescript
// src/backend/handlers/experiment-create.ts

export interface ExperimentCreateRequest {
  mode: "multi_variant";
  agentId: string;
}

export interface ExperimentCreateResponse {
  experimentId: string;
  status: ExperimentStatus;
}
```

**Flow:**
1. Validate `INSTANCE_MODE !== "production"` → 403.
2. Generate `experimentId` (UUID v4).
3. Load per-suite recommendations for the run.
4. Persist experiment record at `PK=RUN#{runId}, SK=EXPERIMENT#{experimentId}` with `status: "generating_variants"`.
5. Start the Experiment State Machine execution, passing `{ runId, experimentId, agentId, recommendations }`.
6. Return `{ experimentId, status: "generating_variants" }`.

### Backend: Variant Generator Module

```typescript
// src/backend/orchestration/variant-generator.ts

export interface VariantConfig {
  variantLetter: "A" | "B" | "C";
  strategy: string; // e.g. "conciseness", "example-heavy", "restructured"
  recommendations: Recommendation[];
}

export interface VariantGenerationInput {
  sourceRecommendations: PerSuiteRecommendation[];
  agentSnapshot: AgentSnapshot;
  agentId: string;
}

export interface VariantGenerationResult {
  variants: VariantConfig[];
  failedVariants: string[]; // variant letters that failed after retry
}

/**
 * Calls Bedrock with temperature > 0 to produce 3 distinct rewrites.
 * Each variant targets only the Tool_Surface values present in the source
 * recommendations (R13.3, R18.4).
 *
 * IMPORTANT: Sonnet 4.6 rejects Converse calls that set both temperature
 * AND topP simultaneously. Set ONLY temperature (e.g., 0.7 for diversity)
 * and omit topP entirely. This matches the fix applied platform-wide after
 * the summarization regression.
 *
 * Validates each variant against:
 * - Structural constraints (valid targetField, non-empty targetName)
 * - System prompt safety rules (R20): dynamic params at end, thinking/messaging immutable, no new examples
 * - Surface scope constraint: variant surfaces ⊆ source surfaces
 *
 * Retries once per failed variant before marking it as failed.
 */
export async function generateVariants(
  input: VariantGenerationInput
): Promise<VariantGenerationResult>;
```

### Backend: Experiment Cleanup Handler

```typescript
// src/backend/handlers/experiment-cleanup.ts

export interface CleanupInput {
  experimentId: string;
  runId: string;
  temporaryAgentIds: string[];
  assistantId: string;
}

export interface CleanupResult {
  deletedCount: number;
  failedIds: string[];
  cleanupStatus: "success" | "partial_failure";
}

/**
 * Deletes all temporary agents created for the experiment.
 * Retry once with exponential backoff per agent.
 * Updates experiment record with cleanupStatus.
 */
export async function cleanupExperiment(input: CleanupInput): Promise<CleanupResult>;
```

### Backend: Tournament Summary Generator

```typescript
// src/backend/orchestration/tournament-summary.ts

export interface TournamentSummaryInput {
  baselineResults: TestCaseResult[];
  variantResults: Record<"A" | "B" | "C", TestCaseResult[]>;
  variantConfigs: VariantConfig[];
}

export interface TournamentSummary {
  winningVariant: "A" | "B" | "C" | null;
  summary: string; // AI-generated explanation
  perVariantHighlights: Record<"A" | "B" | "C", {
    improved: string[];
    regressed: string[];
  }>;
}

/**
 * Calls Bedrock Converse to produce a natural-language summary comparing
 * baseline vs variant results. The winning variant is computed deterministically
 * (highest pass rate, tiebreak by avg goal success score) — the AI summary
 * only explains the quantitative result.
 *
 * Uses temperature: 0 for deterministic summary output. Does NOT set topP
 * (Sonnet 4.6 rejects temperature+topP together).
 */
export async function generateTournamentSummary(
  input: TournamentSummaryInput
): Promise<TournamentSummary>;
```

### Backend: Variant Selection (Pure)

```typescript
// src/backend/orchestration/variant-selection.ts

export interface VariantScore {
  variant: "A" | "B" | "C";
  passRate: number;
  avgGoalSuccessScore: number;
  avgHelpfulnessScore: number;
  avgToolAccuracyScore: number;
  status: "completed" | "error";
}

/**
 * Deterministic, idempotent selection function (R18.5).
 * Returns the variant with the highest pass rate.
 * Ties broken by avg goal success score (higher wins).
 * Errored variants are excluded from selection.
 * Returns null if all variants errored.
 */
export function selectWinningVariant(scores: VariantScore[]): "A" | "B" | "C" | null;
```

### Frontend: ImplementRecommendations Flow

```typescript
// src/frontend/src/components/ImplementRecommendations/
//   ├── ImplementButton.tsx        — entry point, hidden when INSTANCE_MODE=production
//   ├── ModeSelector.tsx           — "Apply directly" / "Multi-variant experiment"
//   ├── ConfirmationDialog.tsx     — diff viewer, drift warning, confirm/cancel
//   ├── ConflictResolution.tsx     — drift detected: apply anyway / cancel / re-analyze
//   ├── ExperimentProgress.tsx     — loading + progress indicators
//   └── TournamentView.tsx         — 4-column results comparison

export interface ImplementButtonProps {
  runId: string;
  suiteId: string;
  agentId: string;
  hasRecommendations: boolean;
  runStatus: RunStatus;
  instanceMode: "production" | "development";
}
```

### CDK: Implement Recommendations Construct

```typescript
// lib/implement-recommendations-construct.ts

export interface ImplementRecommendationsConstructProps {
  table: dynamodb.ITable;
  connectInstanceId: string;
  assistantId: string;
  instanceMode: "production" | "development";
  existingStateMachineArn: string;
  api: apigateway.RestApi;
  authorizer: apigateway.IAuthorizer;
}
```

The construct creates:
- `apply-recommendations` Lambda + API route
- `experiment-create` Lambda + API route
- `experiment-get` Lambda + API route
- `experiment-apply` Lambda + API route
- `experiment-cleanup` Lambda (invoked by Experiment SM)
- `audit` Lambda + API route
- `ExperimentStateMachine` (Step Functions)
- IAM roles scoped to assistant ARN (omits write actions when `instanceMode === "production"`)

## Data Models

### Experiment Record

```typescript
// PK=RUN#{runId}, SK=EXPERIMENT#{experimentId}

interface ExperimentRecord {
  experimentId: string;
  runId: string;
  agentId: string;
  status: ExperimentStatus;
  variantConfigs: VariantConfig[];
  temporaryAgentIds: Record<"A" | "B" | "C", string>;
  variantRunIds: Record<"A" | "B" | "C", string>;
  baselineRunId: string;
  sfnExecutionArn: string;
  /** AI-generated tournament summary. */
  tournamentSummary?: TournamentSummary;
  /** Which variant was applied (if any). */
  appliedVariant?: "A" | "B" | "C";
  appliedAt?: string; // ISO 8601
  cleanupStatus: "pending" | "success" | "partial_failure";
  failedCleanupAgentIds?: string[];
  createdAt: string;  // ISO 8601
  completedAt?: string; // ISO 8601
  /** TTL: 90 days after completedAt (DynamoDB TTL attribute). */
  ttl?: number;
}

type ExperimentStatus =
  | "generating_variants"
  | "creating_agents"
  | "running"
  | "completed"
  | "failed"
  | "cleanup_in_progress"
  | "cleaned_up";
```

### Audit Record

```typescript
// PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}

interface AuditRecord {
  tenantId: string;
  timestamp: string; // ISO 8601
  runId: string;
  agentId: string;
  source: "direct_apply" | "experiment_apply";
  /** For experiment_apply: experiment ID and variant letter. */
  experimentId?: string;
  appliedVariant?: "A" | "B" | "C";
  previousVersionId: string;
  newVersionId: string;
  recommendations: Recommendation[];
  /** Drift detection result, if drift was detected and user forced. */
  driftDetected?: boolean;
  driftedFields?: DriftedField[];
  userDecision?: "apply_anyway" | "normal";
}
```

### Apply Record (per-run)

```typescript
// PK=RUN#{runId}, SK=APPLY#DIRECT#{timestamp}

interface ApplyRecord {
  runId: string;
  timestamp: string;
  agentId: string;
  recommendationIndices: number[];
  newVersionId: string;
  source: "direct_apply";
}
```

### DynamoDB Key Patterns (additions to constants.ts)

```typescript
export const SK_PATTERNS = {
  // ... existing
  EXPERIMENT: "EXPERIMENT#",
  APPLY_DIRECT: "APPLY#DIRECT#",
} as const;

export const PK_PATTERNS = {
  // ... existing
  TENANT: "TENANT#",
} as const;
```

## API Contracts

### POST /runs/{runId}/apply-recommendations

**Request:**
```json
{
  "mode": "direct",
  "agentId": "agent-uuid",
  "recommendationIndices": [0, 1, 2]
}
```

**Success Response (200):**
```json
{
  "success": true,
  "newVersionId": "v3"
}
```

**Drift Response (409):**
```json
{
  "success": false,
  "error": "drift_detected",
  "driftedFields": [
    {
      "targetField": "tool_instruction",
      "targetName": "verifyIdentity",
      "expectedText": "Use only after greeting.",
      "actualText": "Use only after greeting the customer warmly."
    }
  ]
}
```

**Production Mode (403):**
```json
{
  "error": "write_disabled",
  "reason": "Agent writes and experiments are disabled in production mode"
}
```

### POST /runs/{runId}/experiments

**Request:**
```json
{
  "mode": "multi_variant",
  "agentId": "agent-uuid"
}
```

**Response (202):**
```json
{
  "experimentId": "exp-uuid",
  "status": "generating_variants"
}
```

### GET /runs/{runId}/experiments/{experimentId}

**Response (200):**
```json
{
  "experimentId": "exp-uuid",
  "status": "completed",
  "variantConfigs": [...],
  "variantRunIds": { "A": "run-a", "B": "run-b", "C": "run-c" },
  "baselineRunId": "original-run-id",
  "tournamentSummary": {
    "winningVariant": "B",
    "summary": "Variant B achieved 92% pass rate vs 75% baseline...",
    "perVariantHighlights": { ... }
  },
  "cleanupStatus": "success",
  "createdAt": "2025-01-15T10:00:00Z",
  "completedAt": "2025-01-15T10:15:00Z"
}
```

### POST /runs/{runId}/experiments/{experimentId}/apply

**Request:**
```json
{
  "variant": "B"
}
```

**Response:** Same shape as `POST /runs/{runId}/apply-recommendations`.

### GET /audit

**Response (200):**
```json
{
  "records": [...],
  "nextToken": "..."
}
```

Paginated at 50 records per page, reverse chronological.

## Variant Generation Prompt Strategy

### System Prompt

```
You are an expert AI agent prompt engineer specializing in Amazon Q in Connect orchestration agents. You generate diverse, high-quality rewrites of agent configuration recommendations.

You produce 3 variants, each using a DISTINCT rewrite strategy:
- Variant A: CONCISENESS — make instructions shorter, more direct, remove redundancy
- Variant B: EXAMPLE-HEAVY — add concrete examples to tool_examples, make instructions more specific with inline examples
- Variant C: RESTRUCTURED — reorganize instruction flow, improve logical grouping, clarify conditional logic

SAFETY RULES (MANDATORY — violations cause variant rejection):
1. Dynamic parameters ({{$.Custom.*}}, {{agent.*}}, {{session.*}}) MUST remain in their original positions at the END of the system prompt. Do NOT relocate them earlier.
2. Thinking and messaging instruction blocks (<thinking>, <messaging>, or equivalent structural delimiters) are IMMUTABLE — do NOT modify, reword, or remove them byte-for-byte.
3. Do NOT add new examples to the system_prompt body. New examples go ONLY to tool_examples. Existing examples in the prompt MAY be tweaked or removed, but no new example content may be introduced.
4. Target ONLY the Tool_Surface values present in the source recommendations. Do NOT introduce changes to surfaces not already recommended.
5. Do NOT add new tool definitions, remove existing tools, or modify Knowledge Base bindings.

Output JSON only.
```

### User Message

```
## Source Recommendations
{JSON array of the per-suite recommendations being used as seed}

## Current Agent Configuration
{formatTools(agentSnapshot.tools) with Examples blocks}

## Current System Prompt
{agentSnapshot.systemPrompt}

## Instructions
For each of the 3 variants (A=conciseness, B=example-heavy, C=restructured), produce a complete set of recommendations that replace the source recommendations. Each variant's recommendations target the same Tool_Surface values as the source but with the variant's distinct strategy applied.

Output format:
{
  "variants": [
    {
      "variantLetter": "A",
      "strategy": "conciseness",
      "recommendations": [
        {
          "targetField": "tool_instruction" | "tool_description" | "tool_examples" | "system_prompt",
          "targetName": "<tool name or 'system_prompt'>",
          "currentText": "<exact existing text from the agent config>",
          "suggestedText": "<your rewritten text>",
          "rationale": "<brief explanation of the change>"
        }
      ]
    },
    { "variantLetter": "B", ... },
    { "variantLetter": "C", ... }
  ]
}
```

### Variant Validation Rules (post-generation)

Each variant is validated before agent creation:
1. **Surface scope**: `variant.recommendations.map(r => r.targetField)` ⊆ `sourceRecommendations.map(r => r.targetField)`
2. **Structural validity**: Each recommendation has valid `targetField`, non-empty `targetName`, at least one of `currentText`/`suggestedText` non-empty
3. **System prompt safety** (when `system_prompt` is targeted):
   - Dynamic parameters preserved at end (regex match `\{\{[\$\.].*?\}\}` positions)
   - Thinking/messaging blocks unchanged (extract blocks by markers, byte-compare)
   - No new examples in prompt body (diff analysis: additions must not contain example-like patterns when no examples existed in source at that position)

Failed variants are regenerated once (same strategy, with the failure reason injected into the prompt). If still failing after retry, the experiment proceeds with fewer variants (minimum 2) or offers fallback to Direct Apply.

## Experiment State Machine Definition

```typescript
// src/backend/orchestration/experiment-state-machine.ts

/**
 * Step Functions definition for Multi-Variant Experiment orchestration.
 *
 * Flow:
 *   GenerateVariants → ValidateVariants → CreateTempAgents
 *     → Parallel(TriggerRunA, TriggerRunB, TriggerRunC)
 *     → WaitForCompletion → GenerateSummary → Cleanup → MarkCompleted
 *
 * Error handling:
 *   - Variant generation failure: mark experiment as failed, no cleanup needed
 *   - Agent creation failure: rollback any created agents, mark failed
 *   - Single variant run failure: continue others, mark variant as error
 *   - Cleanup failure: mark partial_failure, log orphaned IDs
 */

export interface ExperimentStateMachineProps {
  variantGeneratorFn: lambda.IFunction;
  agentCreatorFn: lambda.IFunction;     // Creates temp agents via CreateAIAgent
  runTriggerFn: lambda.IFunction;        // Triggers existing TestRun SM per variant
  pollRunStatusFn: lambda.IFunction;     // Polls variant run completion
  tournamentSummaryFn: lambda.IFunction; // Generates AI summary via Bedrock
  cleanupFn: lambda.IFunction;           // Deletes temp agents
  statusUpdaterFn: lambda.IFunction;     // Updates experiment DDB record
}
```

The state machine uses Step Functions Parallel state for the 3 variant runs, with individual catch handlers that mark a variant as `error` without aborting siblings. The Cleanup step runs unconditionally (regardless of variant success/failure) via a `ResultPath` that captures errors without stopping execution.

## Error Handling

| Scenario | Behavior |
|----------|----------|
| `INSTANCE_MODE === "production"` | API returns 403, UI hides buttons, IAM blocks SDK calls |
| Drift detected on apply | Return 409 with drifted fields; user chooses force/cancel/re-analyze |
| `UpdateAIAgent` / `UpdateAIPrompt` fails | Return error to user, no audit record persisted, no partial state |
| Variant generation Bedrock throttled | Retry 2× with exponential backoff (1s, 3s); then fail experiment |
| Variant validation failure after retry | Proceed with 2 variants if available, else offer Direct Apply fallback |
| Temp agent creation fails mid-batch | Delete any already-created agents, mark experiment failed |
| Single variant run errors | Continue other variants; mark variant column as error in Tournament View |
| Cleanup `DeleteAIAgent` fails | Retry once with backoff; if still failing, log + mark `partial_failure` |
| Tournament summary Bedrock call fails | Render quantitative results without AI summary; show "Retry summary" button |
| Run has no recommendations | Return 404 with `error: "no_recommendations"` |
| Agent not found / wrong assistant | Return 400 with `error: "agent_not_found"` or `error: "agent_not_on_assistant"` |

## Testing Strategy

### Unit Tests (example-based)

- Confirmation dialog renders correct diff for add/remove/replace operations
- Instance mode flag hides UI elements and returns 403 from API
- Experiment status transitions render correct UI states
- Tournament View highlights correct winning variant
- Audit record contains all required fields

### Integration Tests

- End-to-end Direct Apply: recommendation → drift check → write → verify new version
- End-to-end Experiment: create → generate variants → create agents → verify cleanup
- Drift detection with actual agent version mismatch
- IAM permission boundary enforcement in production mode

### Property-Based Tests

Property-based testing is appropriate for this feature because the core logic (drift detection, config writing, variant selection, surface scope validation) consists of pure functions with clear input/output behavior and universal properties that hold across a wide input space.

**Library**: fast-check (TypeScript, already available in the project ecosystem)
**Configuration**: Minimum 100 iterations per property test.
**Tag format**: `Feature: implement-recommendations, Property {N}: {title}`

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Drift detection correctness

*For any* Recommendation and any live agent configuration, if the recommendation's `currentText` matches the corresponding live agent field character-for-character, then the drift detection function SHALL return `no_drift` for that field. Conversely, if they differ by even one character, it SHALL return `drift` for that field. This holds regardless of whitespace variations in other fields, the number of recommendations in the batch, or the Tool_Surface type.

**Validates: Requirements 3.6, 11.1, 11.2, 18.1**

### Property 2: Write payload purity

*For any* set of Recommendation objects and any valid agent configuration, the `buildUpdatePayload` function SHALL produce an `UpdateAIAgent` payload containing exactly the `suggestedText` values from the applied recommendations mapped to their correct tool fields, and no other field modifications. The write operation is a pure function from `(currentConfig, recommendations) → updatedConfig` — fields not targeted by any recommendation remain byte-for-byte identical to the input config.

**Validates: Requirements 3.2, 18.2**

### Property 3: Variant surface scope containment

*For any* generated variant configuration and its source recommendation set, the set of `targetField` values present in the variant's recommendations SHALL be a subset of (or equal to) the set of `targetField` values present in the source recommendations. Variant generation never introduces changes to Tool_Surface values that were not already recommended.

**Validates: Requirements 5.3, 13.1, 13.3, 18.4**

### Property 4: Winner selection determinism and idempotence

*For any* set of variant scores (with pass rates and average goal success scores), the `selectWinningVariant` function SHALL always assign the "Recommended" badge to the variant with the highest pass rate, with ties broken by average goal success score (higher wins). The function is deterministic (same input always produces same output) and idempotent (calling it multiple times with the same input produces the same result). Errored variants are excluded from selection.

**Validates: Requirements 8.4, 18.5**

### Property 5: Cleanup completeness

*For any* experiment with N Temporary_Agents (where N is 1, 2, or 3), the cleanup function SHALL attempt deletion of exactly N agents. When all deletions succeed, the post-cleanup state SHALL have 0 temporary agents remaining. The function never attempts to delete agents that were not created for this experiment, and never skips agents that were.

**Validates: Requirements 10.1, 18.3**

### Property 6: System prompt safety validation

*For any* generated variant that modifies `system_prompt`, the validation function SHALL reject the variant if it: (a) moves any dynamic parameter (`{{$.Custom.*}}`, `{{agent.*}}`, `{{session.*}}`) away from its original position at the end of the prompt, OR (b) modifies any byte within a thinking/messaging instruction block (identified by structural delimiters), OR (c) introduces new example content into the system prompt body that was not present in the source prompt. A variant passing validation guarantees all three invariants are preserved.

**Validates: Requirements 20.1, 20.2, 20.3, 20.5, 20.6**

### Property 7: Recommendation structural validation

*For any* Recommendation object, the validation function SHALL accept it if and only if: `targetField` is one of the four valid Tool_Surface values (`tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`), AND `targetName` is a non-empty string, AND at least one of `currentText` or `suggestedText` is non-empty. Additionally, for `tool_examples` operations: `add` requires `currentText` empty and `suggestedText` non-empty; `remove` requires `currentText` non-empty and `suggestedText` empty; `replace` requires both non-empty.

**Validates: Requirements 5.4, 13.1**

### Property 8: Score aggregation correctness

*For any* set of TestCaseResult records for a variant run, the aggregate scores computed by the Tournament View SHALL equal: `passRate = countPassed / totalCases`, `avgGoalSuccessScore = mean(goalSuccessScore where defined)`, `avgHelpfulnessScore = mean(helpfulnessScore where defined)`, `avgToolAccuracyScore = mean(toolAccuracyScore where defined)`. Cases with undefined scores are excluded from the mean calculation (not counted as 0).

**Validates: Requirements 8.2**

### Property 9: Production mode API enforcement

*For any* valid request body sent to the write API endpoints (`POST /runs/{runId}/apply-recommendations`, `POST /runs/{runId}/experiments`, `POST /runs/{runId}/experiments/{experimentId}/apply`) when `INSTANCE_MODE === "production"`, the API SHALL return HTTP 403 with `{ error: "write_disabled" }` regardless of the request payload content, authentication state, or agent configuration.

**Validates: Requirements 19.3**

### Property 10: Agent-assistant ownership validation

*For any* `agentId` provided in a write request, the handler SHALL reject the request with an error if the agent does not belong to the configured `assistantId`. This holds regardless of the agent's existence — a valid agent on a different assistant is rejected identically to a nonexistent agent.

**Validates: Requirements 16.3**

