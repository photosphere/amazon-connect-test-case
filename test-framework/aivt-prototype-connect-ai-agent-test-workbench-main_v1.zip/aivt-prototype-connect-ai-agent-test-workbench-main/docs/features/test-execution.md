# Test execution

How the platform actually runs a test suite against a live agent.

## Lifecycle

```
POST /runs                                  // user clicks Start run
  └─> RunTrigger Lambda
        ├─ GetAIAgent + GetAIPrompt          // capture snapshot
        ├─ Persist AgentSnapshot
        ├─ Mint synthetic Connect contact
        └─ StartExecution: TestRunStateMachine

TestRunStateMachine
  ├─ PrepareRun                              // initialize run record
  ├─ ExecuteCases (Map state, concurrency=9)
  │    └─ For each case (parallel):
  │         conversation-driver → eval target agent → write TestCaseResult
  ├─ [if any RAG cases] RAGEvaluate
  │    ├─ Build BYOI JSONL dataset
  │    ├─ Upload to S3
  │    ├─ bedrock:CreateEvaluationJob
  │    ├─ Poll bedrock:GetEvaluationJob (30s interval, 30min cap)
  │    └─ Read per-prompt scores, write back to TestCaseResults
  ├─ EvaluateResults                         // Bedrock judge per case
  └─ WriteResults                            // run summary record
```

## Conversation driver

Source: `src/backend/orchestration/conversation-driver.ts`.

The driver translates one test case into a real Q in Connect session. Key behaviors:

### Session creation

```typescript
client.createSession({
  assistantId,
  name: `test-${randomHex(8)}`,             // required parameter, generated per case
});
// Returns resp.session.sessionId (note: nested!)
```

A common gotcha: omitting `name` returns a `ParamValidationError`. The driver always sets it.

### Agent override

The session is created without an agent association. The agent is specified per-message:

```typescript
client.sendMessage({
  assistantId,
  sessionId,
  aiAgentId: orchestrationAgentId,         // overrides default routing
  type: "TEXT",
  message: { value: { text: { value: customerUtterance } } },
});
```

This is critical: passing the agent on `CreateSession` (`aiAgentConfiguration`) routes through the system's default `SelfService` agent, which has a built-in `QUESTION` tool that catches everything. The `aiAgentId` parameter on `SendMessage` is the only way to invoke a custom orchestration agent directly.

### Polling and filler responses

`GetNextMessage` is polled every 300ms with a 60s timeout per cycle. Three outcomes:

1. **Tool selection** — `conversationSessionData` contains an entry with key `"Tool"`. The driver records the tool, then sends a follow-up to continue the conversation (not terminating yet — the agent may invoke more tools).
2. **Substantive text** — the agent's terminal response or a clarifying question. If a question, the customer simulator generates a response. If terminal, the conversation ends.
3. **Filler `"..."`** — voice-channel placeholder meaning "still thinking". The driver detects this by checking whether the `nextMessageToken` advanced; if not and only filler is present, it keeps polling on the same token.

### Customer simulator

Source: `src/backend/orchestration/customer-simulator.ts`.

When the agent asks a clarifying question, the platform calls Bedrock to generate a contextual customer response. The simulator:

- Receives the test case's `persona`, `style`, `customerKnowledge`, and `goalDescription`.
- Maintains conversation history across turns.
- Uses **role flipping** for the Bedrock Converse API: the customer's prior messages are tagged `assistant` (the model "said" these); the agent's messages are tagged `user`. The model generates the next customer turn as `assistant`.
- Constrained by `MAX_TURNS` (default 20).

The simulator only fires for tool-sequence cases. RAG cases never invoke it — the customer turn is the literal `question`.

### Execution trace capture

After the conversation ends, `ListSpans` is called for the session. Source: `src/backend/orchestration/span-parser.ts`.

The parser extracts:
- Each `inference` span with the agent's reasoning text.
- Each `execute_tool` span with the tool name, arguments, result, and success flag.
- The agent type (e.g. `ORCHESTRATION`, `SELF_SERVICE`).

The result is a `ExecutionTrace` persisted at `PK=RUN#{runId}, SK=TRACE#{caseId}` (or sometimes `SK=TRACE` for the run root, depending on the storage version). This is the source of truth for which tools were actually invoked — the `conversationSessionData["Tool"]` extraction is opportunistic, but `ListSpans` always reports the authoritative sequence.

For RAG cases, `chunk-extractor.ts` pulls the retrieved passages from the Retrieve tool's `execute_tool` span (the `toolResult.values[]` array), preserving order, text content, and citation fields (`knowledgeBaseId`, `contentId`, `title`).

### Throttling

Q in Connect APIs are limited to ~10 TPS per instance. With 9 concurrent test sessions, brief bursts can exceed this. Every API call is wrapped in `callWithThrottleRetry`:

- Detects `ThrottlingException`, `TooManyRequestsException`, or HTTP 429.
- Backs off with exponential delay + jitter: `base 2s, cap 30s`.
- Up to 3 retries per call.

Throttle events are logged but don't surface to the user unless they exceed the retry envelope (in which case the case errors with a throttle error).

## RAG evaluation (Stage 2)

Triggered only when at least one case has `type === "rag"`.

### Dataset assembly

For each RAG case that completed Stage 1 successfully, one JSONL line conforming to Bedrock's BYOI retrieve-and-generate schema:

```json
{
  "conversationTurns": [{
    "prompt": { "content": [{ "text": "What's the rate?" }] },
    "referenceResponses": [{ "content": [{ "text": "Our 30-year rate is 6.875%" }] }],
    "output": {
      "text": "The current 30-year fixed rate is 6.875% APR.",
      "knowledgeBaseIdentifier": "kb-uuid",
      "modelIdentifier": "us.anthropic.claude-haiku-4-5",
      "retrievedPassages": {
        "retrievalResults": [
          {
            "content": { "text": "Our 30-year fixed mortgage..." },
            "name": "Mortgage rates 2026",
            "metadata": { "contentId": "...", "knowledgeBaseId": "..." }
          }
        ]
      }
    }
  }]
}
```

Source: `src/backend/orchestration/jsonl-serializer.ts`.

The platform preserves case ordering: line `i` of the JSONL corresponds to the i-th surviving RAG case, and a line-index → caseId mapping is persisted at `PK=RUN#{runId}, SK=RAGJOB`.

### Job submission

`bedrock:CreateEvaluationJob` is called once per run with:
- `applicationType: "RagEvaluation"`.
- The S3 dataset URI.
- The S3 output location (a per-run prefix).
- A Bedrock judge model (typically the same Claude Sonnet used elsewhere).
- The four built-in metrics: Faithfulness, Correctness, Completeness, Helpfulness.

### Polling and result extraction

The state machine polls `bedrock:GetEvaluationJob` every 30s with a 30-minute hard cap. When `JobStatus === COMPLETED`:

1. Read the per-prompt metric output from S3.
2. Join by prompt index back to caseId via the persisted mapping.
3. Write four scores to each case's `ragMetrics` field.

If the job times out, every RAG case in the run gets `evaluationError: { code: "RAG_JOB_TIMEOUT" }` and the run completes with those scores absent.

### Pass/fail evaluation

Source: `src/backend/orchestration/rag-decision.ts` and the run finalizer.

Per RAG case:
- If `Faithfulness < ragThresholds.faithfulness` → `failed` (hard gate).
- Else if any of `correctness`, `completeness`, `helpfulness` < its threshold → `failed`.
- Else → `passed`.

## Bedrock judge evaluation (Stage 3)

Triggered for every test case with a captured execution trace. See [bedrock-judge-evaluations.md](bedrock-judge-evaluations.md) for the rubric and Score_Scale details.

For each case, the platform fans out `1 + N + M` Converse calls:

- 1 GoalSuccessRate evaluator (session-level).
- N Helpfulness evaluators, one per assistant turn in the trace.
- M ToolSelectionAccuracy evaluators, one per `execute_tool` entry.

Score_Scale tables in `src/shared/utils/evaluation-scoring.ts` map categorical labels to `[0, 1]` decimals. Per-unit values are aggregated:
- `goalSuccessScore` = the GoalSuccessRate value directly.
- `helpfulnessScore` = unweighted arithmetic mean of N Helpfulness values.
- `toolAccuracyScore` = unweighted arithmetic mean of M ToolSelectionAccuracy values.

All values are clamped to `[0, 1]` before persisting.

### Error handling

If the trace has no assistant turns AND no `execute_tool` entries → `evaluationError: { code: "INSUFFICIENT_TRACE" }`.

If a Converse call returns a label not in the Score_Scale → `evaluationError: { code: "UNMAPPABLE_RESULT", reason: "..." }`. No silent zero substitution.

If one evaluator type completes but another fails → the produced scores are persisted, and `evaluationError: { code: "MISSING_EVALUATOR", missingEvaluators: [...] }` is set so the GUI can show the partial result. The run still completes — one bad case doesn't fail the run.

## Run record finalization

The run state machine writes a SUMMARY record at `PK=RUN#{runId}, SK=SUMMARY` with:
- `totalCases`, `passed`, `failed`, `errors`, `accuracy` (passed/total as percentage).
- `startTime`, `endTime`, total duration.
- `concurrency` used.
- `agentSnapshot` reference (runs persist the snapshot at `SK=SNAPSHOT`).
- `sfnExecutionArn` for traceability.

The run record's `status` transitions from `running` → one of `completed` / `failed` / `aborted`.
