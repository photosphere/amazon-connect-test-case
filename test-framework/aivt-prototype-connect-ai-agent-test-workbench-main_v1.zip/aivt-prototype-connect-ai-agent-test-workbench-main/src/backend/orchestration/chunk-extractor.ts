/**
 * Chunk Extractor — extracts retrieved passages from ListSpans execute_tool spans.
 *
 * Pure function: no I/O, no AWS SDK calls, never throws on well-formed input.
 * Produces one RetrievedChunk per text.value found in toolResult.values[] of
 * execute_tool spans whose tool name matches the configured Retrieve tool name.
 *
 * @module chunk-extractor
 */

import type { RawSpan } from "./span-parser";
import type { RetrievedChunk } from "../../shared/types";

/**
 * Citation metadata attached to a span text value by Q in Connect.
 * Mirrors the SDK's SpanCitation shape (only the fields we consume).
 */
interface SpanCitation {
  knowledgeBaseId?: string;
  contentId?: string;
  title?: string;
}

/**
 * Extended text value shape that includes optional citations array.
 * The base RawSpan interface models text as { value?: string } but the
 * actual ListSpans API response includes citations on the text object.
 */
interface TextValueWithCitations {
  value?: string;
  citations?: SpanCitation[];
}

/**
 * Extracts the tool name from an execute_tool span's inputMessages.
 * Returns undefined if no toolUse.name is found.
 */
function extractToolNameFromSpan(span: RawSpan): string | undefined {
  for (const msg of span.attributes?.inputMessages ?? []) {
    for (const v of msg.values ?? []) {
      if (v.toolUse?.name) {
        return v.toolUse.name;
      }
    }
  }
  return undefined;
}

/**
 * Extracts citation fields for a chunk from the text value's citations array.
 * Returns the first citation found, or undefined if none present.
 */
function extractCitationFromTextValue(
  textValue: TextValueWithCitations,
): SpanCitation | undefined {
  const citations = textValue.citations;
  if (!citations || citations.length === 0) return undefined;
  return citations[0];
}

/**
 * Extracts retrieved chunks from ListSpans execute_tool spans.
 *
 * Algorithm:
 * 1. Sort spans chronologically by startTimestamp
 * 2. Filter to execute_tool spans whose tool name matches retrieveToolName
 * 3. For each matching span, iterate outputMessages → values[] → toolResult.values[]
 * 4. For each toolResult value with a text.value, produce one RetrievedChunk
 * 5. Populate citation fields (knowledgeBaseId, contentId, title) from SpanCitation
 *    objects on the text value when present
 * 6. Assign monotonically increasing index across all chunks
 *
 * @param rawSpans - Raw spans from ListSpans
 * @param retrieveToolName - The name of the Retrieve tool to match
 * @returns Ordered array of RetrievedChunks
 */
export function extractRetrievedChunks(
  rawSpans: RawSpan[],
  retrieveToolName: string,
): RetrievedChunk[] {
  const chunks: RetrievedChunk[] = [];
  let globalIndex = 0;

  // Sort spans chronologically — startTimestamp may be a string, Date,
  // number, or absent. Coerce to string to safely compare.
  const sorted = rawSpans.slice().sort((a, b) => {
    const ta = String(a.startTimestamp ?? "");
    const tb = String(b.startTimestamp ?? "");
    return ta.localeCompare(tb);
  });

  for (const span of sorted) {
    if (span.spanName !== "execute_tool") continue;

    // Check if this span's tool name matches the Retrieve tool
    const toolName = extractToolNameFromSpan(span);
    if (toolName !== retrieveToolName) continue;

    // Iterate output messages → toolResult.values[]
    for (const msg of span.attributes?.outputMessages ?? []) {
      for (const value of msg.values ?? []) {
        if (!value.toolResult?.values) continue;
        for (const tv of value.toolResult.values) {
          // Cast to extended type that includes citations
          const textValue = tv.text as TextValueWithCitations | undefined;
          const text = textValue?.value;
          if (text === undefined) continue;

          // Extract citation fields from SpanCitation objects on this text value
          const citation = textValue
            ? extractCitationFromTextValue(textValue)
            : undefined;

          chunks.push({
            text,
            knowledgeBaseId: citation?.knowledgeBaseId,
            contentId: citation?.contentId,
            title: citation?.title,
            index: globalIndex,
          });
          globalIndex++;
        }
      }
    }
  }

  return chunks;
}
