import { describe, it, expect } from "vitest";
import {
  computeRagCaseStatus,
  DEFAULT_RAG_THRESHOLDS,
} from "@backend/orchestration/rag-decision";
import type { RagMetrics, RagThresholds } from "@backend/orchestration/rag-decision";

// ---------------------------------------------------------------------------
// computeRagCaseStatus — example-based unit tests
// ---------------------------------------------------------------------------

describe("computeRagCaseStatus", () => {
  const thresholds: RagThresholds = DEFAULT_RAG_THRESHOLDS; // all 0.7

  it("returns 'passed' when all metrics are above thresholds", () => {
    const metrics: RagMetrics = {
      faithfulness: 0.9,
      correctness: 0.85,
      completeness: 0.8,
      helpfulness: 0.75,
    };
    expect(computeRagCaseStatus(metrics, thresholds)).toBe("passed");
  });

  it("returns 'failed' when faithfulness is below threshold regardless of other metrics", () => {
    const metrics: RagMetrics = {
      faithfulness: 0.5, // below 0.7 threshold
      correctness: 1.0,
      completeness: 1.0,
      helpfulness: 1.0,
    };
    expect(computeRagCaseStatus(metrics, thresholds)).toBe("failed");
  });

  it("returns 'failed' when one non-faithfulness metric is below threshold", () => {
    const metrics: RagMetrics = {
      faithfulness: 0.9, // above threshold
      correctness: 0.9, // above threshold
      completeness: 0.5, // below 0.7 threshold
      helpfulness: 0.9, // above threshold
    };
    expect(computeRagCaseStatus(metrics, thresholds)).toBe("failed");
  });

  it("returns 'passed' when score exactly equals threshold (boundary)", () => {
    const metrics: RagMetrics = {
      faithfulness: 0.7,
      correctness: 0.7,
      completeness: 0.7,
      helpfulness: 0.7,
    };
    expect(computeRagCaseStatus(metrics, thresholds)).toBe("passed");
  });
});
