/**
 * Unit tests for the Customer Simulator module.
 *
 * Tests cover:
 * - Role flipping (customer→assistant, agent→user)
 * - System prompt rendering against the registry's `customer_simulator`
 *   default text (goal, style, customer knowledge)
 * - Style mapping for all communication styles
 * - Bedrock Converse call shape and error fallback behaviour
 *
 * The simulator resolves its prompt via `resolvePromptForRun(...)` per
 * Wave-2 of the prompt-management migration. These tests inject a stub
 * Prompts_Store via `_setPromptStore` so the resolver returns the
 * registry's bundled defaults without touching DynamoDB. Same pattern as
 * `tests/unit/suite-recommend.test.ts`.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { CommunicationStyle } from "../../src/shared/enums";
import type { TranscriptTurn, ToolSequenceTestCase } from "../../src/shared/types";
import {
  flipConversationRoles,
  buildSimulatorPrompt,
  simulateCustomer,
  STYLE_INSTRUCTIONS,
  _setBedrockClient,
} from "../../src/backend/orchestration/customer-simulator";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import { PROMPT_REGISTRY } from "../../src/backend/orchestration/prompt-registry";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";

// --- Test Fixtures ---

const RUN_ID = "run-customer-sim-test";

function makeTestCase(overrides: Partial<ToolSequenceTestCase> = {}): ToolSequenceTestCase {
  return {
    type: "tool_sequence",
    suiteId: "suite-1",
    caseId: "case-1",
    name: "Test Case",
    description: "A test case",
    persona: "banking customer",
    style: CommunicationStyle.DIRECT,
    customerKnowledge: {
      "account number": "1234-5678",
      "last 4 SSN": "9876",
    },
    initialUtterance: "I want to check my account balance",
    successCriteria: [{ toolName: "CheckBalance", required: true }],
    ...overrides,
  };
}

function makeHistory(): TranscriptTurn[] {
  return [
    {
      turnNumber: 1,
      role: "customer",
      text: "I want to check my balance",
      timestamp: "2024-01-01T00:00:00Z",
      elapsedMs: 0,
    },
    {
      turnNumber: 2,
      role: "agent",
      text: "Sure, I can help with that. What is your account number?",
      timestamp: "2024-01-01T00:00:01Z",
      elapsedMs: 1000,
    },
    {
      turnNumber: 3,
      role: "customer",
      text: "It's 1234-5678",
      timestamp: "2024-01-01T00:00:02Z",
      elapsedMs: 2000,
    },
  ];
}

/**
 * Inject a stub Prompts_Store so `resolvePromptForRun("customer_simulator", ...)`
 * returns the registry's bundled defaults without touching DynamoDB.
 *
 * The simulator uses `resolvePromptForRun`, which reads the run snapshot
 * first and falls back to the live registry. We wire `getSnapshot` to
 * return null so the resolver always traverses the live-registry
 * fallback path, then return an empty overrides map so the resolver
 * yields the bundled `customer_simulator` definition (Claude Haiku 4.5,
 * default text, default inference values).
 */
function injectDefaultPromptStore(): void {
  _clearPromptRegistryCaches();
  const store = {
    getSnapshot: vi.fn().mockResolvedValue(null),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  } as unknown as DynamoDBService;
  _setPromptRegistryStore(store);
}

// --- Tests ---

describe("flipConversationRoles", () => {
  it("flips customer turns to assistant role", () => {
    const history: TranscriptTurn[] = [
      {
        turnNumber: 1,
        role: "customer",
        text: "Hello, I need help",
        timestamp: "2024-01-01T00:00:00Z",
        elapsedMs: 0,
      },
    ];

    const result = flipConversationRoles(history);

    expect(result).toHaveLength(1);
    expect(result[0].role).toBe("assistant");
    expect(result[0].content).toEqual([{ text: "Hello, I need help" }]);
  });

  it("flips agent turns to user role", () => {
    const history: TranscriptTurn[] = [
      {
        turnNumber: 1,
        role: "agent",
        text: "How can I help you today?",
        timestamp: "2024-01-01T00:00:00Z",
        elapsedMs: 0,
      },
    ];

    const result = flipConversationRoles(history);

    expect(result).toHaveLength(1);
    expect(result[0].role).toBe("user");
    expect(result[0].content).toEqual([{ text: "How can I help you today?" }]);
  });

  it("preserves text content unchanged during flipping", () => {
    const history = makeHistory();
    const result = flipConversationRoles(history);

    expect(result[0].content).toEqual([{ text: "I want to check my balance" }]);
    expect(result[1].content).toEqual([
      { text: "Sure, I can help with that. What is your account number?" },
    ]);
    expect(result[2].content).toEqual([{ text: "It's 1234-5678" }]);
  });

  it("handles multi-turn conversation with alternating roles", () => {
    const history = makeHistory();
    const result = flipConversationRoles(history);

    expect(result).toHaveLength(3);
    expect(result[0].role).toBe("assistant"); // customer → assistant
    expect(result[1].role).toBe("user"); // agent → user
    expect(result[2].role).toBe("assistant"); // customer → assistant
  });

  it("returns empty array for empty history", () => {
    const result = flipConversationRoles([]);
    expect(result).toEqual([]);
  });
});

describe("buildSimulatorPrompt", () => {
  it("includes the test case goal (initial utterance)", () => {
    const testCase = makeTestCase({
      initialUtterance: "I want to transfer money",
    });

    const prompt = buildSimulatorPrompt(testCase);

    expect(prompt).toContain("I want to transfer money");
  });

  it("includes the style instruction for the communication style", () => {
    const testCase = makeTestCase({ style: CommunicationStyle.COMPLAINT });

    const prompt = buildSimulatorPrompt(testCase);

    expect(prompt).toContain(STYLE_INSTRUCTIONS[CommunicationStyle.COMPLAINT]);
  });

  it("includes customer knowledge as personal details", () => {
    const testCase = makeTestCase({
      customerKnowledge: {
        "account number": "1234-5678",
        "last 4 SSN": "9876",
      },
    });

    const prompt = buildSimulatorPrompt(testCase);

    expect(prompt).toContain("- account number: 1234-5678");
    expect(prompt).toContain("- last 4 SSN: 9876");
  });

  it("instructs model to reveal details only when asked", () => {
    const testCase = makeTestCase();

    const prompt = buildSimulatorPrompt(testCase);

    expect(prompt).toContain("ONLY when the assistant asks");
  });

  it("handles empty customer knowledge", () => {
    const testCase = makeTestCase({ customerKnowledge: {} });

    const prompt = buildSimulatorPrompt(testCase);

    expect(prompt).toContain("No specific personal details provided");
  });

  it("includes all style instructions for each communication style", () => {
    for (const style of Object.values(CommunicationStyle)) {
      const testCase = makeTestCase({ style });
      const prompt = buildSimulatorPrompt(testCase);
      expect(prompt).toContain(STYLE_INSTRUCTIONS[style]);
    }
  });
});

describe("STYLE_INSTRUCTIONS", () => {
  it("has an entry for every CommunicationStyle", () => {
    for (const style of Object.values(CommunicationStyle)) {
      expect(STYLE_INSTRUCTIONS[style]).toBeDefined();
      expect(STYLE_INSTRUCTIONS[style].length).toBeGreaterThan(0);
    }
  });

  it("direct style emphasizes clarity", () => {
    expect(STYLE_INSTRUCTIONS[CommunicationStyle.DIRECT]).toMatch(/clear|to-the-point|exact/i);
  });

  it("indirect style emphasizes describing without naming", () => {
    expect(STYLE_INSTRUCTIONS[CommunicationStyle.INDIRECT]).toMatch(/hint|without naming|describe/i);
  });

  it("colloquial style emphasizes casual language", () => {
    expect(STYLE_INSTRUCTIONS[CommunicationStyle.COLLOQUIAL]).toMatch(/casual|slang|informal/i);
  });

  it("question style emphasizes asking", () => {
    expect(STYLE_INSTRUCTIONS[CommunicationStyle.QUESTION]).toMatch(/question|ask/i);
  });

  it("complaint style emphasizes frustration", () => {
    expect(STYLE_INSTRUCTIONS[CommunicationStyle.COMPLAINT]).toMatch(/frustrat|complain|dissatisf/i);
  });
});

describe("simulateCustomer", () => {
  beforeEach(() => {
    _setBedrockClient(null);
    injectDefaultPromptStore();
  });

  afterEach(() => {
    _setBedrockClient(null);
    _setPromptRegistryStore(null);
    _clearPromptRegistryCaches();
  });

  it("throws when Bedrock client fails (halts the test)", async () => {
    // Create a mock client that throws
    const mockClient = {
      send: vi.fn().mockRejectedValue(new Error("Service unavailable")),
    } as unknown as Parameters<typeof _setBedrockClient>[0];

    _setBedrockClient(mockClient!);

    const testCase = makeTestCase();

    await expect(
      simulateCustomer("What is your account number?", testCase, [], RUN_ID)
    ).rejects.toThrow(/Customer simulator failed/);
  });

  it("returns response text from successful Bedrock call", async () => {
    const mockClient = {
      send: vi.fn().mockResolvedValue({
        output: {
          message: {
            content: [{ text: "My account number is 1234-5678" }],
          },
        },
      }),
    } as unknown as Parameters<typeof _setBedrockClient>[0];

    _setBedrockClient(mockClient!);

    const testCase = makeTestCase();
    const result = await simulateCustomer(
      "What is your account number?",
      testCase,
      makeHistory(),
      RUN_ID
    );

    expect(result).toBe("My account number is 1234-5678");
  });

  it("trims whitespace from response text", async () => {
    const mockClient = {
      send: vi.fn().mockResolvedValue({
        output: {
          message: {
            content: [{ text: "  Sure, it's 9876  " }],
          },
        },
      }),
    } as unknown as Parameters<typeof _setBedrockClient>[0];

    _setBedrockClient(mockClient!);

    const testCase = makeTestCase();
    const result = await simulateCustomer("What's your SSN?", testCase, [], RUN_ID);

    expect(result).toBe("Sure, it's 9876");
  });

  it("returns fallback when response has empty content", async () => {
    const mockClient = {
      send: vi.fn().mockResolvedValue({
        output: {
          message: {
            content: [],
          },
        },
      }),
    } as unknown as Parameters<typeof _setBedrockClient>[0];

    _setBedrockClient(mockClient!);

    const testCase = makeTestCase();
    const result = await simulateCustomer("Hello?", testCase, [], RUN_ID);

    expect(result).toBe("Yes, please proceed");
  });

  it("passes correct messages structure and registry-resolved Converse shape to Bedrock", async () => {
    const sendMock = vi.fn().mockResolvedValue({
      output: {
        message: {
          content: [{ text: "Yes" }],
        },
      },
    });

    const mockClient = { send: sendMock } as unknown as Parameters<
      typeof _setBedrockClient
    >[0];
    _setBedrockClient(mockClient!);

    const testCase = makeTestCase();
    const history: TranscriptTurn[] = [
      {
        turnNumber: 1,
        role: "customer",
        text: "I need help",
        timestamp: "2024-01-01T00:00:00Z",
        elapsedMs: 0,
      },
    ];

    await simulateCustomer("How can I help?", testCase, history, RUN_ID);

    expect(sendMock).toHaveBeenCalledTimes(1);
    const command = sendMock.mock.calls[0][0];
    const input = command.input;

    // Verify messages: flipped history + agent message as final user turn
    expect(input.messages).toHaveLength(2);
    expect(input.messages[0]).toEqual({
      role: "assistant",
      content: [{ text: "I need help" }],
    });
    expect(input.messages[1]).toEqual({
      role: "user",
      content: [{ text: "How can I help?" }],
    });

    // The registry's bundled `customer_simulator` default points at the
    // `claude_haiku_4_5` model whose capability profile is
    // `anthropic_claude_4x` — so `buildInferenceConfig` emits exactly
    // `{ inferenceConfig: { maxTokens: 150 } }` with no `temperature`,
    // `topP`, `topK`, or `stopSequences`. The 0.7 `temperature` value
    // declared in the registry's `defaultInferenceValues` is silently
    // dropped per R17.4 (the Anthropic 4.x profile forbids it).
    const definition = PROMPT_REGISTRY.customer_simulator;
    expect(input.inferenceConfig.maxTokens).toBe(
      definition.defaultInferenceValues.maxTokens,
    );
    expect(input.inferenceConfig.temperature).toBeUndefined();
    expect(input.additionalModelRequestFields).toBeUndefined();

    // Verify the modelId comes from the registry's resolved
    // SupportedModel entry, not from a hard-coded literal or env var.
    expect(input.modelId).toMatch(/^us\.anthropic\.claude-haiku/);

    // Verify the system prompt was rendered from the registry's
    // bundled default text with the four declared placeholders
    // substituted (no leftover `{name}` tokens).
    const systemText = input.system?.[0]?.text ?? "";
    expect(systemText).toContain(testCase.initialUtterance);
    expect(systemText).toContain(STYLE_INSTRUCTIONS[testCase.style]);
    expect(systemText).not.toMatch(/\{scenario\}/);
    expect(systemText).not.toMatch(/\{opening_line\}/);
    expect(systemText).not.toMatch(/\{style_instruction\}/);
    expect(systemText).not.toMatch(/\{customer_details\}/);
  });

  it("logs error and rethrows on failure (does not silently fall back)", async () => {
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    const mockClient = {
      send: vi.fn().mockRejectedValue(new Error("Timeout")),
    } as unknown as Parameters<typeof _setBedrockClient>[0];
    _setBedrockClient(mockClient!);

    const testCase = makeTestCase();

    await expect(
      simulateCustomer("Hello", testCase, [], RUN_ID)
    ).rejects.toThrow(/Customer simulator failed/);

    expect(consoleSpy).toHaveBeenCalledWith(
      "[customer-simulator] Bedrock Converse call failed — halting test:",
      "Timeout"
    );

    consoleSpy.mockRestore();
  });
});
