// @vitest-environment jsdom
/**
 * Component tests for the Prompts list page (task 13.10).
 *
 * Validates:
 *  - **Requirement 13.2** — Cloudscape Table renders columns over `name`,
 *    `category`, `currentModelDisplayName`, and the `isOverridden` status
 *    badge using the data returned by `GET /prompts`.
 *  - **Requirement 13.3** — initial sort is by category then name
 *    ascending, case-insensitive (the page sorts client-side as well so
 *    the rendered order is deterministic regardless of backend order).
 *  - **Requirement 13.4** — clicking a row navigates to
 *    `/prompts/{promptKey}` (verified via the mocked `useNavigate`).
 *  - **Requirement 13.5** — while `listPrompts()` is in flight the page
 *    renders a loading StatusIndicator and no table rows.
 *  - **Requirement 13.6** — when `listPrompts()` rejects, the page
 *    surfaces a Cloudscape Alert with header "Could not load prompts"
 *    and a Retry button that re-issues the request.
 *  - **Requirement 13.7** — when the response is empty, the page renders
 *    a "No prompts available" empty state rather than rows.
 *
 * The only mocked seams are the typed `prompts` API client wrappers (so
 * the test does not hit the network) and the `react-router-dom`
 * `useNavigate` hook (so we can assert the navigation target). Every
 * other module — the Cloudscape Table, the Alert, the StatusIndicator,
 * the page's sort/filter logic — runs as in production.
 */

import React from 'react';
import {
  describe,
  it,
  expect,
  beforeAll,
  beforeEach,
  afterEach,
  vi,
} from 'vitest';
import {
  render,
  screen,
  waitFor,
  cleanup,
  fireEvent,
} from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

// ---------------------------------------------------------------------------
// Mock the API barrel BEFORE importing the page module so the page picks up
// the mocked wrappers. `vi.mock` is hoisted above all imports, so the mock
// fns are declared via `vi.hoisted` to be safely referenced from the factory.
// ---------------------------------------------------------------------------

const {
  listPromptsMock,
  getPromptMock,
  updatePromptMock,
  resetPromptMock,
  getHistoryMock,
  getActiveRunsMock,
} = vi.hoisted(() => ({
  listPromptsMock: vi.fn(),
  getPromptMock: vi.fn(),
  updatePromptMock: vi.fn(),
  resetPromptMock: vi.fn(),
  getHistoryMock: vi.fn(),
  getActiveRunsMock: vi.fn(),
}));

vi.mock('../../../src/frontend/src/api', () => {
  // Reproduce the real ApiClientError / PromptApiError shapes that the page
  // narrows on (`err instanceof PromptApiError` / `instanceof ApiClientError`).
  // The page only branches on the constructor identity to pick a message
  // formatter; behavior is otherwise opaque to the test.
  class MockApiClientError extends Error {
    public readonly status: number;
    public readonly retryable: boolean;
    public readonly code?: string;
    public readonly details?: Record<string, unknown>;
    constructor(
      status: number,
      message: string,
      retryable: boolean,
      options?: { code?: string; details?: Record<string, unknown> },
    ) {
      super(message);
      this.name = 'ApiClientError';
      this.status = status;
      this.retryable = retryable;
      this.code = options?.code;
      this.details = options?.details;
    }
  }
  class MockRuntimeConfigUnavailableError extends Error {
    constructor(message = 'Runtime configuration unavailable.') {
      super(message);
      this.name = 'RuntimeConfigUnavailableError';
    }
  }
  class MockPromptApiError extends Error {
    public readonly code: string;
    public readonly httpStatus: number;
    public readonly details?: Record<string, unknown>;
    constructor(args: {
      message: string;
      code: string;
      httpStatus: number;
      details?: Record<string, unknown>;
    }) {
      super(args.message);
      this.name = 'PromptApiError';
      this.code = args.code;
      this.httpStatus = args.httpStatus;
      this.details = args.details;
    }
  }
  return {
    apiClient: {
      get: vi.fn(),
      post: vi.fn(),
      put: vi.fn(),
      delete: vi.fn(),
    },
    ApiClientError: MockApiClientError,
    RuntimeConfigUnavailableError: MockRuntimeConfigUnavailableError,
    PromptApiError: MockPromptApiError,
    loadConfig: vi.fn(),
    getConfig: vi.fn(),
    getConfigStatus: vi.fn(),
    subscribeToNotifications: vi.fn(() => () => {}),
    notifyError: vi.fn(),
    listPrompts: listPromptsMock,
    getPrompt: getPromptMock,
    updatePrompt: updatePromptMock,
    resetPrompt: resetPromptMock,
    getHistory: getHistoryMock,
    getActiveRuns: getActiveRunsMock,
  };
});

// The page also imports `PromptApiError` from the prompts module directly
// (`from '../api/prompts'`) — re-export the same mock class through that
// path so the `instanceof` narrow inside the page works on either import.
vi.mock('../../../src/frontend/src/api/prompts', async () => {
  const barrel: any = await import('../../../src/frontend/src/api');
  return {
    PromptApiError: barrel.PromptApiError,
    listPrompts: barrel.listPrompts,
    getPrompt: barrel.getPrompt,
    updatePrompt: barrel.updatePrompt,
    resetPrompt: barrel.resetPrompt,
    getHistory: barrel.getHistory,
    getActiveRuns: barrel.getActiveRuns,
  };
});

// ---------------------------------------------------------------------------
// Mock react-router-dom — see results-comparison.test.tsx for the rationale
// (the frontend ships its own React copy under src/frontend/node_modules,
// which would produce two React copies in one render tree if the real
// router hooks were imported). We expose `useNavigate` as a vi.fn so the
// tests can assert on the navigation target directly.
// ---------------------------------------------------------------------------

const { navigateMock } = vi.hoisted(() => ({ navigateMock: vi.fn() }));

vi.mock('react-router-dom', () => ({
  useNavigate: () => navigateMock,
  useParams: () => ({}),
}));

// Page module is imported AFTER the vi.mock calls above so it receives the
// mocked api barrel and the stubbed router hooks.
import { PromptsListPage } from '../../../src/frontend/src/pages/PromptsListPage';
import { ApiClientError } from '../../../src/frontend/src/api';

// ---------------------------------------------------------------------------
// jsdom polyfills required by Cloudscape components (mirrors the setup in
// tests/unit/frontend/results-comparison.test.tsx).
// ---------------------------------------------------------------------------

beforeAll(() => {
  const g = globalThis as unknown as {
    ResizeObserver?: unknown;
    IntersectionObserver?: unknown;
  };
  if (typeof g.ResizeObserver === 'undefined') {
    g.ResizeObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
    };
  }
  if (typeof g.IntersectionObserver === 'undefined') {
    g.IntersectionObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
      takeRecords(): unknown[] {
        return [];
      }
      readonly root = null;
      readonly rootMargin = '';
      readonly thresholds: ReadonlyArray<number> = [];
    };
  }
  if (typeof window.matchMedia !== 'function') {
    window.matchMedia = (query: string) =>
      ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => {},
        removeListener: () => {},
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => false,
      }) as MediaQueryList;
  }
});

beforeEach(() => {
  listPromptsMock.mockReset();
  getPromptMock.mockReset();
  updatePromptMock.mockReset();
  resetPromptMock.mockReset();
  getHistoryMock.mockReset();
  getActiveRunsMock.mockReset();
  navigateMock.mockReset();
});

afterEach(() => {
  cleanup();
});

// ---------------------------------------------------------------------------
// Fixture builders
// ---------------------------------------------------------------------------

function buildPromptListItem(overrides: Record<string, unknown> = {}) {
  return {
    promptKey: 'failure_analysis',
    name: 'Failure Analysis',
    category: 'analysis',
    description: 'Analyses failed cases.',
    defaultModelKey: 'claude_sonnet_4_6',
    currentModelKey: 'claude_sonnet_4_6',
    defaultModelDisplayName: 'Claude Sonnet 4.6',
    currentModelDisplayName: 'Claude Sonnet 4.6',
    lastModifiedAt: null,
    lastModifiedBy: null,
    version: 0,
    isOverridden: false,
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('PromptsListPage', () => {
  it('renders a loading StatusIndicator while listPrompts is in flight (R13.5)', async () => {
    // Hold the listPrompts response open so the page stays in the loading
    // branch for the duration of the assertion.
    let resolveList: (value: { prompts: unknown[] }) => void = () => {};
    listPromptsMock.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          resolveList = resolve;
        }),
    );

    render(<PromptsListPage />);

    // The loading branch renders a Cloudscape StatusIndicator with the text
    // "Loading prompts…" and intentionally omits the Table chrome so rows
    // are demonstrably hidden.
    expect(await screen.findByText(/loading prompts/i)).toBeInTheDocument();
    expect(screen.queryByRole('table')).not.toBeInTheDocument();

    // Resolve so the test cleanup can flush pending state updates.
    resolveList({ prompts: [] });
    await waitFor(() => expect(listPromptsMock).toHaveBeenCalled());
  });

  it('renders the empty state when listPrompts returns no entries (R13.7)', async () => {
    listPromptsMock.mockResolvedValueOnce({ prompts: [] });

    render(<PromptsListPage />);

    // The empty state renders a `<b>` reading "No prompts available"
    // inside the Cloudscape Table's empty slot per the page contract.
    expect(
      await screen.findByText(/no prompts available/i),
    ).toBeInTheDocument();
    // The header row counter reads "(0)" since the Table has no items.
    await waitFor(() => {
      // Cloudscape renders the counter alongside the "Prompts" header
      // section — assert directly on the raw "(0)" string.
      expect(screen.getByText('(0)')).toBeInTheDocument();
    });
  });

  it('renders a "Could not load prompts" Alert when listPrompts rejects (R13.6)', async () => {
    // First call rejects; the page surfaces the Alert. The Retry button
    // re-issues the same request, which we resolve to assert the page can
    // recover from the error state.
    listPromptsMock.mockRejectedValueOnce(
      new ApiClientError(500, 'boom', true),
    );
    listPromptsMock.mockResolvedValueOnce({
      prompts: [buildPromptListItem()],
    });

    render(<PromptsListPage />);

    expect(
      await screen.findByText(/could not load prompts/i),
    ).toBeInTheDocument();
    // The Alert's body shows the error's message.
    expect(screen.getByText('boom')).toBeInTheDocument();

    // Click Retry → the second mocked response should land and the table
    // replaces the alert.
    fireEvent.click(screen.getByRole('button', { name: /retry/i }));
    expect(await screen.findByText('Failure Analysis')).toBeInTheDocument();
    expect(listPromptsMock).toHaveBeenCalledTimes(2);
  });

  it('renders the table with name, category, model and status badge columns (R13.2, R13.3)', async () => {
    // Three prompts spanning two categories; second pair tests the
    // case-insensitive (`category`, `name`) sort because the API returns
    // them in arbitrary order.
    const prompts = [
      buildPromptListItem({
        promptKey: 'suite_recommendation',
        name: 'Suite Recommendation',
        category: 'recommendation',
        currentModelDisplayName: 'Claude Sonnet 4.6',
        isOverridden: true,
        lastModifiedAt: '2024-05-01T12:34:56.000Z',
        lastModifiedBy: 'sub-1234',
        version: 3,
      }),
      buildPromptListItem({
        promptKey: 'comparison_summary',
        name: 'Comparison Summary',
        category: 'analysis',
        currentModelDisplayName: 'Claude Haiku 4.5',
      }),
      buildPromptListItem({
        promptKey: 'failure_analysis',
        name: 'Failure Analysis',
        category: 'analysis',
        currentModelDisplayName: 'Claude Sonnet 4.6',
      }),
    ];
    listPromptsMock.mockResolvedValueOnce({ prompts });

    render(<PromptsListPage />);

    // Wait for the first row to render so we know the response landed.
    await screen.findByText('Comparison Summary');

    // Column headers — verify every column the requirement mandates.
    expect(
      screen.getByRole('columnheader', { name: /^name$/i }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('columnheader', { name: /^category$/i }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('columnheader', { name: /^model$/i }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('columnheader', { name: /^status$/i }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('columnheader', { name: /last modified$/i }),
    ).toBeInTheDocument();

    // Rows render every prompt's name, category and model.
    expect(screen.getByText('Comparison Summary')).toBeInTheDocument();
    expect(screen.getByText('Failure Analysis')).toBeInTheDocument();
    expect(screen.getByText('Suite Recommendation')).toBeInTheDocument();
    // Two analysis prompts and one recommendation — both category labels
    // appear at least once.
    expect(screen.getAllByText('analysis').length).toBeGreaterThanOrEqual(2);
    expect(screen.getByText('recommendation')).toBeInTheDocument();
    // Status badge text — one Override (the seeded suite recommendation)
    // and the rest Default.
    expect(screen.getByText('Override')).toBeInTheDocument();
    expect(screen.getAllByText('Default').length).toBe(2);

    // Sort order: category-then-name ascending case-insensitive ⇒
    // [Comparison Summary, Failure Analysis, Suite Recommendation].
    const rows = screen.getAllByRole('row');
    // rows[0] is the header row; rows[1..] are the data rows.
    expect(rows[1]).toHaveTextContent('Comparison Summary');
    expect(rows[2]).toHaveTextContent('Failure Analysis');
    expect(rows[3]).toHaveTextContent('Suite Recommendation');
  });

  it('navigates to /prompts/{promptKey} when a row is clicked (R13.4)', async () => {
    const prompt = buildPromptListItem({
      promptKey: 'failure_analysis',
      name: 'Failure Analysis',
    });
    listPromptsMock.mockResolvedValueOnce({ prompts: [prompt] });

    render(<PromptsListPage />);
    await screen.findByText('Failure Analysis');

    // Cloudscape Table fires `onRowClick` when a `<tr>` (other than the
    // header row) is clicked. Click the data row directly — the page
    // wires `onRowClick` to call `navigate(/prompts/{key})`.
    const rows = screen.getAllByRole('row');
    // Row 0 is the header; row 1 is the only data row.
    fireEvent.click(rows[1]);

    await waitFor(() => {
      expect(navigateMock).toHaveBeenCalledWith('/prompts/failure_analysis');
    });
  });
});
