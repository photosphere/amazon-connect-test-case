/**
 * Integration tests for RAG test case flows.
 *
 * These tests exercise multiple modules working together with mocked AWS services
 * (no real network calls). Each test verifies a cross-module data flow critical
 * to the RAG feature:
 *
 * 1. Conversation Driver RAG mode — single-turn flow via mocked QConnect.
 * 2. Stage 2 pipeline — mocked Bedrock RAG Evaluation APIs end-to-end.
 * 3. State machine conditional branch — suites with/without RAG cases.
 * 4. Error code propagation — failure modes produce correct DDB records.
 * 5. Opportunistic Faithfulness — tool-sequence cases with/without Retrieve.
 *
 * @validates Requirements 3.1, 3.2, 3.7, 4.1, 4.6, 8.1, 8.2, 8.3, 8.4, 8.5, 12.1, 12.8, 12.11
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { QConnectClient } from "@aws-sdk/client-qconnect";
import { ConnectClient } from "@aws-sdk/client-connect";

// ---------------------------------------------------------------------------
// Mock constants for fast tests (must be before module imports)
// ---------------------------------------------------------------------------

vi.mock("../../src/shared/constants", async (importOriginal) => {
  const original = await importOriginal<typeof import("../../src/shared/constants")>();
  return {
    ...original,
    RAG_JOB_POLL_INTERVAL_MS: 0,
    RAG_JOB_TIMEOUT_MS: 100,
    POLL_INTERVAL_MS: 0,
    POLL_TIMEOUT_MS: 5000,
  };
});

// Environment variables (before module load). Wave 3 (Task 20.3) retired
// the `JUDGE_MODEL_ID` env var: `rag-evaluate.ts` resolves the evaluator
// model id through the Prompt_Registry rather than from an env var.
process.env.RAG_JOB_BUCKET = "test-rag-bucket";
process.env.TABLE_NAME = "TestTable";
process.env.AWS_REGION = "us-east-1";
process.env.CONNECT_INSTANCE_ID = "instance-test-001";
process.env.CONTACT_CREATOR_FLOW_ID = "flow-test-001";
process.env.ASSISTANT_ID = "asst-test-001";

// ---------------------------------------------------------------------------
// Module imports (after env setup)
// ---------------------------------------------------------------------------

import {
  handler as conversationDriverHandler,
  _setQConnectClient as setConversationQClient,
  _setDynamoService as setConversationDynamoService,
  type ConversationDriverEvent,
} from "../../src/backend/orchestration/conversation-driver";
import {
  _setConnectClient as setContactConnectClient,
} from "../../src/backend/orchestration/contact-manager";
import {
  _setBedrockClient as setFaithfulnessBedrockClient,
} from "../../src/backend/orchestration/opportunistic-faithfulness";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";
import {
  handler as ragEvaluateHandler,
  _setS3Client,
  _setBedrockClient as setRagBedrockClient,
  _setDocClient,
  type RagEvaluateInput,
  type RagCaseData,
} from "../../src/backend/orchestration/rag-evaluate";
import type { RagThresholds, RagTestCase } from "../../src/shared/types";
import { CaseStatus } from "../../src/shared/enums";

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

function createMockClient<T>(sendFn: (command: unknown) => Promise<unknown>): T {
  return { send: sendFn } as unknown as T;
}

function makeMockConnectClient(): ConnectClient {
  return createMockClient<ConnectClient>(
    vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      if (cmd.constructor.name === "StartChatContactCommand") {
        return Promise.resolve({ ContactId: "contact-rag-test-001" });
      }
      return Promise.resolve({});
    }),
  );
}

// ---------------------------------------------------------------------------
// 1. Conversation Driver RAG mode — single-turn flow
// ---------------------------------------------------------------------------

describe("Integration: Conversation Driver RAG mode — single-turn flow", () => {
  const ragCase: RagTestCase = {
    type: "rag",
    suiteId: "suite-rag-001",
    caseId: "case-rag-001",
    name: "Return policy question",
    description: "Verifies the agent answers return policy correctly",
    question: "What is your return policy?",
    groundTruthAnswer: "You can return items within 30 days of purchase for a full refund.",
  };

  beforeEach(() => {
    setContactConnectClient(makeMockConnectClient());
  });

  afterEach(() => {
    setConversationQClient(null);
    setContactConnectClient(null);
    setConversationDynamoService(null);
    vi.restoreAllMocks();
  });

  it("executes single-turn RAG flow: CreateSession → SendMessage → poll → ListSpans → chunks extracted", async () => {
    const capturedCalls: Array<{ name: string; input: Record<string, unknown> }> = [];

    const mockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
      capturedCalls.push({ name: cmd.constructor.name, input: cmd.input });

      if (cmd.constructor.name === "CreateSessionCommand") {
        return Promise.resolve({
          session: { sessionId: "session-rag-001" },
        });
      }

      if (cmd.constructor.name === "SendMessageCommand") {
        return Promise.resolve({ nextMessageToken: "token-rag-1" });
      }

      if (cmd.constructor.name === "GetNextMessageCommand") {
        return Promise.resolve({
          response: { value: { text: { value: "Our return policy allows returns within 30 days of purchase for a full refund." } } },
          conversationSessionData: [],
          nextMessageToken: "token-rag-done",
          conversationState: { status: "READY" },
        });
      }

      if (cmd.constructor.name === "ListSpansCommand") {
        return Promise.resolve({
          spans: [
            {
              spanName: "execute_tool",
              startTimestamp: "2024-01-01T00:00:01.000Z",
              attributes: {
                aiAgentName: "ReturnAgent",
                aiAgentType: "ORCHESTRATION",
                inputMessages: [
                  { values: [{ toolUse: { name: "Retrieve", arguments: '{"query":"return policy"}' } }] },
                ],
                outputMessages: [
                  {
                    values: [
                      {
                        toolResult: {
                          values: [
                            { text: { value: "Return policy: Items can be returned within 30 days of purchase." } },
                            { text: { value: "Refund policy: Full refund for items returned in original condition." } },
                          ],
                        },
                      },
                    ],
                  },
                ],
              },
            },
          ],
        });
      }

      return Promise.resolve({});
    });

    setConversationQClient(createMockClient<QConnectClient>(mockSend));

    // Mock DynamoService to provide agent snapshot with Retrieve tool
    const mockDynamoService = {
      getSnapshot: vi.fn().mockResolvedValue({
        tools: [
          { toolName: "Retrieve", toolType: "KNOWLEDGE_BASE", description: "Retrieve from KB", examples: [] },
          { toolName: "Complete", toolType: "LAMBDA", description: "Complete conversation", examples: [] },
        ],
        systemPrompt: "You are a helpful agent.",
        modelId: "us.anthropic.claude-sonnet-4-6",
        capturedAt: "2024-01-01T00:00:00.000Z",
      }),
    };
    setConversationDynamoService(mockDynamoService as any);

    const event: ConversationDriverEvent = {
      caseId: ragCase.caseId,
      testCase: ragCase,
      runId: "run-rag-integ-001",
      agentId: "agent-rag-001",
      assistantId: "asst-rag-001",
      retrieveToolName: "Retrieve",
    };

    const result = await conversationDriverHandler(event);

    // Verify single-turn flow
    expect(result.caseId).toBe("case-rag-001");
    expect(result.caseType).toBe("rag");
    expect(result.status).not.toBe(CaseStatus.ERROR);

    // Verify chunks extracted correctly (2 chunks from the Retrieve span)
    expect(result.retrievedChunks).toBeDefined();
    expect(result.retrievedChunks).toHaveLength(2);
    expect(result.retrievedChunks![0].text).toBe("Return policy: Items can be returned within 30 days of purchase.");
    expect(result.retrievedChunks![1].text).toBe("Refund policy: Full refund for items returned in original condition.");
    expect(result.retrievedChunks![0].index).toBe(0);
    expect(result.retrievedChunks![1].index).toBe(1);

    // Verify transcript: single customer turn + single agent turn
    expect(result.turnCount).toBe(2);

    // Verify no Customer_Simulator was invoked (single-turn, no multi-turn)
    const sendMessageCalls = capturedCalls.filter((c) => c.name === "SendMessageCommand");
    expect(sendMessageCalls).toHaveLength(1);
    // The single message should be the question
    expect(sendMessageCalls[0].input.message).toEqual({
      value: { text: { value: ragCase.question } },
    });

    // Verify session lifecycle: CreateSession + SendMessage + GetNextMessage + ListSpans
    const callNames = capturedCalls.map((c) => c.name);
    expect(callNames).toContain("CreateSessionCommand");
    expect(callNames).toContain("SendMessageCommand");
    expect(callNames).toContain("GetNextMessageCommand");
    expect(callNames).toContain("ListSpansCommand");
  });

  it("does NOT invoke the Customer_Simulator for RAG cases", async () => {
    // Mock the customer simulator module — it should NEVER be called
    const simulatorSpy = vi.fn();
    vi.mock("../../src/backend/orchestration/customer-simulator", () => ({
      simulateCustomer: simulatorSpy,
    }));

    const mockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };

      if (cmd.constructor.name === "CreateSessionCommand") {
        return Promise.resolve({ session: { sessionId: "session-rag-002" } });
      }
      if (cmd.constructor.name === "SendMessageCommand") {
        return Promise.resolve({ nextMessageToken: "token-2" });
      }
      if (cmd.constructor.name === "GetNextMessageCommand") {
        return Promise.resolve({
          response: { value: { text: { value: "Here is your answer." } } },
          conversationSessionData: [],
          nextMessageToken: "token-done",
          conversationState: { status: "READY" },
        });
      }
      if (cmd.constructor.name === "ListSpansCommand") {
        return Promise.resolve({ spans: [] });
      }
      return Promise.resolve({});
    });

    setConversationQClient(createMockClient<QConnectClient>(mockSend));
    setConversationDynamoService({ getSnapshot: vi.fn().mockResolvedValue(null) } as any);

    const event: ConversationDriverEvent = {
      caseId: ragCase.caseId,
      testCase: ragCase,
      runId: "run-no-sim",
      agentId: "agent-001",
      assistantId: "asst-001",
    };

    await conversationDriverHandler(event);

    // The customer simulator should never be called for RAG cases
    expect(simulatorSpy).not.toHaveBeenCalled();
  });

  it("sets status=error and populates errorMessage when session creation fails", async () => {
    const mockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      if (cmd.constructor.name === "CreateSessionCommand") {
        return Promise.reject(new Error("Session creation timeout"));
      }
      // StartChatContact still works
      if (cmd.constructor.name === "StartChatContactCommand") {
        return Promise.resolve({ ContactId: "contact-err" });
      }
      return Promise.resolve({});
    });

    setConversationQClient(createMockClient<QConnectClient>(mockSend));
    setConversationDynamoService({ getSnapshot: vi.fn().mockResolvedValue(null) } as any);

    const event: ConversationDriverEvent = {
      caseId: ragCase.caseId,
      testCase: ragCase,
      runId: "run-err",
      agentId: "agent-001",
      assistantId: "asst-001",
    };

    const result = await conversationDriverHandler(event);

    expect(result.status).toBe(CaseStatus.ERROR);
    expect(result.errorMessage).toContain("Session creation timeout");
    expect(result.caseType).toBe("rag");
    // retrievedChunks should be unset on error
    expect(result.retrievedChunks).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// 2. Stage 2 pipeline — mocked Bedrock RAG Evaluation APIs
// ---------------------------------------------------------------------------

describe("Integration: Stage 2 pipeline — Bedrock RAG Evaluation", () => {
  const DEFAULT_THRESHOLDS: RagThresholds = {
    faithfulness: 0.7,
    correctness: 0.7,
    completeness: 0.7,
    helpfulness: 0.7,
  };

  function makeSurvivingCase(id: string = "case-1"): RagCaseData {
    return {
      caseId: id,
      question: "What is the return policy?",
      groundTruthAnswer: "Items can be returned within 30 days.",
      agentResponse: "Our return policy allows returns within 30 days.",
      retrievedChunks: [{ text: "Return policy: 30 days.", index: 0 }],
      status: "passed",
    };
  }

  function makeInput(overrides: Partial<RagEvaluateInput> = {}): RagEvaluateInput {
    return {
      runId: "run-integ-stage2",
      suiteId: "suite-integ-1",
      ragCases: [makeSurvivingCase()],
      agentSnapshot: { modelId: "us.anthropic.claude-sonnet-4-6" },
      ragThresholds: DEFAULT_THRESHOLDS,
      ...overrides,
    };
  }

  beforeEach(() => {
    // Wave-2 migration (Task 17.7): the RAG Evaluate handler resolves
    // its evaluator-model id via `resolvePromptForRun("rag_evaluation_job", ...)`.
    // Inject an in-memory prompt store so the resolver returns the
    // registry's bundled default without hitting DynamoDB.
    _clearPromptRegistryCaches();
    const promptStore = {
      getSnapshot: vi.fn().mockResolvedValue(null),
      listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
    } as unknown as DynamoDBService;
    _setPromptRegistryStore(promptStore);
  });

  afterEach(() => {
    _setS3Client(null);
    setRagBedrockClient(null);
    _setDocClient(null);
    _setPromptRegistryStore(null);
    _clearPromptRegistryCaches();
  });

  it("full pipeline: upload JSONL → CreateEvaluationJob → poll → read S3 results → write DDB metrics", async () => {
    // Track S3 uploads
    let uploadedBody: string | undefined;

    const s3Send = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
      if (cmd.constructor.name === "PutObjectCommand") {
        uploadedBody = cmd.input.Body as string;
        return Promise.resolve({});
      }
      if (cmd.constructor.name === "ListObjectsV2Command") {
        return Promise.resolve({
          Contents: [{ Key: "run-integ-stage2/output/per_prompt_results.jsonl" }],
        });
      }
      if (cmd.constructor.name === "GetObjectCommand") {
        const perPromptContent = JSON.stringify({
          promptIndex: 0,
          scores: { faithfulness: 0.9, correctness: 0.85, completeness: 0.8, helpfulness: 0.95 },
        });
        return Promise.resolve({
          Body: { transformToString: () => Promise.resolve(perPromptContent) },
        });
      }
      return Promise.resolve({});
    });

    const bedrockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      if (cmd.constructor.name === "CreateEvaluationJobCommand") {
        return Promise.resolve({
          jobArn: "arn:aws:bedrock:us-east-1:123456789012:evaluation-job/integ-job-1",
        });
      }
      if (cmd.constructor.name === "GetEvaluationJobCommand") {
        return Promise.resolve({
          status: "Completed",
          outputDataConfig: { s3Uri: "s3://test-rag-bucket/run-integ-stage2/output/" },
        });
      }
      return Promise.resolve({});
    });

    const ddbWrites: Array<{ commandName: string; input: Record<string, unknown> }> = [];
    const ddbSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
      ddbWrites.push({ commandName: cmd.constructor.name, input: cmd.input });
      return Promise.resolve({});
    });

    _setS3Client({ send: s3Send } as any);
    setRagBedrockClient({ send: bedrockSend } as any);
    _setDocClient({ send: ddbSend } as any);

    const result = await ragEvaluateHandler(makeInput());

    // Verify outcome
    expect(result.status).toBe("COMPLETED");
    expect(result.evaluatedCount).toBe(1);
    expect(result.errorCount).toBe(0);
    expect(result.jobArn).toBe("arn:aws:bedrock:us-east-1:123456789012:evaluation-job/integ-job-1");

    // Verify JSONL was uploaded
    expect(uploadedBody).toBeDefined();
    const parsedLine = JSON.parse(uploadedBody!);
    expect(parsedLine.conversationTurns[0].prompt.content[0].text).toBe("What is the return policy?");
    expect(parsedLine.conversationTurns[0].output.text).toBe("Our return policy allows returns within 30 days.");

    // Verify DDB writes: UpdateCommand for metrics + PutCommand for RAGJOB record
    const updateWrites = ddbWrites.filter((w) => w.commandName === "UpdateCommand");
    const putWrites = ddbWrites.filter((w) => w.commandName === "PutCommand");
    expect(updateWrites.length).toBeGreaterThanOrEqual(1);
    expect(putWrites.length).toBeGreaterThanOrEqual(1);

    // Verify the RAGJOB record was persisted
    const ragJobRecord = putWrites.find(
      (w) => (w.input as any).Item?.SK === "RAGJOB",
    );
    expect(ragJobRecord).toBeDefined();
    expect((ragJobRecord!.input as any).Item.status).toBe("COMPLETED");
    expect((ragJobRecord!.input as any).Item.jobArn).toBe(
      "arn:aws:bedrock:us-east-1:123456789012:evaluation-job/integ-job-1",
    );
  });

  it("multi-case pipeline: scores each case independently via index mapping", async () => {
    const cases = [makeSurvivingCase("case-a"), makeSurvivingCase("case-b")];
    cases[1].question = "How do I track my order?";
    cases[1].groundTruthAnswer = "Use the tracking page.";
    cases[1].agentResponse = "Visit our tracking page for updates.";

    const perPromptContent = [
      JSON.stringify({ promptIndex: 0, scores: { faithfulness: 0.95, correctness: 0.9, completeness: 0.85, helpfulness: 0.9 } }),
      JSON.stringify({ promptIndex: 1, scores: { faithfulness: 0.4, correctness: 0.5, completeness: 0.3, helpfulness: 0.6 } }),
    ].join("\n");

    const s3Send = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      if (cmd.constructor.name === "PutObjectCommand") return Promise.resolve({});
      if (cmd.constructor.name === "ListObjectsV2Command") {
        return Promise.resolve({ Contents: [{ Key: "run-integ-stage2/output/results.jsonl" }] });
      }
      if (cmd.constructor.name === "GetObjectCommand") {
        return Promise.resolve({ Body: { transformToString: () => Promise.resolve(perPromptContent) } });
      }
      return Promise.resolve({});
    });

    const bedrockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      if (cmd.constructor.name === "CreateEvaluationJobCommand") {
        return Promise.resolve({ jobArn: "arn:aws:bedrock:us-east-1:123:job/multi" });
      }
      if (cmd.constructor.name === "GetEvaluationJobCommand") {
        return Promise.resolve({ status: "Completed", outputDataConfig: { s3Uri: "s3://b/o/" } });
      }
      return Promise.resolve({});
    });

    const ddbWrites: Array<{ commandName: string; input: Record<string, unknown> }> = [];
    const ddbSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
      ddbWrites.push({ commandName: cmd.constructor.name, input: cmd.input });
      return Promise.resolve({});
    });

    _setS3Client({ send: s3Send } as any);
    setRagBedrockClient({ send: bedrockSend } as any);
    _setDocClient({ send: ddbSend } as any);

    const result = await ragEvaluateHandler(makeInput({ ragCases: cases }));

    expect(result.status).toBe("COMPLETED");
    expect(result.evaluatedCount).toBe(2);

    // case-a should pass (all above 0.7), case-b should fail (faithfulness below 0.7)
    const updates = ddbWrites.filter((w) => w.commandName === "UpdateCommand");
    expect(updates).toHaveLength(2);

    // Verify the first case was set to "passed"
    const caseAUpdate = updates.find(
      (u) => (u.input as any).Key?.SK === "CASE#case-a",
    );
    expect(caseAUpdate).toBeDefined();
    expect((caseAUpdate!.input as any).ExpressionAttributeValues[":st"]).toBe("passed");

    // Verify the second case was set to "failed" (faithfulness 0.4 < 0.7)
    const caseBUpdate = updates.find(
      (u) => (u.input as any).Key?.SK === "CASE#case-b",
    );
    expect(caseBUpdate).toBeDefined();
    expect((caseBUpdate!.input as any).ExpressionAttributeValues[":st"]).toBe("failed");
  });
});

// ---------------------------------------------------------------------------
// 3. State machine conditional branch — suite with/without RAG cases
// ---------------------------------------------------------------------------

describe("Integration: State machine conditional branch", () => {
  const DEFAULT_THRESHOLDS: RagThresholds = {
    faithfulness: 0.7,
    correctness: 0.7,
    completeness: 0.7,
    helpfulness: 0.7,
  };

  beforeEach(() => {
    // Wave-2 migration (Task 17.7) — see note in the prior describe.
    _clearPromptRegistryCaches();
    const promptStore = {
      getSnapshot: vi.fn().mockResolvedValue(null),
      listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
    } as unknown as DynamoDBService;
    _setPromptRegistryStore(promptStore);
  });

  afterEach(() => {
    _setS3Client(null);
    setRagBedrockClient(null);
    _setDocClient(null);
    _setPromptRegistryStore(null);
    _clearPromptRegistryCaches();
  });

  it("suite WITH RAG cases triggers Stage 2 (CreateEvaluationJob is called)", async () => {
    const bedrockCalls: string[] = [];

    const s3Send = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      if (cmd.constructor.name === "ListObjectsV2Command") {
        return Promise.resolve({ Contents: [{ Key: "run-rag/output/results.jsonl" }] });
      }
      if (cmd.constructor.name === "GetObjectCommand") {
        const content = JSON.stringify({ promptIndex: 0, scores: { faithfulness: 0.9, correctness: 0.9, completeness: 0.9, helpfulness: 0.9 } });
        return Promise.resolve({ Body: { transformToString: () => Promise.resolve(content) } });
      }
      return Promise.resolve({});
    });

    const bedrockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      bedrockCalls.push(cmd.constructor.name);
      if (cmd.constructor.name === "CreateEvaluationJobCommand") {
        return Promise.resolve({ jobArn: "arn:aws:bedrock:us-east-1:123:job/rag-yes" });
      }
      if (cmd.constructor.name === "GetEvaluationJobCommand") {
        return Promise.resolve({ status: "Completed", outputDataConfig: { s3Uri: "s3://b/o/" } });
      }
      return Promise.resolve({});
    });

    _setS3Client({ send: s3Send } as any);
    setRagBedrockClient({ send: bedrockSend } as any);
    _setDocClient({ send: vi.fn().mockResolvedValue({}) } as any);

    const input: RagEvaluateInput = {
      runId: "run-rag",
      suiteId: "suite-with-rag",
      ragCases: [
        {
          caseId: "rag-case-1",
          question: "Q?",
          groundTruthAnswer: "A.",
          agentResponse: "Answer.",
          retrievedChunks: [{ text: "chunk", index: 0 }],
          status: "passed",
        },
      ],
      agentSnapshot: { modelId: "claude-sonnet" },
      ragThresholds: DEFAULT_THRESHOLDS,
    };

    const result = await ragEvaluateHandler(input);

    // Stage 2 was executed — CreateEvaluationJob was called
    expect(bedrockCalls).toContain("CreateEvaluationJobCommand");
    expect(result.status).toBe("COMPLETED");
  });

  it("suite WITHOUT RAG cases skips Stage 2 (zero cases → SKIPPED)", async () => {
    const bedrockCalls: string[] = [];
    const bedrockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      bedrockCalls.push(cmd.constructor.name);
      return Promise.resolve({});
    });

    _setS3Client({ send: vi.fn().mockResolvedValue({}) } as any);
    setRagBedrockClient({ send: bedrockSend } as any);
    _setDocClient({ send: vi.fn().mockResolvedValue({}) } as any);

    // All cases are errored → zero survivors → skip
    const input: RagEvaluateInput = {
      runId: "run-no-rag",
      suiteId: "suite-tool-only",
      ragCases: [
        {
          caseId: "err-case",
          question: "Q?",
          groundTruthAnswer: "A.",
          agentResponse: undefined, // no response → excluded
          status: "error",
        },
      ],
      agentSnapshot: { modelId: "claude-sonnet" },
      ragThresholds: DEFAULT_THRESHOLDS,
    };

    const result = await ragEvaluateHandler(input);

    // Stage 2 was skipped — no CreateEvaluationJob call
    expect(bedrockCalls).not.toContain("CreateEvaluationJobCommand");
    expect(result.status).toBe("SKIPPED");
    expect(result.evaluatedCount).toBe(0);
  });

  it("suite with only errored RAG cases (no survivors) skips CreateEvaluationJob", async () => {
    const bedrockCalls: string[] = [];
    const bedrockSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };
      bedrockCalls.push(cmd.constructor.name);
      return Promise.resolve({});
    });

    _setS3Client({ send: vi.fn().mockResolvedValue({}) } as any);
    setRagBedrockClient({ send: bedrockSend } as any);
    _setDocClient({ send: vi.fn().mockResolvedValue({}) } as any);

    const input: RagEvaluateInput = {
      runId: "run-all-errored",
      suiteId: "suite-all-err",
      ragCases: [
        { caseId: "c1", question: "Q1", groundTruthAnswer: "A1", status: "error" },
        { caseId: "c2", question: "Q2", groundTruthAnswer: "A2", agentResponse: undefined, status: "error" },
      ],
      agentSnapshot: { modelId: "claude-sonnet" },
      ragThresholds: DEFAULT_THRESHOLDS,
    };

    const result = await ragEvaluateHandler(input);

    expect(bedrockCalls).not.toContain("CreateEvaluationJobCommand");
    expect(result.status).toBe("SKIPPED");
    expect(result.evaluatedCount).toBe(0);
    expect(result.errorCount).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// 4. Error code propagation — failure modes produce correct DDB records
// ---------------------------------------------------------------------------

describe("Integration: Error code propagation", () => {
  const DEFAULT_THRESHOLDS: RagThresholds = {
    faithfulness: 0.7,
    correctness: 0.7,
    completeness: 0.7,
    helpfulness: 0.7,
  };

  function makeCase(id: string): RagCaseData {
    return {
      caseId: id,
      question: "Q?",
      groundTruthAnswer: "A.",
      agentResponse: "Response.",
      retrievedChunks: [{ text: "chunk", index: 0 }],
      status: "passed",
    };
  }

  function makeInput(overrides: Partial<RagEvaluateInput> = {}): RagEvaluateInput {
    return {
      runId: "run-err-test",
      suiteId: "suite-err",
      ragCases: [makeCase("case-err-1")],
      agentSnapshot: { modelId: "claude" },
      ragThresholds: DEFAULT_THRESHOLDS,
      ...overrides,
    };
  }

  beforeEach(() => {
    // Wave-2 migration (Task 17.7) — see note in the Stage 2 describe.
    _clearPromptRegistryCaches();
    const promptStore = {
      getSnapshot: vi.fn().mockResolvedValue(null),
      listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
    } as unknown as DynamoDBService;
    _setPromptRegistryStore(promptStore);
  });

  afterEach(() => {
    _setS3Client(null);
    setRagBedrockClient(null);
    _setDocClient(null);
    _setPromptRegistryStore(null);
    _clearPromptRegistryCaches();
  });

  it("RAG_JOB_FAILED: CreateEvaluationJob error → all cases get RAG_JOB_FAILED in DDB", async () => {
    const ddbWrites: Array<{ commandName: string; input: Record<string, unknown> }> = [];

    _setS3Client({ send: vi.fn().mockResolvedValue({}) } as any);
    setRagBedrockClient({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string } };
        if (cmd.constructor.name === "CreateEvaluationJobCommand") {
          return Promise.reject(new Error("Bedrock service error"));
        }
        return Promise.resolve({});
      }),
    } as any);
    _setDocClient({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
        ddbWrites.push({ commandName: cmd.constructor.name, input: cmd.input });
        return Promise.resolve({});
      }),
    } as any);

    const result = await ragEvaluateHandler(makeInput());

    expect(result.status).toBe("FAILED");
    expect(result.errorCount).toBe(1);

    // Verify the error was written to DDB
    const updateCmds = ddbWrites.filter((w) => w.commandName === "UpdateCommand");
    expect(updateCmds.length).toBeGreaterThanOrEqual(1);
    const errorUpdate = updateCmds[0];
    const evalError = (errorUpdate.input as any).ExpressionAttributeValues[":ee"];
    expect(evalError.code).toBe("RAG_JOB_FAILED");
    expect((errorUpdate.input as any).ExpressionAttributeValues[":st"]).toBe("error");
  });

  it("RAG_JOB_TIMEOUT: poll exceeds hard cap → all cases get RAG_JOB_TIMEOUT in DDB", async () => {
    const ddbWrites: Array<{ commandName: string; input: Record<string, unknown> }> = [];

    _setS3Client({ send: vi.fn().mockResolvedValue({}) } as any);
    setRagBedrockClient({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string } };
        if (cmd.constructor.name === "CreateEvaluationJobCommand") {
          return Promise.resolve({ jobArn: "arn:aws:bedrock:us-east-1:123:job/timeout" });
        }
        if (cmd.constructor.name === "GetEvaluationJobCommand") {
          // Always return InProgress — will time out
          return Promise.resolve({ status: "InProgress" });
        }
        if (cmd.constructor.name === "StopEvaluationJobCommand") {
          return Promise.resolve({});
        }
        return Promise.resolve({});
      }),
    } as any);
    _setDocClient({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
        ddbWrites.push({ commandName: cmd.constructor.name, input: cmd.input });
        return Promise.resolve({});
      }),
    } as any);

    const result = await ragEvaluateHandler(makeInput());

    expect(result.status).toBe("TIMEOUT");
    expect(result.errorCount).toBe(1);

    // Verify timeout error written
    const updateCmds = ddbWrites.filter((w) => w.commandName === "UpdateCommand");
    expect(updateCmds.length).toBeGreaterThanOrEqual(1);
    const evalError = (updateCmds[0].input as any).ExpressionAttributeValues[":ee"];
    expect(evalError.code).toBe("RAG_JOB_TIMEOUT");
    expect(evalError.reason).toContain("30 minutes");
  });

  it("MALFORMED_RESULT: per-prompt output missing metrics → single case gets MALFORMED_RESULT", async () => {
    const ddbWrites: Array<{ commandName: string; input: Record<string, unknown> }> = [];

    // Two cases: one with good metrics, one with malformed (missing faithfulness)
    const cases = [makeCase("case-good"), makeCase("case-bad")];

    // Good case gets full metrics, bad case gets incomplete metrics
    const perPromptContent = [
      JSON.stringify({ promptIndex: 0, scores: { faithfulness: 0.9, correctness: 0.9, completeness: 0.9, helpfulness: 0.9 } }),
      JSON.stringify({ promptIndex: 1, scores: { correctness: 0.9, completeness: 0.9, helpfulness: 0.9 } }), // missing faithfulness!
    ].join("\n");

    _setS3Client({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string } };
        if (cmd.constructor.name === "ListObjectsV2Command") {
          return Promise.resolve({ Contents: [{ Key: "run-err-test/output/results.jsonl" }] });
        }
        if (cmd.constructor.name === "GetObjectCommand") {
          return Promise.resolve({ Body: { transformToString: () => Promise.resolve(perPromptContent) } });
        }
        return Promise.resolve({});
      }),
    } as any);
    setRagBedrockClient({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string } };
        if (cmd.constructor.name === "CreateEvaluationJobCommand") {
          return Promise.resolve({ jobArn: "arn:job/malformed" });
        }
        if (cmd.constructor.name === "GetEvaluationJobCommand") {
          return Promise.resolve({ status: "Completed", outputDataConfig: { s3Uri: "s3://b/o/" } });
        }
        return Promise.resolve({});
      }),
    } as any);
    _setDocClient({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
        ddbWrites.push({ commandName: cmd.constructor.name, input: cmd.input });
        return Promise.resolve({});
      }),
    } as any);

    const result = await ragEvaluateHandler(makeInput({ ragCases: cases }));

    expect(result.status).toBe("COMPLETED");
    expect(result.evaluatedCount).toBe(1); // case-good scored
    expect(result.errorCount).toBe(1); // case-bad malformed

    // Find the malformed case error update
    const updateCmds = ddbWrites.filter((w) => w.commandName === "UpdateCommand");
    const malformedUpdate = updateCmds.find(
      (u) => (u.input as any).ExpressionAttributeValues?.[":ee"]?.code === "MALFORMED_RESULT",
    );
    expect(malformedUpdate).toBeDefined();
    expect((malformedUpdate!.input as any).Key.SK).toBe("CASE#case-bad");

    // The good case should have been scored successfully
    const passedUpdate = updateCmds.find(
      (u) => (u.input as any).Key?.SK === "CASE#case-good" && (u.input as any).ExpressionAttributeValues?.[":rm"],
    );
    expect(passedUpdate).toBeDefined();
  });

  it("MISSING_EVALUATOR: no per-prompt result for a case → MISSING_EVALUATOR error", async () => {
    const ddbWrites: Array<{ commandName: string; input: Record<string, unknown> }> = [];

    const cases = [makeCase("case-found"), makeCase("case-missing")];

    // Only one line in output — second case has no corresponding entry
    const perPromptContent = JSON.stringify({
      promptIndex: 0,
      scores: { faithfulness: 0.9, correctness: 0.9, completeness: 0.9, helpfulness: 0.9 },
    });

    _setS3Client({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string } };
        if (cmd.constructor.name === "ListObjectsV2Command") {
          return Promise.resolve({ Contents: [{ Key: "run-err-test/output/results.jsonl" }] });
        }
        if (cmd.constructor.name === "GetObjectCommand") {
          return Promise.resolve({ Body: { transformToString: () => Promise.resolve(perPromptContent) } });
        }
        return Promise.resolve({});
      }),
    } as any);
    setRagBedrockClient({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string } };
        if (cmd.constructor.name === "CreateEvaluationJobCommand") {
          return Promise.resolve({ jobArn: "arn:job/missing" });
        }
        if (cmd.constructor.name === "GetEvaluationJobCommand") {
          return Promise.resolve({ status: "Completed", outputDataConfig: { s3Uri: "s3://b/o/" } });
        }
        return Promise.resolve({});
      }),
    } as any);
    _setDocClient({
      send: vi.fn().mockImplementation((command: unknown) => {
        const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };
        ddbWrites.push({ commandName: cmd.constructor.name, input: cmd.input });
        return Promise.resolve({});
      }),
    } as any);

    const result = await ragEvaluateHandler(makeInput({ ragCases: cases }));

    expect(result.status).toBe("COMPLETED");

    // Find the MISSING_EVALUATOR error
    const updateCmds = ddbWrites.filter((w) => w.commandName === "UpdateCommand");
    const missingUpdate = updateCmds.find(
      (u) => (u.input as any).ExpressionAttributeValues?.[":ee"]?.code === "MISSING_EVALUATOR",
    );
    expect(missingUpdate).toBeDefined();
    expect((missingUpdate!.input as any).Key.SK).toBe("CASE#case-missing");
    expect((missingUpdate!.input as any).ExpressionAttributeValues[":ee"].reason).toContain(
      "did not return a result",
    );
  });
});

// ---------------------------------------------------------------------------
// 5. Opportunistic Faithfulness — tool-sequence with/without Retrieve
// ---------------------------------------------------------------------------

describe("Integration: Opportunistic Faithfulness on tool-sequence cases", () => {
  beforeEach(() => {
    setContactConnectClient(makeMockConnectClient());
    // Wave-2 migration (Task 17.6): the opportunistic-faithfulness
    // scorer now resolves its prompt via `resolvePromptForRun(...)`
    // against the Prompts_Store. Inject an in-memory stub so the
    // resolver returns the registry's bundled
    // `judge_opportunistic_faithfulness` default without hitting
    // DynamoDB. Same pattern as `tests/unit/customer-simulator.test.ts`.
    _clearPromptRegistryCaches();
    const promptStore = {
      getSnapshot: vi.fn().mockResolvedValue(null),
      listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
    } as unknown as DynamoDBService;
    _setPromptRegistryStore(promptStore);
  });

  afterEach(() => {
    setConversationQClient(null);
    setContactConnectClient(null);
    setConversationDynamoService(null);
    setFaithfulnessBedrockClient(null);
    _setPromptRegistryStore(null);
    _clearPromptRegistryCaches();
    vi.restoreAllMocks();
  });

  it("tool-sequence case WITH Retrieve invocation gets ragMetrics.faithfulness", async () => {
    // Mock customer simulator so multi-turn conversation can proceed
    vi.mock("../../src/backend/orchestration/customer-simulator", () => ({
      simulateCustomer: vi.fn().mockResolvedValue("Yes, that's helpful."),
    }));

    let getNextCallCount = 0;
    const mockQSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string }; input: Record<string, unknown> };

      if (cmd.constructor.name === "CreateSessionCommand") {
        return Promise.resolve({ session: { sessionId: "session-opfaith-001" } });
      }
      if (cmd.constructor.name === "SendMessageCommand") {
        return Promise.resolve({ nextMessageToken: "token-opfaith" });
      }
      if (cmd.constructor.name === "GetNextMessageCommand") {
        getNextCallCount++;
        // First call: agent responds with text and then conversation closes
        // Use "CLOSED" status to terminate the loop without needing simulateCustomer
        return Promise.resolve({
          response: { value: { text: { value: "Based on our knowledge base, the answer is X." } } },
          conversationSessionData: [],
          nextMessageToken: "token-opfaith-done",
          conversationState: { status: "CLOSED" },
        });
      }
      if (cmd.constructor.name === "ListSpansCommand") {
        // Return a Retrieve tool invocation span
        return Promise.resolve({
          spans: [
            {
              spanName: "execute_tool",
              startTimestamp: "2024-01-01T00:00:01.000Z",
              attributes: {
                aiAgentName: "Agent",
                aiAgentType: "ORCHESTRATION",
                inputMessages: [
                  { values: [{ toolUse: { name: "Retrieve", arguments: '{"q":"test"}' } }] },
                ],
                outputMessages: [
                  {
                    values: [
                      {
                        toolResult: {
                          values: [
                            { text: { value: "Knowledge base passage about answer X." } },
                          ],
                        },
                      },
                    ],
                  },
                ],
              },
            },
          ],
        });
      }
      return Promise.resolve({});
    });

    setConversationQClient(createMockClient<QConnectClient>(mockQSend));
    setConversationDynamoService({
      getSnapshot: vi.fn().mockResolvedValue({
        tools: [
          { toolName: "Retrieve", toolType: "KNOWLEDGE_BASE", description: "Retrieve", examples: [] },
        ],
        systemPrompt: "Help.",
        modelId: "claude",
        capturedAt: "2024-01-01T00:00:00.000Z",
      }),
    } as any);

    // Mock Bedrock Converse for faithfulness scoring
    setFaithfulnessBedrockClient({
      send: vi.fn().mockResolvedValue({
        output: {
          message: {
            content: [{ text: '{"score": 0.85}' }],
          },
        },
      }),
    } as any);

    const toolSequenceCase = {
      type: "tool_sequence" as const,
      suiteId: "suite-ts-001",
      caseId: "case-ts-opfaith",
      name: "Tool sequence with Retrieve",
      description: "Case that happens to invoke Retrieve",
      persona: "Customer",
      style: "direct" as any,
      customerKnowledge: {},
      initialUtterance: "What is the answer?",
      successCriteria: [{ toolName: "Retrieve", required: true }],
    };

    const event: ConversationDriverEvent = {
      caseId: toolSequenceCase.caseId,
      testCase: toolSequenceCase,
      runId: "run-opfaith-001",
      agentId: "agent-001",
      assistantId: "asst-001",
      retrieveToolName: "Retrieve",
      ragThresholds: { faithfulness: 0.7, correctness: 0.7, completeness: 0.7, helpfulness: 0.7 },
    };

    const result = await conversationDriverHandler(event);

    // Should have ragMetrics.faithfulness from opportunistic evaluation
    expect(result.ragMetrics).toBeDefined();
    expect(result.ragMetrics!.faithfulness).toBe(0.85);

    // Should also have retrievedChunks
    expect(result.retrievedChunks).toBeDefined();
    expect(result.retrievedChunks!.length).toBeGreaterThan(0);
  });

  it("tool-sequence case WITHOUT Retrieve invocation does NOT get ragMetrics.faithfulness", async () => {
    vi.mock("../../src/backend/orchestration/customer-simulator", () => ({
      simulateCustomer: vi.fn().mockResolvedValue("Ok thanks."),
    }));

    const mockQSend = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as { constructor: { name: string } };

      if (cmd.constructor.name === "CreateSessionCommand") {
        return Promise.resolve({ session: { sessionId: "session-no-retrieve" } });
      }
      if (cmd.constructor.name === "SendMessageCommand") {
        return Promise.resolve({ nextMessageToken: "t-no-ret" });
      }
      if (cmd.constructor.name === "GetNextMessageCommand") {
        // Agent responds and conversation closes — no simulateCustomer needed
        return Promise.resolve({
          response: { value: { text: { value: "The answer is Y." } } },
          conversationSessionData: [],
          nextMessageToken: "t-done",
          conversationState: { status: "CLOSED" },
        });
      }
      if (cmd.constructor.name === "ListSpansCommand") {
        // NO Retrieve tool in spans — only a different tool
        return Promise.resolve({
          spans: [
            {
              spanName: "execute_tool",
              startTimestamp: "2024-01-01T00:00:01.000Z",
              attributes: {
                aiAgentName: "Agent",
                aiAgentType: "ORCHESTRATION",
                inputMessages: [
                  { values: [{ toolUse: { name: "SearchFlights", arguments: '{}' } }] },
                ],
                outputMessages: [
                  { values: [{ toolResult: { values: [{ text: { value: "result" } }] } }] },
                ],
              },
            },
          ],
        });
      }
      return Promise.resolve({});
    });

    setConversationQClient(createMockClient<QConnectClient>(mockQSend));
    setConversationDynamoService({
      getSnapshot: vi.fn().mockResolvedValue({
        tools: [
          { toolName: "Retrieve", toolType: "KNOWLEDGE_BASE", description: "Retrieve", examples: [] },
          { toolName: "SearchFlights", toolType: "LAMBDA", description: "Search", examples: [] },
        ],
        systemPrompt: "Help.",
        modelId: "claude",
        capturedAt: "2024-01-01T00:00:00.000Z",
      }),
    } as any);

    const faithfulnessSpy = vi.fn();
    setFaithfulnessBedrockClient({ send: faithfulnessSpy } as any);

    const toolSequenceCase = {
      type: "tool_sequence" as const,
      suiteId: "suite-ts-002",
      caseId: "case-ts-no-retrieve",
      name: "Tool sequence without Retrieve",
      description: "Case that does not invoke Retrieve",
      persona: "Customer",
      style: "direct" as any,
      customerKnowledge: {},
      initialUtterance: "Search flights for me.",
      successCriteria: [{ toolName: "SearchFlights", required: true }],
    };

    const event: ConversationDriverEvent = {
      caseId: toolSequenceCase.caseId,
      testCase: toolSequenceCase,
      runId: "run-no-retrieve",
      agentId: "agent-001",
      assistantId: "asst-001",
      retrieveToolName: "Retrieve",
      ragThresholds: { faithfulness: 0.7, correctness: 0.7, completeness: 0.7, helpfulness: 0.7 },
    };

    const result = await conversationDriverHandler(event);

    // Should NOT have ragMetrics because no Retrieve chunks were found
    expect(result.ragMetrics).toBeUndefined();
    // Faithfulness Bedrock call should not have been made
    expect(faithfulnessSpy).not.toHaveBeenCalled();
  });
});
