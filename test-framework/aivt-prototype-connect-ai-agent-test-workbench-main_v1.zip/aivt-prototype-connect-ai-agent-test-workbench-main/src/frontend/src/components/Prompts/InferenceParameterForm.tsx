/**
 * Capability-aware inference parameter editor for the per-prompt
 * detail page.
 *
 * Implements task 13.6 of the prompt-management feature plan and the
 * following requirements:
 *
 *   - R14.1 — render the prompt's `inferenceParameters` as form fields
 *     "appropriate to their declared types": numeric scalars use a
 *     Cloudscape `Slider` with the schema-declared bounds visible to
 *     the user; integer scalars use a Cloudscape `Input type="number"`
 *     with HTML-level min/max constraints; string arrays use a
 *     Cloudscape `TokenGroup` paired with a text Input for adding
 *     tokens, so the persisted shape (an array of strings) is
 *     unambiguous in the UI rather than smuggled through a
 *     comma-separated string the user has to remember to format.
 *
 *   - R17.4 — for the `amazon_nova` Model_Capability_Profile, the
 *     `topK` parameter is wire-format-routed to
 *     `additionalModelRequestFields.inferenceConfig.topK` rather than
 *     to the top-level `inferenceConfig`. The wire-format placement
 *     itself is the backend's responsibility (`buildInferenceConfig`
 *     in `prompt-registry/capability-profiles.ts`); the editor's job
 *     is to surface that fact to the user so the UI is honest about
 *     where the field will land. We therefore tag the `topK` field's
 *     description specifically on Nova with that placement note. We
 *     do NOT tag every `acceptsAdditional` key generically — Nova's
 *     `topK` is the only key in the catalog that goes through the
 *     additional-fields channel, and a generic note on every
 *     `acceptsAdditional` key would imply a generality the catalog
 *     doesn't actually have.
 *
 * Filtering rules:
 *
 *   - The schema's keys are intersected with the resolved model's
 *     `acceptsTopLevel ∪ acceptsAdditional`. Keys the model forbids
 *     (or simply doesn't recognise) are not rendered, period — even
 *     when the prompt's schema declares them. Persisted draft values
 *     for forbidden keys must already have been stripped by the
 *     caller (the {@link ModelSelector}'s `removedKeys` callback);
 *     this component is the read-side projection and does not mutate
 *     the draft to enforce that.
 *
 *   - When the resolved model lookup fails (defensive — the API
 *     returns `currentModelKey` inline with `allowedModels[]`), we
 *     fall back to the schema's full key set so the user can still
 *     edit. The backend's MODEL_FORBIDS_KEY check is the
 *     authoritative guard at save time.
 *
 * @module frontend/components/Prompts/InferenceParameterForm
 */

import { useMemo, useState } from 'react';
import Box from '@cloudscape-design/components/box';
import FormField from '@cloudscape-design/components/form-field';
import Input from '@cloudscape-design/components/input';
import Slider from '@cloudscape-design/components/slider';
import SpaceBetween from '@cloudscape-design/components/space-between';
import TokenGroup from '@cloudscape-design/components/token-group';
import type {
  AllowedModelEntry,
  InferenceParameterSchema,
} from '../../api';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface InferenceParameterFormProps {
  /**
   * The prompt's `inferenceParameterSchema` from `GET /prompts/{key}`.
   * Keyed by Converse `inferenceConfig` parameter name.
   */
  schema: Record<string, InferenceParameterSchema>;

  /**
   * The current draft inference parameter values. Sparse — keys the
   * user hasn't set may be absent. Values mirror the persisted shape:
   * numeric primitives for `number` / `integer`, `string[]` for
   * `stringArray`.
   */
  values: Record<string, unknown>;

  /**
   * The full `AllowedModelEntry` of the currently-resolved model,
   * carrying its capability profile inline. Undefined when the
   * lookup fails (defensive); see the module docstring.
   */
  resolvedModel: AllowedModelEntry | undefined;

  /**
   * Called with the next full values map. Always receives a freshly
   * constructed object so referential-equality checks downstream
   * detect the change.
   */
  onChange: (next: Record<string, unknown>) => void;

  /**
   * Disable every input while a save or reset is in flight so the
   * user can't change values under the API call's feet.
   */
  disabled?: boolean;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Capability-profile key the registry assigns to Amazon Nova models. */
const AMAZON_NOVA_PROFILE = 'amazon_nova';

/** Inference-parameter key Nova routes through the additional-fields channel. */
const NOVA_ADDITIONAL_FIELDS_KEY = 'topK';

/**
 * Pick a slider step sized to the parameter's range: roughly 100
 * discrete points across the slider, rounded to a tidy increment.
 * Most of the platform's `kind: "number"` parameters are sampling
 * controls bound to [0, 1], where step `0.01` is the human-natural
 * resolution; ranges that span multiple orders of magnitude get a
 * coarser step so the slider remains useful.
 */
function computeSliderStep(min: number, max: number): number {
  const span = Math.max(max - min, Number.EPSILON);
  if (span <= 1) return 0.01;
  if (span <= 10) return 0.1;
  if (span <= 100) return 1;
  return Math.pow(10, Math.floor(Math.log10(span)) - 2);
}

/**
 * Format a slider value for the tooltip / reference labels with
 * sensible precision: integers print without a decimal, fractional
 * values clamp to 3 significant digits.
 */
function formatSliderValue(value: number): string {
  if (Number.isInteger(value)) return value.toString();
  return Number(value.toPrecision(3)).toString();
}

/**
 * Decide whether a numeric draft value is rendered as the slider's
 * current position. Out-of-range or non-numeric drafts fall back to
 * the schema's `default` if declared, else the range midpoint, so
 * the slider always has a valid handle even when the draft was
 * polluted (e.g., loaded from an older prompt version with bounds
 * that have since tightened).
 */
function resolveNumericValue(
  raw: unknown,
  schema: { min: number; max: number; default?: number },
): number {
  if (typeof raw === 'number' && Number.isFinite(raw)) {
    if (raw < schema.min) return schema.min;
    if (raw > schema.max) return schema.max;
    return raw;
  }
  if (schema.default !== undefined) return schema.default;
  return (schema.min + schema.max) / 2;
}

/**
 * Coerce the draft value for a `stringArray` parameter into an
 * actual `string[]`. Defends against drafts polluted with stray
 * non-string elements (which the validator would reject anyway).
 */
function resolveStringArrayValue(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter((item): item is string => typeof item === 'string');
}

/**
 * Build the human-readable description string shown beneath each
 * field. Notes the schema bounds, plus the Nova additional-fields
 * placement when applicable (R17.4).
 */
function describeField(
  key: string,
  schema: InferenceParameterSchema,
  capabilityProfileKey: string | undefined,
): string {
  const isNovaTopK =
    capabilityProfileKey === AMAZON_NOVA_PROFILE &&
    key === NOVA_ADDITIONAL_FIELDS_KEY;
  const novaNote = isNovaTopK
    ? ' Sent under additionalModelRequestFields.inferenceConfig.topK.'
    : '';
  switch (schema.kind) {
    case 'integer':
      return `Integer in [${schema.min}, ${schema.max}].${novaNote}`;
    case 'number':
      return `Number in [${schema.min}, ${schema.max}].${novaNote}`;
    case 'stringArray':
      return `Up to ${schema.maxLength} strings. Press Enter or comma to add.${novaNote}`;
  }
}

// ---------------------------------------------------------------------------
// Subcomponent: stringArray editor
// ---------------------------------------------------------------------------

interface StringArrayEditorProps {
  paramKey: string;
  values: string[];
  maxLength: number;
  disabled?: boolean;
  onChange: (next: string[]) => void;
}

/**
 * Token-group editor for `kind: "stringArray"` parameters. Tokens
 * render as dismissible chips; new tokens are added via the adjoining
 * Input on Enter or comma. Splitting on comma keeps a paste-friendly
 * affordance for users migrating off the prior comma-separated text
 * field.
 */
function StringArrayEditor({
  paramKey,
  values,
  maxLength,
  disabled,
  onChange,
}: StringArrayEditorProps): JSX.Element {
  const [draft, setDraft] = useState('');
  const atLimit = values.length >= maxLength;

  const commitDraft = (raw: string) => {
    // Split on comma so a user pasting "a, b, c" lands three tokens.
    const candidates = raw
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
    if (candidates.length === 0) return;
    // De-dup against existing values; preserve insertion order so the
    // user sees newest tokens last.
    const accepted: string[] = [];
    const seen = new Set(values);
    for (const candidate of candidates) {
      if (values.length + accepted.length >= maxLength) break;
      if (seen.has(candidate)) continue;
      seen.add(candidate);
      accepted.push(candidate);
    }
    if (accepted.length === 0) {
      setDraft('');
      return;
    }
    onChange([...values, ...accepted]);
    setDraft('');
  };

  const handleKeyDown = (key: string) => {
    if (key === 'Enter' || key === ',') {
      commitDraft(draft);
    }
  };

  return (
    <SpaceBetween size="xs">
      <Input
        value={draft}
        placeholder={atLimit ? `Limit reached (${maxLength}).` : 'Add a value'}
        onChange={({ detail }) => {
          // Live-commit when the user types a comma so the UX matches
          // the Enter affordance for either input style.
          if (detail.value.endsWith(',')) {
            commitDraft(detail.value);
          } else {
            setDraft(detail.value);
          }
        }}
        onKeyDown={({ detail }) => handleKeyDown(detail.key)}
        onBlur={() => {
          if (draft.length > 0) commitDraft(draft);
        }}
        disabled={disabled || atLimit}
        ariaLabel={`Add a value to ${paramKey}`}
      />
      {values.length > 0 && (
        <TokenGroup
          items={values.map((label) => ({
            label,
            dismissLabel: `Remove ${label}`,
            disabled,
          }))}
          onDismiss={({ detail }) => {
            const next = values.filter((_, idx) => idx !== detail.itemIndex);
            onChange(next);
          }}
          disableOuterPadding
        />
      )}
    </SpaceBetween>
  );
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * Auto-generated form fields driven by the prompt's inference
 * parameter schema, filtered by the resolved model's capability
 * profile. See the module docstring for the contract.
 */
export function InferenceParameterForm({
  schema,
  values,
  resolvedModel,
  onChange,
  disabled,
}: InferenceParameterFormProps): JSX.Element {
  // Compute the set of keys the resolved model accepts. When the
  // lookup fails, fall back to the raw schema's keys so the user can
  // still edit; the backend's MODEL_FORBIDS_KEY guard catches the
  // mismatch at save time.
  const acceptedKeys = useMemo(() => {
    if (!resolvedModel) return Object.keys(schema);
    const accepted = new Set<string>([
      ...resolvedModel.capabilityProfile.acceptsTopLevel,
      ...resolvedModel.capabilityProfile.acceptsAdditional,
    ]);
    return Object.keys(schema).filter((k) => accepted.has(k));
  }, [schema, resolvedModel]);

  if (acceptedKeys.length === 0) {
    return (
      <Box color="text-body-secondary">
        This model accepts no tunable inference parameters.
      </Box>
    );
  }

  const capabilityProfileKey = resolvedModel?.capabilityProfileKey;

  /** Update a single key in the values map and emit. */
  const setKey = (key: string, value: unknown) => {
    const next: Record<string, unknown> = { ...values };
    if (value === undefined) {
      delete next[key];
    } else {
      next[key] = value;
    }
    onChange(next);
  };

  return (
    <SpaceBetween size="m">
      {acceptedKeys.map((key) => {
        const entry = schema[key];
        const description = describeField(key, entry, capabilityProfileKey);

        if (entry.kind === 'number') {
          const current = resolveNumericValue(values[key], entry);
          const step = computeSliderStep(entry.min, entry.max);
          return (
            <FormField key={key} label={key} description={description}>
              <SpaceBetween size="xxs">
                <Slider
                  value={current}
                  min={entry.min}
                  max={entry.max}
                  step={step}
                  disabled={disabled}
                  valueFormatter={formatSliderValue}
                  ariaLabel={key}
                  referenceValues={[entry.min, entry.max]}
                  onChange={({ detail }) => setKey(key, detail.value)}
                />
                <Box variant="small" color="text-body-secondary">
                  Current: {formatSliderValue(current)}
                </Box>
              </SpaceBetween>
            </FormField>
          );
        }

        if (entry.kind === 'integer') {
          const raw = values[key];
          const stringValue =
            typeof raw === 'number'
              ? String(raw)
              : raw === undefined
                ? ''
                : String(raw);
          return (
            <FormField key={key} label={key} description={description}>
              <Input
                type="number"
                inputMode="numeric"
                step={1}
                value={stringValue}
                disabled={disabled}
                onChange={({ detail }) => {
                  if (detail.value === '') {
                    setKey(key, undefined);
                    return;
                  }
                  const parsed = parseInt(detail.value, 10);
                  // Forward the raw string when parsing fails so the
                  // dry-render validator's INFERENCE_PARAMETER_OUT_OF_BOUNDS
                  // can speak to the offending value rather than to a
                  // silently-coerced NaN.
                  setKey(key, Number.isNaN(parsed) ? detail.value : parsed);
                }}
              />
            </FormField>
          );
        }

        // entry.kind === 'stringArray'
        const arrayValues = resolveStringArrayValue(values[key]);
        return (
          <FormField key={key} label={key} description={description}>
            <StringArrayEditor
              paramKey={key}
              values={arrayValues}
              maxLength={entry.maxLength}
              disabled={disabled}
              onChange={(next) => setKey(key, next)}
            />
          </FormField>
        );
      })}
    </SpaceBetween>
  );
}

export default InferenceParameterForm;
