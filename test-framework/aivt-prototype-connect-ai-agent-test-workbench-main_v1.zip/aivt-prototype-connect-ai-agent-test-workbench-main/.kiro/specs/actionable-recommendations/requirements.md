# Requirements Document

## Introduction

This feature makes test runs actionable. Today, the platform persists detailed per-case results, captures reasoning traces, and the Failure Analysis page renders Bedrock-driven root-cause explanations and recommended edits — but those recommendations are tucked behind a sub-page only reachable from the Results Viewer, are recomputed on every page load (paying the model cost again), are not surfaced on the Run Dashboard where users actually land after a run, are bucketed against an incomplete picture of the agent's editable surface (the platform silently drops the `examples` field that orchestration agents inject into the system prompt at runtime), and offer no whole-suite consolidation that tells a user which one or two changes would lift the run the most.

The feature has four parts:

1. Capture and surface tool `examples` end-to-end (discovery → snapshot → Agent Browser display → Comparison-page config diff → analysis prompt input → recommendation target field) so the platform sees the same agent the runtime sees.
2. Extend per-test-case recommendations to bucket suggestions across all four editable surfaces (tool description, tool instruction, tool examples, system prompt), persist the result so revisits do not re-pay for Bedrock, and make the recommendations reachable from the Run Dashboard and the per-case detail page rather than only from the Results Viewer.
3. Add a new per-suite-run recommendation that consolidates failures across the run, prioritizes 1–3 high-leverage changes, and predicts which failed cases each change would lift, framed as "if you make these, you'd most lift the run."
4. Render both recommendation tiers in a new "Recommended changes" panel on the Run Dashboard above the results table, with an explicit "no failures — all cases passed" empty state, deep-links to the canonical Failure Analysis view on the Results Viewer (single source of truth, not duplicated rendering), and graceful degradation when Bedrock throttles, the snapshot is missing, or examples are absent.

## Glossary

- **Platform**: The Connect Agent Test Platform (the existing system this feature extends).
- **Tool_Examples**: The `examples` field on a Q in Connect orchestration AI Agent's `ToolConfiguration`, an ordered array of free-form strings used as few-shot demonstrations for tool selection. The runtime injects these into the system prompt alongside the tool description and instruction.
- **Tool_Surface**: One of the four editable fields on a Q in Connect orchestration AI Agent that a recommendation may target. The four surfaces are: `tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`.
- **Discovery_API**: The backend handler at `GET /agents` and `GET /agents/{agentId}` that resolves agent configuration from Q in Connect.
- **Agent_Snapshot**: The point-in-time agent configuration captured at run start and persisted at `PK=RUN#{runId}, SK=SNAPSHOT`. The existing snapshot already carries `tools[]`, `systemPrompt`, `modelId`, and `capturedAt`; this feature extends it to carry `Tool_Examples` per tool.
- **Agent_Browser**: The frontend page that renders agent detail (tools, descriptions, instructions, system prompt). Currently does not display `Tool_Examples`.
- **Comparison_View**: The frontend page that diffs two runs, including the configuration diff produced by `diffAgentConfigs` over two `Agent_Snapshot` records.
- **Per_Case_Recommendation**: A single proposed edit to one `Tool_Surface` derived from one failed test case's transcript, reasoning trace, and snapshot. Already produced today by `POST /runs/{runId}/analyze`; this feature extends it to support `tool_examples` and persists the result.
- **Per_Suite_Recommendation**: A single proposed edit to one `Tool_Surface` derived from the whole run (all failed cases, the snapshot, and the per-case analyses), prioritized and accompanied by a predicted-impact statement. New in this feature.
- **Recommendation_Engine**: The backend handler family that produces `Per_Case_Recommendation` and `Per_Suite_Recommendation` records by calling Bedrock and persists them to DynamoDB. Encompasses the existing `analysis.ts` plus a new sibling for the per-suite call.
- **Recommended_Changes_Panel**: The new UI block on the Run Dashboard that renders the persisted recommendations above the test case results table.
- **Failure_Analysis_View**: The existing `FailureAnalysis.tsx` page reachable from the Results Viewer; remains the canonical full-detail view for per-case recommendations.
- **Predicted_Impact**: A statement on a `Per_Suite_Recommendation` listing the failed case IDs the recommendation is expected to lift if applied, plus a short qualitative rationale.

## Requirements

### Requirement 1: Capture Tool Examples Through the Discovery API

**User Story:** As a tester browsing an AI agent, I want to see the `examples` array each tool was configured with, so that the platform shows the same tool definition the runtime sees and I can author tests that exercise the example boundaries.

#### Acceptance Criteria

1. WHEN the Discovery_API receives `GET /agents/{agentId}`, THE Discovery_API SHALL extract the `examples` array from each `toolConfigurations[].examples` field on the orchestration AI Agent's configuration and include it on the returned `ToolDefinition` as an ordered array of strings.
2. IF the upstream `toolConfigurations[].examples` field is absent, null, or an empty array, THEN THE Discovery_API SHALL return an empty array for that tool's examples and SHALL NOT omit the field from the response.
3. THE Discovery_API SHALL preserve the order of strings within the `examples` array exactly as returned by the Q in Connect `GetAIAgent` API.
4. THE Discovery_API SHALL preserve each example string verbatim, including whitespace and any embedded newline or quote characters, without truncation, escape replacement, or normalization.
5. THE Platform SHALL extend the shared `ToolDefinition` type to include `examples: string[]` as a required field with a default of empty array, so that all downstream consumers (Agent_Browser, Agent_Snapshot, Recommendation_Engine, Comparison_View) read the same shape.

### Requirement 2: Display Tool Examples in the Agent Browser

**User Story:** As a tester reviewing an agent's configuration, I want to see each tool's `examples` alongside its description and instruction, so that I understand the few-shot context the agent operates with.

#### Acceptance Criteria

1. WHEN a user opens the Agent_Browser detail panel for an agent, THE Agent_Browser SHALL render each tool's `examples` array as an ordered list directly below that tool's instruction field.
2. WHERE a tool's `examples` array is empty, THE Agent_Browser SHALL render an empty-state label reading "No examples configured" rather than omitting the section.
3. THE Agent_Browser SHALL render each example string in a monospace block that preserves whitespace and newlines.
4. THE Agent_Browser SHALL display a count badge next to the section header showing the number of examples for that tool, including when the count is zero (the badge SHALL render alongside the "No examples configured" empty state for visual consistency).

### Requirement 3: Capture Tool Examples in the Agent Snapshot

**User Story:** As a tester re-analyzing an old run, I want the snapshot persisted at run start to include the tool examples that were active at that moment, so that recommendations and comparisons reflect what the agent actually saw.

#### Acceptance Criteria

1. WHEN the Platform writes the Agent_Snapshot at run start, THE Platform SHALL include each tool's `examples` array exactly as returned by the Discovery_API at snapshot capture time.
2. THE Platform SHALL preserve the snapshot's existing top-level shape (`tools[]`, `systemPrompt`, `modelId`, `capturedAt`) and add `examples` only as a per-tool field within `tools[]`.
3. WHEN the Platform reads an Agent_Snapshot persisted before this feature shipped (records with no `examples` field on any tool), THE Platform SHALL treat each missing `examples` field as an empty array and SHALL NOT fail the read.
4. FOR ANY Agent_Snapshot persisted under this feature, the round-trip property SHALL hold: writing the snapshot to DynamoDB and reading it back SHALL produce a snapshot whose `examples` array per tool is element-wise equal to the input, including order and string content.

### Requirement 4: Extend the Configuration Diff to Detect Example Changes

**User Story:** As a tester comparing two runs, I want the configuration diff to flag added, removed, or reordered tool examples, so that I can correlate result deltas with example changes.

#### Acceptance Criteria

1. WHEN `diffAgentConfigs` compares two Agent_Snapshots that share at least one tool by name, IF that tool's `examples` array differs between the two snapshots in length, in element ordering, or in any element string content, THEN the diff SHALL emit a `tool-examples-changed` change record carrying the tool name, the prior examples array, and the new examples array.
2. IF the two snapshots' `examples` arrays for the same tool are element-wise equal in length, order, and content, THEN the diff SHALL NOT emit a `tool-examples-changed` record for that tool.
3. WHEN the Comparison_View renders a `tool-examples-changed` record, THE Comparison_View SHALL show the prior and new arrays side-by-side with added strings highlighted in green, removed strings in red, and reordered strings flagged with an "order changed" indicator.
4. THE diff SHALL emit `tool-examples-changed` independently of `tool-modified` (description/instruction changes); a tool whose only difference is its examples array SHALL produce a `tool-examples-changed` record and no `tool-modified` record.

### Requirement 5: Per-Case Recommendation Surface Bucketing

**User Story:** As a tester reading a per-case recommendation, I want every recommendation tagged with one of the four editable surfaces, so that the GUI can group recommendations by what I'd actually edit.

#### Acceptance Criteria

1. THE Recommendation_Engine SHALL constrain every `Per_Case_Recommendation`'s `targetField` to exactly one of the four Tool_Surface values: `tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`.
2. WHERE `targetField` equals `tool_examples`, THE Recommendation_Engine SHALL set `targetName` to the tool name the example belongs to and SHALL structure the recommendation as one of three example operations: add an example, remove an example by exact string match, or replace an example by exact string match.
3. WHERE `targetField` equals `tool_examples` and the operation is "remove", THE Recommendation_Engine SHALL set `currentText` to the exact existing example string to remove and SHALL set `suggestedText` to the empty string.
4. WHERE `targetField` equals `tool_examples` and the operation is "add", THE Recommendation_Engine SHALL set `currentText` to the empty string and SHALL set `suggestedText` to the new example to add.
5. WHERE `targetField` equals `tool_examples` and the operation is "replace", THE Recommendation_Engine SHALL set `currentText` to the exact existing example string and `suggestedText` to its replacement.
6. WHEN building the analysis prompt, THE Recommendation_Engine SHALL include each tool's `examples` array (formatted as a numbered list per tool) so that the model can reason about whether the failure was driven by a missing, misleading, or extraneous example.
7. WHERE a tool's `examples` array is an empty array (the tool has no examples configured), THE Recommendation_Engine SHALL proceed with prompt construction and render `Examples: (none)` for that tool.
8. IF the Recommendation_Engine cannot read the `examples` field for a tool because the snapshot record is malformed (the field is present but is not a JSON array), THEN THE Recommendation_Engine SHALL abort the analysis and return an HTTP 500 response with `error: "snapshot_examples_malformed"` and the offending tool name, so that the failure is visible rather than silently degrading the recommendation quality.
9. IF the Recommendation_Engine returns a recommendation whose `targetField` is not one of the four Tool_Surface values, THEN the Platform SHALL drop that recommendation before persisting and SHALL log the malformed recommendation for diagnostics.

### Requirement 6: Per-Case Recommendation Persistence

**User Story:** As a tester re-opening the Run Dashboard, I want the per-case recommendations I generated earlier to load instantly, so that I'm not re-paying for the Bedrock call on every visit.

#### Acceptance Criteria

1. WHEN the Recommendation_Engine completes a per-case analysis for a run, THE Recommendation_Engine SHALL persist the analysis result (root cause category, explanation, trace availability flag, recommendations array) to DynamoDB at `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` along with a `generatedAt` ISO 8601 timestamp and the model ID used.
2. WHEN a client requests `POST /runs/{runId}/analyze` and a persisted analysis exists for every failed case in the run, THE Recommendation_Engine SHALL return the persisted analyses without invoking Bedrock.
3. WHEN a client requests `POST /runs/{runId}/analyze` with an explicit `force: true` flag in the request body, THE Recommendation_Engine SHALL re-invoke Bedrock for every failed case, overwrite the persisted analyses, and update each `generatedAt` timestamp.
4. WHEN the Recommendation_Engine reads a persisted analysis whose schema predates this feature (no `tool_examples` recommendations possible), THE Recommendation_Engine SHALL return the persisted record unchanged and SHALL NOT silently regenerate it.
5. THE Recommendation_Engine SHALL constrain the set of valid `targetField` values to those fields the orchestration AI Agent runtime injects into the agent's effective prompt at inference time (currently: `tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`), and SHALL NOT generate recommendations against fields the runtime does not consume.
6. IF persistence to DynamoDB fails for a per-case analysis, THEN the Recommendation_Engine SHALL still return the analysis to the caller and SHALL log the persistence failure (logging only on actual persistence failure, not on every successful write), so that a transient DDB error does not block the user from seeing recommendations.

### Requirement 7: Per-Case Recommendation Visibility

**User Story:** As a tester drilling into a single failed case, I want the per-case recommendations available directly from the case detail page, so that I do not have to navigate to a separate Failure Analysis sub-page to see them.

#### Acceptance Criteria

1. WHEN a user opens the per-case detail page (`/runs/{runId}/cases/{caseId}`) for a case with status `failed`, THE Platform SHALL fetch the persisted per-case analysis for that case and render the recommendations grouped by Tool_Surface beneath the existing transcript and execution-trace sections.
2. WHERE a persisted per-case analysis does not yet exist for a failed case the user is viewing, THE Platform SHALL display a "Generate recommendations" action that, when activated, triggers analysis for that single case (not the entire run) and renders the result in place.
3. WHEN a user opens the case detail page for a case with status `passed`, `error`, or `timed_out`, THE Platform SHALL NOT render the per-case recommendations section.
4. THE per-case recommendations section on the case detail page SHALL deep-link to the full Failure_Analysis_View with the case anchor pre-selected, so that the Failure_Analysis_View remains the canonical full-detail view and the case detail page is a per-case projection of the same persisted record.

### Requirement 8: Per-Suite Recommendation Generation

**User Story:** As a tester looking at a run with several failures, I want a small, prioritized set of consolidated recommendations that name the highest-leverage edits, so that I know where to start instead of triaging a dozen per-case suggestions.

#### Acceptance Criteria

1. THE Platform SHALL expose a new endpoint `POST /runs/{runId}/recommend-suite` that returns an ordered array of `Per_Suite_Recommendation` records of length 0 or more, where the array is empty only if the model determines no actionable consolidated improvements exist, and is otherwise ordered by descending priority.
2. WHEN the Recommendation_Engine handles `POST /runs/{runId}/recommend-suite`, THE Recommendation_Engine SHALL build a single Bedrock prompt that includes (a) all failed test case results in the run, (b) the run's Agent_Snapshot including `Tool_Examples`, (c) the persisted per-case analyses if available, and (d) instructions to consolidate, prioritize, and predict per-recommendation impact.
3. THE per-suite Bedrock prompt SHALL be distinct from the per-case prompt and SHALL explicitly instruct the model to return only those recommendations the model judges actionable, each targeting a single Tool_Surface, ordered such that recommendation index 0 is the highest-leverage change.
4. THE Recommendation_Engine SHALL constrain every `Per_Suite_Recommendation`'s `targetField` to one of the four Tool_Surface values, with the same structural rules as a `Per_Case_Recommendation` (Requirement 5).
5. WHEN the Recommendation_Engine returns a `Per_Suite_Recommendation`, THE Recommendation_Engine SHALL include a `predictedImpact` object containing (a) a `liftedCaseIds` array listing the failed case IDs the recommendation is expected to flip from failing to passing, and (b) a `rationale` string explaining the prediction in plain language.
6. THE Recommendation_Engine SHALL constrain `liftedCaseIds` such that every entry is the ID of a failed case in the current run, with no duplicates within a single recommendation.
7. THE Recommendation_Engine SHALL persist the per-suite analysis result (the ordered recommendations array, the `generatedAt` timestamp, the model ID) to DynamoDB at `PK=RUN#{runId}, SK=ANALYSIS#SUITE`, so that subsequent reads do not re-invoke Bedrock.
8. WHEN a client requests `POST /runs/{runId}/recommend-suite` and a persisted per-suite analysis exists for the run, THE Recommendation_Engine SHALL return the persisted record without invoking Bedrock unless the request body includes `force: true`.

### Requirement 9: Per-Suite Recommendation Ordering and Determinism

**User Story:** As a tester relying on the prioritization, I want the order of per-suite recommendations to be stable and the higher-priority recommendation to come first, so that "act on the top one" is unambiguous.

#### Acceptance Criteria

1. THE Recommendation_Engine SHALL emit `Per_Suite_Recommendation` records in an array where index 0 is the highest-priority change and subsequent indices are non-increasing priority (each recommendation's `priority` field is an integer that increases monotonically with array index).
2. WHERE two recommendations would tie on model-assigned priority, THE Recommendation_Engine SHALL break the tie by preferring the recommendation whose `liftedCaseIds` array is longer, and if those are equal in length, by the lexicographic ordering of the joined `targetField` and `targetName` strings.
3. FOR ANY persisted per-suite analysis, repeated reads SHALL return the recommendations in the same order they were persisted, with no client-side or server-side reordering.

### Requirement 10: Recommended Changes Panel on the Run Dashboard

**User Story:** As a tester landing on the Run Dashboard after a run completes, I want to see the recommended changes prominently above the results table, so that the next action is obvious without my having to navigate to a sub-page.

#### Acceptance Criteria

1. WHEN a user loads the Run Dashboard for a run whose status is `completed`, `failed`, or `aborted`, THE Run Dashboard SHALL render the Recommended_Changes_Panel between the progress section and the test case results table.
2. WHEN the run has zero failed cases (`failed === 0` and `errors === 0`), THE Recommended_Changes_Panel SHALL render an empty state reading "No recommended changes — all cases passed" with a green success indicator and SHALL NOT invoke the Recommendation_Engine.
3. WHEN a user activates "Re-analyze" on a run with zero failed cases, THE Recommended_Changes_Panel SHALL NOT invoke the Recommendation_Engine and SHALL render an inline message reading "No analysis needed — all cases passed".
4. WHEN the run has at least one failed case AND the Recommendation_Engine returns at least one per-suite or per-case recommendation, THE Recommended_Changes_Panel SHALL render the per-suite recommendations at the top of the panel and the per-case recommendations grouped by root-cause category and bucketed by Tool_Surface beneath them.
5. WHEN the run has at least one failed case AND the Recommendation_Engine returns no recommendations (the model produced an empty array), THE Recommended_Changes_Panel SHALL render an empty state reading "No actionable recommendations were identified for the failed cases in this run" alongside a "Re-analyze" action.
6. THE Recommended_Changes_Panel SHALL render each per-suite recommendation with (a) a priority indicator showing the recommendation's 1-based position in the ordered array, (b) a Tool_Surface badge, (c) the diff view (current text vs suggested text), (d) the `predictedImpact.rationale` text, and (e) a clickable list of `liftedCaseIds` that navigates to each case's detail page.
7. THE Recommended_Changes_Panel SHALL include a "View full failure analysis" link that navigates to the Failure_Analysis_View on the Results Viewer (`/runs/{runId}/results`) so that a single canonical view is the source of truth for full per-case detail.
8. WHILE the run status is `running`, THE Recommended_Changes_Panel SHALL render in a placeholder state showing "Recommendations will appear when the run completes" and SHALL NOT invoke the Recommendation_Engine.
9. WHEN a user revisits the Run Dashboard for a run whose persisted per-suite and per-case analyses already exist, THE Recommended_Changes_Panel SHALL render from the persisted records without invoking Bedrock.

### Requirement 11: Recommendation Source-of-Truth Unification

**User Story:** As a tester moving between the Run Dashboard, the case detail page, and the Failure Analysis page, I want to see the same recommendation text in all three places, so that I'm never confused about which view is authoritative.

#### Acceptance Criteria

1. THE Recommended_Changes_Panel, the per-case detail page recommendations section, and the Failure_Analysis_View SHALL all read from the same persisted per-case analysis records (`PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}`) rather than computing recommendations independently.
2. THE Recommended_Changes_Panel and the Failure_Analysis_View SHALL render the per-suite recommendations from the same persisted record (`PK=RUN#{runId}, SK=ANALYSIS#SUITE`).
3. WHEN a user activates "Re-analyze" on any of the three views, THE Platform SHALL re-invoke the Recommendation_Engine with `force: true` and SHALL update the persisted records, so that the next load on any of the three views renders the new content.
4. THE Failure_Analysis_View SHALL continue to be reachable from the Results Viewer and SHALL remain the canonical full-detail view; this requirement does not deprecate it.

### Requirement 12: Graceful Degradation

**User Story:** As a tester whose Bedrock call fails or whose snapshot is missing, I want the Recommended_Changes_Panel to degrade visibly rather than crash or silently hide, so that I know what is missing and can retry.

#### Acceptance Criteria

1. IF the Bedrock per-suite or per-case call fails with a throttling error, THEN THE Recommendation_Engine SHALL retry with exponential backoff (base 1 second, cap 10 seconds, maximum 2 retries) before surfacing the error to the caller.
2. IF the Bedrock call still fails after retries, THEN THE Recommendation_Engine SHALL return an HTTP 503 response with a `retryable: true` flag, and THE Recommended_Changes_Panel SHALL render an error state with a "Retry" button that re-triggers the call without forcing a full page reload.
3. IF the Agent_Snapshot for the run is missing (no `PK=RUN#{runId}, SK=SNAPSHOT` record), THEN THE Recommendation_Engine SHALL return an HTTP 404 response with `error: "snapshot_missing"`, and THE Recommended_Changes_Panel SHALL render an empty state explaining that recommendations cannot be generated without a snapshot.
4. IF a tool referenced by the Q in Connect agent has no `examples` configured (empty array), THEN THE Recommendation_Engine SHALL still produce recommendations for the other three Tool_Surface values for that tool and SHALL NOT fail the analysis as a whole.
5. IF the per-suite analysis succeeds but one or more per-case analyses fail, THEN THE Recommended_Changes_Panel SHALL render the per-suite recommendations and SHALL render an inline notice listing the case IDs whose per-case analysis failed, so that partial results are visible.
6. IF the persisted analysis for a run was generated against a snapshot schema that predates this feature (no `examples` per tool), THEN THE Recommendation_Engine SHALL render the persisted recommendations as-is and SHALL display a note advising the user to "Re-analyze" to incorporate the now-captured examples.

### Requirement 13: Recommendation Payload Field Constraints

**User Story:** As a frontend engineer rendering a recommendation, I want every recommendation payload to carry the same structural fields with explicit type constraints, so that I can render any recommendation (per-case or per-suite) with one component.

#### Acceptance Criteria

1. THE Platform SHALL define a single shared `Recommendation` shape used by both `Per_Case_Recommendation` and `Per_Suite_Recommendation` containing the fields: `targetField` (one of the four Tool_Surface values), `targetName` (string, the tool name or the literal `"system_prompt"`), `currentText` (string, may be empty for `tool_examples` add operations), `suggestedText` (string, may be empty for `tool_examples` remove operations), and `rationale` (string, may be empty).
2. WHERE the recommendation is a `Per_Suite_Recommendation`, THE shape SHALL additionally carry `priority` (positive integer; lower values indicate higher priority and `1` is the highest priority) and `predictedImpact` (object with `liftedCaseIds: string[]` and `rationale: string`).
3. THE Platform SHALL reject any persisted recommendation record where `targetField` is missing, where `targetName` is missing or empty, or where both `currentText` and `suggestedText` are empty (a no-op recommendation), including the case where a `tool_examples` operation produces both empty fields — a remove operation MUST carry the existing example text in `currentText`, and an add operation MUST carry the new example text in `suggestedText`.

### Requirement 14: Failure Analysis Prompt Includes Examples

**User Story:** As a tester whose tool examples are misleading the agent, I want the per-case analysis prompt to include those examples, so that Bedrock can surface "the example for tool X teaches the wrong pattern" rather than only blaming the description.

#### Acceptance Criteria

1. WHEN the Recommendation_Engine builds a per-case analysis prompt, THE Recommendation_Engine SHALL include each tool's `examples` array in the formatted tool block immediately after the `Instruction` line, labeled `Examples:` and rendered as a numbered list with each example on its own line.
2. WHERE a tool has no examples, THE Recommendation_Engine SHALL render `Examples: (none)` rather than omitting the line.
3. THE Recommendation_Engine SHALL include in the prompt's instructions an explicit clause stating that `tool_examples` is one of the four valid `targetField` values and describing the three example operations (add, remove, replace).

### Requirement 15: Property-Testable Behaviors

**User Story:** As a maintainer, I want the bucketing logic, empty-state handling, and prioritization invariants to be expressible as property tests, so that regressions in those areas are caught automatically.

#### Acceptance Criteria

1. FOR ANY set of `Per_Case_Recommendation` records, the bucketing function SHALL partition the records into exactly four groups keyed by Tool_Surface, where each record appears in exactly one group corresponding to its `targetField`, and the union of the four groups equals the input set.
2. FOR ANY run state where `failed === 0` and `errors === 0`, the Recommended_Changes_Panel render function SHALL return the empty-state element and SHALL NOT call the Recommendation_Engine, regardless of any other run-state field values.
3. FOR ANY array of `Per_Suite_Recommendation` records returned by the Recommendation_Engine for any run, the array SHALL be ordered such that for all indices i < j, recommendation[i].priority is at most recommendation[j].priority (priority ordering is enforced regardless of whether the run has failed cases or how many recommendations the model produced).
4. FOR ANY two persisted per-suite analyses for the same run, repeated reads SHALL return identical ordering of recommendations (no nondeterminism on read).
5. FOR ANY Agent_Snapshot, persisting it to DynamoDB and reading it back SHALL produce a snapshot whose `tools[].examples` arrays are element-wise equal to the input (round-trip property over the new field).
6. FOR ANY two Agent_Snapshots that are element-wise equal across all tool fields including `examples`, `diffAgentConfigs` SHALL return `hasChanges === false` and an empty changes array (the diff function is reflexive over equal-by-value snapshots, including the new field).
