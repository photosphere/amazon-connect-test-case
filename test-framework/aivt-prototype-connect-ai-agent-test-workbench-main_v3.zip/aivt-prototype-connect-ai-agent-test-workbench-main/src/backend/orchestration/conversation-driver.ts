/**
 * Conversation Driver — executes multi-turn test conversations against Q in Connect AI Agents.
 *
 * Implements the core test execution loop:
 * 1. CreateSession with a generated name
 * 2. SendMessage with aiAgentId override
 * 3. Poll GetNextMessage for agent responses
 * 4. Detect filler responses and continue polling
 * 5. Extract tool selections from conversationSessionData
 * 6. For text responses, invoke customer simulator and continue
 * 7. Terminate on: no tool + no text, max turns reached, or timeout
 *
 * Critical API constraints (proven by prototype):
 * - `aiAgentId` goes on SendMessage, NOT CreateSession
 * - Filler responses ("...", "......", "…") with unchanged token must be skipped
 * - Tool name lives in conversationSessionData under key "Tool"
 * - CreateSession requires a `name` parameter; sessionId is nested in response.session
 *
 * @module conversation-driver
 */

import {
  QConnectClient,
  CreateSessionCommand,
  SendMessageCommand,
  GetNextMessageCommand,
  UpdateSessionDataCommand,
  ListSpansCommand,
} from "@aws-sdk/client-qconnect";
import { generateSessionName } from "../../shared/utils/session-name";
import { extractToolName } from "../../shared/utils/tool-extraction";
import { calculateBackoffDelay } from "../../shared/utils/backoff";
import { simulateCustomer } from "./customer-simulator";
import { startContact, stopContact } from "./contact-manager";
import { parseSpansToTrace, augmentTraceWithControlTools, type RawSpan } from "./span-parser";
import { extractRetrievedChunks } from "./chunk-extractor";
import { evaluateOpportunisticFaithfulness } from "./opportunistic-faithfulness";
import { MAX_TURNS, POLL_INTERVAL_MS, POLL_TIMEOUT_MS, MAX_RETRIES } from "../../shared/constants";
import { CaseStatus } from "../../shared/enums";
import type {
  TestCase,
  TestCaseResult,
  TranscriptTurn,
  ExecutionTrace,
  ToolSequenceTestCase,
  RagTestCase,
  RetrievedChunk,
  RagThresholds,
  AgentSnapshot,
  ToolDefinition,
} from "../../shared/types";
import { DynamoDBService } from "../services/dynamodb";

// --- Configuration ---

const REGION = process.env.AWS_REGION ?? "us-east-1";

/**
 * Normalizes the AI Agent ID for the SendMessage `aiAgentId` parameter.
 *
 * The proven prototype (reference/run_test.py) passes a BARE agent UUID on
 * SendMessage and successfully routes to the ORCHESTRATION agent. Wrapping the
 * id in a full ARN, adding a version qualifier, or registering an orchestrator
 * use case all route the message back through the assistant's default
 * SELF_SERVICE agent instead (confirmed via ListSpans). So we deliberately
 * pass the bare UUID and nothing else.
 *
 * If a full ARN or version-qualified id is provided, we strip it back down to
 * the bare UUID to match the prototype exactly.
 */
function toBareAgentId(agentId: string): string {
  // Strip an ARN prefix → "uuid" or "uuid:$VERSION".
  let id = agentId.startsWith("arn:") ? agentId.split("/").pop()! : agentId;
  // Strip any version qualifier (":$LATEST", ":1", etc.).
  const colonIdx = id.indexOf(":");
  if (colonIdx !== -1) {
    id = id.substring(0, colonIdx);
  }
  return id;
}

// --- Q in Connect Client ---

let qconnectClient: QConnectClient | null = null;

function getQConnectClient(): QConnectClient {
  if (!qconnectClient) {
    qconnectClient = new QConnectClient({ region: REGION });
  }
  return qconnectClient;
}

/**
 * Allows injection of a custom Q in Connect client for testing.
 * @internal
 */
export function _setQConnectClient(client: QConnectClient | null): void {
  qconnectClient = client;
}

// --- DynamoDB Service (for loading agent snapshot) ---

let dynamoService: DynamoDBService | null = null;

function getDynamoService(): DynamoDBService {
  if (!dynamoService) {
    dynamoService = new DynamoDBService();
  }
  return dynamoService;
}

/**
 * Allows injection of a custom DynamoDB service for testing.
 * @internal
 */
export function _setDynamoService(service: DynamoDBService | null): void {
  dynamoService = service;
}

// --- Helper: Find Retrieve tool name from snapshot ---

/**
 * Finds the Retrieve tool name from the agent's tool definitions.
 * Matches by toolType containing "RETRIEVE" (case-insensitive) OR by toolName
 * being exactly "Retrieve" (case-insensitive). The latter is needed because
 * Q in Connect classifies the built-in Retrieve tool as MODEL_CONTEXT_PROTOCOL
 * rather than a dedicated "RETRIEVE" type — so name-based matching is the
 * reliable path for the built-in KB retrieval tool.
 */
function findRetrieveToolName(tools: ToolDefinition[]): string | undefined {
  for (const tool of tools) {
    if (tool.toolType && tool.toolType.toUpperCase().includes("RETRIEVE")) {
      return tool.toolName;
    }
    if (tool.toolName && tool.toolName.toLowerCase() === "retrieve") {
      return tool.toolName;
    }
  }
  return undefined;
}

// --- Helper: sleep ---

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// --- Helper: ISO timestamp ---

function now(): string {
  return new Date().toISOString();
}

// --- Throttle Detection ---

/**
 * Determines whether an error is a throttling error that should be retried.
 *
 * Checks for:
 * - ThrottlingException (AWS SDK error name)
 * - TooManyRequestsException (AWS SDK error name)
 * - HTTP 429 status code (generic rate limit)
 *
 * @param error - The error to inspect
 * @returns true if the error is a throttling error eligible for retry
 */
export function isThrottlingError(error: unknown): boolean {
  if (error == null || typeof error !== "object") {
    return false;
  }
  const err = error as Record<string, unknown>;

  // Check AWS SDK error name
  const name = err.name ?? err.code ?? "";
  if (
    name === "ThrottlingException" ||
    name === "TooManyRequestsException"
  ) {
    return true;
  }

  // Check HTTP status code
  const statusCode =
    err.$metadata && typeof err.$metadata === "object"
      ? (err.$metadata as Record<string, unknown>).httpStatusCode
      : err.statusCode ?? err.$httpStatusCode;
  if (statusCode === 429) {
    return true;
  }

  return false;
}

/**
 * Wraps an async operation with throttle retry logic using exponential backoff with jitter.
 *
 * On throttling errors (ThrottlingException, TooManyRequestsException, HTTP 429),
 * retries up to MAX_RETRIES times with exponential backoff (base 2s, cap 30s, full jitter).
 * Non-throttling errors are thrown immediately without retry.
 *
 * @param operation - The async function to execute
 * @returns The result of the operation
 * @throws The original error if all retries are exhausted or if the error is not a throttling error
 */
async function withThrottleRetry<T>(operation: () => Promise<T>): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      return await operation();
    } catch (error: unknown) {
      lastError = error;
      if (!isThrottlingError(error) || attempt >= MAX_RETRIES) {
        throw error;
      }
      const delay = calculateBackoffDelay(attempt);
      await sleep(delay);
    }
  }
  // Should not reach here, but satisfy TypeScript
  throw lastError;
}

// --- Session Management ---

/**
 * Creates a new Q in Connect session with a generated name, bound to a real
 * Amazon Connect contact.
 *
 * The agent is selected per-message via the `aiAgentId` param on SendMessage
 * (NOT via session config — that routes through the default SELF_SERVICE agent).
 *
 * We DO bind a real contact via `contactArn`. ORCHESTRATION agent MCP tools read
 * the bound contact's ContactARN from the session runtime; without it they fail
 * with "ContactARN not found in session" and the agent escalates. A fabricated
 * ARN is rejected by Connect, so the caller must mint a genuine contact first.
 *
 * Includes throttle retry with exponential backoff (base 2s, cap 30s, max 3 retries).
 *
 * @param assistantId - The Q in Connect assistant ID
 * @param contactArn - The fully-qualified ARN of a real (minted) Connect contact
 * @returns The created session ID
 */
async function createSession(assistantId: string, contactArn: string): Promise<string> {
  return withThrottleRetry(async () => {
    const client = getQConnectClient();
    const sessionName = generateSessionName();

    const command = new CreateSessionCommand({
      assistantId,
      name: sessionName,
      contactArn,
    });

    const response = await client.send(command);
    const sessionId = response.session?.sessionId;

    if (!sessionId) {
      throw new Error("CreateSession response did not contain session.sessionId");
    }

    return sessionId;
  });
}


/**
 * Injects key/value data into the session via UpdateSessionData BEFORE the
 * conversation starts, mirroring how Amazon Connect contact flows seed
 * session context (e.g. ANI / customerPhoneNumber). The injected keys become
 * available to the agent's prompt as {{$.Custom.<KEY>}}.
 *
 * @param assistantId - The Q in Connect assistant ID
 * @param sessionId - The session to inject data into
 * @param sessionData - Key/value pairs to attach to the session
 */
async function injectSessionData(
  assistantId: string,
  sessionId: string,
  sessionData: Record<string, string>
): Promise<void> {
  const entries = Object.entries(sessionData).filter(
    ([k, v]) => k && v != null && String(v).trim() !== ""
  );
  if (entries.length === 0) return;

  const data = entries.map(([key, value]) => ({
    key,
    value: { stringValue: String(value) },
  }));

  console.log(
    `[conversation-driver] Injecting session data keys: ${entries.map(([k]) => k).join(", ")}`
  );

  await withThrottleRetry(async () => {
    const client = getQConnectClient();
    await client.send(
      new UpdateSessionDataCommand({
        assistantId,
        sessionId,
        namespace: "Custom",
        data,
      })
    );
  });
}

// --- Message Sending ---

/**
 * Sends a text message to the Q in Connect session with aiAgentId override.
 * Includes throttle retry with exponential backoff (base 2s, cap 30s, max 3 retries).
 *
 * @param assistantId - The assistant ID
 * @param sessionId - The session ID
 * @param agentId - The AI agent ID to override (goes on SendMessage)
 * @param text - The message text to send
 * @returns The nextMessageToken for polling
 */
async function sendMessage(
  assistantId: string,
  sessionId: string,
  agentId: string,
  text: string
): Promise<string> {
  return withThrottleRetry(async () => {
    const client = getQConnectClient();

    // Pass a BARE agent UUID, exactly as the proven prototype does. Wrapping it
    // in an ARN, adding a version qualifier, or setting orchestratorUseCase all
    // route the message back through the default SELF_SERVICE agent instead of
    // our ORCHESTRATION agent.
    const bareAgentId = toBareAgentId(agentId);

    console.log(`[conversation-driver] SendMessage assistantId=${assistantId} sessionId=${sessionId} aiAgentId=${bareAgentId} text=${text.substring(0, 50)}`);

    const command = new SendMessageCommand({
      assistantId,
      sessionId,
      type: "TEXT",
      message: {
        value: {
          text: { value: text },
        },
      },
      // aiAgentId on SendMessage (bare UUID) directly invokes the specified
      // orchestration agent's tool selection logic, bypassing the SELF_SERVICE
      // wrapper. This is the single critical parameter proven by the prototype.
      aiAgentId: bareAgentId,
    });

    const response = await client.send(command);
    const nextToken = response.nextMessageToken;

    if (!nextToken) {
      throw new Error("SendMessage response did not contain nextMessageToken");
    }

    return nextToken;
  });
}

// --- Polling ---

/**
 * Result from consuming a complete agent turn.
 *
 * An agent "turn" may span multiple streamed messages: latency masks
 * ("Let me check..."), one or more tool invocations, tool results, and a
 * final message to the customer. We consume all of them until the agent
 * goes quiet (yields back to the customer) or the conversation closes.
 */
interface PollResult {
  /** Real MCP tools invoked during this turn, in chronological order. */
  toolsInvoked: string[];
  /** The agent's final text message to the customer (the question/statement to respond to). */
  agentText: string | null;
  /** True if the conversation reached a terminal CLOSED state (agent ended the conversation). */
  conversationClosed: boolean;
  /** True if the poll cycle exceeded the timeout. */
  timedOut: boolean;
}

/**
 * Consumes a complete agent turn by polling GetNextMessage repeatedly.
 *
 * The Q in Connect orchestration agent streams a turn as multiple messages:
 * - Latency masks ("Let me check...") — pseudo-tool QUESTION/CONVERSATION, keep consuming
 * - Real MCP tool invocations (type=TOOL_USE_RESULT or non-pseudo tool) — record, keep consuming
 * - A final text message directed at the customer — this is what we respond to
 *
 * We keep consuming until the agent goes quiet (no new content for QUIET_THRESHOLD
 * consecutive polls while READY) or the conversation CLOSES. The "quiet period" is
 * how we distinguish a genuine question (agent waits) from a latency mask (agent
 * keeps producing output).
 *
 * @param assistantId - The assistant ID
 * @param sessionId - The session ID
 * @param nextMessageToken - The token to poll from
 * @param options - Optional configuration
 * @param options.waitPastEndText - When true, on END_TEXT do a continuation check
 *   to see if the agent is about to invoke a tool. Used by RAG single-turn flow
 *   where the agent emits a filler response before calling Retrieve.
 * @returns PollResult with all tools invoked, the final agent text, and terminal flags
 */
async function pollForResponse(
  assistantId: string,
  sessionId: string,
  nextMessageToken: string,
  options?: { waitPastEndText?: boolean }
): Promise<PollResult> {
  const client = getQConnectClient();
  const startTime = Date.now();
  let currentToken = nextMessageToken;

  // Accumulated state across the whole agent turn
  const toolsInvoked: string[] = [];
  const seenToolKeys = new Set<string>(); // de-dupe repeated tool reports
  let lastText: string | null = null;

  while (Date.now() - startTime < POLL_TIMEOUT_MS) {
    const command = new GetNextMessageCommand({
      assistantId,
      sessionId,
      nextMessageToken: currentToken,
    });

    const response = await client.send(command);

    const newToken = response.nextMessageToken ?? currentToken;
    const tokenAdvanced = newToken !== currentToken;
    const status = response.conversationState?.status;
    const msgType = response.type as string | undefined; // TEXT | END_TEXT | TOOL_USE_RESULT
    const chunkedTerminated = response.chunkedResponseTerminated;

    // Extract text from this message
    const responseValue = response.response?.value;
    let chunkText = "";
    if (responseValue && "text" in responseValue && responseValue.text?.value) {
      chunkText = responseValue.text.value;
    }

    // Extract tool indicator from conversationSessionData
    const toolName = extractToolName(
      response.conversationSessionData as
        | { key: string; value: { stringValue?: string } }[]
        | undefined
    );
    const isConversationalAction =
      toolName === null || toolName === "QUESTION" || toolName === "CONVERSATION";
    const isRealTool = !!toolName && !isConversationalAction;

    console.log(
      `[poll] type="${msgType}" tool="${toolName}" status="${status}" chunkTerm=${chunkedTerminated} text="${(chunkText || "").substring(0, 40)}"`
    );

    // Record real MCP tool invocations (de-duped by message id)
    if (isRealTool) {
      const dedupeKey = `${response.requestMessageId ?? ""}:${toolName}`;
      if (!seenToolKeys.has(dedupeKey)) {
        seenToolKeys.add(dedupeKey);
        toolsInvoked.push(toolName!);
        console.log(`[poll] Recorded real tool: ${toolName}`);
      }
    }

    // Capture any real text on this message (regardless of type/status)
    {
      const t = chunkText.trim();
      if (t && !FILLER_PATTERNS.has(t)) {
        lastText = chunkText;
      }
    }

    // CLOSED is terminal regardless of message type — the agent ended the
    // conversation (e.g. after ESCALATION). Return immediately.
    if (status === "CLOSED") {
      return {
        toolsInvoked,
        agentText: lastText,
        conversationClosed: true,
        timedOut: false,
      };
    }

    // TEXT messages carry the real agent response content.
    // Turn-complete signal: status=READY AND the nextMessageToken has stopped
    // advancing. While the agent has more to emit (latency masks, tool calls,
    // more text), the token keeps advancing. When it stabilizes at READY, the
    // agent has delivered its final message and is waiting for the customer.
    // Tool latency is safe: during tool execution status is PROCESSING, so we
    // keep polling regardless of the token.
    if (msgType === "TEXT") {
      const trimmed = chunkText.trim();
      if (trimmed && !FILLER_PATTERNS.has(trimmed)) {
        lastText = chunkText;
      }
      if (status === "READY" && !tokenAdvanced) {
        // Token stable at READY → agent's turn is complete.
        return {
          toolsInvoked,
          agentText: lastText,
          conversationClosed: false,
          timedOut: false,
        };
      }
      // Token advanced or still PROCESSING — more content coming, keep polling.
      currentToken = newToken;
      await sleep(POLL_INTERVAL_MS);
      continue;
    }

    // END_TEXT marks the end of ONE streamed response from the agent. However,
    // this is NOT necessarily the end of the agent's TURN. The agent may emit a
    // filler response ("Let me look that up..."), close it with END_TEXT, then
    // invoke a tool (status → PROCESSING), and after the tool returns, stream a
    // NEW response with the substantive answer (followed by its own END_TEXT).
    //
    // In the multi-turn tool-sequence flow, this doesn't matter — the outer loop
    // treats the filler as "agent spoke" and the customer simulator responds,
    // giving the agent another turn. But in RAG single-turn mode, we only get
    // one shot, so we need to peek past END_TEXT to catch the tool invocation.
    //
    // The `waitPastEndText` option enables a continuation check: poll once more
    // after END_TEXT. If the agent transitions to PROCESSING or the token
    // advances, continue. Otherwise return.
    if (msgType === "END_TEXT") {
      if (options?.waitPastEndText) {
        // RAG mode: check if the agent is about to start a tool call.
        await sleep(POLL_INTERVAL_MS);

        const peekCommand = new GetNextMessageCommand({
          assistantId,
          sessionId,
          nextMessageToken: newToken,
        });
        const peekResponse = await client.send(peekCommand);
        const peekStatus = peekResponse.conversationState?.status;
        const peekToken = peekResponse.nextMessageToken ?? newToken;
        const peekTokenAdvanced = peekToken !== newToken;

        if (peekStatus === "CLOSED") {
          return {
            toolsInvoked,
            agentText: lastText,
            conversationClosed: true,
            timedOut: false,
          };
        }

        if (peekStatus === "PROCESSING" || peekTokenAdvanced) {
          // Agent is still working — continue the main polling loop.
          console.log(
            `[poll] END_TEXT followed by status="${peekStatus}" tokenAdvanced=${peekTokenAdvanced} — continuing poll`
          );
          currentToken = peekToken;
          continue;
        }
      }

      // Standard path (or peek showed READY+stable): turn is complete.
      return {
        toolsInvoked,
        agentText: lastText,
        conversationClosed: false,
        timedOut: false,
      };
    }

    // PROCESSING (or any non-terminal state) with no TEXT — agent still working.
    if (status === "PROCESSING") {
      currentToken = newToken;
      await sleep(POLL_INTERVAL_MS);
      continue;
    }

    // READY with a non-chunked terminal message (no TEXT/END_TEXT pattern).
    if (status === "READY") {
      // If chunked response is still in progress, keep polling.
      if (chunkedTerminated === false) {
        currentToken = newToken;
        await sleep(POLL_INTERVAL_MS);
        continue;
      }
      // Non-chunked terminal: use this message's text if present.
      const finalText =
        lastText ??
        (chunkText.trim() && !FILLER_PATTERNS.has(chunkText.trim()) ? chunkText : null);
      return {
        toolsInvoked,
        agentText: finalText,
        conversationClosed: false,
        timedOut: false,
      };
    }

    // Unknown state — keep polling
    currentToken = newToken;
    await sleep(POLL_INTERVAL_MS);
  }

  // Timed out — return whatever we accumulated
  return {
    toolsInvoked,
    agentText: lastText,
    conversationClosed: false,
    timedOut: true,
  };
}

/** Known filler text patterns from Q in Connect. */
const FILLER_PATTERNS: ReadonlySet<string> = new Set(["...", "......", "\u2026"]);

// --- Execution Trace from ListSpans (authoritative tool source) ---

/**
 * Fetches all spans for a session and parses them into a structured
 * ExecutionTrace. ListSpans is the authoritative source for the tool sequence:
 * MODEL_CONTEXT_PROTOCOL tools (verifyIdentity, getAccounts, ...) appear ONLY
 * as `execute_tool` spans, never in conversationSessionData. Best-effort:
 * returns null on failure (the conversation result still stands).
 *
 * @param assistantId - The assistant ID
 * @param sessionId - The session whose spans to read
 * @returns A structured ExecutionTrace, or null if spans could not be fetched
 */
async function fetchExecutionTrace(
  assistantId: string,
  sessionId: string
): Promise<ExecutionTrace | null> {
  try {
    const client = getQConnectClient();
    const rawSpans: RawSpan[] = [];
    let nextToken: string | undefined;
    do {
      const resp = await client.send(
        new ListSpansCommand({ assistantId, sessionId, nextToken, maxResults: 100 })
      );
      for (const s of resp.spans ?? []) {
        rawSpans.push(s as RawSpan);
      }
      nextToken = resp.nextToken;
    } while (nextToken);

    if (rawSpans.length === 0) return null;
    return parseSpansToTrace(sessionId, rawSpans);
  } catch (error) {
    console.warn(
      `[conversation-driver] fetchExecutionTrace failed for session ${sessionId}: ${
        error instanceof Error ? error.message : String(error)
      }`
    );
    return null;
  }
}

// --- Tool Sequence Accumulation ---

/**
 * Extracts tool names from transcript turns in chronological order.
 *
 * Iterates through all turns and collects the `toolSelected` field
 * where present, preserving the original turn order.
 *
 * @param turns - Array of transcript turns
 * @returns Array of tool names in the order they were invoked
 */
export function accumulateToolSequence(turns: TranscriptTurn[]): string[] {
  const tools: string[] = [];
  for (const turn of turns) {
    if (turn.toolSelected) {
      tools.push(turn.toolSelected);
    }
  }
  return tools;
}

// --- RAG Single-Turn Execution ---

/**
 * Executes a single RAG test case against a Q in Connect AI Agent.
 *
 * Implements the single-turn RAG flow (no Customer_Simulator):
 * 1. CreateSession (suite's assistant, bound to minted contact)
 * 2. IF case.sessionData → UpdateSessionData
 * 3. SendMessage(question) — single message, no simulator
 * 4. PollForResponse — capture agent's terminal text
 * 5. ListSpans → extractRetrievedChunks(spans, retrieveToolName)
 * 6. Persist: transcript, retrievedChunks
 * 7. StopContact (cleanup)
 *
 * @param testCase - The RAG test case to execute
 * @param agentId - The AI agent ID (passed on SendMessage)
 * @param assistantId - The Q in Connect assistant ID
 * @param connectInstanceId - The Amazon Connect instance ID (for minting a contact)
 * @param contactFlowId - The dummy contact-creator flow ID (for minting a contact)
 * @param retrieveToolName - The name of the Retrieve tool for chunk extraction
 * @returns The test case result with transcript, retrieved chunks, and optional session ID
 */
async function executeRagTestCase(
  testCase: RagTestCase,
  agentId: string,
  assistantId: string,
  connectInstanceId: string,
  contactFlowId: string,
  retrieveToolName: string | undefined,
): Promise<TestCaseResult & { transcript: TranscriptTurn[]; executionTrace?: ExecutionTrace; sessionId?: string; agentResponse?: string }> {
  const startTime = Date.now();
  const transcript: TranscriptTurn[] = [];
  let mintedContactId: string | null = null;
  let sessionId: string | null = null;
  let status: CaseStatus = CaseStatus.PASSED;
  let errorMessage: string | undefined;
  let retrievedChunks: RetrievedChunk[] | undefined;
  let executionTrace: ExecutionTrace | undefined;
  let agentResponse: string | undefined;

  try {
    // Step 0: Mint a real Amazon Connect contact so the session has a bindable ContactARN.
    const contact = await startContact(connectInstanceId, contactFlowId);
    mintedContactId = contact.contactId;
    console.log(
      `[conversation-driver] [RAG] Minted contact ${contact.contactId} for case ${testCase.caseId}`
    );

    // Step 1: Create the session bound to the minted contact.
    sessionId = await createSession(assistantId, contact.contactArn);

    // Step 2: Inject session data if present (e.g. content tag filter keys).
    if (testCase.sessionData && Object.keys(testCase.sessionData).length > 0) {
      await injectSessionData(assistantId, sessionId, testCase.sessionData);
    }

    // Step 3: Send the question as a single message (no simulator).
    const customerTimestamp = now();
    transcript.push({
      turnNumber: 1,
      role: "customer",
      text: testCase.question,
      timestamp: customerTimestamp,
      elapsedMs: 0,
    });

    const nextToken = await sendMessage(assistantId, sessionId, agentId, testCase.question);

    // Step 4: Poll for the agent's terminal response.
    // Use waitPastEndText so we don't return the filler ("I'll search our
    // knowledge base...") that the agent emits before calling Retrieve.
    const pollResult = await pollForResponse(assistantId, sessionId, nextToken, { waitPastEndText: true });

    if (pollResult.timedOut) {
      status = CaseStatus.ERROR;
      errorMessage = "Poll timeout exceeded during RAG case execution";
    } else if (pollResult.agentText) {
      agentResponse = pollResult.agentText;
      transcript.push({
        turnNumber: 2,
        role: "agent",
        text: pollResult.agentText,
        timestamp: now(),
        elapsedMs: Date.now() - startTime,
      });
    } else {
      // Agent produced no text — still a valid (if unusual) outcome
      agentResponse = "";
      transcript.push({
        turnNumber: 2,
        role: "agent",
        text: "",
        timestamp: now(),
        elapsedMs: Date.now() - startTime,
      });
    }

    // Step 5: ListSpans → extract retrieved chunks
    if (status !== CaseStatus.ERROR && sessionId) {
      const client = getQConnectClient();
      const rawSpans: RawSpan[] = [];
      let listNextToken: string | undefined;
      do {
        const resp = await client.send(
          new ListSpansCommand({ assistantId, sessionId, nextToken: listNextToken, maxResults: 100 })
        );
        for (const s of resp.spans ?? []) {
          rawSpans.push(s as RawSpan);
        }
        listNextToken = resp.nextToken;
      } while (listNextToken);

      // Parse execution trace from spans
      if (rawSpans.length > 0) {
        executionTrace = parseSpansToTrace(sessionId, rawSpans);
      }

      // Extract retrieved chunks using the Retrieve tool name
      if (retrieveToolName) {
        retrievedChunks = extractRetrievedChunks(rawSpans, retrieveToolName);
        console.log(
          `[conversation-driver] [RAG] Extracted ${retrievedChunks.length} chunks for case ${testCase.caseId}`
        );
      } else {
        // No Retrieve tool found in agent config — no chunks to extract
        retrievedChunks = [];
        console.log(
          `[conversation-driver] [RAG] No Retrieve tool configured — 0 chunks for case ${testCase.caseId}`
        );
      }
    }
  } catch (error: unknown) {
    status = CaseStatus.ERROR;
    errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`[conversation-driver] [RAG] Case ${testCase.caseId} errored: ${errorMessage}`);
  } finally {
    // Always tear down the minted contact (best-effort cleanup).
    if (mintedContactId) {
      await stopContact(connectInstanceId, mintedContactId);
      console.log(
        `[conversation-driver] [RAG] Stopped contact ${mintedContactId} for case ${testCase.caseId}`
      );
    }
  }

  const latencyMs = Date.now() - startTime;
  return {
    runId: "",
    caseId: testCase.caseId,
    status,
    toolsInvoked: [],
    turnCount: transcript.length,
    latencyMs,
    caseType: "rag",
    ...(errorMessage ? { errorMessage } : {}),
    ...(retrievedChunks !== undefined ? { retrievedChunks } : {}),
    transcript,
    ...(executionTrace ? { executionTrace } : {}),
    ...(sessionId ? { sessionId } : {}),
    ...(agentResponse !== undefined ? { agentResponse } : {}),
  };
}

// --- Main Execution ---

/**
 * Executes a single test case against a Q in Connect AI Agent.
 *
 * Manages the full conversation lifecycle:
 * 1. Creates a session
 * 2. Sends the initial utterance
 * 3. Polls for agent responses
 * 4. Handles tool selections (record + send "continue")
 * 5. Handles text responses (simulate customer + send response)
 * 6. Terminates on: no output, max turns, or timeout
 *
 * Error handling:
 * - Throttling errors (429, ThrottlingException, TooManyRequestsException) are retried
 *   with exponential backoff (base 2s, cap 30s, max 3 retries)
 * - Non-throttling errors mark the case as "error" with failure reason (suite continues)
 * - Poll timeout marks the case as "timed_out" (suite continues)
 *
 * @param testCase - The test case to execute
 * @param agentId - The AI agent ID (passed on SendMessage)
 * @param assistantId - The Q in Connect assistant ID
 * @param connectInstanceId - The Amazon Connect instance ID (for minting a contact)
 * @param contactFlowId - The dummy contact-creator flow ID (for minting a contact)
 * @param runId - The run id whose pinned snapshot supplies the
 *                `customer_simulator` prompt for in-conversation turns
 *                (R11.2). Empty string is tolerated for unit tests and
 *                the rare pre-feature run path; the runtime resolver
 *                falls back to the live registry in that case.
 * @returns The test case result with transcript and tools invoked
 */
export async function executeTestCase(
  testCase: TestCase,
  agentId: string,
  assistantId: string,
  connectInstanceId: string,
  contactFlowId: string,
  runId: string = ""
): Promise<TestCaseResult & { transcript: TranscriptTurn[]; executionTrace?: ExecutionTrace; sessionId?: string }> {
  const startTime = Date.now();
  const transcript: TranscriptTurn[] = [];
  // Control tools (Complete/Escalate) captured from conversationSessionData
  // during polling. The authoritative MCP tool sequence is derived from spans
  // at the end and takes precedence; this is a fallback if spans are missing.
  const controlToolsInvoked: string[] = [];
  let turnNumber = 0;
  let mintedContactId: string | null = null;
  let sessionId: string | null = null;
  let status: CaseStatus = CaseStatus.PASSED;
  let errorMessage: string | undefined;

  try {
    // Step 0: Mint a real Amazon Connect contact so the session has a bindable
    // ContactARN. ORCHESTRATION agent MCP tools read this from the session
    // runtime; without it they fail with "ContactARN not found in session".
    const ani = testCase.sessionData?.ANI;
    const contact = await startContact(connectInstanceId, contactFlowId, ani);
    mintedContactId = contact.contactId;
    console.log(
      `[conversation-driver] Minted contact ${contact.contactId} for case ${testCase.caseId}`
    );

    // Step 1: Create the session bound to the minted contact. The agent is
    // selected per-message via aiAgentId on SendMessage (NOT on the session).
    sessionId = await createSession(assistantId, contact.contactArn);

    // Step 1b: Inject any pre-conversation session data (e.g. customerPhoneNumber)
    // so the agent has the customer context it needs — mirrors Connect's flow.
    if (testCase.sessionData && Object.keys(testCase.sessionData).length > 0) {
      await injectSessionData(assistantId, sessionId, testCase.sessionData);
    }

    // Step 1c: Optional priming message — establishes the agent's role/context
    // before the customer speaks, mirroring how Connect contact flows kick off
    // the agent. We consume (and discard) the agent's greeting response so it is
    // not treated as a customer-facing turn.
    const tsCase = testCase as ToolSequenceTestCase;
    if (tsCase.primingMessage && tsCase.primingMessage.trim() !== "") {
      console.log(`[conversation-driver] Sending priming message: "${tsCase.primingMessage.substring(0, 80)}"`);
      const primingToken = await sendMessage(
        assistantId,
        sessionId,
        agentId,
        tsCase.primingMessage
      );
      // Consume the agent's greeting turn (record tools if any, ignore the text)
      const primingResult = await pollForResponse(assistantId, sessionId, primingToken);
      for (const t of primingResult.toolsInvoked) {
        controlToolsInvoked.push(t);
      }
      console.log(`[conversation-driver] Priming greeting: "${(primingResult.agentText ?? "").substring(0, 80)}"`);
    }

    // Step 2: Send initial utterance.
    //
    // The initial utterance IS the customer's first turn from the
    // conversation's point of view — it's the line the test case
    // authored as "what the customer says first". We push it onto the
    // transcript BEFORE sending it to the agent so:
    //
    //   1. The persisted transcript faithfully reflects the
    //      conversation order (customer → agent → customer → agent →
    //      ...). Without this row, downstream consumers see "agent
    //      speaks first" which never happens in practice.
    //   2. The Bedrock judge's per-turn alignment in
    //      `groupTraceIntoTurns` works correctly. That helper pairs
    //      customer turns with assistant turns positionally
    //      (customerTurns[i] → assistant-turn-i). Missing the
    //      initial-utterance row caused a one-position shift, so
    //      every Helpfulness / ToolSelection evaluator was scored
    //      against the wrong customer turn.
    //
    // We use a synthetic timestamp slightly before the first agent
    // response (Date.now() right now is the moment the message hits
    // the wire). `elapsedMs` is 0 since the case clock starts here.
    turnNumber++;
    transcript.push({
      turnNumber,
      timestamp: now(),
      role: "customer",
      text: tsCase.initialUtterance,
      elapsedMs: 0,
    });
    let nextToken = await sendMessage(assistantId, sessionId, agentId, tsCase.initialUtterance);

    // Step 3: Multi-turn conversation loop.
    // Each iteration consumes one full agent turn (which may include multiple
    // tool invocations and latency masks), then responds as the customer.
    let timedOut = false;
    let endedNaturally = false;
    for (let turn = 0; turn < MAX_TURNS; turn++) {
      const result = await pollForResponse(assistantId, sessionId, nextToken);

      // Timeout — mark case as timed out and stop.
      if (result.timedOut) {
        for (const t of result.toolsInvoked) controlToolsInvoked.push(t);
        timedOut = true;
        break;
      }

      // Record control tools (Complete/Escalate) captured this turn, in order.
      for (const toolName of result.toolsInvoked) {
        console.log(`[conversation-driver] Turn ${turn}: CONTROL TOOL: ${toolName}`);
        controlToolsInvoked.push(toolName);
        turnNumber++;
        transcript.push({
          turnNumber,
          role: "agent",
          text: "",
          toolSelected: toolName,
          timestamp: now(),
          elapsedMs: Date.now() - startTime,
        });
      }

      // A RETURN_TO_CONTROL tool (Complete / Escalate / any custom control
      // tool) hands control back from the AI agent to Amazon Connect. At that
      // point there is no longer an agent to converse with, so the simulation
      // MUST end — regardless of whether Q in Connect has flipped the session
      // to CLOSED yet. The tools captured by the poll loop come from
      // conversationSessionData["Tool"], which reports ONLY RETURN_TO_CONTROL
      // tools (MCP tools surface separately via ListSpans), so any entry here
      // is an RTC handoff. Capture any final agent text, then terminate.
      if (result.toolsInvoked.length > 0) {
        console.log(
          `[conversation-driver] Turn ${turn}: RETURN_TO_CONTROL tool invoked (${result.toolsInvoked.join(", ")}) — ending simulation`
        );
        if (result.agentText) {
          turnNumber++;
          transcript.push({
            turnNumber,
            role: "agent",
            text: result.agentText,
            timestamp: now(),
            elapsedMs: Date.now() - startTime,
          });
        }
        endedNaturally = true;
        break;
      }

      // If the agent closed the conversation, we're done.
      if (result.conversationClosed) {
        console.log(`[conversation-driver] Turn ${turn}: conversation CLOSED by agent`);
        if (result.agentText) {
          turnNumber++;
          transcript.push({
            turnNumber,
            role: "agent",
            text: result.agentText,
            timestamp: now(),
            elapsedMs: Date.now() - startTime,
          });
        }
        endedNaturally = true;
        break;
      }

      // The agent has gone quiet and is waiting for the customer.
      // If it produced a final text message, respond as the customer.
      if (result.agentText) {
        console.log(`[conversation-driver] Turn ${turn}: Agent waiting, text: "${result.agentText.substring(0, 100)}"`);
        turnNumber++;
        transcript.push({
          turnNumber,
          role: "agent",
          text: result.agentText,
          timestamp: now(),
          elapsedMs: Date.now() - startTime,
        });

        // Simulate customer response
        const customerResponse = await simulateCustomer(result.agentText, tsCase, transcript, runId);
        console.log(`[conversation-driver] Turn ${turn}: Customer response: "${customerResponse.substring(0, 100)}"`);

        turnNumber++;
        transcript.push({
          turnNumber,
          role: "customer",
          text: customerResponse,
          timestamp: now(),
          elapsedMs: Date.now() - startTime,
        });

        // Send customer response back to agent
        nextToken = await sendMessage(assistantId, sessionId, agentId, customerResponse);
      } else {
        // No tools, no text, not closed — nothing more to do.
        console.log(`[conversation-driver] Turn ${turn}: no output — ending conversation`);
        endedNaturally = true;
        break;
      }
    }

    // Determine terminal status:
    // - timed_out: a poll cycle exceeded POLL_TIMEOUT_MS.
    // - failed (stuck): the loop exhausted MAX_TURNS without the agent ever
    //   reaching a natural end (no RETURN_TO_CONTROL tool, no CLOSED, no quiet
    //   exit). This means the conversation never progressed to resolution —
    //   the agent looped (e.g. repeating "please hold for a specialist") or
    //   otherwise failed to advance. That is a genuine failure signal about
    //   the agent or the test case, NOT a pass.
    // - passed: the conversation ended naturally within the turn budget.
    if (timedOut) {
      status = CaseStatus.TIMED_OUT;
      errorMessage = "Poll timeout exceeded (60s)";
    } else if (!endedNaturally) {
      status = CaseStatus.FAILED;
      errorMessage = `Conversation did not reach a resolution within the ${MAX_TURNS}-turn limit. The agent never handed control back (no Complete/Escalate) and never ended the conversation — it may be stuck in a loop or failing to progress toward the customer's goal.`;
      console.warn(
        `[conversation-driver] Case ${testCase.caseId} hit MAX_TURNS (${MAX_TURNS}) without natural termination — marking FAILED (stuck conversation)`
      );
    } else {
      status = CaseStatus.PASSED;
    }
  } catch (error: unknown) {
    // Non-throttling errors (or exhausted throttle retries) — mark case as "error"
    status = CaseStatus.ERROR;
    errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`[conversation-driver] Case ${testCase.caseId} errored: ${errorMessage}`);
  } finally {
    // Always tear down the minted contact (best-effort; it also auto-expires).
    if (mintedContactId) {
      await stopContact(connectInstanceId, mintedContactId);
      console.log(
        `[conversation-driver] Stopped contact ${mintedContactId} for case ${testCase.caseId}`
      );
    }
  }

  // Step 4: Finalize. Fetch the authoritative execution trace from ListSpans —
  // this is the ONLY reliable source for MCP tool invocations (verifyIdentity,
  // getAccounts, ...), which never appear in conversationSessionData. The
  // trace's toolSequence supersedes the control-tool list for scoring/analysis.
  let executionTrace: ExecutionTrace | undefined;
  let toolsInvoked: string[] = controlToolsInvoked;

  if (sessionId && status !== CaseStatus.ERROR) {
    const trace = await fetchExecutionTrace(assistantId, sessionId);
    if (trace) {
      // Augment the trace with synthetic tool steps for any RETURN_TO_CONTROL
      // tool the polling loop captured but ListSpans did NOT surface as an
      // `execute_tool` span (e.g. Escalate / Complete / any custom control
      // tool a developer wires through Q in Connect). This keeps
      // executionTrace.steps[] and the judge's {context} prompt in sync
      // with what the case row records as `toolsInvoked`. See
      // `augmentTraceWithControlTools` for rationale.
      const augmentedTrace = augmentTraceWithControlTools(trace, controlToolsInvoked);
      executionTrace = augmentedTrace;
      // mergeToolSequences is now technically redundant — the augmented
      // trace already covers control tools — but kept as defense-in-depth
      // so a bug in augmentTraceWithControlTools can't drop a control tool
      // from the persisted case-row toolsInvoked.
      toolsInvoked = mergeToolSequences(augmentedTrace.toolSequence, controlToolsInvoked);
      console.log(
        `[conversation-driver] Case ${testCase.caseId} tools (from spans): ${toolsInvoked.join(" → ") || "(none)"}`
      );
    }
  }

  const latencyMs = Date.now() - startTime;
  return {
    runId: "",
    caseId: testCase.caseId,
    status,
    toolsInvoked,
    turnCount: turnNumber,
    latencyMs,
    ...(errorMessage ? { errorMessage } : {}),
    transcript,
    ...(executionTrace ? { executionTrace } : {}),
    ...(sessionId ? { sessionId } : {}),
  };
}

/**
 * Merges the authoritative MCP tool sequence (from spans) with any control
 * tools (Complete/Escalate) captured from session data. Control tools that the
 * span sequence already contains are not duplicated; control tools that spans
 * lack (RETURN_TO_CONTROL tools sometimes only surface in session data) are
 * appended in their original order.
 *
 * @param spanTools - Authoritative ordered tools from execute_tool spans
 * @param controlTools - Control tools captured from conversationSessionData
 * @returns Merged ordered tool list
 */
export function mergeToolSequences(
  spanTools: string[],
  controlTools: string[]
): string[] {
  const merged = [...spanTools];
  for (const t of controlTools) {
    if (!merged.includes(t)) {
      merged.push(t);
    }
  }
  return merged;
}

// --- Lambda Handler ---

/**
 * Lambda handler for the Conversation Driver step in the Step Functions state machine.
 *
 * Input from Map state:
 * - caseId: the test case ID
 * - testCase: the full test case object
 * - runId: the current run ID
 * - agentId: the AI agent ID
 * - assistantId: the Q in Connect assistant ID
 *
 * Output: TestCaseResult with transcript for downstream steps.
 */
export interface ConversationDriverEvent {
  caseId: string;
  testCase: TestCase;
  runId: string;
  agentId: string;
  assistantId: string;
  /** Optional: pre-resolved Retrieve tool name from the agent snapshot. */
  retrieveToolName?: string;
  /** Optional: suite-level RAG thresholds for opportunistic faithfulness. */
  ragThresholds?: RagThresholds;
}

async function runConversationCase(
  event: ConversationDriverEvent
): Promise<TestCaseResult & { transcript?: TranscriptTurn[]; executionTrace?: ExecutionTrace; sessionId?: string; agentResponse?: string }> {
  const { testCase, agentId, assistantId, runId } = event;

  const connectInstanceId = process.env.CONNECT_INSTANCE_ID ?? "";
  const contactFlowId = process.env.CONTACT_CREATOR_FLOW_ID ?? "";

  if (!connectInstanceId) {
    throw new Error("CONNECT_INSTANCE_ID environment variable is not set");
  }
  if (!contactFlowId) {
    throw new Error("CONTACT_CREATOR_FLOW_ID environment variable is not set");
  }

  console.log(
    `[conversation-driver] Starting case=${testCase.caseId ?? testCase.name} type=${testCase.type ?? "tool_sequence"} agentId=${agentId} assistantId=${assistantId} instanceId=${connectInstanceId} flowId=${contactFlowId}`
  );

  // Resolve retrieveToolName: prefer event field, fall back to loading snapshot from DDB
  let retrieveToolName = event.retrieveToolName;
  let agentSnapshot: AgentSnapshot | null = null;
  if (!retrieveToolName && runId) {
    try {
      const db = getDynamoService();
      agentSnapshot = await db.getSnapshot(runId);
      if (agentSnapshot?.tools) {
        retrieveToolName = findRetrieveToolName(agentSnapshot.tools);
      }
    } catch (err) {
      console.warn(
        `[conversation-driver] Failed to load agent snapshot for retrieveToolName: ${
          err instanceof Error ? err.message : String(err)
        }`
      );
    }
  }

  // RAG mode: single-turn flow, no simulator
  if (testCase.type === "rag") {
    const ragCase = testCase as RagTestCase;
    const result = await executeRagTestCase(
      ragCase,
      agentId,
      assistantId,
      connectInstanceId,
      contactFlowId,
      retrieveToolName,
    );
    return { ...result, runId };
  }

  // Tool-sequence mode: existing multi-turn conversation flow
  const result = await executeTestCase(
    testCase,
    agentId,
    assistantId,
    connectInstanceId,
    contactFlowId,
    runId,
  );

  // Opportunistic Faithfulness for tool-sequence cases:
  // After the execution trace is captured, if chunks were retrieved and
  // the suite has ragThresholds configured, score faithfulness inline.
  if (
    result.status !== CaseStatus.ERROR &&
    result.executionTrace &&
    retrieveToolName &&
    event.ragThresholds
  ) {
    try {
      // Fetch raw spans for chunk extraction (re-fetch from ListSpans)
      const client = getQConnectClient();
      const rawSpans: RawSpan[] = [];
      if (result.sessionId) {
        let listNextToken: string | undefined;
        do {
          const resp = await client.send(
            new ListSpansCommand({
              assistantId,
              sessionId: result.sessionId,
              nextToken: listNextToken,
              maxResults: 100,
            })
          );
          for (const s of resp.spans ?? []) {
            rawSpans.push(s as RawSpan);
          }
          listNextToken = resp.nextToken;
        } while (listNextToken);
      }

      const chunks = extractRetrievedChunks(rawSpans, retrieveToolName);
      if (chunks.length > 0) {
        // Find the agent's final text response from transcript
        const agentTurns = result.transcript.filter(t => t.role === "agent" && t.text);
        const lastAgentText = agentTurns.length > 0
          ? agentTurns[agentTurns.length - 1].text
          : undefined;

        if (lastAgentText) {
          // R11.2 / R11.3: the opportunistic-faithfulness scorer
          // resolves its `judge_opportunistic_faithfulness` prompt via
          // `resolvePromptForRun(...)` against the run's pinned
          // snapshot. The legacy `judgeModelId` argument (and its
          // `process.env.JUDGE_MODEL_ID ?? "..."` fallback) was
          // retired in Wave 2 — Task 17.6 of the prompt-management
          // spec. The empty-string `runId` fallback for pre-feature
          // tests goes through the live registry.
          const faithfulnessScore = await evaluateOpportunisticFaithfulness(
            lastAgentText,
            chunks,
            runId ?? "",
          );

          if (faithfulnessScore !== undefined) {
            console.log(
              `[conversation-driver] Opportunistic faithfulness for case ${testCase.caseId}: ${faithfulnessScore}`
            );
            return {
              ...result,
              runId,
              retrievedChunks: chunks,
              ragMetrics: { faithfulness: faithfulnessScore },
            };
          }
        }

        // Even if faithfulness scoring failed, persist the chunks
        return { ...result, runId, retrievedChunks: chunks };
      }
    } catch (err) {
      console.warn(
        `[conversation-driver] Opportunistic faithfulness failed for case ${testCase.caseId}: ${
          err instanceof Error ? err.message : String(err)
        }`
      );
    }
  }

  return {
    ...result,
    runId,
  };
}

/**
 * Lambda handler for the Conversation Driver Step Functions task.
 *
 * Wraps {@link runConversationCase} and trims the large `transcript` and
 * `executionTrace` fields out of the value returned to Step Functions.
 *
 * WHY: Step Functions caps each task's returned payload at 256 KB. The full
 * transcript + reasoning trace for a long conversation can exceed that limit,
 * which surfaces as "the state/task 'lambda' returned a result with a size
 * exceeding the maximum number of bytes service limit" and fails the case.
 *
 * The transcript and trace are persisted to DynamoDB HERE (the driver already
 * holds table write access), so the downstream RecordTranscript step no longer
 * needs them in the state payload — it safely no-ops its persistence branch
 * (guarded on `transcript.length > 0` / `steps.length > 0`) and just passes the
 * small metadata fields through. All large data still lands in DDB exactly as
 * before; only the inter-state payload shrinks to metadata.
 *
 * Persistence failures here are non-fatal: we log and still return the metadata
 * so the case is recorded (RecordTranscript would otherwise have persisted it,
 * but a DDB error there would fail the case too — this matches prior behavior of
 * surfacing a usable result).
 */
export async function handler(
  event: ConversationDriverEvent
): Promise<TestCaseResult & { sessionId?: string; agentResponse?: string }> {
  const full = await runConversationCase(event);

  const { transcript, executionTrace, ...rest } = full as TestCaseResult & {
    transcript?: TranscriptTurn[];
    executionTrace?: ExecutionTrace;
    sessionId?: string;
    agentResponse?: string;
  };

  const runId = rest.runId || event.runId;
  const caseId = rest.caseId;

  // Persist the large artifacts to DynamoDB so they don't travel through the
  // Step Functions state payload (256 KB task-output limit).
  try {
    const db = getDynamoService();
    if (transcript && transcript.length > 0) {
      await db.writeTranscript(runId, caseId, transcript);
    }
    if (executionTrace && executionTrace.steps.length > 0) {
      await db.writeExecutionTrace(runId, caseId, executionTrace);
    }
  } catch (err) {
    console.warn(
      `[conversation-driver] Failed to persist transcript/trace for case ${caseId}: ${
        err instanceof Error ? err.message : String(err)
      }`
    );
  }

  // Return metadata only — no transcript, no executionTrace. RecordTranscript
  // passes these small fields through to WriteCaseResult; the heavy artifacts
  // are already in DDB.
  return rest;
}
