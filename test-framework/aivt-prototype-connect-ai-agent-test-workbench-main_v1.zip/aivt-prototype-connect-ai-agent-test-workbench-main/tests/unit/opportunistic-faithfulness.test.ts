/**
 * Unit tests for the Opportunistic Faithfulness Evaluator (Task 23,
 * migrated for Wave-2 prompt-management — Task 17.6).
 *
 * Validates: Requirements 12.3, 12.4, 12.11, 1.3, 10.1, 10.3, 11.2,
 * 11.3, 17.4.
 *
 * Test cases:
 * - Mock Converse returns valid `{"score": 0.85}` → returns 0.85
 * - Converse throws ThrottlingException → retries then returns undefined
 * - Converse returns malformed JSON → returns undefined
 * - Empty chunks array → prompt still constructed correctly
 * - Static regression guard: the migrated source contains no
 *   `process.env.*_MODEL_ID ?? "..."` fallback (R1.3 / R15.4 / Task
 *   17.6 acceptance criterion).
 */

import { readFileSync } from "node:fs";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ConverseCommand } from "@aws-sdk/client-bedrock-runtime";
import {
  evaluateOpportunisticFaithfulness,
  _setBedrockClient,
  _resetBedrockClient,
} from "../../src/backend/orchestration/opportunistic-faithfulness";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";
import type { RetrievedChunk } from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------

/** Build a Bedrock Converse response carrying a single text content block. */
function makeConverseResponse(text: string) {
  return {
    output: { message: { content: [{ text }] } },
  };
}

/** Build a duck-typed Bedrock client whose `send` is the given function. */
function makeMockBedrockClient(
  sendFn: (
    cmd: unknown,
    opts?: { abortSignal?: AbortSignal },
  ) => Promise<unknown>,
) {
  return { send: sendFn } as Parameters<typeof _setBedrockClient>[0];
}

/** Sample chunks for testing. */
const SAMPLE_CHUNKS: RetrievedChunk[] = [
  { text: "The capital of France is Paris.", index: 0, knowledgeBaseId: "kb-1" },
  { text: "Paris has a population of over 2 million.", index: 1 },
];

/** Empty-string `runId` makes `resolvePromptForRun` fall back to the
 *  live registry — exactly what we want for a unit test that has
 *  injected the empty-overrides Prompts_Store below. */
const RUN_ID = "" as const;

/**
 * Inject a stub Prompts_Store so `resolvePromptForRun(...)` returns
 * the registry's bundled `judge_opportunistic_faithfulness` default.
 * Same pattern as `tests/unit/customer-simulator.test.ts`.
 */
function setupPromptStoreWithDefaults(): void {
  _clearPromptRegistryCaches();
  const store = {
    getSnapshot: vi.fn().mockResolvedValue(null),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  } as unknown as DynamoDBService;
  _setPromptRegistryStore(store);
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

beforeEach(() => {
  _resetBedrockClient();
  setupPromptStoreWithDefaults();
});

afterEach(() => {
  _setBedrockClient(null);
  _setPromptRegistryStore(null);
  _clearPromptRegistryCaches();
});

// ---------------------------------------------------------------------------
// Happy path: valid JSON score response (Requirement 12.3)
// ---------------------------------------------------------------------------

describe("evaluateOpportunisticFaithfulness — happy path", () => {
  it("returns the score when Converse returns valid JSON {\"score\": 0.85}", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(makeConverseResponse('{"score": 0.85}'));
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "The capital of France is Paris, with over 2 million people.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBe(0.85);
    expect(send).toHaveBeenCalledTimes(1);
  });

  it("returns score from a fenced JSON code block response", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(
        makeConverseResponse('```json\n{"score": 0.92}\n```'),
      );
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Paris is the capital.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBe(0.92);
  });

  it("returns score of 0.0 (boundary low)", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(makeConverseResponse('{"score": 0.0}'));
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Completely ungrounded response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBe(0.0);
  });

  it("returns score of 1.0 (boundary high)", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(makeConverseResponse('{"score": 1.0}'));
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Paris is the capital of France.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBe(1.0);
  });
});

// ---------------------------------------------------------------------------
// ThrottlingException → retries then returns undefined (Requirement 12.4)
// ---------------------------------------------------------------------------

describe("evaluateOpportunisticFaithfulness — throttling retry", () => {
  it("retries on ThrottlingException and returns undefined after exhausting retries", async () => {
    const throttleErr = Object.assign(new Error("Rate exceeded"), {
      name: "ThrottlingException",
    });
    const send = vi.fn().mockRejectedValue(throttleErr);
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Some response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    // Never throws — returns undefined on failure (R12.11)
    expect(result).toBeUndefined();
    // Initial attempt + 2 retries = 3 total calls (maxRetries: 2)
    expect(send).toHaveBeenCalledTimes(3);
  });

  it("succeeds on retry after initial ThrottlingException", async () => {
    const throttleErr = Object.assign(new Error("Rate exceeded"), {
      name: "ThrottlingException",
    });
    const send = vi
      .fn()
      .mockRejectedValueOnce(throttleErr)
      .mockResolvedValueOnce(makeConverseResponse('{"score": 0.75}'));
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Some response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBe(0.75);
    expect(send).toHaveBeenCalledTimes(2);
  });
});

// ---------------------------------------------------------------------------
// Malformed JSON → returns undefined (Requirement 12.11)
// ---------------------------------------------------------------------------

describe("evaluateOpportunisticFaithfulness — malformed responses", () => {
  it("returns undefined when response is not JSON", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(
        makeConverseResponse("I cannot evaluate this."),
      );
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Some response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBeUndefined();
  });

  it("returns undefined when JSON has no score field", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(
        makeConverseResponse('{"rating": 0.9}'),
      );
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Some response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBeUndefined();
  });

  it("returns undefined when score is not a number", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(
        makeConverseResponse('{"score": "high"}'),
      );
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Some response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBeUndefined();
  });

  it("returns undefined when score is out of range (>1)", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(
        makeConverseResponse('{"score": 1.5}'),
      );
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Some response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBeUndefined();
  });

  it("returns undefined when score is out of range (<0)", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(
        makeConverseResponse('{"score": -0.1}'),
      );
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Some response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBeUndefined();
  });

  it("returns undefined on empty response text", async () => {
    const send = vi
      .fn()
      .mockResolvedValue(makeConverseResponse(""));
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Some response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(result).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// Empty chunks array → prompt still constructed correctly (Requirement 12.11)
// ---------------------------------------------------------------------------

describe("evaluateOpportunisticFaithfulness — empty chunks", () => {
  it("constructs a valid prompt and returns score even with empty chunks array", async () => {
    let capturedCmd: ConverseCommand | undefined;
    const send = vi.fn().mockImplementation((cmd: ConverseCommand) => {
      capturedCmd = cmd;
      return Promise.resolve(makeConverseResponse('{"score": 0.1}'));
    });
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "The agent said something without any retrieved context.",
      [],
      RUN_ID,
    );

    expect(result).toBe(0.1);
    expect(send).toHaveBeenCalledTimes(1);

    // Verify the prompt was constructed — the message should contain
    // the agent response and the scoring instruction even with no passages
    const messages = capturedCmd!.input.messages;
    expect(messages).toHaveLength(1);
    const promptText = (messages![0].content as Array<{ text: string }>)[0].text;
    expect(promptText).toContain("Retrieved Passages");
    expect(promptText).toContain(
      "The agent said something without any retrieved context.",
    );
    expect(promptText).toContain('{"score": <number between 0.0 and 1.0>}');
  });

  it("never throws even with empty chunks and a failing Converse call", async () => {
    const send = vi
      .fn()
      .mockRejectedValue(new Error("ServiceUnavailable"));
    _setBedrockClient(makeMockBedrockClient(send));

    const result = await evaluateOpportunisticFaithfulness(
      "Response text.",
      [],
      RUN_ID,
    );

    // Never throws (R12.11), returns undefined on failure
    expect(result).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// Registry-resolved modelId and inferenceConfig (R10.1, R11.2, R11.3, R17.4).
// ---------------------------------------------------------------------------

describe("evaluateOpportunisticFaithfulness — registry resolution (R10.1, R17.4)", () => {
  it("dispatches a ConverseCommand whose modelId comes from the registry default", async () => {
    let captured: ConverseCommand | undefined;
    const send = vi.fn().mockImplementation((cmd: ConverseCommand) => {
      captured = cmd;
      return Promise.resolve(makeConverseResponse('{"score": 0.5}'));
    });
    _setBedrockClient(makeMockBedrockClient(send));

    await evaluateOpportunisticFaithfulness(
      "Response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    expect(captured).toBeInstanceOf(ConverseCommand);
    // The registry's `judge_opportunistic_faithfulness` default model
    // is Anthropic Claude Sonnet 4.6 (cross-region inference profile).
    expect(captured!.input.modelId).toBe("us.anthropic.claude-sonnet-4-6");
  });

  it("emits an inferenceConfig whose key set matches the resolved Anthropic profile (maxTokens only)", async () => {
    let captured: ConverseCommand | undefined;
    const send = vi.fn().mockImplementation((cmd: ConverseCommand) => {
      captured = cmd;
      return Promise.resolve(makeConverseResponse('{"score": 0.5}'));
    });
    _setBedrockClient(makeMockBedrockClient(send));

    await evaluateOpportunisticFaithfulness(
      "Response.",
      SAMPLE_CHUNKS,
      RUN_ID,
    );

    const inferenceConfig = captured!.input.inferenceConfig ?? {};
    // R17.4: Anthropic Claude 4.x accepts `maxTokens` only. The
    // profile forbids `temperature`/`topP`/`topK`/`stopSequences`, so
    // those keys are silently dropped on the wire even though the
    // legacy implementation always set `temperature: 0`.
    expect(Object.keys(inferenceConfig).sort()).toEqual(["maxTokens"]);
    expect(inferenceConfig.maxTokens).toBe(50);
    expect(inferenceConfig.temperature).toBeUndefined();
    expect(captured!.input.additionalModelRequestFields).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// Static regression guard (R1.3 / R15.4 — Task 17.6 acceptance criterion).
// ---------------------------------------------------------------------------

describe("evaluateOpportunisticFaithfulness — registry-only resolution", () => {
  it("the migrated module contains no `process.env.*_MODEL_ID ?? \"...\"` fallback", () => {
    const sourcePath = path.join(
      __dirname,
      "..",
      "..",
      "src",
      "backend",
      "orchestration",
      "opportunistic-faithfulness.ts",
    );
    const source = readFileSync(sourcePath, "utf8");
    const fallbackPattern =
      /process\.env\.[A-Z][A-Z0-9_]*_MODEL_ID\s*(?:\?\?|\|\|)\s*["'`]/;
    expect(source).not.toMatch(fallbackPattern);
  });

  it("the migrated module no longer has an inline `temperature: 0` literal in the Converse inferenceConfig", () => {
    const sourcePath = path.join(
      __dirname,
      "..",
      "..",
      "src",
      "backend",
      "orchestration",
      "opportunistic-faithfulness.ts",
    );
    const source = readFileSync(sourcePath, "utf8");
    // Strip line and block comments before scanning so the regression
    // guard ignores descriptive doc strings that legitimately
    // reference the legacy values for migration history.
    const codeOnly = source
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/(^|[^:])\/\/[^\n]*/g, "$1");
    expect(codeOnly).not.toMatch(/temperature:\s*TEMPERATURE\b/);
    expect(codeOnly).not.toMatch(/temperature:\s*0\b/);
  });
});
