/**
 * ExperimentProgress — displays progress/status for a multi-variant
 * experiment lifecycle. Renders different visual states depending on where
 * the experiment is in its workflow (variant generation → agent creation →
 * running → completed/failed).
 *
 * Key requirements addressed:
 *   - R5.6: Loading state during variant generation ("Generating experiment
 *     variants...")
 *   - R7.3: "Experiment is running. You can leave this page and check
 *     results later." message during parallel test execution.
 *   - R12.2: Progress indicator and experiment status shown on the Run
 *     Dashboard for runs with active experiments.
 *
 * @module components/ImplementRecommendations/ExperimentProgress
 */

import Box from '@cloudscape-design/components/box';
import Container from '@cloudscape-design/components/container';
import Link from '@cloudscape-design/components/link';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Spinner from '@cloudscape-design/components/spinner';
import StatusIndicator from '@cloudscape-design/components/status-indicator';

import type { ExperimentStatus } from '../../../../shared/types';

// ---------------------------------------------------------------------------
// Public props
// ---------------------------------------------------------------------------

export interface ExperimentProgressProps {
  /** The experiment identifier (used for navigation links). */
  experimentId: string;
  /** Current lifecycle status of the experiment. */
  status: ExperimentStatus;
  /** The run ID that owns this experiment (used for building links). */
  runId: string;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * Renders a status-appropriate progress indicator for a multi-variant
 * experiment. The component is fully prop-driven and does not perform
 * any API calls — the parent is responsible for polling experiment status
 * and passing updated props.
 */
export function ExperimentProgress({
  experimentId,
  status,
  runId,
}: ExperimentProgressProps): JSX.Element {
  return (
    <Container>
      <SpaceBetween size="s" alignItems="center">
        {renderStatusContent(status, runId, experimentId)}
      </SpaceBetween>
    </Container>
  );
}

// ---------------------------------------------------------------------------
// Internal render helpers
// ---------------------------------------------------------------------------

function renderStatusContent(
  status: ExperimentStatus,
  runId: string,
  experimentId: string,
): JSX.Element {
  switch (status) {
    case 'generating_variants':
      return (
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <Spinner size="large" />
            <Box variant="p" fontWeight="bold">
              Generating experiment variants...
            </Box>
            <Box variant="small" color="text-body-secondary">
              Creating 3 diverse rewrites of the recommendations using different strategies.
            </Box>
          </SpaceBetween>
        </Box>
      );

    case 'creating_agents':
      return (
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <Spinner size="large" />
            <Box variant="p" fontWeight="bold">
              Creating temporary test agents...
            </Box>
            <Box variant="small" color="text-body-secondary">
              Setting up isolated agent configurations for each variant.
            </Box>
          </SpaceBetween>
        </Box>
      );

    case 'running':
      return (
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <StatusIndicator type="in-progress">
              Experiment in progress
            </StatusIndicator>
            <Box variant="p">
              Experiment is running. You can leave this page and check results later.
            </Box>
            <Box variant="small" color="text-body-secondary">
              The test suite is executing against all 3 variants in parallel.
            </Box>
          </SpaceBetween>
        </Box>
      );

    case 'completed':
      return (
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <StatusIndicator type="success">
              Experiment completed
            </StatusIndicator>
            <Box variant="p">
              All variants have been tested. View the tournament results to compare performance.
            </Box>
            <Link
              href={`/runs/${runId}/experiments/${experimentId}`}
              variant="primary"
            >
              View tournament results
            </Link>
          </SpaceBetween>
        </Box>
      );

    case 'failed':
      return (
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <StatusIndicator type="error">
              Experiment failed
            </StatusIndicator>
            <Box variant="p">
              The experiment encountered an error and could not complete. You can try
              running a new experiment or apply recommendations directly.
            </Box>
          </SpaceBetween>
        </Box>
      );

    case 'cleanup_in_progress':
      return (
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <StatusIndicator type="in-progress">
              Cleaning up temporary agents
            </StatusIndicator>
            <Box variant="small" color="text-body-secondary">
              Deleting temporary test agents. Results are preserved.
            </Box>
          </SpaceBetween>
        </Box>
      );

    case 'cleaned_up':
      return (
        <Box textAlign="center" padding="l">
          <SpaceBetween size="s" alignItems="center">
            <StatusIndicator type="success">
              Experiment completed
            </StatusIndicator>
            <Box variant="p">
              Experiment results are available. Temporary agents have been cleaned up.
            </Box>
            <Link
              href={`/runs/${runId}/experiments/${experimentId}`}
              variant="primary"
            >
              View tournament results
            </Link>
          </SpaceBetween>
        </Box>
      );

    default: {
      // Defensive: handle unexpected status values gracefully.
      const _exhaustive: never = status;
      void _exhaustive;
      return (
        <Box textAlign="center" padding="l">
          <StatusIndicator type="info">
            Unknown experiment status
          </StatusIndicator>
        </Box>
      );
    }
  }
}
