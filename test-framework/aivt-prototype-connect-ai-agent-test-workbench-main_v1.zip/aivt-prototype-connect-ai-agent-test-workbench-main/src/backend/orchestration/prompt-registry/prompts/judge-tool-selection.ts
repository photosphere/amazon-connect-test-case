/**
 * `judge_tool_selection` — verbatim AgentCore-template prompt for the
 * `Builtin.ToolSelectionAccuracy` judge. The default text re-exports
 * `TOOL_SELECTION_TEMPLATE` from `judge-prompt-templates.ts` so the
 * byte-for-byte copy from the AWS docs stays in one place.
 *
 * Placeholders are the AgentCore-defined tokens substituted by
 * `bedrock-judge-client.ts`'s `fillTemplate`:
 *
 *   - `{available_tools}` — formatted catalog of the agent's tools
 *   - `{context}` — prior conversation history
 *   - `{tool_turn}` — the specific tool-call turn being evaluated
 *
 * @module backend/orchestration/prompt-registry/prompts/judge-tool-selection
 */

import { TOOL_SELECTION_TEMPLATE } from "../../judge-prompt-templates";
import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

export const judgeToolSelectionPrompt: PromptDefinition = {
  promptKey: "judge_tool_selection",
  name: "Judge — Tool Selection Accuracy",
  description:
    "Verbatim AWS-published Builtin.ToolSelectionAccuracy judge prompt. Yes/No verdict on whether a specific tool call was justified at this point in the conversation.",
  category: "evaluation",
  defaultText: TOOL_SELECTION_TEMPLATE,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [
    {
      name: "available_tools",
      description:
        "Formatted catalog of the agent's tools (name, description, instruction) injected by the judge client.",
      maxOccurrences: 1,
    },
    {
      name: "context",
      description:
        "Prior conversation history leading up to the tool call under evaluation.",
      maxOccurrences: 1,
    },
    {
      name: "tool_turn",
      description:
        "The specific Action turn (tool selected + arguments) the judge must score.",
      maxOccurrences: 1,
    },
  ],
  literalBraceRegions: [
    {
      start: '{"properties": {"reasoning": ',
      end: '"required": ["reasoning", "score"]}',
    },
  ],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 2_048 },
  },
  defaultInferenceValues: {
    maxTokens: 2_048,
  },
};
