/**
 * `variant_generation` — system prompt for the Bedrock Converse call
 * inside `src/backend/orchestration/variant-generator.ts` that produces
 * three diverse rewrites of the source recommendations (conciseness,
 * example-heavy, restructured). The user message (source recommendations,
 * agent configuration, system prompt, instructions) is built locally by
 * `buildUserMessage`; the registered prompt is the literal `SYSTEM_PROMPT`
 * constant lifted byte-for-byte from `variant-generator.ts`.
 *
 * --- Decision (Task 17.4): Anthropic stays the default ---------------
 *
 * The legacy callsite ran on Anthropic Claude Sonnet 4.6 with
 * `temperature: 0.7` to encourage the three variants to diverge. Sonnet
 * 4.6's capability profile (`anthropic_claude_4x_lax` post-Wave-3, after
 * the conformance probe surfaced that the wire silently drops the key)
 * does not include `temperature` in `acceptsTopLevel`, so the validator
 * rejects an override that adds it and the wire-shape helper omits it
 * even if it lands in the resolved prompt — the legacy callsite predated
 * the capability-profile rule and was historically pointed at older
 * Claude variants that honoured `temperature`.
 *
 * Two paths were on the table during the Wave 2 migration:
 *
 *   1. **Migrate to Nova.** Set `defaultModelKey` to `nova_pro` so
 *      `temperature: 0.7` survives onto the wire and the three
 *      variants genuinely diverge at the model level. This is
 *      a behaviour change relative to the legacy callsite (different
 *      vendor, different output style).
 *   2. **Stay on Anthropic Sonnet 4.6.** Leave `defaultModelKey` at
 *      `claude_sonnet_4_6` and accept that `buildInferenceConfig` will
 *      drop `temperature` per R17.4. The model runs at Anthropic's
 *      default sampling temperature; diversity comes from the prompt's
 *      explicit "DISTINCT rewrite strategy" instruction rather than from
 *      the temperature knob.
 *
 * **We picked path 2.** Rationale:
 *
 *   - Path 2 preserves the historical behaviour of this callsite
 *     byte-for-byte at the model level — operators upgrading to the
 *     prompt-management feature do not see a vendor change land
 *     silently underneath their experiments.
 *   - The Wave 3 cleanup (Task 20.3) retired the `BEDROCK_MODEL_ID`
 *     env-var bridge entirely. The registry now reads only its
 *     hardcoded `claude_sonnet_4_6` default; operator overrides go
 *     through `PUT /prompts/variant_generation`.
 *   - The "DISTINCT rewrite strategy" instruction in the prompt body
 *     (variants A/B/C use conciseness, example-heavy, restructured)
 *     drives diversity at the semantic level. Empirically the legacy
 *     callsite produced acceptable diversity even when `temperature`
 *     was honoured by older Claude variants, suggesting the strategy
 *     instruction does most of the work.
 *   - Operators who want temperature-driven diversity have a one-click
 *     override on the Prompts page: switch the model to Nova Pro and
 *     the registry's declared `temperature: 0.7` value starts being
 *     honoured on the wire.
 *
 * The `temperature: 0.7` value is preserved in `defaultInferenceValues`
 * as a hint for any future Nova migration. It is silently dropped at
 * Converse time today (R17.4 + R10.4) because the resolved model's
 * capability profile (`anthropic_claude_4x_lax` for Sonnet 4.6) does
 * not include `temperature` in `acceptsTopLevel`. This is intentional,
 * not a bug — the `buildInferenceConfig` helper enforces the
 * capability-profile contract and the variant-generator's unit tests
 * assert `inferenceConfig.temperature` is `undefined` so a future
 * regression can't silently switch the default model and have nobody
 * notice.
 *
 * Anthropic stays in `allowedModels[]` (and is the default) because
 * Sonnet 4.6 is the platform's standard model for non-evaluation
 * Converse callsites. Nova stays in `allowedModels[]` so operators who
 * want temperature-driven diversity can switch on the Prompts page
 * without a code change.
 *
 * @module backend/orchestration/prompt-registry/prompts/variant-generation
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

/**
 * Byte-for-byte equivalent of the `SYSTEM_PROMPT` template literal in
 * `variant-generator.ts`. The legacy literal is a single multi-line
 * template string containing the strategy descriptions, safety rules, and
 * the JSON-only output instruction.
 */
const DEFAULT_TEXT = `You are an expert AI agent prompt engineer specializing in Amazon Q in Connect orchestration agents. You generate diverse, high-quality rewrites of agent configuration recommendations.

You produce 3 variants, each using a DISTINCT rewrite strategy:
- Variant A: CONCISENESS — make instructions shorter, more direct, remove redundancy
- Variant B: EXAMPLE-HEAVY — add concrete examples to tool_examples, make instructions more specific with inline examples
- Variant C: RESTRUCTURED — reorganize instruction flow, improve logical grouping, clarify conditional logic

SAFETY RULES (MANDATORY — violations cause variant rejection):
1. Dynamic parameters ({{$.Custom.*}}, {{agent.*}}, {{session.*}}) MUST remain in their original positions at the END of the system prompt. Do NOT relocate them earlier.
2. Thinking and messaging instruction blocks (<thinking>, <messaging>, or equivalent structural delimiters) are IMMUTABLE — do NOT modify, reword, or remove them byte-for-byte.
3. Do NOT add new examples to the system_prompt body. New examples go ONLY to tool_examples. Existing examples in the prompt MAY be tweaked or removed, but no new example content may be introduced.
4. Target ONLY the Tool_Surface values present in the source recommendations. Do NOT introduce changes to surfaces not already recommended.
5. Do NOT add new tool definitions, remove existing tools, or modify Knowledge Base bindings.

Output JSON only. Do not include any markdown formatting, code fences, or explanation outside the JSON object.`;

export const variantGenerationPrompt: PromptDefinition = {
  promptKey: "variant_generation",
  name: "Variant Generation — Three Diverse Rewrites",
  description:
    "System prompt for the Converse call that produces three diverse rewrites of source recommendations (conciseness, example-heavy, restructured).",
  category: "experiment",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [],
  inferenceParameters: {
    // The Anthropic 4.x capability profile only honours `maxTokens` —
    // `temperature` is silently dropped at request-build time per R10.4.
    // We declare `temperature` and `topP` here so a user who switches the
    // model to Nova can opt into the diversity-tuning surface; for
    // Anthropic models the buildInferenceConfig helper will not place
    // them on the wire.
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 8_192 },
    temperature: { kind: "number", min: 0.0, max: 1.0, default: 0.7 },
    topP: { kind: "number", min: 0.0, max: 1.0, default: 1.0 },
  },
  defaultInferenceValues: {
    maxTokens: 8_192,
    temperature: 0.7,
  },
};
