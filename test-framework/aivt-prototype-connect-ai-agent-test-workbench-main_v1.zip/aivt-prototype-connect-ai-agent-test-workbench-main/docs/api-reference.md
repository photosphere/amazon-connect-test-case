# API Reference

Complete reference for the platform's REST API. Every endpoint is protected by the Cognito User Pools authorizer scoped to `test-platform/run`. Calls without a valid Cognito access token (web client or machine client) return 401.

The base URL is the API Gateway invoke URL surfaced as the `ApiUrl` stack output. Routes below are relative to that base URL plus the `/prod` stage prefix (added automatically by API Gateway).

## Conventions

- All request bodies are JSON (`Content-Type: application/json`).
- All response bodies are JSON.
- All endpoints return CORS headers for `*` origin (the frontend is served from CloudFront, callable from any origin).
- Path parameters are `{enclosed in braces}`; query parameters use `?key=value`.
- The authenticated tenant is extracted from the JWT (`sub` for users, `client_id` for machine clients). All data is automatically scoped to that tenant.

## Authentication

Send the Cognito access token as a bearer token:

```
Authorization: Bearer eyJraWQiOi...
```

For interactive users: the frontend acquires this via the Cognito hosted UI and the Authorization Code grant. For automation: use the machine client and the Client Credentials grant. See [deployment.md](deployment.md#cicd-with-the-machine-client).

A 401 response with `error: "Unauthorized..."` means the token is missing, expired, or doesn't carry the `test-platform/run` scope.

## Endpoints

### Discovery

#### `GET /agents`

List all AI agents on the configured Q in Connect assistant.

**Response 200:**
```json
{
  "agents": [
    {
      "agentId": "uuid",
      "name": "AnyBank Mortgage Agent",
      "type": "ORCHESTRATION",
      "toolCount": 12,
      "modelId": "us.anthropic.claude-haiku-4-5"
    }
  ]
}
```

#### `GET /agents/{agentId}`

Full configuration for one agent.

**Response 200:** `AgentDetail` shape (see `src/shared/types.ts`):
```json
{
  "agentId": "uuid",
  "name": "AnyBank Mortgage Agent",
  "type": "ORCHESTRATION",
  "systemPrompt": "...",
  "modelId": "us.anthropic.claude-haiku-4-5",
  "tools": [
    {
      "toolName": "verifyIdentity",
      "toolType": "LAMBDA",
      "description": "...",
      "instruction": "...",
      "inputSchema": { "type": "object", "...": "..." },
      "examples": ["Customer: My account number is 12345", "..."]
    }
  ]
}
```

### Test Suites

#### `POST /suites`
Create a new test suite.

**Request:**
```json
{
  "name": "AnyBank wire transfers",
  "description": "Wire transfer happy and sad paths",
  "agentId": "uuid",
  "ragThresholds": {
    "faithfulness": 0.7,
    "correctness": 0.7,
    "completeness": 0.7,
    "helpfulness": 0.7
  }
}
```

**Response 201:** the created `TestSuite` record.

#### `GET /suites`
List the authenticated tenant's test suites.

#### `GET /suites/{suiteId}`
Retrieve a single test suite (without cases).

#### `PUT /suites/{suiteId}`
Update suite name, description, or `ragThresholds`. The `agentId` cannot be changed.

#### `DELETE /suites/{suiteId}`
Delete a suite and all its cases. Cascades.

### Test Cases

#### `POST /suites/{suiteId}/cases`
Create a test case. The request body's `type` field discriminates between `tool_sequence` and `rag` shapes.

**Tool-sequence case:**
```json
{
  "type": "tool_sequence",
  "name": "Wire transfer happy path",
  "description": "Customer wants to send a domestic wire",
  "goalDescription": "Send $5000 to Jane Smith",
  "persona": "Marcus Johnson",
  "style": "direct",
  "customerKnowledge": {
    "recipientName": "Jane Smith",
    "routingNumber": "021000021"
  },
  "initialUtterance": "I need to wire five thousand dollars",
  "successCriteria": [
    { "toolName": "verifyIdentity", "required": true },
    { "toolName": "sendWireTransfer", "required": true,
      "parameterChecks": [{ "paramName": "amount", "expectedValue": "5000" }] }
  ],
  "sessionData": { "ANI": "+15555551234" },
  "primingMessage": "[System] Customer has reached you."
}
```

**RAG case:**
```json
{
  "type": "rag",
  "name": "Mortgage rate question",
  "description": "Customer asks about current 30-year fixed rates",
  "question": "What's your current 30-year fixed mortgage rate?",
  "groundTruthAnswer": "Our current 30-year fixed mortgage rate is 6.875% APR with 0 points.",
  "sessionData": { "productCategory": "mortgage" }
}
```

**Response 201:** the created case.

**Response 400** — when validation fails. RAG cases reject extraneous tool-sequence fields with `error: "rag_case_extraneous_field"`.

#### `GET /suites/{suiteId}/cases`
List all cases in a suite. Returns mixed `tool_sequence` and `rag` cases.

#### `GET /suites/{suiteId}/cases/{caseId}`
Retrieve a single case.

#### `PUT /suites/{suiteId}/cases/{caseId}`
Update a case. The `type` field cannot change.

#### `DELETE /suites/{suiteId}/cases/{caseId}`

#### `POST /suites/{suiteId}/cases/scaffold`
AI-powered tool-sequence inference and customer-knowledge template generation.

**Request:**
```json
{
  "agentId": "uuid",
  "goalDescription": "Customer wants to dispute a charge and request provisional credit"
}
```

**Response 200:**
```json
{
  "successCriteria": [
    { "toolName": "verifyIdentity", "required": true },
    { "toolName": "disputeTransaction", "required": true },
    { "toolName": "requestProvisionalCredit", "required": false }
  ],
  "customerKnowledgeTemplate": [
    { "key": "transactionId", "label": "Transaction ID", "tool": "disputeTransaction" },
    { "key": "amount", "label": "Disputed amount", "tool": "disputeTransaction" }
  ],
  "modelId": "us.anthropic.claude-sonnet-4-6",
  "rationale": "..."
}
```

### Test Runs

#### `POST /runs`
Start a new test run.

**Request:**
```json
{
  "suiteId": "uuid",
  "concurrency": 9
}
```

**Response 202:**
```json
{
  "runId": "uuid",
  "sfnExecutionArn": "arn:aws:states:...",
  "status": "running"
}
```

#### `GET /runs/{runId}`
Get the run record, progress, and per-case results.

**Query params:**
- `suiteId` (optional) — hint to resolve in-progress runs faster.

**Response 200:**
```json
{
  "run": { /* TestRun record */ },
  "progress": {
    "totalCases": 25,
    "completed": 18,
    "passed": 16,
    "failed": 2,
    "errors": 0,
    "accuracy": 88.9
  },
  "results": [/* TestCaseResult[] */]
}
```

#### `POST /runs/{runId}/abort`
Stop an in-progress run.

#### `GET /runs/{runId}/cases/{caseId}`
Per-case detail: full transcript, execution trace, scores, evaluation details.

#### `GET /runs/{runId}/snapshot`
The agent snapshot captured at run start.

#### `GET /suites/{suiteId}/runs`
Run history for a suite, reverse chronological.

### Analysis and Recommendations

#### `POST /runs/{runId}/analyze`
Per-case root-cause analysis with concrete edit recommendations.

**Request:**
```json
{
  "suiteId": "optional-hint",
  "force": false
}
```

When `force: true`, overwrites persisted analysis records and re-invokes Bedrock. When `force` is absent or `false`, returns the persisted records if every failed case has one (free re-fetch). 

**Response 200:**
```json
{
  "caseAnalyses": [
    {
      "caseId": "uuid",
      "rootCauseCategory": "missing_disambiguation",
      "explanation": "...",
      "traceAvailable": true,
      "recommendations": [
        {
          "targetField": "tool_instruction",
          "targetName": "verifyIdentity",
          "currentText": "Use only after greeting.",
          "suggestedText": "Use only after greeting the customer warmly.",
          "rationale": "..."
        }
      ],
      "generatedAt": "2026-06-08T10:00:00Z",
      "modelId": "us.anthropic.claude-sonnet-4-6"
    }
  ],
  "generatedAt": "2026-06-08T10:00:00Z",
  "modelId": "us.anthropic.claude-sonnet-4-6",
  "partialFailures": []
}
```

`partialFailures` lists caseIds whose Bedrock analysis succeeded but DynamoDB persistence failed.

#### `POST /runs/{runId}/recommend-suite`
Per-suite consolidated, prioritized recommendations.

**Request:** `{ "force": false }`.

**Response 200:**
```json
{
  "recommendations": [
    {
      "priority": 1,
      "targetField": "tool_description",
      "targetName": "lookupCustomer",
      "currentText": "...",
      "suggestedText": "...",
      "rationale": "...",
      "predictedImpact": {
        "liftedCaseIds": ["case-3", "case-7"],
        "rationale": "Both failed cases referenced ambiguous routing of generic queries."
      }
    }
  ],
  "generatedAt": "2026-06-08T10:00:00Z",
  "modelId": "us.anthropic.claude-sonnet-4-6"
}
```

#### `POST /comparisons/summarize`
AI-generated summary diffing two runs.

**Request:**
```json
{
  "runIdA": "uuid",
  "runIdB": "uuid",
  "suiteId": "optional"
}
```

**Response 200:**
```json
{
  "summary": "Run B improved overall pass rate from 75% to 88%. Three cases that previously failed (case-1, case-3, case-9) passed in run B. One case regressed (case-7).",
  "modelId": "us.anthropic.claude-sonnet-4-6"
}
```

### Apply Recommendations

> All write endpoints return **403 with `error: "write_disabled"`** when the platform is deployed in production mode. See [operations.md](operations.md).

#### `POST /runs/{runId}/apply-recommendations`
Direct apply.

**Request:**
```json
{
  "mode": "direct",
  "agentId": "uuid",
  "recommendationIndices": [0, 1, 4]
}
```

The indices are positions in the run's persisted per-suite recommendations array (from `POST /runs/{id}/recommend-suite`).

**Response 200 (success):**
```json
{
  "success": true,
  "newVersionId": "uuid"
}
```

**Response 409 (drift detected):**
```json
{
  "success": false,
  "error": "drift_detected",
  "driftedFields": [
    {
      "targetField": "tool_instruction",
      "targetName": "verifyIdentity",
      "expectedText": "Use only after greeting.",
      "actualText": "Use only after greeting the customer warmly."
    }
  ]
}
```

When drift is detected, the user must choose one of:
- Re-call this endpoint with the same recommendations to **force** the write through. (Currently the endpoint always re-checks; "apply anyway" is a UI-level action that re-submits.)
- Cancel and accept the divergence.
- Re-run the analysis against the now-current state.

**Response 404:** `{ "error": "no_recommendations" }` — the run has no persisted recommendations.

**Response 400:** `{ "error": "agent_not_found" }` — the `agentId` doesn't belong to the configured assistant.

### Experiments

#### `POST /runs/{runId}/experiments`
Create a multi-variant experiment.

**Request:**
```json
{
  "mode": "multi_variant",
  "agentId": "uuid"
}
```

**Response 202:**
```json
{
  "experimentId": "uuid",
  "status": "generating_variants"
}
```

The experiment runs asynchronously through the experiment state machine. Poll `GET /runs/{runId}/experiments/{experimentId}` for status.

#### `GET /runs/{runId}/experiments/{experimentId}`
Get the full experiment record.

**Response 200:** `ExperimentRecord`:
```json
{
  "experimentId": "uuid",
  "runId": "uuid",
  "agentId": "uuid",
  "status": "completed",
  "variantConfigs": [/* VariantConfig[] */],
  "temporaryAgentIds": { "A": "...", "B": "...", "C": "..." },
  "variantRunIds": { "A": "...", "B": "...", "C": "..." },
  "baselineRunId": "uuid",
  "tournamentSummary": {
    "winningVariant": "B",
    "summary": "Variant B achieved 92% pass rate vs 75% baseline...",
    "perVariantHighlights": {
      "A": { "improved": ["case-1"], "regressed": [] },
      "B": { "improved": ["case-1", "case-3"], "regressed": [] },
      "C": { "improved": [], "regressed": ["case-7"] }
    }
  },
  "cleanupStatus": "success",
  "createdAt": "2026-06-08T10:00:00Z",
  "completedAt": "2026-06-08T10:15:00Z"
}
```

**Response 404:** `{ "error": "experiment_not_found" }`.

#### `POST /runs/{runId}/experiments/{experimentId}/apply`
Apply a winning variant.

**Request:** `{ "variant": "B" }`.

**Response shape** is identical to `POST /runs/{runId}/apply-recommendations`. Drift detection runs the same way. The experiment record is updated with `appliedVariant` and `appliedAt`.

### Audit

#### `GET /audit`
Paginated tenant audit trail, reverse chronological.

**Query params:**
- `nextToken` (optional) — base64-encoded pagination token from the previous response.

**Response 200:**
```json
{
  "records": [
    {
      "tenantId": "...",
      "timestamp": "2026-06-08T10:15:00Z",
      "runId": "...",
      "agentId": "...",
      "source": "experiment_apply",
      "experimentId": "...",
      "appliedVariant": "B",
      "previousVersionId": "...",
      "newVersionId": "...",
      "recommendations": [/* Recommendation[] */],
      "driftDetected": false,
      "userDecision": "normal"
    }
  ],
  "nextToken": "..."
}
```

50 records per page.

## Error responses

All error responses follow this shape:

```json
{
  "error": "machine-readable-code",
  "message": "Human readable explanation",
  "...": "additional context fields when relevant"
}
```

Common HTTP status codes:

| Status | Meaning |
|---|---|
| 400 | Validation failure (missing/invalid body, bad path params, unknown agent). |
| 401 | Missing or invalid Cognito token. |
| 403 | Production-mode write block (`error: "write_disabled"`). |
| 404 | Resource not found (suite, case, run, experiment). |
| 409 | Drift detected (`error: "drift_detected"` with `driftedFields`). |
| 429 | Bedrock or Q in Connect throttle exceeded retry envelope. Retry after the `retryAfterSeconds` value. |
| 500 | Unhandled error. CloudWatch logs have detail. |
