// @vitest-environment jsdom
/**
 * Integration tests for the Implement Recommendations flows.
 *
 * These tests render a lightweight harness that composes the real hook
 * (useImplementRecommendations) with the real presentational components
 * (ImplementButton, ModeSelector, ConfirmationDialog, PostApplyPrompt)
 * and mocked API responses to verify the full user-facing flow.
 *
 * Requirements: 1.1, 1.2, 1.3, 1.6
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor, within, cleanup, act } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';
import { ImplementButton } from '../ImplementButton';
import { ConfirmationDialog } from '../ConfirmationDialog';
import { ConflictResolution } from '../ConflictResolution';
import { PostApplyPrompt } from '../PostApplyPrompt';
import { ExperimentBannerPanel } from '../ExperimentBannerPanel';
import { useImplementRecommendations } from '../../../hooks/useImplementRecommendations';
import { useExperimentBanner } from '../../../hooks/useExperimentBanner';
import { RunStatus } from '../../../../../shared/enums';
import type { ExperimentRecord, ExperimentStatus, PerSuiteRecommendation } from '../../../../../shared/types';

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

vi.mock('../../../api', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../../api')>();
  return {
    ...actual,
    fetchRecommendations: vi.fn(),
    applyRecommendations: vi.fn(),
    createExperiment: vi.fn(),
    getExperiment: vi.fn(),
    applyVariant: vi.fn(),
    listExperiments: vi.fn(),
    getConfig: () => ({ instanceMode: 'development', apiEndpoint: 'http://localhost' }),
  };
});

// useExperimentBanner imports directly from the recommendations module
// rather than the barrel, so we need to mock it separately.
vi.mock('../../../api/recommendations', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../../api/recommendations')>();
  return {
    ...actual,
    fetchRecommendations: vi.fn(),
    applyRecommendations: vi.fn(),
    createExperiment: vi.fn(),
    getExperiment: vi.fn(),
    applyVariant: vi.fn(),
    listExperiments: vi.fn(),
  };
});

import {
  fetchRecommendations,
  applyRecommendations,
  createExperiment,
  getExperiment,
  ApiClientError,
} from '../../../api';

// These mocks apply to the barrel (used by useImplementRecommendations)
const mockFetchRecommendations = fetchRecommendations as ReturnType<typeof vi.fn>;
const mockApplyRecommendations = applyRecommendations as ReturnType<typeof vi.fn>;
const mockCreateExperiment = createExperiment as ReturnType<typeof vi.fn>;
const mockGetExperiment = getExperiment as ReturnType<typeof vi.fn>;

// These mocks apply to the direct recommendations module (used by useExperimentBanner)
import {
  listExperiments as listExperimentsRec,
  getExperiment as getExperimentRec,
} from '../../../api/recommendations';

const mockListExperimentsRec = listExperimentsRec as ReturnType<typeof vi.fn>;
const mockGetExperimentRec = getExperimentRec as ReturnType<typeof vi.fn>;

// ---------------------------------------------------------------------------
// Test Data
// ---------------------------------------------------------------------------

const PROPS = { runId: 'run-001', suiteId: 'suite-001', agentId: 'agent-001' };

function makeRecommendation(index: number): PerSuiteRecommendation {
  return {
    targetField: 'system_prompt',
    targetName: 'system_prompt',
    currentText: `old-text-${index}`,
    suggestedText: `new-text-${index}`,
    rationale: `Rationale for change ${index}`,
    priority: index + 1,
    predictedImpact: { liftedCaseIds: [`case-${index}`], rationale: 'Improves accuracy' },
  };
}

// ---------------------------------------------------------------------------
// Harness — wires real hook + real presentational components
// ---------------------------------------------------------------------------

function DirectApplyHarness() {
  const impl = useImplementRecommendations(PROPS);

  return (
    <div>
      <ImplementButton
        runId={PROPS.runId}
        suiteId={PROPS.suiteId}
        agentId={PROPS.agentId}
        hasRecommendations={true}
        runStatus={RunStatus.COMPLETED}
        instanceMode="development"
        onDirectApply={impl.startDirectApply}
        onExperiment={impl.startExperiment}
      />

      <ConfirmationDialog
        visible={impl.state === 'confirming' || impl.state === 'applying'}
        agentName="TestAgent"
        agentId={PROPS.agentId}
        recommendations={impl.context.recommendations}
        onConfirm={impl.confirmApply}
        onCancel={impl.cancelDialog}
        loading={impl.state === 'applying'}
      />

      <ConflictResolution
        visible={impl.state === 'conflict'}
        driftedFields={impl.context.driftedFields}
        onApplyAnyway={impl.forceApply}
        onCancel={impl.cancelDialog}
        onReAnalyze={impl.reAnalyze}
      />

      <PostApplyPrompt
        visible={impl.state === 'success'}
        newVersionId={impl.context.newVersionId ?? ''}
        onReRunSuite={impl.reRunSuite}
        onDismiss={impl.dismissSuccess}
      />

      <span data-testid="state">{impl.state}</span>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Direct Apply Flow Tests
// ---------------------------------------------------------------------------

describe('Integration: Direct Apply Flow', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    cleanup();
  });

  it('full happy path: button click → mode select → fetch → confirm → apply → success prompt', async () => {
    // Arrange: API returns 2 recommendations, then apply succeeds
    const recommendations = [makeRecommendation(0), makeRecommendation(1)];
    mockFetchRecommendations.mockResolvedValueOnce({
      recommendations,
      agentName: 'TestAgent',
      agentId: 'agent-001',
    });
    mockApplyRecommendations.mockResolvedValueOnce({
      success: true,
      newVersionId: 'v42-new',
    });

    render(<DirectApplyHarness />);

    // 1. Click "Implement Recommendations" button (R1.1)
    const implButton = screen.getByRole('button', { name: /implement recommendations/i });
    expect(implButton).toBeInTheDocument();
    fireEvent.click(implButton);

    // 2. ModeSelector modal appears — "Apply directly" is pre-selected.
    //    Click "Continue" to trigger Direct Apply (R1.1)
    const continueButton = await waitFor(() =>
      screen.getByRole('button', { name: /^Continue$/i }),
    );
    expect(continueButton).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(continueButton);
    });

    // 3. ConfirmationDialog should appear with recommendation diffs (R1.1)
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('confirming');
    });

    // Verify ConfirmationDialog renders the diffs
    expect(screen.getByText(/Confirm Changes to TestAgent/i)).toBeInTheDocument();
    expect(screen.getByText('old-text-0')).toBeInTheDocument();
    expect(screen.getByText('new-text-0')).toBeInTheDocument();
    expect(screen.getByText('old-text-1')).toBeInTheDocument();
    expect(screen.getByText('new-text-1')).toBeInTheDocument();
    expect(screen.getByText(/Agent ID: agent-001/)).toBeInTheDocument();

    // 4. Click "Confirm and Apply" (R1.2)
    const confirmButton = screen.getByRole('button', { name: /confirm and apply/i });
    expect(confirmButton).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(confirmButton);
    });

    // 5. Verify PostApplyPrompt with newVersionId (R1.3)
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('success');
    });

    expect(screen.getByText(/v42-new/)).toBeInTheDocument();
    expect(screen.getByText(/Changes applied successfully/i)).toBeInTheDocument();

    // Verify correct API payload (R1.2)
    expect(mockApplyRecommendations).toHaveBeenCalledWith(
      'run-001',
      'agent-001',
      [0, 1],
    );
  });

  it('ConfirmationDialog shows loading state and disables Cancel during apply (R1.6)', async () => {
    const recommendations = [makeRecommendation(0)];
    mockFetchRecommendations.mockResolvedValueOnce({
      recommendations,
      agentName: 'TestAgent',
      agentId: 'agent-001',
    });

    // Delay the apply response to observe loading state
    let resolveApply!: (value: unknown) => void;
    mockApplyRecommendations.mockReturnValueOnce(
      new Promise((resolve) => {
        resolveApply = resolve;
      }),
    );

    render(<DirectApplyHarness />);

    // Navigate to ConfirmationDialog
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));
    const continueButton = await waitFor(() =>
      screen.getByRole('button', { name: /^Continue$/i }),
    );
    await act(async () => {
      fireEvent.click(continueButton);
    });
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('confirming');
    });

    // Click Confirm — promise remains pending
    const confirmButton = screen.getByRole('button', { name: /confirm and apply/i });
    await act(async () => {
      fireEvent.click(confirmButton);
    });

    // State should be 'applying'
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('applying');
    });

    // Cancel button in the ConfirmationDialog is disabled during loading (R1.6).
    // Multiple Cancel buttons exist from various modals, so find the disabled one.
    const cancelButtons = screen.getAllByRole('button', { name: /^Cancel$/i });
    const disabledCancel = cancelButtons.find((btn) => btn.hasAttribute('disabled'));
    expect(disabledCancel).toBeDefined();
    expect(disabledCancel).toBeDisabled();

    // Resolve the apply
    await act(async () => {
      resolveApply({ success: true, newVersionId: 'v99' });
    });

    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('success');
    });
  });

  it('PostApplyPrompt renders newVersionId and offers Re-run Suite (R1.3)', async () => {
    const recommendations = [makeRecommendation(0)];
    mockFetchRecommendations.mockResolvedValueOnce({
      recommendations,
      agentName: 'TestAgent',
      agentId: 'agent-001',
    });
    mockApplyRecommendations.mockResolvedValueOnce({
      success: true,
      newVersionId: 'version-abc-123',
    });

    render(<DirectApplyHarness />);

    // Fast-forward to success state
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));
    const continueButton = await waitFor(() =>
      screen.getByRole('button', { name: /^Continue$/i }),
    );
    await act(async () => {
      fireEvent.click(continueButton);
    });
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('confirming');
    });
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /confirm and apply/i }));
    });
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('success');
    });

    // PostApplyPrompt should show the version
    expect(screen.getByText(/version-abc-123/)).toBeInTheDocument();

    // Should have a "Re-run Suite" button
    const reRunButton = screen.getByRole('button', { name: /re-run suite/i });
    expect(reRunButton).toBeInTheDocument();

    // Clicking the dismiss button returns to idle
    const dismissButton = screen.getByRole('button', { name: /dismiss/i });
    await act(async () => {
      fireEvent.click(dismissButton);
    });

    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('idle');
    });
  });

  it('cancel from ConfirmationDialog returns to idle without API call', async () => {
    const recommendations = [makeRecommendation(0)];
    mockFetchRecommendations.mockResolvedValueOnce({
      recommendations,
      agentName: 'TestAgent',
      agentId: 'agent-001',
    });

    render(<DirectApplyHarness />);

    // Navigate to ConfirmationDialog
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));
    const continueButton = await waitFor(() =>
      screen.getByRole('button', { name: /^Continue$/i }),
    );
    await act(async () => {
      fireEvent.click(continueButton);
    });
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('confirming');
    });

    // Click Cancel inside the ConfirmationDialog (which has the "Confirm Changes" header).
    // Multiple Cancel buttons exist from hidden modals, so scope to the visible dialog.
    const confirmDialog = screen.getByText(/Confirm Changes to TestAgent/i).closest('[role="dialog"]')!;
    const cancelButton = within(confirmDialog as HTMLElement).getByRole('button', { name: /^Cancel$/i });
    await act(async () => {
      fireEvent.click(cancelButton);
    });

    // Should be back to idle, no apply call made
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('idle');
    });
    expect(mockApplyRecommendations).not.toHaveBeenCalled();
  });
});


// ---------------------------------------------------------------------------
// Conflict Flow Tests — Requirements: 2.1, 5.1
// ---------------------------------------------------------------------------

describe('Integration: Conflict Flow', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    cleanup();
  });

  it('apply → 409 conflict → ConflictResolution renders → force apply → success (R2.1)', async () => {
    // Arrange: fetch returns recommendations, first apply throws 409 with driftedFields
    const recommendations = [makeRecommendation(0), makeRecommendation(1)];
    mockFetchRecommendations.mockResolvedValueOnce({
      recommendations,
      agentName: 'TestAgent',
      agentId: 'agent-001',
    });
    mockApplyRecommendations
      .mockRejectedValueOnce(
        new ApiClientError(409, 'Conflict detected', false, {
          details: {
            driftedFields: [
              {
                targetField: 'system_prompt',
                targetName: 'system_prompt',
                expectedText: 'expected prompt text',
                actualText: 'actual prompt text',
              },
            ],
          },
        }),
      )
      // Force apply succeeds
      .mockResolvedValueOnce({
        success: true,
        newVersionId: 'v99-forced',
      });

    render(<DirectApplyHarness />);

    // Navigate to ConfirmationDialog
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));
    const continueButton = await waitFor(() =>
      screen.getByRole('button', { name: /^Continue$/i }),
    );
    await act(async () => {
      fireEvent.click(continueButton);
    });
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('confirming');
    });

    // Click "Confirm and Apply" — triggers 409
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /confirm and apply/i }));
    });

    // Should transition to 'conflict' state
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('conflict');
    });

    // ConflictResolution renders with drifted field info
    expect(screen.getByText(/Conflict Detected/i)).toBeInTheDocument();
    expect(screen.getByText(/has been modified/i)).toBeInTheDocument();

    // Click "Apply anyway" to force apply (R2.1)
    const applyAnywayButton = screen.getByRole('button', { name: /apply anyway/i });
    expect(applyAnywayButton).toBeInTheDocument();

    await act(async () => {
      fireEvent.click(applyAnywayButton);
    });

    // Should transition to success after force apply
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('success');
    });

    // Verify force apply was called with force: true
    expect(mockApplyRecommendations).toHaveBeenCalledTimes(2);
    expect(mockApplyRecommendations).toHaveBeenLastCalledWith(
      'run-001',
      'agent-001',
      [0, 1],
      true,
    );

    // PostApplyPrompt shows the new version
    expect(screen.getByText(/v99-forced/)).toBeInTheDocument();
  });

  it('conflict → Cancel returns to idle without API call (R2.2)', async () => {
    const recommendations = [makeRecommendation(0)];
    mockFetchRecommendations.mockResolvedValueOnce({
      recommendations,
      agentName: 'TestAgent',
      agentId: 'agent-001',
    });
    mockApplyRecommendations.mockRejectedValueOnce(
      new ApiClientError(409, 'Conflict detected', false, {
        details: {
          driftedFields: [
            {
              targetField: 'system_prompt',
              targetName: 'system_prompt',
              expectedText: 'old text',
              actualText: 'new text',
            },
          ],
        },
      }),
    );

    render(<DirectApplyHarness />);

    // Navigate to conflict
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));
    const continueButton = await waitFor(() =>
      screen.getByRole('button', { name: /^Continue$/i }),
    );
    await act(async () => {
      fireEvent.click(continueButton);
    });
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('confirming');
    });
    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: /confirm and apply/i }));
    });
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('conflict');
    });

    // Click Cancel in the ConflictResolution dialog
    const conflictDialog = screen.getByText(/Conflict Detected/i).closest('[role="dialog"]')!;
    const cancelButton = within(conflictDialog as HTMLElement).getByRole('button', { name: /^Cancel$/i });
    await act(async () => {
      fireEvent.click(cancelButton);
    });

    // Should return to idle, no additional API call made
    await waitFor(() => {
      expect(screen.getByTestId('state')).toHaveTextContent('idle');
    });
    // Only the initial apply was called (which triggered 409), no force apply
    expect(mockApplyRecommendations).toHaveBeenCalledTimes(1);
  });
});

// ---------------------------------------------------------------------------
// Experiment Flow Tests — Requirements: 4.1, 4.3, 4.4
// ---------------------------------------------------------------------------

describe('Integration: Experiment Flow', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.clearAllMocks();
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
  });

  it('mode select → fetch recommendations → confirming → start experiment → poll → completed (R4.1, R4.3, R4.4)', async () => {
    // The experiment flow requires going through confirming first (valid transition).
    // Step 1: Fetch recommendations to reach 'confirming' state.
    const recommendations = [makeRecommendation(0)];
    mockFetchRecommendations.mockResolvedValueOnce({
      recommendations,
      agentName: 'TestAgent',
      agentId: 'agent-001',
    });

    // Step 2: createExperiment succeeds from confirming → experiment_starting → experiment_polling
    mockCreateExperiment.mockResolvedValueOnce({
      experimentId: 'exp-123',
      status: 'generating_variants',
    });

    // Step 3: First poll returns 'running' (non-terminal)
    mockGetExperiment
      .mockResolvedValueOnce({
        experimentId: 'exp-123',
        runId: 'run-001',
        agentId: 'agent-001',
        status: 'running',
        variantConfigs: [],
        temporaryAgentIds: { A: 'a1', B: 'b1', C: 'c1' },
        variantRunIds: { A: 'r1', B: 'r2', C: 'r3' },
        baselineRunId: 'baseline-001',
        sfnExecutionArn: 'arn:aws:states:us-east-1:123:execution:exp',
        cleanupStatus: 'pending',
        createdAt: '2024-01-01T00:00:00Z',
      } satisfies ExperimentRecord)
      // Step 4: Second poll returns 'completed' (terminal)
      .mockResolvedValueOnce({
        experimentId: 'exp-123',
        runId: 'run-001',
        agentId: 'agent-001',
        status: 'completed',
        variantConfigs: [],
        temporaryAgentIds: { A: 'a1', B: 'b1', C: 'c1' },
        variantRunIds: { A: 'r1', B: 'r2', C: 'r3' },
        baselineRunId: 'baseline-001',
        sfnExecutionArn: 'arn:aws:states:us-east-1:123:execution:exp',
        cleanupStatus: 'success',
        createdAt: '2024-01-01T00:00:00Z',
        completedAt: '2024-01-01T01:00:00Z',
      } satisfies ExperimentRecord);

    render(<DirectApplyHarness />);

    // 1. Click "Implement Recommendations" → opens ModeSelector
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));

    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    // 2. Select "Apply directly" to get to confirming state (needed for valid transitions)
    const continueButton = screen.getByRole('button', { name: /^Continue$/i });
    fireEvent.click(continueButton);

    // Flush microtasks for fetchRecommendations to resolve
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    // Should be in confirming state now
    expect(screen.getByTestId('state')).toHaveTextContent('confirming');

    // 3. Now click "Implement Recommendations" again to open ModeSelector from confirming
    //    and select experiment mode. But since the harness has ImplementButton visible,
    //    we can re-open it. However, the state is now 'confirming' so the button is still visible.
    //    Actually, looking at the hook: startExperiment transitions from confirming → experiment_starting.
    //    The ImplementButton calls onExperiment (which is impl.startExperiment).
    //    But in the harness, the ImplementButton is always visible; let's click it again.
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));

    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    // Select experiment radio and click Continue
    const experimentRadio = screen.getByLabelText(/Advanced: Multi-variant experiment/i);
    fireEvent.click(experimentRadio);

    const continueBtn2 = screen.getByRole('button', { name: /^Continue$/i });
    fireEvent.click(continueBtn2);

    // Flush microtasks for createExperiment to resolve
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    // 4. Should be in experiment_polling state
    expect(screen.getByTestId('state')).toHaveTextContent('experiment_polling');
    expect(mockCreateExperiment).toHaveBeenCalledWith('run-001', 'agent-001');

    // 5. First poll fires (immediate) — returns 'running' (non-terminal)
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    expect(screen.getByTestId('state')).toHaveTextContent('experiment_polling');

    // 6. Next poll at 5s — returns 'completed'
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5_000);
    });

    expect(screen.getByTestId('state')).toHaveTextContent('experiment_completed');
    expect(mockGetExperiment).toHaveBeenCalledWith('run-001', 'exp-123');
  });

  it('experiment creation failure from confirming shows error state (R4.2)', async () => {
    const recommendations = [makeRecommendation(0)];
    mockFetchRecommendations.mockResolvedValueOnce({
      recommendations,
      agentName: 'TestAgent',
      agentId: 'agent-001',
    });
    mockCreateExperiment.mockRejectedValueOnce(
      new ApiClientError(500, 'Internal server error', true),
    );

    render(<DirectApplyHarness />);

    // Navigate to confirming state first
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });
    const continueButton = screen.getByRole('button', { name: /^Continue$/i });
    fireEvent.click(continueButton);
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });
    expect(screen.getByTestId('state')).toHaveTextContent('confirming');

    // Now open ModeSelector again and select experiment
    fireEvent.click(screen.getByRole('button', { name: /implement recommendations/i }));
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });
    const experimentRadio = screen.getByLabelText(/Advanced: Multi-variant experiment/i);
    fireEvent.click(experimentRadio);
    const continueBtn2 = screen.getByRole('button', { name: /^Continue$/i });
    fireEvent.click(continueBtn2);

    // Flush microtasks for rejected promise
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    // Should transition to error
    expect(screen.getByTestId('state')).toHaveTextContent('error');
  });
});

// ---------------------------------------------------------------------------
// Banner Lifecycle Tests — Requirements: 5.1, 5.3, 5.4
// ---------------------------------------------------------------------------

/**
 * Separate harness for the banner lifecycle tests.
 * Composes useExperimentBanner + ExperimentBannerPanel.
 */
function BannerHarness({ runId }: { runId: string }) {
  const bannerState = useExperimentBanner(runId);

  return (
    <div>
      <span data-testid="has-experiment">{String(bannerState.hasExperiment)}</span>
      <span data-testid="is-terminal">{String(bannerState.isTerminal)}</span>
      <span data-testid="poll-error">{String(bannerState.pollError)}</span>
      <span data-testid="experiment-status">
        {bannerState.experiment?.status ?? 'none'}
      </span>
      {bannerState.hasExperiment && bannerState.experiment && (
        <ExperimentBannerPanel
          experiment={bannerState.experiment}
          runId={runId}
          pollError={bannerState.pollError}
        />
      )}
    </div>
  );
}

function makeExperimentRecord(status: ExperimentStatus): ExperimentRecord {
  return {
    experimentId: 'exp-001',
    runId: 'run-001',
    agentId: 'agent-001',
    status,
    variantConfigs: [],
    temporaryAgentIds: { A: 'a1', B: 'b1', C: 'c1' },
    variantRunIds: { A: 'r1', B: 'r2', C: 'r3' },
    baselineRunId: 'baseline-001',
    sfnExecutionArn: 'arn:aws:states:us-east-1:123:execution:exp',
    cleanupStatus: 'pending',
    createdAt: '2024-01-01T00:00:00Z',
  };
}

describe('Integration: Banner Lifecycle', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.clearAllMocks();
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
  });

  it('mount with active experiment → poll → status change → banner updates → terminal → stop (R5.1, R5.3, R5.4)', async () => {
    // Initial: experiment is 'running'
    mockListExperimentsRec.mockResolvedValue({
      experiments: [makeExperimentRecord('running')],
    });

    // First poll: still running
    mockGetExperimentRec
      .mockResolvedValueOnce(makeExperimentRecord('running'))
      // Second poll: transitions to 'completed'
      .mockResolvedValueOnce(makeExperimentRecord('completed'));

    render(<BannerHarness runId="run-001" />);

    // Initial listExperiments resolves
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    // Banner should show the active experiment
    expect(screen.getByTestId('has-experiment')).toHaveTextContent('true');
    expect(screen.getByTestId('experiment-status')).toHaveTextContent('running');
    expect(screen.getByTestId('is-terminal')).toHaveTextContent('false');

    // Banner shows "in-progress" status indicator for active experiments
    expect(screen.getByText(/Experiment running/i)).toBeInTheDocument();
    expect(screen.getByText(/View progress/i)).toBeInTheDocument();

    // First poll at 10s — still running
    await act(async () => {
      await vi.advanceTimersByTimeAsync(10_000);
    });

    expect(screen.getByTestId('experiment-status')).toHaveTextContent('running');

    // Second poll at 20s — transitions to completed
    await act(async () => {
      await vi.advanceTimersByTimeAsync(10_000);
    });

    expect(screen.getByTestId('experiment-status')).toHaveTextContent('completed');
    expect(screen.getByTestId('is-terminal')).toHaveTextContent('true');

    // Banner should show completion indicator and "View Experiment Results" link
    expect(screen.getByText(/Experiment completed/i)).toBeInTheDocument();
    expect(screen.getByText(/View Experiment Results/i)).toBeInTheDocument();

    // No further polling should occur after terminal state
    mockGetExperimentRec.mockClear();
    await act(async () => {
      await vi.advanceTimersByTimeAsync(30_000);
    });
    expect(mockGetExperimentRec).not.toHaveBeenCalled();
  });

  it('banner displays "Status updates unavailable" after 3 consecutive poll failures (R5.6)', async () => {
    mockListExperimentsRec.mockResolvedValue({
      experiments: [makeExperimentRecord('running')],
    });
    mockGetExperimentRec.mockRejectedValue(new Error('Network error'));

    render(<BannerHarness runId="run-001" />);

    // Initial fetch
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    expect(screen.getByTestId('poll-error')).toHaveTextContent('false');

    // 3 consecutive poll failures
    await act(async () => {
      await vi.advanceTimersByTimeAsync(10_000);
    });
    expect(screen.getByTestId('poll-error')).toHaveTextContent('false');

    await act(async () => {
      await vi.advanceTimersByTimeAsync(10_000);
    });
    expect(screen.getByTestId('poll-error')).toHaveTextContent('false');

    await act(async () => {
      await vi.advanceTimersByTimeAsync(10_000);
    });
    expect(screen.getByTestId('poll-error')).toHaveTextContent('true');

    // Banner should render the poll error alert
    expect(screen.getByText(/Status updates unavailable/i)).toBeInTheDocument();
  });

  it('banner shows failed experiment with "View Details" link (R5.5)', async () => {
    mockListExperimentsRec.mockResolvedValue({
      experiments: [makeExperimentRecord('failed')],
    });

    render(<BannerHarness runId="run-001" />);

    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    expect(screen.getByTestId('experiment-status')).toHaveTextContent('failed');
    expect(screen.getByTestId('is-terminal')).toHaveTextContent('true');

    // Banner should show error status and "View Details" link
    expect(screen.getByText(/Experiment failed/i)).toBeInTheDocument();
    expect(screen.getByText(/View Details/i)).toBeInTheDocument();
  });
});
