// Feature: implement-recommendations, Property 10: Agent-assistant ownership validation
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import fc from "fast-check";
import { QConnectClient } from "@aws-sdk/client-qconnect";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

import {
  handler,
  _setQConnectClient,
  _setDDBDocClient,
} from "@backend/handlers/apply-recommendations";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const ASSISTANT_ID = "some-assistant-id";
const RUN_ID = "run-test-123";

const originalEnv = { ...process.env };

/**
 * Creates a mock DynamoDB Document Client that returns a persisted suite
 * analysis with at least one recommendation (so we get past the
 * "no_recommendations" check in the handler).
 */
function createMockDDBDocClient(): DynamoDBDocumentClient {
  const mockSend = async () => ({
    Item: {
      PK: `RUN#${RUN_ID}`,
      SK: "ANALYSIS#SUITE",
      recommendations: [
        {
          targetField: "tool_description",
          targetName: "verifyIdentity",
          currentText: "Verify customer identity",
          suggestedText: "Verify the customer identity using their account number",
          rationale: "More specific instruction",
          priority: 1,
          predictedImpact: { liftedCaseIds: [], rationale: "" },
        },
      ],
      generatedAt: "2025-01-15T10:00:00Z",
      modelId: "anthropic.claude-3-sonnet",
    },
  });

  return { send: mockSend } as unknown as DynamoDBDocumentClient;
}

/**
 * Creates a mock QConnect client that throws ResourceNotFoundException
 * for any GetAIAgent call — simulating that the agent does not belong
 * to the configured assistant.
 */
function createMockQConnectClientThrowingResourceNotFound(): QConnectClient {
  const mockSend = async () => {
    const error = new Error(
      "Resource not found: agent does not belong to this assistant"
    );
    error.name = "ResourceNotFoundException";
    throw error;
  };

  return { send: mockSend } as unknown as QConnectClient;
}

/**
 * Builds a valid API Gateway event for the apply-recommendations handler.
 */
function makeEvent(agentId: string) {
  return {
    httpMethod: "POST",
    resource: "/runs/{runId}/apply-recommendations",
    pathParameters: { runId: RUN_ID },
    body: JSON.stringify({
      mode: "direct",
      agentId,
      recommendationIndices: [0],
    }),
    requestContext: {
      authorizer: {
        claims: {
          sub: "user-123",
          "custom:tenantId": "tenant-abc",
        },
      },
    },
  };
}

// ---------------------------------------------------------------------------
// Property 10: Agent-assistant ownership validation
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 16.3**
 *
 * Property 10: Agent-assistant ownership validation
 *
 * For any agentId that does not belong to the configured ASSISTANT_ID,
 * the apply-recommendations handler SHALL return a 400 error with
 * `error: "agent_not_found"` rather than proceeding with the write.
 */
describe("Feature: implement-recommendations, Property 10: Agent-assistant ownership validation", () => {
  beforeEach(() => {
    process.env.INSTANCE_MODE = "development";
    process.env.ASSISTANT_ID = ASSISTANT_ID;
    process.env.TABLE_NAME = "TestTable";
    process.env.AWS_REGION = "us-east-1";

    // Inject mock DDB client that returns recommendations
    _setDDBDocClient(createMockDDBDocClient());
    // Inject mock QConnect client that throws ResourceNotFoundException
    _setQConnectClient(createMockQConnectClientThrowingResourceNotFound());
  });

  afterEach(() => {
    _setQConnectClient(null);
    _setDDBDocClient(null);
    process.env = { ...originalEnv };
  });

  it("returns 400 with error 'agent_not_found' for any agentId when GetAIAgent throws ResourceNotFoundException", async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.string({ minLength: 1, maxLength: 100 }),
        async (agentId) => {
          const event = makeEvent(agentId);
          const response = await handler(event);

          expect(response.statusCode).toBe(400);

          const body = JSON.parse(response.body);
          expect(body.error).toBe("agent_not_found");
          expect(body.reason).toContain(agentId);
          expect(body.reason).toContain(ASSISTANT_ID);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("never proceeds to drift detection or write operations when agent is not found", async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.string({ minLength: 1, maxLength: 100 }),
        async (agentId) => {
          const event = makeEvent(agentId);
          const response = await handler(event);

          // Should always return 400, never 200 (success), 409 (drift), or 500 (write failure)
          expect(response.statusCode).toBe(400);

          const body = JSON.parse(response.body);
          // Should not contain write-related fields
          expect(body.success).toBeUndefined();
          expect(body.newVersionId).toBeUndefined();
          expect(body.driftedFields).toBeUndefined();
        },
      ),
      { numRuns: 100 },
    );
  });

  it("returns 400 with agent_not_found for arbitrary unicode agentId strings", async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.unicodeString({ minLength: 1, maxLength: 50 }),
        async (agentId) => {
          const event = makeEvent(agentId);
          const response = await handler(event);

          expect(response.statusCode).toBe(400);

          const body = JSON.parse(response.body);
          expect(body.error).toBe("agent_not_found");
        },
      ),
      { numRuns: 100 },
    );
  });
});
