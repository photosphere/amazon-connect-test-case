#!/usr/bin/env node
/**
 * Bedrock-judge probe — validates that the AgentCore prompt templates
 * produce sensible scores when invoked directly via Bedrock Converse.
 *
 * Loads tests/fixtures/spans/multi-tool-success.json, parses it into an
 * ExecutionTrace via parseSpansToTrace, then renders the three documented
 * AgentCore prompt templates (Goal Success Rate, Helpfulness, Tool
 * Selection Accuracy) and scores each via one bedrock:Converse call per
 * evaluator unit.
 *
 * Run: AWS_REGION=us-east-1 npx ts-node --transpile-only scripts/bedrock-judge-probe.ts
 *
 * Cost: 1 Goal Success Rate + 2 Helpfulness (one per assistant turn) +
 * 2 Tool Selection Accuracy (one per tool call) = 5 Bedrock Converse
 * calls. ~$0.05–$0.10 with Claude 3.5 Sonnet on us-east-1.
 */
import { readFileSync } from "node:fs";
import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ContentBlock,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";
import {
  parseSpansToTrace,
  type RawSpan,
} from "../src/backend/orchestration/span-parser";
import type { ExecutionTrace } from "../src/shared/types";

const REGION = process.env.AWS_REGION ?? "us-east-1";
// Use Claude 3.5 Sonnet — same family AgentCore uses for builtin evaluators.
const JUDGE_MODEL_ID =
  process.env.JUDGE_MODEL_ID ??
  "us.anthropic.claude-3-5-sonnet-20241022-v2:0";

interface SpanFixture {
  name: string;
  sessionId: string;
  rawSpans: RawSpan[];
  availableTools: Array<{
    toolName: string;
    description?: string;
    inputSchema?: unknown;
  }>;
  expectedToolNames: string[];
}

// ---------------------------------------------------------------------------
// Score scales — mirrors AgentCore's documented [0.0, 1.0] mapping.
// ---------------------------------------------------------------------------

/** Helpfulness 7-point scale → [0,1]. */
const HELPFULNESS_SCALE: Record<string, number> = {
  "Not Helpful At All": 0.0,
  "Very Unhelpful": 1 / 6,
  "Somewhat Unhelpful": 2 / 6,
  "Neutral/Mixed": 3 / 6,
  "Somewhat Helpful": 4 / 6,
  "Very Helpful": 5 / 6,
  "Above And Beyond": 1.0,
};

const YES_NO_SCALE: Record<string, number> = { Yes: 1.0, No: 0.0 };

// ---------------------------------------------------------------------------
// Prompt templates — verbatim from
// https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html
// (escaped JSON-schema braces left as `{{` `}}` in the source so they pass
// through to the judge as literal `{` / `}`).
// ---------------------------------------------------------------------------

const GOAL_SUCCESS_RATE_TEMPLATE = `You are an objective judge evaluating the quality of an AI assistant as to whether a conversation between a User and the AI assistant successfully completed all User goals. You will be provided with:
1. The list of available tools the AI assistant can use. There are descriptions for each tool about when to use it and how to use it.
2. The complete conversation record with multiple turns including:
    - User messages (User:)
    - Assistant responses (Assistant:)
    - Tool selected by the assistant (Action:)
    - Tool outputs (Tool:)
3. The final assistant response that concludes the conversation.

Your task is to carefully analyze the conversation and determine if all User goals were successfully achieved. In order to achieve a User goal, the AI assistant usually need to use some tools and respond to User about the outcome. Please assess the goals one by one, following the steps below:
1. First, analyze the list of available tools, reason about what tools the AI assistant should use, and what response it should provide to the User in order to achieve the goal;
2. Next, check the conversation record and the final assistant response to decide whether the AI assistant used the expected tools and got the expected output, got the expected information, and responded to the User in the expected way. If the AI assistant did all expected work in the conversation record and provided an appropriate final response, the goal was achieved.
3. After judging about all the goals, decide whether the conversation achieved all user goals or not.

## Evaluation Rubric
- Yes: All user goals were achieved. The agent successfully completed all requested tasks, provided accurate information, and the user received satisfactory outcomes.
- No: Not all user goals were achieved. The agent failed to complete one or more requested tasks, provided incomplete/incorrect information, or the user's needs were not fully met.

**IMPORTANT**: The tool output ALWAYS takes priority over your own knowledge.

## Available tools
{available_tools}

## Conversation record
{context}

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Yes' or 'No'", "enum": ["Yes", "No"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}
Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (\`\`\`).`;

const HELPFULNESS_TEMPLATE = `You are an objective judge evaluating the helpfulness of an AI assistant's response from the user's perspective. Your task is to assess whether the assistant's turn moves the user closer to achieving or formulating their goals.

IMPORTANT: Evaluate purely from the user's perspective, without considering the factual accuracy or backend operations. Focus only on how the response helps the user progress towards their goals.

**IMPORTANT**: The tool output ALWAYS takes priority over your own knowledge.

Infer the user's goals purely based on the user's initial request, and any additional context they may provide afterwards.

# Conversation Context:
## Previous turns:
{context}

## Target turn to evaluate:
{assistant_turn}

# Evaluation Guidelines:
Rate the helpfulness of the assistant's turn using this scale:

0. Not Helpful At All
1. Very Unhelpful
2. Somewhat Unhelpful
3. Neutral/Mixed
4. Somewhat Helpful
5. Very Helpful
6. Above And Beyond

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Not Helpful At All', 'Very Unhelpful', 'Somewhat Unhelpful', 'Neutral/Mixed', 'Somewhat Helpful', 'Very Helpful' or 'Above And Beyond'", "enum": ["Not Helpful At All", "Very Unhelpful", "Somewhat Unhelpful", "Neutral/Mixed", "Somewhat Helpful", "Very Helpful", "Above And Beyond"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}

Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (\`\`\`).`;

const TOOL_SELECTION_TEMPLATE = `You are an objective judge evaluating if an AI assistant's action is justified at this specific point in the conversation.
## Available tool-calls
{available_tools}
## Previous conversation history
{context}
## Target tool-call to evaluate
{tool_turn}
## Evaluation Question:
Given the current state of the conversation, is the Agent justified in calling this specific action at this point in the conversation?
Consider:
1. Does this action reasonably address the user's current request or implied need?
2. Is the action aligned with the user's expressed or implied intent?
3. Are the minimum necessary parameters available to make the call useful?
4. Would a helpful assistant reasonably take this action to serve the user?
## Output Format:
First, provide a brief analysis of why this action is or is not justified at this point in the conversation.
Then, answer the evaluation question with EXACTLY ONE of these responses:
- Yes (if the action reasonably serves the user's intention at this point)
- No (if the action clearly does not serve the user's intention at this point)

The output should be a well-formatted JSON instance that conforms to the JSON schema below.
Here is the output JSON schema:
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Yes' or 'No'", "enum": ["Yes", "No"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}
Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (\`\`\`).`;

// ---------------------------------------------------------------------------
// Context rendering — turn an ExecutionTrace into the User:/Assistant:/
// Action:/Tool: log format the prompt templates expect.
// ---------------------------------------------------------------------------

interface FixtureTurn {
  customerText?: string;
  assistantText?: string;
  toolCalls: Array<{ name: string; args: unknown; result: unknown }>;
}

/**
 * Group the trace's steps into per-assistant-turn windows. The Q in Connect
 * trace alternates inference (assistant text) with execute_tool (tool calls);
 * we group by inference span, attaching subsequent tool calls until the next
 * inference span.
 */
function groupTraceIntoTurns(
  trace: ExecutionTrace,
  customerTurns: string[]
): FixtureTurn[] {
  const turns: FixtureTurn[] = [];
  let assistantIndex = 0;
  let current: FixtureTurn | null = null;
  for (const step of trace.steps) {
    if (step.type === "inference") {
      if (current) turns.push(current);
      current = {
        customerText: customerTurns[assistantIndex],
        assistantText: step.text,
        toolCalls: [],
      };
      assistantIndex += 1;
    } else if (step.type === "tool" && step.tool && current) {
      current.toolCalls.push({
        name: step.tool.toolName,
        args: step.tool.arguments,
        result: step.tool.result,
      });
    }
  }
  if (current) turns.push(current);
  return turns;
}

/** Render the full conversation as User:/Assistant:/Action:/Tool: lines. */
function renderFullContext(turns: FixtureTurn[]): string {
  const lines: string[] = [];
  for (const t of turns) {
    if (t.customerText) lines.push(`User: ${t.customerText}`);
    if (t.assistantText) lines.push(`Assistant: ${t.assistantText}`);
    for (const tc of t.toolCalls) {
      lines.push(`Action: ${tc.name}(${JSON.stringify(tc.args ?? {})})`);
      lines.push(`Tool: ${JSON.stringify(tc.result ?? null)}`);
    }
  }
  return lines.join("\n");
}

/** Render only the turns up to (but excluding) `targetIndex`. */
function renderContextBefore(
  turns: FixtureTurn[],
  targetIndex: number
): string {
  return renderFullContext(turns.slice(0, targetIndex));
}

/** Render the available-tools list. */
function renderAvailableTools(
  tools: SpanFixture["availableTools"]
): string {
  if (!tools.length) return "(no available tools)";
  return tools
    .map((t, i) => {
      const desc = t.description ?? "(no description)";
      const schema = t.inputSchema
        ? JSON.stringify(t.inputSchema)
        : "{}";
      return `${i + 1}. ${t.toolName}\n   description: ${desc}\n   inputSchema: ${schema}`;
    })
    .join("\n");
}

// ---------------------------------------------------------------------------
// Bedrock Converse helper
// ---------------------------------------------------------------------------

const client = new BedrockRuntimeClient({ region: REGION });

async function judge(prompt: string): Promise<{
  reasoning: string;
  score: string;
}> {
  const messages: Message[] = [
    { role: "user", content: [{ text: prompt }] as ContentBlock[] },
  ];
  const resp = await client.send(
    new ConverseCommand({
      modelId: JUDGE_MODEL_ID,
      messages,
      inferenceConfig: { maxTokens: 1024, temperature: 0 },
    })
  );
  const text = resp.output?.message?.content
    ?.map((b) => ("text" in b ? b.text ?? "" : ""))
    .join("");
  if (!text) throw new Error("Bedrock returned no text");
  const json = extractJson(text);
  return JSON.parse(json);
}

/** Pull the JSON object out of the ```...``` fenced block (per template). */
function extractJson(raw: string): string {
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
  if (fenced) return fenced[1].trim();
  // Fall back: find first { ... last } pair.
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start >= 0 && end > start) return raw.slice(start, end + 1);
  return raw.trim();
}

function fillTemplate(template: string, vars: Record<string, string>): string {
  return Object.entries(vars).reduce(
    (acc, [k, v]) => acc.split(`{${k}}`).join(v),
    template
  );
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main(): Promise<void> {
  const fixturePath =
    process.argv[2] ?? "tests/fixtures/spans/multi-tool-success.json";
  const fixture = JSON.parse(
    readFileSync(fixturePath, "utf-8")
  ) as SpanFixture;

  console.log(`Fixture: ${fixture.name} (${fixture.sessionId})`);
  console.log(`Judge model: ${JUDGE_MODEL_ID}\n`);

  const trace = parseSpansToTrace(fixture.sessionId, fixture.rawSpans);
  console.log(
    `Parsed: ${trace.steps.length} steps, ${trace.toolSequence.length} tool calls`
  );

  // Pull customer turns from the inference inputMessages (they're in the raw
  // fixture's input messages on each inference span).
  const customerTurns: string[] = [];
  for (const span of fixture.rawSpans) {
    if (span.spanName !== "inference") continue;
    const inputs = span.attributes?.inputMessages ?? [];
    for (const m of inputs) {
      for (const v of m.values ?? []) {
        if (v.text?.value) {
          customerTurns.push(v.text.value);
          break;
        }
      }
      break;
    }
  }
  const turns = groupTraceIntoTurns(trace, customerTurns);
  console.log(`Grouped into ${turns.length} assistant turn(s)\n`);

  const fullContext = renderFullContext(turns);
  const availableTools = renderAvailableTools(fixture.availableTools);

  // ---------------------- Goal Success Rate -----------------------------
  console.log("=".repeat(70));
  console.log("Builtin.GoalSuccessRate (session-level)");
  console.log("=".repeat(70));
  const gsrPrompt = fillTemplate(GOAL_SUCCESS_RATE_TEMPLATE, {
    available_tools: availableTools,
    context: fullContext,
  });
  const gsr = await judge(gsrPrompt);
  const gsrScore = YES_NO_SCALE[gsr.score];
  console.log(`Score: ${gsr.score} → ${gsrScore?.toFixed(4) ?? "(unmapped)"}`);
  console.log(`Reasoning: ${gsr.reasoning.slice(0, 240)}\n`);

  // ---------------------- Helpfulness (per turn) -----------------------------
  console.log("=".repeat(70));
  console.log("Builtin.Helpfulness (trace-level — one per assistant turn)");
  console.log("=".repeat(70));
  const helpfulnessScores: number[] = [];
  for (let i = 0; i < turns.length; i++) {
    const turn = turns[i];
    if (!turn.assistantText) continue;
    const previousContext = renderContextBefore(turns, i);
    const prompt = fillTemplate(HELPFULNESS_TEMPLATE, {
      context: previousContext.length ? previousContext : "(beginning of conversation)",
      assistant_turn: turn.assistantText,
    });
    const r = await judge(prompt);
    const v = HELPFULNESS_SCALE[r.score];
    helpfulnessScores.push(v ?? 0);
    console.log(
      `Turn ${i + 1}: ${r.score} → ${v?.toFixed(4) ?? "(unmapped)"}`
    );
    console.log(`  Reasoning: ${r.reasoning.slice(0, 200)}`);
  }
  const helpfulnessMean =
    helpfulnessScores.length > 0
      ? helpfulnessScores.reduce((a, b) => a + b, 0) /
        helpfulnessScores.length
      : undefined;
  console.log(
    `\nHelpfulness mean: ${helpfulnessMean?.toFixed(4) ?? "(no turns)"}\n`
  );

  // ---------------------- Tool Selection Accuracy (per tool) -----------------
  console.log("=".repeat(70));
  console.log(
    "Builtin.ToolSelectionAccuracy (tool-level — one per tool call)"
  );
  console.log("=".repeat(70));
  const toolScores: number[] = [];
  let toolGlobalIndex = 0;
  for (let ti = 0; ti < turns.length; ti++) {
    const turn = turns[ti];
    for (let tci = 0; tci < turn.toolCalls.length; tci++) {
      const tc = turn.toolCalls[tci];
      // Context is everything BEFORE this tool call within the conversation.
      const turnsBefore = turns.slice(0, ti);
      const lines: string[] = [renderFullContext(turnsBefore)];
      if (turn.customerText) lines.push(`User: ${turn.customerText}`);
      if (turn.assistantText) lines.push(`Assistant: ${turn.assistantText}`);
      // Include tool calls within this turn that came before this one.
      for (let prev = 0; prev < tci; prev++) {
        const p = turn.toolCalls[prev];
        lines.push(`Action: ${p.name}(${JSON.stringify(p.args ?? {})})`);
        lines.push(`Tool: ${JSON.stringify(p.result ?? null)}`);
      }
      const ctx = lines.filter((l) => l.length > 0).join("\n");
      const toolTurn = `${tc.name}(${JSON.stringify(tc.args ?? {})})`;
      const prompt = fillTemplate(TOOL_SELECTION_TEMPLATE, {
        available_tools: availableTools,
        context: ctx.length ? ctx : "(beginning of conversation)",
        tool_turn: toolTurn,
      });
      const r = await judge(prompt);
      const v = YES_NO_SCALE[r.score];
      toolScores.push(v ?? 0);
      toolGlobalIndex += 1;
      console.log(
        `Tool call ${toolGlobalIndex} (${tc.name}): ${r.score} → ${
          v?.toFixed(4) ?? "(unmapped)"
        }`
      );
      console.log(`  Reasoning: ${r.reasoning.slice(0, 200)}`);
    }
  }
  const toolMean =
    toolScores.length > 0
      ? toolScores.reduce((a, b) => a + b, 0) / toolScores.length
      : undefined;
  console.log(`\nTool selection accuracy mean: ${toolMean?.toFixed(4) ?? "(no tools)"}\n`);

  console.log("=".repeat(70));
  console.log("FINAL");
  console.log("=".repeat(70));
  console.log(`goalSuccessScore:   ${gsrScore?.toFixed(4) ?? "(unmapped)"}`);
  console.log(`helpfulnessScore:   ${helpfulnessMean?.toFixed(4) ?? "(none)"}`);
  console.log(`toolAccuracyScore:  ${toolMean?.toFixed(4) ?? "(none)"}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
