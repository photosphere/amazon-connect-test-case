# Implementation Plan: RAG Test Cases

## Overview

This plan extends the Connect Agent Test Platform with a second test case type — `rag` — alongside the existing `tool_sequence` type. The implementation progresses through shared types and pure utility modules first (chunk-extractor, jsonl-serializer, rag-decision), then backend handlers (cases handler, conversation-driver extension, rag-evaluate Lambda, opportunistic Faithfulness), then CDK infrastructure (S3 bucket, Lambda, IAM, state machine branch), then frontend surfaces (SuiteDetail form, CaseDetail RAG render, threshold editor), and finally tests and verification.

Every task references its target file from the design's Reuse Map. The codebase already exists — tasks either extend files in place or create one of the five new modules the design specifies (`chunk-extractor.ts`, `jsonl-serializer.ts`, `rag-decision.ts`, `opportunistic-faithfulness.ts`, `rag-evaluate.ts`) plus the new `cases.ts` handler.

## Tasks

- [x] 1. Extend shared types in `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/shared/types.ts`
  - Add `type: "tool_sequence" | "rag"` discriminator to the `TestCase` interface. Add the `RagTestCase` interface with `question` (1..1000 trimmed-non-empty), `groundTruthAnswer` (1..4000 trimmed-non-empty), optional `sessionData` (max 20 pairs).
  - Add the `ToolSequenceTestCase` interface preserving all existing fields. Export the discriminated union `TestCase = ToolSequenceTestCase | RagTestCase`.
  - Add `RetrievedChunk` interface: `{ text: string; knowledgeBaseId?: string; contentId?: string; title?: string; index: number }`.
  - Extend `TestCaseResult` with optional `caseType?: "tool_sequence" | "rag"`, optional `ragMetrics?: { faithfulness?: number; correctness?: number; completeness?: number; helpfulness?: number }`, optional `retrievedChunks?: RetrievedChunk[]`.
  - Extend `TestSuite` with optional `ragThresholds?: RagThresholds`.
  - Add `RagMetrics` and `RagThresholds` interfaces. Add `DEFAULT_RAG_THRESHOLDS` constant (all 0.7).
  - Extend `EvaluationErrorCode` union with `"RAG_JOB_FAILED" | "RAG_JOB_TIMEOUT" | "INSUFFICIENT_RAG_DATA" | "MALFORMED_RESULT"`.
  - Add `RAG_QUESTION_MAX`, `RAG_GROUND_TRUTH_MAX`, `RAG_JOB_POLL_INTERVAL_MS`, `RAG_JOB_TIMEOUT_MS` constants to `src/shared/constants.ts`.
  - _Requirements: 1.1, 1.3, 1.4, 3.4, 3.5, 6.1, 6.2, 8.1, 10.1, 10.2, 10.3, 10.5_

- [x] 2. Add new pure module `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/orchestration/chunk-extractor.ts`
  - Export `extractRetrievedChunks(rawSpans: RawSpan[], retrieveToolName: string): RetrievedChunk[]` exactly as specified in the design's Chunk Extraction Algorithm section.
  - Filter spans to `execute_tool` spans matching `retrieveToolName`, iterate `toolResult.values[]`, produce one `RetrievedChunk` per `text.value` with citation fields from `SpanCitation` objects.
  - Sort spans chronologically by `startTimestamp`. Preserve value order within each span. Assign monotonically increasing `index` across all chunks.
  - Import `RawSpan` from `./span-parser` and `RetrievedChunk` from `../../shared/types`.
  - The function is pure (no I/O, no AWS SDK calls) and never throws on well-formed input.
  - _Requirements: 3.4, 11.3, 12.1_

- [x] 3. Add new pure module `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/orchestration/jsonl-serializer.ts`
  - Export `RagCaseInput` interface and `serializeRagCaseToJsonl(input: RagCaseInput): string` that produces a single-line valid JSON conforming to the Bedrock BYOI retrieve-and-generate schema.
  - Implement `knowledgeBaseIdentifier` derivation: first chunk's `knowledgeBaseId` if present, else `"connect-orchestration-retrieve"` sentinel.
  - Export `assembleJsonlFile(cases: Array<{ caseId: string; line: string }>): { body: string; indexMap: Record<number, string> }` that joins lines with `\n`, no leading/trailing blank lines, and builds the line-index → caseId mapping.
  - All text fields (`question`, `groundTruthAnswer`, `agentResponse`, chunk texts) are preserved byte-for-byte in the output JSON — no trimming, no escaping beyond standard JSON string escaping.
  - The module is pure (no I/O).
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 5.10, 11.1_

- [x] 4. Add new pure module `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/orchestration/rag-decision.ts`
  - Export `RagMetrics`, `RagThresholds`, `DEFAULT_RAG_THRESHOLDS`, and `computeRagCaseStatus(metrics: RagMetrics, thresholds: RagThresholds): "passed" | "failed"`.
  - Implement the three-rule decision logic from the design: (1) faithfulness hard gate, (2) all-thresholds-met → passed, (3) otherwise → failed.
  - The function is pure, total, never throws, and always returns exactly one of two values.
  - _Requirements: 6.3, 6.4, 11.2_

- [x] 5. Checkpoint — Verify pure modules compile
  - Ensure `npx tsc --noEmit` passes with the new types and three pure modules. Ask the user if questions arise.

- [x] 6. Add new module `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/orchestration/opportunistic-faithfulness.ts`
  - Export `evaluateOpportunisticFaithfulness(agentResponse: string, chunks: RetrievedChunk[], judgeModelId: string): Promise<number | undefined>`.
  - Build the structured judge prompt from the design (retrieved passages as numbered list + assistant's response + scoring instruction).
  - Call Bedrock Converse with `temperature: 0`, `maxTokens: 50`, retry posture `(baseMs: 1000, capMs: 10000, maxRetries: 2)` on `ThrottlingException`, 15s timeout.
  - Parse the JSON response `{"score": <number>}`. On any failure (parse error, throttle after retries, model error), return `undefined` and log a warning — never throw.
  - Import the existing `backoff` helper from `src/shared/utils/backoff.ts` and the existing `BedrockRuntimeClient` patterns from `bedrock-judge-client.ts`.
  - _Requirements: 12.1, 12.2, 12.3, 12.4, 12.5, 12.7, 12.9, 12.10, 12.11_

- [x] 7. Extend the Conversation Driver at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/orchestration/conversation-driver.ts` — single-turn RAG mode
  - Add a conditional branch at the top of the per-case execution logic: when `case.type === "rag"`, execute the single-turn RAG flow instead of the multi-turn simulator loop.
  - RAG flow: CreateSession → optional UpdateSessionData (if `case.sessionData`) → SendMessage(`case.question`) → PollForResponse → ListSpans → `extractRetrievedChunks(spans, retrieveToolName)`.
  - Do NOT invoke the `Customer_Simulator` for RAG cases.
  - After ListSpans, if `case.type === "tool_sequence"` AND chunks were extracted AND suite has `ragThresholds`, call `evaluateOpportunisticFaithfulness` inline (~3-5s).
  - Persist transcript (single customer turn + single agent turn), `retrievedChunks`, and optional `ragMetrics.faithfulness` on the `TestCaseResult`.
  - On failure (timeout, session error), set `case.status = "error"`, populate `errorMessage`, set `caseType = "rag"`, leave `retrievedChunks` unset.
  - StopContact at the end regardless of success/failure.
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 12.1, 12.2, 12.5, 12.6, 12.7, 12.8, 12.10, 12.11_

- [x] 8. Add new Lambda handler `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/orchestration/rag-evaluate.ts` — Stage 2 handler
  - Export `handler(event: RagEvaluateInput): Promise<RagEvaluateOutput>` for Step Functions invocation.
  - Step 1: Filter to RAG cases with captured responses (not `error`).
  - Step 2: Serialize each case via `serializeRagCaseToJsonl`, assemble via `assembleJsonlFile`.
  - Step 3: Upload to `s3://{RAG_Job_Bucket}/{runId}/input.jsonl` with `Content-Type: application/jsonl`.
  - Step 4: Call `bedrock:CreateEvaluationJob` with BYOI dataset, retrieve-and-generate metric set (Faithfulness, Correctness, Completeness, Helpfulness), judge model from env.
  - Step 5: Poll `bedrock:GetEvaluationJob` every 30s, hard cap 30 min.
  - Step 6: On `COMPLETED` — read per-prompt output from S3, join by index via `indexMap`, write `ragMetrics` to DDB.
  - Step 7: On `FAILED`/`STOPPED`/timeout — write error codes (`RAG_JOB_FAILED`, `RAG_JOB_TIMEOUT`) to each case.
  - Step 8: Apply `computeRagCaseStatus` thresholds, set `case.status`.
  - Step 9: Persist `RAGJOB` record (`PK=RUN#{runId}, SK=RAGJOB`) with job ARN, status, indexMap, timestamps.
  - Log at INFO: job ARN, input S3 URI, judge model, metric set, case count. Log at ERROR: poll/read failures (without echoing JSONL contents).
  - _Requirements: 4.2, 4.4, 4.5, 4.7, 5.9, 5.10, 6.3, 6.4, 8.1, 8.2, 8.3, 8.4, 8.5, 9.1, 9.2_

- [x] 9. Add new handler `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/handlers/cases.ts` — type-discriminator validation
  - Export the cases handler for `POST /suites/{suiteId}/cases` and `PUT /suites/{suiteId}/cases/{caseId}`.
  - Implement the `normalizeTestCase` function: absent `type` → treat as `"tool_sequence"`.
  - Validate shape by type: RAG cases require `question` (1..1000, trimmed-non-empty) and `groundTruthAnswer` (1..4000, trimmed-non-empty); reject extraneous simulator fields (`persona`, `style`, `customerKnowledge`, `initialUtterance`, `goalDescription`, `primingMessage`, `successCriteria`) with HTTP 400 `{ error: "rag_case_extraneous_field", field }`.
  - Tool-sequence cases preserve existing validation unchanged.
  - On `PUT`, the `type` field is immutable — reject changes with HTTP 400.
  - Optional `sessionData` on RAG cases: max 20 key-value pairs, same constraint as tool-sequence.
  - Implement content tag filter validation (R13): on save with `sessionData`, inspect the agent's Retrieve tool config for `{{$.Custom.*}}` placeholders. Surface validation warnings (not hard errors) when keys don't match. If Discovery API call fails, save succeeds without the warning.
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 2.5, 2.7, 10.1, 10.2, 10.4, 10.5, 13.1, 13.2, 13.3, 13.4, 13.5, 13.6_

- [x] 10. Extend the suites handler at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/handlers/suites.ts` — ragThresholds
  - On `POST /suites` and `PUT /suites/{suiteId}`, accept optional `ragThresholds: { faithfulness, correctness, completeness, helpfulness }` with each value validated in `[0,1]`.
  - On read, normalize absent `ragThresholds` to `DEFAULT_RAG_THRESHOLDS` (all 0.7) without writing back.
  - Preserve existing suite fields verbatim — no `type` discriminator at the suite level.
  - _Requirements: 1.6, 1.7, 6.1, 6.2, 6.5, 6.6, 10.2_

- [x] 11. Extend the state machine at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/backend/orchestration/state-machine.ts` — conditional Stage 2 branch
  - Extend PrepareRun to detect whether the suite contains RAG cases and pass `hasRagCases: boolean`.
  - After the existing Map state, add a Choice state: if `hasRagCases === true` AND at least one RAG case survived Stage 1, transition to the RAG_Evaluate Lambda task; otherwise transition to EvaluateResults.
  - RAG_Evaluate task: invoke `RagEvaluateFn` with `runId` and RAG case data.
  - After RAG_Evaluate, transition to WriteResults.
  - EvaluateResults (existing): add a filter to skip cases where `caseType === "rag"`.
  - _Requirements: 4.1, 4.2, 4.3, 4.6, 4.7_

- [x] 12. Checkpoint — Verify backend compiles
  - Ensure `npx tsc --noEmit` passes with all backend changes. Ask the user if questions arise.

- [x] 13. CDK infrastructure at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/lib/orchestration-construct.ts`
  - Add `RAG_Job_Bucket` S3 bucket: S3-managed encryption, block all public access, `RemovalPolicy.RETAIN`, 90-day lifecycle expiration.
  - Add `RagEvaluateFn` NodejsFunction from `src/backend/orchestration/rag-evaluate.ts`: timeout 15 min, memory 1024 MB, environment includes `RAG_JOB_BUCKET` and `JUDGE_MODEL_ID`.
  - Grant `ragJobBucket.grantReadWrite(ragEvaluateFn)`.
  - Grant Bedrock IAM: `bedrock:CreateEvaluationJob`, `bedrock:GetEvaluationJob`, `bedrock:StopEvaluationJob` on `"*"`.
  - Grant Bedrock Converse on the Conversation Driver Lambda for opportunistic Faithfulness (confirm existing grant covers it or add).
  - Grant DynamoDB read/write for the RAG Evaluate Lambda.
  - Wire the `RagEvaluateFn` into the state machine definition.
  - _Requirements: 4.2, 9.1, 9.2, 10.6_

- [x] 14. Wire cases handler into `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/lib/api-construct.ts`
  - Add a new `casesLambda` NodejsFunction from `src/backend/handlers/cases.ts` with appropriate timeout and memory.
  - Grant DynamoDB read/write for persisting cases.
  - Add API Gateway routes: `POST /suites/{suiteId}/cases`, `PUT /suites/{suiteId}/cases/{caseId}`, `GET /suites/{suiteId}/cases/{caseId}`, `DELETE /suites/{suiteId}/cases/{caseId}`.
  - Grant Discovery API read access for content tag filter validation.
  - _Requirements: 1.1, 1.5, 13.1, 13.5_

- [x] 15. Checkpoint — CDK synth passes
  - Run `npx cdk synth` and confirm the new S3 bucket, RAG_Evaluate Lambda, cases Lambda, IAM grants, and state machine branch all appear in the template. Ask the user if questions arise.

- [x] 16. Extend `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/frontend/src/pages/SuiteDetail.tsx` — Test Type dropdown, conditional form, type badge, threshold editor
  - Add a `Test Type` dropdown as the first field in the "Create test case" modal with options `Tool Use` (value `tool_sequence`) and `RAG` (value `rag`), defaulting to `Tool Use`.
  - When `RAG` is selected, render: `Name`, `Description`, `Question` (max 1000), `Ground Truth Answer` (max 4000), and optional collapsible `Session Data` (max 20 pairs).
  - When `Tool Use` is selected, render existing field set unchanged.
  - On type switch, discard values of hidden fields on submit to prevent hybrid records.
  - Add `Type` column to the case list table showing badge `Tool Use` or `RAG`.
  - Disable the `Test Type` dropdown in edit mode (type is immutable post-creation).
  - Add RAG thresholds editor (four numeric inputs [0,1], one decimal place) on the suite edit form when the suite contains at least one RAG case. Default unfilled to 0.7.
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 6.5_

- [x] 17. Extend `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/src/frontend/src/pages/CaseDetail.tsx` — RAG render surface and opportunistic Faithfulness row
  - When `caseType === "rag"`, render four sections: `Question`, `Agent's Answer`, `Ground Truth`, `Metrics`.
  - `Question`: render `case.question` verbatim preserving whitespace and newlines.
  - `Agent's Answer`: render agent's terminal response verbatim.
  - `Ground Truth`: render `case.groundTruthAnswer` verbatim.
  - `Metrics`: render four rows (Faithfulness, Correctness, Completeness, Helpfulness) with score (3 decimal places), threshold, pass/fail indicator.
  - Add collapsible `Retrieved Chunks` panel: each chunk's `text` in preformatted monospace, `title`, `knowledgeBaseId`, `contentId`. Empty state: "No chunks were retrieved for this question".
  - When `status === "failed"` due to Faithfulness hard gate, render "Failed Faithfulness gate" badge above Metrics.
  - Hide `Tools Invoked`, `Turn Count`, and tool-sequence evaluation panels for RAG cases.
  - For `tool_sequence` cases with `ragMetrics.faithfulness`, render a "Groundedness" metric row beneath evaluation reasoning showing score, threshold, pass/fail indicator (informational only).
  - Render `evaluationError` alert for each new error code with appropriate user-facing copy per R8.7.
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 7.7, 7.8, 8.7, 12.5, 12.9_

- [x] 18. Checkpoint — Frontend build passes
  - Run `npm run build` in `src/frontend/` and confirm zero new type or lint errors. Ask the user if questions arise.

- [x] 19. Add example-based unit tests for chunk-extractor at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/chunk-extractor.test.ts`
  - Test cases: single Retrieve span with two chunks → produces two RetrievedChunks in order; mixed span types (non-Retrieve spans ignored); empty `toolResult.values` → produces zero chunks; multiple Retrieve spans → chunks ordered chronologically across spans; citation fields populated from SpanCitation when present, undefined when absent.
  - _Requirements: 3.4, 11.3_

- [x] 20. Add example-based unit tests for jsonl-serializer at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/jsonl-serializer.test.ts`
  - Test cases: case with empty chunks → `retrievalResults: []`; `knowledgeBaseId` derivation from first chunk vs sentinel fallback; multi-chunk case → all chunk texts preserved verbatim; `assembleJsonlFile` joins with `\n`, no blank lines, correct `indexMap`.
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 11.1_

- [x] 21. Add example-based unit tests for rag-decision at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/rag-decision.test.ts`
  - Test cases: all metrics above thresholds → `"passed"`; faithfulness below threshold → `"failed"` regardless of others; one non-faithfulness metric below threshold → `"failed"`; exact boundary (score === threshold) → `"passed"`.
  - _Requirements: 6.3, 6.4, 11.2_

- [x] 22. Add example-based unit tests for cases handler at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/cases.test.ts`
  - Test cases: valid RAG case creation → persisted with `type: "rag"`; missing `question` → HTTP 400; empty trimmed `question` → HTTP 400; extraneous simulator field on RAG case → HTTP 400 with `rag_case_extraneous_field`; valid tool-sequence case → existing fields preserved; type mutation attempt on PUT → HTTP 400; legacy record without `type` field → normalized to `"tool_sequence"` on read; sessionData > 20 pairs → HTTP 400.
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 11.4_

- [x] 23. Add example-based unit tests for opportunistic-faithfulness at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/opportunistic-faithfulness.test.ts`
  - Test cases: mock Converse returns valid `{"score": 0.85}` → returns `0.85`; Converse throws ThrottlingException → retries then returns `undefined`; Converse returns malformed JSON → returns `undefined`; empty chunks array → prompt still constructed correctly.
  - _Requirements: 12.3, 12.4, 12.11_

- [x] 24. Add example-based unit tests for rag-evaluate at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/rag-evaluate.test.ts`
  - Test cases: successful flow (create job → poll → read → write metrics); job fails → all cases get `RAG_JOB_FAILED` error; poll timeout → all cases get `RAG_JOB_TIMEOUT`; malformed per-prompt output → single case gets `MALFORMED_RESULT`, others still scored; zero surviving cases → skips CreateEvaluationJob.
  - _Requirements: 4.4, 4.5, 4.6, 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 25. Add Property 1 (JSONL round-trip) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/jsonl-roundtrip.property.test.ts`
  - **Property 1: JSONL Serialization Round-Trip**
  - **Validates: Requirements 11.1, 5.1, 5.2, 5.3, 5.4, 5.7**
  - Generator: arbitrary `RagCaseInput` with `question` (1..1000 chars), `groundTruthAnswer` (1..4000 chars), `agentResponse` (arbitrary string), `retrievedChunks` (0..10 chunks with arbitrary text), `knowledgeBaseId` (optional), `modelIdentifier` (arbitrary).
  - Property: `serializeRagCaseToJsonl(input)` produces a single-line valid JSON whose `prompt.content[0].text === input.question`, `referenceResponses[0].content[0].text === input.groundTruthAnswer`, `output.text === input.agentResponse`, and `retrievalResults[i].content.text === input.retrievedChunks[i].text` byte-for-byte.
  - Minimum 100 fast-check iterations. Tag: `// Feature: rag-test-cases, Property 1: JSONL Serialization Round-Trip`.

- [x] 26. Add Property 2 (Pass/Fail decision pure and total) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/rag-decision.property.test.ts`
  - **Property 2: Pass/Fail Decision Function is Pure and Total**
  - **Validates: Requirements 11.2, 6.3, 6.4**
  - Generator: four `fc.double({ min: 0, max: 1 })` for metrics, four `fc.double({ min: 0, max: 1 })` for thresholds.
  - Property: `computeRagCaseStatus` returns `"failed"` if `faithfulness < faithfulnessThreshold`; returns `"passed"` if all four metrics >= respective thresholds; returns `"failed"` otherwise. Never throws.
  - Minimum 100 fast-check iterations. Tag: `// Feature: rag-test-cases, Property 2: Pass/Fail Decision Function is Pure and Total`.

- [x] 27. Add Property 3 (Chunk extraction preserves order and text) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/chunk-extractor.property.test.ts`
  - **Property 3: Chunk Extraction Preserves Order and Text**
  - **Validates: Requirements 11.3, 3.4**
  - Generator: array of 0..5 `execute_tool` spans matching the Retrieve tool name, each with 0..5 `toolResult.values[]` entries carrying arbitrary text strings, plus 0..3 non-matching spans interspersed.
  - Property: `extractRetrievedChunks` returns a `RetrievedChunk[]` whose length equals the total `toolResult.values[]` count across matching spans, in chronological span order then positional value order, with each `chunk.text` byte-for-byte equal to the corresponding `text.value`.
  - Minimum 100 fast-check iterations. Tag: `// Feature: rag-test-cases, Property 3: Chunk Extraction Preserves Order and Text`.

- [x] 28. Add Property 4 (Type-discriminator accepts exactly valid shapes) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/type-discriminator.property.test.ts`
  - **Property 4: Type-Discriminator Validator Accepts Exactly Valid Shapes**
  - **Validates: Requirements 11.4, 1.3, 1.4, 1.5**
  - Generator: random record objects that are either (a) valid `tool_sequence` shapes, (b) valid `rag` shapes, (c) invalid shapes (missing required fields, extraneous simulator fields on rag type, empty question, etc.).
  - Property: the validator accepts records satisfying shape (a) or (b) and rejects all others; no third valid shape exists.
  - Minimum 100 fast-check iterations. Tag: `// Feature: rag-test-cases, Property 4: Type-Discriminator Validator Accepts Exactly Valid Shapes`.

- [x] 29. Add Property 5 (Read normalization backward compatibility) at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/unit/properties/rag-backward-compat.property.test.ts`
  - **Property 5: Read Normalization Preserves Backward Compatibility**
  - **Validates: Requirements 10.1, 10.2, 10.3, 10.4, 1.2, 6.2**
  - Generator: random persisted records missing `type` (TestCase), `ragThresholds` (TestSuite), or `caseType` (TestCaseResult).
  - Property: the normalizer produces a valid typed object with defaults (`type = "tool_sequence"`, `ragThresholds = DEFAULT_RAG_THRESHOLDS`, `caseType = "tool_sequence"`) without mutating the original and without throwing.
  - Minimum 100 fast-check iterations. Tag: `// Feature: rag-test-cases, Property 5: Read Normalization Preserves Backward Compatibility`.

- [x] 30. Checkpoint — All tests pass
  - Run `npx vitest run` and confirm all unit tests and property tests pass. Ask the user if questions arise.

- [x] 31. Add integration tests at `/Users/trindfus/Documents/Connect-Automated-Agentic-Tester/tests/integration/rag-test-cases.test.ts`
  - Conversation Driver RAG mode: mocked QConnect client, single-turn flow, no simulator invocation, chunks extracted correctly.
  - Stage 2 pipeline: mocked Bedrock RAG Evaluation APIs (CreateEvaluationJob → GetEvaluationJob poll → S3 read → DDB write).
  - State machine conditional branch: suite with RAG cases triggers Stage 2; suite without RAG cases skips Stage 2.
  - Error code propagation: each failure mode (`RAG_JOB_FAILED`, `RAG_JOB_TIMEOUT`, `MALFORMED_RESULT`, `MISSING_EVALUATOR`) produces the correct DDB record.
  - Opportunistic Faithfulness: tool-sequence case with Retrieve invocation gets `ragMetrics.faithfulness`; tool-sequence without Retrieve does not.
  - _Requirements: 3.1, 3.2, 3.7, 4.1, 4.6, 8.1, 8.2, 8.3, 8.4, 8.5, 12.1, 12.8, 12.11_

- [x] 32. Verification — full build, test suite, CDK synth
  - Run `npx tsc --noEmit` from the repository root and confirm zero new TypeScript errors across `src/`, `lib/`, and `tests/`.
  - Run `npx vitest run` from the repository root and confirm all unit tests, property tests, and integration tests pass.
  - Run the frontend production build (`npm run build` in `src/frontend/`) and confirm zero new lint or type errors.
  - Run `npx cdk synth` and confirm: `RagJobBucket` S3 resource, `RagEvaluateFn` Lambda, cases Lambda, IAM policies (Bedrock RAG Evaluation + S3 + DDB), state machine Choice state for Stage 2 branch.
  - Confirm no unrelated CloudFormation drift in `cdk.out/ConnectAgentTestPlatformStack.template.json`.
  - _Requirements: All — final integration verification_

## Notes

- Every task references absolute file paths from the design's Reuse Map. Sub-bullets are implementation details only.
- Tasks 2, 3, and 4 are independent pure modules with no AWS SDK dependencies — ideal for parallel development.
- Property tests (tasks 25–29) are individual leaf tasks per the project's convention so each property's pass/fail is independently visible in CI.
- Tasks marked with `*` are optional and can be skipped for faster MVP. Core implementation tasks are never optional.
- The design uses TypeScript throughout; all code examples in the tasks assume TypeScript.
- Checkpoints (tasks 5, 12, 15, 18, 30) ensure incremental validation — each gate confirms the build is green before downstream tasks begin.
- The state machine extension (task 11) depends on the RAG Evaluate Lambda (task 8) existing as a module; the CDK wiring (task 13) connects them at the infrastructure level.
- Content tag filter validation in the cases handler (task 9) is best-effort — a failed Discovery API call allows the save to proceed without the warning.
- Backward compatibility is all read-time normalization — no existing records are mutated.

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1"] },
    { "id": 1, "tasks": ["2", "3", "4"] },
    { "id": 2, "tasks": ["6", "9", "10"] },
    { "id": 3, "tasks": ["7", "8", "11"] },
    { "id": 4, "tasks": ["13", "14"] },
    { "id": 5, "tasks": ["16", "17"] },
    { "id": 6, "tasks": ["19", "20", "21", "22", "23", "24"] },
    { "id": 7, "tasks": ["25", "26", "27", "28", "29"] },
    { "id": 8, "tasks": ["31"] },
    { "id": 9, "tasks": ["32"] }
  ]
}
```
