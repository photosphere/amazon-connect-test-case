/**
 * Golden-prompt snapshot conformance test — replaces the prior OTel schema
 * conformance test (`tests/unit/trace-to-otel.fixtures.test.ts`).
 *
 * For each Span_Fixture under `tests/fixtures/spans/`, this test reproduces
 * the inputs the generator (`scripts/generate-golden-prompts.ts`) feeds to
 * `renderJudgePromptContext` and asserts byte-equality against every
 * committed `.txt` snapshot under
 * `tests/fixtures/golden-prompts/{fixture-name}/`. It also asserts the three
 * structural invariants the snapshot layout depends on:
 *
 *   - The count of `{assistant_turn}` renderings equals the number of
 *     inference steps in the trace (Requirement 11.3).
 *   - The count of `{tool_turn}` renderings equals the number of
 *     `execute_tool` entries in the trace (Requirement 11.3).
 *   - Chronological order is preserved across both arrays — `index` is
 *     strictly increasing and matches array position (Requirement 11.6).
 *
 * On mismatch the test fails with a diff that names the changed `.txt` file,
 * so a snapshot drift surfaces as a focused code-review byte-diff rather than
 * a silent semantic change. Snapshots are intentionally regenerated only by
 * an explicit `npx tsx scripts/generate-golden-prompts.ts` checked in to the
 * same PR.
 *
 *   Validates: Requirements 11.2, 11.3, 11.6
 */

import { describe, it, expect } from "vitest";
import * as fs from "node:fs";
import * as path from "node:path";

import {
  parseSpansToTrace,
  type RawSpan,
} from "../../src/backend/orchestration/span-parser";
import { renderJudgePromptContext } from "../../src/shared/utils/judge-prompt-rendering";
import type {
  AgentSnapshot,
  ToolDefinition,
  TranscriptTurn,
} from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Fixture loading (mirrors scripts/generate-golden-prompts.ts byte-for-byte
// so the test reproduces the same `renderJudgePromptContext` inputs the
// generator wrote the snapshots from)
// ---------------------------------------------------------------------------

interface SpanFixture {
  name: string;
  description?: string;
  sessionId: string;
  rawSpans: RawSpan[];
  expectedToolSequence?: string[];
  availableTools: ToolDefinition[];
  expectedToolNames: string[];
}

const SPANS_DIR = path.resolve(__dirname, "../fixtures/spans");
const GOLDEN_DIR = path.resolve(__dirname, "../fixtures/golden-prompts");

function loadFixtures(): SpanFixture[] {
  return fs
    .readdirSync(SPANS_DIR)
    .filter((entry) => entry.endsWith(".json"))
    .sort()
    .map((entry) => {
      const full = path.join(SPANS_DIR, entry);
      return JSON.parse(fs.readFileSync(full, "utf8")) as SpanFixture;
    });
}

const FIXTURES = loadFixtures();

// ---------------------------------------------------------------------------
// Helpers — reproducing the generator's input derivation
// ---------------------------------------------------------------------------

/**
 * Pulls the customer-side utterances from a fixture's raw `inference` spans
 * into a positional `TranscriptTurn[]`. Mirrors
 * `extractCustomerTranscript` in `scripts/generate-golden-prompts.ts` so the
 * rendered output is byte-equal to the snapshots the generator wrote.
 */
function extractCustomerTranscript(fixture: SpanFixture): TranscriptTurn[] {
  const turns: TranscriptTurn[] = [];
  let turnNumber = 0;
  for (const span of fixture.rawSpans) {
    if (span.spanName !== "inference") continue;
    const text = firstInputText(span);
    if (text === undefined) continue;
    turns.push({
      turnNumber: turnNumber++,
      role: "customer",
      text,
      timestamp: span.startTimestamp ?? new Date(0).toISOString(),
      elapsedMs: 0,
    });
  }
  return turns;
}

function firstInputText(span: RawSpan): string | undefined {
  const inputs = span.attributes?.inputMessages ?? [];
  for (const m of inputs) {
    for (const v of m.values ?? []) {
      const text = v.text?.value;
      if (typeof text === "string" && text.length > 0) return text;
    }
  }
  return undefined;
}

function makeSnapshot(tools: ToolDefinition[]): AgentSnapshot {
  return {
    tools,
    systemPrompt: "",
    modelId: "",
    capturedAt: new Date(0).toISOString(),
  };
}

/** Counts spans of a specific name across a fixture's chronological raw spans. */
function countSpans(fixture: SpanFixture, spanName: string): number {
  return fixture.rawSpans.filter((s) => s.spanName === spanName).length;
}

// ---------------------------------------------------------------------------
// Sanity check on the fixture inventory
// ---------------------------------------------------------------------------

describe("Span_Fixture inventory (golden-prompt conformance)", () => {
  it("loads at least the two committed fixtures from tests/fixtures/spans/", () => {
    expect(FIXTURES.length).toBeGreaterThanOrEqual(2);
    const names = FIXTURES.map((f) => f.name);
    expect(names).toContain("multi-tool-success");
    expect(names).toContain("failure-escalation");
  });

  it("has a corresponding golden-prompts directory for each fixture", () => {
    for (const f of FIXTURES) {
      const dir = path.join(GOLDEN_DIR, f.name);
      expect(
        fs.existsSync(dir),
        `Missing golden-prompts directory for fixture "${f.name}" at ${dir}. ` +
          `Run \`npx tsx scripts/generate-golden-prompts.ts\` to regenerate.`,
      ).toBe(true);
    }
  });
});

// ---------------------------------------------------------------------------
// Per-fixture conformance: byte-equality + structural invariants
// ---------------------------------------------------------------------------

describe.each(FIXTURES)(
  "Span_Fixture[$name] — judge-prompt rendering conforms to committed snapshots (Reqs 11.2, 11.3, 11.6)",
  (fixture) => {
    const trace = parseSpansToTrace(fixture.sessionId, fixture.rawSpans);
    const transcript = extractCustomerTranscript(fixture);
    const snapshot = makeSnapshot(fixture.availableTools ?? []);
    const expectedToolNames = fixture.expectedToolNames ?? [];

    const rendered = renderJudgePromptContext({
      trace,
      transcript,
      snapshot,
      expectedToolNames,
    });

    const fixtureDir = path.join(GOLDEN_DIR, fixture.name);

    /** Reads a snapshot file as UTF-8 with a clear failure message when it is missing. */
    function readSnapshot(relPath: string): string {
      const full = path.join(fixtureDir, relPath);
      if (!fs.existsSync(full)) {
        throw new Error(
          `Missing golden-prompt snapshot "${path.relative(GOLDEN_DIR, full)}". ` +
            `Run \`npx tsx scripts/generate-golden-prompts.ts\` to regenerate.`,
        );
      }
      return fs.readFileSync(full, "utf8");
    }

    /**
     * Asserts byte-equality between a rendered string and a committed
     * snapshot. On mismatch Vitest's diff identifies the changed bytes; the
     * surrounding `expect` message names the snapshot path so the failure
     * points at the file the engineer must regenerate.
     */
    function expectMatches(actual: string, relPath: string): void {
      const expected = readSnapshot(relPath);
      expect(
        actual,
        `Rendered prompt-context drift vs committed snapshot ${path.join(
          fixture.name,
          relPath,
        )}. Snapshots are updated only by an explicit checked-in regeneration ` +
          `(see scripts/generate-golden-prompts.ts).`,
      ).toBe(expected);
    }

    // -- Byte-equality assertions ---------------------------------------------

    it("session-level {context} matches context.txt byte-for-byte", () => {
      expectMatches(rendered.context, "context.txt");
    });

    it("{available_tools} matches available-tools.txt byte-for-byte", () => {
      expectMatches(rendered.availableTools, "available-tools.txt");
    });

    it("each {assistant_turn} and its prefix-only {context} match their snapshot files byte-for-byte", () => {
      for (const at of rendered.assistantTurns) {
        expectMatches(at.assistantTurn, `assistant-turn-${at.index}.txt`);
        expectMatches(at.context, `assistant-turn-${at.index}.context.txt`);
      }
    });

    it("each {tool_turn} and its prefix-only {context} match their snapshot files byte-for-byte", () => {
      for (const tt of rendered.toolTurns) {
        expectMatches(tt.toolTurn, `tool-turn-${tt.index}.txt`);
        expectMatches(tt.context, `tool-turn-${tt.index}.context.txt`);
      }
    });

    it("does not produce extra rendered units beyond what the fixture has snapshot files for", () => {
      // Guard against silent additions: every assistant-turn-{i}.txt and
      // tool-turn-{i}.txt that exists on disk MUST have a matching rendered
      // unit, and the renderer MUST NOT emit a unit without a snapshot.
      const onDisk = fs.readdirSync(fixtureDir).sort();
      const expectedAssistantFiles = new Set<string>();
      const expectedToolFiles = new Set<string>();
      for (const at of rendered.assistantTurns) {
        expectedAssistantFiles.add(`assistant-turn-${at.index}.txt`);
        expectedAssistantFiles.add(`assistant-turn-${at.index}.context.txt`);
      }
      for (const tt of rendered.toolTurns) {
        expectedToolFiles.add(`tool-turn-${tt.index}.txt`);
        expectedToolFiles.add(`tool-turn-${tt.index}.context.txt`);
      }

      const assistantFilesOnDisk = onDisk.filter((n) =>
        n.startsWith("assistant-turn-"),
      );
      const toolFilesOnDisk = onDisk.filter((n) => n.startsWith("tool-turn-"));

      expect(new Set(assistantFilesOnDisk)).toEqual(expectedAssistantFiles);
      expect(new Set(toolFilesOnDisk)).toEqual(expectedToolFiles);
    });

    // -- Structural invariants -------------------------------------------------

    it("emits exactly one {assistant_turn} per inference step (Req 11.3)", () => {
      const inferenceCount = countSpans(fixture, "inference");
      expect(rendered.assistantTurns.length).toBe(inferenceCount);
    });

    it("emits exactly one {tool_turn} per execute_tool entry (Req 11.3)", () => {
      const toolCount = countSpans(fixture, "execute_tool");
      expect(rendered.toolTurns.length).toBe(toolCount);
    });

    it("preserves chronological order — assistantTurns indices are strictly increasing and match array position", () => {
      for (let i = 0; i < rendered.assistantTurns.length; i++) {
        expect(rendered.assistantTurns[i].index).toBe(i);
      }
    });

    it("preserves chronological order — toolTurns indices are strictly increasing and match array position", () => {
      for (let i = 0; i < rendered.toolTurns.length; i++) {
        expect(rendered.toolTurns[i].index).toBe(i);
      }
    });

    it("preserves chronological order — emitted tool sequence equals the fixture's expectedToolSequence (Req 11.6)", () => {
      const emitted = trace.steps
        .filter((s) => s.type === "tool" && s.tool != null)
        .map((s) => s.tool!.toolName);
      const expected = fixture.expectedToolSequence ?? [];
      if (expected.length > 0) {
        expect(emitted).toEqual(expected);
      }
      // The toolTurns array, by construction, is rendered in the same order
      // as the trace's tool steps; that ordering is asserted indirectly by
      // the per-tool byte-equality tests above (`tool-turn-{i}.txt` is
      // generated in chronological order). This assertion guards against a
      // future refactor that reorders rendered.toolTurns out of trace order.
      expect(rendered.toolTurns.length).toBe(emitted.length);
    });
  },
);
