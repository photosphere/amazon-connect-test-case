/**
 * Tenant ID extraction utility.
 *
 * Derives the tenant identity from Cognito authorizer claims in API Gateway events.
 * Supports both interactive (user pool) and machine (client_credentials) token types.
 *
 * - Interactive users: tenant = `sub` claim (Cognito user ID)
 * - Machine clients: tenant = `machine:{client_id}` (prefixed to avoid collision)
 *
 * Requirements: 15.3, 15.4, 15.5
 *
 * @module tenant-extraction
 */

/**
 * Shape of the claims object from a Cognito-authorized API Gateway event.
 */
export interface CognitoClaims {
  /** Present for interactive user pool tokens. */
  sub?: string;
  /** Present for machine client_credentials tokens. */
  client_id?: string;
  /** Other claims we don't use for tenant derivation. */
  [key: string]: string | undefined;
}

/**
 * Extracts the tenant ID from Cognito authorizer claims.
 *
 * Priority:
 * 1. If `sub` is present → interactive user, return `sub` directly
 * 2. If `client_id` is present → machine client, return `machine:{client_id}`
 * 3. Otherwise → throw (no valid identity)
 *
 * @param claims - The claims object from `event.requestContext.authorizer.claims`
 * @returns The derived tenant ID string
 * @throws Error if neither `sub` nor `client_id` is present
 */
export function extractTenantId(claims: CognitoClaims | undefined | null): string {
  if (!claims) {
    throw new Error('Unable to determine tenant identity: no claims present');
  }

  // Interactive user: Cognito User Pool issues tokens with `sub`
  if (claims.sub) {
    return claims.sub;
  }

  // Machine client: client_credentials tokens have `client_id` but no `sub`
  if (claims.client_id) {
    return `machine:${claims.client_id}`;
  }

  throw new Error('Unable to determine tenant identity from token');
}

/**
 * Extracts the tenant ID from an API Gateway proxy event structure.
 *
 * Convenience wrapper that navigates the event shape to reach claims.
 *
 * @param event - The API Gateway proxy event (or subset)
 * @returns The derived tenant ID string, or null if extraction fails
 */
export function extractTenantIdFromEvent(event: {
  requestContext?: {
    authorizer?: {
      claims?: CognitoClaims;
    };
  };
}): string | null {
  try {
    const claims = event.requestContext?.authorizer?.claims;
    return extractTenantId(claims);
  } catch {
    return null;
  }
}
