/**
 * Contact Manager — mints and tears down real Amazon Connect contacts for test runs.
 *
 * Why this exists:
 * Q in Connect ORCHESTRATION agents expose MCP tools whose gateway backends read
 * the bound contact's ContactARN from the session's runtime context (the same
 * ContactARN Amazon Connect injects when a real contact reaches the agent). A
 * standalone Q in Connect session created via CreateSession has no associated
 * contact, so those tools fail with "ContactARN not found in session" and the
 * agent escalates.
 *
 * To test the agent the way a real contact reaches it, we mint a genuine (but
 * synthetic) Connect contact via StartChatContact against a minimal dummy flow,
 * pass its ARN to CreateSession.contactArn, run the conversation, then stop the
 * contact. This was proven empirically: with a bound contact, verifyIdentity →
 * getAccounts → getLoanDetails all succeed.
 *
 * @module contact-manager
 */

import {
  ConnectClient,
  StartChatContactCommand,
  StopContactCommand,
} from "@aws-sdk/client-connect";

const REGION = process.env.AWS_REGION ?? "us-east-1";

/** A minted contact: the raw ID plus the fully-qualified ARN for session binding. */
export interface MintedContact {
  contactId: string;
  contactArn: string;
}

// --- Client (lazy singleton, test-injectable) ---

let connectClient: ConnectClient | null = null;

function getConnectClient(): ConnectClient {
  if (!connectClient) {
    connectClient = new ConnectClient({ region: REGION });
  }
  return connectClient;
}

/** @internal — allows test injection */
export function _setConnectClient(client: ConnectClient | null): void {
  connectClient = client;
}

/**
 * Builds the fully-qualified contact ARN from an instance ID and contact ID.
 *
 * Format: arn:aws:connect:{region}:{account}:instance/{instanceId}/contact/{contactId}
 *
 * Region and account are resolved at call time from the environment so the
 * function is testable and reflects the runtime Lambda environment.
 */
export function buildContactArn(instanceId: string, contactId: string): string {
  const region = process.env.AWS_REGION ?? "us-east-1";
  const account =
    process.env.ACCOUNT_ID ?? process.env.AWS_ACCOUNT_ID ?? process.env.CDK_ACCOUNT ?? "";
  // Accept either a bare instance UUID or a full instance ARN.
  const instanceUuid = instanceId.startsWith("arn:")
    ? instanceId.split("/").pop()!
    : instanceId;
  return `arn:aws:connect:${region}:${account}:instance/${instanceUuid}/contact/${contactId}`;
}

/**
 * Mints a real Amazon Connect contact via StartChatContact against the dummy
 * contact-creator flow. The contact exists only to provide a bindable
 * ContactARN for the Q in Connect session; we never connect a participant.
 *
 * @param instanceId - The Connect instance ID
 * @param contactFlowId - The dummy contact-creator flow ID
 * @param ani - Optional caller phone number to attach to the contact
 * @returns The minted contact ID and its fully-qualified ARN
 */
export async function startContact(
  instanceId: string,
  contactFlowId: string,
  ani?: string
): Promise<MintedContact> {
  const client = getConnectClient();

  const response = await client.send(
    new StartChatContactCommand({
      InstanceId: instanceId,
      ContactFlowId: contactFlowId,
      ParticipantDetails: { DisplayName: "AgentTestHarness" },
      // Attach ANI as a contact attribute so it is available to the contact
      // record and any flow logic that reads it.
      ...(ani ? { Attributes: { ANI: ani } } : {}),
      // Keep the synthetic contact short-lived as a safety net in case StopContact
      // is never reached (min allowed is 60 minutes).
      ChatDurationInMinutes: 60,
    })
  );

  const contactId = response.ContactId;
  if (!contactId) {
    throw new Error("StartChatContact response did not contain a ContactId");
  }

  return {
    contactId,
    contactArn: buildContactArn(instanceId, contactId),
  };
}

/**
 * Stops a previously minted contact. Best-effort: failures are logged and
 * swallowed so contact teardown never fails the test (the contact will also
 * auto-expire via ChatDurationInMinutes).
 *
 * @param instanceId - The Connect instance ID
 * @param contactId - The contact ID to stop
 */
export async function stopContact(
  instanceId: string,
  contactId: string
): Promise<void> {
  try {
    const client = getConnectClient();
    await client.send(
      new StopContactCommand({ InstanceId: instanceId, ContactId: contactId })
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.warn(
      `[contact-manager] StopContact failed for ${contactId} (non-fatal): ${message}`
    );
  }
}
