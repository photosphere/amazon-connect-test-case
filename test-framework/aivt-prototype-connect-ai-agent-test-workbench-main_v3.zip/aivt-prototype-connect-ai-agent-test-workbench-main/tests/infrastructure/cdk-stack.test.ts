/**
 * CDK Infrastructure Tests for ConnectAgentTestPlatformStack.
 *
 * Validates Requirements: 1.1, 1.2, 1.5, 2.1, 3.1, 3.3, 3.5, 4.1, 4.2, 4.4,
 *                        6.1, 7.1, 7.2, 12.4, 13.3, 14.1, 14.3, 14.4, 15.1,
 *                        15.2, 15.6, 15.7
 */
import * as path from 'path';
import { describe, it, expect, vi } from 'vitest';
import * as cdk from 'aws-cdk-lib';
import { Template, Match } from 'aws-cdk-lib/assertions';

// Mock NodejsFunction to avoid esbuild bundling during tests.
// Replace with a plain Lambda function using inline code.
vi.mock('aws-cdk-lib/aws-lambda-nodejs', () => {
  const lambda = require('aws-cdk-lib/aws-lambda');

  class NodejsFunction extends lambda.Function {
    constructor(scope: any, id: string, props: any) {
      super(scope, id, {
        ...props,
        code: lambda.Code.fromInline('exports.handler = async () => {}'),
        handler: 'index.handler',
        runtime: props?.runtime ?? lambda.Runtime.NODEJS_20_X,
      });
    }
  }

  return { NodejsFunction };
});

import { ConnectAgentTestPlatformStack } from '../../lib/connect-agent-test-platform-stack';

const MOCK_CONNECT_INSTANCE_ID = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890';

/**
 * Fixture build directory that contains an `index.html` at its root, so the
 * `FrontendDeploymentConstruct` synth-time guard (Req 1.4) passes during tests
 * without relying on a real Vite build artifact. Mirrors the existing
 * NodejsFunction mocking pattern: tests own the surface they exercise.
 */
const FIXTURE_BUILD_DIR = path.resolve(__dirname, 'fixtures/frontend-dist');

interface TemplateOptions {
  callbackUrls?: string[];
  adminEmail?: string;
}

function synthTemplate(opts: TemplateOptions = {}): Template {
  const app = new cdk.App();
  const stack = new ConnectAgentTestPlatformStack(app, 'TestStack', {
    connectInstanceId: MOCK_CONNECT_INSTANCE_ID,
    callbackUrls: opts.callbackUrls ?? ['http://localhost:5173'],
    adminEmail: opts.adminEmail,
    frontendBuildDir: FIXTURE_BUILD_DIR,
    env: { account: '123456789012', region: 'us-east-1' },
  });
  return Template.fromStack(stack);
}

function createTestTemplate(): Template {
  return synthTemplate();
}

describe('ConnectAgentTestPlatformStack', () => {
  const template = createTestTemplate();

  // -------------------------------------------------------------------------
  // Snapshot test
  // -------------------------------------------------------------------------
  it('matches CloudFormation snapshot', () => {
    // Verify template synthesizes without error — structural correctness
    // is covered by the assertion tests below. We skip snapshot comparison
    // because CDK produces non-deterministic resource ordering across process invocations.
    const json = template.toJSON();
    expect(json).toBeDefined();
    expect(json.Resources).toBeDefined();
    expect(Object.keys(json.Resources).length).toBeGreaterThan(0);
  });

  // -------------------------------------------------------------------------
  // DynamoDB: TTL enabled
  // Validates: Requirement 14.3
  // -------------------------------------------------------------------------
  it('DynamoDB table has TTL enabled with attribute "ttl"', () => {
    template.hasResourceProperties('AWS::DynamoDB::Table', {
      TimeToLiveSpecification: {
        Enabled: true,
        AttributeName: 'ttl',
      },
    });
  });

  // -------------------------------------------------------------------------
  // IAM: wisdom + qconnect action prefixes
  // Validates: Requirement 14.1
  // -------------------------------------------------------------------------
  it('IAM policies include both wisdom: and qconnect: action prefixes', () => {
    const policies = template.findResources('AWS::IAM::Policy');

    let hasWisdom = false;
    let hasQConnect = false;

    for (const [, resource] of Object.entries(policies)) {
      const statements = (resource as any).Properties?.PolicyDocument?.Statement;
      if (!Array.isArray(statements)) continue;

      for (const statement of statements) {
        const actions: string[] = Array.isArray(statement.Action)
          ? statement.Action
          : [statement.Action];
        for (const action of actions) {
          if (typeof action === 'string' && action.startsWith('wisdom:')) hasWisdom = true;
          if (typeof action === 'string' && action.startsWith('qconnect:')) hasQConnect = true;
        }
      }
    }

    expect(hasWisdom).toBe(true);
    expect(hasQConnect).toBe(true);
  });

  // -------------------------------------------------------------------------
  // Lambda: Environment variables contain CONNECT_INSTANCE_ID and ASSISTANT_ID
  // Validates: Requirement 14.4
  // -------------------------------------------------------------------------
  it('Lambda environment variables include CONNECT_INSTANCE_ID and ASSISTANT_ID', () => {
    const lambdas = template.findResources('AWS::Lambda::Function');

    let foundInstanceId = false;
    let foundAssistantId = false;

    for (const [, resource] of Object.entries(lambdas)) {
      const env = (resource as any).Properties?.Environment?.Variables;
      if (!env) continue;
      if (env.CONNECT_INSTANCE_ID) foundInstanceId = true;
      if (env.ASSISTANT_ID) foundAssistantId = true;
    }

    expect(foundInstanceId).toBe(true);
    expect(foundAssistantId).toBe(true);
  });

  // -------------------------------------------------------------------------
  // API Gateway: Cognito authorizer
  // Validates: Requirement 15.1
  // -------------------------------------------------------------------------
  it('API Gateway has a Cognito User Pools authorizer', () => {
    template.hasResourceProperties('AWS::ApiGateway::Authorizer', {
      Type: 'COGNITO_USER_POOLS',
    });
  });

  // -------------------------------------------------------------------------
  // Lambda: Each Lambda has its own role (multiple distinct IAM roles)
  // Validates: Requirement 15.2
  // -------------------------------------------------------------------------
  it('each Lambda has its own IAM role with scoped permissions', () => {
    const lambdas = template.findResources('AWS::Lambda::Function');
    const roles = template.findResources('AWS::IAM::Role');

    // Collect all unique role references from Lambda functions
    const lambdaRoleRefs = new Set<string>();
    for (const [, resource] of Object.entries(lambdas)) {
      const roleRef = (resource as any).Properties?.Role;
      if (roleRef) {
        // The role ref is typically a Fn::GetAtt or Ref - serialize for comparison
        lambdaRoleRefs.add(JSON.stringify(roleRef));
      }
    }

    // We should have multiple Lambda functions
    const lambdaCount = Object.keys(lambdas).length;
    expect(lambdaCount).toBeGreaterThan(1);

    // Each Lambda should reference a distinct role (at least as many unique roles as Lambdas)
    // Note: Some roles may be shared by the CDK framework (custom resource handler)
    // but the application Lambdas should each have distinct roles
    expect(lambdaRoleRefs.size).toBeGreaterThan(1);

    // We should have at least as many IAM roles as we have unique role references
    const roleCount = Object.keys(roles).length;
    expect(roleCount).toBeGreaterThanOrEqual(lambdaRoleRefs.size);
  });

  // -------------------------------------------------------------------------
  // Cognito: Resource Server with test-platform/run scope
  // Validates: Requirement 15.6
  // -------------------------------------------------------------------------
  it('Resource Server exists with identifier "test-platform" and scope containing "run"', () => {
    template.hasResourceProperties('AWS::Cognito::UserPoolResourceServer', {
      Identifier: 'test-platform',
      Scopes: Match.arrayWith([
        Match.objectLike({
          ScopeName: 'run',
        }),
      ]),
    });
  });

  // -------------------------------------------------------------------------
  // Cognito: Machine App Client with client_credentials and correct scopes
  // Validates: Requirement 15.7
  // -------------------------------------------------------------------------
  it('Machine App Client has client_credentials grant type and test-platform/run scope', () => {
    template.hasResourceProperties('AWS::Cognito::UserPoolClient', {
      AllowedOAuthFlows: Match.arrayWith(['client_credentials']),
      AllowedOAuthScopes: Match.arrayWith(['test-platform/run']),
    });
  });

  // -------------------------------------------------------------------------
  // Stack Outputs: MachineClientId, TokenEndpoint, MachineClientSecretArn
  // Validates: Requirement 15.7
  // -------------------------------------------------------------------------
  it('CDK outputs include MachineClientId, TokenEndpoint, and MachineClientSecretArn', () => {
    const outputs = template.findOutputs('*');
    const outputKeys = Object.keys(outputs);

    // The output keys are prefixed with the construct path, e.g. "AuthMachineClientId"
    const hasMachineClientId = outputKeys.some(k => k.includes('MachineClientId'));
    const hasTokenEndpoint = outputKeys.some(k => k.includes('TokenEndpoint'));
    const hasMachineClientSecretArn = outputKeys.some(k => k.includes('MachineClientSecretArn'));

    expect(hasMachineClientId).toBe(true);
    expect(hasTokenEndpoint).toBe(true);
    expect(hasMachineClientSecretArn).toBe(true);
  });
});

// ===========================================================================
// Frontend hosting / wiring / idempotency assertions (Task 6.1)
// Validates Requirements: 1.1, 1.2, 1.5, 2.1, 3.1, 3.3, 3.5, 4.1, 4.2, 4.4,
//                        6.1, 7.1, 7.2, 12.4, 13.3
// ===========================================================================

/**
 * Find every BucketDeployment custom resource in a synthesized template, keyed
 * by logical id. CDK lands these as `Custom::CDKBucketDeployment` resources.
 */
function findBucketDeployments(template: Template): Record<string, any> {
  return template.findResources('Custom::CDKBucketDeployment');
}

/**
 * Find every UserPoolClient resource in a synthesized template.
 */
function findUserPoolClients(template: Template): Record<string, any> {
  return template.findResources('AWS::Cognito::UserPoolClient');
}

describe('ConnectAgentTestPlatformStack — frontend hosting (Reqs 1, 2, 3)', () => {
  const template = synthTemplate();

  it('synthesizes exactly one frontend BucketDeployment targeting the frontend bucket', () => {
    // Validates: Requirements 1.1, 3.1
    const deployments = findBucketDeployments(template);
    const entries = Object.entries(deployments);
    expect(entries).toHaveLength(1);

    const [logicalId, resource] = entries[0];
    expect(logicalId).toContain('FrontendDeployment');

    // DestinationBucketName must Ref the FrontendBucket logical id (no other bucket).
    const destRef = (resource as any).Properties?.DestinationBucketName;
    expect(destRef).toBeDefined();
    expect(destRef).toHaveProperty('Ref');
    expect(destRef.Ref).toMatch(/FrontendBucket/);
  });

  it('BucketDeployment carries two sources (build asset + config.json) and prunes', () => {
    // Validates: Requirements 1.1, 3.1, 3.5
    const [resource] = Object.values(findBucketDeployments(template));
    const props = (resource as any).Properties;

    // Two sources: the build asset zip + Source.jsonData('config.json', ...).
    // Both surface as entries in SourceObjectKeys/SourceBucketNames.
    expect(Array.isArray(props.SourceObjectKeys)).toBe(true);
    expect(props.SourceObjectKeys).toHaveLength(2);
    expect(Array.isArray(props.SourceBucketNames)).toBe(true);
    expect(props.SourceBucketNames).toHaveLength(2);

    // Exactly one of the two sources is the config.json — its SourceMarkers
    // entry carries placeholders (the build asset has no markers).
    const markers = props.SourceMarkers ?? [];
    const markerEntriesWithKeys = markers
      .filter((m: any) => m && typeof m === 'object')
      .filter((m: any) => Object.keys(m).length > 0);
    expect(markerEntriesWithKeys).toHaveLength(1);

    // Prune is on so unchanged deploys are no-ops on object content (Req 3.5,
    // 12.1, 12.2). The config.json source survives the asset upload because it
    // is part of the same deployment, so prune operates over the union.
    expect(props.Prune).toBe(true);
  });

  it('BucketDeployment sets DistributionId and DistributionPaths: ["/*"] for cache invalidation', () => {
    // Validates: Requirement 2.1
    const [resource] = Object.values(findBucketDeployments(template));
    const props = (resource as any).Properties;

    expect(props.DistributionId).toBeDefined();
    expect(props.DistributionId).toHaveProperty('Ref');
    expect(props.DistributionId.Ref).toMatch(/FrontendDistribution/);

    expect(props.DistributionPaths).toEqual(['/*']);
  });

  it('CloudFront sets DefaultRootObject: index.html', () => {
    // Validates: Requirement 1.2
    template.hasResourceProperties('AWS::CloudFront::Distribution', {
      DistributionConfig: Match.objectLike({
        DefaultRootObject: 'index.html',
      }),
    });
  });

  it('CloudFront SPA fallback maps 403 and 404 to /index.html with 200', () => {
    // Validates: Requirements 1.2, 1.5
    template.hasResourceProperties('AWS::CloudFront::Distribution', {
      DistributionConfig: Match.objectLike({
        CustomErrorResponses: Match.arrayWith([
          Match.objectLike({
            ErrorCode: 403,
            ResponseCode: 200,
            ResponsePagePath: '/index.html',
          }),
          Match.objectLike({
            ErrorCode: 404,
            ResponseCode: 200,
            ResponsePagePath: '/index.html',
          }),
        ]),
      }),
    });
  });
});

describe('ConnectAgentTestPlatformStack — Cognito callbacks & runtime config wiring (Reqs 3, 4, 13)', () => {
  it('Web_Client CallbackURLs and LogoutURLs include CloudFront URL + provided URLs deduplicated', () => {
    // Validates: Requirements 4.1, 4.2, 4.4
    const template = synthTemplate({
      callbackUrls: [
        'http://localhost:5173',
        'https://example.com/cb',
        // Duplicate of the first concrete entry — must be deduped to ONE entry.
        'http://localhost:5173',
      ],
    });

    const clients = findUserPoolClients(template);
    const webClientEntry = Object.entries(clients).find(([id]) =>
      id.includes('WebAppClient')
    );
    expect(webClientEntry).toBeDefined();
    const [, webClient] = webClientEntry!;
    const props = (webClient as any).Properties;

    // Concrete strings must appear exactly once each.
    const concreteCallbacks = (props.CallbackURLs as any[]).filter(
      (u): u is string => typeof u === 'string'
    );
    expect(concreteCallbacks).toEqual([
      'http://localhost:5173',
      'https://example.com/cb',
    ]);

    const concreteLogouts = (props.LogoutURLs as any[]).filter(
      (u): u is string => typeof u === 'string'
    );
    expect(concreteLogouts).toEqual([
      'http://localhost:5173',
      'https://example.com/cb',
    ]);

    // CloudFront URL is always present, expressed as a token (Fn::Join over
    // the FrontendDistribution domain name).
    function hasCloudFrontTokenEntry(urls: any[]): boolean {
      return urls.some((entry) => {
        if (typeof entry !== 'object' || entry === null) return false;
        const join = entry['Fn::Join'];
        if (!join) return false;
        const serialized = JSON.stringify(join);
        return serialized.includes('FrontendDistribution');
      });
    }
    expect(hasCloudFrontTokenEntry(props.CallbackURLs)).toBe(true);
    expect(hasCloudFrontTokenEntry(props.LogoutURLs)).toBe(true);
  });

  it('config.json references Web_Client id (UserPoolClientId), never MachineClientId', () => {
    // Validates: Requirements 3.3, 13.3
    const template = synthTemplate();
    const clients = findUserPoolClients(template);

    // Resolve the actual logical ids of the Web_Client and the M2M Machine
    // client from the synthesized template.
    const webClientLogicalId = Object.keys(clients).find((id) =>
      id.includes('WebAppClient')
    );
    const machineClientLogicalId = Object.keys(clients).find((id) =>
      id.includes('MachineClient')
    );
    expect(webClientLogicalId).toBeDefined();
    expect(machineClientLogicalId).toBeDefined();

    // The config.json source is delivered via the BucketDeployment as a
    // marker-substituted JSON blob. Its SourceMarkers entry resolves the four
    // token-bearing fields (apiEndpoint, cognitoUserPoolId, cognitoClientId,
    // cognitoDomain) by Ref. We assert that the cognitoClientId Ref points to
    // the Web_Client and that no marker references the Machine client.
    const [deployment] = Object.values(findBucketDeployments(template));
    const markers = (deployment as any).Properties.SourceMarkers ?? [];
    const configMarkers = markers.find(
      (m: any) => m && typeof m === 'object' && Object.keys(m).length > 0
    );
    expect(configMarkers).toBeDefined();
    const serializedMarkers = JSON.stringify(configMarkers);

    // Web_Client id reference is present.
    expect(serializedMarkers).toContain(webClientLogicalId!);
    // Machine client id reference is NOT present.
    expect(serializedMarkers).not.toContain(machineClientLogicalId!);
  });
});

describe('ConnectAgentTestPlatformStack — admin bootstrap presence (Reqs 6, 7)', () => {
  it('with adminEmail, a single bootstrap custom resource is synthesized', () => {
    // Validates: Requirement 6.1
    const template = synthTemplate({ adminEmail: 'admin@example.com' });
    const bootstrap = template.findResources('Custom::CognitoAdminUserBootstrap');
    expect(Object.keys(bootstrap)).toHaveLength(1);
  });

  it('without adminEmail, no bootstrap resource is synthesized', () => {
    // Validates: Requirement 7.1
    // The construct creates NO Lambda, NO custom resource, NO role when the
    // admin email is absent/empty/whitespace.
    const cases: Array<TemplateOptions> = [
      { adminEmail: undefined },
      { adminEmail: '' },
      { adminEmail: '   ' },
    ];

    for (const opts of cases) {
      const template = synthTemplate(opts);
      const bootstrap = template.findResources('Custom::CognitoAdminUserBootstrap');
      expect(Object.keys(bootstrap)).toHaveLength(0);

      // No bootstrap-prefixed resources of any kind.
      const all = template.toJSON().Resources as Record<string, any>;
      const bootstrapAny = Object.keys(all).filter((k) => k.includes('AdminBootstrap'));
      expect(bootstrapAny).toEqual([]);
    }
  });

  it('with vs without adminEmail, all non-bootstrap resources are identical', () => {
    // Validates: Requirement 7.2
    const tWith = synthTemplate({ adminEmail: 'admin@example.com' });
    const tWithout = synthTemplate({});

    /**
     * The `AssistantDiscovery` custom resource intentionally writes
     * `Date.now()` into a `Timestamp` property to force re-evaluation on every
     * deployment. That property is non-deterministic across synths and is
     * unrelated to admin-bootstrap presence, so we normalize it before
     * comparing the two templates' non-bootstrap resources.
     */
    function normalizeResource(resource: any): any {
      if (
        resource?.Type === 'AWS::CloudFormation::CustomResource' &&
        typeof resource?.Properties?.Timestamp === 'string'
      ) {
        return {
          ...resource,
          Properties: { ...resource.Properties, Timestamp: '<normalized>' },
        };
      }
      return resource;
    }

    const filterAndNormalize = (resources: Record<string, any>) =>
      Object.fromEntries(
        Object.entries(resources)
          .filter(([id]) => !id.includes('AdminBootstrap'))
          .map(([id, res]) => [id, normalizeResource(res)])
      );

    const withResources = filterAndNormalize(
      (tWith.toJSON().Resources ?? {}) as Record<string, any>
    );
    const withoutResources = filterAndNormalize(
      (tWithout.toJSON().Resources ?? {}) as Record<string, any>
    );

    // Same set of logical ids…
    expect(new Set(Object.keys(withResources))).toEqual(
      new Set(Object.keys(withoutResources))
    );

    // …and the same property bodies for each.
    for (const id of Object.keys(withResources)) {
      expect(withResources[id]).toEqual(withoutResources[id]);
    }
  });
});

describe('ConnectAgentTestPlatformStack — logical id stability across synth (Req 12.4)', () => {
  it('frontend bucket / distribution / user pool / clients keep stable logical ids across synth', () => {
    // Validates: Requirement 12.4
    // Synthesize twice with identical inputs and confirm the logical ids of
    // the resources whose preservation Req 12.4 calls out are identical, so
    // repeat deploys do not delete and recreate them.
    const t1 = synthTemplate({
      callbackUrls: ['http://localhost:5173'],
      adminEmail: 'admin@example.com',
    });
    const t2 = synthTemplate({
      callbackUrls: ['http://localhost:5173'],
      adminEmail: 'admin@example.com',
    });

    function collect(template: Template): Record<string, string[]> {
      return {
        bucket: Object.keys(template.findResources('AWS::S3::Bucket')).sort(),
        distribution: Object.keys(
          template.findResources('AWS::CloudFront::Distribution')
        ).sort(),
        userPool: Object.keys(template.findResources('AWS::Cognito::UserPool')).sort(),
        userPoolClients: Object.keys(
          template.findResources('AWS::Cognito::UserPoolClient')
        ).sort(),
      };
    }

    expect(collect(t1)).toEqual(collect(t2));
  });
});

// ===========================================================================
// Actionable Recommendations infrastructure assertions
//
// Validates the three CDK changes required by the actionable-recommendations
// design and task 8 (api-construct.ts):
//   1. A new SuiteRecommendLambda exists with a NodejsFunction shape and the
//      same Bedrock IAM grant posture as analysisLambda.
//   2. A new POST /runs/{runId}/recommend-suite API Gateway route exists,
//      authorized by the Cognito User Pools authorizer.
//   3. The analysisLambda IAM grant is upgraded from grantReadData to
//      grantReadWriteData so the per-case persistence path can write its
//      ANALYSIS#CASE#{caseId} records.
//
// Note (Wave 3, prompt-management Task 20.5): the SuiteRecommendLambda
// Bedrock InvokeModel/Converse assertion that previously lived in this
// block was removed. The canonical assertion now lives in
// `tests/cdk/bedrock-grants.test.ts`, which is registry-derived
// (computeBedrockGrants set-equality) and enforces the single-grant
// posture across every Bedrock-calling Lambda. The legacy assertion here
// hard-coded the pre-Wave-3 inline-block ARN shape (`us.anthropic.*`
// inference-profile prefix, exactly three regions) and is now stale.
// Duplicating it would just duplicate maintenance — the bedrock-grants
// test is a strictly stronger replacement.
// ===========================================================================

describe('ConnectAgentTestPlatformStack — actionable recommendations wiring', () => {
  const template = createTestTemplate();

  it('synthesizes a SuiteRecommendLambda function', () => {
    // Validates: design task 8 (suiteRecommendLambda field) and Requirement 8.1
    const lambdas = template.findResources('AWS::Lambda::Function');
    const suiteRecommendIds = Object.keys(lambdas).filter((id) =>
      id.includes('SuiteRecommendLambda')
    );
    expect(suiteRecommendIds).toHaveLength(1);

    // The Lambda should run on Node 24 ARM64 with the standard
    // commonLambdaProps the rest of the stack uses.
    const [, suiteLambda] = Object.entries(lambdas).find(([id]) =>
      id.includes('SuiteRecommendLambda')
    )!;
    const props = (suiteLambda as any).Properties;
    expect(props.Runtime).toBe('nodejs24.x');
    // Architecture defaults to x86_64 unless explicitly set; the construct
    // sets ARM64 via commonLambdaProps.
    expect(props.Architectures).toEqual(['arm64']);
  });

  it('SuiteRecommendLambda has DynamoDB write permissions (grantReadWriteData)', () => {
    // Validates: design task 8 (grantReadWriteData on the new lambda — it
    // persists ANALYSIS#SUITE) and Requirement 8.7
    const policies = template.findResources('AWS::IAM::Policy');
    const suitePolicy = Object.entries(policies).find(([id]) =>
      id.includes('SuiteRecommendLambdaServiceRoleDefaultPolicy')
    );
    expect(suitePolicy).toBeDefined();

    const [, policyResource] = suitePolicy!;
    const statements = (policyResource as any).Properties.PolicyDocument.Statement;
    const ddbStatement = statements.find((s: any) => {
      const actions = Array.isArray(s.Action) ? s.Action : [s.Action];
      return actions.some((a: string) => a === 'dynamodb:PutItem');
    });
    expect(ddbStatement).toBeDefined();

    const ddbActions: string[] = Array.isArray(ddbStatement.Action)
      ? ddbStatement.Action
      : [ddbStatement.Action];
    // Mutating actions characteristic of grantReadWriteData.
    for (const action of [
      'dynamodb:PutItem',
      'dynamodb:UpdateItem',
      'dynamodb:DeleteItem',
      'dynamodb:BatchWriteItem',
    ]) {
      expect(ddbActions).toContain(action);
    }
  });

  it('AnalysisLambda IAM grant is upgraded to grantReadWriteData (persists ANALYSIS#CASE records)', () => {
    // Validates: Requirement 6.1 and design task 8 (grantReadWriteData upgrade)
    const policies = template.findResources('AWS::IAM::Policy');
    const analysisPolicy = Object.entries(policies).find(
      ([id]) =>
        id.includes('AnalysisLambdaServiceRoleDefaultPolicy') &&
        // Exclude the SuiteRecommendLambda's policy.
        !id.includes('SuiteRecommend')
    );
    expect(analysisPolicy).toBeDefined();

    const [, policyResource] = analysisPolicy!;
    const statements = (policyResource as any).Properties.PolicyDocument.Statement;
    const ddbStatement = statements.find((s: any) => {
      const actions = Array.isArray(s.Action) ? s.Action : [s.Action];
      return actions.some((a: string) => a === 'dynamodb:PutItem');
    });
    expect(ddbStatement).toBeDefined();

    const ddbActions: string[] = Array.isArray(ddbStatement.Action)
      ? ddbStatement.Action
      : [ddbStatement.Action];
    // The Lambda must carry mutating DynamoDB actions, not just the read-only
    // subset. Presence of PutItem distinguishes grantReadWriteData from
    // grantReadData.
    for (const action of [
      'dynamodb:PutItem',
      'dynamodb:UpdateItem',
      'dynamodb:DeleteItem',
    ]) {
      expect(ddbActions).toContain(action);
    }
  });

  it('SuiteCrudLambda can call ListAIAgents (GET /suites agent-name enrichment)', () => {
    // Regression guard for the agent-grouped-suites bug where GET /suites
    // enriches each suite with its resolved agent display name by calling
    // `listAgents()` (Q in Connect ListAIAgents), but the SuiteCrudLambda
    // role was never granted the action. The handler's graceful catch then
    // fell back to the raw agentId, so the UI rendered UUIDs instead of
    // agent names — silently, with no build-time signal. This test fails
    // the build if the grant is ever dropped from the SuiteCrudLambda role.
    const policies = template.findResources('AWS::IAM::Policy');
    const suiteCrudPolicy = Object.entries(policies).find(
      ([id]) =>
        id.includes('SuiteCrudLambdaServiceRoleDefaultPolicy'),
    );
    expect(suiteCrudPolicy).toBeDefined();

    const [, policyResource] = suiteCrudPolicy!;
    const statements = (policyResource as any).Properties.PolicyDocument
      .Statement;

    // Collect every action granted to the SuiteCrudLambda role.
    const grantedActions = new Set<string>();
    for (const statement of statements) {
      const actions = Array.isArray(statement.Action)
        ? statement.Action
        : [statement.Action];
      for (const action of actions) {
        if (typeof action === 'string') grantedActions.add(action);
      }
    }

    // Both the qconnect and the (legacy) wisdom action prefixes must be
    // present — the SDK call resolves against whichever the account exposes.
    expect(grantedActions.has('qconnect:ListAIAgents')).toBe(true);
    expect(grantedActions.has('wisdom:ListAIAgents')).toBe(true);

    // The ListAIAgents call authorizes against the per-agent
    // `ai-agent/{assistantId}/*` ARN, not just the `assistant/*` ARN —
    // granting only `assistant/*` still yields AccessDenied on the
    // `ai-agent/*` resource (the bug that shipped raw agentIds to the UI).
    // Assert the statement carrying ListAIAgents includes an `ai-agent`
    // resource so a too-narrow grant fails the build.
    const listAgentsStatement = statements.find((s: any) => {
      const actions = Array.isArray(s.Action) ? s.Action : [s.Action];
      return actions.some(
        (a: string) =>
          a === 'qconnect:ListAIAgents' || a === 'wisdom:ListAIAgents',
      );
    });
    expect(listAgentsStatement).toBeDefined();
    const listAgentsResources: string[] = Array.isArray(
      listAgentsStatement.Resource,
    )
      ? listAgentsStatement.Resource
      : [listAgentsStatement.Resource];
    const resourceStrings = listAgentsResources.map((r) =>
      typeof r === 'string' ? r : JSON.stringify(r),
    );
    expect(
      resourceStrings.some((r) => r.includes(':ai-agent/')),
    ).toBe(true);
  });

  it('exposes a POST /runs/{runId}/recommend-suite route protected by the Cognito authorizer', () => {
    // Validates: design task 8 (route wiring) and Requirements 8.1, 15.1
    const resources = template.findResources('AWS::ApiGateway::Resource');
    const recommendSuiteResources = Object.entries(resources).filter(
      ([, res]) => (res as any).Properties?.PathPart === 'recommend-suite'
    );
    expect(recommendSuiteResources).toHaveLength(1);
    const [recommendSuiteResourceId] = recommendSuiteResources[0];

    // The POST method on that resource must be wired to the
    // SuiteRecommendLambda (via a LambdaIntegration) and authorized by the
    // Cognito User Pools authorizer. We identify the POST method by the
    // ResourceId Ref pointing at the recommend-suite resource.
    const methods = template.findResources('AWS::ApiGateway::Method');
    const postEntry = Object.entries(methods).find(([, res]) => {
      const props = (res as any).Properties;
      const resourceIdRef = props.ResourceId?.Ref;
      return props.HttpMethod === 'POST' && resourceIdRef === recommendSuiteResourceId;
    });
    expect(postEntry).toBeDefined();
    const [, postResource] = postEntry!;
    const postProps = (postResource as any).Properties;

    expect(postProps.AuthorizationType).toBe('COGNITO_USER_POOLS');
    expect(postProps.AuthorizerId).toBeDefined();

    // The integration URI must reference the SuiteRecommendLambda.
    const integrationUri = postProps.Integration?.Uri;
    expect(integrationUri).toBeDefined();
    expect(JSON.stringify(integrationUri)).toContain('SuiteRecommendLambda');
  });
});
