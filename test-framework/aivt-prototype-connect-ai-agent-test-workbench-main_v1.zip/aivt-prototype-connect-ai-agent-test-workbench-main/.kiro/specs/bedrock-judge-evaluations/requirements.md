# Requirements Document

## Introduction

This feature replaces the previously specified AgentCore Evaluate (`bedrock-agentcore:Evaluate`) integration with a direct **Amazon Bedrock Converse** integration that uses the AWS-published built-in evaluator prompt templates (`Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, `Builtin.ToolSelectionAccuracy`) as its scoring rubric. Empirical validation against this account confirmed that AgentCore Evaluate cannot be driven from Q in Connect ListSpans output: every shape we attempted (9 wire variants in the dev account) returned `LogEventMissingException` because Evaluate requires records produced by the AgentCore Runtime + ADOT ingestion pipeline that this platform does not use, and CloudWatch Transaction Search is not enabled in the account. The pivot keeps every observable contract identical — same three score fields per `TestCaseResult`, same `[0.0, 1.0]` range, same `Evaluation_Error_State` semantics, same DynamoDB persistence shape, same UI surfaces — and changes only the scoring backend and the modules that call it.

The scope of this feature is the evaluation backend (Workstream 2 of the previous spec). The frontend hosting, runtime config, Cognito callback, admin-user-bootstrap, idempotent-deploy, frontend-bundle-secret-hygiene, and score-aware run-comparison requirements (Workstream 1 of the previous spec, plus the run-comparison requirement) are owned by their respective specs and are unchanged here.

### What carries over from `platform-hosting-and-evaluations`

The `Evaluation_Error_State` semantics (no silent local fallback), the local Evaluation_Harness, the least-privilege credential posture for the harness, and the requirement that real captured spans validate the integration carry over verbatim, with terminology updated from AgentCore-specific terms to Bedrock-judge terms.

### What is replaced

- The AgentCore Evaluations submission requirement is replaced by a Bedrock Converse-based judge integration.
- The Execution_Trace-to-OTel translation requirement is replaced by a Judge_Prompt_Context rendering requirement.
- The "translated session conforms to AgentCore input schema" validation against `Span_Fixtures` is replaced by Golden_Prompt_Snapshot conformance against the same fixtures.

### What is new

Requirements for the Prompt_Template_Steering_Doc, the Bedrock_Judge_Client, the Score_Scale tables, the configurable Judge_Model, and the per-case parallelism / latency / cost bounds.

### Non-Goals

- Reusing any of the AgentCore Evaluate API surface.
- Custom evaluators (the AgentCore `Custom_Evaluator` / Lambda-as-judge flow). Only the three AWS-published built-in templates are used.
- Multi-judge ensembles or judge-model A/B testing.
- Per-case selection of the Judge_Model. The Judge_Model is a deploy-time configuration, not a per-case parameter.
- Online (streaming) evaluation. Evaluation runs after a `Test_Run` completes.
- Reproducing AgentCore's exact rounding, calibration, or label thresholding.

## Glossary

- **Platform**: The Connect Agent Test Platform — the deployed serverless web application this feature extends.
- **Q_in_Connect**: Amazon Q in Connect, the session-based assistant service whose APIs (CreateSession, SendMessage, GetNextMessage, ListSpans) drive test conversations against AI agents.
- **ORCHESTRATION_Agent**: A Q in Connect AI Agent of type ORCHESTRATION, configured with tools and a system prompt, that the Platform tests.
- **ListSpans**: The Q in Connect API that returns a session's ordered spans, including `execute_tool` spans, used to derive the authoritative tool sequence and reasoning steps.
- **Execution_Trace**: The structured, ordered record of agent reasoning and tool calls (with arguments, results, and success/error status) produced by `parseSpansToTrace` from ListSpans output and persisted in DynamoDB under SK="TRACE".
- **Transcript**: The ordered sequence of conversation turns (customer and agent messages plus tool selections) recorded for a single test case execution.
- **AgentSnapshot**: The captured agent configuration for a test case, including the available tools (each with name, description, and input schema).
- **Test_Run**: An execution of a Test Suite, identified by a run id and a timestamp and associated with its suite id, against which results and scores are recorded.
- **TestCaseResult**: The DynamoDB-persisted record for a single test case within a run (PK=`RUN#{runId}`, SK=`CASE#{caseId}`), including the score fields `goalSuccessScore`, `helpfulnessScore`, `toolAccuracyScore` (each a decimal in `[0.0, 1.0]`) and an optional `evaluationError`.
- **Evaluation_Lambda**: The backend Lambda (`src/backend/orchestration/evaluation.ts`) invoked in the EvaluateResults step of the state machine, which scores each test case result.
- **Bedrock_Judge**: The Bedrock Converse-based scoring backend that replaces AgentCore Evaluate. The Bedrock_Judge invokes the Judge_Model with a Prompt_Template and a Judge_Prompt_Context to produce a `{ reasoning, score }` JSON response per evaluator unit.
- **Bedrock_Judge_Client**: The thin SDK seam (`src/backend/orchestration/bedrock-judge-client.ts`) over `@aws-sdk/client-bedrock-runtime` `ConverseCommand` that calls the Bedrock_Judge for a single evaluator unit.
- **Judge_Model**: The Bedrock foundation model invoked by the Bedrock_Judge_Client, identified by an inference-profile id or a foundation-model id. The platform default is the same Anthropic Claude model used by the analysis and scaffold Lambdas (currently `us.anthropic.claude-sonnet-4-6`) so that reasoning-quality is consistent across the platform.
- **Judge_Model_Id**: The configured Bedrock model id (default `us.anthropic.claude-sonnet-4-6`) used by the Bedrock_Judge_Client. Sourced from the `JUDGE_MODEL_ID` Lambda environment variable, which the CDK stack populates from the `judgeModelId` CDK context key (defaulting when the context key is absent).
- **Judge_Model_Routing_Regions**: The set of AWS regions a cross-region inference profile may route a Converse call to. For an inference-profile id whose prefix is `us.` the routing region set is `{us-east-1, us-east-2, us-west-2}`; for `eu.` it is `{eu-central-1, eu-west-1, eu-west-3, eu-north-1}`; for `apac.` it is `{ap-northeast-1, ap-northeast-2, ap-south-1, ap-southeast-1, ap-southeast-2}`. For a foundation-model id (no profile prefix), the set is the single region the model is invoked in. The set is derived deterministically at synth time from `judgeModelId` and is the basis for the IAM grants in Requirement 6.
- **Prompt_Template**: One of the three AWS-published built-in evaluator templates (`Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, `Builtin.ToolSelectionAccuracy`) used as the scoring rubric.
- **Prompt_Template_Steering_Doc**: The committed file `.kiro/steering/bedrock-judge-prompts.md` containing verbatim copies of the three Prompt_Templates plus the Score_Scale mapping tables. The single source of truth for prompts and rubrics.
- **Judge_Prompt_Context**: The four rendered strings supplied to a Prompt_Template — `{context}`, `{available_tools}`, `{assistant_turn}` (per assistant turn), and `{tool_turn}` (per tool call) — derived from the Execution_Trace, Transcript, and AgentSnapshot.
- **Prompt_Rendering_Module**: The pure module `src/shared/utils/judge-prompt-rendering.ts` that produces the Judge_Prompt_Context from an Execution_Trace, Transcript, AgentSnapshot, and the test case's expected tool names. Has no AWS imports and is unit-testable without deploy.
- **Score_Scale**: A canonical mapping table from a Prompt_Template rubric label (e.g. `Yes`, `No`, `Very Helpful`) to a finite decimal in `[0.0, 1.0]`. The Score_Scales for the three evaluators are: GoalSuccessRate `{ Yes: 1.0, No: 0.0 }`; ToolSelectionAccuracy `{ Yes: 1.0, No: 0.0 }`; Helpfulness 7 levels uniformly spaced in steps of `1/6` from `Not Helpful At All` (0.0) to `Above And Beyond` (1.0).
- **Goal_Success_Score**: The `goalSuccessScore` field on a TestCaseResult — the session-level GoalSuccessRate label mapped through its Score_Scale.
- **Helpfulness_Score**: The `helpfulnessScore` field on a TestCaseResult — the unweighted arithmetic mean of per-assistant-turn Helpfulness labels mapped through their Score_Scale.
- **Tool_Accuracy_Score**: The `toolAccuracyScore` field on a TestCaseResult — the unweighted arithmetic mean of per-tool-call ToolSelectionAccuracy labels mapped through their Score_Scale.
- **Evaluation_Error_State**: The state recorded on a TestCaseResult's `evaluationError` field when scoring fails. It carries one of the codes `INSUFFICIENT_TRACE`, `TIMEOUT`, `JUDGE_ERROR`, `UNMAPPABLE_RESULT`, or `MISSING_EVALUATOR`, plus a human-readable reason string. The Platform never substitutes local scoring when the Evaluation_Error_State is set.
- **Evaluation_Harness**: The local script `scripts/evaluation-harness.ts`, run from a developer machine against a saved transcript or a real Q in Connect session id, that exercises the Bedrock_Judge integration without deploying the stack.
- **Span_Fixture**: A real ListSpans payload captured from an actual completed test session and saved as a checked-in test fixture under `tests/fixtures/spans/`. The two committed fixtures are `multi-tool-success.json` and `failure-escalation.json`.
- **Golden_Prompt_Snapshot**: A checked-in `.txt` file under `tests/fixtures/golden-prompts/` containing the byte-exact rendering of one of the four Judge_Prompt_Context strings for a specific Span_Fixture, asserted byte-equal on every test run.

## Requirements

### Requirement 1: Bedrock-Judge Evaluations Integration

**User Story:** As a tester, I want each test case scored by a Bedrock-Converse-based judge using the AWS-published built-in evaluator templates, so that runs produce managed-rubric goal-success, helpfulness, and tool-selection scores without depending on the AgentCore Evaluate ingestion pipeline.

#### Acceptance Criteria

1. WHEN the Evaluation_Lambda processes a test case result, THE Platform SHALL replace the previous `callAgentCoreEvaluation` stub with calls to the Bedrock_Judge_Client, and SHALL request exactly one `Builtin.GoalSuccessRate` evaluator unit, one `Builtin.Helpfulness` evaluator unit per assistant turn in the Execution_Trace, and one `Builtin.ToolSelectionAccuracy` evaluator unit per `execute_tool` entry in the Execution_Trace.
2. THE Platform SHALL invoke the Bedrock_Judge using only the three Prompt_Templates listed in clause 1, and SHALL NOT invoke any custom evaluator, multi-judge ensemble, or AgentCore Evaluate API as part of scoring.
3. WHEN the Bedrock_Judge returns a parseable `{ reasoning, score }` for the GoalSuccessRate unit, THE Platform SHALL map the `score` label through the GoalSuccessRate Score_Scale and store the resulting value as `goalSuccessScore` on the TestCaseResult.
4. WHEN the Bedrock_Judge returns parseable `{ reasoning, score }` results for one or more Helpfulness units, THE Platform SHALL map each `score` label through the Helpfulness Score_Scale and reduce the resulting values to `helpfulnessScore` on the TestCaseResult by unweighted arithmetic mean.
5. WHEN the Bedrock_Judge returns parseable `{ reasoning, score }` results for one or more ToolSelectionAccuracy units, THE Platform SHALL map each `score` label through the ToolSelectionAccuracy Score_Scale and reduce the resulting values to `toolAccuracyScore` on the TestCaseResult by unweighted arithmetic mean.
6. THE Platform SHALL clamp every `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` value persisted on a TestCaseResult to the inclusive range `[0.0, 1.0]`.
7. WHEN the Bedrock_Judge produces scores for a test case, THE Platform SHALL persist the mapped scores to the TestCaseResult DynamoDB item at PK=`RUN#{runId}`, SK=`CASE#{caseId}`.
8. WHEN a Test_Run completes with Bedrock_Judge scoring applied, THE Platform SHALL display the `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` for each scored test case in the results view, each shown as a numeric value in the inclusive range `[0.0, 1.0]`.
9. IF the Bedrock_Judge returns parseable results for one requested evaluator type but omits another for the same test case, THEN THE Platform SHALL persist the produced score(s), set the Evaluation_Error_State with code `MISSING_EVALUATOR` and a reason identifying the omitted evaluator, complete processing of that test case, and continue processing all remaining test cases in the Test_Run without marking the Test_Run failed.

### Requirement 2: Execution Trace Rendering Into Judge Prompt Context

**User Story:** As a tester, I want the captured Execution_Trace, Transcript, and AgentSnapshot rendered into the four prompt-context strings the AWS-published templates expect, so that the Bedrock_Judge sees the actual conversation, available tools, and per-unit utterances or tool calls in the format the rubrics were written against.

#### Acceptance Criteria

1. THE Prompt_Rendering_Module SHALL produce four kinds of strings from a single test case's Execution_Trace, Transcript, and AgentSnapshot: a session-level `{context}` string, an `{available_tools}` string, one `{assistant_turn}` string per assistant turn, and one `{tool_turn}` string per `execute_tool` entry.
2. THE Prompt_Rendering_Module SHALL preserve the chronological order of customer turns, assistant turns, and tool calls from the Execution_Trace and Transcript when emitting `{context}`, with one line per source step, formatted as `User:`, `Assistant:`, `Action:`, or `Tool:` lines as appropriate, with no source step omitted and no source step duplicated.
3. THE Prompt_Rendering_Module SHALL render `{available_tools}` as a numbered list of every tool present in the AgentSnapshot, including the tool name, its description, and its input schema for each entry.
4. WHEN the Prompt_Rendering_Module renders the `{context}` supplied to a per-unit evaluator (per-assistant-turn Helpfulness or per-tool-call ToolSelectionAccuracy), THE Prompt_Rendering_Module SHALL include only the steps that strictly precede the unit being evaluated (plus the unit itself where the Prompt_Template's instruction text requires it) and SHALL NOT include any step that occurs later in the Execution_Trace.
5. THE Prompt_Rendering_Module SHALL render `{tool_turn}` as the tool name followed by its arguments serialized as JSON in parentheses, using the tool name and arguments captured in the corresponding `execute_tool` entry of the Execution_Trace.
6. THE Prompt_Rendering_Module SHALL include the test case's expected tool names, sourced from the test case's success criteria, in the `{context}` supplied to the GoalSuccessRate and ToolSelectionAccuracy evaluators, so the rubrics can be assessed against the test case's intended behavior.
7. THE Prompt_Rendering_Module SHALL be implemented with no AWS SDK imports so that the rendering can be exercised by automated tests without a deploy or any AWS API call.
8. WHILE the Execution_Trace contains exactly zero assistant turns AND exactly zero `execute_tool` entries, the Evaluation_Lambda SHALL set the Evaluation_Error_State with code `INSUFFICIENT_TRACE` on the TestCaseResult, SHALL NOT invoke the Bedrock_Judge_Client for that test case, and SHALL NOT substitute local scoring; an Execution_Trace with at least one assistant turn OR at least one `execute_tool` entry is considered submittable and SHALL NOT trigger `INSUFFICIENT_TRACE`.

### Requirement 3: Bedrock Judge Client (Converse Seam)

**User Story:** As a developer, I want a single thin module that turns a Prompt_Template plus its variables into one Bedrock Converse call and returns a typed `{ reasoning, score }`, so that the Evaluation_Lambda and the Evaluation_Harness share one call site, one timeout policy, and one parsing policy.

#### Acceptance Criteria

1. THE Bedrock_Judge_Client SHALL expose a single public method `judge({ template, vars, timeoutMs })` that substitutes `vars` into `template`, sends one `ConverseCommand` to the Judge_Model identified by Judge_Model_Id, and returns `{ reasoning: string, score: string }` extracted from the model's fenced-JSON response (the `\`\`\`...\`\`\`` block the Prompt_Templates ask for).
2. THE Bedrock_Judge_Client SHALL use the `@aws-sdk/client-bedrock-runtime` package pinned to a fixed (exact) version and bundled with the Evaluation_Lambda.
3. THE Bedrock_Judge_Client SHALL apply a per-call timeout, defaulting to 60 seconds when `timeoutMs` is not supplied, and SHALL throw a typed `JudgeTimeoutError` if the Converse response is not received within that duration.
4. IF the model response does not contain a fenced JSON block, OR the fenced JSON cannot be parsed, OR the parsed object does not contain both a `reasoning` string field and a non-empty `score` string field, THEN the Bedrock_Judge_Client SHALL throw a typed parsing error and SHALL NOT return a synthesized or default `{ reasoning, score }`.
5. THE Bedrock_Judge_Client SHALL NOT interpret, normalize, or remap the `score` label; the raw label string SHALL be returned and Score_Scale mapping SHALL occur in the Score_Scale module.
6. THE Bedrock_Judge_Client SHALL expose a test seam (mirroring the existing `_setQConnectClient` pattern) that allows automated tests to inject a mock Bedrock runtime client without invoking AWS.

### Requirement 4: Score-Scale Mapping

**User Story:** As a tester, I want the categorical labels returned by each Prompt_Template mapped to fixed decimal values via committed lookup tables, so that the conversion from rubric label to a `[0.0, 1.0]` score is explicit, version-controlled, and auditable.

#### Acceptance Criteria

1. THE Platform SHALL implement and export the three Score_Scale lookup tables (GoalSuccessRate, Helpfulness, ToolSelectionAccuracy) from `src/shared/utils/evaluation-scoring.ts`, with values defined as: GoalSuccessRate `{ Yes: 1.0, No: 0.0 }`; ToolSelectionAccuracy `{ Yes: 1.0, No: 0.0 }`; Helpfulness `{ "Not Helpful At All": 0/6, "Very Unhelpful": 1/6, "Somewhat Unhelpful": 2/6, "Neutral/Mixed": 3/6, "Somewhat Helpful": 4/6, "Very Helpful": 5/6, "Above And Beyond": 6/6 }`.
2. THE Platform SHALL map every label defined in a Score_Scale to a finite decimal in the inclusive range `[0.0, 1.0]`.
3. WHEN a Bedrock_Judge response carries a `score` label that is present in the corresponding Score_Scale, THE Platform SHALL convert the label to its mapped decimal value and use that value as the per-unit score.
4. IF a Bedrock_Judge response carries a `score` label that is not present in the corresponding Score_Scale, THEN the Platform SHALL treat the per-unit result as unmappable, set the Evaluation_Error_State with code `UNMAPPABLE_RESULT` and a reason identifying the unrecognized label and the evaluator, and SHALL NOT silently substitute zero, the mean of the scale, or any other default.
5. THE Platform SHALL define the Score_Scale tables as explicit constants in source code (not derived at runtime from a Prompt_Template string), so that any rubric change requires a code edit and review.
6. THE Platform SHALL keep the Score_Scale tables in `evaluation-scoring.ts` in sync with the rubric labels documented in the Prompt_Template_Steering_Doc.

### Requirement 5: Prompt-Template Steering Doc as Source of Truth

**User Story:** As a code reviewer, I want the three AWS-published evaluator prompt templates committed verbatim to the repo as the single source of truth, so that prompt drift is detectable in code review and the rubric we score against is auditable.

#### Acceptance Criteria

1. THE Platform SHALL maintain a Prompt_Template_Steering_Doc at `.kiro/steering/bedrock-judge-prompts.md` that contains verbatim copies of the three Prompt_Templates (`Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, `Builtin.ToolSelectionAccuracy`).
2. THE Prompt_Template_Steering_Doc SHALL record, alongside each verbatim template, the AWS documentation URL it was copied from and the date of the copy.
3. THE Prompt_Template_Steering_Doc SHALL document the Score_Scale mapping tables (the rubric label → `[0.0, 1.0]` value lookup for each evaluator) so that the rubric and its mapping live next to each other.
4. THE Platform SHALL load the verbatim Prompt_Template strings used by the Bedrock_Judge_Client from constants that match, byte-for-byte, the templates in the Prompt_Template_Steering_Doc.
5. WHEN the Prompt_Template_Steering_Doc is updated to reflect AWS revisions to a published template, THE Platform SHALL also update any corresponding Score_Scale entry in `evaluation-scoring.ts` in the same change set if the rubric labels changed.

### Requirement 6: Configurable Judge Model

**User Story:** As a deployer, I want the Judge_Model to be configurable at deploy time without a code change so that I can pin to a different Bedrock foundation model or inference profile, and I want the IAM grant on the Evaluation_Lambda to be tightened to exactly the configured model and the regions its inference profile may route to so that the role grants no broader Bedrock access than necessary.

#### Acceptance Criteria

1. THE Platform SHALL expose a `judgeModelId` CDK context key whose value is propagated to the Evaluation_Lambda as a `JUDGE_MODEL_ID` environment variable.
2. WHEN the `judgeModelId` CDK context key is absent at deploy time, THE Platform SHALL set `JUDGE_MODEL_ID` to the default value `us.anthropic.claude-sonnet-4-6`, matching the model id used by the analysis and scaffold Lambdas elsewhere in the platform.
3. WHEN the Bedrock_Judge_Client issues a Converse call, THE Bedrock_Judge_Client SHALL set the request's `modelId` parameter to the value of the `JUDGE_MODEL_ID` environment variable read at Lambda startup.
4. THE Platform SHALL grant the Evaluation_Lambda's IAM role `bedrock:InvokeModel` and `bedrock:Converse` actions on exactly two kinds of resource ARNs derived deterministically from `judgeModelId`: (a) the inference-profile ARN `arn:aws:bedrock:{home_region}:{account}:inference-profile/{judgeModelId}` for each region in the configured Judge_Model_Routing_Regions set when `judgeModelId` is a cross-region inference-profile id, and (b) the foundation-model ARN `arn:aws:bedrock:{region}::foundation-model/{base_model_id}` for each region in the same Judge_Model_Routing_Regions set, where `base_model_id` is the underlying Anthropic foundation-model id the configured profile resolves to (or `judgeModelId` itself when `judgeModelId` is already a foundation-model id with no profile prefix).
5. THE Platform SHALL NOT grant the Evaluation_Lambda's IAM role `bedrock:InvokeModel` or `bedrock:Converse` on any resource ARN containing a wildcard segment in the model id portion (e.g. `inference-profile/us.anthropic.*` or `foundation-model/anthropic.*`); each resource ARN SHALL name exactly one model or profile id.
6. THE Platform SHALL NOT grant the Evaluation_Lambda's IAM role any `bedrock-agentcore:Evaluate` action or any other AgentCore Runtime / Evaluate permission, and SHALL NOT grant `bedrock:*` or any wildcard Bedrock action.
7. IF a deployer provides a `judgeModelId` value that is empty or whitespace-only, THEN THE Platform SHALL fail the deployment at synth with an error identifying the invalid `judgeModelId` and SHALL NOT deploy the Evaluation_Lambda with an empty `JUDGE_MODEL_ID`.
8. IF a deployer provides a `judgeModelId` whose inference-profile prefix is not one of the supported prefixes (`us.`, `eu.`, `apac.`) and is not a bare foundation-model id, THEN THE Platform SHALL fail the deployment at synth with an error naming the unrecognized `judgeModelId` and listing the supported prefixes, so that the IAM grant cannot be silently under-scoped.
9. THE Platform SHALL NOT accept a per-test-case Judge_Model override; the Judge_Model is fixed for the lifetime of a deploy.

### Requirement 7: Per-Case Parallelism, Latency, and Cost Bounds

**User Story:** As a tester, I want per-case judging to fan out concurrently with explicit latency and cost expectations documented, so that runs complete in a predictable wall-clock time and the Bedrock spend is forecastable.

#### Acceptance Criteria

1. WHEN the Evaluation_Lambda scores a single test case, THE Platform SHALL issue the `1` GoalSuccessRate Converse call, the `N` per-assistant-turn Helpfulness Converse calls (where `N` is the number of assistant turns in the Execution_Trace), and the `M` per-tool-call ToolSelectionAccuracy Converse calls (where `M` is the number of `execute_tool` entries in the Execution_Trace) concurrently rather than sequentially.
2. THE Platform SHALL apply a per-case wall-clock budget of 90 seconds for the full fan-out of `1 + N + M` Converse calls.
3. IF the per-case wall-clock budget elapses before all `1 + N + M` Converse calls complete, THEN THE Platform SHALL set the Evaluation_Error_State with code `TIMEOUT` and a reason identifying that the per-case budget was exceeded, persist any per-evaluator scores that did complete, and cancel any in-flight Converse calls for that test case.
4. THE Platform SHALL apply the per-call 60-second timeout from Requirement 3.3 in addition to the per-case 90-second budget; a single Converse call exceeding 60 seconds SHALL surface as `TIMEOUT` for that evaluator unit specifically.
5. WHEN persistent throttling (such as `ThrottlingException`) from Bedrock causes the SDK's built-in retry-with-exponential-backoff to exhaust the per-call timeout, THE Platform SHALL surface the failure as Evaluation_Error_State code `JUDGE_ERROR` with a reason identifying throttling, and SHALL NOT substitute local scoring.
6. THE Platform SHALL document, in the `bedrock-judge-evaluations` design.md and the Prompt_Template_Steering_Doc, the per-case Converse call count formula `1 + N + M` and the resulting indicative cost guidance for the default Judge_Model (on the order of `$0.03–$0.05` per case at current Bedrock pricing for typical input/output token volumes).
7. WHEN scoring a Test_Run that contains many test cases, THE Platform SHALL process test cases as the existing state-machine fan-out dictates and SHALL NOT introduce any synchronous, all-cases-in-one-Lambda-invocation execution path that would scale wall-clock time linearly with the case count within a single Lambda execution.

### Requirement 8: Evaluation Error Surfacing — No Silent Fallback

**User Story:** As a tester, I want evaluation failures surfaced as explicit errors in place of scores, so that I never mistake a degraded or substituted result for a real Bedrock_Judge evaluation.

#### Acceptance Criteria

1. IF a Bedrock_Judge_Client call exceeds its per-call timeout (Requirement 3.3) for a given evaluator unit of a test case, THEN THE Platform SHALL set the Evaluation_Error_State on that TestCaseResult with code `TIMEOUT` and a reason identifying the timed-out evaluator, and SHALL NOT substitute local scoring.
2. IF a Bedrock_Judge_Client call returns an error response (such as `ThrottlingException`, `ValidationException`, `ServiceUnavailableException`, `ModelStreamErrorException`, or an access-denied error) for a given evaluator unit of a test case, THEN THE Platform SHALL set the Evaluation_Error_State on that TestCaseResult with code `JUDGE_ERROR` and a reason carrying the error name, the failing operation, and the error message, and SHALL NOT substitute local scoring.
3. IF a Bedrock_Judge_Client call returns a response that cannot be parsed as fenced JSON or whose `score` label is not present in the corresponding Score_Scale, THEN THE Platform SHALL set the Evaluation_Error_State on that TestCaseResult with code `UNMAPPABLE_RESULT` and a reason identifying the unmappable label or parse failure, and SHALL NOT substitute local scoring.
4. WHEN one or more requested evaluator units complete successfully for a test case while one or more of the others fail (timeout, judge error, or unmappable result), THE Platform SHALL persist the produced scores on the TestCaseResult and SHALL set the Evaluation_Error_State with the most specific applicable code (or `MISSING_EVALUATOR` if the failures collectively leave a required score field unset) and a reason identifying which evaluator(s) were missing.
5. WHEN the Evaluation_Error_State is set on a TestCaseResult, THE Platform SHALL leave the score fields that could not be produced unset (no numeric value for those fields), and SHALL NOT replace them with zero, the local `calculateToolAccuracy` value, the mean of the scale, or any other default.
6. WHEN the Evaluation_Error_State is set on a TestCaseResult, THE Platform SHALL display the recorded error reason in the results view in place of the score values that could not be produced for that test case.
7. WHEN one or more test cases in a Test_Run enter the Evaluation_Error_State, THE Platform SHALL complete the Test_Run, SHALL persist a TestCaseResult for every test case, and SHALL NOT mark the Test_Run itself as failed solely because individual cases entered the Evaluation_Error_State.
8. THE Platform SHALL NOT compute or persist `toolAccuracyScore` from the local `calculateToolAccuracy` logic as a substitute for a Bedrock_Judge result in any test case's scored output.

### Requirement 9: Local Bedrock-Judge Evaluation Harness

**User Story:** As a developer, I want to run the Bedrock_Judge integration from a local script against a saved transcript or a live Q in Connect session, so that I can iterate on prompt rendering, score-scale mapping, and judge behavior without redeploying the stack for every change.

#### Acceptance Criteria

1. THE Platform SHALL provide a local Evaluation_Harness script at `scripts/evaluation-harness.ts` that invokes the Bedrock_Judge integration from a developer machine without requiring a CDK deploy.
2. WHEN a developer runs the Evaluation_Harness against a saved or sample transcript file, THE Evaluation_Harness SHALL render the Judge_Prompt_Context from the transcript, invoke the Bedrock_Judge_Client for each evaluator unit, map the returned labels through the Score_Scales, and print the resulting `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` as the numeric values produced (including a value of exactly `0.0` when produced) without treating any value in `[0.0, 1.0]` as invalid.
3. WHERE a developer supplies a Q in Connect session identifier, THE Evaluation_Harness SHALL retrieve the session's Execution_Trace via ListSpans, render the Judge_Prompt_Context, invoke the Bedrock_Judge_Client for each evaluator unit, and print the resulting `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` as the numeric values produced (including a value of exactly `0.0` when produced) without treating any value in `[0.0, 1.0]` as invalid.
4. THE Evaluation_Harness SHALL invoke the same Prompt_Rendering_Module, the same Bedrock_Judge_Client, the same Score_Scales, and the same aggregation logic as the Evaluation_Lambda, so that local results are representative of deployed behavior.
5. THE Evaluation_Harness SHALL accept its input source as a command-line argument that is either a transcript file path or a Q in Connect session identifier.
6. IF the Evaluation_Harness is invoked without a valid input source argument, THEN THE Evaluation_Harness SHALL print usage guidance and exit with a non-zero status.
7. IF the specified transcript file does not exist or cannot be parsed as a valid transcript, THEN THE Evaluation_Harness SHALL print an error message identifying the invalid input and exit with a non-zero status without invoking the Bedrock_Judge_Client.
8. IF the supplied Q in Connect session identifier cannot be resolved or ListSpans returns no Execution_Trace spans for it, THEN THE Evaluation_Harness SHALL print an error message indicating the Execution_Trace could not be retrieved and exit with a non-zero status without invoking the Bedrock_Judge_Client.
9. IF a Bedrock_Judge_Client call from the Evaluation_Harness returns an error or exceeds its per-call timeout, THEN THE Evaluation_Harness SHALL print the failure reason and exit with a non-zero status, and SHALL NOT substitute local scoring.

### Requirement 10: Least-Privilege Credentials for the Evaluation Harness

**User Story:** As a security reviewer, I want the Evaluation_Harness to run with least-privilege credentials, so that local iteration does not require broad or production-admin access.

#### Acceptance Criteria

1. THE Evaluation_Harness SHALL invoke only the AWS operations strictly required to call `bedrock:Converse` against the configured Judge_Model and to read Q in Connect session spans via ListSpans, SHALL NOT call any other AWS operation as part of its normal scoring path, and SHALL complete successfully when run under credentials scoped to only those operations.
2. THE Evaluation_Harness SHALL obtain AWS credentials from the developer's environment (such as a named profile or environment credentials).
3. THE Evaluation_Harness SHALL NOT contain embedded or hardcoded long-lived AWS credentials in source.
4. IF no AWS credentials are available in the developer's environment when the Evaluation_Harness runs, THEN THE Evaluation_Harness SHALL report that credentials are missing and exit with a non-zero status without invoking any AWS operation.
5. IF the supplied credentials are denied permission to call `bedrock:Converse` against the configured Judge_Model OR to call ListSpans, THEN THE Evaluation_Harness SHALL report which operation was denied and exit with a non-zero status, SHALL NOT silently fall back to partial or local-only scoring, and SHALL NOT retry against a different model or operation.

### Requirement 11: Golden-Prompt Snapshots Against Real Captured Spans

**User Story:** As a developer, I want the Prompt_Rendering_Module validated against real captured spans via byte-exact prompt snapshots, so that any unintended change to rendering surfaces in code review as a snapshot diff and the rubric inputs we score against are stable across changes.

#### Acceptance Criteria

1. THE Platform SHALL include at least two Span_Fixtures captured from real completed test sessions (one multi-tool success session and one failure/escalation session) as checked-in test fixtures under `tests/fixtures/spans/`.
2. THE Platform SHALL provide an automated test that, for each Span_Fixture, renders the four Judge_Prompt_Context strings (`{context}`, `{available_tools}`, the per-assistant-turn `{assistant_turn}` strings, and the per-`execute_tool` `{tool_turn}` strings) via the Prompt_Rendering_Module and asserts each rendering is byte-equal to a Golden_Prompt_Snapshot file checked in under `tests/fixtures/golden-prompts/`; the test SHALL fail when any byte-equality assertion fails.
3. WHEN the Prompt_Rendering_Module renders a Judge_Prompt_Context for a Span_Fixture, THE test SHALL assert that every `execute_tool` entry in the source Execution_Trace is represented as exactly one `{tool_turn}` rendering and every assistant turn is represented as exactly one `{assistant_turn}` rendering, with chronological order preserved.
4. WHEN the Evaluation_Harness is run against a Span_Fixture, THE Evaluation_Harness SHALL invoke the Bedrock_Judge_Client for each evaluator unit derived from the fixture and report the returned per-evaluator labels and the mapped `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore`, so a developer can confirm end-to-end processing on real data.
5. WHERE a Span_Fixture is derived from a real session, THE Platform SHALL redact or use non-production placeholder values for any sensitive customer data (for example, phone number and SSN-last-four) in the checked-in fixture and in its Golden_Prompt_Snapshots.
6. IF a Prompt_Rendering_Module change causes a Golden_Prompt_Snapshot mismatch, THEN the Platform's automated tests SHALL fail with a diff identifying the changed bytes, and the Golden_Prompt_Snapshot SHALL be updated only by an explicit checked-in change to the snapshot file.
