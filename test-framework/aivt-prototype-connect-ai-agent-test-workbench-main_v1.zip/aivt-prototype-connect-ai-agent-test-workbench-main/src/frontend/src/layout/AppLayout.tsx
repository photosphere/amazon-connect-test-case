import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import CloudscapeAppLayout from '@cloudscape-design/components/app-layout';
import SideNavigation, { SideNavigationProps } from '@cloudscape-design/components/side-navigation';
import TopNavigation from '@cloudscape-design/components/top-navigation';
import BreadcrumbGroup, { BreadcrumbGroupProps } from '@cloudscape-design/components/breadcrumb-group';
import { useAuth } from '../auth/AuthContext';
import { NotificationBar } from './NotificationBar';
import { ActiveRunsBanner } from './ActiveRunsBanner';
import { InstanceModeBadge } from '../components/ImplementRecommendations';
import { getConfig } from '../api';

interface AppLayoutProps {
  children: React.ReactNode;
}

const NAV_ITEMS: SideNavigationProps.Item[] = [
  { type: 'link', text: 'Agents', href: '/agents' },
  { type: 'link', text: 'Test Suites', href: '/suites' },
  // R13.1: the Prompts catalog sits immediately below Test Suites so the
  // sidebar order reflects the platform's primary nouns (Agents → Suites
  // → Prompts → ...) and so users discover prompt customisation right
  // next to the suites whose runs invoke those prompts.
  { type: 'link', text: 'Prompts', href: '/prompts' },
  // "Compare Runs" used to live here as a top-level entry. It's now
  // accessed from the suite-detail page's "Run History" section so
  // comparisons are always suite-scoped (cross-suite diffs aren't
  // semantically meaningful — different test cases, different agents).
];

/**
 * Builds the breadcrumb trail for the current location. Reads both the
 * pathname AND the query string so `/runs/:runId/...` routes can route
 * the parent crumb through the owning suite when `?suiteId=` is present.
 *
 * Runs do NOT have a top-level list page (they're suite-scoped per the
 * design), so the prior `{ text: 'Runs', href: '#' }` placeholder was a
 * dead-end click. We drop it: when we know the suiteId we route through
 * `Test Suites > {suite}`; when we don't (e.g. a hard-reload of a
 * `/runs/:runId/...` URL with no `?suiteId=`) we fall back to a single
 * `Run {runId}` crumb that links to the dashboard.
 */
function getBreadcrumbs(
  pathname: string,
  search: string,
): BreadcrumbGroupProps.Item[] {
  const crumbs: BreadcrumbGroupProps.Item[] = [
    { text: 'Home', href: '/agents' },
  ];

  if (pathname.startsWith('/agents')) {
    crumbs.push({ text: 'Agents', href: '/agents' });
    return crumbs;
  }

  if (pathname.startsWith('/suites')) {
    crumbs.push({ text: 'Test Suites', href: '/suites' });
    const match = pathname.match(/^\/suites\/([^/]+)/);
    if (match) {
      crumbs.push({ text: match[1], href: `/suites/${match[1]}` });
    }
    return crumbs;
  }

  if (pathname.startsWith('/runs')) {
    const runMatch = pathname.match(/^\/runs\/([^/]+)/);
    const caseMatch = pathname.match(/^\/runs\/[^/]+\/cases\/([^/]+)/);
    const experimentMatch = pathname.match(/^\/runs\/[^/]+\/experiments\/([^/]+)/);
    const suiteId = new URLSearchParams(search).get('suiteId');
    const suiteQs = suiteId
      ? `?suiteId=${encodeURIComponent(suiteId)}`
      : '';

    // Runs are suite-scoped (the Run History section embedded on the
    // suite-detail page replaces the prior top-level "Compare Runs"
    // route). When we know the owning suite, route the parent crumbs
    // through Test Suites > Runs — both the `{suiteId}` crumb and the
    // `Runs` crumb would land on the same suite-detail page (the
    // latter just scrolls to the Run History anchor), so the explicit
    // suite-id crumb is redundant and we drop it. The `Runs` label is
    // the more useful one for the user's mental model. Without a
    // suiteId hint we skip the suite/runs ancestors and link the run
    // crumb directly to the run dashboard so the trail stays
    // clickable.
    if (suiteId) {
      crumbs.push({ text: 'Test Suites', href: '/suites' });
      crumbs.push({
        text: 'Runs',
        href: `/suites/${suiteId}#run-history`,
      });
    }

    if (runMatch) {
      const runId = runMatch[1];
      crumbs.push({
        text: runId === 'new' ? 'New run' : `Run ${runId}`,
        href: `/runs/${runId}${suiteQs}`,
      });
    }

    if (caseMatch) {
      crumbs.push({
        text: `Case ${caseMatch[1]}`,
        href: `${pathname}${suiteQs}`,
      });
    }

    if (experimentMatch) {
      crumbs.push({
        text: 'Experiment Results',
        href: pathname,
      });
    }
    return crumbs;
  }

  if (pathname.startsWith('/compare')) {
    crumbs.push({ text: 'Compare', href: '/compare' });
    return crumbs;
  }

  return crumbs;
}

export function AppLayout({ children }: AppLayoutProps) {
  const [navOpen, setNavOpen] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();
  const { userEmail, signOut } = useAuth();

  const config = getConfig();
  const instanceMode = (config?.instanceMode ?? 'development') as
    | 'production'
    | 'development';

  const handleNavFollow = (event: CustomEvent<SideNavigationProps.FollowDetail>) => {
    event.preventDefault();
    navigate(event.detail.href);
  };

  const handleBreadcrumbFollow = (event: CustomEvent<BreadcrumbGroupProps.ClickDetail>) => {
    event.preventDefault();
    const href = event.detail.href;
    navigate(href);
    // React Router's navigate() only updates history; it does not scroll
    // a fragment (#anchor) into view. The "Runs" crumb routes through
    // `/suites/{id}#run-history`, so do the scroll manually after the
    // route swap. setTimeout 0 lets the destination page mount before
    // we look for the anchor element.
    const hashIndex = href.indexOf('#');
    if (hashIndex >= 0) {
      const anchorId = href.slice(hashIndex + 1);
      setTimeout(() => {
        const el = document.getElementById(anchorId);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 0);
    }
  };

  const activeHref = '/' + location.pathname.split('/')[1];

  return (
    <>
      <TopNavigation
        identity={{
          href: '/agents',
          title: 'Connect Agent Test Platform',
        }}
        utilities={[
          {
            type: 'menu-dropdown',
            text: userEmail || 'User',
            iconName: 'user-profile',
            items: [
              { id: 'signout', text: 'Sign out' },
            ],
            onItemClick: (event) => {
              if (event.detail.id === 'signout') {
                signOut();
              }
            },
          },
        ]}
      />
      <CloudscapeAppLayout
        navigation={
          <SideNavigation
            header={{ text: 'Navigation', href: '/agents' }}
            items={NAV_ITEMS}
            activeHref={activeHref}
            onFollow={handleNavFollow}
          />
        }
        navigationOpen={navOpen}
        onNavigationChange={({ detail }) => setNavOpen(detail.open)}
        breadcrumbs={
          <BreadcrumbGroup
            items={getBreadcrumbs(location.pathname, location.search)}
            onFollow={handleBreadcrumbFollow}
          />
        }
        notifications={
          <>
            <InstanceModeBadge instanceMode={instanceMode} />
            <ActiveRunsBanner />
            <NotificationBar />
          </>
        }
        content={children}
        toolsHide={true}
      />
    </>
  );
}
