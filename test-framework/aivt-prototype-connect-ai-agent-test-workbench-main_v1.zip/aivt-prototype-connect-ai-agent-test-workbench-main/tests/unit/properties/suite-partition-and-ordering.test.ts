// Feature: test-case-validity-analysis, Properties 6, 7, 8: Suite partition and ordering
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import {
  buildUserMessage,
  filterAndNormalizeSuiteRecommendations,
  sortAndDenseRankSuiteRecommendations,
  type PersistedCaseAnalysis,
} from "@backend/handlers/suite-recommend";
import {
  AgentSnapshot,
  PerSuiteRecommendation,
  RecommendationTarget,
  TestCaseTargetField,
  TestCaseResult,
} from "@shared/types";
import { CaseStatus } from "@shared/enums";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** All valid rootCauseCategory values (including test_case_defect). */
const ALL_ROOT_CAUSE_CATEGORIES = [
  "test_case_defect",
  "overlapping_tool_descriptions",
  "missing_disambiguation",
  "incorrect_tool_prioritization",
  "incomplete_tool_description",
  "system_prompt_gap",
  "missing_tool_instruction",
  "parameter_mismatch",
  "other",
] as const;

/** The five valid RecommendationTarget values. */
const VALID_TARGET_FIELDS: readonly RecommendationTarget[] = [
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
  "test_case",
];

/** Agent-targeted ToolSurface values. */
const AGENT_TARGET_FIELDS: readonly RecommendationTarget[] = [
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
];

/** The five valid TestCaseTargetField values. */
const VALID_TEST_CASE_FIELDS: readonly TestCaseTargetField[] = [
  "successCriteria",
  "initialUtterance",
  "persona",
  "customerKnowledge",
  "goalDescription",
];

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Non-empty trimmed string (suitable for IDs, text fields). */
const nonEmptyStringArb = fc
  .string({ minLength: 1, maxLength: 40 })
  .filter((s) => s.trim().length > 0);

/** Arbitrary caseId — alphanumeric-ish for realistic IDs. */
const caseIdArb = fc
  .stringOf(fc.constantFrom(...("abcdefghijklmnopqrstuvwxyz0123456789-_".split(""))), {
    minLength: 3,
    maxLength: 20,
  })
  .filter((s) => s.trim().length > 0);

/** Arbitrary rootCauseCategory. */
const rootCauseCategoryArb: fc.Arbitrary<string> = fc.constantFrom(
  ...ALL_ROOT_CAUSE_CATEGORIES,
);

/** Arbitrary valid RecommendationTarget. */
const targetFieldArb: fc.Arbitrary<RecommendationTarget> = fc.constantFrom(
  ...VALID_TARGET_FIELDS,
);

/** Arbitrary valid TestCaseTargetField. */
const testCaseFieldArb: fc.Arbitrary<TestCaseTargetField> = fc.constantFrom(
  ...VALID_TEST_CASE_FIELDS,
);

/**
 * Generate a set of unique caseIds with associated root cause categories.
 * Returns at least 1 case.
 */
const caseSetArb = fc
  .array(
    fc.record({
      caseId: caseIdArb,
      rootCauseCategory: rootCauseCategoryArb,
    }),
    { minLength: 1, maxLength: 15 },
  )
  .map((entries) => {
    // Deduplicate by caseId
    const seen = new Set<string>();
    return entries.filter((e) => {
      if (seen.has(e.caseId)) return false;
      seen.add(e.caseId);
      return true;
    });
  })
  .filter((arr) => arr.length >= 1);

/** Minimal AgentSnapshot for buildUserMessage (needs tools, systemPrompt, modelId, capturedAt). */
const minimalSnapshot: AgentSnapshot = {
  tools: [{ toolName: "testTool", toolType: "EXTERNAL", description: "A test tool", inputSchema: {}, examples: [] }],
  systemPrompt: "Test system prompt",
  modelId: "test-model-id",
  capturedAt: new Date().toISOString(),
};

// ---------------------------------------------------------------------------
// Property 6: Suite failure partition correctness
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 6.1**
 *
 * Property 6: Suite failure partition correctness
 *
 * For any set of PersistedCaseAnalysis records with various rootCauseCategory
 * values, the suite prompt partition function (buildUserMessage) places every
 * record with rootCauseCategory === "test_case_defect" in the test-case-defect
 * group and every other record in the agent-deficiency group, where the union
 * of both groups equals the input and the intersection is empty.
 */
describe("Feature: test-case-validity-analysis, Property 6: Suite failure partition correctness", () => {
  it("cases with rootCauseCategory === 'test_case_defect' appear in '## Test Case Defect Failures' section", () => {
    fc.assert(
      fc.property(caseSetArb, (caseEntries) => {
        const failedCaseIds = caseEntries.map((e) => e.caseId);
        const perCaseAnalyses = new Map<string, PersistedCaseAnalysis>();
        for (const entry of caseEntries) {
          perCaseAnalyses.set(entry.caseId, {
            caseId: entry.caseId,
            rootCauseCategory: entry.rootCauseCategory,
            explanation: "test explanation",
            traceAvailable: false,
            recommendations: [],
            generatedAt: new Date().toISOString(),
            modelId: "test-model",
          });
        }

        // Minimal failedResults (needs caseId, runId, status, toolsInvoked, turnCount, latencyMs)
        const failedResults: TestCaseResult[] = failedCaseIds.map((caseId) => ({
          runId: "run-123",
          caseId,
          status: CaseStatus.FAILED,
          toolsInvoked: [],
          turnCount: 1,
          latencyMs: 100,
        }));

        const message = buildUserMessage({
          failedCaseIds,
          snapshot: minimalSnapshot,
          failedResults,
          perCaseAnalyses,
        });

        const defectCaseIds = caseEntries
          .filter((e) => e.rootCauseCategory === "test_case_defect")
          .map((e) => e.caseId);
        const agentCaseIds = caseEntries
          .filter((e) => e.rootCauseCategory !== "test_case_defect")
          .map((e) => e.caseId);

        // If there are defect cases, the section header must appear
        if (defectCaseIds.length > 0) {
          expect(message).toContain("## Test Case Defect Failures");
          // Each defect case ID should appear after the Test Case Defect section
          for (const caseId of defectCaseIds) {
            const sectionIdx = message.indexOf("## Test Case Defect Failures");
            const caseIdIdx = message.indexOf(caseId, sectionIdx);
            expect(caseIdIdx).toBeGreaterThan(sectionIdx);
          }
        } else {
          expect(message).not.toContain("## Test Case Defect Failures");
        }

        // If there are agent-deficiency cases, that section header must appear
        if (agentCaseIds.length > 0) {
          expect(message).toContain("## Agent Deficiency Failures");
          // Each agent case ID should appear after the Agent Deficiency section
          for (const caseId of agentCaseIds) {
            const sectionIdx = message.indexOf("## Agent Deficiency Failures");
            const caseIdIdx = message.indexOf(caseId, sectionIdx);
            expect(caseIdIdx).toBeGreaterThan(sectionIdx);
          }
        } else {
          expect(message).not.toContain("## Agent Deficiency Failures");
        }
      }),
      { numRuns: 100 },
    );
  });

  it("union of both partition groups equals the input set (no cases lost or duplicated)", () => {
    fc.assert(
      fc.property(caseSetArb, (caseEntries) => {
        const failedCaseIds = caseEntries.map((e) => e.caseId);
        const perCaseAnalyses = new Map<string, PersistedCaseAnalysis>();
        for (const entry of caseEntries) {
          perCaseAnalyses.set(entry.caseId, {
            caseId: entry.caseId,
            rootCauseCategory: entry.rootCauseCategory,
            explanation: "test explanation",
            traceAvailable: false,
            recommendations: [],
            generatedAt: new Date().toISOString(),
            modelId: "test-model",
          });
        }

        const failedResults: TestCaseResult[] = failedCaseIds.map((caseId) => ({
          runId: "run-123",
          caseId,
          status: CaseStatus.FAILED,
          toolsInvoked: [],
          turnCount: 1,
          latencyMs: 100,
        }));

        const message = buildUserMessage({
          failedCaseIds,
          snapshot: minimalSnapshot,
          failedResults,
          perCaseAnalyses,
        });

        // Every caseId should appear in the message exactly in one section
        for (const caseId of failedCaseIds) {
          expect(message).toContain(caseId);
        }

        // The partition is exhaustive: count of defect + agent = total
        const defectCount = caseEntries.filter(
          (e) => e.rootCauseCategory === "test_case_defect",
        ).length;
        const agentCount = caseEntries.filter(
          (e) => e.rootCauseCategory !== "test_case_defect",
        ).length;
        expect(defectCount + agentCount).toBe(caseEntries.length);
      }),
      { numRuns: 100 },
    );
  });

  it("partition is disjoint: no case appears in both sections", () => {
    fc.assert(
      fc.property(caseSetArb, (caseEntries) => {
        const failedCaseIds = caseEntries.map((e) => e.caseId);
        const perCaseAnalyses = new Map<string, PersistedCaseAnalysis>();
        for (const entry of caseEntries) {
          perCaseAnalyses.set(entry.caseId, {
            caseId: entry.caseId,
            rootCauseCategory: entry.rootCauseCategory,
            explanation: "test explanation",
            traceAvailable: false,
            recommendations: [],
            generatedAt: new Date().toISOString(),
            modelId: "test-model",
          });
        }

        const failedResults: TestCaseResult[] = failedCaseIds.map((caseId) => ({
          runId: "run-123",
          caseId,
          status: CaseStatus.FAILED,
          toolsInvoked: [],
          turnCount: 1,
          latencyMs: 100,
        }));

        const message = buildUserMessage({
          failedCaseIds,
          snapshot: minimalSnapshot,
          failedResults,
          perCaseAnalyses,
        });

        const agentSectionIdx = message.indexOf("## Agent Deficiency Failures");
        const defectSectionIdx = message.indexOf("## Test Case Defect Failures");

        // For each test_case_defect case, verify it does NOT appear in
        // the agent deficiency section (between agentSectionIdx and defectSectionIdx)
        if (agentSectionIdx >= 0 && defectSectionIdx >= 0) {
          const defectCaseIds = caseEntries
            .filter((e) => e.rootCauseCategory === "test_case_defect")
            .map((e) => e.caseId);
          const agentCaseIds = caseEntries
            .filter((e) => e.rootCauseCategory !== "test_case_defect")
            .map((e) => e.caseId);

          // Agent section comes before defect section
          const agentSectionEnd = defectSectionIdx;
          const agentSectionContent = message.slice(agentSectionIdx, agentSectionEnd);

          for (const caseId of defectCaseIds) {
            // A defect case's formatted block should not appear in agent section
            expect(agentSectionContent).not.toContain(`### Case ${caseId}`);
          }

          // Defect section content (from defect header to end or next major section)
          const defectSectionContent = message.slice(defectSectionIdx);
          for (const caseId of agentCaseIds) {
            expect(defectSectionContent).not.toContain(`### Case ${caseId}`);
          }
        }
      }),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 7: Suite liftedCaseIds partition subset
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 6.3, 11.4**
 *
 * Property 7: Suite liftedCaseIds partition subset
 *
 * For any persisted per-suite analysis, every PerSuiteRecommendation with
 * targetField === "test_case" has predictedImpact.liftedCaseIds entries that
 * are a subset of the case IDs classified as test_case_defect. Conversely,
 * every agent-targeted recommendation has liftedCaseIds entries that are a
 * subset of the non-test_case_defect case IDs.
 */
describe("Feature: test-case-validity-analysis, Property 7: Suite liftedCaseIds partition subset", () => {
  it("test_case recs have liftedCaseIds that are a subset of testCaseDefectCaseIds after filtering", () => {
    fc.assert(
      fc.property(
        caseSetArb,
        fc.integer({ min: 1, max: 5 }),
        (caseEntries, numRecs) => {
          const failedCaseIds = new Set(caseEntries.map((e) => e.caseId));
          const testCaseDefectCaseIds = new Set(
            caseEntries
              .filter((e) => e.rootCauseCategory === "test_case_defect")
              .map((e) => e.caseId),
          );

          // Skip if no defect cases (can't make test_case recs)
          if (testCaseDefectCaseIds.size === 0) return;

          const allCaseIdsArr = [...failedCaseIds];

          // Create test_case recommendations with liftedCaseIds from mixed pool
          const candidates: PerSuiteRecommendation[] = Array.from(
            { length: numRecs },
            (_, i) => ({
              targetField: "test_case" as RecommendationTarget,
              targetName: `case-${i}`,
              currentText: "current",
              suggestedText: "suggested",
              rationale: "rationale",
              priority: i + 1,
              testCaseField: "successCriteria" as TestCaseTargetField,
              predictedImpact: {
                liftedCaseIds: allCaseIdsArr, // intentionally includes non-defect IDs
                rationale: "test",
              },
            }),
          );

          const filtered = filterAndNormalizeSuiteRecommendations(
            candidates,
            failedCaseIds,
            testCaseDefectCaseIds,
          );

          // Every surviving test_case rec's liftedCaseIds should only have defect IDs
          for (const rec of filtered) {
            if (rec.targetField === "test_case") {
              for (const id of rec.predictedImpact.liftedCaseIds) {
                expect(testCaseDefectCaseIds.has(id)).toBe(true);
              }
            }
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("agent recs have liftedCaseIds that are a subset of non-defect case IDs after filtering", () => {
    fc.assert(
      fc.property(
        caseSetArb,
        fc.integer({ min: 1, max: 5 }),
        (caseEntries, numRecs) => {
          const failedCaseIds = new Set(caseEntries.map((e) => e.caseId));
          const testCaseDefectCaseIds = new Set(
            caseEntries
              .filter((e) => e.rootCauseCategory === "test_case_defect")
              .map((e) => e.caseId),
          );
          const nonDefectCaseIds = new Set(
            caseEntries
              .filter((e) => e.rootCauseCategory !== "test_case_defect")
              .map((e) => e.caseId),
          );

          // Skip if no non-defect cases (can't make agent recs with valid liftedCaseIds)
          if (nonDefectCaseIds.size === 0) return;

          const allCaseIdsArr = [...failedCaseIds];

          // Create agent recommendations with liftedCaseIds from mixed pool
          const candidates: PerSuiteRecommendation[] = Array.from(
            { length: numRecs },
            (_, i) => ({
              targetField: "tool_description" as RecommendationTarget,
              targetName: `tool-${i}`,
              currentText: "current",
              suggestedText: "suggested",
              rationale: "rationale",
              priority: i + 1,
              predictedImpact: {
                liftedCaseIds: allCaseIdsArr, // intentionally includes defect IDs
                rationale: "test",
              },
            }),
          );

          const filtered = filterAndNormalizeSuiteRecommendations(
            candidates,
            failedCaseIds,
            testCaseDefectCaseIds,
          );

          // Every surviving agent rec's liftedCaseIds should only have non-defect IDs
          for (const rec of filtered) {
            if (rec.targetField !== "test_case") {
              for (const id of rec.predictedImpact.liftedCaseIds) {
                expect(testCaseDefectCaseIds.has(id)).toBe(false);
              }
            }
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("liftedCaseIds are always a subset of failedCaseIds regardless of target type", () => {
    fc.assert(
      fc.property(
        caseSetArb,
        fc.integer({ min: 1, max: 5 }),
        (caseEntries, numRecs) => {
          const failedCaseIds = new Set(caseEntries.map((e) => e.caseId));
          const testCaseDefectCaseIds = new Set(
            caseEntries
              .filter((e) => e.rootCauseCategory === "test_case_defect")
              .map((e) => e.caseId),
          );

          const allCaseIdsArr = [...failedCaseIds];
          // Include some invalid IDs that are NOT in failedCaseIds
          const invalidIds = ["unknown-id-1", "unknown-id-2", "fake-case-xyz"];

          const candidates: PerSuiteRecommendation[] = Array.from(
            { length: numRecs },
            (_, i) => ({
              targetField: (i % 2 === 0 ? "test_case" : "tool_description") as RecommendationTarget,
              targetName: i % 2 === 0 ? `case-${i}` : `tool-${i}`,
              currentText: "current",
              suggestedText: "suggested",
              rationale: "rationale",
              priority: i + 1,
              ...(i % 2 === 0 ? { testCaseField: "successCriteria" as TestCaseTargetField } : {}),
              predictedImpact: {
                liftedCaseIds: [...allCaseIdsArr, ...invalidIds],
                rationale: "test",
              },
            }),
          );

          const filtered = filterAndNormalizeSuiteRecommendations(
            candidates,
            failedCaseIds,
            testCaseDefectCaseIds,
          );

          for (const rec of filtered) {
            for (const id of rec.predictedImpact.liftedCaseIds) {
              expect(failedCaseIds.has(id)).toBe(true);
            }
          }
        },
      ),
      { numRuns: 100 },
    );
  });
});

// ---------------------------------------------------------------------------
// Property 8: Suite priority ordering across mixed recommendation types
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 6.4**
 *
 * Property 8: Suite priority ordering across mixed recommendation types
 *
 * For any array of PerSuiteRecommendation records (containing both agent-targeted
 * and test-case-targeted entries) after server-side sorting and renumbering, the
 * priority values are monotonically non-decreasing with array index:
 * recommendations[i].priority <= recommendations[j].priority for all i < j,
 * regardless of targetField.
 */
describe("Feature: test-case-validity-analysis, Property 8: Suite priority ordering across mixed recommendation types", () => {
  /** Generate a mixed array of suite recommendations with various target types and priorities. */
  const mixedSuiteRecsArb = fc
    .array(
      fc.record({
        targetField: targetFieldArb,
        targetName: nonEmptyStringArb,
        currentText: nonEmptyStringArb,
        suggestedText: nonEmptyStringArb,
        rationale: fc.string({ minLength: 0, maxLength: 40 }),
        priority: fc.integer({ min: 1, max: 20 }),
        testCaseField: fc.option(testCaseFieldArb, { nil: undefined }),
        liftedCaseIds: fc.array(caseIdArb, { minLength: 0, maxLength: 5 }),
        impactRationale: fc.string({ minLength: 0, maxLength: 40 }),
      }),
      { minLength: 0, maxLength: 20 },
    )
    .map((entries) =>
      entries.map((e): PerSuiteRecommendation => {
        const rec: PerSuiteRecommendation = {
          targetField: e.targetField,
          targetName: e.targetName,
          currentText: e.currentText,
          suggestedText: e.suggestedText,
          rationale: e.rationale,
          priority: e.priority,
          predictedImpact: {
            liftedCaseIds: e.liftedCaseIds,
            rationale: e.impactRationale,
          },
        };
        if (e.targetField === "test_case" && e.testCaseField) {
          rec.testCaseField = e.testCaseField;
        }
        return rec;
      }),
    );

  it("after sortAndDenseRankSuiteRecommendations, priorities are monotonically non-decreasing", () => {
    fc.assert(
      fc.property(mixedSuiteRecsArb, (recs) => {
        const sorted = sortAndDenseRankSuiteRecommendations(recs);

        for (let i = 0; i < sorted.length - 1; i++) {
          expect(sorted[i].priority).toBeLessThanOrEqual(sorted[i + 1].priority);
        }
      }),
      { numRuns: 100 },
    );
  });

  it("dense ranking starts at 1 when there are recommendations", () => {
    fc.assert(
      fc.property(
        mixedSuiteRecsArb.filter((recs) => recs.length > 0),
        (recs) => {
          const sorted = sortAndDenseRankSuiteRecommendations(recs);

          expect(sorted[0].priority).toBe(1);
        },
      ),
      { numRuns: 100 },
    );
  });

  it("output length equals input length (no recs lost or duplicated)", () => {
    fc.assert(
      fc.property(mixedSuiteRecsArb, (recs) => {
        const sorted = sortAndDenseRankSuiteRecommendations(recs);

        expect(sorted.length).toBe(recs.length);
      }),
      { numRuns: 100 },
    );
  });

  it("priority ordering holds regardless of targetField mix (agent and test_case interleaved)", () => {
    fc.assert(
      fc.property(
        fc.array(
          fc.record({
            isTestCase: fc.boolean(),
            priority: fc.integer({ min: 1, max: 10 }),
            liftedCount: fc.integer({ min: 0, max: 5 }),
          }),
          { minLength: 2, maxLength: 15 },
        ),
        (specs) => {
          const recs: PerSuiteRecommendation[] = specs.map((spec, idx) => {
            const targetField: RecommendationTarget = spec.isTestCase
              ? "test_case"
              : AGENT_TARGET_FIELDS[idx % AGENT_TARGET_FIELDS.length];
            const rec: PerSuiteRecommendation = {
              targetField,
              targetName: spec.isTestCase ? `case-${idx}` : `tool-${idx}`,
              currentText: "current",
              suggestedText: "suggested",
              rationale: "reason",
              priority: spec.priority,
              predictedImpact: {
                liftedCaseIds: Array.from({ length: spec.liftedCount }, (_, i) => `lifted-${idx}-${i}`),
                rationale: "impact",
              },
            };
            if (spec.isTestCase) {
              rec.testCaseField = "successCriteria";
            }
            return rec;
          });

          const sorted = sortAndDenseRankSuiteRecommendations(recs);

          // Monotonically non-decreasing priorities
          for (let i = 0; i < sorted.length - 1; i++) {
            expect(sorted[i].priority).toBeLessThanOrEqual(sorted[i + 1].priority);
          }
        },
      ),
      { numRuns: 100 },
    );
  });

  it("original rec content is preserved after sorting (no data corruption)", () => {
    fc.assert(
      fc.property(mixedSuiteRecsArb, (recs) => {
        const sorted = sortAndDenseRankSuiteRecommendations(recs);

        // Every sorted rec's non-priority fields should match some input rec
        for (const sortedRec of sorted) {
          const match = recs.find(
            (r) =>
              r.targetField === sortedRec.targetField &&
              r.targetName === sortedRec.targetName &&
              r.currentText === sortedRec.currentText &&
              r.suggestedText === sortedRec.suggestedText &&
              r.rationale === sortedRec.rationale,
          );
          expect(match).toBeDefined();
        }
      }),
      { numRuns: 100 },
    );
  });
});
