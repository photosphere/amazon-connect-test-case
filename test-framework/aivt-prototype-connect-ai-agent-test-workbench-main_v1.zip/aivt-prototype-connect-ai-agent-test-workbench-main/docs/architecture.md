# Architecture

This document describes the technical architecture of the platform: components, data flow, state machines, IAM, and the data model.

## Table of contents

1. [System overview](#system-overview)
2. [Components](#components)
   - [Frontend](#frontend)
   - [API layer](#api-layer)
   - [Lambda handlers](#lambda-handlers)
   - [Step Functions](#step-functions)
   - [Storage](#storage)
   - [External services](#external-services)
3. [Data model](#data-model)
4. [State machines](#state-machines)
5. [Authentication and authorization](#authentication-and-authorization)
6. [Cross-cutting concerns](#cross-cutting-concerns)

---

## System overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              User's browser                                  │
│  React + Cloudscape  •  Cognito hosted UI auth  •  fetch() with bearer token │
└──────────────────────────┬───────────────────────────────────────────────────┘
                           │ HTTPS
┌──────────────────────────▼───────────────────────────────────────────────────┐
│  CloudFront                                                                  │
│  ├── /* (default) → S3 frontend bucket (SPA, with 403/404 → index.html)     │
│  └── (none — API is on a separate domain)                                    │
└──────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────┐
│  API Gateway (REST, prod stage)                                              │
│  ├── Cognito User Pools authorizer (test-platform/run scope)                │
│  ├── Default 4xx/5xx CORS headers (so 401s don't get masked as CORS errors) │
│  └── Routes (every method protected by the authorizer):                     │
│      /agents, /agents/{id}                       → Discovery Lambda         │
│      /suites, /suites/{id}, .../cases/*          → Suite + Cases Lambdas    │
│      .../cases/scaffold                          → Scaffold Lambda          │
│      /runs, /runs/{id}, .../snapshot, .../abort  → Run Trigger + Results    │
│      /runs/{id}/analyze                          → Analysis Lambda          │
│      /runs/{id}/recommend-suite                  → Suite Recommend Lambda   │
│      /comparisons/summarize                      → Comparison Summary       │
│      /runs/{id}/apply-recommendations            → Apply Recommendations    │
│      /runs/{id}/experiments                      → Experiment Create        │
│      /runs/{id}/experiments/{id}                 → Experiment Get           │
│      /runs/{id}/experiments/{id}/apply           → Experiment Apply         │
│      /audit                                      → Audit Lambda             │
└──┬───────────────────────────────────────────────────────────────────────────┘
   │
   │  Lambdas call:
   │
   ▼
┌───────────────────────┐  ┌────────────────────┐  ┌──────────────────────┐
│  Q in Connect APIs    │  │  Bedrock Converse  │  │  Bedrock RAG Eval    │
│  CreateSession        │  │  Judge model       │  │  Knowledge Base      │
│  SendMessage          │  │  Scaffold prompts  │  │  evaluation jobs     │
│  GetNextMessage       │  │  Variant gen       │  │                      │
│  ListSpans            │  │  Tournament summ.  │  │                      │
│  GetAIAgent           │  └────────────────────┘  └──────────────────────┘
│  GetAIPrompt          │
│  Update / Create /    │
│  DeleteAIAgent        │
│  Update AIPrompt      │
└───────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────┐
│  Storage                                                                     │
│  ├── DynamoDB (single table, PK/SK + 2 GSIs)                                │
│  ├── S3 frontend bucket (private, OAI-only)                                 │
│  └── Secrets Manager (machine-client secret for CI/CD)                      │
└──────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────┐
│  Step Functions                                                              │
│  ├── TestRunStateMachine: drives test suite execution                       │
│  └── ExperimentStateMachine: orchestrates multi-variant experiments         │
└──────────────────────────────────────────────────────────────────────────────┘
```

## Components

### Frontend

`src/frontend/` — React 18 + TypeScript, built with Vite, using AWS Cloudscape Design System for components.

**Routing** (see `src/frontend/src/App.tsx`):

| Route | Page |
|---|---|
| `/agents` | Agent browser |
| `/suites` | Test suite list |
| `/suites/:suiteId` | Suite detail (cases, run history) |
| `/runs/new` | Start a new run |
| `/runs/:runId` | Run dashboard (live progress + results) |
| `/runs/:runId/cases/:caseId` | Per-case detail (transcript, trace, recs) |
| `/runs/:runId/results` | Results viewer |
| `/runs/:runId/experiments/:experimentId` | Tournament view |
| `/compare` | Run comparison |

**Auth** — `AuthContext` wraps the app with a `ProtectedRoute`. Cognito hosted UI handles login; auth tokens are attached to every API request by `src/frontend/src/api/client.ts`.

**Runtime config** — the frontend fetches `/config.json` at startup. This file is generated at deploy time from stack outputs (see `lib/runtime-config.ts`). Fields: `apiEndpoint`, `cognitoUserPoolId`, `cognitoClientId`, `cognitoDomain`, `region`, `instanceMode`. No build-time environment variables are used.

**State** — minimal global state: `ActiveRunsContext` polls in-progress runs so the persistent banner updates across pages. Most state is local to each page.

### API layer

`lib/api-construct.ts` defines the API Gateway REST API:

- One Cognito User Pool authorizer scoped to the `test-platform/run` OAuth scope.
- 100 RPS / 200 burst throttling.
- Default CORS preflight + explicit 4xx/5xx CORS headers (so 401 responses don't surface as CORS errors in browsers).

The `ImplementRecommendationsConstruct` (`lib/implement-recommendations-construct.ts`) attaches additional routes for the apply / experiment / audit Lambdas, sharing the same authorizer.

### Lambda handlers

All handlers live in `src/backend/handlers/` and use NodejsFunction (esbuild bundling) on Node 20.x ARM64 with X-Ray tracing.

| Handler | Source | Purpose |
|---|---|---|
| `discovery.ts` | `src/backend/handlers/discovery.ts` | `GET /agents`, `GET /agents/{agentId}` — calls `ListAIAgents` and `GetAIAgent` to discover and return agent configs (with tools, examples, system prompt). |
| `suites.ts` | `src/backend/handlers/suites.ts` | CRUD for test suites at `/suites/*`. |
| `cases.ts` | `src/backend/handlers/cases.ts` | CRUD for test cases at `/suites/{id}/cases/*`. Validates the `tool_sequence` vs `rag` discriminator. |
| `scaffold.ts` | `src/backend/handlers/scaffold.ts` | `POST /suites/{id}/cases/scaffold` — Bedrock-powered tool sequence inference and customer-knowledge template generation. |
| `runs.ts` | `src/backend/handlers/runs.ts` | `POST /runs` (start) and `POST /runs/{id}/abort`. Captures the agent snapshot and triggers the TestRun state machine. |
| `results.ts` | `src/backend/handlers/results.ts` | Read-only: `GET /runs/{id}`, `GET /runs/{id}/cases/{id}`, `GET /runs/{id}/snapshot`, `GET /suites/{id}/runs`. |
| `analysis.ts` | `src/backend/handlers/analysis.ts` | `POST /runs/{id}/analyze` — per-case root-cause analysis. Persists to `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` so re-fetches are free. `force: true` regenerates. |
| `suite-recommend.ts` | `src/backend/handlers/suite-recommend.ts` | `POST /runs/{id}/recommend-suite` — consolidated, prioritized per-suite recommendations. Persists at `SK=ANALYSIS#SUITE`. |
| `comparison-summary.ts` | `src/backend/handlers/comparison-summary.ts` | `POST /comparisons/summarize` — Bedrock-generated summary diffing two runs. |
| `apply-recommendations.ts` | `src/backend/handlers/apply-recommendations.ts` | `POST /runs/{id}/apply-recommendations` — direct apply with drift detection, audit, and apply record. |
| `experiment-create.ts` | `src/backend/handlers/experiment-create.ts` | `POST /runs/{id}/experiments` — generates `experimentId`, persists experiment record, starts the experiment state machine. |
| `experiment-get.ts` | `src/backend/handlers/experiment-get.ts` | `GET /runs/{id}/experiments/{id}`. |
| `experiment-apply.ts` | `src/backend/handlers/experiment-apply.ts` | `POST /runs/{id}/experiments/{id}/apply` — apply a winning variant. Same drift+audit flow as direct apply. |
| `experiment-cleanup.ts` | `src/backend/handlers/experiment-cleanup.ts` | Invoked by the experiment state machine. Deletes temporary agents with retry. |
| `audit.ts` | `src/backend/handlers/audit.ts` | `GET /audit` — paginated tenant audit records, reverse chronological. |

### Orchestration modules

`src/backend/orchestration/` holds the test-execution and analysis logic. These are mostly pure or near-pure modules — they're heavily property-tested.

| Module | Purpose |
|---|---|
| `state-machine.ts` | Defines the TestRunStateMachine CDK construct. |
| `experiment-state-machine.ts` | Defines the ExperimentStateMachine CDK construct. |
| `conversation-driver.ts` | Drives a Q in Connect session for one test case: CreateSession, SendMessage with `aiAgentId` override, polls `GetNextMessage`, handles filler responses, calls `ListSpans`. |
| `customer-simulator.ts` | Bedrock-powered customer persona simulator. Plays the customer role in multi-turn tool-sequence cases. |
| `contact-manager.ts` | Mints synthetic Connect contacts that orchestration tools require. |
| `span-parser.ts` | Parses `ListSpans` payloads into a structured `ExecutionTrace` with reasoning steps and tool invocations. |
| `chunk-extractor.ts` | Pulls retrieved chunks from `Retrieve` tool spans for RAG cases. |
| `evaluation.ts` | Per-case scoring via Bedrock judge. Maps rubric labels through Score_Scale tables to `[0,1]` values. |
| `bedrock-judge-client.ts` | Thin SDK seam over `bedrock-runtime` `ConverseCommand`. One module = one call site. |
| `judge-prompt-templates.ts` | Verbatim copies of AWS-published evaluator templates (`GoalSuccessRate`, `Helpfulness`, `ToolSelectionAccuracy`). |
| `score-aggregation.ts` | Pure: computes `passRate`, `avgGoalSuccess`, `avgHelpfulness`, `avgToolAccuracy` from a `TestCaseResult[]`. Excludes undefined scores. |
| `opportunistic-faithfulness.ts` | Inline RAG faithfulness scoring for tool-sequence cases that happened to invoke `Retrieve`. |
| `rag-decision.ts` | Determines whether a run requires Stage 2 (RAG evaluation). |
| `rag-evaluate.ts` | Submits a Bedrock RAG Evaluation job, polls until completion, reads results from S3. |
| `jsonl-serializer.ts` | Builds the Bedrock BYOI retrieve-and-generate JSONL dataset. |
| `drift-detection.ts` | Pure: compares each recommendation's `currentText` against the live agent character-for-character. |
| `config-writer.ts` | Builds and executes `UpdateAIAgent` / `UpdateAIPrompt` payloads. Tool changes in one call, prompt changes in one call. |
| `validation.ts` | Pure: structural validation of `Recommendation` records. |
| `system-prompt-safety.ts` | Pure: validates that variant-modified system prompts preserve dynamic parameters at the end, leave thinking/messaging blocks unchanged, and don't introduce new examples. |
| `variant-generator.ts` | Bedrock Converse call (temperature 0.7, no topP) producing 3 diverse rewrites with retry. |
| `variant-selection.ts` | Pure deterministic winner selection: highest pass rate, tiebreak by goal success. |
| `tournament-summary.ts` | Bedrock Converse call (temperature 0) explaining the deterministic winner. |

### Step Functions

Two state machines:

**TestRunStateMachine** (`src/backend/orchestration/state-machine.ts`) — orchestrates one test run:

```
PrepareRun → ExecuteCases (parallel, default concurrency 9)
  → [if any RAG cases: RAGEvaluate]
  → EvaluateResults (Bedrock judge per case)
  → WriteResults
```

**ExperimentStateMachine** (`src/backend/orchestration/experiment-state-machine.ts`) — orchestrates a multi-variant experiment:

```
GenerateVariants → ValidateVariants → CreateTempAgents → MarkRunning
  → Parallel(RunVariantA, RunVariantB, RunVariantC) — each branch:
    TriggerRun → PollStatus loop (30s waits) → VariantDone
  → GenerateSummary → Cleanup → MarkCompleted
```

Error handling per branch ensures one variant failure doesn't abort siblings. Cleanup runs unconditionally — even if upstream steps fail — so temporary agents are always deleted.

### Storage

`lib/storage-construct.ts`:

- **DynamoDB single table** with composite `PK`/`SK`, point-in-time recovery enabled, TTL attribute `ttl`.
- **GSI1** (`GSI1PK`/`GSI1SK`) — list suites by tenant sorted by update time.
- **GSI2** (`GSI2PK`/`GSI2SK`) — find suites by target agent.
- **S3 frontend bucket** — private, encrypted (SSE-S3), TLS-only, OAI-only access. CloudFront serves the SPA from here.
- **CloudFront distribution** — redirects HTTP→HTTPS, returns `index.html` on 403/404 for SPA routing.

### External services

| Service | What we call | Why |
|---|---|---|
| **Q in Connect** | `CreateSession`, `SendMessage` (with `aiAgentId` override), `GetNextMessage`, `ListSpans` | Drive test conversations against the live agent. |
| **Q in Connect** | `ListAIAgents`, `GetAIAgent`, `GetAIPrompt` | Discovery, snapshot capture, drift detection. |
| **Q in Connect** | `UpdateAIAgent`, `UpdateAIPrompt`, `CreateAIAgent`, `DeleteAIAgent` | Apply recommendations, create/clean up experiment temp agents. Production mode omits these. |
| **Bedrock Runtime** | `ConverseCommand` | Customer simulator, scaffold, analysis, suite recommendations, comparison summary, judge evaluations, variant generation, tournament summary. |
| **Bedrock** | `CreateEvaluationJob`, `GetEvaluationJob` | RAG evaluation jobs. |
| **Amazon Connect** | Synthetic contact creation via the contact-creator flow | Q in Connect orchestration tools require a `ContactARN`. |
| **Cognito** | User Pool, Identity Pool, hosted UI, Resource Server | Auth. |

## Data model

DynamoDB single-table layout. All entities live in one table; the partition (`PK`) and sort (`SK`) keys discriminate.

| Entity | PK | SK | Notes |
|---|---|---|---|
| Test suite | `TENANT#{tenantId}` | `SUITE#{suiteId}` | GSI1 keys for tenant listings. |
| Test case | `SUITE#{suiteId}` | `CASE#{caseId}` | Discriminator: `type: "tool_sequence" \| "rag"`. |
| Test run | `SUITE#{suiteId}` | `RUN#{startTime}` | Plus a `SUMMARY` record at `PK=RUN#{runId}, SK=SUMMARY` after completion. |
| Test case result | `RUN#{runId}` | `CASE#{caseId}` | Includes scores, transcript turns, execution trace. |
| Transcript turn | `RUN#{runId}#CASE#{caseId}` | `TURN#{number}` | Customer/agent turns with text, tool selection, timestamps. |
| Execution trace | `RUN#{runId}` | `TRACE` (or per case: `TRACE#{caseId}`) | Parsed `ListSpans` output. |
| Agent snapshot | `RUN#{runId}` | `SNAPSHOT` | Tools (with examples), system prompt, model id, capturedAt. |
| Per-case analysis | `RUN#{runId}` | `ANALYSIS#CASE#{caseId}` | Persisted recommendations from `analysis.ts`. |
| Per-suite analysis | `RUN#{runId}` | `ANALYSIS#SUITE` | Persisted consolidated recommendations from `suite-recommend.ts`. |
| Experiment | `RUN#{runId}` | `EXPERIMENT#{experimentId}` | Variant configs, temp agent IDs, variant run IDs, tournament summary. TTL: 90 days post-completion. |
| Apply record | `RUN#{runId}` | `APPLY#DIRECT#{timestamp}` | Per-run audit: which recommendations were applied directly. |
| Audit record | `TENANT#{tenantId}` | `AUDIT#{timestamp}` | Tenant-wide audit trail. |

Patterns are codified in `src/shared/constants.ts` (`PK_PATTERNS`, `SK_PATTERNS`).

### Type system

`src/shared/types.ts` is the canonical type contract between frontend and backend. Key types:

| Type | What it is |
|---|---|
| `TestSuite`, `TestCase`, `ToolSequenceTestCase`, `RagTestCase` | Test definitions. |
| `TestRun`, `TestCaseResult` | Run records. |
| `ToolDefinition`, `AgentDetail`, `AgentSnapshot` | Agent configuration. |
| `Recommendation`, `PerSuiteRecommendation` | Recommendation records. |
| `ExperimentRecord`, `VariantConfig`, `TournamentSummary` | Experiment data. |
| `AuditRecord`, `ApplyRecord`, `DriftedField` | Audit/apply records. |
| `ExecutionTrace`, `ExecutionStep`, `ToolInvocation` | Parsed reasoning trace. |

## State machines

### TestRun state machine

The lifecycle of one test run, from `POST /runs` through final results.

1. **PrepareRun** — captures `AgentSnapshot` (calls `GetAIAgent` and `GetAIPrompt`), creates the `TestRun` record, mints a synthetic Connect contact for the run.
2. **ExecuteCases** — Step Functions Map state runs each test case in parallel (default concurrency 9). Per case:
   - For **tool-sequence cases**: `conversation-driver.ts` orchestrates the Q in Connect session, simulates the customer with Bedrock, captures tool selections from `conversationSessionData["Tool"]`, handles filler `"..."` responses with token-advancement detection.
   - For **RAG cases**: sends the question once, captures the terminal response and retrieved chunks from `ListSpans`.
   - Throttle backoff with jitter on every Q in Connect API call.
3. **RAGEvaluate** (only if the suite has at least one RAG case): builds a BYOI JSONL, uploads to S3, calls `bedrock:CreateEvaluationJob`, polls until COMPLETED, reads per-prompt metric scores, joins back to caseId, writes `ragMetrics` per case.
4. **EvaluateResults** — for each non-errored case, calls the Bedrock judge: 1 GoalSuccessRate + N Helpfulness (per assistant turn) + M ToolSelectionAccuracy (per tool call). Maps labels through Score_Scale tables, aggregates per case.
5. **WriteResults** — finalizes the run record with totals and writes a SUMMARY record.

### Experiment state machine

The lifecycle of one multi-variant experiment.

1. **GenerateVariants** — `variant-generator.ts` calls Bedrock with temperature=0.7 (no topP) to produce 3 diverse rewrites of the source recommendations, validating each against structural constraints, surface scope containment, and system prompt safety. Up to 1 retry per failed variant.
2. **ValidateVariants** — updates experiment status to `creating_agents`.
3. **CreateTempAgents** — clones the target agent 3 times via `CreateAIAgent`, applying each variant's changes. Names `{original}-experiment-{id}-variant-{A|B|C}`. Knowledge Base bindings preserved unchanged. Catch handler triggers RollbackAgents (delete any partial creates) on failure.
4. **MarkRunning** — updates experiment status to `running`.
5. **Parallel(RunVariantA, RunVariantB, RunVariantC)** — three independent branches:
   - TriggerRun → trigger a TestRun state machine execution targeting the temp agent.
   - PollStatus loop with 30s waits until run completes or errors.
   - Per-branch catch handler isolates failures so one variant erroring doesn't abort siblings.
6. **GenerateSummary** — `tournament-summary.ts` calls Bedrock with temperature=0 to explain the deterministic winner. Catch handler proceeds to cleanup with a fallback summary on failure.
7. **Cleanup** — `experiment-cleanup.ts` deletes all temp agents with one retry per agent. Runs unconditionally regardless of upstream success/failure.
8. **MarkCompleted** — updates experiment status to `completed` (or `partial_failure` if cleanup left orphans).

Total timeout: 3 hours.

## Authentication and authorization

`lib/cognito-auth.ts` provisions:

- **User Pool** — email-based sign-in, MFA optional, password policy enforced. Self-signup disabled — admins create users (the optional `adminEmail` deploy-time bootstrap creates the first one).
- **Hosted UI** — Cognito-hosted login at `{stack-name}-{account}.auth.{region}.amazoncognito.com`.
- **Resource Server** with one custom scope: `test-platform/run`. The web client and machine client both have this scope.
- **Web Client** (`UserPoolClientId`) — for the React frontend. Authorization Code Grant flow. Public client (no secret).
- **Machine Client** (`MachineClientId`) — for CI/CD. Client Credentials Grant. Secret stored in Secrets Manager.
- **Identity Pool** — issues temporary AWS credentials to authenticated users. The attached IAM role grants `wisdom:CreateSession`, `wisdom:SendMessage`, `wisdom:GetNextMessage` (plus `qconnect:` equivalents) and `bedrock:InvokeModel`/`bedrock:Converse`. Scoped to assistant ARNs.

**Tenant isolation** — `tenantId` is extracted from the Cognito JWT (`sub` for users, `client_id` for machine clients) on every API call. All DynamoDB queries are scoped to `PK=TENANT#{tenantId}` (or `SUITE#{suiteId}`/`RUN#{runId}` where the parent record's tenancy is already established).

**INSTANCE_MODE** is enforced at three layers:
1. **UI** — `ImplementButton`, `ConfirmationDialog`, etc. return `null` when `instanceMode === "production"`.
2. **API** — write handlers (`apply-recommendations`, `experiment-create`, `experiment-apply`) return 403 with `error: "write_disabled"`.
3. **IAM** — `ImplementRecommendationsConstruct` omits `wisdom:UpdateAIAgent`, `UpdateAIPrompt`, `CreateAIAgent`, `DeleteAIAgent` from Lambda role policies in production mode. Even a compromised Lambda can't write.

See [operations.md](operations.md) for the complete instance-mode contract.

## Cross-cutting concerns

### Observability

- **CloudWatch Logs** — every Lambda. Structured JSON logs.
- **X-Ray tracing** — enabled on every Lambda (`tracing: lambda.Tracing.ACTIVE`) and on the experiment state machine.
- **DynamoDB point-in-time recovery** — enabled on the main table.

### Throttling and retries

- API Gateway: 100 RPS / 200 burst.
- Q in Connect: exponential backoff with jitter on every call. Base 2s, cap 30s, max 3 retries.
- Bedrock: throttle retry with jitter on `ThrottlingException` (variant generator and tournament summary). Other errors propagate immediately.

### Bundling

- Lambdas use NodejsFunction (esbuild). Most AWS SDK packages are excluded from bundles to use the runtime's built-in versions, **except** `@aws-sdk/client-qconnect` which is bundled to ensure newer API field support.

### `anthropic_claude_4x` capability profile

Bedrock Converse calls against any model in the `anthropic_claude_4x` capability profile (Claude Sonnet 4.6, Haiku 4.5, Opus 4.8) **set only `maxTokens`** — `temperature`, `topP`, `topK`, and `stopSequences` are forbidden by the profile. The validation pipeline rejects any inference parameter conflicting with the resolved model's profile with structured code `MODEL_FORBIDS_KEY`. The `variant-generator.ts` and `tournament-summary.ts` callsites historically set `temperature` only and never `topP`; that behavior is now enforced platform-wide by the capability profile rather than callsite-local guards.
