// Feature: test-case-validity-analysis, Property 4: Recommendation partitioning invariant
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import { partitionByTargetType } from "@shared/utils/recommendation-bucketing";
import type { RecommendationTarget } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** The five valid RecommendationTarget values. */
const recommendationTargetArb: fc.Arbitrary<RecommendationTarget> =
  fc.constantFrom<RecommendationTarget>(
    "tool_description",
    "tool_instruction",
    "tool_examples",
    "system_prompt",
    "test_case",
  );

/** The four ToolSurface values (agent-targeted). */
const TOOL_SURFACE_VALUES: ReadonlySet<string> = new Set([
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
]);

/**
 * Arbitrary recommendation-like record with `targetField` drawn from
 * the five valid RecommendationTarget values. Additional fields are
 * included to ensure the function preserves the full record shape.
 */
const recArb = fc.record({
  targetField: recommendationTargetArb,
  targetName: fc.string({ minLength: 0, maxLength: 40 }),
  currentText: fc.string({ minLength: 0, maxLength: 80 }),
  suggestedText: fc.string({ minLength: 0, maxLength: 80 }),
  rationale: fc.string({ minLength: 0, maxLength: 80 }),
});

/** Arrays of length 0..50. */
const recsArrayArb = fc.array(recArb, { minLength: 0, maxLength: 50 });

// ---------------------------------------------------------------------------
// Property 4: Recommendation partitioning invariant
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 8.1, 8.2, 11.1**
 *
 * Property 4: Recommendation partitioning invariant
 *
 * For any array of Recommendation records with `targetField` values drawn
 * from the five valid RecommendationTarget values, `partitionByTargetType`
 * produces two arrays (`agent` and `testCase`) such that:
 *   (a) every input record appears in exactly one output array,
 *   (b) the concatenation of both output arrays is a permutation of the input,
 *   (c) every record in `testCase` has `targetField === "test_case"` and
 *       every record in `agent` has `targetField` in the four ToolSurface values.
 */
describe("Feature: test-case-validity-analysis, Property 4: Recommendation partitioning invariant", () => {
  it("(a) every input record appears in exactly one output array", () => {
    fc.assert(
      fc.property(recsArrayArb, (xs) => {
        const { agent, testCase } = partitionByTargetType(xs);

        // Every input record appears in exactly one output (by reference).
        for (const rec of xs) {
          const inAgent = agent.includes(rec);
          const inTestCase = testCase.includes(rec);
          // Exactly one must be true.
          expect(inAgent !== inTestCase).toBe(true);
        }
      }),
      { numRuns: 100 },
    );
  });

  it("(b) concatenation of both output arrays is a permutation of the input", () => {
    fc.assert(
      fc.property(recsArrayArb, (xs) => {
        const { agent, testCase } = partitionByTargetType(xs);
        const concat = [...agent, ...testCase];

        // Same length.
        expect(concat).toHaveLength(xs.length);

        // Same multiset: every input record (by reference) is in the
        // concatenated output exactly once.
        const remaining = [...concat];
        for (const rec of xs) {
          const idx = remaining.indexOf(rec);
          expect(idx).toBeGreaterThanOrEqual(0);
          remaining.splice(idx, 1);
        }
        expect(remaining).toHaveLength(0);
      }),
      { numRuns: 100 },
    );
  });

  it("(c) testCase entries have targetField === 'test_case' and agent entries have one of the four ToolSurface values", () => {
    fc.assert(
      fc.property(recsArrayArb, (xs) => {
        const { agent, testCase } = partitionByTargetType(xs);

        for (const rec of testCase) {
          expect(rec.targetField).toBe("test_case");
        }
        for (const rec of agent) {
          expect(TOOL_SURFACE_VALUES.has(rec.targetField)).toBe(true);
        }
      }),
      { numRuns: 100 },
    );
  });

  it("output sizes sum to input length", () => {
    fc.assert(
      fc.property(recsArrayArb, (xs) => {
        const { agent, testCase } = partitionByTargetType(xs);
        expect(agent.length + testCase.length).toBe(xs.length);
      }),
      { numRuns: 100 },
    );
  });

  it("order within each group matches the input's filtered subsequence (stable partition)", () => {
    fc.assert(
      fc.property(recsArrayArb, (xs) => {
        const { agent, testCase } = partitionByTargetType(xs);

        const expectedAgent = xs.filter((r) => r.targetField !== "test_case");
        const expectedTestCase = xs.filter(
          (r) => r.targetField === "test_case",
        );

        expect(agent).toEqual(expectedAgent);
        expect(testCase).toEqual(expectedTestCase);
      }),
      { numRuns: 100 },
    );
  });

  it("returns both arrays even when the input is empty", () => {
    const { agent, testCase } = partitionByTargetType([]);
    expect(agent).toEqual([]);
    expect(testCase).toEqual([]);
  });
});
