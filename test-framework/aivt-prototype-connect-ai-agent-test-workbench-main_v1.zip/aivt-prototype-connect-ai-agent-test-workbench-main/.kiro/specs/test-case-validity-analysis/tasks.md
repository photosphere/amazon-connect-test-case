# Implementation Plan: Test Case Validity Analysis

## Overview

This plan extends the Recommendation_Engine to detect and surface test case defects. The implementation proceeds in layers: shared types first, then backend logic (prompt rendering, validation, suite partitioning), prompt registry updates, frontend UI, and finally property-based tests validating universal invariants. Each task builds incrementally on the prior, with no orphaned code.

## Tasks

- [x] 1. Extend shared types and add recommendation partitioning utility
  - [x] 1.1 Extend `src/shared/types.ts` with new types
    - Add `RecommendationTarget` type union (`tool_description | tool_instruction | tool_examples | system_prompt | test_case`)
    - Add `TestCaseTargetField` type union (`successCriteria | initialUtterance | persona | customerKnowledge | goalDescription`)
    - Add optional `testCaseField?: TestCaseTargetField` property to the `Recommendation` interface
    - Widen `Recommendation.targetField` from `ToolSurface` to `RecommendationTarget`
    - Add `testCaseDefect?: boolean` to the `PerCaseAnalysis` response interface (or equivalent exported type)
    - _Requirements: 3.1, 3.4, 4.1, 4.2, 8.5_

  - [x] 1.2 Add `partitionByTargetType` utility to `src/shared/utils/recommendation-bucketing.ts`
    - Implement `partitionByTargetType<T extends { targetField: string }>(recs: T[]): { agent: T[]; testCase: T[] }` that splits recommendations into agent-targeted (four ToolSurface values) and test-case-targeted (`test_case`) groups
    - Every input record appears in exactly one output group; union equals input
    - Export the function alongside the existing `bucketByTargetField`
    - _Requirements: 8.1, 8.2, 11.1_

  - [x] 1.3 Write property test for recommendation partitioning (Property 4)
    - **Property 4: Recommendation partitioning invariant**
    - Test file: `tests/unit/properties/recommendation-partitioning.test.ts`
    - Generate arbitrary arrays of recommendations with `targetField` drawn from the five valid values; assert: (a) every record in exactly one output, (b) concatenation is a permutation of input, (c) `testCase` entries all have `targetField === "test_case"` and `agent` entries have one of the four ToolSurface values
    - **Validates: Requirements 8.1, 8.2, 11.1**

- [x] 2. Implement test case definition fetcher and renderer in `analysis.ts`
  - [x] 2.1 Add `getTestCaseDefinition` function to `src/backend/handlers/analysis.ts`
    - Fetch test case record from DynamoDB using `PK=SUITE#{suiteId}, SK=CASE#{caseId}`
    - Return `ToolSequenceTestCase | null` (null when record not found or case is RAG type)
    - Accept `suiteId` from request context (extend request interface if needed)
    - _Requirements: 1.6, 1.7_

  - [x] 2.2 Add `renderTestCaseDefinition` function to `src/backend/handlers/analysis.ts`
    - Render `## Test Case Definition` section with: name, description, persona, style, initialUtterance, goalDescription (or `"(not specified)"`), customerKnowledge (bulleted list or `"(none)"`), successCriteria (numbered list with parameterChecks as indented sub-items)
    - When test case is null, render fallback message per Requirement 1.7
    - _Requirements: 1.1, 1.3, 1.4, 1.5_

  - [x] 2.3 Write property tests for test case definition renderer (Properties 1, 2)
    - **Property 1: Test case definition renderer completeness**
    - **Property 2: Prompt section ordering**
    - Test file: `tests/unit/properties/test-case-definition-renderer.test.ts`
    - Generate arbitrary valid `ToolSequenceTestCase` records; assert rendered output contains all required fields and maintains correct section ordering relative to `## Test Case:` and `## Conversation Transcript`
    - **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 11.5**

- [x] 3. Extend per-case analysis prompt and validation
  - [x] 3.1 Extend `buildAnalysisPrompt` in `src/backend/handlers/analysis.ts`
    - Add `testCaseDefinition: ToolSequenceTestCase | null` parameter
    - Insert rendered `## Test Case Definition` section after `## Test Case: {caseId}` and before `## Conversation Transcript`
    - Extend instructions block: add `test_case_defect` to root cause enumeration, add `test_case` to valid targetField values, add `testCaseField` to response schema, add Sound Decision Signal detection instructions, add constraint for at most one test_case recommendation per case
    - _Requirements: 1.2, 2.1, 2.2, 2.3, 2.4, 2.5, 4.6, 4.7, 5.1, 5.2, 5.3, 5.4, 5.5, 9.1, 9.2, 9.3, 9.4, 9.5_

  - [x] 3.2 Extend `sanitizeRecommendations` in `src/backend/handlers/analysis.ts`
    - Widen `VALID_TARGET_FIELDS` set to include `"test_case"`
    - Add `VALID_TEST_CASE_FIELDS` set with the five valid values
    - Validate: `test_case` recs must have valid `testCaseField`; drop if missing/invalid
    - Validate: `test_case` recs only valid when `rootCauseCategory === "test_case_defect"`; drop otherwise
    - Strip `testCaseField` from non-`test_case` recs (model hallucination cleanup)
    - Accept `rootCauseCategory` as parameter for partition-aware validation
    - _Requirements: 3.3, 3.4, 3.5_

  - [x] 3.3 Extend `parseAnalysisResponse` to parse `testCaseField` from Bedrock output
    - Include `testCaseField` in the recommendation mapping when present
    - Accept `test_case_defect` as a valid rootCauseCategory (do not reclassify to `other`)
    - _Requirements: 2.3, 9.1_

  - [x] 3.4 Wire test case fetch into the analysis handler's main loop
    - Call `getTestCaseDefinition(suiteId, caseId)` per failed case
    - Pass result to `buildAnalysisPrompt`
    - Persist `testCaseDefect: true` boolean when rootCauseCategory is `test_case_defect`
    - Set `targetName` to `caseId` for validated `test_case` recommendations
    - _Requirements: 1.6, 3.2, 8.5, 10.1, 10.2_

  - [x] 3.5 Write property tests for test case recommendation validation (Properties 3, 9, 10)
    - **Property 3: Test case recommendation validation invariant**
    - **Property 9: Valid test_case_defect analysis preserves test_case recommendations**
    - **Property 10: successCriteria currentText is non-empty**
    - Test file: `tests/unit/properties/test-case-recommendation-validation.test.ts`
    - Generate arbitrary recommendation arrays and rootCauseCategory values; assert validation invariants hold
    - **Validates: Requirements 3.3, 3.4, 11.2, 11.3, 11.6**

- [x] 4. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Extend suite consolidation with partition logic
  - [x] 5.1 Extend `buildUserMessage` in `src/backend/handlers/suite-recommend.ts`
    - Partition `failedCaseIds` into `testCaseDefectIds` and `agentDeficiencyIds` based on `perCaseAnalyses` rootCauseCategory
    - Render two labeled sections: `## Agent Deficiency Failures` and `## Test Case Defect Failures` (only sections with cases)
    - Extend instructions block to reference `test_case` as valid targetField, include `testCaseField` in schema, add cross-partition constraints on liftedCaseIds
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

  - [x] 5.2 Extend `filterAndNormalizeSuiteRecommendations` in `src/backend/handlers/suite-recommend.ts`
    - Accept `testCaseDefectCaseIds: ReadonlySet<string>` parameter
    - For `test_case` recs: validate liftedCaseIds are subset of testCaseDefectCaseIds; drop offending IDs
    - For agent recs: validate liftedCaseIds are subset of non-defect case IDs; drop offending IDs
    - Add `test_case` to valid targetField set
    - Validate `testCaseField` on `test_case` suite recs (same rules as per-case)
    - _Requirements: 6.3, 3.4, 3.5_

  - [x] 5.3 Wire the partition set through the suite-recommend handler
    - Compute `testCaseDefectCaseIds` from `perCaseAnalyses` Map
    - Pass to `filterAndNormalizeSuiteRecommendations`
    - Persist `test_case` suite recommendations in the unified `recommendations[]` array
    - _Requirements: 10.4, 10.5_

  - [x] 5.4 Write property tests for suite partition and ordering (Properties 6, 7, 8)
    - **Property 6: Suite failure partition correctness**
    - **Property 7: Suite liftedCaseIds partition subset**
    - **Property 8: Suite priority ordering across mixed recommendation types**
    - Test file: `tests/unit/properties/suite-partition-and-ordering.test.ts`
    - Generate arbitrary per-case analyses with various rootCauseCategory values; assert partition correctness, liftedCaseIds constraints, and monotonic priority ordering
    - **Validates: Requirements 6.1, 6.3, 6.4, 11.4**

- [x] 6. Update prompt registry versions
  - [x] 6.1 Bump `failure-analysis` prompt to v3 in `src/backend/orchestration/prompt-registry/prompts/failure-analysis.ts`
    - Preserve `PRIOR_DEFAULT_TEXT` chain (add v2 as prior)
    - Update `DEFAULT_TEXT` to reference: test case definition section, `test_case_defect` root cause category, Sound Decision Signal detection, `test_case` recommendation target with `testCaseField`
    - _Requirements: 2.2, 5.1, 9.1, 9.4_

  - [x] 6.2 Bump `suite-recommendation` prompt to v3 in `src/backend/orchestration/prompt-registry/prompts/suite-recommendation.ts`
    - Preserve `PRIOR_DEFAULT_TEXT` chain (add v2 as prior)
    - Update `DEFAULT_TEXT` to reference: dual-partition structure (`## Agent Deficiency Failures` / `## Test Case Defect Failures`), `test_case` as valid targetField, cross-partition liftedCaseIds constraint
    - _Requirements: 6.2_

- [x] 7. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 8. Implement persistence round-trip and backward compatibility
  - [x] 8.1 Verify persistence of `testCaseField` and `testCaseDefect` in DynamoDB writes
    - Ensure `persistCaseAnalysis` includes `testCaseField` on recommendations and `testCaseDefect` boolean on the record
    - Ensure `writePersistedSuiteAnalysis` persists `testCaseField` on suite recommendations
    - _Requirements: 10.1, 10.2, 10.4_

  - [x] 8.2 Add backward-compatibility read handling
    - When reading persisted records without `testCaseField`, treat as agent-targeted
    - When reading persisted records without `testCaseDefect`, treat as `false`
    - Existing `ANALYSIS#CASE#` and `ANALYSIS#SUITE` records render unchanged
    - _Requirements: 8.1, 8.2, 8.3, 8.4_

  - [x] 8.3 Write property test for persistence round-trip (Property 5)
    - **Property 5: Per-case analysis persistence round-trip**
    - Test file: `tests/unit/properties/test-case-persistence-roundtrip.test.ts`
    - Generate arbitrary `PerCaseAnalysis` records with `test_case` recommendations; assert write-then-read produces identical `targetField`, `targetName`, `testCaseField`, `currentText`, `suggestedText`, `rationale` values
    - **Validates: Requirements 10.1, 10.2, 10.3**

- [x] 9. Implement frontend UI changes
  - [x] 9.1 Extend `RecommendedChangesPanel` with badge and section grouping
    - Add `RecommendationBadge` component: blue "Fix test" badge for `test_case`, orange "Fix agent" badge for agent targets
    - Group recommendations into two visual sections: "Agent recommendations" (orange tint, first) and "Test case recommendations" (blue tint, second)
    - Render only relevant section when recommendations are single-type
    - Use `partitionByTargetType` from the shared utility
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 10.5_

  - [x] 9.2 Extend `FailureAnalysis` per-case view
    - Render `test_case` recommendations with blue "Fix test" badge and `testCaseField` sub-label (e.g., "Fix test · successCriteria")
    - Add "Edit test case" deep-link to test case editor with target field pre-selected
    - _Requirements: 7.5, 7.6_

  - [x] 9.3 Write unit tests for frontend components
    - Test `RecommendedChangesPanel`: blue badge for test_case, orange badge for agent, section grouping, single-type rendering
    - Test `FailureAnalysis`: testCaseField sub-label, deep-link generation
    - Test backward compat: pre-feature records without `testCaseField` render with orange badge
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 8.1, 8.2_

- [x] 10. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design's Correctness Properties section
- Unit tests validate specific examples, edge cases, and component rendering
- The design uses TypeScript throughout; all implementation tasks use TypeScript
- The `suiteId` for test case fetching comes from the request context — the analysis endpoint already has access to the run record which carries `suiteId`
- The existing `bucketByTargetField` utility throws on unknown targetField values — callers must filter before bucketing, or use the new `partitionByTargetType` which handles `test_case` natively

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["1.2", "2.1", "2.2"] },
    { "id": 2, "tasks": ["1.3", "2.3", "3.1", "3.2", "3.3"] },
    { "id": 3, "tasks": ["3.4", "3.5", "6.1", "6.2"] },
    { "id": 4, "tasks": ["5.1", "5.2"] },
    { "id": 5, "tasks": ["5.3", "5.4"] },
    { "id": 6, "tasks": ["8.1", "8.2"] },
    { "id": 7, "tasks": ["8.3", "9.1", "9.2"] },
    { "id": 8, "tasks": ["9.3"] }
  ]
}
```
