/**
 * Unit tests for the runtime prompt-resolution helpers in
 * `src/backend/orchestration/prompt-registry/runtime.ts`.
 *
 * Two helpers compose the runtime surface:
 *
 *   - `resolvePromptForRun(promptKey, runId)` reads the run's pinned
 *     `AgentSnapshot.prompts` map first; falls back to the live
 *     override store when the snapshot is missing the prompt, lacks a
 *     `prompts` field, or simply doesn't exist.
 *   - `resolvePromptLive(promptKey)` reads the live override store
 *     directly and runs the pure resolver.
 *
 * Both fail closed — they throw a typed `PromptResolutionError` rather
 * than substitute an empty or stale prompt when both paths fail. The
 * live-override read is cached for 30 seconds per Lambda warm to avoid
 * hammering DynamoDB during a Map iteration over hundreds of cases.
 *
 * The tests use the runtime module's `_setPromptStore` injection point
 * to swap in a `vi.fn()`-driven `DynamoDBService` double, and
 * `_clearCaches` between cases so a stale cache does not bleed into
 * the next test.
 *
 * _Validates: Requirements 11.2, 11.3, 16.2, 16.3_
 */

import {
  afterEach,
  beforeEach,
  describe,
  expect,
  it,
  vi,
  type MockInstance,
} from "vitest";

import {
  PromptResolutionError,
  _clearCaches,
  _setPromptStore,
  resolvePromptForRun,
  resolvePromptLive,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import {
  CAPABILITY_PROFILES,
  PROMPT_REGISTRY,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";
import type {
  AgentSnapshot,
  PromptKey,
  PromptOverride,
  ResolvedPromptSnapshot,
} from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Constants & fixtures
// ---------------------------------------------------------------------------

const PROMPT_KEY: PromptKey = "failure_analysis";
const RUN_ID = "run-test-1";

/**
 * Build a `DynamoDBService`-shaped mock with `vi.fn()` instances for the
 * two methods the runtime helpers consult. Tests reach into the returned
 * stub to set per-test return values and assert call counts.
 *
 * The narrow surface keeps the test honest: any method other than
 * `getSnapshot` / `listPromptOverrides` triggering during a test means
 * the runtime helper grew an unexpected dependency.
 */
type MockStore = {
  getSnapshot: ReturnType<typeof vi.fn>;
  listPromptOverrides: ReturnType<typeof vi.fn>;
};

function makeMockStore(): MockStore {
  return {
    getSnapshot: vi.fn(),
    listPromptOverrides: vi.fn(),
  };
}

function injectStore(store: MockStore): MockStore {
  _setPromptStore(store as unknown as DynamoDBService);
  return store;
}

/**
 * Build a `ResolvedPromptSnapshot` for `failure_analysis` shaped the way
 * the PrepareRun snapshotter would persist it. The values intentionally
 * differ from the registry's bundled defaults so every test that
 * exercises the snapshot-first path can assert the runtime returned the
 * pinned values rather than re-resolved them through the live store.
 */
function makePinnedSnapshot(
  overrides: Partial<ResolvedPromptSnapshot> = {},
): ResolvedPromptSnapshot {
  return {
    text: "Pinned snapshot text for failure analysis.",
    modelKey: "claude_haiku_4_5",
    modelId: SUPPORTED_MODELS.claude_haiku_4_5.inferenceProfileId,
    inferenceParameters: { maxTokens: 1024 },
    capabilityProfileKey: "anthropic_claude_4x_lax",
    version: 7,
    ...overrides,
  };
}

/**
 * Build an `AgentSnapshot` carrying the pinned prompts map. The non-prompt
 * fields are placeholders — the runtime helpers only consult `prompts`.
 */
function makeSnapshot(
  prompts: Readonly<Record<PromptKey, ResolvedPromptSnapshot>> | undefined,
): AgentSnapshot {
  const base: AgentSnapshot = {
    tools: [],
    systemPrompt: "snapshot system prompt",
    modelId: "us.anthropic.claude-sonnet-4-6",
    capturedAt: "2024-06-01T00:00:00.000Z",
  };
  if (prompts !== undefined) {
    return { ...base, prompts };
  }
  return base;
}

// ---------------------------------------------------------------------------
// Test scaffolding
// ---------------------------------------------------------------------------

describe("Runtime prompt resolver", () => {
  let store: MockStore;
  let infoSpy: MockInstance;
  let warnSpy: MockInstance;

  beforeEach(() => {
    store = injectStore(makeMockStore());
    _clearCaches();
    // Silence the structured logs the runtime emits and capture them
    // for assertion. Tests opt into the spies they need; the silenced
    // output keeps test runs readable.
    infoSpy = vi.spyOn(console, "info").mockImplementation(() => {});
    warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
  });

  afterEach(() => {
    _setPromptStore(null);
    _clearCaches();
    infoSpy.mockRestore();
    warnSpy.mockRestore();
    vi.useRealTimers();
    vi.clearAllMocks();
  });

  // -------------------------------------------------------------------------
  // resolvePromptForRun — snapshot-first path (R11.2)
  // -------------------------------------------------------------------------

  describe("resolvePromptForRun — snapshot-first path", () => {
    it("returns the pinned snapshot triple without consulting the live store when prompts.{key} is present (R11.2)", async () => {
      const pinned = makePinnedSnapshot();
      store.getSnapshot.mockResolvedValue(
        makeSnapshot({ [PROMPT_KEY]: pinned } as Record<
          PromptKey,
          ResolvedPromptSnapshot
        >),
      );

      const resolved = await resolvePromptForRun(PROMPT_KEY, RUN_ID);

      // The runtime returned exactly the pinned values, not the
      // registry default — proves the snapshot path won.
      expect(resolved.promptKey).toBe(PROMPT_KEY);
      expect(resolved.text).toBe(pinned.text);
      expect(resolved.modelKey).toBe(pinned.modelKey);
      expect(resolved.modelId).toBe(pinned.modelId);
      expect(resolved.inferenceParameters).toEqual(pinned.inferenceParameters);
      expect(resolved.version).toBe(pinned.version);
      expect(resolved.capabilityProfile).toBe(
        CAPABILITY_PROFILES[pinned.capabilityProfileKey],
      );

      // Snapshot read happened exactly once; live store was never
      // consulted.
      expect(store.getSnapshot).toHaveBeenCalledTimes(1);
      expect(store.getSnapshot).toHaveBeenCalledWith(RUN_ID);
      expect(store.listPromptOverrides).not.toHaveBeenCalled();
    });
  });

  // -------------------------------------------------------------------------
  // resolvePromptForRun — live-fallback path (R11.4 / R16.2)
  // -------------------------------------------------------------------------

  describe("resolvePromptForRun — live-fallback path", () => {
    it("falls back to the live store and emits an info log when the snapshot lacks a prompts field (pre-feature snapshot)", async () => {
      // Pre-feature snapshot — no `prompts` field at all.
      store.getSnapshot.mockResolvedValue(makeSnapshot(undefined));
      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>(),
      );

      const resolved = await resolvePromptForRun(PROMPT_KEY, RUN_ID);

      // The fallback resolved through the live store and produced the
      // bundled-default triple for `failure_analysis`.
      const def = PROMPT_REGISTRY[PROMPT_KEY];
      expect(resolved.text).toBe(def.defaultText);
      expect(resolved.modelKey).toBe(def.defaultModelKey);
      expect(resolved.version).toBe(0);

      expect(store.getSnapshot).toHaveBeenCalledTimes(1);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(1);

      // Structured info log named the reason for the fall-through.
      expect(infoSpy).toHaveBeenCalled();
      const infoMessages = infoSpy.mock.calls.map((call) => String(call[0]));
      expect(
        infoMessages.some((msg) =>
          msg.includes("predates the prompt-management feature"),
        ),
      ).toBe(true);
    });

    it("falls back to the live store and emits an info log when the snapshot has prompts but no entry for this key", async () => {
      // Post-feature snapshot whose `prompts` map exists but doesn't
      // pin the requested key — e.g. a new prompt added between run
      // start and the callsite executing.
      store.getSnapshot.mockResolvedValue(
        makeSnapshot({} as Record<PromptKey, ResolvedPromptSnapshot>),
      );
      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>(),
      );

      const resolved = await resolvePromptForRun(PROMPT_KEY, RUN_ID);

      const def = PROMPT_REGISTRY[PROMPT_KEY];
      expect(resolved.text).toBe(def.defaultText);
      expect(resolved.version).toBe(0);

      expect(store.getSnapshot).toHaveBeenCalledTimes(1);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(1);

      const infoMessages = infoSpy.mock.calls.map((call) => String(call[0]));
      expect(
        infoMessages.some((msg) =>
          msg.includes("has prompts map but no entry for promptKey"),
        ),
      ).toBe(true);
    });

    it("falls back to the live store and emits an info log when no snapshot exists (getSnapshot returns null)", async () => {
      store.getSnapshot.mockResolvedValue(null);
      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>(),
      );

      const resolved = await resolvePromptForRun(PROMPT_KEY, RUN_ID);

      const def = PROMPT_REGISTRY[PROMPT_KEY];
      expect(resolved.text).toBe(def.defaultText);
      expect(resolved.version).toBe(0);

      expect(store.getSnapshot).toHaveBeenCalledTimes(1);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(1);

      const infoMessages = infoSpy.mock.calls.map((call) => String(call[0]));
      expect(
        infoMessages.some((msg) =>
          msg.includes("No snapshot found for runId"),
        ),
      ).toBe(true);
    });

    it("falls back to the live store and emits a warning log when the snapshot read throws", async () => {
      const ddbError = new Error("DynamoDB timeout");
      store.getSnapshot.mockRejectedValue(ddbError);
      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>(),
      );

      const resolved = await resolvePromptForRun(PROMPT_KEY, RUN_ID);

      const def = PROMPT_REGISTRY[PROMPT_KEY];
      expect(resolved.text).toBe(def.defaultText);

      expect(store.getSnapshot).toHaveBeenCalledTimes(1);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(1);

      // Warning log named the snapshot read failure (rather than an
      // info log naming the missing-field reason).
      expect(warnSpy).toHaveBeenCalled();
      const warnMessages = warnSpy.mock.calls.map((call) => String(call[0]));
      expect(
        warnMessages.some((msg) =>
          msg.includes("Snapshot read failed for runId"),
        ),
      ).toBe(true);
    });
  });

  // -------------------------------------------------------------------------
  // resolvePromptForRun — fail-closed path (R16.3)
  // -------------------------------------------------------------------------

  describe("resolvePromptForRun — fail-closed path", () => {
    it("throws PromptResolutionError with the underlying cause attached when both reads fail (R16.3)", async () => {
      const snapshotError = new Error("Snapshot DDB unavailable");
      const liveError = new Error("Live store DDB unavailable");
      store.getSnapshot.mockRejectedValue(snapshotError);
      store.listPromptOverrides.mockRejectedValue(liveError);

      let captured: unknown = null;
      try {
        await resolvePromptForRun(PROMPT_KEY, RUN_ID);
      } catch (err) {
        captured = err;
      }

      expect(captured).toBeInstanceOf(PromptResolutionError);
      const promptErr = captured as PromptResolutionError;
      expect(promptErr.promptKey).toBe(PROMPT_KEY);
      expect(promptErr.runId).toBe(RUN_ID);

      // The most recent failure (the live read) is attached as the
      // cause. The runtime wraps the live store's failure in its own
      // PromptResolutionError first, so the outer error's `cause` is
      // that inner PromptResolutionError, whose `cause` in turn is the
      // raw DDB error. Walking one hop down the chain gives the
      // underlying transport error, which is the contract callsites
      // need to log.
      const outerCause = (promptErr as Error & { cause?: unknown }).cause;
      expect(outerCause).toBeInstanceOf(PromptResolutionError);
      const innerCause = (outerCause as Error & { cause?: unknown }).cause;
      expect(innerCause).toBe(liveError);
    });
  });

  // -------------------------------------------------------------------------
  // resolvePromptLive — cache behaviour (R16.2 / R16.3)
  // -------------------------------------------------------------------------

  describe("resolvePromptLive — cache behaviour", () => {
    it("shares one DDB read across two consecutive calls within 30s of each other", async () => {
      vi.useFakeTimers();
      vi.setSystemTime(new Date("2024-06-01T00:00:00.000Z"));

      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>(),
      );

      // First call — populates the cache.
      await resolvePromptLive(PROMPT_KEY);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(1);

      // Advance just under the TTL — second call hits the cache.
      vi.setSystemTime(new Date("2024-06-01T00:00:25.000Z"));
      await resolvePromptLive(PROMPT_KEY);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(1);
    });

    it("issues two DDB reads when calls are 31s apart (cache TTL elapsed)", async () => {
      vi.useFakeTimers();
      vi.setSystemTime(new Date("2024-06-01T00:00:00.000Z"));

      store.listPromptOverrides.mockResolvedValue(
        new Map<PromptKey, PromptOverride>(),
      );

      // First call — populates the cache.
      await resolvePromptLive(PROMPT_KEY);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(1);

      // Advance past the 30s TTL — cache entry expired, second call
      // refetches.
      vi.setSystemTime(new Date("2024-06-01T00:00:31.000Z"));
      await resolvePromptLive(PROMPT_KEY);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(2);
    });

    it("fail-closed: live read failure resets the cache and throws PromptResolutionError", async () => {
      // Seed the cache with a successful read so we can observe that
      // the next failed read does not return the prior cached value.
      store.listPromptOverrides.mockResolvedValueOnce(
        new Map<PromptKey, PromptOverride>(),
      );
      await resolvePromptLive(PROMPT_KEY);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(1);

      // Force the cache entry to be considered stale on the next call
      // by rolling time forward past the TTL, then arrange the next
      // read to throw.
      vi.useFakeTimers();
      vi.setSystemTime(new Date("3000-01-01T00:00:00.000Z"));

      const ddbError = new Error("DynamoDB unavailable");
      store.listPromptOverrides.mockRejectedValueOnce(ddbError);

      let captured: unknown = null;
      try {
        await resolvePromptLive(PROMPT_KEY);
      } catch (err) {
        captured = err;
      }

      expect(captured).toBeInstanceOf(PromptResolutionError);
      const promptErr = captured as PromptResolutionError;
      expect(promptErr.promptKey).toBe(PROMPT_KEY);
      expect((promptErr as Error & { cause?: unknown }).cause).toBe(ddbError);

      // The cache was reset by the failure: a subsequent successful
      // read must hit DDB again rather than returning a stale value.
      store.listPromptOverrides.mockResolvedValueOnce(
        new Map<PromptKey, PromptOverride>(),
      );
      await resolvePromptLive(PROMPT_KEY);
      expect(store.listPromptOverrides).toHaveBeenCalledTimes(3);
    });
  });
});
