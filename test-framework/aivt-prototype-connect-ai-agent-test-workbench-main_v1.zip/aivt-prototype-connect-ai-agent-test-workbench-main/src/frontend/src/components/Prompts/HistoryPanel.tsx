/**
 * Change-history panel for the per-prompt detail page.
 *
 * Implements task 13.7 of the prompt-management feature plan and the
 * following requirement:
 *
 *   - R14.5 — render below the editor as a Cloudscape `ExpandableSection`.
 *     On expand, refetch the parent's prompt detail (`GET /prompts/{key}`)
 *     AND the history list (`GET /prompts/{key}/history`) in parallel so
 *     the list cannot show entries fresher than the editor's "current
 *     version" badge. Each row exposes a `View` affordance that swaps the
 *     right-pane viewer from `defaultText` to that historical entry's
 *     text WITHOUT mutating the editor's draft state — viewing history
 *     must never accidentally overwrite an in-flight edit.
 *
 * The parent ({@link PromptDetailPage}) owns:
 *
 *   1. The right-pane viewer's source-of-truth (default text vs.
 *      historical entry's text). The panel surfaces clicks via the
 *      `onViewHistorical`/`onClearHistorical` props; the parent
 *      decides what to render.
 *
 *   2. The "currently-viewing" version pointer (`viewingVersion`) so the
 *      panel can render a `Clear view` button on the matching row when
 *      that row is the one currently being viewed.
 *
 *   3. Re-fetching the prompt detail on expand. The panel calls
 *      `onExpand()` BEFORE its own history fetch so the two requests
 *      execute in parallel; the parent's fetch updates the editor's
 *      "current version" badge while the panel populates its rows.
 *
 * The panel itself owns:
 *
 *   - The expanded/collapsed state of the `ExpandableSection`.
 *   - The history fetch lifecycle (loading, error, entries).
 *   - The mapping of {@link PromptApiError} structured codes to inline
 *     error text (delegated to {@link describePromptError}).
 *
 * Errors from the history fetch are surfaced as a Cloudscape `Alert`
 * inside the expanded section so they can be retried by collapsing
 * and re-expanding without disturbing the rest of the page. We
 * intentionally do NOT crash to the page's load-failure state on a
 * history fetch error — the editor remains usable even when the
 * history endpoint is unreachable.
 *
 * @module frontend/components/Prompts/HistoryPanel
 */

import { useCallback, useState } from 'react';
import Alert from '@cloudscape-design/components/alert';
import Badge from '@cloudscape-design/components/badge';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Spinner from '@cloudscape-design/components/spinner';
import Table, { type TableProps } from '@cloudscape-design/components/table';
import {
  getHistory,
  type HistoryEntry,
} from '../../api';
import { PromptApiError } from '../../api/prompts';
import type { PromptKey } from '../../../../shared/types';
import { describePromptError, formatTimestamp } from './utils';

export interface HistoryPanelProps {
  /** The promptKey whose history to load. */
  promptKey: PromptKey;
  /**
   * Called when the panel is expanded so the parent can refetch the
   * prompt detail in parallel with the history fetch (R14.5 staleness
   * guard). The parent's fetch and the panel's history fetch happen
   * concurrently — `onExpand` is invoked synchronously before the
   * panel awaits its own request.
   */
  onExpand: () => void;
  /** Called when the user clicks "View" on a history row. */
  onViewHistorical: (entry: HistoryEntry) => void;
  /** Called when the user clears the historical view (returns to default). */
  onClearHistorical: () => void;
  /**
   * The version currently being viewed in the right-pane viewer, or
   * `null` when the viewer is showing the bundled default. Used to
   * render a `Clear view` button on the matching row.
   */
  viewingVersion: number | null;
}

export function HistoryPanel({
  promptKey,
  onExpand,
  onViewHistorical,
  onClearHistorical,
  viewingVersion,
}: HistoryPanelProps): JSX.Element {
  const [expanded, setExpanded] = useState(false);
  const [entries, setEntries] = useState<HistoryEntry[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * Refetch the history list. R14.5 also requires refetching the prompt
   * detail in parallel; we delegate that to the parent via `onExpand()`
   * which is invoked synchronously before this awaitable returns —
   * giving the two requests genuine parallelism rather than serialising
   * them through the panel.
   */
  const refetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      onExpand();
      const response = await getHistory(promptKey);
      setEntries(response.history);
    } catch (err) {
      if (err instanceof PromptApiError) {
        setError(describePromptError(err));
      } else if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Failed to load history.');
      }
    } finally {
      setLoading(false);
    }
  }, [promptKey, onExpand]);

  const handleChange = (next: boolean) => {
    setExpanded(next);
    if (next) {
      refetch();
    }
  };

  const columnDefinitions: TableProps.ColumnDefinition<HistoryEntry>[] = [
    {
      id: 'version',
      header: 'Version',
      cell: (item) => item.version,
    },
    {
      id: 'modifiedAt',
      header: 'Modified at',
      cell: (item) => formatTimestamp(item.modifiedAt),
    },
    {
      id: 'modifiedBy',
      header: 'Modified by',
      // Prefer the captured display-hint email over the stable UUID;
      // see the matching cell in `PromptsListPage` for the rationale.
      cell: (item) => item.modifiedByEmail ?? item.modifiedBy,
    },
    {
      id: 'changeKind',
      header: 'Change',
      cell: (item) => (
        <Badge color={item.changeKind === 'reset' ? 'grey' : 'blue'}>
          {item.changeKind}
        </Badge>
      ),
    },
    {
      id: 'modelKey',
      header: 'Model',
      cell: (item) => item.modelKey,
    },
    {
      id: 'view',
      header: 'View',
      cell: (item) => {
        const isViewing = viewingVersion === item.version;
        return isViewing ? (
          <Button onClick={onClearHistorical}>Clear view</Button>
        ) : (
          <Button onClick={() => onViewHistorical(item)}>View</Button>
        );
      },
    },
  ];

  return (
    <ExpandableSection
      headerText="Change history"
      expanded={expanded}
      onChange={({ detail }) => handleChange(detail.expanded)}
    >
      <SpaceBetween size="s">
        {error && <Alert type="error">{error}</Alert>}
        {loading ? (
          <Box textAlign="center" padding="m">
            <Spinner /> Loading history…
          </Box>
        ) : (
          <Table
            columnDefinitions={columnDefinitions}
            items={entries ?? []}
            trackBy="version"
            empty={
              <Box textAlign="center" color="inherit" padding="m">
                No history entries yet. The prompt is on its bundled default.
              </Box>
            }
          />
        )}
      </SpaceBetween>
    </ExpandableSection>
  );
}
