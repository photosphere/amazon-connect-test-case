/**
 * Prompt detail/edit page.
 *
 * Implements Requirements 14.1, 14.3, 14.4, and 14.6 of the
 * prompt-management feature:
 *
 *   - R14.1: render the prompt's `name`, `description`, `category`,
 *     current effective `modelId`, the editable `effectiveText`, the
 *     read-only `defaultText` viewer alongside it, the `placeholders[]`
 *     chip list with descriptions, and the form fields for the
 *     resolved model's accepted inference parameters.
 *
 *   - R14.3: on Save, `PUT` only the fields the user actually changed
 *     (sparse body), render any HTTP 400 validation error inline, and
 *     refetch on 200 so `version` and `lastModifiedAt` stay current.
 *
 *   - R14.4: on Revert to default, prompt for confirmation, then
 *     `POST /reset` with `{ confirm: true }` and refetch.
 *
 *   - R14.6: poll `GET /prompts/active-runs` once on mount and once
 *     before submitting an edit/reset; if `count > 0`, surface the
 *     "Saved. The change will not affect runs already in progress…"
 *     Flashbar after a successful save so the user is not surprised
 *     by Run_Snapshot pinning.
 *
 * The `ModelSelector` is lifted into its own file under
 * `components/Prompts/ModelSelector.tsx` (task 13.5), the
 * `InferenceParameterForm` is lifted into
 * `components/Prompts/InferenceParameterForm.tsx` (task 13.6), the
 * `HistoryPanel` is lifted into `components/Prompts/HistoryPanel.tsx`
 * (task 13.7), and the `RevertConfirmModal` and `ActiveRunsFlashbar`
 * are lifted into their own files under `components/Prompts/`
 * (task 13.8); all of them are imported here.
 */

import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Alert from '@cloudscape-design/components/alert';
import Badge from '@cloudscape-design/components/badge';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import Container from '@cloudscape-design/components/container';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Form from '@cloudscape-design/components/form';
import FormField from '@cloudscape-design/components/form-field';
import Header from '@cloudscape-design/components/header';
import KeyValuePairs from '@cloudscape-design/components/key-value-pairs';
import SpaceBetween from '@cloudscape-design/components/space-between';
import StatusIndicator from '@cloudscape-design/components/status-indicator';
import Textarea from '@cloudscape-design/components/textarea';
import {
  ApiClientError,
  getActiveRuns,
  getPrompt,
  resetPrompt,
  updatePrompt,
  type GetPromptResponse,
  type HistoryEntry,
  type UpdatePromptRequest,
} from '../api';
import { PromptApiError } from '../api/prompts';
import {
  ActiveRunsFlashbar,
  HistoryPanel,
  InferenceParameterForm,
  ModelSelector,
  RevertConfirmModal,
  describePromptError,
  formatTimestamp,
} from '../components/Prompts';
import type {
  ModelKey,
  PromptKey,
} from '../../../shared/types';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Shallow equality on `Record<string, unknown>` keyed sets; used to
 * decide whether to send `inferenceParameters` in a sparse PUT body.
 * Order-independent: we compare the union of keys plus per-key value
 * equality using JSON.stringify (parameters are pure data — numbers,
 * strings, string arrays — so structural compare via stringify is
 * faithful and avoids pulling in lodash for one call).
 */
function inferenceParametersEqual(
  a: Record<string, unknown>,
  b: Record<string, unknown>,
): boolean {
  const aKeys = Object.keys(a);
  const bKeys = Object.keys(b);
  if (aKeys.length !== bKeys.length) return false;
  for (const k of aKeys) {
    if (!(k in b)) return false;
    if (JSON.stringify(a[k]) !== JSON.stringify(b[k])) return false;
  }
  return true;
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------

export function PromptDetailPage(): JSX.Element {
  const navigate = useNavigate();
  const { promptKey: rawPromptKey } = useParams<{ promptKey: string }>();
  // Cast to PromptKey for downstream typed calls. The backend validates
  // the key against the registry; an unknown key returns 404 and we
  // surface that as the load-failure state.
  const promptKey = (rawPromptKey ?? '') as PromptKey;

  // ---- Detail load state ---------------------------------------------
  const [detail, setDetail] = useState<GetPromptResponse | null>(null);
  const [loading, setLoading] = useState(true);
  // `refetching` is the background-refresh sibling to `loading`. The
  // top-level "Loading prompt…" placeholder reads only `loading`, so a
  // background refetch (the R14.5 staleness guard fired on history
  // expand) keeps the editor visible. See {@link fetchDetail}.
  const [, setRefetching] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  // ---- Editor draft (mutated by the user) -----------------------------
  const [draftText, setDraftText] = useState('');
  const [draftModelKey, setDraftModelKey] = useState<ModelKey | null>(null);
  const [draftInferenceParameters, setDraftInferenceParameters] = useState<
    Record<string, unknown>
  >({});

  // ---- Save / reset transient state -----------------------------------
  const [saving, setSaving] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [revertModalVisible, setRevertModalVisible] = useState(false);

  // ---- R14.6 active-runs notice ---------------------------------------
  const [activeRunsCount, setActiveRunsCount] = useState<number>(0);
  const [activeRunsNoticeVisible, setActiveRunsNoticeVisible] = useState(false);

  // ---- R5.5 model-switch removed-keys notice --------------------------
  // Tracks the inferenceParameter keys most recently dropped by a model
  // switch. The selector strips them from the draft on change; this
  // state drives a Cloudscape Alert so the user knows what was removed
  // and can decide whether to undo the model switch before saving. The
  // list is cleared on save, on reset, and when the user dismisses the
  // alert; subsequent model switches REPLACE the list rather than
  // appending so the message reflects only the most recent change.
  const [modelSwitchRemovedKeys, setModelSwitchRemovedKeys] = useState<
    string[]
  >([]);

  // ---- R14.5 historical-view state ------------------------------------
  // When the user clicks "View" on a history entry the right pane swaps
  // from `defaultText` to the historical entry's text. The editor (left
  // pane) is NOT mutated — viewing history must never accidentally
  // overwrite the user's in-flight edit.
  const [viewingHistorical, setViewingHistorical] = useState<HistoryEntry | null>(null);

  // ---- Fetchers --------------------------------------------------------

  /**
   * Refetch the prompt detail and seed the editor's draft state. Called
   * on mount, after a successful save, after a successful revert, and
   * (per R14.5) when the history panel is expanded.
   *
   * `mode` controls whether the refetch blanks the page or runs in the
   * background:
   *
   *   - `"initial"` (default) flips the top-level `loading` flag to
   *     `true` so the page renders its full-page "Loading prompt…"
   *     placeholder. Used on first mount, on retry after a load error,
   *     and after save/reset where the user has triggered a write and
   *     a brief flash is expected.
   *   - `"background"` leaves `loading` alone and only flips a separate
   *     `refetching` indicator. Used when the history panel is
   *     expanded (R14.5 staleness guard) so the page does not
   *     unmount the open ExpandableSection — flipping `loading` would
   *     cause the panel's `expanded` state to reset on remount and
   *     produce a "page reload" UX.
   */
  const fetchDetail = useCallback(
    async (mode: 'initial' | 'background' = 'initial') => {
      if (mode === 'initial') {
        setLoading(true);
      } else {
        setRefetching(true);
      }
      setLoadError(null);
      try {
        const response = await getPrompt(promptKey);
        setDetail(response);
        setDraftText(response.effectiveText);
        setDraftModelKey(response.currentModelKey);
        setDraftInferenceParameters({ ...response.inferenceParameters });
        setViewingHistorical(null);
        // Re-syncing with the server snapshots makes any prior draft-only
        // model switch moot — the alert that surfaces the dropped keys
        // belongs only to the in-flight draft. Clearing it here keeps the
        // notice from "ghosting" past a successful save or reset.
        setModelSwitchRemovedKeys([]);
      } catch (err) {
        if (err instanceof PromptApiError) {
          setLoadError(describePromptError(err));
        } else if (err instanceof ApiClientError) {
          setLoadError(err.message);
        } else if (err instanceof Error) {
          setLoadError(err.message);
        } else {
          setLoadError('Failed to load prompt.');
        }
        // Background refetches must not blank an existing detail — the
        // user is mid-task. Surface the error via setLoadError above
        // (currently silenced for background mode by leaving detail
        // intact) and keep the prior detail visible.
        if (mode === 'initial') {
          setDetail(null);
        }
      } finally {
        if (mode === 'initial') {
          setLoading(false);
        } else {
          setRefetching(false);
        }
      }
    },
    [promptKey],
  );

  /**
   * Fetch the active-runs count. Called once on mount and once before
   * each save / reset so the R14.6 notice surfaces only when the count
   * was non-zero at submit time. We use a separate fetch (rather than
   * caching the mount value) because runs may finish or start between
   * mount and submit, and the requirement is keyed on submit-time state.
   */
  const fetchActiveRuns = useCallback(async () => {
    try {
      const response = await getActiveRuns();
      setActiveRunsCount(response.count);
      return response.count;
    } catch {
      // Best-effort — never block save/reset on a missing active-runs
      // count. The notice is purely informational.
      return 0;
    }
  }, []);

  // Initial load.
  useEffect(() => {
    fetchDetail();
    fetchActiveRuns();
  }, [fetchDetail, fetchActiveRuns]);

  // ---- Derived state ---------------------------------------------------

  /** The full `AllowedModelEntry` for the currently-drafted model. */
  const resolvedDraftModel = useMemo(() => {
    if (!detail || !draftModelKey) return undefined;
    return detail.allowedModels.find((m) => m.modelKey === draftModelKey);
  }, [detail, draftModelKey]);

  /** True when the user has actually changed something the API would persist. */
  const hasUnsavedChanges = useMemo(() => {
    if (!detail) return false;
    if (draftText !== detail.effectiveText) return true;
    if (draftModelKey !== detail.currentModelKey) return true;
    if (
      !inferenceParametersEqual(
        draftInferenceParameters,
        detail.inferenceParameters,
      )
    )
      return true;
    return false;
  }, [detail, draftText, draftModelKey, draftInferenceParameters]);

  /** Build a sparse PUT body containing only the changed fields (R14.3). */
  const buildUpdateBody = useCallback((): UpdatePromptRequest => {
    if (!detail) return {};
    const body: UpdatePromptRequest = {};
    if (draftText !== detail.effectiveText) {
      body.text = draftText;
    }
    if (draftModelKey && draftModelKey !== detail.currentModelKey) {
      body.modelKey = draftModelKey;
    }
    if (
      !inferenceParametersEqual(
        draftInferenceParameters,
        detail.inferenceParameters,
      )
    ) {
      body.inferenceParameters = draftInferenceParameters;
    }
    return body;
  }, [detail, draftText, draftModelKey, draftInferenceParameters]);

  // ---- Save handler (R14.3) -------------------------------------------

  const handleSave = useCallback(async () => {
    if (!detail || !hasUnsavedChanges) return;
    setSaving(true);
    setSaveError(null);
    setActiveRunsNoticeVisible(false);
    // Refetch active runs RIGHT BEFORE submit so the notice keys on the
    // submit-time count, not the mount-time one.
    const submitTimeCount = await fetchActiveRuns();
    try {
      await updatePrompt(promptKey, buildUpdateBody());
      // Refetch on 200 so `version` and `lastModifiedAt` reflect the
      // server-generated values and the editor's draft state is reset
      // to "in sync".
      await fetchDetail();
      if (submitTimeCount > 0) {
        setActiveRunsNoticeVisible(true);
      }
    } catch (err) {
      if (err instanceof PromptApiError) {
        setSaveError(describePromptError(err));
      } else if (err instanceof ApiClientError) {
        setSaveError(err.message);
      } else if (err instanceof Error) {
        setSaveError(err.message);
      } else {
        setSaveError('Failed to save prompt.');
      }
    } finally {
      setSaving(false);
    }
  }, [
    detail,
    hasUnsavedChanges,
    promptKey,
    buildUpdateBody,
    fetchDetail,
    fetchActiveRuns,
  ]);

  // ---- Reset handler (R14.4) ------------------------------------------

  const handleConfirmReset = useCallback(async () => {
    setResetting(true);
    setSaveError(null);
    setActiveRunsNoticeVisible(false);
    const submitTimeCount = await fetchActiveRuns();
    try {
      await resetPrompt(promptKey);
      await fetchDetail();
      setRevertModalVisible(false);
      if (submitTimeCount > 0) {
        setActiveRunsNoticeVisible(true);
      }
    } catch (err) {
      if (err instanceof PromptApiError) {
        setSaveError(describePromptError(err));
      } else if (err instanceof ApiClientError) {
        setSaveError(err.message);
      } else if (err instanceof Error) {
        setSaveError(err.message);
      } else {
        setSaveError('Failed to reset prompt.');
      }
    } finally {
      setResetting(false);
    }
  }, [promptKey, fetchDetail, fetchActiveRuns]);

  // ---- Render branches -------------------------------------------------

  if (loading) {
    return (
      <ContentLayout
        header={
          <Header variant="h1" description="Loading prompt…">
            Prompt
          </Header>
        }
      >
        <Box textAlign="center" padding="xl">
          <StatusIndicator type="loading">Loading prompt…</StatusIndicator>
        </Box>
      </ContentLayout>
    );
  }

  if (loadError || !detail) {
    return (
      <ContentLayout
        header={
          <Header
            variant="h1"
            actions={
              <Button onClick={() => navigate('/prompts')}>Back to prompts</Button>
            }
          >
            Prompt
          </Header>
        }
      >
        <Alert
          type="error"
          header="Could not load prompt"
          action={<Button onClick={() => fetchDetail()}>Retry</Button>}
        >
          {loadError ?? 'The prompt could not be loaded.'}
        </Alert>
      </ContentLayout>
    );
  }

  // ---- Loaded state — full detail render ------------------------------

  // The right-pane viewer either shows the bundled `defaultText` (the
  // normal case) or a historical entry's text when the user has clicked
  // a history "View" button. The label updates so the user always knows
  // which version they're seeing.
  const viewerLabel = viewingHistorical
    ? `Historical text — version ${viewingHistorical.version}`
    : 'Bundled default text (read-only)';
  const viewerText = viewingHistorical
    ? viewingHistorical.text
    : detail.defaultText;

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description={detail.description}
          actions={
            <SpaceBetween direction="horizontal" size="xs">
              <Button onClick={() => navigate('/prompts')}>Back to prompts</Button>
            </SpaceBetween>
          }
        >
          {detail.name}
        </Header>
      }
    >
      <SpaceBetween size="l">
        <ActiveRunsFlashbar
          visible={activeRunsNoticeVisible}
          onDismiss={() => setActiveRunsNoticeVisible(false)}
        />

        {saveError && (
          <Alert
            type="error"
            dismissible
            onDismiss={() => setSaveError(null)}
            header="The platform refused this change"
          >
            {saveError}
          </Alert>
        )}

        {modelSwitchRemovedKeys.length > 0 && (
          <Alert
            type="warning"
            dismissible
            onDismiss={() => setModelSwitchRemovedKeys([])}
            header="Inference parameters dropped to match the new model"
          >
            The selected model's capability profile does not accept the
            following inference parameter
            {modelSwitchRemovedKeys.length === 1 ? '' : 's'}, so they were
            removed from the draft:{' '}
            <strong>{modelSwitchRemovedKeys.join(', ')}</strong>. Switch back
            to the previous model to restore them, or save to persist the
            change.
          </Alert>
        )}

        {activeRunsCount > 0 && !activeRunsNoticeVisible && (
          <Alert type="info" header="Test run in progress">
            {activeRunsCount === 1
              ? '1 run is currently in progress. '
              : `${activeRunsCount} runs are currently in progress. `}
            Saving this prompt will not affect them — the change applies to the
            next run started.
          </Alert>
        )}

        <Container header={<Header variant="h2">Overview</Header>}>
          <KeyValuePairs
            columns={4}
            items={[
              {
                label: 'Prompt key',
                value: detail.promptKey,
              },
              {
                label: 'Category',
                value: detail.category,
              },
              {
                label: 'Current model',
                value: resolvedDraftModel?.displayName ?? draftModelKey ?? '—',
              },
              {
                label: 'Status',
                value: detail.isOverridden ? (
                  <Badge color="blue">Override (v{detail.version})</Badge>
                ) : (
                  <Badge color="grey">Default</Badge>
                ),
              },
              {
                label: 'Last modified',
                value: formatTimestamp(detail.lastModifiedAt),
              },
              {
                label: 'Last modified by',
                value:
                  detail.lastModifiedByEmail ??
                  detail.lastModifiedBy ??
                  '—',
              },
            ]}
          />
        </Container>

        {/* Placeholders chip list (R14.1) — render the prompt's declared
            template tokens with their descriptions so the user can see
            what must remain in the text. The chips are intentionally
            non-interactive; they exist for discoverability only. */}
        <Container header={<Header variant="h3">Placeholders</Header>}>
          {detail.placeholders.length === 0 ? (
            <Box color="text-body-secondary">
              This prompt declares no placeholders.
            </Box>
          ) : (
            <SpaceBetween size="xs" direction="horizontal">
              {detail.placeholders.map((p) => (
                <Box key={p.name} margin={{ right: 's', bottom: 'xs' }}>
                  <SpaceBetween size="xxs">
                    <Badge color="green">{`{${p.name}}`}</Badge>
                    <Box variant="small" color="text-body-secondary">
                      {p.description}
                    </Box>
                  </SpaceBetween>
                </Box>
              ))}
            </SpaceBetween>
          )}
        </Container>

        {/* Side-by-side editor / read-only viewer (R14.1). Cloudscape's
            full SplitPanel widget is part of the AppLayout shell which we
            don't reach into here — a two-column ColumnLayout produces the
            same visual structure with much less coupling and lets the
            editor and viewer scroll independently when the page itself
            overflows. */}
        <Container header={<Header variant="h2">Prompt text</Header>}>
          <ColumnLayout columns={2}>
            <FormField
              label="Effective text (editable)"
              description="Edit the prompt the platform sends to Bedrock. Required placeholders must remain present in the text."
            >
              <Textarea
                value={draftText}
                onChange={({ detail: d }) => setDraftText(d.value)}
                rows={20}
                disabled={saving || resetting}
              />
            </FormField>
            <FormField label={viewerLabel}>
              <Textarea value={viewerText} readOnly rows={20} />
              {viewingHistorical && (
                <Box padding={{ top: 'xs' }}>
                  <Button onClick={() => setViewingHistorical(null)}>
                    Show bundled default
                  </Button>
                </Box>
              )}
            </FormField>
          </ColumnLayout>
        </Container>

        <Container
          header={<Header variant="h2">Model and inference parameters</Header>}
        >
          <Form
            actions={
              <SpaceBetween direction="horizontal" size="xs">
                <Button
                  onClick={() => setRevertModalVisible(true)}
                  disabled={!detail.isOverridden || saving || resetting}
                >
                  Revert to default
                </Button>
                <Button
                  variant="primary"
                  onClick={handleSave}
                  loading={saving}
                  disabled={!hasUnsavedChanges || saving || resetting}
                >
                  Save
                </Button>
              </SpaceBetween>
            }
          >
            <SpaceBetween size="m">
              <FormField
                label="Model"
                description="Select which Bedrock model resolves this prompt. The list is constrained to the prompt's allowed models."
              >
                <ModelSelector
                  allowedModels={detail.allowedModels}
                  selectedModelKey={draftModelKey ?? detail.currentModelKey}
                  currentInferenceParameters={draftInferenceParameters}
                  onChange={(next, removedKeys) => {
                    setDraftModelKey(next);
                    if (removedKeys.length > 0) {
                      // Strip the now-forbidden keys from the draft so a
                      // subsequent save doesn't trip MODEL_FORBIDS_KEY,
                      // and surface the alert (R5.5).
                      setDraftInferenceParameters((prev) => {
                        const next: Record<string, unknown> = { ...prev };
                        for (const key of removedKeys) delete next[key];
                        return next;
                      });
                      setModelSwitchRemovedKeys(removedKeys);
                    }
                  }}
                  disabled={saving || resetting}
                />
              </FormField>
              <InferenceParameterForm
                schema={detail.inferenceParameterSchema}
                values={draftInferenceParameters}
                resolvedModel={resolvedDraftModel}
                onChange={(next) => setDraftInferenceParameters(next)}
                disabled={saving || resetting}
              />
            </SpaceBetween>
          </Form>
        </Container>

        <HistoryPanel
          promptKey={promptKey}
          onExpand={() => {
            // R14.5 staleness guard — re-pull the detail in parallel
            // with the history fetch so the editor's "current" version
            // cannot drift behind the history list. Use the
            // background-refetch path so the page does NOT blank to
            // the "Loading prompt…" placeholder mid-expand (which
            // unmounts the panel and looks like a page reload).
            fetchDetail('background');
          }}
          onViewHistorical={(entry) => setViewingHistorical(entry)}
          onClearHistorical={() => setViewingHistorical(null)}
          viewingVersion={viewingHistorical?.version ?? null}
        />

        <RevertConfirmModal
          visible={revertModalVisible}
          promptName={detail.name}
          loading={resetting}
          onConfirm={handleConfirmReset}
          onCancel={() => setRevertModalVisible(false)}
        />
      </SpaceBetween>
    </ContentLayout>
  );
}
