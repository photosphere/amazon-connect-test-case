# Implementation Plan: Bedrock-Judge Evaluations

## Overview

This plan replaces the AgentCore Evaluate integration delivered in `platform-hosting-and-evaluations` Workstream 2 with a direct Bedrock Converse + AWS-published built-in prompt-template integration. The persisted contract (`goalSuccessScore`, `helpfulnessScore`, `toolAccuracyScore` in `[0.0, 1.0]`, `evaluationError`, `RUN#/CASE#` shape) is unchanged; only the scoring backend and the modules that call it change.

The plan is organized so the foundations land first (steering doc, score-scale tables, error-code rename), then the two new pure modules (`judge-prompt-rendering`, `bedrock-judge-client`) with their property tests, then the Lambda/harness rewrite that composes them, then the CDK seam, then golden-prompt snapshot validation against the real `Span_Fixtures`, then cleanup of obsolete AgentCore artifacts.

`scripts/bedrock-judge-probe.ts` is the validated working reference; its logic — the three verbatim prompt templates, the score-scale lookups, `groupTraceIntoTurns`/`renderFullContext`/`renderContextBefore`/`renderAvailableTools`, the `judge`/`extractJson`/`fillTemplate` helpers, and the per-evaluator orchestration loop — is reorganised into the production modules. The probe stays in `scripts/` as documented reference behavior.

These modules from `platform-hosting-and-evaluations` are **reused not rewritten** and have no top-level tasks here:
- `src/shared/utils/evaluation-scoring.ts` — extended (Score_Scale tables added); existing `clamp01`/`aggregateMean`/`aggregateScores` exports unchanged
- `src/shared/utils/evaluation-result.ts` — unchanged except for the `evaluationError.code` enum rename cascading from `types.ts`
- `src/shared/utils/score-comparison.ts` — untouched
- `src/shared/types.ts` — only edit is the `evaluationError.code` enum rename `AGENTCORE_ERROR` → `JUDGE_ERROR`
- Frontend results / comparison views and run-comparison wiring — untouched
- `tests/fixtures/spans/multi-tool-success.json`, `tests/fixtures/spans/failure-escalation.json` — checked-in fixtures reused as-is

Hosting/bootstrap (Workstream 1 of `platform-hosting-and-evaluations`) is owned by that spec and is not in scope here.

Property-based tests use the platform's convention: Vitest + `fast-check`, `{ numRuns: 100 }`, each tagged `// Feature: bedrock-judge-evaluations, Property {n}: {text}`.

## Tasks

- [x] 1. Author the prompt-template steering doc
  - [x] 1.1 Create `.kiro/steering/bedrock-judge-prompts.md`
    - Commit verbatim copies of the three AWS-published built-in prompt templates (`Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, `Builtin.ToolSelectionAccuracy`) lifted byte-for-byte from `scripts/bedrock-judge-probe.ts` (which copied them from `https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html`); above each template record the source URL and the date of the copy
    - Document the three Score_Scale mapping tables next to their templates (GoalSuccessRate `{ Yes: 1.0, No: 0.0 }`; ToolSelectionAccuracy `{ Yes: 1.0, No: 0.0 }`; Helpfulness 7 levels in steps of `1/6`); add the per-case Converse-call formula `1 + N + M` and the indicative `~$0.03–$0.05/case` cost note for the default Judge_Model `us.anthropic.claude-sonnet-4-6`
    - _Requirements: 5.1, 5.2, 5.3, 7.6_

- [x] 2. Land the foundation edits in shared modules
  - [x] 2.1 Rename the `evaluationError.code` enum value `AGENTCORE_ERROR` → `JUDGE_ERROR`
    - Edit `src/shared/types.ts` to rename the union member; cascade the rename through every consumer (`src/shared/utils/evaluation-result.ts`, `src/backend/orchestration/evaluation.ts`, `src/frontend/src/pages/ResultsViewer.tsx`, and any tests still referencing the old name); make no other change to the `evaluationError` shape or to `evaluation-result.ts`
    - _Requirements: 8.2_
  - [x] 2.2 Extend `evaluation-scoring.ts` with the three Score_Scale tables
    - Add `GOAL_SUCCESS_SCALE`, `TOOL_SELECTION_SCALE`, and `HELPFULNESS_SCALE` as exported `Readonly<Record<string, number>>` constants matching the steering-doc tables byte-for-byte; add `mapScoreLabel(scale, label): number | undefined` returning `undefined` for unknown labels (so callers can raise `UNMAPPABLE_RESULT`); leave `clamp01`, `aggregateMean`, `aggregateScores`, and every other existing export untouched
    - _Requirements: 4.1, 4.2, 4.5, 4.6, 5.4_
  - [x] 2.3 Property test for the Score_Scale tables
    - File `tests/unit/properties/score-scale.test.ts`, `{ numRuns: 100 }`, arbitrary label strings (mix of in-scale and synthetic out-of-scale), tagged `// Feature: bedrock-judge-evaluations, Property 3: Score-scale mapping is total and in-range`
    - **Property 3: Score-scale mapping is total and in-range**
    - **Validates: Requirements 4.1, 4.2, 4.4, 8.3**
  - [x] 2.4 Re-tag the carried-over aggregation property tests
    - Update the existing tests in `tests/unit/properties/evaluation-scoring.test.ts` and `tests/unit/properties/evaluation-result.test.ts` so the comment tags read `// Feature: bedrock-judge-evaluations, Property 4: …` (goal direct + arithmetic-mean), `// Feature: bedrock-judge-evaluations, Property 5: …` (every emitted score in `[0,1]`), and `// Feature: bedrock-judge-evaluations, Property 6: …` (error state leaves the right scores unset); update any reference to `AGENTCORE_ERROR` to `JUDGE_ERROR`; do not change the assertions (the underlying modules are reused unchanged)
    - **Property 4: Goal direct + arithmetic-mean aggregation** (carried over)
    - **Property 5: Every emitted score is in [0.0, 1.0]** (carried over)
    - **Property 6: Error state leaves the right scores unset** (carried over)
    - **Validates: Requirements 1.3, 1.4, 1.5, 1.6, 1.9, 8.4, 8.5**

- [x] 3. Implement the pure prompt-rendering module
  - [x] 3.1 Create `src/shared/utils/judge-prompt-rendering.ts`
    - No AWS imports; export `groupTraceIntoTurns(trace, customerTurns)`, `renderContext(turns)`, `renderContextBefore(turns, targetIndex)`, `renderAvailableTools(tools)`, `renderAssistantTurn(step)`, `renderToolTurn(toolInvocation)`, and a `renderJudgePromptContext({ trace, transcript, snapshot, expectedToolNames }): { context, availableTools, assistantTurns: Array<{ index, context, assistantTurn }>, toolTurns: Array<{ index, context, toolTurn }> }` aggregator; preserve chronological order across `User:`/`Assistant:`/`Action:`/`Tool:` lines; render `{available_tools}` as a numbered list of `name`/`description`/`inputSchema`; emit one `{assistant_turn}` per inference step and one `{tool_turn}` per `execute_tool` step formatted `name(JSON.stringify(args))`; build per-unit `{context}` strings as the prefix of all steps strictly before that unit; surface `expectedToolNames` to the GoalSuccessRate and ToolSelectionAccuracy contexts (e.g. an `Expected tools:` annotation appended to those rendered contexts); reorganise the equivalent helpers from `scripts/bedrock-judge-probe.ts`
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7_
  - [x] 3.2 Property test: rendering is deterministic and complete
    - File `tests/unit/properties/judge-prompt-rendering.test.ts`, `{ numRuns: 100 }`, arbitrary `ExecutionTrace`/`TranscriptTurn[]`/`AgentSnapshot`, tagged `// Feature: bedrock-judge-evaluations, Property 1: Prompt rendering is deterministic and complete`
    - **Property 1: Prompt rendering is deterministic and complete**
    - **Validates: Requirements 2.1, 2.2, 11.3**
  - [x] 3.3 Property test: per-turn windowing is prefix-only
    - Same file as 3.2, tagged `// Feature: bedrock-judge-evaluations, Property 2: Per-turn windowing is prefix-only`
    - **Property 2: Per-turn windowing is prefix-only**
    - **Validates: Requirements 2.4**

- [x] 4. Implement the Bedrock judge client
  - [x] 4.1 Create `src/backend/orchestration/bedrock-judge-client.ts`
    - Thin wrapper over `@aws-sdk/client-bedrock-runtime` `ConverseCommand`; expose `judge({ template, vars, timeoutMs }): Promise<{ reasoning: string; score: string }>`; substitute `{key}`-style placeholders into `template` from `vars` (mirror the probe's `fillTemplate`); send one Converse call to the model id from `process.env.JUDGE_MODEL_ID`, with `temperature: 0` and `maxTokens: 1024`; parse the model's fenced-JSON response (mirror the probe's `extractJson`) and validate `{ reasoning: string, score: non-empty string }`; default `timeoutMs` to 60_000; throw a typed `JudgeTimeoutError` on timeout (`AbortController` + `setTimeout`) and a typed `JudgeResponseParseError` on missing/malformed/non-conforming JSON; do not interpret, normalize, or remap the `score` label; export a `_setBedrockClient(client)` test seam mirroring the existing `_setQConnectClient` pattern
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 6.3_
  - [x] 4.2 Unit tests for the judge client
    - File `tests/unit/bedrock-judge-client.test.ts`: timeout → `JudgeTimeoutError`; missing fenced JSON → `JudgeResponseParseError`; malformed JSON inside fenced block → `JudgeResponseParseError`; missing/empty `reasoning` or `score` field → `JudgeResponseParseError`; happy path returns the raw `{ reasoning, score }` unchanged (label not interpreted); model id is read from `JUDGE_MODEL_ID` env var; `_setBedrockClient` injection works without invoking AWS
    - _Requirements: 3.1, 3.3, 3.4, 3.5, 3.6, 6.3_

- [x] 5. Rewrite the Evaluation Lambda to compose the new modules
  - [x] 5.1 Rewrite `src/backend/orchestration/evaluation.ts`
    - Remove every reference to `trace-to-otel`, `agentcore-client`, `callAgentCoreEvaluation`, `computeFallbackScores`, `formatTranscriptForEvaluation`, and any local-scoring fallback path that remained after the previous spec; per case load trace/transcript/snapshot, short-circuit to `Evaluation_Error_State INSUFFICIENT_TRACE` when the trace has zero assistant turns AND zero `execute_tool` entries (no Converse call), otherwise call `renderJudgePromptContext` (task 3.1) and fan out concurrently the `1` GoalSuccessRate, `N` Helpfulness (one per assistant turn), and `M` ToolSelectionAccuracy (one per tool call) Converse calls via `bedrock-judge-client.judge` (task 4.1)
    - Apply a per-case 90s wall-clock budget (`AbortController`) on top of the per-call 60s timeout from task 4.1; on overall timeout map any in-flight failures to `TIMEOUT`; map per-evaluator `JudgeTimeoutError` → `TIMEOUT`, AWS SDK error → `JUDGE_ERROR`, `JudgeResponseParseError` or unknown label → `UNMAPPABLE_RESULT`, and a missing required score after aggregation → `MISSING_EVALUATOR`, each with a human-readable reason carrying the operation/evaluator name
    - Map labels through the Score_Scale tables (task 2.2), aggregate with the existing unchanged `aggregateScores`, clamp emitted scores via the existing unchanged `clamp01`, and assemble each `TestCaseResult` with the existing unchanged `assembleCaseEvaluation`; persist whatever scores were produced even when `Evaluation_Error_State` is set; persist a `TestCaseResult` for every case to `PK=RUN#{runId}`, `SK=CASE#{caseId}`; never fail the run solely because individual cases entered the error state; never compute or persist `toolAccuracyScore` from the local `calculateToolAccuracy` logic
    - Export a reusable `evaluateCaseSession(input)` function so the harness (task 6.1) shares the exact same translate→judge→aggregate→assemble code path
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.9, 2.8, 4.3, 4.4, 7.1, 7.2, 7.3, 7.4, 7.5, 7.7, 8.1, 8.2, 8.3, 8.4, 8.5, 8.7, 8.8_
  - [x] 5.2 Unit tests for the rewritten Lambda
    - Rewrite `tests/unit/evaluation.test.ts` (mocked `bedrock-judge-client` via `_setBedrockClient` + `aws-sdk-client-mock` for DynamoDB): one `judge` call per evaluator unit with the rendered prompt vars (Req 1.1); concurrent fan-out (assert all calls dispatched before any awaits resolve, Req 7.1); per-case 90s budget cancels in-flight calls and persists `TIMEOUT` (Req 7.3); per-call timeout / SDK error / unmappable label / missing evaluator each map to the right `Evaluation_Error_State` code with no local-scoring substitution (Reqs 8.1–8.5, 8.8); partial success persists produced scores plus the error state (Req 8.4); persists to `PK=RUN#{runId}`, `SK=CASE#{caseId}` (Req 1.7); a mixed batch persists all cases and does not fail the run (Req 8.7); `INSUFFICIENT_TRACE` short-circuits without any judge call (Req 2.8)
    - _Requirements: 1.1, 1.7, 2.8, 7.1, 7.3, 8.1, 8.2, 8.3, 8.4, 8.5, 8.7, 8.8_
  - [x] 5.3 Static check: Lambda never imports a local-scoring helper
    - File `tests/unit/evaluation-no-fallback.test.ts` (rewrite of the prior file): assert the `evaluation.ts` source does not import `calculateToolAccuracy`, `tool-accuracy`, `accuracy`, `trace-to-otel`, or `agentcore-client`; assert it does import `bedrock-judge-client` and `judge-prompt-rendering`
    - **Property 7: No local-scoring fallback path**
    - **Validates: Requirements 8.5, 8.8**

- [x] 6. Update the local Evaluation Harness to the new modules
  - [x] 6.1 Rewrite `scripts/evaluation-harness.ts`
    - Swap the AgentCore client for `bedrock-judge-client` and the OTel translator for `judge-prompt-rendering`; CLI takes one arg (transcript file path or Q in Connect session id); file mode loads a transcript or `Span_Fixture`, session mode calls `ListSpans` + `parseSpansToTrace`; both feed the **same** `evaluateCaseSession` exported from task 5.1 and print the three scores plus per-evaluator label + reasoning; use the default AWS credential chain (no hardcoded creds); missing arg / unparseable file / unresolvable or empty session / missing creds / `bedrock:Converse` access-denied / `qconnect:ListSpans` access-denied / judge timeout / judge error each print a clear message naming the operation and exit non-zero with no submission and no local fallback; never make any AWS call other than `bedrock:Converse` and `qconnect:ListSpans` on its normal path
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7, 9.8, 9.9, 10.1, 10.2, 10.3, 10.4, 10.5_
  - [x] 6.2 Unit tests for the harness
    - Rewrite `tests/unit/evaluation-harness.test.ts`: arg resolver (file path vs session id heuristic), no-arg → usage + exit 1, missing/garbage transcript file → exit 1 with no judge call, empty `ListSpans` → exit 1 with no judge call, missing creds → exit 1 with no AWS call, `bedrock:Converse` access-denied → reports the operation and exits 1 with no fallback, `qconnect:ListSpans` access-denied → reports the operation and exits 1, judge timeout/error → exits 1 with no fallback; assert the harness imports the same `evaluateCaseSession`, `judge-prompt-rendering`, `bedrock-judge-client`, and `evaluation-scoring` modules as the Lambda
    - _Requirements: 9.4, 9.5, 9.6, 9.7, 9.8, 9.9, 10.4, 10.5_

- [x] 7. Update the CDK orchestration construct for the Bedrock judge
  - [x] 7.1 Rewire `lib/orchestration-construct.ts` for Bedrock Converse
    - Read the `judgeModelId` CDK context key with default `us.anthropic.claude-sonnet-4-6` (matching `src/backend/handlers/analysis.ts` and `src/backend/handlers/scaffold.ts`); throw at synth on empty/whitespace-only context value (Req 6.7) and on unrecognized inference-profile prefix (Req 6.8); set the Evaluation Lambda's `JUDGE_MODEL_ID` environment variable to the resolved value; remove `@aws-sdk/client-bedrock-agentcore` from the Lambda's `externalModules`/bundling configuration; ensure `@aws-sdk/client-bedrock-runtime` is bundled at a pinned exact version (mirror the existing `client-qconnect` bundling pattern)
    - Replace any `bedrock-agentcore:Evaluate` and other `bedrock-agentcore:*` IAM grants on the Lambda role with a tightly-scoped `bedrock:InvokeModel` + `bedrock:Converse` policy whose `Resource` list is derived deterministically from `judgeModelId`: (a) for a cross-region inference-profile id, one inference-profile ARN per routing region (`us.` → us-east-1/us-east-2/us-west-2; `eu.` → eu-central-1/eu-west-1/eu-west-3/eu-north-1; `apac.` → ap-northeast-1/ap-northeast-2/ap-south-1/ap-southeast-1/ap-southeast-2) plus one foundation-model ARN per routing region for the underlying model id the profile resolves to; (b) for a bare foundation-model id, a single foundation-model ARN in the deploy region. The resource ARNs SHALL contain no wildcard segment in the model-id portion (no `inference-profile/us.anthropic.*`, no `foundation-model/anthropic.*`); each resource SHALL name exactly one model or profile id. Encode the routing-region table as a const map in the construct so adding a new prefix is a focused diff. Grant no other Bedrock model, no `bedrock:*` wildcard action, and no AgentCore Runtime / Evaluate permission
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7, 6.8, 6.9_
  - [x] 7.2 CDK assertions test for the orchestration construct
    - Rewrite the relevant assertions in `tests/infrastructure/` (extend the existing CDK test file or add `tests/infrastructure/orchestration-construct.test.ts`): the Evaluation Lambda has `Environment.Variables.JUDGE_MODEL_ID` matching the default `us.anthropic.claude-sonnet-4-6` and a context override; for the default `us.`-prefixed profile the role's IAM policy contains `bedrock:InvokeModel` + `bedrock:Converse` on exactly the three inference-profile ARNs (us-east-1/us-east-2/us-west-2) plus the three foundation-model ARNs for the resolved underlying model id and contains no `bedrock-agentcore:*` action and no wildcard model-id segment; an `eu.`-prefixed override produces the four eu-region ARN pair; an empty `judgeModelId` and an unrecognized-prefix `judgeModelId` each fail synth with the expected error message
    - _Requirements: 6.1, 6.2, 6.4, 6.5, 6.6, 6.7, 6.8_

- [x] 8. Generate and validate golden-prompt snapshots against real captured spans
  - [x] 8.1 Generate the golden-prompt snapshot files
    - Add a small generator (e.g. `scripts/generate-golden-prompts.ts`) that, for each fixture under `tests/fixtures/spans/` (`multi-tool-success.json`, `failure-escalation.json`), runs `renderJudgePromptContext` and writes one `.txt` file per rendered string under `tests/fixtures/golden-prompts/{fixture-name}/`: `context.txt`, `available-tools.txt`, `assistant-turn-{i}.txt` for each assistant turn, and `tool-turn-{i}.txt` for each tool call; commit the generated files; assert via the redaction guard already in `tests/unit/fixtures-redaction.test.ts` (extend it to scan `golden-prompts/` too) that no real phone number / SSN fragment leaks into the snapshots
    - _Requirements: 11.1, 11.2, 11.5_
  - [x] 8.2 Snapshot conformance test (replaces the OTel schema conformance test)
    - File `tests/unit/judge-prompt-rendering.fixtures.test.ts` (replacing `tests/unit/trace-to-otel.fixtures.test.ts`): for each fixture, run `renderJudgePromptContext` and assert byte-equality against each committed `.txt` snapshot; assert that the count of `{assistant_turn}` renderings equals the count of inference steps, the count of `{tool_turn}` renderings equals the count of `execute_tool` entries, and chronological order is preserved; on mismatch the test fails with a diff identifying the changed bytes (snapshots updated only by an explicit checked-in change)
    - _Requirements: 11.2, 11.3, 11.6_

- [x] 9. Remove obsolete AgentCore artifacts
  - [x] 9.1 Delete the AgentCore code modules and their dedicated tests
    - Delete `src/backend/orchestration/trace-to-otel.ts`, `src/backend/orchestration/agentcore-client.ts`, `tests/unit/properties/trace-to-otel.test.ts`, `tests/unit/agentcore-client.test.ts`, `tests/unit/trace-to-otel.fixtures.test.ts` (superseded by task 8.2); verify with a workspace search that no remaining source or test imports any deleted symbol
    - _Requirements: 6.5_
  - [x] 9.2 Delete the diagnostic probe scripts that this pivot makes obsolete
    - Delete `scripts/agentcore-shape-probe.ts`, `scripts/strands-tracer-probe.py`, and `scripts/cloudwatch-shape-probe.py`; keep `scripts/bedrock-judge-probe.ts` as the documented validated reference
    - _Requirements: 6.5_
  - [x] 9.3 Drop the AgentCore SDK dependency
    - Remove `@aws-sdk/client-bedrock-agentcore` from `package.json` (`dependencies` and any `externalModules` reference); run `npm install` to refresh the lockfile; assert via repo grep that no source/test/script references the package
    - _Requirements: 6.5_

- [x] 10. Final checkpoint
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional test sub-tasks and can be skipped for a faster MVP; core implementation tasks are never optional.
- `evaluation-scoring.ts`, `evaluation-result.ts`, `score-comparison.ts`, `types.ts`, the frontend, and run-comparison wiring are reused not rewritten — the only edits there are the `evaluationError.code` enum rename (task 2.1) and the Score_Scale table additions (task 2.2).
- Properties 4–7 are carried over from `platform-hosting-and-evaluations` (the underlying modules are unchanged); their existing property tests are simply re-tagged in task 2.4. Properties 1–3 are new and are co-located with the new modules they validate.
- Each property test is run at `{ numRuns: 100 }` and is tagged `// Feature: bedrock-judge-evaluations, Property {n}: {text}` per the platform's PBT convention.
- Golden-prompt snapshot tests (task 8.2) replace the prior OTel schema conformance test (`Span_Fixture` shape Property 5 from the previous spec) and surface any unintended rendering change as a byte-diff in code review.
- The local harness (task 6.1) and the Lambda (task 5.1) import the same `evaluateCaseSession` so local iteration is representative of deployed behavior.
- `scripts/bedrock-judge-probe.ts` is retained as the validated working reference; the production modules reorganise its logic without changing its behavior on the two committed fixtures.

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1", "2.1", "2.2", "3.1", "4.1", "9.2"] },
    { "id": 1, "tasks": ["2.3", "2.4", "3.2", "3.3", "4.2", "5.1", "8.1"] },
    { "id": 2, "tasks": ["5.2", "5.3", "6.1", "7.1", "8.2", "9.1"] },
    { "id": 3, "tasks": ["6.2", "7.2", "9.3"] }
  ]
}
```
