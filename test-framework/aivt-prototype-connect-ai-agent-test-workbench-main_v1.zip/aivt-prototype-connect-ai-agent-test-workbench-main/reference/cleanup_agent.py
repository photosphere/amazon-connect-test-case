#!/usr/bin/env python3
"""Restore the AI Agent to its pre-test configuration.

Usage:
    .venv/bin/python scratch/scaling_test/cleanup_agent.py

This script:
1. Reads .original_agent_config.json (saved by configure_agent.py on first run)
2. Restores the AI Agent to its original configuration via update_ai_agent()
3. Verifies restoration by calling get_ai_agent()
4. Deletes the .original_agent_config.json file on success

Since the scaling test no longer creates separate AI Prompts (it only updates
toolConfigurations on the existing agent), cleanup is just a config restore.
"""

import json
import sys
from pathlib import Path

import boto3

# --- Constants ---
REGION = "us-east-1"
INSTANCE_ID = "46837cc7-8562-4b3f-92b2-1bae0ede624b"
ASSISTANT_ID = "5664eea5-381d-468e-bfba-302b69ae6dec"
AI_AGENT_ID = "8c02abb3-ba52-42cc-be7d-d01a8634d4ae"

SCRIPT_DIR = Path(__file__).resolve().parent
ORIGINAL_CONFIG_FILE = SCRIPT_DIR / ".original_agent_config.json"


def load_original_config() -> dict:
    """Load the original AI Agent configuration from the saved file.

    Exits with error code 1 if the file is missing.
    """
    if not ORIGINAL_CONFIG_FILE.exists():
        print(f"ERROR: Original config file not found: {ORIGINAL_CONFIG_FILE}")
        print()
        print("The configure_agent.py script must be run first to save the original")
        print("AI Agent configuration before cleanup can restore it.")
        sys.exit(1)

    with open(ORIGINAL_CONFIG_FILE, "r") as f:
        return json.load(f)


def restore_ai_agent(qconnect_client, original_config: dict) -> bool:
    """Restore the AI Agent to its original configuration.

    Returns True on success, False on failure.
    """
    print("Restoring AI Agent to original configuration...")

    ai_agent = original_config.get("aiAgent", original_config)
    configuration = ai_agent.get("configuration", {})
    visibility_status = ai_agent.get("visibilityStatus", "PUBLISHED")

    if not configuration:
        print("WARNING: No 'configuration' found in original config.")
        print("Attempting restoration with empty configuration...")

    try:
        qconnect_client.update_ai_agent(
            assistantId=ASSISTANT_ID,
            aiAgentId=AI_AGENT_ID,
            configuration=configuration,
            visibilityStatus=visibility_status,
        )
        print("  AI Agent configuration restored successfully.")
        return True
    except Exception as e:
        print(f"  ERROR: Failed to restore AI Agent: {e}")
        if hasattr(e, "response"):
            print(f"  API Response: {json.dumps(e.response, indent=2, default=str)}")
        return False


def verify_restoration(qconnect_client, original_config: dict) -> bool:
    """Verify the AI Agent matches the original configuration.

    Returns True if verification passes, False otherwise.
    """
    print("Verifying AI Agent restoration...")

    try:
        response = qconnect_client.get_ai_agent(
            assistantId=ASSISTANT_ID,
            aiAgentId=AI_AGENT_ID,
        )
    except Exception as e:
        print(f"  ERROR: Failed to verify AI Agent: {e}")
        if hasattr(e, "response"):
            print(f"  API Response: {json.dumps(e.response, indent=2, default=str)}")
        return False

    # Compare the current prompt ID with the original
    ai_agent = response.get("aiAgent", response)
    current_config = ai_agent.get("configuration", {})
    orch_config = current_config.get("orchestrationAIAgentConfiguration", {})
    if not orch_config:
        ss_config = current_config.get("selfServiceAIAgentConfiguration", {})
        orch_config = ss_config.get("orchestrationAIAgentConfiguration", {})
    current_prompt = orch_config.get("orchestrationAIPromptId", "")
    current_tools = orch_config.get("toolConfigurations", [])

    # Get original prompt for comparison
    orig_agent = original_config.get("aiAgent", original_config)
    orig_config = orig_agent.get("configuration", {})
    orig_orch = orig_config.get("orchestrationAIAgentConfiguration", {})
    if not orig_orch:
        orig_ss = orig_config.get("selfServiceAIAgentConfiguration", {})
        orig_orch = orig_ss.get("orchestrationAIAgentConfiguration", {})
    orig_prompt = orig_orch.get("orchestrationAIPromptId", "")
    orig_tools = orig_orch.get("toolConfigurations", [])

    prompt_match = current_prompt == orig_prompt
    tools_match = len(current_tools) == len(orig_tools)

    print(f"  Prompt ID: {current_prompt} {'✓' if prompt_match else '✗ (expected: ' + orig_prompt + ')'}")
    print(f"  Tool count: {len(current_tools)} {'✓' if tools_match else '✗ (expected: ' + str(len(orig_tools)) + ')'}")

    return prompt_match and tools_match


def main():
    """Main entry point."""
    print("=== AI Agent Scaling Test Cleanup ===")
    print(f"Region: {REGION}")
    print(f"Assistant: {ASSISTANT_ID}")
    print(f"AI Agent: {AI_AGENT_ID}")
    print()

    # Step 1: Load original config
    original_config = load_original_config()
    print(f"Loaded original config from: {ORIGINAL_CONFIG_FILE}")
    print()

    # Create boto3 client
    qconnect_client = boto3.client("qconnect", region_name=REGION)

    # Step 2: Restore AI Agent
    restore_success = restore_ai_agent(qconnect_client, original_config)
    print()

    # Step 3: Verify
    verification_passed = verify_restoration(qconnect_client, original_config)
    print()

    # Step 4: Summary
    print("=== Cleanup Summary ===")
    print(f"  Agent restoration: {'SUCCESS' if restore_success else 'FAILED'}")
    print(f"  Verification:      {'PASSED' if verification_passed else 'FAILED'}")
    print()

    if restore_success and verification_passed:
        # Remove the config file since we've restored successfully
        ORIGINAL_CONFIG_FILE.unlink()
        print(f"Cleanup complete. Removed {ORIGINAL_CONFIG_FILE.name}.")
        sys.exit(0)
    else:
        print("CLEANUP INCOMPLETE. Manual intervention may be needed.")
        print(f"Original config still at: {ORIGINAL_CONFIG_FILE}")
        print()
        print("Manual restore command:")
        print(f"  aws qconnect update-ai-agent \\")
        print(f"    --assistant-id {ASSISTANT_ID} \\")
        print(f"    --ai-agent-id {AI_AGENT_ID} \\")
        print(f"    --configuration file://{ORIGINAL_CONFIG_FILE} \\")
        print(f"    --visibility-status PUBLISHED")
        sys.exit(1)


if __name__ == "__main__":
    main()
