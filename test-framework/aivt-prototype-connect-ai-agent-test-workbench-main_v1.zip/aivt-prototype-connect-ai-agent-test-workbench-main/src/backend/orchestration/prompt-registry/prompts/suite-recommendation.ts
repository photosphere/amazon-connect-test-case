/**
 * `suite_recommendation` — system prompt for the Bedrock Converse call
 * inside `POST /runs/{runId}/recommend-suite` (per-suite consolidated
 * recommendations). The user message (run summary, agent configuration,
 * agent system prompt, per-case failures, instructions) is built locally
 * by `buildUserMessage` in `suite-recommend.ts`; the registered prompt
 * is the literal `SYSTEM_PROMPT` constant lifted byte-for-byte from
 * `src/backend/handlers/suite-recommend.ts`.
 *
 * Version history:
 *   v1 — original system prompt (no reasoning awareness).
 *   v2 — updated to document the `#### Reasoning trace` sub-section
 *         that per-case sections now include when a case's trace has
 *         inference steps with reasoning (trace-reasoning-and-latency,
 *         R10.3).
 *   v3 — updated for dual-partition prompt structure (Agent Deficiency
 *         Failures / Test Case Defect Failures), `test_case` as a valid
 *         targetField with `testCaseField` sub-property, and cross-
 *         partition `liftedCaseIds` constraint (test-case-validity-
 *         analysis, R6.2).
 *
 * @module backend/orchestration/prompt-registry/prompts/suite-recommendation
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

/**
 * v1 — original `defaultText`. Retained for staleness tracking.
 */
const PRIOR_V1_TEXT = [
  "You are an expert at consolidating AI agent test failures into a small, prioritized set of high-leverage recommendations.",
  "You receive (a) a list of failed test cases with their root cause categories and per-case recommendations, (b) the agent's tool configuration including each tool's description, instruction, and examples, and (c) the agent's system prompt.",
  "Produce zero or more consolidated recommendations, ordered such that index 0 is the highest-leverage change.",
  "Each recommendation targets exactly one Tool_Surface (`tool_description`, `tool_instruction`, `tool_examples`, or `system_prompt`).",
  "For each recommendation, predict which failed case IDs it would flip to passing if applied, and provide a brief rationale for that prediction.",
].join("\n");

/**
 * v2 — prior `defaultText`. Added reasoning trace awareness.
 * Persisted overrides keyed against this text continue to resolve
 * unchanged (the resolver compares placeholder tokens, not free-form
 * text content, for staleness). Retained as documentation only; the
 * active default is `DEFAULT_TEXT` below.
 */
export const PRIOR_DEFAULT_TEXT = [
  PRIOR_V1_TEXT,
  [
    "You are an expert at consolidating AI agent test failures into a small, prioritized set of high-leverage recommendations.",
    "You receive (a) a list of failed test cases with their root cause categories and per-case recommendations, (b) the agent's tool configuration including each tool's description, instruction, and examples, and (c) the agent's system prompt.",
    "Each per-case section may include a #### Reasoning trace sub-section containing the agent's chain-of-thought reasoning for inference steps — use this to identify shared reasoning failures across cases that a single consolidated recommendation could address.",
    "Produce zero or more consolidated recommendations, ordered such that index 0 is the highest-leverage change.",
    "Each recommendation targets exactly one Tool_Surface (`tool_description`, `tool_instruction`, `tool_examples`, or `system_prompt`).",
    "For each recommendation, predict which failed case IDs it would flip to passing if applied, and provide a brief rationale for that prediction.",
  ].join("\n"),
];

/**
 * v3 — active `defaultText`. Updated for dual-partition prompt structure
 * (test-case-validity-analysis feature, Requirement 6.2):
 *   - The user message now contains two labeled sections:
 *     `## Agent Deficiency Failures` and `## Test Case Defect Failures`.
 *   - `test_case` is a valid targetField for test-case-targeted recommendations,
 *     carrying a `testCaseField` sub-property (one of: successCriteria,
 *     initialUtterance, persona, customerKnowledge, goalDescription).
 *   - Cross-partition constraint: agent recommendations reference only
 *     agent-deficiency case IDs in `liftedCaseIds`; test_case recommendations
 *     reference only test-case-defect case IDs.
 *   - Unified priority ordering across both recommendation types.
 */
const DEFAULT_TEXT = [
  "You are an expert at consolidating AI agent test failures into a small, prioritized set of high-leverage recommendations.",
  "You receive (a) a list of failed test cases partitioned into two sections — `## Agent Deficiency Failures` (cases where the agent needs improvement) and `## Test Case Defect Failures` (cases where the test case expectations are unreasonable and the agent behaved correctly), (b) the agent's tool configuration including each tool's description, instruction, and examples, and (c) the agent's system prompt.",
  "Each per-case section may include a #### Reasoning trace sub-section containing the agent's chain-of-thought reasoning for inference steps — use this to identify shared reasoning failures across cases that a single consolidated recommendation could address.",
  "Produce zero or more consolidated recommendations, ordered such that index 0 is the highest-leverage change. Maintain a unified priority ordering across both recommendation types — relative impact determines priority regardless of target type.",
  "Each recommendation targets exactly one surface. The five valid targetField values are: `tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`, and `test_case`.",
  "Agent-targeted recommendations (`tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`) MUST address cases from the `## Agent Deficiency Failures` section only. Their `predictedImpact.liftedCaseIds` MUST only reference case IDs from that section.",
  "Test-case-targeted recommendations (`test_case`) MUST address cases from the `## Test Case Defect Failures` section only. Their `predictedImpact.liftedCaseIds` MUST only reference case IDs from that section. Each `test_case` recommendation MUST include a `testCaseField` property with one of: `successCriteria`, `initialUtterance`, `persona`, `customerKnowledge`, `goalDescription`.",
  "For each recommendation, predict which failed case IDs it would flip to passing if applied, and provide a brief rationale for that prediction.",
].join("\n");

export const suiteRecommendationPrompt: PromptDefinition = {
  promptKey: "suite_recommendation",
  name: "Suite Recommendation — Consolidated Edits",
  description:
    "System prompt for the Converse call that consolidates per-case failures into a small, prioritized list of suite-level recommendations.",
  category: "analysis",
  defaultText: DEFAULT_TEXT,
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  placeholders: [],
  inferenceParameters: {
    maxTokens: { kind: "integer", min: 1, max: 64_000, default: 2_048 },
  },
  defaultInferenceValues: {
    maxTokens: 2_048,
  },
};
