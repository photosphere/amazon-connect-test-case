/**
 * Suite CRUD Lambda — handles all /suites and /suites/{suiteId}/cases routes.
 *
 * Routes:
 * - POST   /suites                         — Create suite
 * - GET    /suites                         — List suites for tenant
 * - GET    /suites/{suiteId}               — Get suite with case count
 * - PUT    /suites/{suiteId}               — Update suite
 * - DELETE /suites/{suiteId}               — Cascade delete (requires confirmation token)
 * - POST   /suites/{suiteId}/cases         — Create test case
 * - GET    /suites/{suiteId}/cases         — List cases for suite
 * - PUT    /suites/{suiteId}/cases/{caseId} — Update test case
 * - DELETE /suites/{suiteId}/cases/{caseId} — Delete single case
 *
 * @module suites
 */

import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBService, createDynamoDBService } from "../services/dynamodb";
import { listAgents } from "./discovery";
import { validateTestSuite, validateTestCase } from "../../shared/validation";
import type {
  TestSuite,
  TestCase,
  ToolSequenceTestCase,
  RagThresholds,
  AgentSummary,
  EnrichedTestSuite,
} from "../../shared/types";
import { DEFAULT_RAG_THRESHOLDS } from "../../shared/types";
import { CommunicationStyle } from "../../shared/enums";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";

// ---------------------------------------------------------------------------
// Service setup
// ---------------------------------------------------------------------------

let dbService: DynamoDBService | null = null;

function getDBService(): DynamoDBService {
  if (!dbService) {
    const ddbClient = new DynamoDBClient({});
    const docClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
    dbService = createDynamoDBService(TABLE_NAME, docClient);
  }
  return dbService;
}

/** @internal — allows test injection */
export function _setDBService(service: DynamoDBService | null): void {
  dbService = service;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface APIGatewayEvent {
  httpMethod: string;
  resource: string;
  pathParameters?: Record<string, string> | null;
  body?: string | null;
  requestContext?: {
    authorizer?: {
      claims?: Record<string, string>;
    };
  };
}

export interface APIGatewayResponse {
  statusCode: number;
  body: string;
  headers: Record<string, string>;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const CORS_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function jsonResponse(statusCode: number, body: unknown): APIGatewayResponse {
  return {
    statusCode,
    body: JSON.stringify(body),
    headers: CORS_HEADERS,
  };
}

function extractTenantId(event: APIGatewayEvent): string | null {
  const claims = event.requestContext?.authorizer?.claims;
  // Interactive user: sub claim; Machine client: client_id claim
  return claims?.sub ?? claims?.client_id ?? null;
}

function generateId(): string {
  const hex = "0123456789abcdef";
  let id = "";
  for (let i = 0; i < 24; i++) {
    id += hex[Math.floor(Math.random() * 16)];
  }
  return id;
}

function nowISO(): string {
  return new Date().toISOString();
}

/**
 * Validates ragThresholds if provided. Each of the four metrics must be a
 * number in [0,1]. Returns an error message if invalid, or null if valid/absent.
 */
function validateRagThresholds(
  ragThresholds: unknown
): string | null {
  if (ragThresholds === undefined || ragThresholds === null) {
    return null; // absent is fine
  }
  if (typeof ragThresholds !== "object" || Array.isArray(ragThresholds)) {
    return "ragThresholds must be an object with faithfulness, correctness, completeness, helpfulness";
  }
  const thresholds = ragThresholds as Record<string, unknown>;
  const fields: (keyof RagThresholds)[] = [
    "faithfulness",
    "correctness",
    "completeness",
    "helpfulness",
  ];
  for (const field of fields) {
    const value = thresholds[field];
    if (value === undefined) {
      continue; // partial updates are allowed — missing fields keep existing/default
    }
    if (typeof value !== "number" || isNaN(value)) {
      return `ragThresholds.${field} must be a number`;
    }
    if (value < 0 || value > 1) {
      return `ragThresholds.${field} must be in [0,1]`;
    }
  }
  return null;
}

/**
 * Normalizes a suite read from DDB: applies DEFAULT_RAG_THRESHOLDS when
 * ragThresholds is absent. Does NOT write back — read-only normalization.
 */
function normalizeSuiteOnRead(suite: TestSuite): TestSuite {
  if (!suite.ragThresholds) {
    return { ...suite, ragThresholds: DEFAULT_RAG_THRESHOLDS };
  }
  return suite;
}

/**
 * Builds a lookup map from agentId → agent display name.
 * Pure function — easy to unit test independently.
 */
export function buildAgentNameMap(agents: AgentSummary[]): Map<string, string> {
  const map = new Map<string, string>();
  for (const agent of agents) {
    map.set(agent.agentId, agent.name);
  }
  return map;
}

/**
 * Enriches each suite with agentName resolved from the map.
 * Falls back to the literal agentId when the agent is not found.
 */
export function enrichWithAgentName(
  suites: TestSuite[],
  agentNameMap: Map<string, string>
): EnrichedTestSuite[] {
  return suites.map((suite) => ({
    ...suite,
    agentName: agentNameMap.get(suite.agentId) ?? suite.agentId,
  }));
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------

async function createSuite(
  tenantId: string,
  body: string | null
): Promise<APIGatewayResponse> {
  if (!body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let input: Partial<TestSuite> & { ragThresholds?: unknown };
  try {
    input = JSON.parse(body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  const validation = validateTestSuite(input);
  if (!validation.valid) {
    return jsonResponse(400, { error: "Validation failed", details: validation.errors });
  }

  // Validate ragThresholds if provided
  const thresholdsError = validateRagThresholds(input.ragThresholds);
  if (thresholdsError) {
    return jsonResponse(400, { error: thresholdsError });
  }

  const now = nowISO();
  const suite: TestSuite = {
    tenantId,
    suiteId: generateId(),
    name: input.name!.trim(),
    description: input.description?.trim(),
    agentId: input.agentId!.trim(),
    assistantId: process.env.ASSISTANT_ID ?? "",
    createdAt: now,
    updatedAt: now,
    ...(input.ragThresholds != null && { ragThresholds: input.ragThresholds as RagThresholds }),
  };

  const db = getDBService();
  await db.createSuite(suite);

  return jsonResponse(201, suite);
}

async function listSuites(tenantId: string): Promise<APIGatewayResponse> {
  const db = getDBService();
  const suites = await db.listSuites(tenantId);

  let agentNameMap: Map<string, string>;
  try {
    const agents = await listAgents();
    agentNameMap = buildAgentNameMap(agents);
  } catch (err) {
    console.warn(
      "[suites] Failed to resolve agent names, falling back to agentId:",
      err
    );
    agentNameMap = new Map();
  }

  const enriched = enrichWithAgentName(
    suites.map(normalizeSuiteOnRead),
    agentNameMap
  );

  return jsonResponse(200, { suites: enriched });
}

async function getSuite(
  tenantId: string,
  suiteId: string
): Promise<APIGatewayResponse> {
  const db = getDBService();
  const suite = await db.getSuite(tenantId, suiteId);

  if (!suite) {
    return jsonResponse(404, { error: "Suite not found" });
  }

  const cases = await db.listCases(suiteId);
  const normalized = normalizeSuiteOnRead(suite);

  return jsonResponse(200, { ...normalized, caseCount: cases.length });
}

async function updateSuite(
  tenantId: string,
  suiteId: string,
  body: string | null
): Promise<APIGatewayResponse> {
  if (!body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let input: Partial<TestSuite> & { ragThresholds?: unknown };
  try {
    input = JSON.parse(body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  // Validate only the fields being updated
  const validationInput: Partial<TestSuite> = {};
  if (input.name !== undefined) validationInput.name = input.name;
  if (input.description !== undefined) validationInput.description = input.description;
  // agentId is required for suite validation but not necessarily for an update
  // Only validate if provided
  if (input.agentId !== undefined) validationInput.agentId = input.agentId;
  else validationInput.agentId = "placeholder"; // skip agentId validation on update

  const validation = validateTestSuite(validationInput);
  if (!validation.valid) {
    // Filter out the placeholder agentId error if we used it
    const errors = input.agentId === undefined
      ? validation.errors.filter((e) => e.field !== "agentId")
      : validation.errors;
    if (errors.length > 0) {
      return jsonResponse(400, { error: "Validation failed", details: errors });
    }
  }

  // Validate ragThresholds if provided
  const thresholdsError = validateRagThresholds(input.ragThresholds);
  if (thresholdsError) {
    return jsonResponse(400, { error: thresholdsError });
  }

  const db = getDBService();

  // Verify suite exists
  const existing = await db.getSuite(tenantId, suiteId);
  if (!existing) {
    return jsonResponse(404, { error: "Suite not found" });
  }

  const now = nowISO();
  await db.updateSuite({
    tenantId,
    suiteId,
    name: input.name?.trim(),
    description: input.description?.trim(),
    updatedAt: now,
    ...(input.ragThresholds !== undefined && { ragThresholds: input.ragThresholds as RagThresholds }),
  });

  // Return the updated suite (normalized)
  const updated = await db.getSuite(tenantId, suiteId);
  return jsonResponse(200, updated ? normalizeSuiteOnRead(updated) : null);
}

async function deleteSuite(
  tenantId: string,
  suiteId: string,
  body: string | null
): Promise<APIGatewayResponse> {
  if (!body) {
    return jsonResponse(400, { error: "Confirmation token is required in request body" });
  }

  let parsed: { confirmationToken?: string };
  try {
    parsed = JSON.parse(body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  if (!parsed.confirmationToken || parsed.confirmationToken !== suiteId) {
    return jsonResponse(400, {
      error: "Invalid confirmation token. Provide the suiteId as confirmationToken to confirm deletion.",
    });
  }

  const db = getDBService();

  // Verify suite exists
  const existing = await db.getSuite(tenantId, suiteId);
  if (!existing) {
    return jsonResponse(404, { error: "Suite not found" });
  }

  await db.deleteSuite(tenantId, suiteId);

  return jsonResponse(200, { message: "Suite and all associated cases deleted" });
}

async function createCase(
  suiteId: string,
  tenantId: string,
  body: string | null
): Promise<APIGatewayResponse> {
  if (!body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let input: Partial<TestCase>;
  try {
    input = JSON.parse(body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  const validation = validateTestCase(input);
  if (!validation.valid) {
    return jsonResponse(400, { error: "Validation failed", details: validation.errors });
  }

  // Verify parent suite exists
  const db = getDBService();
  const suite = await db.getSuite(tenantId, suiteId);
  if (!suite) {
    return jsonResponse(404, { error: "Suite not found" });
  }

  const testCase: TestCase = {
    type: "tool_sequence",
    suiteId,
    caseId: generateId(),
    name: input.name ?? "",
    description: input.description!.trim(),
    // goalDescription is the simulator scenario / scaffold seed (see TestCase
    // jsdoc). Persist it only when the caller supplied a non-blank value so
    // that an absent field on the request stays absent on the persisted
    // record (the simulator's fallback chain handles the missing-value case
    // by reading `description` instead).
    ...((input as Partial<ToolSequenceTestCase>).goalDescription && (input as Partial<ToolSequenceTestCase>).goalDescription!.trim() !== "" && {
      goalDescription: (input as Partial<ToolSequenceTestCase>).goalDescription!.trim(),
    }),
    persona: (input as Partial<ToolSequenceTestCase>).persona ?? "",
    style: (input as Partial<ToolSequenceTestCase>).style ?? CommunicationStyle.DIRECT,
    customerKnowledge: (input as Partial<ToolSequenceTestCase>).customerKnowledge ?? {},
    initialUtterance: (input as Partial<ToolSequenceTestCase>).initialUtterance!.trim(),
    successCriteria: (input as Partial<ToolSequenceTestCase>).successCriteria!.map((step: { toolName: string; required?: boolean; parameterChecks?: { paramName: string; expectedValue: string }[] }) => ({
      toolName: step.toolName.trim(),
      required: step.required !== false, // default to true
      parameterChecks: step.parameterChecks,
    })),
    ...(input.sessionData && { sessionData: input.sessionData }),
    ...((input as Partial<ToolSequenceTestCase>).primingMessage && { primingMessage: (input as Partial<ToolSequenceTestCase>).primingMessage }),
  };

  await db.createCase(testCase);

  return jsonResponse(201, testCase);
}

async function listCases(suiteId: string): Promise<APIGatewayResponse> {
  const db = getDBService();
  const cases = await db.listCases(suiteId);
  return jsonResponse(200, { cases });
}

async function updateCase(
  suiteId: string,
  caseId: string,
  body: string | null
): Promise<APIGatewayResponse> {
  if (!body) {
    return jsonResponse(400, { error: "Request body is required" });
  }

  let input: Partial<TestCase>;
  try {
    input = JSON.parse(body);
  } catch {
    return jsonResponse(400, { error: "Invalid JSON in request body" });
  }

  const validation = validateTestCase(input);
  if (!validation.valid) {
    return jsonResponse(400, { error: "Validation failed", details: validation.errors });
  }

  const db = getDBService();

  // Verify case exists
  const existing = await db.getCase(suiteId, caseId);
  if (!existing) {
    return jsonResponse(404, { error: "Test case not found" });
  }

  const updatedCase: TestCase = {
    type: "tool_sequence",
    suiteId,
    caseId,
    name: input.name ?? existing.name,
    description: input.description?.trim() ?? existing.description,
    // goalDescription supports clearing (empty string from the editor →
    // delete the field) so the simulator falls back to `description` for
    // a case the user explicitly cleared the field on. An absent property
    // on the input keeps the existing value.
    ...((() => {
      const tsInput = input as Partial<ToolSequenceTestCase>;
      const tsExisting = existing as ToolSequenceTestCase;
      if (tsInput.goalDescription === undefined) {
        return tsExisting.goalDescription !== undefined
          ? { goalDescription: tsExisting.goalDescription }
          : {};
      }
      const trimmed = tsInput.goalDescription.trim();
      return trimmed !== "" ? { goalDescription: trimmed } : {};
    })()),
    persona: (input as Partial<ToolSequenceTestCase>).persona ?? (existing as ToolSequenceTestCase).persona,
    style: (input as Partial<ToolSequenceTestCase>).style ?? (existing as ToolSequenceTestCase).style,
    customerKnowledge: (input as Partial<ToolSequenceTestCase>).customerKnowledge ?? (existing as ToolSequenceTestCase).customerKnowledge,
    initialUtterance: (input as Partial<ToolSequenceTestCase>).initialUtterance?.trim() ?? (existing as ToolSequenceTestCase).initialUtterance,
    successCriteria: (input as Partial<ToolSequenceTestCase>).successCriteria
      ? (input as Partial<ToolSequenceTestCase>).successCriteria!.map((step) => ({
          toolName: step.toolName.trim(),
          required: step.required !== false,
          parameterChecks: step.parameterChecks,
        }))
      : (existing as ToolSequenceTestCase).successCriteria,
    ...((input.sessionData ?? (existing as ToolSequenceTestCase).sessionData) && {
      sessionData: input.sessionData ?? (existing as ToolSequenceTestCase).sessionData,
    }),
    ...(((input as Partial<ToolSequenceTestCase>).primingMessage ?? (existing as ToolSequenceTestCase).primingMessage) && {
      primingMessage: (input as Partial<ToolSequenceTestCase>).primingMessage ?? (existing as ToolSequenceTestCase).primingMessage,
    }),
  } as ToolSequenceTestCase;

  await db.updateCase(updatedCase);

  return jsonResponse(200, updatedCase);
}

async function deleteCase(
  suiteId: string,
  caseId: string
): Promise<APIGatewayResponse> {
  const db = getDBService();

  // Verify case exists
  const existing = await db.getCase(suiteId, caseId);
  if (!existing) {
    return jsonResponse(404, { error: "Test case not found" });
  }

  await db.deleteCase(suiteId, caseId);

  return jsonResponse(200, { message: "Test case deleted" });
}

// ---------------------------------------------------------------------------
// Main handler / router
// ---------------------------------------------------------------------------

/**
 * Lambda handler for suite and case CRUD operations.
 * Routes based on httpMethod and resource path pattern.
 */
export async function handler(event: APIGatewayEvent): Promise<APIGatewayResponse> {
  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return jsonResponse(200, {});
  }

  // Extract tenant ID from Cognito authorizer claims
  const tenantId = extractTenantId(event);
  if (!tenantId) {
    return jsonResponse(401, { error: "Unauthorized: missing tenant identity" });
  }

  const method = event.httpMethod;
  const resource = event.resource;
  const suiteId = event.pathParameters?.suiteId ?? null;
  const caseId = event.pathParameters?.caseId ?? null;

  try {
    // Route: POST /suites
    if (method === "POST" && resource === "/suites") {
      return await createSuite(tenantId, event.body ?? null);
    }

    // Route: GET /suites
    if (method === "GET" && resource === "/suites") {
      return await listSuites(tenantId);
    }

    // Route: GET /suites/{suiteId}
    if (method === "GET" && resource === "/suites/{suiteId}" && suiteId) {
      return await getSuite(tenantId, suiteId);
    }

    // Route: PUT /suites/{suiteId}
    if (method === "PUT" && resource === "/suites/{suiteId}" && suiteId) {
      return await updateSuite(tenantId, suiteId, event.body ?? null);
    }

    // Route: DELETE /suites/{suiteId}
    if (method === "DELETE" && resource === "/suites/{suiteId}" && suiteId) {
      return await deleteSuite(tenantId, suiteId, event.body ?? null);
    }

    // Route: POST /suites/{suiteId}/cases
    if (method === "POST" && resource === "/suites/{suiteId}/cases" && suiteId) {
      return await createCase(suiteId, tenantId, event.body ?? null);
    }

    // Route: GET /suites/{suiteId}/cases
    if (method === "GET" && resource === "/suites/{suiteId}/cases" && suiteId) {
      return await listCases(suiteId);
    }

    // Route: PUT /suites/{suiteId}/cases/{caseId}
    if (method === "PUT" && resource === "/suites/{suiteId}/cases/{caseId}" && suiteId && caseId) {
      return await updateCase(suiteId, caseId, event.body ?? null);
    }

    // Route: DELETE /suites/{suiteId}/cases/{caseId}
    if (method === "DELETE" && resource === "/suites/{suiteId}/cases/{caseId}" && suiteId && caseId) {
      return await deleteCase(suiteId, caseId);
    }

    return jsonResponse(404, { error: `Route not found: ${method} ${resource}` });
  } catch (error) {
    console.error("[suites] Handler error:", error instanceof Error ? error.message : error);

    // Handle DynamoDB condition check failures (e.g., duplicate creation)
    if (error instanceof Error && error.name === "ConditionalCheckFailedException") {
      return jsonResponse(409, { error: "Resource already exists or was modified" });
    }

    return jsonResponse(500, {
      error: "Internal server error",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
}
