/**
 * Evaluation Lambda — composes the pure prompt-rendering module and the
 * Bedrock judge client to score every test case in a run.
 *
 * Called as the `EvaluateResults` step of the Step Functions state machine
 * (see `state-machine.ts`). For each test case in the run:
 *
 *   1. Load the captured `ExecutionTrace`, `TranscriptTurn[]`, and
 *      `AgentSnapshot` from DynamoDB.
 *   2. Short-circuit to `Evaluation_Error_State` code `INSUFFICIENT_TRACE`
 *      when the trace contains zero assistant inference steps AND zero
 *      `execute_tool` entries — no Bedrock Converse call is made
 *      (Requirement 2.8).
 *   3. Render the four Judge_Prompt_Context surfaces (`{context}`,
 *      `{available_tools}`, per-turn `{assistant_turn}`,
 *      per-tool-call `{tool_turn}`) via the pure
 *      {@link renderJudgePromptContext} module
 *      (`src/shared/utils/judge-prompt-rendering.ts`, task 3.1).
 *   4. Fan out concurrently the per-case Converse calls — `1`
 *      GoalSuccessRate, `N` per-assistant-turn Helpfulness, and `M`
 *      per-`execute_tool` ToolSelectionAccuracy — via the thin
 *      {@link judge} client (`bedrock-judge-client.ts`, task 4.1).
 *   5. Map each judge label through the Score_Scale tables
 *      (`evaluation-scoring.ts`, task 2.2), aggregate per-evaluator
 *      arithmetic means via the existing unchanged {@link aggregateScores},
 *      clamp via the existing unchanged {@link clamp01}, and assemble the
 *      score / error-state slice via the existing unchanged
 *      {@link assembleCaseEvaluation}.
 *   6. Persist a `TestCaseResult` for every case to
 *      `PK=RUN#{runId}, SK=CASE#{caseId}` (Requirement 1.7). Per-case
 *      errors never fail the run (Requirement 8.7).
 *
 * Per-case latency budget (Requirement 7.2):
 * - A single 90-second wall-clock budget applies on top of the per-call
 *   60-second timeout from {@link DEFAULT_JUDGE_TIMEOUT_MS}. When the
 *   budget elapses, any in-flight Converse calls are aborted via the
 *   per-case `AbortController` and surfaced as `TIMEOUT`
 *   (Requirement 7.3).
 *
 * Error-state mapping (Requirements 4.4, 8.1, 8.2, 8.3, 8.4):
 * - `JudgeTimeoutError` from any evaluator unit  → `TIMEOUT`.
 * - Per-case 90-second budget exceeded            → `TIMEOUT`.
 * - AWS SDK error (`ThrottlingException`,
 *   `ValidationException`, `ServiceUnavailableException`,
 *   `AccessDeniedException`, …) from any evaluator → `JUDGE_ERROR`.
 * - `JudgeResponseParseError` or a `score` label
 *   not present in the corresponding Score_Scale  → `UNMAPPABLE_RESULT`.
 * - All evaluator units returned but at least one
 *   required score remained unset after aggregation → `MISSING_EVALUATOR`.
 * - Trace has zero assistant turns AND zero tool
 *   calls (pre-flight check, no Converse call)    → `INSUFFICIENT_TRACE`.
 *
 * Per Requirement 8.8, this module **never** computes or persists
 * `toolAccuracyScore` from the local `calculateToolAccuracy` helper or
 * any other local-scoring path; the static check in
 * `tests/unit/evaluation-no-fallback.test.ts` (task 5.3) refuses to even
 * import that symbol.
 *
 * The per-case evaluation pipeline is exported as the pure-ish
 * {@link evaluateCaseSession} function so the local Evaluation Harness
 * (`scripts/evaluation-harness.ts`, task 6.1) shares the **exact** same
 * translate → judge → aggregate → assemble code path as the deployed
 * Lambda (Requirement 9.6).
 *
 * @module evaluation
 */

import {
  judge,
  JudgeResponseParseError,
  JudgeTimeoutError,
  DEFAULT_JUDGE_TIMEOUT_MS,
  type JudgePromptKey,
} from "./bedrock-judge-client";
import {
  renderJudgePromptContext,
  type JudgePromptContext,
} from "../../shared/utils/judge-prompt-rendering";
import {
  aggregateScores,
  GOAL_SUCCESS_SCALE,
  HELPFULNESS_SCALE,
  TOOL_SELECTION_SCALE,
  mapScoreLabel,
  type AggregatedScores,
  type EvaluationResultContent,
  type EvaluatorOutcome,
} from "../../shared/utils/evaluation-scoring";
import {
  assembleCaseEvaluation,
  type CaseEvaluation,
  type FailureContext,
} from "../../shared/utils/evaluation-result";
import { DynamoDBService } from "../services/dynamodb";
import type {
  AgentSnapshot,
  ExecutionTrace,
  TestCase,
  TestCaseResult,
  TranscriptTurn,
} from "../../shared/types";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/**
 * Per-call timeout in milliseconds. Mirrors
 * {@link DEFAULT_JUDGE_TIMEOUT_MS} from the judge client; declared
 * locally so this module can be reasoned about without re-reading the
 * client (Requirement 3.3 specifies 60s).
 */
const PER_EVALUATOR_TIMEOUT_MS = DEFAULT_JUDGE_TIMEOUT_MS;

/**
 * Per-case wall-clock budget for the full `1 + N + M` Converse fan-out
 * (Requirement 7.2). When this elapses any in-flight calls are aborted
 * via the per-case `AbortController` and surfaced as `TIMEOUT`
 * (Requirement 7.3).
 */
const PER_CASE_BUDGET_MS = 90_000;

/**
 * Built-in evaluator ids the platform requests for every test case.
 * Matched by {@link aggregateScores}; unchanged from the previous spec.
 */
const EVALUATOR_GOAL = "Builtin.GoalSuccessRate";
const EVALUATOR_HELPFULNESS = "Builtin.Helpfulness";
const EVALUATOR_TOOL_ACCURACY = "Builtin.ToolSelectionAccuracy";

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/**
 * Lambda input event. The Step Functions Map state writes its results into
 * `caseResults` (see `state-machine.ts` `resultPath: "$.caseResults"`); the
 * `results` alias is preserved for direct invocations and for tests that
 * pre-date the `caseResults` rename.
 */
export interface EvaluationInput {
  runId: string;
  /** Preferred field name (Step Functions Map output). */
  caseResults?: TestCaseResult[];
  /** Legacy alias kept for direct callers and pre-existing tests. */
  results?: TestCaseResult[];
  testCases: TestCase[];
}

/**
 * Lambda output summary. Counts are reported at the run level so the
 * `WriteResults` step can include them in the run summary item without
 * re-querying DynamoDB.
 */
export interface EvaluationOutput {
  /** Number of test cases for which a `TestCaseResult` was persisted. */
  evaluated: number;
  /** Number of cases whose persisted result includes an `evaluationError`. */
  evaluationErrors: number;
  /** Number of cases that could not be processed at all (e.g. unmatched caseId). */
  errors: number;
}

/**
 * Inputs to the per-case session evaluation pipeline. The harness and the
 * Lambda both supply trace/transcript/snapshot and the test case's expected
 * tool names; the pipeline takes care of pre-flight `INSUFFICIENT_TRACE`
 * detection and prompt rendering.
 */
export interface EvaluateCaseSessionInput {
  /** Captured execution trace for the case. */
  trace: ExecutionTrace;
  /** Captured transcript for the case (customer + agent turns). */
  transcript: TranscriptTurn[];
  /** Captured agent snapshot (tool list lives here). */
  snapshot: AgentSnapshot;
  /** Expected tool names sourced from `TestCase.successCriteria`. */
  expectedToolNames: readonly string[];
  /** Optional override for the per-call 60s timeout. */
  timeoutMs?: number;
  /** Optional override for the per-case 90s wall-clock budget. */
  budgetMs?: number;
  /**
   * Optional logging context. When `runId`/`caseId` are supplied, every
   * judge unit (success or failure) emits a single grep-friendly line to
   * CloudWatch with its label, score, and reasoning. The harness leaves
   * these unset; the deployed Lambda passes the run/case ids so an
   * operator can drill into "why did the judge say No?" via Logs
   * Insights without re-running the case.
   */
  runId?: string;
  caseId?: string;
}

/**
 * Output of {@link evaluateCaseSession}. The `caseEvaluation` field is what
 * gets spread onto the persisted `TestCaseResult` (the three score fields
 * and the optional `evaluationError`); `aggregated` and `rawOutcomes` are
 * exposed for the harness which prints per-evaluator detail.
 *
 * `rawJudgeResults` carries each per-call `{ reasoning, score, label,
 * mappedValue }` quadruple so the harness and tests can surface the
 * judge's rationale alongside the numeric score.
 */
export interface EvaluateCaseSessionOutput {
  /** Score / error-state slice ready to spread onto a `TestCaseResult`. */
  caseEvaluation: CaseEvaluation;
  /**
   * Aggregator output, or `undefined` when no Converse call was made
   * (e.g. the trace was rejected as insufficient or the per-case budget
   * elapsed before any call returned).
   */
  aggregated?: AggregatedScores;
  /**
   * Raw per-evaluator outcomes (one per evaluator id). Each outcome's
   * `results` array holds one synthesized `EvaluationResultContent` per
   * Converse call that returned a mappable label, with `value` set to
   * the Score_Scale-mapped decimal.
   */
  rawOutcomes: EvaluatorOutcome[];
  /**
   * Per-call detail surfaced to the harness — one entry per attempted
   * Converse call, including the raw judge label and reasoning when the
   * call returned. Failed calls carry `error` describing the failure
   * mode.
   */
  rawJudgeResults: JudgeCallDetail[];
}

/** One row of per-call diagnostic detail emitted by {@link evaluateCaseSession}. */
export interface JudgeCallDetail {
  /** Which evaluator template this call was issued for. */
  evaluatorId: string;
  /**
   * 0-based ordinal of the call within its evaluator family
   * (`0` for GoalSuccessRate; per-turn / per-tool-call indices for the
   * other two).
   */
  index: number;
  /** Judge's verbatim `reasoning` field (when the call returned). */
  reasoning?: string;
  /** Raw rubric label returned by the judge (when the call returned). */
  label?: string;
  /** Score_Scale-mapped decimal in `[0,1]` (when the label was mappable). */
  mappedValue?: number;
  /** Failure description when the call did not produce a mappable score. */
  error?: { kind: FailureContext["kind"]; message: string };
}

// ---------------------------------------------------------------------------
// Per-call dispatch
// ---------------------------------------------------------------------------

/**
 * One concrete Converse call to issue: which judge promptKey to
 * resolve, which substitutions to interpolate, which evaluator family
 * it counts toward, and which Score_Scale to map its returned label
 * through.
 *
 * The `template` field that used to live here was retired in Wave 2 —
 * Task 17.6 of the prompt-management spec: the registry is now the
 * runtime source of truth for the AgentCore template body, and the
 * `bedrock-judge-client.judge` entrypoint resolves it on every call
 * via `resolvePromptForRun(promptKey, runId)`.
 */
interface JudgeUnit {
  evaluatorId: string;
  /** 0-based ordinal within the evaluator family (for diagnostics). */
  index: number;
  /** Registry key resolved per call by the judge client. */
  promptKey: JudgePromptKey;
  vars: Record<string, string>;
  scale: Readonly<Record<string, number>>;
  /** Human-readable operation name embedded in error reasons. */
  operation: string;
}

/** Per-call outcome — either a mapped numeric value or a typed failure. */
type UnitResult =
  | {
      kind: "ok";
      evaluatorId: string;
      index: number;
      label: string;
      reasoning: string;
      value: number;
    }
  | {
      kind: "error";
      evaluatorId: string;
      index: number;
      failure: FailureContext;
      label?: string;
      reasoning?: string;
    };

/**
 * Runs a single Converse call and folds its outcome into either a mapped
 * `value` (success) or a typed {@link FailureContext} (failure). Errors
 * are caught here so a single judge failure cannot reject the
 * `Promise.all` and short-circuit the other concurrent calls — every
 * evaluator unit gets to report its own outcome and the caller decides
 * which (if any) error code wins.
 *
 * Per-call mapping:
 * - `JudgeTimeoutError`        → `timeout`           → `TIMEOUT`.
 * - `JudgeResponseParseError`  → `unmappable-result` → `UNMAPPABLE_RESULT`.
 * - `AbortError` (signal)      → `timeout`           → `TIMEOUT` (per-case budget).
 * - Score label not in `scale` → `unmappable-result` → `UNMAPPABLE_RESULT`.
 * - Anything else (AWS SDK)    → `agentcore-error`   → `JUDGE_ERROR`.
 */
async function runJudgeUnit(
  unit: JudgeUnit,
  signal: AbortSignal,
  budgetExceededRef: { value: boolean },
  timeoutMs: number,
  runId: string,
): Promise<UnitResult> {
  // Pre-flight: if the per-case budget already elapsed, do not even
  // dispatch this unit — surface as TIMEOUT with the budget reason so
  // every in-flight failure carries the same operation tag.
  if (signal.aborted || budgetExceededRef.value) {
    return {
      kind: "error",
      evaluatorId: unit.evaluatorId,
      index: unit.index,
      failure: {
        kind: "timeout",
        message: `${unit.operation} did not start before the per-case ${PER_CASE_BUDGET_MS}ms budget elapsed.`,
      },
    };
  }

  let label: string | undefined;
  let reasoning: string | undefined;
  try {
    const out = await judge({
      promptKey: unit.promptKey,
      vars: unit.vars,
      runId,
      timeoutMs,
    });
    label = out.score;
    reasoning = out.reasoning;
  } catch (error) {
    // Per-case budget elapsed while this call was in-flight — the
    // judge client surfaces aborts via the SDK's AbortError; surface
    // it as TIMEOUT regardless of the underlying error class.
    if (budgetExceededRef.value || isAbortError(error)) {
      return {
        kind: "error",
        evaluatorId: unit.evaluatorId,
        index: unit.index,
        failure: {
          kind: "timeout",
          message: `${unit.operation} did not return within the per-case ${PER_CASE_BUDGET_MS}ms budget.`,
        },
      };
    }
    if (error instanceof JudgeTimeoutError) {
      return {
        kind: "error",
        evaluatorId: unit.evaluatorId,
        index: unit.index,
        failure: {
          kind: "timeout",
          message: `${unit.operation} did not return within ${error.timeoutMs}ms.`,
        },
      };
    }
    if (error instanceof JudgeResponseParseError) {
      return {
        kind: "error",
        evaluatorId: unit.evaluatorId,
        index: unit.index,
        failure: {
          kind: "unmappable-result",
          message: `${unit.operation} returned an unparseable response: ${error.message}`,
        },
      };
    }
    return {
      kind: "error",
      evaluatorId: unit.evaluatorId,
      index: unit.index,
      failure: {
        kind: "agentcore-error",
        message:
          error instanceof Error
            ? `${unit.operation} failed: ${error.name}: ${error.message}`
            : `${unit.operation} failed.`,
      },
    };
  }

  // Map the raw rubric label through the Score_Scale (Requirement 4.3).
  const mapped = mapScoreLabel(unit.scale, label);
  if (mapped === undefined) {
    return {
      kind: "error",
      evaluatorId: unit.evaluatorId,
      index: unit.index,
      label,
      reasoning,
      failure: {
        kind: "unmappable-result",
        message: `${unit.operation} returned label '${label}' which is not present in the ${unit.evaluatorId} Score_Scale.`,
      },
    };
  }

  return {
    kind: "ok",
    evaluatorId: unit.evaluatorId,
    index: unit.index,
    label,
    reasoning,
    value: mapped,
  };
}

/**
 * Emits a structured one-line log per judge unit so operators can read
 * the model's verdict and its justification in CloudWatch without
 * persisting the reasoning to DynamoDB. Only called from the per-case
 * pipeline below, after each unit lands.
 *
 * The log shape is intentionally compact and grep-friendly — one line
 * per unit, prefixed with `[evaluation:judge]` and the runId/caseId so
 * a CloudWatch Logs Insights query can isolate a single case quickly.
 */
function logJudgeUnit(
  runId: string,
  caseId: string,
  result: UnitResult,
): void {
  const truncate = (s: string | undefined, max: number): string =>
    s == null ? "" : s.length > max ? s.slice(0, max) + "…" : s;

  if (result.kind === "ok") {
    console.log(
      `[evaluation:judge] runId=${runId} caseId=${caseId} ` +
        `evaluator=${result.evaluatorId} index=${result.index} ` +
        `label=${JSON.stringify(result.label)} ` +
        `value=${result.value.toFixed(4)} ` +
        `reasoning=${JSON.stringify(truncate(result.reasoning, 800))}`,
    );
    return;
  }
  console.log(
    `[evaluation:judge] runId=${runId} caseId=${caseId} ` +
      `evaluator=${result.evaluatorId} index=${result.index} ` +
      `failure.kind=${result.failure.kind} ` +
      `label=${JSON.stringify(result.label ?? null)} ` +
      `reasoning=${JSON.stringify(truncate(result.reasoning, 400))} ` +
      `message=${JSON.stringify(truncate(result.failure.message, 400))}`,
  );
}

/**
 * Returns true for the AWS SDK / fetch `AbortError` shapes that surface
 * when the per-case `AbortController` cancels an in-flight Converse call.
 * The SDK throws either `AbortError` or a generic error with `name ===
 * "AbortError"`; both are accepted.
 */
function isAbortError(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const err = error as { name?: unknown };
  return err.name === "AbortError";
}

/**
 * Picks the dominant failure when more than one judge unit failed. The
 * precedence mirrors {@link assembleCaseEvaluation}'s documented order:
 *
 *   `timeout` > `agentcore-error` > `unmappable-result` > (none)
 *
 * `insufficient-trace` is never produced here — that variant is raised by
 * the pre-flight check before any Converse call runs.
 */
function pickDominantFailure(
  failures: ReadonlyArray<FailureContext | undefined>,
): FailureContext | undefined {
  const nonEmpty = failures.filter(
    (f): f is FailureContext => f !== undefined,
  );
  if (nonEmpty.length === 0) return undefined;
  return (
    nonEmpty.find((f) => f.kind === "timeout") ??
    nonEmpty.find((f) => f.kind === "agentcore-error") ??
    nonEmpty.find((f) => f.kind === "unmappable-result") ??
    nonEmpty[0]
  );
}

// ---------------------------------------------------------------------------
// Per-case evaluation pipeline (shared with the harness)
// ---------------------------------------------------------------------------

/**
 * Builds the concrete list of {@link JudgeUnit}s to fan out for one test
 * case from the rendered prompt context surfaces. Order in the returned
 * array is irrelevant — `aggregateScores` indexes by evaluator id — but
 * this implementation lists GoalSuccessRate first, then per-assistant-turn
 * Helpfulness, then per-tool-call ToolSelectionAccuracy so test snapshots
 * have a deterministic order.
 */
function buildJudgeUnits(
  rendered: JudgePromptContext,
): JudgeUnit[] {
  const units: JudgeUnit[] = [];

  // 1 GoalSuccessRate (session-level).
  units.push({
    evaluatorId: EVALUATOR_GOAL,
    index: 0,
    promptKey: "judge_goal_success_rate",
    vars: {
      available_tools: rendered.availableTools,
      context: rendered.context,
    },
    scale: GOAL_SUCCESS_SCALE,
    operation: `Bedrock judge ${EVALUATOR_GOAL}`,
  });

  // N Helpfulness (one per assistant turn).
  for (const t of rendered.assistantTurns) {
    units.push({
      evaluatorId: EVALUATOR_HELPFULNESS,
      index: t.index,
      promptKey: "judge_helpfulness",
      vars: {
        context: t.context,
        assistant_turn: t.assistantTurn,
      },
      scale: HELPFULNESS_SCALE,
      operation: `Bedrock judge ${EVALUATOR_HELPFULNESS}#${t.index}`,
    });
  }

  // M ToolSelectionAccuracy (one per execute_tool entry).
  for (const t of rendered.toolTurns) {
    units.push({
      evaluatorId: EVALUATOR_TOOL_ACCURACY,
      index: t.index,
      promptKey: "judge_tool_selection",
      vars: {
        available_tools: rendered.availableTools,
        context: t.context,
        tool_turn: t.toolTurn,
      },
      scale: TOOL_SELECTION_SCALE,
      operation: `Bedrock judge ${EVALUATOR_TOOL_ACCURACY}#${t.index}`,
    });
  }

  return units;
}

/**
 * Counts the assistant inference steps and `execute_tool` steps in the
 * trace. A trace with zero of both is the `INSUFFICIENT_TRACE` short-
 * circuit case (Requirement 2.8). A trace with at least one of either
 * kind is submittable.
 */
function countSubmittableSteps(trace: ExecutionTrace): {
  assistantTurns: number;
  toolCalls: number;
} {
  let assistantTurns = 0;
  let toolCalls = 0;
  for (const step of trace.steps) {
    if (step.type === "inference") assistantTurns += 1;
    else if (step.type === "tool") toolCalls += 1;
  }
  return { assistantTurns, toolCalls };
}

/**
 * Folds successful per-call outcomes into the
 * {@link EvaluatorOutcome}[] shape `aggregateScores` expects. Each
 * mapped numeric value becomes one synthesized
 * {@link EvaluationResultContent} entry on the corresponding evaluator's
 * `results` list, in the order the calls were issued.
 */
function buildOutcomes(units: JudgeUnit[], results: UnitResult[]): EvaluatorOutcome[] {
  const byId = new Map<string, EvaluationResultContent[]>();
  // Seed every evaluator family that had at least one unit dispatched
  // so an evaluator with all-failed units shows up in `aggregateScores`
  // with an empty `results` list (and is therefore reported as missing).
  for (const u of units) {
    if (!byId.has(u.evaluatorId)) byId.set(u.evaluatorId, []);
  }
  for (const r of results) {
    if (r.kind !== "ok") continue;
    const list = byId.get(r.evaluatorId);
    if (!list) continue;
    list.push({
      value: r.value,
      label: r.label,
      explanation: r.reasoning,
    });
  }
  return Array.from(byId.entries()).map(([evaluatorId, results]) => ({
    evaluatorId,
    results,
  }));
}

/**
 * Synthesizes an {@link EvaluatorOutcome} for any evaluator family that
 * was *required* by the case (per the rendered context) but had zero
 * units dispatched (e.g. an inference-only trace with no tool calls
 * skips ToolSelectionAccuracy entirely). For aggregator purposes this
 * looks like a missing evaluator.
 *
 * Note: GoalSuccessRate is always required (one unit per case).
 * Helpfulness requires at least one assistant turn; ToolSelectionAccuracy
 * requires at least one tool call. A submittable trace
 * (`assistantTurns > 0 || toolCalls > 0`) may legitimately omit one of
 * the latter two — when it does, that evaluator is still reported as
 * missing so the case ends up with `MISSING_EVALUATOR` + a precise
 * reason.
 */
function ensureEvaluatorPlaceholders(
  outcomes: EvaluatorOutcome[],
  rendered: JudgePromptContext,
): EvaluatorOutcome[] {
  const ids = new Set(outcomes.map((o) => o.evaluatorId));
  const out: EvaluatorOutcome[] = [...outcomes];
  if (!ids.has(EVALUATOR_GOAL)) {
    out.push({ evaluatorId: EVALUATOR_GOAL, results: [] });
  }
  if (!ids.has(EVALUATOR_HELPFULNESS) && rendered.assistantTurns.length > 0) {
    out.push({ evaluatorId: EVALUATOR_HELPFULNESS, results: [] });
  }
  if (!ids.has(EVALUATOR_TOOL_ACCURACY) && rendered.toolTurns.length > 0) {
    out.push({ evaluatorId: EVALUATOR_TOOL_ACCURACY, results: [] });
  }
  return out;
}

/**
 * Filters `aggregated.missingEvaluators` so an evaluator family that the
 * case did not request (e.g. ToolSelectionAccuracy on a trace with zero
 * tool calls) is **not** reported as missing — the platform only
 * requires the score families the trace had units for, plus the always-
 * required GoalSuccessRate.
 */
function trimMissingEvaluators(
  aggregated: AggregatedScores,
  rendered: JudgePromptContext,
): AggregatedScores {
  const required = new Set<string>([EVALUATOR_GOAL]);
  if (rendered.assistantTurns.length > 0) required.add(EVALUATOR_HELPFULNESS);
  if (rendered.toolTurns.length > 0) required.add(EVALUATOR_TOOL_ACCURACY);
  return {
    ...aggregated,
    missingEvaluators: aggregated.missingEvaluators.filter((id) =>
      required.has(id),
    ),
  };
}

/**
 * Runs the pre-flight → render → fan-out → aggregate → assemble pipeline
 * for a single test case session and returns the score / error-state
 * slice that gets persisted on the `TestCaseResult`.
 *
 * This function is the **single shared code path** between the deployed
 * Evaluation Lambda (`handler` below) and the local Evaluation Harness
 * (`scripts/evaluation-harness.ts`, task 6.1) — Requirement 9.6. It is
 * intentionally I/O-free apart from the Bedrock Converse calls so it is
 * directly unit-testable with a mocked judge client and needs no
 * DynamoDB fixtures.
 *
 * Per-case 90-second budget (Requirement 7.2):
 * - A single `AbortController` is created at the start of the call. A
 *   `setTimeout` aborts it when the budget elapses, which causes the SDK
 *   to surface in-flight calls as `AbortError` — those map to `TIMEOUT`.
 * - Calls dispatched after the abort short-circuit immediately to a
 *   `TIMEOUT` failure without consuming network time.
 *
 * Per Requirement 8.5 / 8.8, whenever an error code is set the persisted
 * scores are left unset by {@link assembleCaseEvaluation}; no local-
 * scoring substitute is computed in any branch.
 *
 * @param input - Trace, transcript, snapshot, and expected tool names for one test case.
 * @returns A `caseEvaluation` ready to spread onto a `TestCaseResult`,
 *          plus the aggregator output, per-evaluator raw outcomes, and
 *          per-call diagnostic detail.
 */
export async function evaluateCaseSession(
  input: EvaluateCaseSessionInput,
): Promise<EvaluateCaseSessionOutput> {
  const timeoutMs = input.timeoutMs ?? PER_EVALUATOR_TIMEOUT_MS;
  const budgetMs = input.budgetMs ?? PER_CASE_BUDGET_MS;

  // -------------------------------------------------------------------------
  // 1. Pre-flight: INSUFFICIENT_TRACE short-circuit (Requirement 2.8).
  //    A trace with zero assistant inference steps AND zero execute_tool
  //    entries cannot drive any of the three rubrics, so we record the
  //    error state and skip the Converse fan-out entirely.
  // -------------------------------------------------------------------------
  const counts = countSubmittableSteps(input.trace);
  if (counts.assistantTurns === 0 && counts.toolCalls === 0) {
    return {
      caseEvaluation: assembleCaseEvaluation(undefined, {
        kind: "insufficient-trace",
        message:
          "Captured trace contained no assistant turns and no tool calls; cannot evaluate.",
      }),
      rawOutcomes: [],
      rawJudgeResults: [],
    };
  }

  // -------------------------------------------------------------------------
  // 2. Render the four prompt-context surfaces (Requirement 2.1) via the
  //    pure module — no AWS imports, no I/O.
  // -------------------------------------------------------------------------
  let rendered: JudgePromptContext;
  try {
    rendered = renderJudgePromptContext({
      trace: input.trace,
      transcript: input.transcript,
      snapshot: input.snapshot,
      expectedToolNames: input.expectedToolNames,
    });
  } catch (error) {
    // Rendering should not fail for any well-formed trace, but treat any
    // error as UNMAPPABLE_RESULT so the case is recorded with an
    // explicit error and never silently scored locally
    // (Requirement 8.8).
    return {
      caseEvaluation: assembleCaseEvaluation(undefined, {
        kind: "unmappable-result",
        message:
          error instanceof Error
            ? `Judge prompt rendering failed: ${error.message}`
            : "Judge prompt rendering failed.",
      }),
      rawOutcomes: [],
      rawJudgeResults: [],
    };
  }

  // -------------------------------------------------------------------------
  // 3. Build the concrete list of judge units (1 + N + M).
  // -------------------------------------------------------------------------
  const units = buildJudgeUnits(rendered);

  // -------------------------------------------------------------------------
  // 4. Per-case 90s budget controller (Requirement 7.2).
  //    The judge client honours `process.env` overrides only — we cannot
  //    pass an external AbortSignal through it without changing its
  //    public API. Instead we track the budget locally, abort the
  //    in-flight calls via the per-call SDK timeout (60s) when the
  //    budget elapses, and short-circuit any pending units to TIMEOUT.
  // -------------------------------------------------------------------------
  const controller = new AbortController();
  const budgetExceededRef = { value: false };
  const budgetTimer = setTimeout(() => {
    budgetExceededRef.value = true;
    controller.abort();
  }, budgetMs);

  let results: UnitResult[];
  try {
    results = await Promise.all(
      units.map((unit) =>
        runJudgeUnit(
          unit,
          controller.signal,
          budgetExceededRef,
          timeoutMs,
          // Empty-string `runId` falls back to the live registry —
          // used by the harness and by tests that don't pin a snapshot.
          input.runId ?? "",
        ),
      ),
    );
  } finally {
    clearTimeout(budgetTimer);
  }

  // Emit per-unit diagnostic logs as soon as every unit has settled. We
  // only log when the caller passed a runId/caseId pair (deployed
  // Lambda) so the harness output stays clean. CloudWatch Logs Insights
  // can isolate one case via:
  //   filter @message like /\[evaluation:judge\]/ and runId="<id>"
  if (input.runId && input.caseId) {
    for (const r of results) {
      logJudgeUnit(input.runId, input.caseId, r);
    }
  }

  // -------------------------------------------------------------------------
  // 5. Fold outcomes into the aggregator's expected shape and aggregate.
  // -------------------------------------------------------------------------
  const baseOutcomes = buildOutcomes(units, results);
  const rawOutcomes = ensureEvaluatorPlaceholders(baseOutcomes, rendered);
  const aggregatedRaw = aggregateScores(rawOutcomes);
  const aggregated = trimMissingEvaluators(aggregatedRaw, rendered);

  // -------------------------------------------------------------------------
  // 6. Pick the dominant failure (if any) and assemble the final case
  //    evaluation. `assembleCaseEvaluation` enforces the structural
  //    invariant that an error state leaves all three scores unset.
  // -------------------------------------------------------------------------
  const failure = pickDominantFailure(
    results.map((r) => (r.kind === "error" ? r.failure : undefined)),
  );
  const caseEvaluation = assembleCaseEvaluation(aggregated, failure);

  // -------------------------------------------------------------------------
  // 7. Build the per-call diagnostic detail surfaced to the harness.
  // -------------------------------------------------------------------------
  const rawJudgeResults: JudgeCallDetail[] = results.map((r) => {
    if (r.kind === "ok") {
      return {
        evaluatorId: r.evaluatorId,
        index: r.index,
        label: r.label,
        reasoning: r.reasoning,
        mappedValue: r.value,
      };
    }
    return {
      evaluatorId: r.evaluatorId,
      index: r.index,
      label: r.label,
      reasoning: r.reasoning,
      error: { kind: r.failure.kind, message: r.failure.message ?? "" },
    };
  });

  return { caseEvaluation, aggregated, rawOutcomes, rawJudgeResults };
}

// ---------------------------------------------------------------------------
// DynamoDB injection (singleton, test-overridable)
// ---------------------------------------------------------------------------

let dynamoService: DynamoDBService | null = null;

function getDynamoService(): DynamoDBService {
  if (!dynamoService) {
    dynamoService = new DynamoDBService();
  }
  return dynamoService;
}

/**
 * Test-only injector for the DynamoDB service. Pass `null` to clear the
 * cached singleton between tests.
 *
 * @internal
 */
export function _setDynamoService(service: DynamoDBService | null): void {
  dynamoService = service;
}

// ---------------------------------------------------------------------------
// Lambda handler
// ---------------------------------------------------------------------------

/**
 * Loads the per-case inputs (trace, transcript) and the run-level agent
 * snapshot from DynamoDB.
 *
 * Returns `null` for any missing piece so the caller can record an
 * `UNMAPPABLE_RESULT` without raising — a missing trace or snapshot in a
 * deployed flow indicates an upstream bug, but failing the whole run for
 * one case would violate Requirement 8.7.
 */
async function loadCaseInputs(
  db: DynamoDBService,
  runId: string,
  caseId: string,
  cachedSnapshot: AgentSnapshot | null,
): Promise<{
  trace: ExecutionTrace | null;
  transcript: TranscriptTurn[];
  snapshot: AgentSnapshot | null;
}> {
  const [trace, transcript] = await Promise.all([
    db.getExecutionTrace(runId, caseId),
    db.getTranscript(runId, caseId),
  ]);
  // The snapshot lives at PK=RUN#{runId}, SK=SNAPSHOT and is shared by all
  // cases in the run. Cache the first lookup so a 50-case run only hits
  // DynamoDB once for it.
  const snapshot = cachedSnapshot ?? (await db.getSnapshot(runId));
  return { trace, transcript, snapshot };
}

/**
 * Lambda entry point. For each case in `caseResults`, builds the per-case
 * `TestCaseResult` from the existing fields plus the score / error-state
 * slice produced by {@link evaluateCaseSession}, and persists the merged
 * record to `PK=RUN#{runId}, SK=CASE#{caseId}` (Requirement 1.7).
 *
 * The state machine's input shape is preserved verbatim: the Map step's
 * output is bound to `$.caseResults` (see `state-machine.ts`), and the
 * `runId` and `testCases` arrays are passed through from `PrepareRun`.
 *
 * Error semantics (Requirement 8.7):
 * - A case with no matching `TestCase` is counted in `errors` and skipped
 *   (no result is written; the test scaffold has no expected trajectory).
 * - A case whose `loadCaseInputs` fails or whose Bedrock judge fan-out
 *   yields any error-state code still produces a persisted
 *   `TestCaseResult` (with `evaluationError` set), counted in
 *   `evaluationErrors`. The Lambda's overall return status is unaffected.
 * - A case whose DynamoDB `writeResult` fails is counted in `errors`.
 *
 * @returns A summary used by the `WriteResults` step's run summary item.
 */
export async function handler(
  event: EvaluationInput,
): Promise<EvaluationOutput> {
  const { runId, testCases } = event;
  // Map state output is stored at 'caseResults' by the state machine; the
  // legacy `results` alias is preserved for direct invocations.
  const caseResults = event.caseResults ?? event.results ?? [];

  const testCaseMap = new Map<string, TestCase>();
  for (const tc of testCases) {
    testCaseMap.set(tc.caseId, tc);
  }

  const db = getDynamoService();

  // Snapshot is run-level; load it once and reuse across all cases.
  let cachedSnapshot: AgentSnapshot | null = null;
  try {
    cachedSnapshot = await db.getSnapshot(runId);
  } catch {
    // Tolerate snapshot-load failures: per-case `loadCaseInputs` will
    // re-attempt and the case will end up with an UNMAPPABLE_RESULT
    // error if it remains unavailable.
    cachedSnapshot = null;
  }

  let evaluated = 0;
  let evaluationErrors = 0;
  let errors = 0;

  for (const result of caseResults) {
    const testCase = testCaseMap.get(result.caseId);
    if (!testCase) {
      console.error(
        `[evaluation] No matching test case for caseId=${result.caseId}; skipping.`,
      );
      errors++;
      continue;
    }

    let updatedResult: TestCaseResult;
    try {
      const { trace, transcript, snapshot } = await loadCaseInputs(
        db,
        runId,
        result.caseId,
        cachedSnapshot,
      );
      // Cache the snapshot for subsequent cases in the same run if it
      // wasn't pre-loaded (covers the case where the bulk pre-load failed).
      if (!cachedSnapshot && snapshot) {
        cachedSnapshot = snapshot;
      }

      let caseEvaluation: CaseEvaluation;
      // Per-evaluator-unit detail surfaced to the persisted record so
      // the GUI can drill into "why did the judge score this?" without
      // re-running the evaluation. Populated only on the happy path
      // where `evaluateCaseSession` actually fired Converse calls; the
      // INSUFFICIENT_TRACE / no-snapshot short-circuits return no
      // detail (and don't deserve one — there were no judge calls).
      let evaluationDetails:
        | TestCaseResult["evaluationDetails"]
        | undefined;

      if (!trace) {
        // No trace persisted for this case — record as UNMAPPABLE_RESULT
        // rather than silently invoking the judge with nothing.
        caseEvaluation = assembleCaseEvaluation(undefined, {
          kind: "unmappable-result",
          message:
            "No execution trace was persisted for this case; cannot submit to Bedrock judge.",
        });
      } else if (!snapshot) {
        // Without a snapshot the available-tools list is empty and the
        // ToolSelectionAccuracy rubric cannot be evaluated. Surface as
        // UNMAPPABLE_RESULT so the case is persisted with an explicit
        // error — never silently substitute local scoring.
        caseEvaluation = assembleCaseEvaluation(undefined, {
          kind: "unmappable-result",
          message:
            "No agent snapshot was persisted for this run; cannot evaluate tool selection accuracy.",
        });
      } else {
        const evaluation = await evaluateCaseSession({
          trace,
          transcript,
          snapshot,
          // Only "required" steps drive the `Expected tools:` annotation
          // we hand the judge. Optional steps (e.g. control signals like
          // `Complete` / `Escalate` that the test case authored as
          // `required: false`) are still tracked for status logic in the
          // platform but the judge must not penalise the agent for not
          // emitting them — that's the whole point of marking a step
          // optional.
          expectedToolNames: testCase.type === "rag" ? [] : testCase.successCriteria
            .filter((s: { required?: boolean }) => s.required !== false)
            .map((s: { toolName: string }) => s.toolName),
          // Surface runId/caseId so each per-judge-call line in
          // CloudWatch carries the same correlation tags the rest of
          // the per-case logs use.
          runId,
          caseId: result.caseId,
        });
        caseEvaluation = evaluation.caseEvaluation;
        // Persist the per-evaluator-unit detail alongside the aggregated
        // scores so the GUI can drill into "why did the judge return
        // this score?" via a second GET — no re-evaluation needed.
        // Project `JudgeCallDetail` into the narrower
        // `EvaluationCallDetail` shape that the shared TestCaseResult
        // type carries (the union on `evaluator` is enforced at the
        // type boundary; the Lambda's only legal evaluatorIds are the
        // three Builtin templates listed in the union).
        evaluationDetails = evaluation.rawJudgeResults.map((d) => ({
          evaluator: d.evaluatorId as
            | "Builtin.GoalSuccessRate"
            | "Builtin.Helpfulness"
            | "Builtin.ToolSelectionAccuracy",
          index: d.index,
          ...(d.label !== undefined && { label: d.label }),
          ...(d.mappedValue !== undefined && { mappedValue: d.mappedValue }),
          ...(d.reasoning !== undefined && { reasoning: d.reasoning }),
          ...(d.error !== undefined && { error: d.error }),
        }));
      }

      updatedResult = {
        ...result,
        runId,
        ...caseEvaluation,
        ...(evaluationDetails && evaluationDetails.length > 0 && {
          evaluationDetails,
        }),
      };
    } catch (error) {
      // Defensive: any unexpected error during per-case processing is
      // surfaced as a JUDGE_ERROR-shaped evaluationError so the case is
      // still persisted (Requirement 8.7).
      console.error(
        `[evaluation] Unexpected error evaluating case ${result.caseId}:`,
        error instanceof Error ? error.message : error,
      );
      const caseEvaluation = assembleCaseEvaluation(undefined, {
        kind: "agentcore-error",
        message:
          error instanceof Error
            ? `Evaluation pipeline failed: ${error.message}`
            : "Evaluation pipeline failed.",
      });
      updatedResult = {
        ...result,
        runId,
        ...caseEvaluation,
      };
    }

    try {
      await db.writeResult(updatedResult);
      evaluated++;
      if (updatedResult.evaluationError !== undefined) {
        evaluationErrors++;
      }
    } catch (error) {
      console.error(
        `[evaluation] Failed to persist result for case ${result.caseId}:`,
        error instanceof Error ? error.message : error,
      );
      errors++;
    }
  }

  console.log(
    `[evaluation] Complete: evaluated=${evaluated}, evaluationErrors=${evaluationErrors}, errors=${errors}`,
  );

  return { evaluated, evaluationErrors, errors };
}

// ---------------------------------------------------------------------------
// Re-exports (kept narrow on purpose)
// ---------------------------------------------------------------------------

export type { CaseEvaluation } from "../../shared/utils/evaluation-result";
export type { JudgePromptContext } from "../../shared/utils/judge-prompt-rendering";
