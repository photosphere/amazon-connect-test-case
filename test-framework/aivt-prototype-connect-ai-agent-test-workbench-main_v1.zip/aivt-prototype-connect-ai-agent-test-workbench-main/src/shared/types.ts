/**
 * Shared TypeScript interfaces for the Connect Agent Test Platform.
 *
 * @module types
 */

import { CaseStatus, CommunicationStyle, RunStatus } from "./enums";

// ---------------------------------------------------------------------------
// Test Suite & Test Case
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// RAG Metrics & Thresholds
// ---------------------------------------------------------------------------

/** Per-metric scores from a RAG evaluation (Faithfulness, Correctness, Completeness, Helpfulness). */
export interface RagMetrics {
  faithfulness: number;
  correctness: number;
  completeness: number;
  helpfulness: number;
}

/** Per-metric pass/fail thresholds configured at the suite level. Each value in [0,1]. */
export interface RagThresholds {
  faithfulness: number;
  correctness: number;
  completeness: number;
  helpfulness: number;
}

/** Default RAG thresholds applied when a suite has no explicit ragThresholds. */
export const DEFAULT_RAG_THRESHOLDS: RagThresholds = {
  faithfulness: 0.7,
  correctness: 0.7,
  completeness: 0.7,
  helpfulness: 0.7,
};

// ---------------------------------------------------------------------------
// Retrieved Chunks
// ---------------------------------------------------------------------------

/** A single passage retrieved by the agent's Retrieve tool during a RAG case execution. */
export interface RetrievedChunk {
  /** The full text of the retrieved passage. */
  text: string;
  /** Knowledge base identifier from SpanCitation, if present. */
  knowledgeBaseId?: string;
  /** Content identifier from SpanCitation, if present. */
  contentId?: string;
  /** Chunk title from SpanCitation, if present. */
  title?: string;
  /** Monotonically increasing index across all chunks in the case execution. */
  index: number;
}

// ---------------------------------------------------------------------------
// Test Suite
// ---------------------------------------------------------------------------

/** A collection of test cases targeting a specific agent. */
export interface TestSuite {
  tenantId: string;
  suiteId: string;
  /** Max 128 characters. */
  name: string;
  /** Max 500 characters. */
  description?: string;
  agentId: string;
  assistantId: string;
  /** ISO 8601 timestamp. */
  createdAt: string;
  /** ISO 8601 timestamp. */
  updatedAt: string;
  /**
   * Per-metric pass/fail thresholds for RAG cases in this suite.
   * When absent on a persisted record, the platform applies DEFAULT_RAG_THRESHOLDS at read time.
   */
  ragThresholds?: RagThresholds;
}

/**
 * A {@link TestSuite} enriched with the resolved human-readable agent name
 * for display. This is a response-only type computed at read time by the
 * Suites API (`GET /suites`) — it is NEVER persisted to DynamoDB. The
 * `agentName` is resolved from the agent listing (Connect Q `ListAIAgents`)
 * and falls back to the literal `agentId` when the agent cannot be resolved
 * (agent deleted, API error). See agent-grouped-suites design (R1.1, R1.4).
 */
export interface EnrichedTestSuite extends TestSuite {
  /** Resolved agent display name; falls back to `agentId` if unresolvable. */
  agentName: string;
}

// ---------------------------------------------------------------------------
// Test Case (Discriminated Union)
// ---------------------------------------------------------------------------

/** Base fields shared by all test case types. */
interface TestCaseBase {
  suiteId: string;
  caseId: string;
  /** Max 100 characters. */
  name: string;
  /** Max 2000 characters. */
  description: string;
  /** Discriminator: "tool_sequence" or "rag". */
  type: "tool_sequence" | "rag";
}

/**
 * A tool-sequence test case. Preserves all existing fields from the original
 * TestCase interface. Asserts success against an ordered list of tool invocations.
 */
export interface ToolSequenceTestCase extends TestCaseBase {
  type: "tool_sequence";
  /**
   * Customer's underlying goal for the conversation, in plain prose. Used by
   * two distinct call sites:
   *
   *   1. The Customer_Simulator's prompt — when set, the simulator uses
   *      `goalDescription` as the customer's "scenario" / "goal" line; when
   *      absent, the simulator falls back to `description` (then to
   *      `initialUtterance`) for backward compatibility with test cases
   *      authored before this field existed.
   *   2. The Suggest-Tools scaffold endpoint
   *      (`POST /suites/{suiteId}/cases/scaffold`) — the Bedrock prompt that
   *      proposes a tool sequence. The form's "Goal description" textarea
   *      is captured into this field so a single typed goal drives both
   *      tool suggestion AND the runtime simulator (vs. the prior behaviour
   *      where the goal text was discarded after the suggestion landed).
   *
   * Optional; max 2000 characters. The simulator and scaffold both trim
   * whitespace before use.
   */
  goalDescription?: string;
  persona: string;
  style: CommunicationStyle;
  /** Max 20 key-value pairs. */
  customerKnowledge: Record<string, string>;
  /** Max 1000 characters. */
  initialUtterance: string;
  /** 1–30 tool steps. */
  successCriteria: ToolStep[];
  /**
   * Optional key/value data injected into the Q in Connect session via
   * UpdateSessionData BEFORE the conversation starts. Mirrors how Amazon
   * Connect contact flows seed session context (e.g. ANI / customerPhoneNumber)
   * so the agent has the customer context it needs to drive its tools.
   * Keys become available to the agent's prompt as {{$.Custom.<KEY>}}.
   */
  sessionData?: Record<string, string>;
  /**
   * Optional priming message sent to the agent BEFORE the customer's first
   * utterance, mirroring how Amazon Connect contact flows kick off the agent
   * (e.g. "[System] Customer has reached you. Ask how you can help."). This
   * establishes the assistant's role/context. The agent's response to this
   * priming message is not treated as a customer-facing turn.
   */
  primingMessage?: string;
}

/**
 * A RAG test case. Carries a question and ground truth answer for
 * retrieval-augmented generation evaluation. Single-turn: the question is
 * sent once and the agent's response is scored against the ground truth.
 */
export interface RagTestCase extends TestCaseBase {
  type: "rag";
  /** The customer's literal utterance sent to the agent. 1..1000 chars, trimmed-non-empty. */
  question: string;
  /** The known-good agent reply for metric scoring. 1..4000 chars, trimmed-non-empty. */
  groundTruthAnswer: string;
  /**
   * Optional key/value data injected into the Q in Connect session via
   * UpdateSessionData BEFORE the question is sent. Max 20 pairs. Used to
   * drive content tag filters or other session-data-driven retrieval behavior.
   */
  sessionData?: Record<string, string>;
}

/** Discriminated union of all test case types. */
export type TestCase = ToolSequenceTestCase | RagTestCase;

// ---------------------------------------------------------------------------
// Tool Definitions
// ---------------------------------------------------------------------------

/** A single expected tool invocation step in success criteria. */
export interface ToolStep {
  toolName: string;
  /** Whether this step must be invoked for the case to pass. Defaults to true. */
  required: boolean;
  /** Max 10 parameter checks per step. */
  parameterChecks?: { paramName: string; expectedValue: string }[];
}

/** Definition of a tool available to an agent. */
export interface ToolDefinition {
  toolName: string;
  toolType: string;
  description: string;
  instruction?: string;
  inputSchema: Record<string, unknown>;
  /**
   * Few-shot examples injected by the orchestration runtime alongside the
   * tool description and instruction. Required field on the type so that the
   * compiler catches field-omission bugs at every construction site
   * (`AgentSummary`/`AgentDetail` mappers, `AgentSnapshot` writers, the
   * analysis prompt builder, the config-diff utility).
   *
   * Read-side contract: consumers SHALL treat absence on a persisted record
   * (records written before this field shipped) as `[]`. The DDB read helper
   * normalizes missing/null/non-array values to `[]` so downstream code never
   * needs to optional-chain (R1.2, R1.5, R3.3).
   *
   * Write-side contract: every `ToolDefinition` constructed at runtime
   * (Discovery API response, snapshot persistence) MUST include this field.
   * Order is preserved verbatim from the upstream Q in Connect
   * `GetAIAgent` API; strings are preserved verbatim including embedded
   * whitespace, newlines, and quote characters (R1.3, R1.4).
   */
  examples: string[];
}

// ---------------------------------------------------------------------------
// Test Run & Results
// ---------------------------------------------------------------------------

/** Represents a single execution run of a test suite. */
export interface TestRun {
  suiteId: string;
  runId: string;
  status: RunStatus;
  totalCases: number;
  passed: number;
  failed: number;
  errors: number;
  /** Default 9. */
  concurrency: number;
  /** ISO 8601 timestamp. */
  startTime: string;
  /** ISO 8601 timestamp. */
  endTime?: string;
  sfnExecutionArn: string;
}

/** Machine-readable failure category for evaluation errors. */
export type EvaluationErrorCode =
  | "INSUFFICIENT_TRACE"
  | "TIMEOUT"
  | "JUDGE_ERROR"
  | "UNMAPPABLE_RESULT"
  | "MISSING_EVALUATOR"
  | "RAG_JOB_FAILED"
  | "RAG_JOB_TIMEOUT"
  | "INSUFFICIENT_RAG_DATA"
  | "MALFORMED_RESULT";

/** Result of a single test case within a run. */
export interface TestCaseResult {
  runId: string;
  caseId: string;
  status: CaseStatus;
  toolsInvoked: string[];
  turnCount: number;
  latencyMs: number;
  /** Score 0.0–1.0. */
  goalSuccessScore?: number;
  /** Score 0.0–1.0. */
  helpfulnessScore?: number;
  /** Score 0.0–1.0. */
  toolAccuracyScore?: number;
  errorMessage?: string;
  /**
   * Discriminator indicating whether this result is for a tool-sequence or RAG case.
   * Absent on records persisted before this feature shipped — treat as "tool_sequence".
   */
  caseType?: "tool_sequence" | "rag";
  /**
   * Per-metric scores from the Bedrock RAG Evaluation job (Stage 2) or the
   * opportunistic inline Faithfulness evaluator. Present on RAG cases after
   * Stage 2 completes successfully, and optionally on tool-sequence cases
   * that invoked the Retrieve tool (opportunistic faithfulness only).
   */
  ragMetrics?: {
    faithfulness?: number;
    correctness?: number;
    completeness?: number;
    helpfulness?: number;
  };
  /**
   * The agent's terminal text response captured during Stage 1 execution.
   * Persisted so that Stage 2 (RAG_Evaluate) can read it from DDB without
   * relying on state-machine payload threading. Absent on cases that errored
   * before the agent produced a response.
   */
  agentResponse?: string;
  /**
   * Ordered list of passages the Retrieve tool returned during this case's
   * execution, extracted from ListSpans. Empty array when no chunks were
   * retrieved. Absent on cases that errored before spans were captured.
   */
  retrievedChunks?: RetrievedChunk[];
  /**
   * Evaluation error state recorded when AgentCore Evaluate cannot produce a
   * complete, mappable result for this case. When present, the three score
   * fields above are left unset (no silent local-scoring fallback) — leaving
   * them off the interface as separate optional fields means absence is
   * structurally enforced rather than relying on runtime checks (Req 10.3).
   * The frontend treats the presence of this field as the signal to show the
   * reason in place of scores (Req 10.4).
   */
  evaluationError?: {
    /** Human-readable explanation displayed in the results view (Req 10.4). */
    reason: string;
    /** Machine-readable failure category mapped from the underlying error. */
    code: EvaluationErrorCode;
    /**
     * Names of requested evaluators that did not return a usable result.
     * Populated when `code === "MISSING_EVALUATOR"` (Req 8.7).
     */
    missingEvaluators?: string[];
  };
  /**
   * Per-evaluator-unit detail captured by the Bedrock judge while
   * scoring this case. One entry per attempted Converse call. Surfaced
   * to the GUI so a user can drill into "why did the judge score this
   * 0.5 on Helpfulness?" without re-running the evaluation.
   *
   * Optional for backward compatibility with `TestCaseResult` records
   * persisted before this field existed; the GUI renders a "Reasoning
   * not captured for this run" empty state when the field is absent.
   *
   * See {@link EvaluationCallDetail} for the per-entry shape.
   */
  evaluationDetails?: EvaluationCallDetail[];
  /**
   * Q in Connect session id for this case's conversation. Persisted so
   * the case-detail page can surface it for cross-correlation with
   * CloudWatch logs / Q in Connect ListSpans diagnostics. Optional —
   * an INSUFFICIENT_TRACE / no-snapshot short-circuit produces a result
   * record without a session id.
   */
  sessionId?: string;
  /**
   * Structured turn-by-turn execution trace derived from the Q in
   * Connect ListSpans payload at run time. Present when the
   * conversation driver successfully captured spans for the case;
   * absent on cases that errored before the agent emitted any.
   */
  executionTrace?: ExecutionTrace;
}

/**
 * Per-evaluator-unit detail surfaced from the Bedrock judge to the
 * persisted `TestCaseResult`. Mirrors the shape of `JudgeCallDetail` in
 * `src/backend/orchestration/evaluation.ts`; the two MUST stay in sync —
 * the Lambda projects `JudgeCallDetail` into this type when it builds
 * the persisted record.
 *
 * Field semantics:
 *   - `evaluator` — which Builtin template the call exercised.
 *   - `index` — unit index within that evaluator family (0 for the
 *     single GoalSuccessRate call; 0..N-1 for Helpfulness / 0..M-1 for
 *     ToolSelectionAccuracy).
 *   - `label` — raw rubric label the judge returned (`"Yes"`,
 *     `"Very Helpful"`, etc.). Absent on calls that failed before
 *     returning a parseable response.
 *   - `mappedValue` — the `[0,1]` score the label was mapped to via
 *     the Score_Scale tables. Absent when the label was unmappable or
 *     the call failed.
 *   - `reasoning` — the judge's free-text explanation (≤250 words).
 *   - `error` — failure category and message when the call did not
 *     complete successfully.
 */
export interface EvaluationCallDetail {
  evaluator:
    | "Builtin.GoalSuccessRate"
    | "Builtin.Helpfulness"
    | "Builtin.ToolSelectionAccuracy";
  index: number;
  label?: string;
  mappedValue?: number;
  reasoning?: string;
  error?: {
    kind:
      | "timeout"
      | "agentcore-error"
      | "unmappable-result"
      | "insufficient-trace"
      | "missing-evaluator";
    message: string;
  };
}

// ---------------------------------------------------------------------------
// Transcript
// ---------------------------------------------------------------------------

/** A single turn in a conversation transcript. */
export interface TranscriptTurn {
  turnNumber: number;
  role: "customer" | "agent";
  text: string;
  toolSelected?: string;
  /** ISO 8601 timestamp. */
  timestamp: string;
  elapsedMs: number;
}

// ---------------------------------------------------------------------------
// Execution Trace (from ListSpans)
// ---------------------------------------------------------------------------

/** Inference-level metadata extracted from ListSpans span attributes. */
export interface InferenceMetadata {
  usageInputTokens?: number;
  usageOutputTokens?: number;
  usageTotalTokens?: number;
  requestModel?: string;
  requestMaxTokens?: number;
  temperature?: number;
  timeToFirstTokenMs?: number;
  responseFinishReasons?: string[];
  promptArn?: string;
  promptId?: string;
  promptName?: string;
  promptVersion?: number;
  aiAgentVersion?: number;
  /** Joined from attributes.systemInstructions[].text.value with "\n\n". */
  systemInstructions?: string;
}

/**
 * A single tool invocation captured from a ListSpans `execute_tool` span.
 * Includes the arguments the agent passed and the result it received, plus a
 * success/error classification — the raw material for debugging failed cases
 * and for the failure-analysis recommendation engine.
 */
export interface ToolInvocation {
  /** The tool name (e.g. "verifyIdentity"). */
  toolName: string;
  /** Arguments the agent passed to the tool (best-effort parsed JSON or raw string). */
  arguments?: unknown;
  /** The tool's returned result (best-effort parsed JSON or raw string). */
  result?: unknown;
  /** Whether the tool reported success. Derived from the result payload. */
  success: boolean;
  /** ISO 8601 timestamp of when the tool executed (span startTimestamp). */
  timestamp?: string;
}

/**
 * A single step in the agent's execution, derived from ListSpans. Captures
 * either the agent's reasoning/output text (an `inference` span) or a tool
 * invocation (an `execute_tool` span), in chronological order.
 */
export interface ExecutionStep {
  /** Sequence index (chronological, 0-based). */
  index: number;
  /** The kind of step. */
  type: "inference" | "tool" | "agent" | "other";
  /** The span name from ListSpans (e.g. "inference", "execute_tool"). */
  spanName: string;
  /** Agent reasoning/output text for inference steps (if present). */
  text?: string;
  /** Tool details for tool steps. */
  tool?: ToolInvocation;
  /** Which AI agent handled this step (e.g. "AnyBank"). */
  aiAgentName?: string;
  /** The AI agent type (e.g. "ORCHESTRATION", "SELF_SERVICE"). */
  aiAgentType?: string;
  /** ISO 8601 timestamp (span startTimestamp). */
  timestamp?: string;
  /** Wall-clock duration of this span in whole milliseconds (non-negative). */
  durationMs?: number;
  /** Agent's chain-of-thought reasoning (distinct from customer-facing text). */
  reasoning?: string;
  /** Inference-level metadata (only on type === "inference" steps). */
  inferenceMetadata?: InferenceMetadata;
}

/**
 * Structured turn-by-turn execution trace for a single test case, derived from
 * the session's ListSpans reasoning data. Persisted to DynamoDB (SK="TRACE")
 * for debugging failed tests and feeding the failure-analysis engine.
 */
export interface ExecutionTrace {
  /** The Q in Connect session ID this trace was derived from. */
  sessionId: string;
  /** Ordered execution steps (reasoning + tool calls). */
  steps: ExecutionStep[];
  /** Ordered list of tool names actually executed (authoritative, from spans). */
  toolSequence: string[];
  /** Which AI agent handled the session (e.g. "AnyBank"). */
  aiAgentName?: string;
  /** The AI agent type that handled the session. */
  aiAgentType?: string;
  /** ISO 8601 timestamp when the trace was captured. */
  capturedAt: string;
}

// ---------------------------------------------------------------------------
// Agent Information
// ---------------------------------------------------------------------------

/** Summary view of an agent (list context). */
export interface AgentSummary {
  agentId: string;
  name: string;
  type: "ORCHESTRATION";
  toolCount: number;
  modelId: string;
}

/** Detailed view of an agent including tools and prompt. */
export interface AgentDetail {
  agentId: string;
  name: string;
  type: "ORCHESTRATION";
  systemPrompt: string;
  modelId: string;
  tools: ToolDefinition[];
}

/** Point-in-time snapshot of agent configuration captured at test run start. */
export interface AgentSnapshot {
  tools: ToolDefinition[];
  systemPrompt: string;
  modelId: string;
  /** ISO 8601 timestamp. */
  capturedAt: string;
  /**
   * Per-promptKey resolved prompts pinned at run start (Prompt Management
   * feature). The PrepareRun Lambda invokes the Prompt_Resolver for every
   * `promptKey` the run will consume and writes the resulting
   * `ResolvedPromptSnapshot` map here so in-flight runs read their prompts
   * from this snapshot rather than from the live Prompts_Store (R11.1, R16.1).
   *
   * Optional for backward compatibility with snapshots written before this
   * feature shipped — readers that find this field absent fall back to the
   * live registry per R11.4 / R16.2.
   */
  prompts?: Readonly<Record<PromptKey, ResolvedPromptSnapshot>>;
}

// ---------------------------------------------------------------------------
// Prompt Management (Prompt Management feature)
// ---------------------------------------------------------------------------

/**
 * Stable machine identifiers for every promptKey the Prompt_Registry
 * recognises. The set is intentionally closed — adding a new prompt requires
 * extending this union and registering a `PromptDefinition` alongside it.
 *
 * See `.kiro/specs/prompt-management/design.md` (Components and Interfaces)
 * and Requirement 1.1 for the canonical list.
 */
export type PromptKey =
  | "suite_scaffold"
  | "case_scaffold"
  | "failure_analysis"
  | "suite_recommendation"
  | "comparison_summary"
  | "tournament_summary"
  | "variant_generation"
  | "customer_simulator"
  | "judge_goal_success_rate"
  | "judge_helpfulness"
  | "judge_tool_selection"
  | "judge_opportunistic_faithfulness"
  | "rag_evaluation_job";

/**
 * Stable machine identifiers for every Bedrock model the Prompts page
 * exposes in the per-prompt model dropdown. Each `ModelKey` resolves to a
 * canonical cross-region inference-profile id via the `Supported_Models`
 * catalog (see Requirement 17.1 and the design's Supported_Models section).
 */
export type ModelKey =
  | "claude_sonnet_4_6"
  | "claude_haiku_4_5"
  | "claude_opus_4_8"
  | "nova_lite"
  | "nova_pro";

/**
 * One placeholder declaration carried by a `PromptDefinition`. The renderer
 * substitutes `{name}` tokens at render time; `maxOccurrences` is undefined
 * to mean unbounded and is enforced by the validation pipeline (R12.3).
 */
export interface Placeholder {
  name: string;
  description: string;
  maxOccurrences?: number;
}

/**
 * Schema for a single inference parameter the prompt may carry. The
 * dry-render validator and the frontend form derive their bounds from this
 * declaration; the resolved model's `ModelCapabilityProfile` decides which
 * keys are emitted on the wire.
 */
export type InferenceParameterSchema =
  | { kind: "number"; min: number; max: number; default?: number }
  | { kind: "integer"; min: number; max: number; default?: number }
  | { kind: "stringArray"; maxLength: number };

/**
 * One registered prompt — exactly one `PromptDefinition` exists in the
 * `Prompt_Registry` per `PromptKey`. The `defaultText` is the literal that
 * the platform shipped with for that prompt; the `defaultModelKey` is the
 * model the prompt resolves to absent any persisted override.
 */
export interface PromptDefinition {
  promptKey: PromptKey;
  name: string;
  description: string;
  category:
    | "scaffolding"
    | "analysis"
    | "evaluation"
    | "experiment"
    | "simulation"
    | "rag";
  defaultText: string;
  defaultModelKey: ModelKey;
  allowedModels: readonly ModelKey[];
  placeholders: readonly Placeholder[];
  /** Per-key max UTF-8 byte size; absent ⇒ default 64 KiB cap from R12.1. */
  maxTextBytes?: number;
  /** Inference-parameter schema keyed by Converse `inferenceConfig` key name. */
  inferenceParameters: Readonly<Record<string, InferenceParameterSchema>>;
  /** Default values for the inference parameters this prompt ships with. */
  defaultInferenceValues: Readonly<Record<string, unknown>>;
  /**
   * Optional: documented JSON-schema regions in the default text where
   * literal `{name}` braces appear that are NOT placeholders (R12.4).
   */
  literalBraceRegions?: ReadonlyArray<{ start: string; end: string }>;
}

/**
 * A single override row materialised from the `Prompts_Store`. Override is
 * intentionally a sparse update: missing fields fall back to the registry's
 * bundled defaults at resolve time (R10.1 default-fallback invariant).
 */
export interface PromptOverride {
  promptKey: PromptKey;
  text?: string;
  modelKey?: ModelKey;
  inferenceParameters?: Readonly<Record<string, unknown>>;
  version: number;
  /** ISO 8601 timestamp. */
  lastModifiedAt: string;
  lastModifiedBy: string;
  /**
   * Optional human-readable identifier of the user who made this edit,
   * persisted at write time as a display hint alongside the
   * authoritative `lastModifiedBy` Cognito `sub` UUID. Sourced from the
   * caller's `X-User-Email` header (the platform's web client
   * propagates the signed-in user's email from the ID token; machine
   * clients typically omit it). Absent for rows persisted before this
   * field existed and for any caller that did not supply the header.
   *
   * NOT used for authorization or accountability — those continue to
   * key on the `sub` UUID. The email exists only so the Prompts page
   * can show "alice@example.com" instead of a UUID. Callers that
   * persist this value MUST validate it against a basic email regex
   * before storage.
   */
  lastModifiedByEmail?: string;
}

/**
 * A single change-history entry for a prompt, persisted at
 * `PK=PROMPT#{promptKey}, SK=HISTORY#{paddedVersion}`. One entry is
 * written each time a prompt's override is updated or reset; at most
 * {@link PROMPT_HISTORY_MAX_ENTRIES} entries are retained per prompt
 * (R7.2). The shape mirrors the prior {@link PromptOverride} that the
 * entry snapshots, plus the discriminator distinguishing edit-driven
 * snapshots from reset-driven ones.
 *
 * The override's sparse fields (`text`, `modelKey`,
 * `inferenceParameters`) are persisted verbatim so a viewer can see
 * exactly what the user set at that version. Consumers that need the
 * effective (default-merged) values resolve the entry against the
 * registry at read time.
 */
export interface PromptHistoryEntry {
  promptKey: PromptKey;
  /** Version number of the snapshotted override. Matches the SK suffix. */
  version: number;
  /** Sparse text from the snapshotted override; absent when not set. */
  text?: string;
  /** Sparse modelKey from the snapshotted override; absent when not set. */
  modelKey?: ModelKey;
  /** Sparse inferenceParameters from the snapshotted override; absent when not set. */
  inferenceParameters?: Readonly<Record<string, unknown>>;
  /** ISO 8601 timestamp of the override that this entry snapshots. */
  modifiedAt: string;
  /** User identifier of the override that this entry snapshots. */
  modifiedBy: string;
  /**
   * Optional human-readable email captured at the time of the edit
   * that this entry snapshots — same display-hint contract as
   * {@link PromptOverride.lastModifiedByEmail}. Absent on entries
   * created before the field existed and on entries from callers that
   * did not supply the `X-User-Email` header.
   */
  modifiedByEmail?: string;
  /** Whether this snapshot was created by an edit or by a reset. */
  changeKind: "edit" | "reset";
}

/**
 * Per-model declaration of which Bedrock Converse `inferenceConfig` keys the
 * model accepts, which it forbids, and the closed numeric range for each
 * accepted numeric key. The three profile shapes currently in use are
 * `anthropic_claude_4x` (accepts only `maxTokens`, forbids
 * `temperature`/`topP`/`topK`/`stopSequences`),
 * `anthropic_claude_4x_lax` (accepts only `maxTokens`, forbids nothing —
 * for Anthropic 4.x models that silently accept and drop sampling
 * parameters at the wire), and `amazon_nova` (accepts the full Converse
 * parameter set with `topK` placed under
 * `additionalModelRequestFields.inferenceConfig.topK`). See R17.2 / R17.4.
 */
export interface ModelCapabilityProfile {
  key: "anthropic_claude_4x" | "anthropic_claude_4x_lax" | "amazon_nova";
  /** Keys that may appear in the top-level Converse `inferenceConfig`. */
  acceptsTopLevel: readonly string[];
  /** Keys that may appear under `additionalModelRequestFields.inferenceConfig`. */
  acceptsAdditional: readonly string[];
  /** Keys that MUST NOT appear anywhere — explicit forbid list (R10.4). */
  forbids: readonly string[];
  /** Numeric bounds used by the dry-render validator and the frontend form. */
  numericRanges: Readonly<Record<string, { min: number; max: number }>>;
}

/**
 * Output of the `Prompt_Resolver` — exactly what a Bedrock_Callsite needs
 * to construct a Converse request. The `version` is `0` when no override is
 * in effect; `capabilityProfile` is the resolved model's profile, handed to
 * `buildInferenceConfig` to shape the on-the-wire request.
 */
export interface ResolvedPrompt {
  promptKey: PromptKey;
  text: string;
  modelKey: ModelKey;
  /** Canonical cross-region inference-profile id (Bedrock `modelId`). */
  modelId: string;
  inferenceParameters: Readonly<Record<string, unknown>>;
  /** Effective version: `0` when no override is in effect. */
  version: number;
  capabilityProfile: ModelCapabilityProfile;
}

/**
 * Per-promptKey resolved-prompt snapshot persisted on the run-start
 * `AgentSnapshot.prompts` map. This is the run-pinned shape that
 * Bedrock_Callsites read inside a Step Functions execution (R11.2). It
 * carries `capabilityProfileKey` rather than the full profile so that
 * snapshot reads do not have to re-hydrate the registry to construct the
 * Converse request — the runtime helper looks up the profile by key.
 */
export interface ResolvedPromptSnapshot {
  text: string;
  modelKey: ModelKey;
  /** Canonical cross-region inference-profile id (Bedrock `modelId`). */
  modelId: string;
  inferenceParameters: Readonly<Record<string, unknown>>;
  capabilityProfileKey:
    | "anthropic_claude_4x"
    | "anthropic_claude_4x_lax"
    | "amazon_nova";
  /** Effective version at capture; `0` if no override was in effect. */
  version: number;
}

/**
 * One model registered in the `Supported_Models` catalog. Six entries exist
 * today (Claude Sonnet 4.6 / Haiku 4.5 / Opus 4.8, Nova Lite / Pro /
 * Premier). The `routingRegions[]` set drives the IAM grant computed at CDK
 * synth time; `foundationModelArnPattern` is the vendor-scoped wildcard
 * fragment (`anthropic.*` or `amazon.nova-*`) the helper expands per region.
 */
export interface SupportedModel {
  modelKey: ModelKey;
  displayName: string;
  /** Sent as Bedrock `modelId` on every Converse request. */
  inferenceProfileId: string;
  vendor: "anthropic" | "amazon";
  capabilityProfileKey:
    | "anthropic_claude_4x"
    | "anthropic_claude_4x_lax"
    | "amazon_nova";
  maxOutputTokens: number;
  /** AWS Regions the cross-region inference profile may dispatch to. */
  routingRegions: readonly string[];
  /** Foundation-model wildcard fragment used in IAM (vendor-scoped). */
  foundationModelArnPattern: string;
}

// ---------------------------------------------------------------------------
// Recommendations (Actionable Recommendations feature)
// ---------------------------------------------------------------------------

/**
 * The four editable Tool_Surface values the Q in Connect orchestration
 * runtime injects into the agent's effective prompt at inference time. Every
 * recommendation produced by the platform — per-case or per-suite — targets
 * exactly one of these four surfaces (R5.1, R6.5, R8.4).
 *
 * The Recommendation_Engine SHALL drop any recommendation whose `targetField`
 * is not one of these four values before persistence (R5.9).
 */
export type ToolSurface =
  | "tool_description"
  | "tool_instruction"
  | "tool_examples"
  | "system_prompt";

/**
 * Extended recommendation target type. Includes the four existing
 * ToolSurface values plus `test_case` for recommendations that target
 * the test case definition rather than the agent's configuration.
 */
export type RecommendationTarget =
  | "tool_description"
  | "tool_instruction"
  | "tool_examples"
  | "system_prompt"
  | "test_case";

/**
 * The editable fields on a test case that a `test_case` recommendation
 * may target. One of these is required when `targetField === "test_case"`.
 */
export type TestCaseTargetField =
  | "successCriteria"
  | "initialUtterance"
  | "persona"
  | "customerKnowledge"
  | "goalDescription";

/**
 * Operation kind for `tool_examples` recommendations. The discriminator is
 * not stored on the wire — the (currentText, suggestedText) pair encodes the
 * operation per R5.2–5.5:
 *
 *   - `add`     → currentText is empty,     suggestedText is the new example
 *   - `remove`  → currentText is the exact existing example, suggestedText is empty
 *   - `replace` → both currentText and suggestedText are non-empty
 *
 * Renderers do not need to switch on this discriminator; they show
 * `currentText` vs `suggestedText` as a diff regardless of operation kind.
 */
export type ToolExamplesOperation = "add" | "remove" | "replace";

/**
 * Shared recommendation shape used by both the per-case and per-suite paths
 * (R13.1). The frontend renders any recommendation — per-case or per-suite —
 * with a single component because both share these fields.
 *
 * Required-field invariants enforced at persistence time (R13.3 — the
 * Platform SHALL reject any record violating these rules):
 *
 *   - `targetField` is one of the five {@link RecommendationTarget} values
 *     (the four {@link ToolSurface} values plus `test_case`).
 *   - `targetName` is a non-empty string.
 *   - At least one of `currentText` or `suggestedText` is non-empty
 *     (no-op recommendations are rejected).
 *   - When `targetField` is `test_case`, `testCaseField` must be a valid
 *     {@link TestCaseTargetField} value.
 *
 * Per-surface text-presence rules for `tool_examples` operations
 * (R5.2–5.5 / R13.3):
 *
 *   - `tool_examples` remove  → `currentText` non-empty, `suggestedText` empty.
 *   - `tool_examples` add     → `currentText` empty,     `suggestedText` non-empty.
 *   - `tool_examples` replace → both `currentText` and `suggestedText` non-empty.
 *
 * For `tool_examples` recommendations, `targetName` is the tool name (R5.2),
 * never the example string itself — the example text always lives in
 * `currentText` / `suggestedText`. For `system_prompt`, `targetName` is the
 * literal `"system_prompt"`. For `test_case`, `targetName` is the caseId.
 */
export interface Recommendation {
  /** The target this recommendation edits. One of the five valid RecommendationTarget values. */
  targetField: RecommendationTarget;
  /**
   * Tool name for `tool_description` / `tool_instruction` / `tool_examples`,
   * the literal `"system_prompt"` for `system_prompt`, or the caseId for
   * `test_case`. Non-empty (R13.3).
   */
  targetName: string;
  /**
   * The exact existing text to replace or remove. Empty for `tool_examples`
   * add operations; otherwise non-empty per the per-surface rules above
   * (R5.3, R5.4, R5.5, R13.3). For exact-string operations on
   * `tool_examples`, this MUST match an entry in the tool's persisted
   * examples character-for-character.
   */
  currentText: string;
  /**
   * The replacement text or new example. Empty for `tool_examples` remove
   * operations; otherwise non-empty per the per-surface rules above
   * (R5.3, R5.4, R5.5, R13.3).
   */
  suggestedText: string;
  /**
   * Plain-language explanation of why this edit helps. May be empty (R13.1).
   */
  rationale: string;
  /**
   * Present when `targetField === "test_case"`. Identifies which field
   * of the test case definition the recommendation edits. Absent (undefined)
   * for agent-targeted recommendations.
   */
  testCaseField?: TestCaseTargetField;
}

/**
 * Per-suite extension of {@link Recommendation} adding the prioritization
 * and predicted-impact fields produced by the per-suite Recommendation_Engine
 * (R13.2, R8.5).
 *
 * Ordering contract (R9.1, R15.3 — enforced server-side before persistence,
 * never reordered on read):
 *
 *   - `priority` is a positive integer; lower values indicate higher
 *     priority. `1` is the highest priority.
 *   - For any persisted per-suite array, `recommendations[i].priority <=
 *     recommendations[j].priority` for all `i < j` (priority increases
 *     monotonically with array index).
 *
 * `predictedImpact` validity contract (R8.6 — enforced server-side; entries
 * violating these rules are dropped before persistence):
 *
 *   - Every entry in `liftedCaseIds` is the ID of a failed case in the
 *     current run.
 *   - `liftedCaseIds` contains no duplicates within a single recommendation.
 */
export interface PerSuiteRecommendation extends Recommendation {
  /**
   * Positive integer; `1` is the highest priority. Monotonic with array
   * index across the persisted recommendations array (R9.1, R15.3).
   */
  priority: number;
  /**
   * Predicted impact of applying this recommendation to the current run.
   *
   * - `liftedCaseIds`: failed case IDs the recommendation is expected to
   *   flip from failing to passing if applied. Every entry MUST be a failed
   *   case ID in the current run; no duplicates (R8.6).
   * - `rationale`: plain-language explanation of why those cases are
   *   expected to lift.
   */
  predictedImpact: {
    /**
     * Failed case IDs expected to flip to passing. Subset of the run's
     * failed-case-ID set; deduplicated within this recommendation (R8.6).
     */
    liftedCaseIds: string[];
    /** Plain-language explanation of the prediction. */
    rationale: string;
  };
}

// ---------------------------------------------------------------------------
// Experiment & Apply Data Models (Implement Recommendations feature)
// ---------------------------------------------------------------------------

/**
 * Experiment lifecycle statuses. Tracks the progress of a multi-variant
 * experiment from variant generation through cleanup.
 */
export type ExperimentStatus =
  | "generating_variants"
  | "creating_agents"
  | "running"
  | "completed"
  | "failed"
  | "cleanup_in_progress"
  | "cleaned_up";

/**
 * A field where drift was detected between the recommendation's expected
 * value and the live agent's actual value. Used to surface conflicts before
 * writes (R3.6, R11.1, R11.2).
 */
export interface DriftedField {
  targetField: ToolSurface;
  targetName: string;
  expectedText: string;
  actualText: string;
}

/**
 * Configuration for a single variant in a multi-variant experiment.
 * Each variant applies a distinct rewrite strategy to the source
 * recommendations (R5.1, R5.2).
 */
export interface VariantConfig {
  variantLetter: "A" | "B" | "C";
  strategy: string;
  recommendations: Recommendation[];
}

/**
 * Aggregate scores for a single variant, used by the tournament selection
 * logic (R8.2, R8.4).
 */
export interface VariantScore {
  variant: "A" | "B" | "C";
  passRate: number;
  avgGoalSuccessScore: number;
  avgHelpfulnessScore: number;
  avgToolAccuracyScore: number;
  status: "completed" | "error";
}

/**
 * AI-generated tournament summary comparing baseline vs variant results.
 * The winning variant is determined deterministically; the summary explains
 * the quantitative outcome (R8.4, R8.5).
 */
export interface TournamentSummary {
  winningVariant: "A" | "B" | "C" | null;
  summary: string;
  perVariantHighlights: Record<"A" | "B" | "C", {
    improved: string[];
    regressed: string[];
  }>;
}

/**
 * Result of the experiment cleanup operation that deletes temporary agents
 * (R10.1, R10.3).
 */
export interface CleanupResult {
  deletedCount: number;
  failedIds: string[];
  cleanupStatus: "success" | "partial_failure";
}

/**
 * Full experiment record persisted to DynamoDB at
 * PK=RUN#{runId}, SK=EXPERIMENT#{experimentId}.
 *
 * Tracks the complete experiment lifecycle: variant configs, temporary agent
 * IDs, variant run IDs, tournament results, and cleanup status (R12.1).
 */
export interface ExperimentRecord {
  experimentId: string;
  runId: string;
  agentId: string;
  status: ExperimentStatus;
  variantConfigs: VariantConfig[];
  temporaryAgentIds: Record<"A" | "B" | "C", string>;
  variantRunIds: Record<"A" | "B" | "C", string>;
  baselineRunId: string;
  sfnExecutionArn: string;
  tournamentSummary?: TournamentSummary;
  appliedVariant?: "A" | "B" | "C";
  appliedAt?: string; // ISO 8601
  cleanupStatus: "pending" | "success" | "partial_failure";
  failedCleanupAgentIds?: string[];
  createdAt: string; // ISO 8601
  completedAt?: string; // ISO 8601
  /** TTL: 90 days after completedAt (DynamoDB TTL attribute). */
  ttl?: number;
}

/**
 * Audit record persisted at PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}.
 * Captures every agent modification made through the platform for
 * traceability (R15.1, R15.2).
 *
 * The `source` literal is extended by the Prompt Management feature with
 * `prompt_edit` and `prompt_reset` so that prompt-override edits and resets
 * land in the same audit table as recommendation applies (R9.1, R9.2).
 */
export interface AuditRecord {
  tenantId: string;
  timestamp: string; // ISO 8601
  runId: string;
  agentId: string;
  source:
    | "direct_apply"
    | "experiment_apply"
    | "prompt_edit"
    | "prompt_reset";
  experimentId?: string;
  appliedVariant?: "A" | "B" | "C";
  previousVersionId: string;
  newVersionId: string;
  recommendations: Recommendation[];
  driftDetected?: boolean;
  driftedFields?: DriftedField[];
  userDecision?: "apply_anyway" | "normal";
}

/**
 * Per-run apply record persisted at PK=RUN#{runId}, SK=APPLY#DIRECT#{timestamp}.
 * Records which recommendations were applied directly (without experiment) for
 * a given run (R3.5).
 */
export interface ApplyRecord {
  runId: string;
  timestamp: string;
  agentId: string;
  recommendationIndices: number[];
  newVersionId: string;
  source: "direct_apply";
  /** Pre-apply state persisted for revert capability. */
  previousState?: {
    /** The qualified promptId the agent was pointing to before the apply (e.g. "uuid:2"). */
    promptId: string;
    /** The full YAML template text of the prompt before the apply. */
    promptTemplateText: string;
    /** The raw toolConfigurations array from the agent before the apply (SDK shape). */
    toolConfigurations?: unknown[];
  };
  /** Whether this apply has been reverted. */
  reverted?: boolean;
  /** Timestamp when the revert was performed. */
  revertedAt?: string;
}

// ---------------------------------------------------------------------------
// Implement Recommendations API Request/Response Types
// ---------------------------------------------------------------------------

/**
 * Request body for POST /runs/{runId}/apply-recommendations (R14.1).
 */
export interface ApplyRecommendationsRequest {
  mode: "direct";
  agentId: string;
  /** Indices into the run's per-suite recommendations array to apply. */
  recommendationIndices: number[];
  /** When true, skip drift detection and apply anyway (R2.1). */
  force?: boolean;
}

/**
 * Response from POST /runs/{runId}/apply-recommendations (R14.1).
 */
export interface ApplyRecommendationsResponse {
  success: boolean;
  newVersionId?: string;
  error?: string;
  /** Fields where drift was detected (populated on conflict). */
  driftedFields?: DriftedField[];
}

/**
 * Request body for POST /runs/{runId}/experiments (R14.2).
 */
export interface ExperimentCreateRequest {
  mode: "multi_variant";
  agentId: string;
}

/**
 * Response from POST /runs/{runId}/experiments (R14.2).
 */
export interface ExperimentCreateResponse {
  experimentId: string;
  status: ExperimentStatus;
}
