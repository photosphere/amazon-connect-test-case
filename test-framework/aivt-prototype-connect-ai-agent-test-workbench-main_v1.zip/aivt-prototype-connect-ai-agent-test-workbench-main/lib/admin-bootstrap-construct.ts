import * as crypto from 'crypto';
import * as cdk from 'aws-cdk-lib';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as cr from 'aws-cdk-lib/custom-resources';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { Construct } from 'constructs';
import { parseAdminEmail } from './admin-email';

/**
 * Props for {@link AdminUserBootstrapConstruct}.
 */
export interface AdminUserBootstrapProps {
  /**
   * The Cognito User Pool the first admin user is created in.
   */
  userPool: cognito.IUserPool;

  /**
   * The optional admin email supplied at deploy time (CDK context parameter or
   * stack prop). May be `undefined`, empty, or whitespace-only — in which case
   * the construct creates NO bootstrap resources at all (Reqs 7.1, 7.2, 7.4).
   *
   * A non-empty but invalid email throws at synth (via {@link parseAdminEmail}),
   * failing the deploy and creating nothing (Req 6.6).
   */
  adminEmail?: string;
}

/**
 * Optionally bootstraps the first Cognito Web_Client user from an `Admin_Email`
 * deploy parameter, idempotently and with least privilege.
 *
 * Design (see design.md §1.5):
 *  - **Skip path (Reqs 7.1, 7.2, 7.4):** when {@link parseAdminEmail} returns
 *    `{ skip: true }` (email absent/empty/whitespace), this construct creates
 *    NO Lambda, NO custom resource, and NO role — so an admin-less deploy
 *    provisions everything else identically, and removing a previously-set
 *    email on a later deploy deletes the custom resource (whose `Delete` is a
 *    no-op) without touching the existing user.
 *  - **Create path (Reqs 6.1–6.4, 6.7):** a small custom-resource Lambda calls
 *    `AdminCreateUser` with the email as username/attribute, `email_verified`,
 *    and the default `MessageAction` so Cognito emails the temporary password
 *    (FORCE_CHANGE_PASSWORD flow). `UsernameExistsException` is treated as
 *    success without resetting credentials (Req 6.5).
 *  - **Idempotency (Reqs 6.5, 7.3, 12.1):** the custom resource's physical id is
 *    derived deterministically from the email, so repeat deploys with the same
 *    email are no-ops and changing the email converges by creating the new user
 *    (the old user is left untouched by the no-op `Delete`).
 *  - **Least privilege:** the handler role is granted ONLY
 *    `cognito-idp:AdminCreateUser` and `cognito-idp:AdminGetUser` on the
 *    specific user-pool ARN.
 *
 * When the email is skipped, {@link customResource} and {@link bootstrapFn} are
 * `undefined`.
 *
 * Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.7, 7.1, 7.2, 7.3, 7.4, 12.1
 */
export class AdminUserBootstrapConstruct extends Construct {
  /**
   * The custom-resource Lambda that calls `AdminCreateUser`, or `undefined`
   * when the admin email was skipped (no resources created).
   */
  public readonly bootstrapFn?: NodejsFunction;

  /**
   * The CloudFormation custom resource that triggers the bootstrap, or
   * `undefined` when the admin email was skipped.
   */
  public readonly customResource?: cdk.CustomResource;

  constructor(scope: Construct, id: string, props: AdminUserBootstrapProps) {
    super(scope, id);

    // Resolve the optional admin email. Absent/empty/whitespace -> skip (create
    // nothing). Non-empty-but-invalid throws here at synth (Req 6.6) — let it
    // propagate to fail the deploy.
    const parsed = parseAdminEmail(props.adminEmail);
    if ('skip' in parsed) {
      // Skip path (Reqs 7.1, 7.2, 7.4): create NO resources at all.
      return;
    }

    const { email } = parsed;
    const { userPool } = props;

    // --- Custom-resource Lambda handler ---
    // AdminCreateUser/AdminGetUser are long-standing, stable APIs, so the SDK
    // client is left external (served by the Lambda runtime SDK) — the
    // NodejsFunction default. No bundling override is needed.
    this.bootstrapFn = new NodejsFunction(this, 'BootstrapFn', {
      runtime: lambda.Runtime.NODEJS_24_X,
      architecture: lambda.Architecture.ARM_64,
      entry: 'src/backend/bootstrap/admin-user-bootstrap.ts',
      handler: 'handler',
      description:
        'Custom resource that bootstraps the first Cognito admin user via AdminCreateUser',
      timeout: cdk.Duration.minutes(2),
      memorySize: 256,
    });

    // Least privilege: only AdminCreateUser + AdminGetUser on THIS user pool.
    this.bootstrapFn.addToRolePolicy(
      new iam.PolicyStatement({
        sid: 'CognitoAdminUserBootstrap',
        effect: iam.Effect.ALLOW,
        actions: ['cognito-idp:AdminCreateUser', 'cognito-idp:AdminGetUser'],
        resources: [userPool.userPoolArn],
      })
    );

    const provider = new cr.Provider(this, 'BootstrapProvider', {
      onEventHandler: this.bootstrapFn,
    });

    // Stable, email-derived physical resource id (Reqs 6.5, 7.3, 12.1).
    // Deterministic from the email: identical emails across deploys keep the
    // same id (no-op), and a changed email yields a new id so CloudFormation
    // creates the new user while the old custom resource's Delete is a no-op
    // (old user untouched).
    const emailHash = crypto
      .createHash('sha256')
      .update(email)
      .digest('hex')
      .slice(0, 16);
    const physicalResourceId = `admin-user-bootstrap-${emailHash}`;

    this.customResource = new cdk.CustomResource(this, 'AdminUser', {
      serviceToken: provider.serviceToken,
      // resourceType is purely cosmetic in the CloudFormation console.
      resourceType: 'Custom::CognitoAdminUserBootstrap',
      properties: {
        UserPoolId: userPool.userPoolId,
        AdminEmail: email,
        // The stable id is passed through so the handler can echo it back,
        // anchoring idempotency to the email value.
        PhysicalResourceId: physicalResourceId,
      },
    });
  }
}
