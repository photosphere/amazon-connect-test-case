/**
 * Type surface for the Prompt_Registry module.
 *
 * This file is the registry's single import point for the shared
 * prompt-management types declared in `src/shared/types.ts`. Re-exporting
 * them from here lets every other registry module (`resolver.ts`,
 * `runtime.ts`, the per-prompt definition files, the capability-profile
 * catalog, the supported-models catalog) import from one local module
 * instead of reaching into `../../shared/types` directly — which keeps the
 * public surface of the registry self-contained and makes it cheap to add
 * registry-internal types alongside the shared ones.
 *
 * Two registry-internal additions live here that intentionally do NOT live
 * in `src/shared/types.ts`:
 *
 *   - {@link PromptRegistry} — the map shape every registry index file
 *     conforms to. Declared here because it is implementation-internal:
 *     callsites resolve through the {@link ResolvedPrompt} surface, never
 *     by reading the registry map.
 *   - {@link UnknownPromptKeyError} — the typed error the resolver throws
 *     when handed a `promptKey` the registry does not recognise, per the
 *     unknown-promptKey invariant in the design's Prompt_Resolver section
 *     (R10.1 / R10.5).
 *
 * @module backend/orchestration/prompt-registry/types
 */

import type {
  InferenceParameterSchema,
  ModelCapabilityProfile,
  ModelKey,
  Placeholder,
  PromptDefinition,
  PromptKey,
  PromptOverride,
  ResolvedPrompt,
  ResolvedPromptSnapshot,
  SupportedModel,
} from "../../../shared/types";

// ---------------------------------------------------------------------------
// Re-exports of shared prompt-management types
// ---------------------------------------------------------------------------

export type {
  InferenceParameterSchema,
  ModelCapabilityProfile,
  ModelKey,
  Placeholder,
  PromptDefinition,
  PromptKey,
  PromptOverride,
  ResolvedPrompt,
  ResolvedPromptSnapshot,
  SupportedModel,
};

// ---------------------------------------------------------------------------
// Registry-internal types
// ---------------------------------------------------------------------------

/**
 * Shape of the in-code Prompt_Registry: an immutable map keyed by every
 * {@link PromptKey} in the closed union, valued by that prompt's
 * {@link PromptDefinition}.
 *
 * The `Readonly<Record<...>>` form is load-bearing: every consumer of the
 * registry treats both the map and its entries as deeply read-only, so
 * mutating a definition at runtime is a type error rather than a silent
 * regression. The registry index module's exported singleton is typed as
 * this map and `as const`-asserted at the declaration site so TypeScript
 * verifies that exactly the thirteen `PromptKey` values are present (R1.1)
 * and that no extra keys leak in.
 */
export type PromptRegistry = Readonly<Record<PromptKey, PromptDefinition>>;

/**
 * Thrown by the `Prompt_Resolver` when invoked with a `promptKey` value
 * that does not appear in the registry. Distinct from a generic `Error` so
 * that callsites can pattern-match on the type and surface a structured
 * error to their caller (per the design's "Unknown promptKey" invariant in
 * the Prompt_Resolver section), rather than synthesising a default and
 * silently emitting a malformed Bedrock call.
 *
 * The class deliberately preserves the offending `promptKey` on the
 * instance so logs and structured error responses can name it without the
 * caller having to capture it from local scope.
 */
export class UnknownPromptKeyError extends Error {
  /** Make the error nominally distinct from plain `Error` instances. */
  public readonly name = "UnknownPromptKeyError";

  /** The `promptKey` value the resolver was invoked with. */
  public readonly promptKey: string;

  public constructor(promptKey: string) {
    super(`Unknown promptKey: ${promptKey}`);
    this.promptKey = promptKey;
    // Preserve prototype across down-level emit (TS handbook recommendation
    // for subclassing built-in errors).
    Object.setPrototypeOf(this, UnknownPromptKeyError.prototype);
  }
}
