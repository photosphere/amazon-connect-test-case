/**
 * ConflictResolution — Modal dialog shown when drift detection finds that the
 * agent has been modified since the recommendation's snapshot was captured.
 *
 * Displays a table of drifted fields (field name, expected value, actual
 * current value) and provides three actions:
 *   - "Apply anyway" — force-write ignoring drift (R11.4)
 *   - "Cancel" — abort the operation (R11.3)
 *   - "Re-analyze" — trigger a fresh analysis against the current agent state (R11.3)
 *
 * @module components/ImplementRecommendations/ConflictResolution
 */

import Modal from '@cloudscape-design/components/modal';
import Table from '@cloudscape-design/components/table';
import Button from '@cloudscape-design/components/button';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Alert from '@cloudscape-design/components/alert';
import Box from '@cloudscape-design/components/box';
import type { DriftedField } from '../../../../shared/types';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface ConflictResolutionProps {
  driftedFields: DriftedField[];
  onApplyAnyway: () => void;
  onCancel: () => void;
  onReAnalyze: () => void;
  visible: boolean;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Human-readable label for a targetField + targetName combination. */
function fieldLabel(field: DriftedField): string {
  if (field.targetField === 'system_prompt') {
    return 'System Prompt';
  }
  return `${field.targetName} (${field.targetField.replace(/_/g, ' ')})`;
}

/** Truncate long text for display, preserving enough context. */
function truncate(text: string, maxLength = 120): string {
  if (!text) return '(empty)';
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '…';
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function ConflictResolution({
  driftedFields,
  onApplyAnyway,
  onCancel,
  onReAnalyze,
  visible,
}: ConflictResolutionProps): JSX.Element {
  return (
    <Modal
      visible={visible}
      onDismiss={onCancel}
      header="Conflict Detected"
      size="large"
      footer={
        <Box float="right">
          <SpaceBetween direction="horizontal" size="xs">
            <Button variant="link" onClick={onReAnalyze}>
              Re-analyze
            </Button>
            <Button variant="normal" onClick={onCancel}>
              Cancel
            </Button>
            <Button variant="primary" onClick={onApplyAnyway}>
              Apply anyway
            </Button>
          </SpaceBetween>
        </Box>
      }
    >
      <SpaceBetween size="m">
        <Alert type="warning" statusIconAriaLabel="Warning">
          The agent has been modified since this run. The following fields have
          changed:
        </Alert>

        <Table
          columnDefinitions={[
            {
              id: 'field',
              header: 'Field',
              cell: (item: DriftedField) => fieldLabel(item),
              width: 200,
            },
            {
              id: 'expected',
              header: 'Expected value',
              cell: (item: DriftedField) => (
                <Box variant="code">{truncate(item.expectedText)}</Box>
              ),
            },
            {
              id: 'actual',
              header: 'Actual current value',
              cell: (item: DriftedField) => (
                <Box variant="code">{truncate(item.actualText)}</Box>
              ),
            },
          ]}
          items={driftedFields}
          variant="embedded"
          wrapLines
          empty={
            <Box textAlign="center" color="text-status-inactive" padding="s">
              No drifted fields.
            </Box>
          }
        />
      </SpaceBetween>
    </Modal>
  );
}
