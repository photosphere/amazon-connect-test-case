/**
 * Synth-time helper that derives every Bedrock-calling Lambda's IAM grant
 * deterministically from the Prompt_Registry and the Supported_Models
 * catalog.
 *
 * Today, seven CDK constructs (`scaffoldLambda`, `analysisLambda`,
 * `comparisonSummaryLambda`, `suiteRecommendLambda` in `api-construct.ts`;
 * the Evaluation Lambda, the Conversation Driver Lambda's
 * customer-simulator path, the Variant Generator Lambda, and the
 * Tournament Summary Lambda in `orchestration-construct.ts`; the RAG
 * Evaluate Lambda) hand-maintain inline `bedrock:InvokeModel` /
 * `bedrock:Converse` `addToRolePolicy` blocks. Each block hard-codes the
 * Anthropic inference-profile + foundation-model ARN union across
 * `us-east-1 / us-east-2 / us-west-2` independently, which means every
 * model addition (Haiku 4.5, Opus 4.8, the three Nova variants) is a
 * seven-construct copy-paste. {@link computeBedrockGrants} replaces those
 * blocks with one function call per Lambda: pass the `promptKey` list the
 * Lambda's source code invokes the Prompt_Resolver against and the helper
 * walks the registry, computes the union of `allowedModels[]`, and emits
 * the exact `iam.PolicyStatement` whose Resource list is the union of (a)
 * the inference-profile ARNs in the deployment Region and (b) one
 * foundation-model wildcard ARN per Region in each model's
 * `routingRegions[]`.
 *
 * The helper is the synth-time gate that R19 commits to. Adding a new
 * model to a Prompt's `allowedModels[]` is a registry edit followed by a
 * redeploy — never another inline IAM diff. The CDK assertion test in
 * Task 10.6 walks every Bedrock-calling Lambda's role policy and asserts
 * the Resource list is set-equal to the union the helper computes for
 * that Lambda's `promptKey` set, so a hand-edited grant that drifts
 * either wider or narrower than the registry fails the build (R19.3).
 *
 * @module lib/bedrock-grants
 */

import * as cdk from "aws-cdk-lib";
import * as iam from "aws-cdk-lib/aws-iam";

import {
  PROMPT_REGISTRY,
  SUPPORTED_MODELS,
} from "../src/backend/orchestration/prompt-registry";
import type {
  ModelKey,
  PromptKey,
} from "../src/backend/orchestration/prompt-registry";

// ---------------------------------------------------------------------------
// Public surface
// ---------------------------------------------------------------------------

/**
 * Inputs to {@link computeBedrockGrants}.
 *
 * `promptKeys` is the literal list of prompts that the Lambda's source
 * code invokes the Prompt_Resolver against. `stack` is the synth-time
 * `cdk.Stack` whose `region` and `account` tokens are interpolated into
 * the inference-profile ARN — the foundation-model ARNs are
 * account-agnostic and use each model's `routingRegions[]` instead.
 */
export interface ComputeBedrockGrantsArgs {
  /** Closed list of `promptKey` values the Lambda invokes (R19.1). */
  readonly promptKeys: readonly PromptKey[];
  /** Synthesising stack — used for `stack.region` and `stack.account`. */
  readonly stack: cdk.Stack;
}

/**
 * Output of {@link computeBedrockGrants}.
 *
 * `statement` is attached to the Lambda's role via
 * `lambda.addToRolePolicy(grant.statement)`. `modelKeys` is the
 * deduplicated, alphabetically-sorted set of {@link ModelKey} values the
 * statement covers; constructs surface this on the
 * `BedrockGrantSummary` CFN output (R19.6) so a deployment review can
 * read off which models each Lambda is permitted to invoke without
 * parsing the synthesised IAM JSON.
 */
export interface BedrockGrant {
  readonly statement: iam.PolicyStatement;
  readonly modelKeys: readonly ModelKey[];
}

/**
 * Build the Bedrock IAM grant for a Lambda whose source code invokes the
 * Prompt_Resolver against the supplied `promptKeys`.
 *
 * Logic, mirroring the design's "CDK helper `computeBedrockGrants`"
 * section step by step:
 *
 *   1. For each `promptKey` in the input, look up its `allowedModels[]`
 *      from {@link PROMPT_REGISTRY}. Throw if the `promptKey` is not in
 *      the registry — the check is defensive (TypeScript already narrows
 *      to the closed `PromptKey` union at compile time) so a dynamically-
 *      constructed list (e.g. one assembled from a config file in a
 *      future refactor) cannot silently emit a grant for nothing.
 *
 *   2. Union every reachable `modelKey` into a `Set<ModelKey>`. Throw if
 *      any `allowedModels[]` references a `modelKey` not declared in the
 *      {@link SUPPORTED_MODELS} catalog — the registry's definition
 *      files are typed against the closed `ModelKey` union, so this is
 *      another defensive synth-time gate that catches a hand-rolled
 *      definition that bypassed the type system.
 *
 *   3. For each model in the union, look up its {@link SupportedModel}
 *      entry. Throw with an explicit message naming the offending
 *      `modelKey` if the entry has an empty `routingRegions[]` (R19.5).
 *      The {@link SUPPORTED_MODELS} module already self-checks this at
 *      load time, but we re-check here so that a future catalog edit
 *      that bypasses the load-time invariant (for example by mutating
 *      the frozen record under `// @ts-expect-error`) is still caught at
 *      synth.
 *
 *   4. Emit one inference-profile ARN per model in the deployment Region
 *      (`arn:aws:bedrock:${stack.region}:${stack.account}:inference-profile/{inferenceProfileId}`)
 *      and one vendor-scoped foundation-model wildcard ARN per Region in
 *      that model's `routingRegions[]`
 *      (`arn:aws:bedrock:{routingRegion}::foundation-model/{foundationModelArnPattern}`).
 *      Resources are accumulated in a `Set<string>` so identical ARNs
 *      across models that share a vendor and Region collapse to one
 *      entry — Sonnet 4.6, Haiku 4.5, and Opus 4.8 all expand to the
 *      same `anthropic.*` foundation-model wildcards across the same
 *      three Regions.
 *
 *   5. Wrap the Resource list (sorted, for CFN-template stability across
 *      synth runs) in a single `iam.PolicyStatement` whose `actions` are
 *      exactly `["bedrock:InvokeModel", "bedrock:Converse"]` per R19.1
 *      and the design's Architecture / CDK helper section. Return the
 *      statement and the alphabetically-sorted `modelKeys[]` for use on
 *      the `BedrockGrantSummary` CFN output (R19.6).
 *
 * The function is pure with respect to the registry and the catalog —
 * given the same `promptKeys` and a `stack` whose region/account tokens
 * resolve identically, two synth runs produce byte-identical
 * statements. That determinism is what lets the assertion test in Task
 * 10.6 set-equal each Lambda's role-policy Resource list against the
 * helper's output without false-positive drift.
 *
 * @throws Error when any `promptKey` is not declared in
 *   {@link PROMPT_REGISTRY}, when any reachable `modelKey` is not in
 *   {@link SUPPORTED_MODELS}, or when any reachable `SupportedModel` has
 *   an empty `routingRegions[]` (R19.5). The throw aborts CDK synth and
 *   the message names the offending key, so a misconfiguration cannot
 *   reach a deployed stack.
 */
export function computeBedrockGrants(
  args: ComputeBedrockGrantsArgs,
): BedrockGrant {
  const { promptKeys, stack } = args;

  // Step 1 + 2: collect the union of `modelKey` values reachable from
  // the input promptKeys, validating each lookup along the way.
  const modelKeySet = new Set<ModelKey>();
  for (const promptKey of promptKeys) {
    const definition = (
      PROMPT_REGISTRY as Readonly<Record<string, (typeof PROMPT_REGISTRY)[PromptKey] | undefined>>
    )[promptKey];
    if (definition === undefined) {
      throw new Error(
        `computeBedrockGrants: unknown promptKey "${promptKey}" — not declared in PROMPT_REGISTRY`,
      );
    }
    for (const modelKey of definition.allowedModels) {
      if (
        !Object.prototype.hasOwnProperty.call(SUPPORTED_MODELS, modelKey)
      ) {
        throw new Error(
          `computeBedrockGrants: prompt "${promptKey}" references modelKey "${modelKey}" which is not declared in SUPPORTED_MODELS`,
        );
      }
      modelKeySet.add(modelKey);
    }
  }

  // Step 3 + 4: expand every reachable model into its inference-profile
  // ARN (deployment Region) and per-routing-region foundation-model
  // wildcard ARN (cross-region inference target Regions).
  const resourceSet = new Set<string>();
  for (const modelKey of modelKeySet) {
    const model = SUPPORTED_MODELS[modelKey];
    if (model.routingRegions.length === 0) {
      // R19.5: empty `routingRegions[]` is a misconfiguration. The
      // SUPPORTED_MODELS module's load-time invariant already catches
      // this, but the helper re-checks so a runtime mutation cannot
      // produce a Lambda role with no Bedrock resources.
      throw new Error(
        `computeBedrockGrants: modelKey "${modelKey}" has empty routingRegions[] — at least one Region is required to derive a Bedrock IAM grant`,
      );
    }

    resourceSet.add(
      `arn:aws:bedrock:${stack.region}:${stack.account}:inference-profile/${model.inferenceProfileId}`,
    );
    for (const region of model.routingRegions) {
      resourceSet.add(
        `arn:aws:bedrock:${region}::foundation-model/${model.foundationModelArnPattern}`,
      );
    }
  }

  // Step 5: build the single `iam.PolicyStatement` whose `actions` are
  // exactly the two Converse API actions per R19.1 and whose `resources`
  // are the sorted union of inference-profile + foundation-model ARNs.
  // Sorting is purely cosmetic for CFN-template stability — the IAM
  // engine treats the Resource list as a set, so order has no semantic
  // effect.
  const statement = new iam.PolicyStatement({
    effect: iam.Effect.ALLOW,
    actions: ["bedrock:InvokeModel", "bedrock:Converse"],
    resources: Array.from(resourceSet).sort(),
  });

  // Sort `modelKeys[]` alphabetically so the `BedrockGrantSummary` CFN
  // output is byte-stable across synth runs even when the input
  // `promptKeys[]` order changes.
  const modelKeys = Array.from(modelKeySet).sort() as ModelKey[];

  return {
    statement,
    modelKeys,
  };
}
