/**
 * Comparison Summary panel — Bedrock-generated plain-language summary of
 * the diff between two runs of the same suite. Rendered prominently at
 * the top of the Comparison page when the user has selected two runs and
 * clicked Compare.
 *
 * Props:
 *   - `runIdA`, `runIdB`: the two runs being compared. The Lambda
 *     re-orders them by start time internally so the summary always
 *     reads chronologically (older → newer).
 *   - `suiteId`: forwarded as a hint to speed the backend's run lookup
 *     when the SUMMARY by-id record hasn't landed yet. Optional.
 *   - `triggerKey`: a value the parent bumps whenever the underlying
 *     comparison changes (e.g. the user picked a different pair of
 *     runs). The component re-fetches when it changes.
 *
 * The component owns its own loading / error state. The parent doesn't
 * need to thread a fetch promise through — it just renders the panel
 * with the current run pair and the panel handles the rest.
 */
import { useEffect, useState } from 'react';
import Container from '@cloudscape-design/components/container';
import Header from '@cloudscape-design/components/header';
import Box from '@cloudscape-design/components/box';
import Spinner from '@cloudscape-design/components/spinner';
import Alert from '@cloudscape-design/components/alert';
import Button from '@cloudscape-design/components/button';
import SpaceBetween from '@cloudscape-design/components/space-between';
import { apiClient, ApiClientError } from '../api';
import { extractFriendlyModelName } from '../../../shared/utils/model-naming';

interface SummaryResponse {
  summary: string;
  runIdA: string;
  runIdB: string;
  modelId: string;
  generatedAt: string;
}

interface ComparisonSummaryProps {
  runIdA: string;
  runIdB: string;
  suiteId?: string;
  /**
   * Bumped by the parent whenever the underlying run pair changes so the
   * summary refetches. The parent typically passes a stable key like
   * `${sortedA}-${sortedB}` so two clicks on the same comparison reuse
   * the existing result instead of re-paying for the model call.
   */
  triggerKey: string;
}

/**
 * Renders an inline "summary" card that fetches once per `triggerKey`.
 * Idle state never appears (the parent only mounts this when the user
 * has already clicked Compare); loading shows a spinner; success shows
 * the model output verbatim with a small footer crediting the model;
 * error shows a Cloudscape Alert with a Retry button.
 */
export function ComparisonSummary({
  runIdA,
  runIdB,
  suiteId,
  triggerKey,
}: ComparisonSummaryProps) {
  const [data, setData] = useState<SummaryResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    setData(null);

    Promise.resolve(
      apiClient.post<SummaryResponse>('/comparisons/summarize', {
        runIdA,
        runIdB,
        ...(suiteId ? { suiteId } : {}),
      }),
    )
      .then((response) => {
        if (cancelled) return;
        // Defensive: stub responses (e.g. test-suite default post mock)
        // can resolve without a `summary` field. Treat that as "no
        // summary available" rather than rendering empty whitespace.
        if (response && typeof response.summary === 'string' && response.summary.length > 0) {
          setData(response);
        } else {
          setData(null);
        }
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        if (err instanceof ApiClientError) {
          setError(err.message);
        } else {
          setError('Failed to generate comparison summary.');
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [runIdA, runIdB, suiteId, triggerKey]);

  // Manual retry when Bedrock throttled or the Lambda timed out. Resets
  // the local state and re-runs the effect via a tiny seed nonce on the
  // post body so the request isn't deduped client-side.
  const retry = () => {
    setError(null);
    setLoading(true);
    apiClient
      .post<SummaryResponse>('/comparisons/summarize', {
        runIdA,
        runIdB,
        ...(suiteId ? { suiteId } : {}),
      })
      .then((response) => setData(response))
      .catch((err: unknown) => {
        if (err instanceof ApiClientError) {
          setError(err.message);
        } else {
          setError('Failed to generate comparison summary.');
        }
      })
      .finally(() => setLoading(false));
  };

  return (
    <Container
      header={
        <Header
          variant="h2"
          description="A short, model-generated readout of what changed between the two runs. Cites only the diff data the comparison tables show below."
        >
          Comparison summary
        </Header>
      }
    >
      {loading && (
        <SpaceBetween direction="horizontal" size="xs">
          <Spinner />
          <Box color="text-status-inactive">
            Summarizing differences with Bedrock…
          </Box>
        </SpaceBetween>
      )}

      {!loading && error && (
        <Alert
          type="warning"
          dismissible={false}
          action={
            <Button onClick={retry} disabled={loading}>
              Retry
            </Button>
          }
        >
          {error}
        </Alert>
      )}

      {!loading && !error && data && (
        <SpaceBetween size="xs">
          {/*
            Render the summary as preformatted text so the model's
            bullet/whitespace structure survives. The Lambda enforces a
            "no markdown" output rule so we don't need a markdown
            renderer; whitespace + dashes is enough.
          */}
          <Box>
            <pre
              style={{
                margin: 0,
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-word',
                fontFamily: 'inherit',
                fontSize: 'inherit',
                lineHeight: 1.5,
              }}
            >
              {data.summary}
            </pre>
          </Box>
          <Box variant="small" color="text-status-inactive">
            Generated {new Date(data.generatedAt).toLocaleString()} ·{' '}
            {extractFriendlyModelName(data.modelId)}
          </Box>
        </SpaceBetween>
      )}
    </Container>
  );
}
