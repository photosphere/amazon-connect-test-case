/**
 * Unit tests for the Scaffold Lambda handler.
 *
 * Tests the exported pure functions: buildToolSequencePrompt, parseToolSequenceResponse,
 * buildLabelMappingPrompt, parseLabelMappingResponse, extractParameterNames,
 * and the handler's input validation logic — without requiring Bedrock or Q in Connect.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { ConverseCommand } from "@aws-sdk/client-bedrock-runtime";
import {
  buildToolSequencePrompt,
  parseToolSequenceResponse,
  buildLabelMappingPrompt,
  parseLabelMappingResponse,
  extractParameterNames,
  handler,
  _setBedrockClient,
  _setQConnectClient,
  type ScaffoldResponse,
} from "../../src/backend/handlers/scaffold";
import {
  buildInferenceConfig,
  PROMPT_REGISTRY,
  resolvePrompt,
} from "../../src/backend/orchestration/prompt-registry";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import type { DynamoDBService } from "../../src/backend/services/dynamodb";

describe("Scaffold Lambda", () => {
  describe("buildToolSequencePrompt", () => {
    it("includes goal description and all tool names", () => {
      const prompt = buildToolSequencePrompt("Book a flight for me", [
        {
          toolName: "SearchFlights",
          description: "Search for available flights",
          inputSchema: {
            type: "object",
            properties: { origin: { type: "string" }, destination: { type: "string" } },
          },
        },
        {
          toolName: "BookFlight",
          description: "Book a specific flight",
          inputSchema: {
            type: "object",
            properties: { flightId: { type: "string" } },
          },
        },
      ]);

      expect(prompt).toContain("Book a flight for me");
      expect(prompt).toContain("SearchFlights");
      expect(prompt).toContain("BookFlight");
      expect(prompt).toContain("Search for available flights");
      expect(prompt).toContain("Book a specific flight");
    });

    it("includes input schemas when present", () => {
      const prompt = buildToolSequencePrompt("Test goal", [
        {
          toolName: "MyTool",
          description: "A tool",
          inputSchema: { type: "object", properties: { param1: { type: "string" } } },
        },
      ]);

      expect(prompt).toContain("Input Schema");
      expect(prompt).toContain("param1");
    });

    it("omits schema section when inputSchema is empty", () => {
      const prompt = buildToolSequencePrompt("Test goal", [
        {
          toolName: "EmptyTool",
          description: "A tool with no schema",
          inputSchema: {},
        },
      ]);

      expect(prompt).not.toContain("Input Schema");
    });
  });

  describe("parseToolSequenceResponse", () => {
    it("parses valid tool sequence JSON", () => {
      const response = JSON.stringify({
        tools: [
          { toolName: "Auth", position: 1, required: true },
          { toolName: "Lookup", position: 2, required: true },
          { toolName: "Optional", position: 3, required: false },
        ],
      });

      const result = parseToolSequenceResponse(response);
      expect("tools" in result).toBe(true);
      if ("tools" in result) {
        expect(result.tools).toHaveLength(3);
        expect(result.tools[0]).toEqual({
          toolName: "Auth",
          position: 1,
          required: true,
        });
        expect(result.tools[2].required).toBe(false);
      }
    });

    it("handles markdown-fenced JSON", () => {
      const response = `\`\`\`json
{"tools": [{"toolName": "ToolA", "position": 1, "required": true}]}
\`\`\``;

      const result = parseToolSequenceResponse(response);
      expect("tools" in result).toBe(true);
      if ("tools" in result) {
        expect(result.tools).toHaveLength(1);
        expect(result.tools[0].toolName).toBe("ToolA");
      }
    });

    it("returns error when Bedrock signals ambiguity", () => {
      const response = JSON.stringify({
        error: "The goal is ambiguous — multiple tools could apply",
      });

      const result = parseToolSequenceResponse(response);
      expect("error" in result).toBe(true);
      if ("error" in result) {
        expect(result.error).toContain("ambiguous");
      }
    });

    it("returns error on invalid JSON", () => {
      const result = parseToolSequenceResponse("not valid json at all");
      expect("error" in result).toBe(true);
    });

    it("returns error when tools array is missing", () => {
      const response = JSON.stringify({ something: "else" });
      const result = parseToolSequenceResponse(response);
      expect("error" in result).toBe(true);
    });

    it("returns error when all tools are malformed", () => {
      const response = JSON.stringify({
        tools: [{ invalid: true }, { alsoInvalid: "yes" }],
      });
      const result = parseToolSequenceResponse(response);
      expect("error" in result).toBe(true);
    });

    it("defaults required to true when not specified", () => {
      const response = JSON.stringify({
        tools: [{ toolName: "Tool", position: 1 }],
      });

      const result = parseToolSequenceResponse(response);
      expect("tools" in result).toBe(true);
      if ("tools" in result) {
        expect(result.tools[0].required).toBe(true);
      }
    });

    it("filters out malformed tools but keeps valid ones", () => {
      const response = JSON.stringify({
        tools: [
          { toolName: "Valid", position: 1, required: true },
          { invalid: true },
          { toolName: "AlsoValid", position: 2, required: false },
        ],
      });

      const result = parseToolSequenceResponse(response);
      expect("tools" in result).toBe(true);
      if ("tools" in result) {
        expect(result.tools).toHaveLength(2);
        expect(result.tools[0].toolName).toBe("Valid");
        expect(result.tools[1].toolName).toBe("AlsoValid");
      }
    });
  });

  describe("buildLabelMappingPrompt", () => {
    it("includes all parameter names and tool groups", () => {
      const prompt = buildLabelMappingPrompt([
        { paramName: "accountNumber", toolGroup: "AuthTool" },
        { paramName: "destinationCity", toolGroup: "SearchFlights" },
      ]);

      expect(prompt).toContain("accountNumber");
      expect(prompt).toContain("AuthTool");
      expect(prompt).toContain("destinationCity");
      expect(prompt).toContain("SearchFlights");
    });
  });

  describe("parseLabelMappingResponse", () => {
    const params = [
      { paramName: "accountNumber", toolGroup: "Auth" },
      { paramName: "flightId", toolGroup: "Book" },
    ];

    it("parses valid label mapping response", () => {
      const response = JSON.stringify({
        labels: [
          { paramName: "accountNumber", label: "Account Number" },
          { paramName: "flightId", label: "Flight ID" },
        ],
      });

      const result = parseLabelMappingResponse(response, params);
      expect(result.get("accountNumber")).toBe("Account Number");
      expect(result.get("flightId")).toBe("Flight ID");
    });

    it("falls back to param name when Bedrock misses a mapping", () => {
      const response = JSON.stringify({
        labels: [{ paramName: "accountNumber", label: "Account Number" }],
      });

      const result = parseLabelMappingResponse(response, params);
      expect(result.get("accountNumber")).toBe("Account Number");
      expect(result.get("flightId")).toBe("flightId"); // fallback
    });

    it("returns fallback map on invalid JSON", () => {
      const result = parseLabelMappingResponse("not json", params);
      expect(result.get("accountNumber")).toBe("accountNumber");
      expect(result.get("flightId")).toBe("flightId");
    });

    it("returns fallback map when labels array is missing", () => {
      const response = JSON.stringify({ something: "else" });
      const result = parseLabelMappingResponse(response, params);
      expect(result.get("accountNumber")).toBe("accountNumber");
    });

    it("handles markdown-fenced JSON", () => {
      const response = `\`\`\`json
{"labels": [{"paramName": "accountNumber", "label": "Account Number"}]}
\`\`\``;

      const result = parseLabelMappingResponse(response, params);
      expect(result.get("accountNumber")).toBe("Account Number");
    });
  });

  describe("extractParameterNames", () => {
    it("extracts keys from properties object", () => {
      const schema = {
        type: "object",
        properties: {
          name: { type: "string" },
          age: { type: "number" },
          email: { type: "string" },
        },
      };

      const result = extractParameterNames(schema);
      expect(result).toEqual(["name", "age", "email"]);
    });

    it("returns empty array for empty schema", () => {
      expect(extractParameterNames({})).toEqual([]);
    });

    it("handles schema with only meta-keywords", () => {
      const schema = { type: "object", required: ["field1"], description: "test" };
      expect(extractParameterNames(schema)).toEqual([]);
    });

    it("handles flat non-standard schema keys as params", () => {
      // If no "properties" key, extracts non-meta keys
      const schema = { customParam: { type: "string" }, anotherParam: { type: "number" } };
      const result = extractParameterNames(schema);
      expect(result).toContain("customParam");
      expect(result).toContain("anotherParam");
    });
  });

  describe("handler input validation", () => {
    beforeEach(() => {
      // Reset clients to avoid lingering state
      _setBedrockClient(null);
      _setQConnectClient(null);
    });

    it("returns 400 when body is missing", async () => {
      const result = await handler({ pathParameters: { suiteId: "suite-1" } });
      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.error).toContain("Missing request body");
    });

    it("returns 400 when body is invalid JSON", async () => {
      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: "not json",
      });
      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.error).toContain("Invalid JSON");
    });

    it("returns 400 when goalDescription is missing", async () => {
      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: JSON.stringify({ agentId: "agent-1" }),
      });
      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.error).toContain("goalDescription");
    });

    it("returns 400 when agentId is missing", async () => {
      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: JSON.stringify({ goalDescription: "Book a flight" }),
      });
      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.error).toContain("agentId");
    });

    it("returns 400 when goalDescription is empty string", async () => {
      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: JSON.stringify({ goalDescription: "", agentId: "agent-1" }),
      });
      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.error).toContain("goalDescription");
    });
  });

  describe("handler with mocked clients", () => {
    const mockQConnectSend = vi.fn();
    const mockBedrockSend = vi.fn();

    beforeEach(() => {
      mockQConnectSend.mockReset();
      mockBedrockSend.mockReset();

      // Inject mock Q in Connect client
      _setQConnectClient({ send: mockQConnectSend } as any);
      // Inject mock Bedrock client
      _setBedrockClient({ send: mockBedrockSend } as any);

      // Inject a stub Prompts_Store that returns no overrides so
      // `resolvePromptLive("suite_scaffold" / "case_scaffold")` falls back
      // to the registry's bundled defaults. The two interactive
      // callsites only consult `listPromptOverrides` (no `getSnapshot`
      // — they execute outside any run scope), so a minimal duck-typed
      // store with that one method is enough. The reset between tests
      // happens via `_clearPromptRegistryCaches` so the live-override
      // cache from a previous test does not bleed into the next.
      _clearPromptRegistryCaches();
      const promptStore = {
        listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
        getSnapshot: vi.fn().mockResolvedValue(null),
      } as unknown as DynamoDBService;
      _setPromptRegistryStore(promptStore);
    });

    afterEach(() => {
      _setBedrockClient(null);
      _setQConnectClient(null);
      _setPromptRegistryStore(null);
      _clearPromptRegistryCaches();
    });

    it("returns 400 when agent has no tools", async () => {
      mockQConnectSend.mockResolvedValueOnce({
        aiAgent: {
          configuration: {},
        },
      });

      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: JSON.stringify({
          goalDescription: "Help me",
          agentId: "agent-123",
        }),
      });

      expect(result.statusCode).toBe(400);
      const body = JSON.parse(result.body);
      expect(body.error).toContain("No tools found");
    });

    it("returns 422 when Bedrock cannot determine sequence", async () => {
      // Agent has tools
      mockQConnectSend.mockResolvedValueOnce({
        aiAgent: {
          type: "ORCHESTRATION",
          configuration: {
            orchestrationAIAgentConfiguration: {
              toolConfigurations: [
                {
                  toolName: "ToolA",
                  description: "Does A",
                  inputSchema: { type: "object", properties: { x: { type: "string" } } },
                },
              ],
            },
          },
        },
      });

      // Bedrock returns error
      mockBedrockSend.mockResolvedValueOnce({
        output: {
          message: {
            content: [
              { text: JSON.stringify({ error: "Goal is too ambiguous" }) },
            ],
          },
        },
      });

      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: JSON.stringify({
          goalDescription: "Do something vague",
          agentId: "agent-123",
        }),
      });

      expect(result.statusCode).toBe(422);
      const body = JSON.parse(result.body);
      expect(body.error).toContain("Unable to infer tool sequence");
      expect(body.reason).toContain("ambiguous");
    });

    it("returns 200 with suggested tools and knowledge template on success", async () => {
      // Agent has tools with input schemas
      mockQConnectSend.mockResolvedValueOnce({
        aiAgent: {
          type: "ORCHESTRATION",
          configuration: {
            orchestrationAIAgentConfiguration: {
              toolConfigurations: [
                {
                  toolName: "AuthenticateCustomer",
                  description: "Verify customer identity",
                  inputSchema: {
                    type: "object",
                    properties: {
                      accountNumber: { type: "string" },
                      dateOfBirth: { type: "string" },
                    },
                  },
                },
                {
                  toolName: "SearchFlights",
                  description: "Search for available flights",
                  inputSchema: {
                    type: "object",
                    properties: {
                      origin: { type: "string" },
                      destination: { type: "string" },
                      accountNumber: { type: "string" }, // duplicate
                    },
                  },
                },
              ],
            },
          },
        },
      });

      // First Bedrock call: infer tool sequence
      mockBedrockSend.mockResolvedValueOnce({
        output: {
          message: {
            content: [
              {
                text: JSON.stringify({
                  tools: [
                    { toolName: "AuthenticateCustomer", position: 1, required: true },
                    { toolName: "SearchFlights", position: 2, required: true },
                  ],
                }),
              },
            ],
          },
        },
      });

      // Second Bedrock call: label mapping
      mockBedrockSend.mockResolvedValueOnce({
        output: {
          message: {
            content: [
              {
                text: JSON.stringify({
                  labels: [
                    { paramName: "accountNumber", label: "Account Number" },
                    { paramName: "dateOfBirth", label: "Date of Birth" },
                    { paramName: "origin", label: "Departure City" },
                    { paramName: "destination", label: "Arrival City" },
                  ],
                }),
              },
            ],
          },
        },
      });

      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: JSON.stringify({
          goalDescription: "Rebook my flight",
          agentId: "agent-123",
        }),
      });

      expect(result.statusCode).toBe(200);
      const body = JSON.parse(result.body) as ScaffoldResponse;

      // Verify suggested tools
      expect(body.suggestedTools).toHaveLength(2);
      expect(body.suggestedTools[0].toolName).toBe("AuthenticateCustomer");
      expect(body.suggestedTools[0].position).toBe(1);
      expect(body.suggestedTools[0].required).toBe(true);
      expect(body.suggestedTools[1].toolName).toBe("SearchFlights");

      // Verify knowledge template - deduplication should keep accountNumber
      // grouped under AuthenticateCustomer (first tool that uses it)
      expect(body.customerKnowledgeTemplate).toHaveLength(4);

      const accountEntry = body.customerKnowledgeTemplate.find(
        (e) => e.key === "accountNumber"
      );
      expect(accountEntry).toBeDefined();
      expect(accountEntry!.toolGroup).toBe("AuthenticateCustomer");
      expect(accountEntry!.label).toBe("Account Number");

      // origin and destination should be under SearchFlights
      const originEntry = body.customerKnowledgeTemplate.find(
        (e) => e.key === "origin"
      );
      expect(originEntry).toBeDefined();
      expect(originEntry!.toolGroup).toBe("SearchFlights");
      expect(originEntry!.label).toBe("Departure City");
    });

    it("returns 500 on unexpected error", async () => {
      mockQConnectSend.mockRejectedValueOnce(new Error("Connection failed"));

      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: JSON.stringify({
          goalDescription: "Do something",
          agentId: "agent-123",
        }),
      });

      expect(result.statusCode).toBe(500);
      const body = JSON.parse(result.body);
      expect(body.error).toContain("Internal server error");
    });

    it("issues Converse with the inferenceConfig and modelId from the resolved prompt registry entry", async () => {
      // Compute the wire shape the handler ought to produce — directly from
      // the same registry helpers the migrated handler calls. The test
      // asserts the bridge between `resolvePromptLive` and `ConverseCommand`
      // is wired correctly: every bundled-default key set by
      // `buildInferenceConfig` reaches the SDK call site, and no forbidden
      // key (legacy `temperature: 0` literals from the pre-migration
      // handler) leaks through.
      const suitePrompt = resolvePrompt("suite_scaffold", new Map());
      const casePrompt = resolvePrompt("case_scaffold", new Map());
      const expectedSuite = buildInferenceConfig(suitePrompt);
      const expectedCase = buildInferenceConfig(casePrompt);

      // Same agent-config + Bedrock fixture as the success test above.
      mockQConnectSend.mockResolvedValueOnce({
        aiAgent: {
          type: "ORCHESTRATION",
          configuration: {
            orchestrationAIAgentConfiguration: {
              toolConfigurations: [
                {
                  toolName: "AuthenticateCustomer",
                  description: "Verify customer identity",
                  inputSchema: {
                    type: "object",
                    properties: {
                      accountNumber: { type: "string" },
                    },
                  },
                },
              ],
            },
          },
        },
      });
      mockBedrockSend.mockResolvedValueOnce({
        output: {
          message: {
            content: [
              {
                text: JSON.stringify({
                  tools: [
                    { toolName: "AuthenticateCustomer", position: 1, required: true },
                  ],
                }),
              },
            ],
          },
        },
      });
      mockBedrockSend.mockResolvedValueOnce({
        output: {
          message: {
            content: [
              {
                text: JSON.stringify({
                  labels: [{ paramName: "accountNumber", label: "Account Number" }],
                }),
              },
            ],
          },
        },
      });

      const result = await handler({
        pathParameters: { suiteId: "suite-1" },
        body: JSON.stringify({
          goalDescription: "Authenticate the customer",
          agentId: "agent-123",
        }),
      });
      expect(result.statusCode).toBe(200);

      // Two Converse calls — first `suite_scaffold` (tool-sequence), then
      // `case_scaffold` (label mapping). Each must carry the resolved
      // model id and the wire-shape inferenceConfig that
      // `buildInferenceConfig` produced for that prompt.
      expect(mockBedrockSend).toHaveBeenCalledTimes(2);

      const firstCmd = mockBedrockSend.mock.calls[0][0] as ConverseCommand;
      expect(firstCmd).toBeInstanceOf(ConverseCommand);
      expect(firstCmd.input.modelId).toBe(suitePrompt.modelId);
      expect(firstCmd.input.inferenceConfig).toEqual(expectedSuite.inferenceConfig);
      // `anthropic_claude_4x` capability profile — no additional model
      // request fields. The SDK call must not carry a stray `topK` or
      // other Nova-only key.
      expect(firstCmd.input.additionalModelRequestFields).toBeUndefined();
      // The handler must use the resolved system prompt text byte-for-byte.
      expect(firstCmd.input.system).toEqual([{ text: suitePrompt.text }]);
      // Sanity check: the resolved system prompt actually matches the
      // registry's bundled default for this prompt.
      expect(suitePrompt.text).toBe(PROMPT_REGISTRY.suite_scaffold.defaultText);

      const secondCmd = mockBedrockSend.mock.calls[1][0] as ConverseCommand;
      expect(secondCmd).toBeInstanceOf(ConverseCommand);
      expect(secondCmd.input.modelId).toBe(casePrompt.modelId);
      expect(secondCmd.input.inferenceConfig).toEqual(expectedCase.inferenceConfig);
      expect(secondCmd.input.additionalModelRequestFields).toBeUndefined();
      expect(secondCmd.input.system).toEqual([{ text: casePrompt.text }]);
    });
  });
});
