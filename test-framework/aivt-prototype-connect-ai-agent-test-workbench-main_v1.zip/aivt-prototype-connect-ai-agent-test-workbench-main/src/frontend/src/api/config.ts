/**
 * Runtime configuration loader.
 *
 * At deploy time, the CDK stack injects a `config.json` file into the S3 frontend bucket
 * with the API Gateway URL and Cognito settings. This avoids requiring a rebuild when
 * deployment outputs change.
 *
 * The file is loaded once at application startup and cached in memory.
 *
 * Expected format of /config.json:
 * {
 *   "apiEndpoint": "https://xxxxxxx.execute-api.us-east-1.amazonaws.com/prod",
 *   "cognitoUserPoolId": "us-east-1_xxxxxxxx",
 *   "cognitoClientId": "xxxxxxxxxxxxxxxxxxxxxxxxxx",
 *   "cognitoDomain": "your-domain.auth.us-east-1.amazoncognito.com",
 *   "region": "us-east-1",
 *   "instanceMode": "development"
 * }
 *
 * If the document cannot be loaded, returns an unsuccessful response, or is malformed
 * (missing/empty required fields, not valid JSON, etc.), the load surfaces an explicit
 * `error` status. The application MUST display a "runtime configuration unavailable"
 * error state and SHALL NOT issue any API calls (Requirement 5.4).
 */

export interface RuntimeConfig {
  apiEndpoint: string;
  cognitoUserPoolId: string;
  cognitoClientId: string;
  cognitoDomain: string;
  region: string;
  instanceMode: string;
}

/** Reasons the runtime config can fail to load. */
export type RuntimeConfigErrorCode =
  | 'NETWORK_FAILURE'
  | 'UNSUCCESSFUL_RESPONSE'
  | 'MALFORMED_DOCUMENT';

export interface RuntimeConfigError {
  code: RuntimeConfigErrorCode;
  message: string;
}

export type RuntimeConfigStatus =
  | { status: 'pending' }
  | { status: 'ready'; config: RuntimeConfig }
  | { status: 'error'; error: RuntimeConfigError };

/** The exact, exhaustive set of fields the runtime config must contain. */
const REQUIRED_FIELDS: ReadonlyArray<keyof RuntimeConfig> = [
  'apiEndpoint',
  'cognitoUserPoolId',
  'cognitoClientId',
  'cognitoDomain',
  'region',
  'instanceMode',
];

let configState: RuntimeConfigStatus = { status: 'pending' };
let inflight: Promise<RuntimeConfigStatus> | null = null;

function isNonBlankString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

function validatePayload(raw: unknown): RuntimeConfig | RuntimeConfigError {
  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) {
    return {
      code: 'MALFORMED_DOCUMENT',
      message: 'Runtime configuration document is not a JSON object.',
    };
  }
  const record = raw as Record<string, unknown>;
  const missing: string[] = [];
  for (const field of REQUIRED_FIELDS) {
    if (!isNonBlankString(record[field])) {
      missing.push(field);
    }
  }
  if (missing.length > 0) {
    return {
      code: 'MALFORMED_DOCUMENT',
      message: `Runtime configuration is missing or empty: ${missing.join(', ')}.`,
    };
  }
  return {
    apiEndpoint: (record.apiEndpoint as string).trim(),
    cognitoUserPoolId: (record.cognitoUserPoolId as string).trim(),
    cognitoClientId: (record.cognitoClientId as string).trim(),
    cognitoDomain: (record.cognitoDomain as string).trim(),
    region: (record.region as string).trim(),
    instanceMode: (record.instanceMode as string).trim(),
  };
}

/**
 * Load runtime config from /config.json.
 *
 * Should be called once at application startup (e.g., in main.tsx before rendering).
 * The result is cached for the lifetime of the page; subsequent calls return the
 * cached status without re-fetching.
 *
 * Resolves to a {@link RuntimeConfigStatus} of `ready` (config validated) or `error`
 * (network failure, non-OK response, or malformed document). Never throws.
 */
export async function loadConfig(): Promise<RuntimeConfigStatus> {
  if (configState.status !== 'pending') {
    return configState;
  }
  if (inflight) {
    return inflight;
  }

  inflight = (async (): Promise<RuntimeConfigStatus> => {
    let response: Response;
    try {
      response = await fetch('/config.json', { cache: 'no-store' });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Network request failed.';
      configState = {
        status: 'error',
        error: {
          code: 'NETWORK_FAILURE',
          message: `Could not reach /config.json: ${message}`,
        },
      };
      return configState;
    }

    if (!response.ok) {
      configState = {
        status: 'error',
        error: {
          code: 'UNSUCCESSFUL_RESPONSE',
          message: `/config.json returned HTTP ${response.status} ${response.statusText}.`,
        },
      };
      return configState;
    }

    let raw: unknown;
    try {
      raw = await response.json();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Invalid JSON.';
      configState = {
        status: 'error',
        error: {
          code: 'MALFORMED_DOCUMENT',
          message: `/config.json is not valid JSON: ${message}`,
        },
      };
      return configState;
    }

    const validated = validatePayload(raw);
    if ('code' in validated) {
      configState = { status: 'error', error: validated };
      return configState;
    }

    configState = { status: 'ready', config: validated };
    return configState;
  })();

  try {
    return await inflight;
  } finally {
    inflight = null;
  }
}

/**
 * Get the cached runtime config status synchronously.
 * Returns `{ status: 'pending' }` if {@link loadConfig} has not completed yet.
 */
export function getConfigStatus(): RuntimeConfigStatus {
  return configState;
}

/**
 * Get the validated runtime config synchronously, or `null` if not yet loaded
 * or unavailable. Callers MUST NOT issue API calls when this returns `null`
 * (Requirement 5.4 — suppress API calls with an undefined apiEndpoint).
 */
export function getConfig(): RuntimeConfig | null {
  return configState.status === 'ready' ? configState.config : null;
}

/**
 * Test-only helper: reset the cached state so each test starts from `pending`.
 * Not exported from the package barrel.
 */
export function __resetConfigForTests(): void {
  configState = { status: 'pending' };
  inflight = null;
}
