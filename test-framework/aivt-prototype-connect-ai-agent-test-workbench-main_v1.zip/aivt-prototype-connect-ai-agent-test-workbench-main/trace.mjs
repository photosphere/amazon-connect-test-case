// Pulls ListSpans for a session and prints the agent type/name that handled each span.
import { QConnectClient, ListSpansCommand } from "@aws-sdk/client-qconnect";

const assistantId = process.argv[2];
const sessionId = process.argv[3];

if (!assistantId || !sessionId) {
  console.error("usage: node trace.mjs <assistantId> <sessionId>");
  process.exit(1);
}

const client = new QConnectClient({ region: "us-east-1" });

const spans = [];
let nextToken;
do {
  const resp = await client.send(
    new ListSpansCommand({ assistantId, sessionId, nextToken, maxResults: 100 })
  );
  for (const s of resp.spans ?? []) spans.push(s);
  nextToken = resp.nextToken;
} while (nextToken);

console.log(`Total spans: ${spans.length}\n`);

for (const s of spans) {
  // Print the full span so we can inspect every field, plus the key routing fields.
  const keys = Object.keys(s);
  const routing = {
    aiAgentType: s.aiAgentType,
    aiAgentName: s.aiAgentName,
    aiAgentId: s.aiAgentId,
    aiAgentOrchestratorUseCase: s.aiAgentOrchestratorUseCase,
    name: s.name,
    type: s.type,
  };
  console.log("--- span ---");
  console.log("keys:", keys.join(", "));
  console.log("routing:", JSON.stringify(routing));
  console.log("full:", JSON.stringify(s));
  console.log();
}
