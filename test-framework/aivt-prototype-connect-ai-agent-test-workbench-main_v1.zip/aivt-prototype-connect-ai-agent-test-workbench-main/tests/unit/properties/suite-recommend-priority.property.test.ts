// Feature: actionable-recommendations, Property 3: Monotonic priority ordering
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import { sortAndDenseRankSuiteRecommendations } from "@backend/handlers/suite-recommend";
import type { PerSuiteRecommendation, ToolSurface } from "@shared/types";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** The four valid Tool_Surface values (R5.1, R13.2). */
const toolSurfaceArb: fc.Arbitrary<ToolSurface> = fc.constantFrom<ToolSurface>(
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
);

/**
 * Non-empty arbitrary string used for `targetName` and the rationale fields.
 * The sort comparator's lexicographic tiebreaker reads
 * `targetField + "|" + targetName`, so we deliberately exercise a wide
 * character range — empty strings are excluded because the production
 * filter (`filterAndNormalizeSuiteRecommendations`) drops empty
 * `targetName` entries before they reach the sort/renumber pipeline
 * (R13.3).
 */
const nonEmptyStringArb = fc.string({ minLength: 1, maxLength: 40 });

/** Arbitrary case-id string used inside `liftedCaseIds`. */
const caseIdArb = fc.string({ minLength: 1, maxLength: 16 });

/** Arbitrary text body that may legitimately be empty (rationale). */
const maybeEmptyTextArb = fc.string({ minLength: 0, maxLength: 80 });

/**
 * Arbitrary `currentText` / `suggestedText` pair that satisfies the
 * "at least one is non-empty" rule (R13.3). The sort/renumber pipeline
 * does not enforce this rule itself — it only sorts what arrives — but
 * generating realistic survivors of the upstream filter keeps the
 * property test grounded in the contract the function is asked to
 * preserve.
 */
const currentSuggestedPairArb: fc.Arbitrary<{
  currentText: string;
  suggestedText: string;
}> = fc.oneof(
  // currentText non-empty, suggestedText empty (e.g. tool_examples remove)
  fc.record({
    currentText: nonEmptyStringArb,
    suggestedText: fc.constant(""),
  }),
  // currentText empty, suggestedText non-empty (e.g. tool_examples add)
  fc.record({
    currentText: fc.constant(""),
    suggestedText: nonEmptyStringArb,
  }),
  // both non-empty (replace / description / instruction / system_prompt)
  fc.record({
    currentText: nonEmptyStringArb,
    suggestedText: nonEmptyStringArb,
  }),
);

/**
 * Arbitrary {@link PerSuiteRecommendation}. Priority is drawn from
 * 1..100 with arbitrary length `liftedCaseIds` arrays so the test
 * exercises the comparator's three keys (priority asc,
 * liftedCaseIds.length desc, lexicographic tiebreaker).
 */
const perSuiteRecommendationArb: fc.Arbitrary<PerSuiteRecommendation> =
  fc.tuple(
    toolSurfaceArb,
    nonEmptyStringArb,
    currentSuggestedPairArb,
    maybeEmptyTextArb,
    fc.integer({ min: 1, max: 100 }),
    fc.array(caseIdArb, { minLength: 0, maxLength: 10 }),
    maybeEmptyTextArb,
  ).map(
    ([
      targetField,
      targetName,
      texts,
      rationale,
      priority,
      liftedCaseIds,
      impactRationale,
    ]) => ({
      targetField,
      targetName,
      currentText: texts.currentText,
      suggestedText: texts.suggestedText,
      rationale,
      priority,
      predictedImpact: {
        liftedCaseIds,
        rationale: impactRationale,
      },
    }),
  );

/** Arbitrary array of recommendations of length 0..30 per the task spec. */
const recommendationsArrayArb: fc.Arbitrary<PerSuiteRecommendation[]> =
  fc.array(perSuiteRecommendationArb, { minLength: 0, maxLength: 30 });

// ---------------------------------------------------------------------------
// Property 3: Monotonic priority ordering
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 15.3**
 *
 * Property 3: Monotonic priority ordering
 * For any array of `PerSuiteRecommendation` records returned by the
 * Recommendation_Engine for any run, the array shall be ordered such
 * that for all indices i < j, recommendation[i].priority is at most
 * recommendation[j].priority. This invariant is enforced by the
 * server-side sort + dense-rank pipeline regardless of what priority
 * values the model produced and regardless of how long the input array
 * is (including the empty array, which trivially satisfies the
 * predicate).
 */
describe("Feature: actionable-recommendations, Property 3: Monotonic priority ordering", () => {
  it("for all i < j, output[i].priority <= output[j].priority", () => {
    fc.assert(
      fc.property(recommendationsArrayArb, (input) => {
        const sorted = sortAndDenseRankSuiteRecommendations(input);

        // Length is preserved — the function is a pure sort + renumber, never
        // a filter — so the post-image array has the same cardinality.
        expect(sorted).toHaveLength(input.length);

        for (let i = 0; i < sorted.length - 1; i++) {
          expect(sorted[i].priority).toBeLessThanOrEqual(
            sorted[i + 1].priority,
          );
        }
      }),
      { numRuns: 100 },
    );
  });

  it("renumbered priorities are positive integers starting at 1 (dense rank)", () => {
    fc.assert(
      fc.property(recommendationsArrayArb, (input) => {
        const sorted = sortAndDenseRankSuiteRecommendations(input);

        if (sorted.length === 0) return;

        // Dense rank: first element is priority 1, every subsequent
        // priority is either equal to the previous or exactly one
        // greater. No gaps in the numbering.
        expect(sorted[0].priority).toBe(1);
        for (let i = 1; i < sorted.length; i++) {
          const delta = sorted[i].priority - sorted[i - 1].priority;
          expect(delta === 0 || delta === 1).toBe(true);
        }

        // All priorities are positive integers.
        for (const rec of sorted) {
          expect(Number.isInteger(rec.priority)).toBe(true);
          expect(rec.priority).toBeGreaterThanOrEqual(1);
        }
      }),
      { numRuns: 100 },
    );
  });

  it("does not mutate the input array", () => {
    fc.assert(
      fc.property(recommendationsArrayArb, (input) => {
        const snapshot = input.map((r) => ({
          ...r,
          predictedImpact: {
            ...r.predictedImpact,
            liftedCaseIds: [...r.predictedImpact.liftedCaseIds],
          },
        }));
        sortAndDenseRankSuiteRecommendations(input);
        expect(input).toEqual(snapshot);
      }),
      { numRuns: 100 },
    );
  });
});
