/**
 * Global notification bar for API errors.
 * Subscribes to the API notification system and displays Cloudscape Flashbar items.
 * Notifications auto-dismiss after 8 seconds unless manually dismissed.
 */

import { useEffect, useState, useCallback } from 'react';
import Flashbar, { type FlashbarProps } from '@cloudscape-design/components/flashbar';
import { subscribeToNotifications, type ApiNotification } from '../api';

const AUTO_DISMISS_MS = 8_000;

export function NotificationBar() {
  const [items, setItems] = useState<FlashbarProps.MessageDefinition[]>([]);

  const handleNotification = useCallback((notification: ApiNotification) => {
    const item: FlashbarProps.MessageDefinition = {
      id: notification.id,
      type: notification.type,
      content: notification.message,
      dismissible: notification.dismissible,
      onDismiss: () => {
        setItems((prev) => prev.filter((i) => i.id !== notification.id));
      },
    };

    setItems((prev) => {
      // Limit to 5 notifications max to avoid overwhelming the UI
      const updated = [...prev, item];
      if (updated.length > 5) {
        return updated.slice(-5);
      }
      return updated;
    });

    // Auto-dismiss after timeout
    setTimeout(() => {
      setItems((prev) => prev.filter((i) => i.id !== notification.id));
    }, AUTO_DISMISS_MS);
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToNotifications(handleNotification);
    return unsubscribe;
  }, [handleNotification]);

  if (items.length === 0) {
    return null;
  }

  return <Flashbar items={items} />;
}
