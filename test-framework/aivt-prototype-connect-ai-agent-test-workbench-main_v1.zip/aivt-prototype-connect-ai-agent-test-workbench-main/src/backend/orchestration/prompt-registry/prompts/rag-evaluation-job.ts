/**
 * `rag_evaluation_job` — model-only prompt for the Bedrock RAG
 * Evaluation Job (`CreateEvaluationJob`) creator in
 * `src/backend/orchestration/rag-evaluate.ts`.
 *
 * Unlike every other entry in the registry, this prompt does NOT carry
 * a system-prompt body — the Bedrock RAG evaluation job ships its own
 * AWS-managed evaluator templates (`Builtin.Faithfulness` +
 * `Builtin.Correctness` + `Builtin.Completeness` + `Builtin.Helpfulness`)
 * that are rendered server-side. The platform supplies only the
 * evaluator `modelIdentifier` on
 * `evaluatorModelConfig.bedrockEvaluatorModels[].modelIdentifier` per
 * R10.2.
 *
 * Model-only entry shape, per the design's Components and Interfaces
 * section and the Wave-2 task instructions for Task 17.7:
 *
 *   - `defaultText: ""` — there is no template body to render.
 *   - `placeholders: []` — there is no template body to substitute into,
 *     so the validation pipeline's "Placeholder presence" stage trivially
 *     passes for any (empty or non-empty) override text.
 *   - `maxTextBytes: 0` — pins the model-only contract on the Prompts
 *     page and the validation pipeline. An override that tries to
 *     persist any non-empty body fails the size-cap stage with
 *     `PROMPT_TEXT_TOO_LARGE` (observed > 0). The Prompts UI uses this
 *     zero cap as a signal to render the entry as model-only with the
 *     text editor disabled.
 *   - `inferenceParameters: {}` — the RAG evaluation job does not run a
 *     Converse call, so there are no tunable inference values.
 *     Validation's capability-profile compliance stage trivially passes.
 *
 * The Wave-2 migration (Task 17.7) of `rag-evaluate.ts` resolves this
 * prompt via `resolvePromptForRun("rag_evaluation_job", runId)` and
 * wires `prompt.modelId` into the request's
 * `evaluatorModelConfig.bedrockEvaluatorModels[0].modelIdentifier`. The
 * resolved `prompt.text` is intentionally NOT consumed — the registry
 * entry exists purely to surface `modelKey` (and therefore `modelId`)
 * on the Prompts page so operators can switch the evaluator model
 * without a code change.
 *
 * The default model is Anthropic Claude Sonnet 4.6 — the platform's
 * standard judge model. The Wave 3 cleanup (Task 20.3) retired the
 * `JUDGE_MODEL_ID` env-var bridge entirely; operator overrides go
 * through `PUT /prompts/rag_evaluation_job`.
 *
 * @module backend/orchestration/prompt-registry/prompts/rag-evaluation-job
 */

import type { PromptDefinition } from "../types";

const ALLOWED_MODELS = [
  "claude_sonnet_4_6",
  "claude_haiku_4_5",
  "claude_opus_4_8",
  "nova_lite",
  "nova_pro",
] as const;

export const ragEvaluationJobPrompt: PromptDefinition = {
  promptKey: "rag_evaluation_job",
  name: "RAG Evaluation Job — Evaluator Model",
  description:
    "Model-only prompt for the Bedrock RAG Evaluation Job (CreateEvaluationJob). The platform controls only the evaluator-model id; the evaluator templates (Builtin.Faithfulness, Builtin.Correctness, Builtin.Completeness, Builtin.Helpfulness) are AWS-managed and rendered server-side, so this entry has no template body.",
  category: "rag",
  // Empty body — there is no Converse system prompt to render. The
  // Prompts page surfaces this entry as model-only.
  defaultText: "",
  defaultModelKey: "claude_sonnet_4_6",
  allowedModels: ALLOWED_MODELS,
  // Empty placeholders array — this prompt is model-only per the design.
  placeholders: [],
  // Pin the model-only contract: any non-empty override text body is
  // rejected by the validation pipeline's size-cap stage with
  // PROMPT_TEXT_TOO_LARGE (observed > 0). The frontend uses this zero
  // cap as a signal to render the entry with the text editor disabled.
  maxTextBytes: 0,
  // No inference-config knobs apply: the RAG evaluation job orchestrates
  // its own server-side rendering and is not a Converse call. Declared
  // empty so the validation pipeline's capability-profile compliance
  // stage trivially passes.
  inferenceParameters: {},
  defaultInferenceValues: {},
};
