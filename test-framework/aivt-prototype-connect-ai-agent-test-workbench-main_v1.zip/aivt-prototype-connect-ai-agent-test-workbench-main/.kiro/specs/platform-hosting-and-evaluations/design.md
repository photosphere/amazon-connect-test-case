# Design Document

## Overview

This feature closes the three remaining end-to-end gaps in the already-deployed Connect Agent Test Platform (CDK/TypeScript, AWS account 104220062740, `us-east-1`). The core pipeline — mint a Connect contact, drive a multi-turn conversation against a Q in Connect ORCHESTRATION agent, capture the tool sequence and a structured `ExecutionTrace` from `ListSpans`, and persist results to DynamoDB — already works. This design adds:

1. **Frontend Hosting / Deployment** (Requirements 1–5, 12, 13) — produce the React/Cloudscape build, upload it to the `Frontend_Bucket` via a CDK `BucketDeployment`, generate and upload `config.json` from stack outputs, invalidate the CloudFront cache on deploy, and register the `CloudFront_URL` on the Cognito Web_Client callback/logout URLs.
2. **First-User Bootstrap** (Requirements 6, 7) — an optional `Admin_Email` deploy parameter that auto-creates the first Cognito user idempotently via `AdminCreateUser`, while deploys without it still succeed.
3. **Real AgentCore Evaluations Integration + local harness** (Requirements 8–11, 14, 15, 16) — replace the stub `callAgentCoreEvaluation` with a real call to the Amazon Bedrock AgentCore Evaluations `Evaluate` API. Because that API only accepts OpenTelemetry `sessionSpans` with a supported instrumentation scope (not Q in Connect `ListSpans` output and not a plain transcript), the platform translates each captured `ExecutionTrace` into synthetic OTel session spans/events (a standalone, unit-testable module), submits the session, fans out across the three built-in evaluators, maps/aggregates the returned scores onto the `TestCaseResult`, and surfaces an explicit `Evaluation_Error_State` (never a silent local-scoring fallback) on failure/timeout/incompleteness. It also ships a local `Evaluation_Harness` and checked-in real `Span_Fixtures`, plus score-aware run comparison.

### Design Principles

- **Reuse before rebuild.** The hosting work extends the existing `StorageConstruct`, `CognitoAuth`, and stack wiring rather than introducing new patterns. The evaluation work keeps the existing state-machine topology (`EvaluateResults` step) and `TestCaseResult` shape, changing only the Lambda's internals and adding pure helper modules.
- **Pure logic is extracted and property-tested.** The two pieces of real algorithmic logic — trace→OTel translation (Req 9) and score aggregation/normalization (Req 8) plus score-delta classification (Req 15) — are pure functions in `src/shared` / standalone modules, validated by property-based tests and by real `Span_Fixtures`.
- **Infrastructure is verified by synth assertions, not PBT.** Hosting, bootstrap, callback URLs, and idempotency (Reqs 1–7, 12, 13) are declarative CDK; they are verified with `aws-cdk-lib/assertions` template tests, not property-based tests.
- **No silent degradation.** The single most important behavioral change is removing the local-scoring fallback. When AgentCore cannot produce a real result, the platform records an `Evaluation_Error_State` carrying an explicit reason and leaves the three score fields unset.

### Key Research Findings (AgentCore Evaluate API)

These findings ground the integration design and come from the AgentCore Data Plane API reference and developer guide. Content was rephrased for compliance with licensing restrictions.

- **Endpoint shape.** `Evaluate` is a synchronous, per-evaluator call: `POST /evaluations/evaluate/{evaluatorId}`. `evaluatorId` matches `Builtin.{Name}` for built-ins (e.g. `Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, `Builtin.ToolSelectionAccuracy`). ([API_Evaluate](https://docs.aws.amazon.com/bedrock-agentcore/latest/APIReference/API_Evaluate.html))
- **Input is OTel `sessionSpans`.** The request body's `evaluationInput` is a union whose `sessionSpans` member is an array (1–1000) of JSON spans/events in OpenTelemetry format. ([API_EvaluationInput](https://docs.aws.amazon.com/bedrock-agentcore/latest/APIReference/API_EvaluationInput.html))
- **Spans AND events are both required.** A session needs spans plus their corresponding events; spans carrying a supported scope must have matching events or the service returns `ValidationException`. ([understanding-input-spans](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/understanding-input-spans.html))
- **Supported scopes** are `strands.telemetry.tracer`, `opentelemetry.instrumentation.langchain`, `openinference.instrumentation.langchain`. We standardize on `strands.telemetry.tracer`.
- **Span identity & required fields.** Each span requires `spanId`, `traceId`, `name`, `scope.name`, `startTimeUnixNano`, `endTimeUnixNano`, and `attributes` including `session.id`. `invoke_agent` spans are identified by attribute `gen_ai.operation.name = "invoke_agent"` and may carry `gen_ai.agent.tools` / `gen_ai.tool.definitions`; tool spans represent `execute_tool` operations. Events reference their span via `spanId`/`traceId` and carry a `body` with `input.messages[]` / `output.messages[]` (`{content, role}`).
- **Targeting & granularity.** `evaluationTarget` is a union of `traceIds` (32-char, per request-response interaction → trace-level) or `spanIds` (16-char, per tool call → tool-level). Session-level evaluators score the whole submission. This is how a single submitted session fans out across session/trace/tool granularities.
- **Result shape & scale.** The response is `evaluationResults[]`, each an `EvaluationResultContent` with `value` (Double, numeric per the evaluator's rating scale), optional `label`, `explanation`, and optional `errorCode`/`errorMessage`. Built-in quality evaluators use a 0.0–1.0 numeric scale. ([API_EvaluationResultContent](https://docs.aws.amazon.com/bedrock-agentcore/latest/APIReference/API_EvaluationResultContent.html))
- **IAM.** On-demand evaluation requires `bedrock-agentcore:Evaluate` plus `bedrock:InvokeModel`/`bedrock:Converse` (the judge model) on foundation-model and inference-profile ARNs. ([iam-permissions-on-demand](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/iam-permissions-on-demand.html))
- **SDK.** The JavaScript v3 client is `@aws-sdk/client-bedrock-agentcore` (data plane, API version `2024-02-28`) exposing `EvaluateCommand`. Per Requirement 8.2 it is pinned to an exact version and bundled with the Evaluation Lambda (the same bundling pattern already used for `@aws-sdk/client-qconnect`).

> Caveat: the AgentCore Evaluations service surface is new and evolving. The integration isolates all SDK-shape assumptions behind two seams — the translation module's output schema and a thin `AgentCoreEvaluationClient` wrapper — so that a shape change touches one module, and the `Evaluation_Harness` + `Span_Fixtures` let us validate the real shape without a redeploy (Req 11, 16).

## Architecture

### System Context

```mermaid
flowchart TB
    Deployer([Deployer / CI-CD]) -->|cdk deploy -c adminEmail -c callbackUrls| CFN[CloudFormation]

    subgraph Deploy["Deploy-time (CDK)"]
        CFN --> BD[BucketDeployment<br/>build + config.json + invalidation]
        CFN --> Bootstrap[AdminUserBootstrap<br/>custom resource]
        CFN --> Cognito[CognitoAuth<br/>callback/logout URLs]
    end

    BD --> S3[(Frontend_Bucket S3)]
    BD -->|/* invalidation| CF[CloudFront]
    Bootstrap --> UP[Cognito User Pool]
    S3 --> CF

    User([Platform User]) -->|HTTPS| CF
    CF -->|index.html + /config.json| Browser[React/Cloudscape SPA]
    Browser -->|hosted-UI login| UP
    Browser -->|access token| APIGW[API Gateway prod]

    subgraph Runtime["Test run (existing Step Functions)"]
        SFN[State Machine] --> CD[ConversationDriver] --> QIC[Q in Connect ListSpans]
        SFN --> EVAL[Evaluation Lambda]
    end

    APIGW --> SFN
    EVAL -->|EvaluateCommand| AC[AgentCore Evaluations]
    EVAL --> DDB[(DynamoDB)]

    Dev([Developer]) -->|harness CLI| HARNESS[Evaluation_Harness]
    HARNESS -->|same code path| AC
    HARNESS -.->|ListSpans / fixture| QIC
```

### Two Independent Workstreams

The feature splits cleanly into a **deploy-time** workstream (hosting + bootstrap, Reqs 1–7, 12, 13) and a **runtime** workstream (evaluations + harness + comparison, Reqs 8–11, 14, 15, 16). They share no code and can be implemented and reviewed independently; the only coupling is that a working hosted UI (workstream 1) is how a user *sees* the scores (workstream 2) via the results and comparison views.

### Evaluation Data Flow (Req 8, 9, 10)

```mermaid
sequenceDiagram
    participant SM as State Machine
    participant EV as Evaluation Lambda
    participant DB as DynamoDB
    participant TR as trace-to-otel (pure)
    participant AC as AgentCore Evaluate

    SM->>EV: EvaluationInput {runId, caseResults, testCases}
    loop each test case
        EV->>DB: getExecutionTrace(runId, caseId) + getTranscript
        alt trace has no tool spans AND no assistant turns
            EV->>DB: writeResult (Evaluation_Error_State: insufficient trace)
        else submittable
            EV->>TR: buildSessionSpans(trace, transcript, snapshot, expectedTools)
            TR-->>EV: sessionSpans[] + traceIds + toolSpanIds
            par GoalSuccessRate (session)
                EV->>AC: Evaluate Builtin.GoalSuccessRate (no target)
            and Helpfulness (per trace)
                EV->>AC: Evaluate Builtin.Helpfulness (traceIds)
            and ToolSelectionAccuracy (per tool span)
                EV->>AC: Evaluate Builtin.ToolSelectionAccuracy (spanIds, expectedTrajectory)
            end
            AC-->>EV: evaluationResults[] (value 0.0-1.0)
            alt all three evaluators returned
                EV->>EV: aggregate + clamp to [0,1]
                EV->>DB: writeResult {goalSuccessScore, helpfulnessScore, toolAccuracyScore}
            else timeout / error / missing evaluator
                EV->>DB: writeResult (Evaluation_Error_State + partial scores)
            end
        end
    end
    EV-->>SM: {evaluated, errored}
```

The submission is conceptually "submit the session once and let AgentCore fan out" (Req 8.1). Because the on-demand `Evaluate` API is per-evaluator, "once" means **one translation of the session into `sessionSpans`, reused across the three evaluator calls** — the expensive/authoritative step (building the session representation) happens exactly once per test case, and the same `sessionSpans` payload is sent to each evaluator with a different `evaluationTarget`. No evaluator is requested more than once per case.

## Components and Interfaces

### Workstream 1 — Hosting & Bootstrap (CDK)

#### 1.0 Frontend bucket security posture (bucket-level, account-independent)

The `Frontend_Bucket` (in `lib/storage-construct.ts`) enforces its private, no-public-access posture **at the bucket level** so the guarantee holds even when the stack is deployed into an AWS account that does **not** have an account-level S3 Public Access Block configured. The posture does not depend on any account-wide setting:

- **`blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL`** — all four bucket-level public-access-block flags (`BlockPublicAcls`, `IgnorePublicAcls`, `BlockPublicPolicy`, `RestrictPublicBuckets`) are on, so no public ACL or public bucket policy can ever take effect on this bucket.
- **`objectOwnership: s3.ObjectOwnership.BUCKET_OWNER_ENFORCED`** — ACLs are disabled entirely, so no object or bucket ACL can grant access to anyone (no `AllUsers`/`AuthenticatedUsers` grants are even expressible). This is the AWS-recommended default.
- **`enforceSSL: true`** — attaches a bucket policy that denies any request made with `aws:SecureTransport=false`, so assets are TLS-only.
- **`encryption: s3.BucketEncryption.S3_MANAGED`** — SSE-S3 encryption at rest.

Access is granted **exclusively** to the existing CloudFront Origin Access Identity (OAI) via `frontendBucket.grantRead(originAccessIdentity)` (see 1.3 for the distribution wiring); there is no public principal anywhere on the bucket. The `cdk synth` output renders `OwnershipControls` (`BucketOwnerEnforced`), a `PublicAccessBlockConfiguration` with all four flags `true`, and the `SecureTransport` deny statement, confirming the posture is materialized in the template rather than assumed from the account.

The `BucketDeployment` (1.1, 1.2) uploads the build and `config.json` **into this same bucket** and adds no public access and no ACLs — `BucketDeployment` is compatible with `BUCKET_OWNER_ENFORCED` because it does not require object ACLs to upload. This keeps the no-public-access / no-ACL guarantee intact through every deploy. The posture directly supports the security requirements (Requirement 13 — no secrets / least exposure of publicly served assets) and is consistent with the idempotency requirement (Requirement 12 — the bucket's resource identifier is preserved and these declarative properties re-synthesize identically across deploys).

#### 1.1 Frontend build pipeline (Req 1, 12)

The build is produced before/at synth and uploaded via `BucketDeployment`. Two viable mechanisms, with the chosen approach noted:

- **Chosen: `s3deploy.Source.asset(buildDir, { bundling })`** — the asset's Docker/local bundling step runs `npm ci && npm run build` in `src/frontend` and emits `dist/`. This keeps the build reproducible inside `cdk synth`/`deploy` and makes the deploy self-contained for a first-time deployer.
- Fallback for environments without bundling: `Source.asset('src/frontend/dist')` with a documented `npm run build` prerequisite.

A new `FrontendDeploymentConstruct` (in `lib/frontend-deployment-construct.ts`) owns the `BucketDeployment`:

```ts
export interface FrontendDeploymentProps {
  frontendBucket: s3.IBucket;
  distribution: cloudfront.IDistribution;
  runtimeConfig: RuntimeConfigInputs; // resolved stack outputs (see 1.2)
  buildDir?: string;                  // default 'src/frontend/dist'
}
```

Behavior:
- A **deploy-time precondition check** (Req 1.4): a small synth-time guard asserts the resolved build directory exists and contains `index.html` at its root; if not, it throws during synth so no `BucketDeployment` mutates the bucket. (When using `Source.asset` bundling, the bundler failing to emit `index.html` fails the deploy before upload.)
- One `BucketDeployment` uploads the build recursively, preserving structure (Req 1.1), guaranteeing an `index.html` at the root (Req 1.2). CloudFront's existing `defaultRootObject: index.html` and 403/404→`/index.html` SPA fallback (already in `StorageConstruct`) satisfy Reqs 1.3 and 1.5.
- `prune` is set so unchanged deploys are no-ops on object content; `retainOnDelete` defaults keep idempotency (Req 12.1, 12.2, 12.4).

#### 1.2 Runtime config generation (Req 3, 13)

`config.json` is generated from stack outputs and uploaded so it is served at `/config.json`. To guarantee it is **retained after the asset upload** (Req 3.5) and that the build upload does not delete it, `config.json` is delivered as a **second `BucketDeployment` source within the same deployment** (CDK merges sources of one `BucketDeployment`, and `prune` then operates over the union — so both the build and `config.json` survive). Concretely, the construct uses a single `BucketDeployment` with two sources:

```ts
new s3deploy.BucketDeployment(this, 'FrontendDeploy', {
  destinationBucket: props.frontendBucket,
  distribution: props.distribution,
  distributionPaths: ['/*'],                 // Req 2.1 cache invalidation
  sources: [
    s3deploy.Source.asset(buildDir),         // Req 1.1
    s3deploy.Source.jsonData('config.json', resolvedConfig), // Req 3.1-3.4
  ],
  prune: true,
});
```

`resolvedConfig` is built from CDK tokens for the existing outputs and asserted non-empty at synth (Req 3.6):

| `config.json` field | Source | Requirement |
|---|---|---|
| `apiEndpoint` | `api.api.url` (prod stage invoke URL) | 3.2, 3.4 |
| `cognitoUserPoolId` | `cognitoAuth.userPool.userPoolId` | 3.2 |
| `cognitoClientId` | `cognitoAuth.userPoolClient.userPoolClientId` (Web_Client) — **never** `machineClient` | 3.3, 13.3 |
| `cognitoDomain` | hosted-UI domain name | 3.2 |
| `region` | `Stack.of(this).region` | 3.2, 3.4 |

`Source.jsonData` only serializes these five non-secret fields, satisfying Reqs 13.1–13.3 (no M2M secret, no Secrets Manager values). Because the Web_Client has `generateSecret: false`, no client secret can leak.

#### 1.3 CloudFront invalidation (Req 2)

Setting `distribution` + `distributionPaths: ['/*']` on the `BucketDeployment` makes CDK's deployment custom resource create and **wait for** an invalidation to complete before the resource (and therefore the deploy) reports success. This satisfies Reqs 2.1–2.3, and the custom resource failing/timing out fails the deploy (Req 2.4). The 30-minute bound (Req 2.4) is documented; CloudFront invalidations typically complete well within it, and the custom resource surfaces a failure if not.

#### 1.4 Cognito callback/logout URLs (Req 4)

`CognitoAuth` already accepts `callbackUrls`/`logoutUrls`. The change moves CloudFront-URL inclusion into the stack wiring so the `CloudFront_URL` is always registered (Reqs 4.1, 4.2) in addition to any context-provided URLs (Req 4.4, deduplicated). Because the distribution and user-pool client are in the same stack, the stack passes `distribution.distributionDomainName` into `CognitoAuth`.

- **Ordering note:** `UserPoolClient.callbackUrls` must reference the CloudFront URL (a token), which is fine — both resources are in one stack and CloudFormation resolves the dependency. No cross-stack export needed.
- **Validation (Req 4.6):** a pure `validateCallbackUrls(urls: string[]): string[]` helper (in `lib/`) trims, rejects empty/non-absolute-URL entries by throwing at synth, and returns a deduplicated list including the CloudFront URL.
- Reqs 4.3/4.5 (successful vs failed hosted-UI round-trip) are runtime auth behaviors verified by an integration/E2E check, not synth.

#### 1.5 Admin user bootstrap (Req 6, 7)

A new `AdminUserBootstrapConstruct` (`lib/admin-bootstrap-construct.ts`) wraps an `AwsCustomResource` (or a small custom-resource Lambda) that calls Cognito `AdminCreateUser`.

```ts
export interface AdminUserBootstrapProps {
  userPool: cognito.IUserPool;
  adminEmail?: string;   // from context/prop; may be undefined/empty/whitespace
}
```

Behavior:
- **Email resolution & validation (Req 6.6):** a pure `parseAdminEmail(raw?: string): { skip: true } | { email: string }` helper trims and applies the spec's definition (non-empty local part, single `@`, domain containing at least one `.`). Invalid non-empty values throw at synth (fail the deploy, create nothing). Absent/empty/whitespace → `{ skip: true }`.
- **Skip path (Req 7.1, 7.4):** when `skip`, the construct creates **no** bootstrap resource at all, so an admin-less deploy provisions everything else identically (Req 7.2) and removing a previously-set email on a later deploy does not delete the existing user (Req 7.4 — `AdminCreateUser` is the only operation; nothing deletes users).
- **Create path (Req 6.1–6.4, 6.7):** `AdminCreateUser` with `Username = email`, `UserAttributes=[{email}, {email_verified:true}]`, default `MessageAction` (omit `SUPPRESS`) so Cognito sends the temporary-password email (Req 6.2), and the default flow that requires a password change on first sign-in / `FORCE_CHANGE_PASSWORD` (Reqs 6.3, 6.7). Email is the sign-in alias (Req 6.4), consistent with the pool's `signInAliases: { email: true }`.
- **Idempotency (Req 6.5, 7.3, 12.1):** the custom resource treats `UsernameExistsException` as success and never overwrites credentials or resets `FORCE_CHANGE_PASSWORD`. A physical resource id derived from the email keeps repeat deploys as no-ops; changing the email to a new value converges (Req 7.3) by creating the new user (old user untouched).
- **Least privilege:** the bootstrap role is granted only `cognito-idp:AdminCreateUser` (and `AdminGetUser` for the existence check) on the specific user-pool ARN.

### Workstream 2 — Evaluations, Harness, Comparison

#### 2.1 Trace-to-OTel translation module (Req 9, 16) — pure, standalone

`src/backend/orchestration/trace-to-otel.ts` (no AWS imports; pure and unit-testable per Req 9.6) converts an `ExecutionTrace` + `TranscriptTurn[]` + `AgentSnapshot` + expected tool names into the AgentCore `sessionSpans` payload.

```ts
export interface OtelTranslationInput {
  sessionId: string;
  trace: ExecutionTrace;
  transcript: TranscriptTurn[];
  availableTools: ToolDefinition[];   // from agent snapshot (Req 9.3)
  expectedToolNames: string[];        // ordered, from success criteria (Req 9.4)
}

export interface OtelSession {
  sessionSpans: OtelSpanOrEvent[];    // spans + events interleaved (Req 9.1, 9.2)
  invokeAgentTraceIds: string[];      // 32-char hex, one per assistant turn (trace-level target)
  toolSpanIds: string[];             // 16-char hex, one per tool call (tool-level target)
  expectedToolNames: string[];        // echoed for the expectedTrajectory reference input
}

export class InsufficientTraceError extends Error {} // Req 9.5

export function buildOtelSession(input: OtelTranslationInput): OtelSession;
```

Translation rules (grounded in the AgentCore span/event schema and the existing `ExecutionStep`/`ToolInvocation` model):

- **Scope:** every span/event carries `scope.name = "strands.telemetry.tracer"` (a supported scope, Req 9.2).
- **Session id:** every span/event `attributes["session.id"]` (and event `attributes["session.id"]`) is set to `input.sessionId`, grouping the submission under one session (Req 9.1).
- **Ordering & ids:** steps are consumed in the trace's existing chronological order. Each `invoke_agent`-style span (one per assistant turn) gets a fresh 32-char hex `traceId`; each `execute_tool` span gets a fresh 16-char hex `spanId` and is parented to the most recent assistant turn's span. `startTimeUnixNano`/`endTimeUnixNano` are derived from step timestamps when present, else a monotonically increasing synthetic clock that preserves order (Req 9.1).
- **Assistant turns → `invoke_agent` spans + events (trace-level):** `attributes["gen_ai.operation.name"] = "invoke_agent"`, `gen_ai.agent.tools` and `gen_ai.tool.definitions` populated from `availableTools` (Req 9.3 set-of-available-tools), and a paired event whose `body` has `input.messages` (the preceding customer turn) and `output.messages` (the assistant text). Pairing spans with events satisfies the "supported scope ⇒ must have events" rule (Req 9.2) and avoids `ValidationException`.
- **Tool calls → `execute_tool` spans + events (tool-level):** span `name = "{toolName}"` / tool-kind attributes; the paired event `body.input` carries the tool name + arguments and `body.output` carries the tool result, both from the `ToolInvocation` in the trace (Req 9.3). `status.code` reflects `ToolInvocation.success`.
- **Expected trajectory (Req 9.4):** `expectedToolNames` is not a span; it is carried out of the module and passed as the `Evaluate` `evaluationReferenceInputs[].expectedTrajectory.toolNames` for the tool-selection evaluator.
- **Insufficient data (Req 9.5):** if the trace has zero `execute_tool` steps **and** zero assistant turns, the module throws `InsufficientTraceError`; the caller converts this into an `Evaluation_Error_State` and does not submit or locally score.

This module is exercised directly by the `Span_Fixture` schema-conformance tests (Reqs 16.2, 16.3).

#### 2.2 AgentCore client wrapper (Req 8.2, 10) — thin SDK seam

`src/backend/orchestration/agentcore-client.ts` wraps `@aws-sdk/client-bedrock-agentcore` so the SDK shape lives in one place and is easy to mock/timeout.

```ts
export interface AgentCoreEvaluationClient {
  evaluate(args: {
    evaluatorId: string;                 // 'Builtin.GoalSuccessRate' | ...
    sessionSpans: unknown[];
    target?: { traceIds?: string[]; spanIds?: string[] };
    referenceInputs?: EvaluationReferenceInput[];
    timeoutMs: number;                   // default 60_000 (Req 10.1, 11.5)
  }): Promise<EvaluationResultContent[]>;
}
```

- Backed by `EvaluateCommand`; the SDK client is pinned to an exact version and bundled (Req 8.2), mirroring the `client-qconnect` bundling already used in `orchestration-construct.ts` and `api-construct.ts` (remove `@aws-sdk/client-bedrock-agentcore` from `externalModules`).
- A 60s timeout (`withTimeout`, already present) wraps each call; timeout → typed `EvaluationTimeoutError` (Req 10.1).
- The wrapper does not interpret scores; it returns raw `EvaluationResultContent[]` so mapping logic stays pure and testable.

#### 2.3 Score mapping & aggregation module (Req 8.3, 8.4) — pure

`src/shared/utils/evaluation-scoring.ts` (pure) maps and aggregates raw evaluator results into the three `TestCaseResult` scores.

```ts
export interface EvaluatorOutcome { evaluatorId: string; results: EvaluationResultContent[]; }

export interface AggregatedScores {
  goalSuccessScore?: number;     // session-level (Req 8.3)
  helpfulnessScore?: number;     // mean of per-turn values (Req 8.4)
  toolAccuracyScore?: number;    // mean of per-tool-call values (Req 8.4)
  missingEvaluators: string[];   // requested but absent (Req 8.7)
}

export function clamp01(v: number): number;                       // <0→0, >1→1 (Req 8.3)
export function aggregateMean(values: number[]): number | undefined;
export function aggregateScores(outcomes: EvaluatorOutcome[]): AggregatedScores;
```

- **Goal success (session-level):** the single `Builtin.GoalSuccessRate` result's `value`, clamped to [0,1] (Req 8.3).
- **Helpfulness (per-turn → one number):** **arithmetic mean** of the per-trace `Builtin.Helpfulness` `value`s, then clamped. The documented aggregation method (Req 8.4) is the unweighted mean over all returned per-turn results.
- **Tool accuracy (per-tool-call → one number):** **arithmetic mean** of the per-span `Builtin.ToolSelectionAccuracy` `value`s, then clamped (Req 8.4). This replaces — and must never be computed from — the local `calculateToolAccuracy` (Req 10.6).
- **Clamping:** every emitted score passes through `clamp01` so out-of-range judge outputs are stored as 0.0/1.0 (Req 8.3).
- **Missing-evaluator detection (Req 8.7):** any requested evaluator with no usable numeric result is listed in `missingEvaluators`; the caller stores whatever scores *were* produced and sets the `Evaluation_Error_State` naming the omitted evaluator(s).

#### 2.4 Evaluation Lambda rewrite (Req 8, 10) — orchestration only

`src/backend/orchestration/evaluation.ts` is rewritten to orchestrate the pure modules and the client; the stub `callAgentCoreEvaluation`, `computeFallbackScores`, `formatTranscriptForEvaluation`, and all fallback paths are removed (Reqs 8.2, 10.6).

Per test case:
1. Load `ExecutionTrace` (`getExecutionTrace`) and `TranscriptTurn[]` (`getTranscript`) from DynamoDB; the agent snapshot (`SK="SNAPSHOT"`) supplies `availableTools`; expected tools come from `testCase.successCriteria`.
2. `buildOtelSession(...)`. On `InsufficientTraceError` → write `Evaluation_Error_State` (reason: insufficient trace data) and continue (Reqs 9.5, 10.5).
3. Three `evaluate` calls (Goal/Helpfulness/Tool), each ≤60s, run concurrently:
   - GoalSuccessRate: no `target` (session-level).
   - Helpfulness: `target.traceIds = invokeAgentTraceIds`.
   - ToolSelectionAccuracy: `target.spanIds = toolSpanIds`, `referenceInputs=[{expectedTrajectory:{toolNames: expectedToolNames}}]`.
4. `aggregateScores(...)`. If any call errored/timed out, or results cannot map to valid scores, or `missingEvaluators` is non-empty → set `Evaluation_Error_State` with the specific reason; store any scores that *were* produced (Reqs 8.7, 10.1, 10.2).
5. `writeResult` to `PK=RUN#{runId}`, `SK=CASE#{caseId}` (Reqs 8.5, 10.3 leaves missing scores unset).
6. The run is never failed solely because cases entered the error state; a `TestCaseResult` is persisted for every case (Req 10.5).

The handler stays compatible with the state machine's `EvaluateResults` step (it already passes `caseResults`, `runId`, `testCases`); no state-machine topology change is required.

#### 2.5 Local Evaluation Harness (Req 11, 14, 16)

`scripts/evaluation-harness.ts` (run via `npx tsx`/`ts-node`) invokes the **same** translation + client + scoring code path as the Lambda (Req 11.4) so local results are representative.

- **Input (Req 11.6):** one CLI arg — either a transcript/trace file path or a Q in Connect session id. Mutually-exclusive resolution by file-exists check / id pattern.
- **File mode (Req 11.2, 16.4):** load a saved transcript or a `Span_Fixture`, translate, submit, print `goalSuccessScore`/`helpfulnessScore`/`toolAccuracyScore` (and per-evaluator detail).
- **Session mode (Req 11.3):** call `ListSpans` for the id, `parseSpansToTrace`, then the same path.
- **Failure behavior (Req 11.5, 11.7, 11.8, 11.9):** missing/invalid input → usage + non-zero exit, no submission; unparseable transcript or unresolvable session/empty trace → error + non-zero exit, no submission; AgentCore error/timeout → print reason + non-zero exit.
- **Credentials & least privilege (Req 14):** uses the default AWS credential chain (profile/env, Req 14.2), no hardcoded creds (Req 14.3). Missing creds → report + non-zero exit before any AWS call (Req 14.4). The harness only ever calls `bedrock-agentcore:Evaluate`, `bedrock:InvokeModel`/`Converse`, and `qconnect:ListSpans`; an access-denied on either is reported naming the operation, with **no** local-only fallback, and non-zero exit (Reqs 14.1, 14.5). A documented least-privilege IAM policy is provided in the repo for harness users.

#### 2.6 Score-aware run comparison (Req 15) — pure helper + UI

A pure helper extends the existing `run-comparison.ts` pattern; per Req 15.6 it is standalone and unit-testable.

`src/shared/utils/score-comparison.ts`:

```ts
export type MetricKey = 'goalSuccessScore' | 'helpfulnessScore' | 'toolAccuracyScore';
export type DeltaClass = 'improved' | 'regressed' | 'unchanged' | 'not-comparable';

export interface MetricDelta { metric: MetricKey; delta?: number; classification: DeltaClass; }
export interface CaseScoreComparison { caseId: string; metrics: Record<MetricKey, MetricDelta>; }
export interface ScoreComparisonSummary {
  perMetric: Record<MetricKey, { improved: number; regressed: number; unchanged: number; notComparable: number }>;
}

export function compareScores(runA: TestCaseResult[], runB: TestCaseResult[]):
  { entries: CaseScoreComparison[]; summary: ScoreComparisonSummary };
```

- For each case present in both runs and each metric: if both values present, `delta = later - earlier` (Req 15.1) classified `improved`/`regressed`/`unchanged` by sign (Req 15.2); if either absent (including `Evaluation_Error_State`) → `not-comparable` (Req 15.3).
- The suite-level summary counts cases per classification per metric (Req 15.4).
- The existing `Comparison.tsx` consumes this alongside `compareRuns`; classifications are visually distinguished (color/icon) per Req 15.2. `ResultsViewer.tsx` already renders the three scores and gains an explicit `Evaluation_Error_State` reason in place of scores (Reqs 8.6, 10.4, 15.5), replacing the current "Fallback" badge heuristic.

## Data Models

### `TestCaseResult` (extended)

The existing fields are unchanged. The `Evaluation_Error_State` is represented on the same item without new score fields (so Req 10.3 "leave scores unset" is structurally enforced):

```ts
export interface TestCaseResult {
  runId: string;
  caseId: string;
  status: CaseStatus;          // unchanged; NOT failed solely due to eval error (Req 10.5)
  toolsInvoked: string[];
  turnCount: number;
  latencyMs: number;
  goalSuccessScore?: number;   // set only by AgentCore mapping (Req 8.3); unset in error state
  helpfulnessScore?: number;   // mean of per-turn (Req 8.4); unset in error state
  toolAccuracyScore?: number;  // mean of per-tool-call (Req 8.4); never from local calc (Req 10.6)
  errorMessage?: string;       // existing field reused for conversation errors
  // NEW — Evaluation_Error_State (Req 10)
  evaluationError?: {
    reason: string;            // human-readable, displayed in results view (Req 10.4)
    code: 'INSUFFICIENT_TRACE' | 'TIMEOUT' | 'AGENTCORE_ERROR' | 'UNMAPPABLE_RESULT' | 'MISSING_EVALUATOR';
    missingEvaluators?: string[]; // when code = MISSING_EVALUATOR (Req 8.7)
  };
}
```

Persistence is unchanged (`writeResult`, `PK=RUN#{runId}`, `SK=CASE#{caseId}`); `removeUndefinedValues` keeps unset scores absent. The frontend treats "`evaluationError` present" as the signal to show the reason instead of scores.

### OTel session payload (internal to translation module)

```ts
type Hex = string;
interface OtelSpan {
  spanId: Hex;            // 16-char (tool) — also used as the tool-level target
  traceId: Hex;          // 32-char (assistant turn) — trace-level target
  parentSpanId?: Hex;
  name: string;
  scope: { name: 'strands.telemetry.tracer' };
  startTimeUnixNano: number;
  endTimeUnixNano: number;
  attributes: Record<string, unknown> & { 'session.id': string };
  status?: { code: 'OK' | 'ERROR' | 'UNSET' };
  kind?: string;
}
interface OtelEvent {
  spanId: Hex; traceId: Hex;
  scope: { name: 'strands.telemetry.tracer' };
  body: { input?: { messages: OtelMessage[] }; output?: { messages: OtelMessage[] } };
  attributes: { 'event.name': string; 'session.id': string };
  timeUnixNano?: number;
}
interface OtelMessage { content: string | Record<string, unknown>; role: string; }
type OtelSpanOrEvent = OtelSpan | OtelEvent;
```

These shapes mirror the AgentCore span/event schema (required `spanId`/`traceId`/`name`/`scope.name`/timestamps/`attributes["session.id"]`, and events with `body.input`/`body.output` messages).

### `Span_Fixture` (Req 16)

Checked-in under `tests/fixtures/spans/`:

```ts
interface SpanFixture {
  name: string;                       // e.g. 'multi-tool-success', 'failure-escalation'
  description: string;
  sessionId: string;
  rawSpans: RawSpan[];                // real ListSpans payload (parser input), redacted (Req 16.5)
  expectedToolSequence: string[];     // ground-truth assertion aid (Req 16.3)
  availableTools: ToolDefinition[];   // agent snapshot at capture time (Req 9.3)
  expectedToolNames: string[];        // success-criteria trajectory (Req 9.4)
}
```

At least two fixtures (a multi-tool success and a failure/escalation session) are required (Req 16.1). Sensitive customer data (phone, SSN-last-four, names) is redacted to placeholders (Req 16.5).

### Deploy-time config inputs

```ts
interface RuntimeConfigInputs {
  apiEndpoint: string;        // api.url (token)
  cognitoUserPoolId: string;  // token
  cognitoClientId: string;    // Web_Client id (token) — NOT machine client (Req 13.3)
  cognitoDomain: string;      // token
  region: string;             // Stack region
}
```

All five are asserted non-empty at synth (Req 3.6) before the `BucketDeployment` is created.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

PBT applies to this feature's **pure logic**: runtime-config assembly/validation, callback-URL and admin-email validation, the trace→OTel translation, score mapping/aggregation/normalization, and score-delta classification. The declarative CDK surface (hosting, invalidation, idempotency, callback registration, bootstrap wiring) and runtime/auth/UI behaviors are verified by CDK `assertions` template tests, example/component tests, and post-deploy smoke/integration checks (see Testing Strategy), not by PBT.

The prework consolidated the testable criteria into the following non-redundant properties.

### Property 1: Runtime config is complete-or-rejected

*For any* mapping of the five runtime-config fields (`apiEndpoint`, `cognitoUserPoolId`, `cognitoClientId`, `cognitoDomain`, `region`): if all five resolve to non-empty strings, `buildRuntimeConfig` returns an object whose keys are exactly those five fields, each non-empty and equal to its input; if any required field is missing, empty, or whitespace-only, `buildRuntimeConfig` throws and produces no config object. The output never contains any key beyond the five non-secret fields.

**Validates: Requirements 3.2, 3.6, 13.1, 13.2**

### Property 2: Callback URLs are validated, deduplicated, and always include CloudFront

*For any* list of candidate callback URLs: if every entry is a well-formed absolute URL, `validateCallbackUrls` returns a list that contains the CloudFront URL and each distinct input URL exactly once (no duplicates, set-preserving); if any entry is empty or not a well-formed absolute URL, it throws and returns nothing.

**Validates: Requirements 4.4, 4.6**

### Property 3: Admin email is parsed into create-or-skip-or-reject

*For any* raw admin-email input: if it is absent, empty, or whitespace-only, `parseAdminEmail` returns a skip decision; if it is a non-empty string that satisfies the validity rule (non-empty local part, exactly one `@`, domain containing at least one `.`), it returns the trimmed email; if it is a non-empty string that violates that rule, it throws.

**Validates: Requirements 6.6, 7.1**

### Property 4: OTel translation preserves trace structure and order

*For any* `ExecutionTrace` with at least one assistant turn or tool call, `buildOtelSession` emits exactly one `invoke_agent`-style span per assistant turn and exactly one `execute_tool`-style span per tool call, preserves their original chronological order, and assigns the same `session.id` to every span and event. (Run against generated traces and against each checked-in `Span_Fixture`.)

**Validates: Requirements 9.1, 16.3**

### Property 5: OTel output conforms to the AgentCore input schema

*For any* `ExecutionTrace` that yields a session, every emitted span carries a supported instrumentation scope and the required fields (`spanId`, `traceId`, `name`, `scope.name`, `startTimeUnixNano`, `endTimeUnixNano`, `attributes["session.id"]`), and every supported-scope span has a corresponding event with an `input`/`output` message body. (Run against generated traces and against each checked-in `Span_Fixture`.)

**Validates: Requirements 9.2, 16.2**

### Property 6: Tool spans carry tool name, arguments, result, and available tools

*For any* `ExecutionTrace` and `AgentSnapshot`, every `execute_tool` span/event produced represents its source `ToolInvocation` with the same tool name, supplied arguments, and captured result, and the set of available tools from the snapshot is attached to the session data the tool-level and session-level evaluators consume.

**Validates: Requirements 9.3**

### Property 7: Expected tool trajectory is passed through unchanged

*For any* test case success criteria, the `expectedToolNames` carried out of `buildOtelSession` equals the ordered list of tool names from those success criteria.

**Validates: Requirements 9.4**

### Property 8: Degenerate traces are rejected, not scored

*For any* `ExecutionTrace` containing zero tool calls and zero assistant turns, `buildOtelSession` throws `InsufficientTraceError`; *for any* trace containing at least one tool call or at least one assistant turn, it returns a session without throwing.

**Validates: Requirements 9.5**

### Property 9: Every emitted score lies within [0.0, 1.0]

*For any* set of evaluator outcomes with arbitrary numeric values (including values below 0.0 or above 1.0), every score field that `aggregateScores` emits (`goalSuccessScore`, `helpfulnessScore`, `toolAccuracyScore`) is a decimal in the inclusive range 0.0–1.0, with values below 0.0 stored as 0.0 and values above 1.0 stored as 1.0.

**Validates: Requirements 8.3**

### Property 10: Aggregation maps goal directly and reduces per-unit results by arithmetic mean

*For any* evaluator outcomes: `goalSuccessScore` equals the clamped session-level `Builtin.GoalSuccessRate` value; and for the per-turn helpfulness and per-tool-call tool-selection results, the aggregated value (before clamping) equals the arithmetic mean of the returned values and lies within the inclusive range of the minimum and maximum returned value. An empty set of per-unit results aggregates to undefined.

**Validates: Requirements 8.3, 8.4**

### Property 11: Missing-evaluator detection is exactly the absent subset

*For any* subset of the three requested evaluators that returns usable results, `aggregateScores` lists in `missingEvaluators` exactly the requested evaluators that did not return a usable result, and still emits a score for each evaluator that did return one.

**Validates: Requirements 8.7**

### Property 12: An evaluation error state leaves all three scores unset

*For any* outcome that produces an `Evaluation_Error_State` (insufficient trace, timeout, AgentCore error, unmappable result), the persisted `TestCaseResult` has `evaluationError` set and leaves `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` all unset (no numeric value).

**Validates: Requirements 10.3**

### Property 13: Tool accuracy originates only from AgentCore, never from local scoring

*For any* inputs, a persisted `toolAccuracyScore` is present only when the `Builtin.ToolSelectionAccuracy` evaluator returned a usable value for that case; the value is never derived from the local `calculateToolAccuracy` logic.

**Validates: Requirements 10.6**

### Property 14: Score-delta classification is sign-consistent and not-comparable on absence

*For any* pair of runs and any metric of a case present in both runs: when both runs have a numeric value for that metric, `compareScores` sets `delta = later − earlier` and classifies it `improved` iff `delta > 0`, `regressed` iff `delta < 0`, and `unchanged` iff `delta == 0`; when the metric is present in exactly one of the two runs (including a case in the `Evaluation_Error_State`), it classifies the metric `not-comparable` with no numeric delta.

**Validates: Requirements 15.1, 15.2, 15.3**

### Property 15: Per-metric comparison summary counts are exhaustive

*For any* pair of runs and any metric, the suite-level summary counts for that metric (`improved + regressed + unchanged + notComparable`) equal the number of cases considered for that metric, so every considered case is counted in exactly one classification.

**Validates: Requirements 15.4**

### Property 16: Frontend bucket is private and ACL-free by construction

*For any* synthesized stack, the `Frontend_Bucket` resource has all four public-access-block flags (`BlockPublicAcls`, `IgnorePublicAcls`, `BlockPublicPolicy`, `RestrictPublicBuckets`) set `true`, `ObjectOwnership = BucketOwnerEnforced`, an attached bucket policy statement denying non-TLS requests (`aws:SecureTransport = false`), SSE encryption enabled, and no bucket policy statement or ACL grant whose principal is public (`AllUsers`/`AuthenticatedUsers`/`*`) — independent of any account-level Public Access Block.

This property concerns declarative IaC (the bucket's rendered CloudFormation), so it is **verified by a CDK `assertions` template test, not by property-based testing**, consistent with the PBT-for-pure-logic / CDK-assertions-for-declarative-IaC split used throughout this design.

**Validates: Requirements 12, 13**

## Error Handling

### Deploy-time (fail fast, never partially mutate)

| Condition | Handling | Requirement |
|---|---|---|
| Build dir missing / no `index.html` at root | Synth-time guard throws before any `BucketDeployment`; bucket untouched | 1.4 |
| Any required runtime-config output empty/missing | `buildRuntimeConfig` throws at synth; no `config.json` uploaded | 3.6 |
| Empty / non-absolute callback URL in context param | `validateCallbackUrls` throws at synth; no callback URLs registered from that param | 4.6 |
| Invalid non-empty `Admin_Email` | `parseAdminEmail` throws at synth; no Cognito user created | 6.6 |
| Invalidation cannot create / not complete in 30 min | `BucketDeployment` custom resource fails → deploy fails, not reported successful | 2.4 |
| Any deploy step fails | CloudFormation rolls back to last good state; previously served frontend remains intact (CloudFront still 200); non-zero exit | 12.3, 12.5 |

All deploy-time validators are pure functions invoked during synth so failures surface before resources change, preserving idempotency (Req 12).

### Bootstrap (idempotent)

- `UsernameExistsException` from `AdminCreateUser` is treated as success; credentials and `FORCE_CHANGE_PASSWORD` status are never overwritten (Reqs 6.5, 7.3).
- The skip path creates no resource, so toggling `Admin_Email` off never deletes or disables an existing user (Req 7.4).

### Evaluation (explicit error state, never silent fallback)

The Evaluation Lambda maps each failure mode to an `evaluationError.code` and records it on the `TestCaseResult` while leaving the three scores unset (Reqs 10.1–10.3):

| Failure | `code` | Notes |
|---|---|---|
| Trace has no tool spans and no assistant turns | `INSUFFICIENT_TRACE` | `InsufficientTraceError`; no submission (Req 9.5) |
| No result within 60s | `TIMEOUT` | per-evaluator `withTimeout`; no local scoring (Req 10.1) |
| AgentCore returns an error / throws | `AGENTCORE_ERROR` | reason carries the SDK error (Req 10.2) |
| Result cannot map to valid scores | `UNMAPPABLE_RESULT` | non-numeric/empty `value` (Req 10.2) |
| One evaluator returns, another omitted | `MISSING_EVALUATOR` | store returned score(s); name omitted evaluator(s) (Req 8.7) |

Per-case errors are isolated: a `TestCaseResult` is persisted for every case and the run is not marked failed solely because cases entered the error state (Req 10.5). The local `calculateToolAccuracy` is never used as a substitute anywhere in this path (Req 10.6) — it remains only as a standalone utility outside the evaluation flow.

### Harness (clear messages, non-zero exit, no submission on bad input)

Missing creds (Req 14.4), invalid/absent input source (Reqs 11.7, 11.8), unresolvable session or empty trace (Req 11.9) all print a message and exit non-zero **before** any AgentCore submission. AgentCore errors/timeouts (Req 11.5) and access-denied on `Evaluate`/`ListSpans` (Req 14.5) print the failing operation and exit non-zero, never falling back to local scoring.

### Frontend (degrade visibly, never call with undefined endpoint)

If `/config.json` fails to load (network failure, non-OK response, or malformed JSON), the app shows a "runtime configuration unavailable" error state, keeps the user on the page, and suppresses API calls that would use an undefined `apiEndpoint` (Req 5.4). A 401/403 from an authenticated request shows an error and prompts re-auth via the hosted UI (Req 5.6). Cases in the `Evaluation_Error_State` render the recorded reason in place of scores (Reqs 10.4, 15.5).

## Testing Strategy

### Dual approach

- **Property-based tests** (Vitest + `fast-check`, already in the stack) verify the 15 universal properties above across generated inputs.
- **Unit / example / edge tests** cover specific behaviors, orchestration, and enumerated failure modes.
- **CDK `assertions` template tests** verify the declarative hosting/bootstrap/wiring requirements.
- **Component tests** (`@testing-library/react`) cover frontend rendering and error states.
- **Integration / smoke checks** cover external/runtime behavior (CloudFront, Cognito hosted UI, real AgentCore) post-deploy.

### Property test configuration

- Library: `fast-check` (existing dependency). Tests live in `tests/unit/properties/`.
- Minimum **100 iterations** per property (`fc.assert(fc.property(...), { numRuns: 100 })`).
- Each property test is tagged with a comment referencing its design property, format:
  `// Feature: platform-hosting-and-evaluations, Property {n}: {property text}`
- Each correctness property is implemented by a **single** property-based test. Generators: arbitrary `ExecutionTrace`/`ExecutionStep`/`ToolInvocation`, arbitrary `ToolStep[]`, arbitrary evaluator-outcome value lists (including out-of-range and empty), arbitrary `TestCaseResult[]` pairs, arbitrary URL lists, and arbitrary email-ish strings.

### Property → test-module map

| Property | Module under test | Test file |
|---|---|---|
| P1 | `buildRuntimeConfig` | `tests/unit/properties/runtime-config.test.ts` |
| P2 | `validateCallbackUrls` | `tests/unit/properties/callback-urls.test.ts` |
| P3 | `parseAdminEmail` | `tests/unit/properties/admin-email.test.ts` |
| P4, P5, P6, P7, P8 | `trace-to-otel.buildOtelSession` | `tests/unit/properties/trace-to-otel.test.ts` |
| P9, P10, P11 | `evaluation-scoring.aggregateScores` | `tests/unit/properties/evaluation-scoring.test.ts` |
| P12, P13 | evaluation result assembly (pure mapping) | `tests/unit/properties/evaluation-result.test.ts` |
| P14, P15 | `score-comparison.compareScores` | `tests/unit/properties/score-comparison.test.ts` |

### Real Span_Fixture validation (Req 16)

- At least two redacted fixtures under `tests/fixtures/spans/` (`multi-tool-success`, `failure-escalation`) (Reqs 16.1, 16.5).
- `tests/unit/trace-to-otel.fixtures.test.ts` runs **Properties 4 and 5 against each fixture** (schema conformance, required fields, supported scope, span/event pairing, per-turn/per-tool counts with order preserved) — satisfying Reqs 16.2 and 16.3 on genuine data.
- A redaction guard test scans every checked-in fixture for forbidden patterns (real phone numbers, SSN fragments) and asserts placeholders are used (Req 16.5).
- The harness is exercised against a fixture in CI with a mocked AgentCore client, and ad hoc against the real service, to confirm end-to-end reporting on real data (Req 16.4).

### CDK assertion tests (Reqs 1–4, 6, 7, 12, 13)

Extend `tests/infrastructure/cdk-stack.test.ts` (mocks `NodejsFunction`; same pattern for `BucketDeployment` if needed):
- `BucketDeployment` targets the frontend bucket, has the build asset source and a `config.json` source in **one** deployment with `prune` (Reqs 1.1, 3.1, 3.5), and sets `DistributionId` + `DistributionPaths: ['/*']` (Reqs 2.1).
- CloudFront `DefaultRootObject: index.html` and 403/404→`/index.html`/200 already asserted (Reqs 1.2, 1.5).
- `UserPoolClient` `CallbackURLs`/`LogoutURLs` include the CloudFront URL and any provided URLs, deduplicated (Reqs 4.1, 4.2, 4.4); `config.json` references the Web_Client id, never the machine client (Reqs 3.3, 13.3).
- With `adminEmail` provided → a bootstrap custom resource exists; without it → no bootstrap resource and all other resources are structurally identical (Reqs 6.1, 7.1, 7.2). Logical ids of bucket/distribution/user pool/clients are stable across synths (Req 12.4).
- The `Frontend_Bucket` renders with `PublicAccessBlockConfiguration` (all four flags — `BlockPublicAcls`, `IgnorePublicAcls`, `BlockPublicPolicy`, `RestrictPublicBuckets` — `true`), `OwnershipControls` rule `ObjectOwnership: BucketOwnerEnforced`, the `aws:SecureTransport=false` deny policy statement, and SSE encryption, and **no** bucket policy statement grants a public principal (`AllUsers`/`AuthenticatedUsers`/`*`) — so the privacy guarantee is enforced at the bucket level regardless of account-level Public Access Block settings (Property 16; Reqs 12, 13).

### Example / edge / component tests

- Bootstrap handler (mocked Cognito SDK): one `AdminCreateUser`, `MessageAction` not `SUPPRESS`, email as username/attribute, `FORCE_CHANGE_PASSWORD`, and `UsernameExistsException`→success without reset (Reqs 6.2, 6.4, 6.5, 6.7).
- Evaluation Lambda (mocked `AgentCoreEvaluationClient` + DynamoDB): one translation + one call per evaluator with correct targets (Req 8.1); persists to `RUN#/CASE#` (Req 8.5); timeout/error/unmappable/missing→error state with no local scoring (Reqs 10.1, 10.2, 10.5); mixed batch persists all cases and does not fail the run (Req 10.5).
- SDK bundling/pinning: `@aws-sdk/client-bedrock-agentcore` absent from `externalModules` and pinned to an exact version in `package.json` (Req 8.2); a static check that `evaluation.ts` does not import `calculateToolAccuracy` (Req 10.6).
- Harness: arg resolver (file vs session id), no-arg usage, missing/garbage file, empty `ListSpans`, missing creds, and access-denied paths each exit non-zero without submission/fallback (Reqs 11.5–11.9, 14.4, 14.5); harness and Lambda import the same translate/evaluate/aggregate modules (Req 11.4).
- Frontend: `loadConfig`/`getBaseUrl` guard for network/non-OK/malformed config (Req 5.4); unauthenticated redirect (Req 5.5); 401/403 re-auth prompt (Req 5.6); results view renders three scores or the error reason (Reqs 8.6, 10.4, 15.5).

### Post-deploy smoke / integration (external behavior)

A scripted smoke check after deploy: GET CloudFront root → 200 `index.html` (Reqs 1.3, 2.2, 12.2); GET `/config.json` → 200 with `apiEndpoint` == prod invoke URL and `region` == deploy region (Req 3.4); a client-route GET → 200 via SPA fallback (Req 1.5); a no-op redeploy shows zero changes (`cdk diff`) (Req 12.1). Hosted-UI sign-in success/failure round-trips (Reqs 4.3, 4.5, 5.1, 5.3) and the harness against the real AgentCore service (Reqs 11.2, 11.3, 16.4) are validated as integration checks. Harness least-privilege (Req 14.1) is validated by running under a scoped role with only `bedrock-agentcore:Evaluate`, `bedrock:InvokeModel`/`Converse`, and `qconnect:ListSpans`.

### Why not PBT for the rest

Hosting, invalidation, callback registration, bootstrap wiring, and idempotency (Reqs 1–7 wiring, 12, 13.3) are declarative IaC — behavior does not vary with input and 100 iterations add nothing over a synth assertion. Runtime CloudFront/Cognito/AgentCore behaviors are external services. UI rendering uses component/snapshot-style tests. These are intentionally excluded from the property set above.
