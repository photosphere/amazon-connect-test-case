import { describe, it, expect, vi, beforeEach } from "vitest";
import { truncateSystemInstructions } from "../../src/backend/services/dynamodb";
import { ExecutionStep } from "../../src/shared/types";

describe("truncateSystemInstructions", () => {
  const runId = "test-run-123";
  const caseId = "test-case-456";

  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it("passes through steps with no inferenceMetadata", () => {
    const steps: ExecutionStep[] = [
      {
        index: 0,
        type: "inference",
        spanName: "inference",
        text: "Hello",
      },
      {
        index: 1,
        type: "tool",
        spanName: "execute_tool",
      },
    ];

    const result = truncateSystemInstructions(steps, runId, caseId);
    expect(result).toEqual(steps);
  });

  it("passes through steps with systemInstructions under 350 KB", () => {
    const smallInstructions = "A".repeat(1000);
    const steps: ExecutionStep[] = [
      {
        index: 0,
        type: "inference",
        spanName: "inference",
        inferenceMetadata: {
          systemInstructions: smallInstructions,
          requestModel: "claude-3",
        },
      },
    ];

    const result = truncateSystemInstructions(steps, runId, caseId);
    expect(result[0].inferenceMetadata?.systemInstructions).toBe(
      smallInstructions
    );
  });

  it("truncates systemInstructions exceeding 350 KB and appends suffix", () => {
    // Create a string whose JSON serialization exceeds 350 KB.
    // JSON.stringify adds quotes around strings, so the string itself
    // needs to be large enough that the serialized form exceeds the limit.
    const largeInstructions = "X".repeat(360 * 1024);
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

    const steps: ExecutionStep[] = [
      {
        index: 0,
        type: "inference",
        spanName: "inference",
        inferenceMetadata: {
          systemInstructions: largeInstructions,
          requestModel: "claude-3",
        },
      },
    ];

    const result = truncateSystemInstructions(steps, runId, caseId);

    // The result should end with the truncation suffix
    expect(result[0].inferenceMetadata?.systemInstructions).toContain(
      "\n…[truncated]"
    );

    // The result (minus suffix) should be within the 350 KB byte limit
    const truncatedValue = result[0].inferenceMetadata!.systemInstructions!;
    const withoutSuffix = truncatedValue.slice(
      0,
      truncatedValue.length - "\n…[truncated]".length
    );
    const byteLength = Buffer.byteLength(withoutSuffix, "utf8");
    expect(byteLength).toBeLessThanOrEqual(350 * 1024);

    // Other inferenceMetadata fields are preserved
    expect(result[0].inferenceMetadata?.requestModel).toBe("claude-3");

    // console.warn was emitted
    expect(warnSpy).toHaveBeenCalledOnce();
    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining("runId=test-run-123")
    );
    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining("caseId=test-case-456")
    );
    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining("stepIndex=0")
    );
  });

  it("handles multi-byte characters at the truncation boundary", () => {
    // Use a string with multi-byte Unicode characters (each emoji is 4 bytes)
    const emoji = "🎉"; // 4 bytes in UTF-8
    // Fill up to just under 350 KB with ASCII, then pad with emojis to exceed
    const baseSize = 350 * 1024 - 10;
    const largeInstructions = "A".repeat(baseSize) + emoji.repeat(100);
    vi.spyOn(console, "warn").mockImplementation(() => {});

    const steps: ExecutionStep[] = [
      {
        index: 0,
        type: "inference",
        spanName: "inference",
        inferenceMetadata: {
          systemInstructions: largeInstructions,
        },
      },
    ];

    const result = truncateSystemInstructions(steps, runId, caseId);
    const truncatedValue = result[0].inferenceMetadata!.systemInstructions!;

    // Should not have broken multi-byte characters — the result should be
    // valid UTF-8 that can be re-encoded without replacement characters
    const reEncoded = Buffer.from(truncatedValue, "utf8").toString("utf8");
    expect(reEncoded).toBe(truncatedValue);

    // Should end with the suffix
    expect(truncatedValue.endsWith("\n…[truncated]")).toBe(true);
  });

  it("only truncates affected steps, leaving others untouched", () => {
    const largeInstructions = "Y".repeat(400 * 1024);
    const smallInstructions = "Small prompt";
    vi.spyOn(console, "warn").mockImplementation(() => {});

    const steps: ExecutionStep[] = [
      {
        index: 0,
        type: "inference",
        spanName: "inference",
        inferenceMetadata: { systemInstructions: smallInstructions },
      },
      {
        index: 1,
        type: "inference",
        spanName: "inference",
        inferenceMetadata: { systemInstructions: largeInstructions },
      },
      {
        index: 2,
        type: "tool",
        spanName: "execute_tool",
      },
    ];

    const result = truncateSystemInstructions(steps, runId, caseId);

    // Step 0 unchanged
    expect(result[0].inferenceMetadata?.systemInstructions).toBe(
      smallInstructions
    );
    // Step 1 truncated
    expect(result[1].inferenceMetadata?.systemInstructions).toContain(
      "\n…[truncated]"
    );
    // Step 2 unchanged
    expect(result[2]).toEqual(steps[2]);
  });

  it("preserves undefined systemInstructions without modification", () => {
    const steps: ExecutionStep[] = [
      {
        index: 0,
        type: "inference",
        spanName: "inference",
        inferenceMetadata: {
          requestModel: "claude-3",
          // systemInstructions is undefined
        },
      },
    ];

    const result = truncateSystemInstructions(steps, runId, caseId);
    expect(result[0].inferenceMetadata?.systemInstructions).toBeUndefined();
    expect(result[0].inferenceMetadata?.requestModel).toBe("claude-3");
  });
});
