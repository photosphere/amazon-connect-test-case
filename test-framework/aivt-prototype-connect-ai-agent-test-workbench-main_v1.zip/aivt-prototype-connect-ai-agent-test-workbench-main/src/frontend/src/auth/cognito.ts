/**
 * Lightweight Cognito authentication module.
 * Uses the OAuth2 Authorization Code flow with the Cognito Hosted UI.
 * Tokens are stored in sessionStorage for the current tab session.
 */

export interface AuthTokens {
  idToken: string;
  accessToken: string;
  refreshToken: string;
  expiresAt: number; // Unix timestamp in ms
}

export interface CognitoConfig {
  userPoolId: string;
  clientId: string;
  domain: string;
  redirectUri: string;
}

const STORAGE_KEY = 'catp_auth_tokens';
const REFRESH_BUFFER_MS = 5 * 60 * 1000; // Refresh 5 minutes before expiry

let refreshTimer: ReturnType<typeof setTimeout> | null = null;

import { getConfig } from '../api/config';

export function getCognitoConfig(): CognitoConfig {
  // Runtime config is loaded by main.tsx before the app renders,
  // so getConfig() returns the cached value synchronously.
  const runtimeConfig = getConfig();

  return {
    userPoolId: runtimeConfig?.cognitoUserPoolId || import.meta.env.VITE_COGNITO_USER_POOL_ID || '',
    clientId: runtimeConfig?.cognitoClientId || import.meta.env.VITE_COGNITO_CLIENT_ID || '',
    domain: runtimeConfig?.cognitoDomain || import.meta.env.VITE_COGNITO_DOMAIN || '',
    redirectUri: import.meta.env.VITE_COGNITO_REDIRECT_URI || window.location.origin,
  };
}

/**
 * Build the Cognito Hosted UI login URL and redirect the user.
 * Preserves the current path for post-auth redirect.
 */
export function redirectToLogin(): void {
  const config = getCognitoConfig();
  const state = encodeURIComponent(window.location.pathname + window.location.search);
  // The API Gateway COGNITO_USER_POOLS authorizer is configured with
  // `authorizationScopes: ['test-platform/run']`, which means it inspects the
  // access token's `scope` claim and rejects (401) any token that does not
  // carry that scope. The Web client must request it during the hosted-UI
  // authorize redirect; otherwise the access token is `openid email profile`
  // only and every API call surfaces a 401 (which the browser reports as a
  // CORS error because the 4xx gateway response carries no CORS headers).
  const loginUrl = `https://${config.domain}/login?` +
    `client_id=${config.clientId}` +
    `&response_type=code` +
    `&scope=openid+email+profile+test-platform%2Frun` +
    `&redirect_uri=${encodeURIComponent(config.redirectUri)}` +
    `&state=${state}`;
  window.location.href = loginUrl;
}

/**
 * Exchange the authorization code for tokens via the Cognito token endpoint.
 */
export async function exchangeCodeForTokens(code: string): Promise<AuthTokens> {
  const config = getCognitoConfig();
  const tokenUrl = `https://${config.domain}/oauth2/token`;

  const body = new URLSearchParams({
    grant_type: 'authorization_code',
    client_id: config.clientId,
    redirect_uri: config.redirectUri,
    code,
  });

  const response = await fetch(tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });

  if (!response.ok) {
    throw new Error(`Token exchange failed: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  const tokens: AuthTokens = {
    idToken: data.id_token,
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    expiresAt: Date.now() + data.expires_in * 1000,
  };

  storeTokens(tokens);
  scheduleTokenRefresh(tokens);
  return tokens;
}

/**
 * Refresh the tokens using the refresh token grant.
 */
export async function refreshTokens(): Promise<AuthTokens | null> {
  const currentTokens = getStoredTokens();
  if (!currentTokens?.refreshToken) {
    return null;
  }

  const config = getCognitoConfig();
  const tokenUrl = `https://${config.domain}/oauth2/token`;

  const body = new URLSearchParams({
    grant_type: 'refresh_token',
    client_id: config.clientId,
    refresh_token: currentTokens.refreshToken,
  });

  try {
    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });

    if (!response.ok) {
      // Refresh token expired or revoked — force re-login
      clearTokens();
      redirectToLogin();
      return null;
    }

    const data = await response.json();
    const tokens: AuthTokens = {
      idToken: data.id_token,
      accessToken: data.access_token,
      refreshToken: currentTokens.refreshToken, // Cognito doesn't return a new refresh token
      expiresAt: Date.now() + data.expires_in * 1000,
    };

    storeTokens(tokens);
    scheduleTokenRefresh(tokens);
    return tokens;
  } catch {
    // Network error during refresh — don't interrupt, will retry on next API call
    return null;
  }
}

/**
 * Schedule automatic token refresh before expiry.
 */
function scheduleTokenRefresh(tokens: AuthTokens): void {
  if (refreshTimer) {
    clearTimeout(refreshTimer);
  }

  const delay = tokens.expiresAt - Date.now() - REFRESH_BUFFER_MS;
  if (delay > 0) {
    refreshTimer = setTimeout(() => {
      refreshTokens();
    }, delay);
  }
}

/**
 * Get the current access token, refreshing if needed.
 */
export async function getAccessToken(): Promise<string | null> {
  const tokens = getStoredTokens();
  if (!tokens) {
    return null;
  }

  // If token is about to expire, refresh proactively
  if (Date.now() >= tokens.expiresAt - REFRESH_BUFFER_MS) {
    const refreshed = await refreshTokens();
    return refreshed?.accessToken ?? null;
  }

  return tokens.accessToken;
}

/**
 * Check if the user is currently authenticated.
 */
export function isAuthenticated(): boolean {
  const tokens = getStoredTokens();
  return tokens !== null && tokens.expiresAt > Date.now();
}

/**
 * Store tokens in sessionStorage.
 */
function storeTokens(tokens: AuthTokens): void {
  sessionStorage.setItem(STORAGE_KEY, JSON.stringify(tokens));
}

/**
 * Retrieve stored tokens.
 */
export function getStoredTokens(): AuthTokens | null {
  const raw = sessionStorage.getItem(STORAGE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as AuthTokens;
  } catch {
    return null;
  }
}

/**
 * Clear stored tokens and cancel refresh timer.
 */
export function clearTokens(): void {
  sessionStorage.removeItem(STORAGE_KEY);
  if (refreshTimer) {
    clearTimeout(refreshTimer);
    refreshTimer = null;
  }
}

/**
 * Sign out the user: clear tokens and redirect to Cognito logout.
 */
export function signOut(): void {
  const config = getCognitoConfig();
  clearTokens();
  const logoutUrl = `https://${config.domain}/logout?` +
    `client_id=${config.clientId}` +
    `&logout_uri=${encodeURIComponent(config.redirectUri)}`;
  window.location.href = logoutUrl;
}

/**
 * Handle the OAuth callback: extract code from URL params and exchange for tokens.
 * Returns the originally requested path (from state param) or '/'.
 */
export async function handleAuthCallback(): Promise<string> {
  const params = new URLSearchParams(window.location.search);
  const code = params.get('code');
  const state = params.get('state');

  if (!code) {
    throw new Error('No authorization code in callback URL');
  }

  await exchangeCodeForTokens(code);

  // Clean the URL
  window.history.replaceState({}, '', window.location.pathname);

  // Return the originally requested path
  return state ? decodeURIComponent(state) : '/agents';
}

/**
 * Initialize auth on app load: check for callback code or existing session.
 * Schedules refresh if tokens exist.
 */
export function initializeAuth(): void {
  const tokens = getStoredTokens();
  if (tokens && tokens.expiresAt > Date.now()) {
    scheduleTokenRefresh(tokens);
  }
}

/**
 * Decode the email claim from the Cognito ID token JWT payload, if any.
 *
 * The platform's API access token (audience: `test-platform/run`) does
 * not carry an email claim, but the ID token from the same hosted-UI
 * login flow does. The Prompts API uses this email as a *display hint*
 * persisted on `lastModifiedByEmail` so the table can show "you@…"
 * instead of the Cognito `sub` UUID. The `sub` UUID is still
 * authoritative for "who made this edit" — the email is informational.
 *
 * Returns `null` when no tokens are stored, when the ID token is
 * malformed, or when the token carries neither an `email` nor a
 * `cognito:username` claim. Callers MUST treat a `null` return as
 * "fall back to the existing UUID-based display path".
 *
 * Mirrors the inline `extractEmailFromToken` helper in
 * {@link AuthContext} byte-for-byte (same precedence: `email` first,
 * `cognito:username` second). Lifted into the auth module so the API
 * client can read it without depending on the React context.
 */
export function getStoredUserEmail(): string | null {
  const tokens = getStoredTokens();
  if (!tokens?.idToken) return null;
  try {
    const payload = JSON.parse(atob(tokens.idToken.split('.')[1])) as {
      email?: unknown;
      'cognito:username'?: unknown;
    };
    const candidate = payload.email ?? payload['cognito:username'];
    return typeof candidate === 'string' && candidate.length > 0
      ? candidate
      : null;
  } catch {
    return null;
  }
}
