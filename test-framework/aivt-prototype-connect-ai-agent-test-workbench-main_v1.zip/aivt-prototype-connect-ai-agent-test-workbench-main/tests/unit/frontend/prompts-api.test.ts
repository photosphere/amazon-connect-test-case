/**
 * Unit tests for the typed Prompts API client wrappers (task 13.1).
 *
 * Covers:
 *  - Each wrapper hits the right `(method, path)` and returns the typed
 *    response shape verbatim.
 *  - `resetPrompt` injects `{ confirm: true }` automatically so callers
 *    cannot trip the design's `RESET_CONFIRMATION_REQUIRED` guard (R6.6).
 *  - 4xx responses carrying a recognised structured `code` are rethrown
 *    as {@link PromptApiError} with the typed `code`, `httpStatus`, and
 *    `details` lifted from the body — covers every code in the design's
 *    error table (`PROMPT_NOT_FOUND`, `PROMPT_TEXT_TOO_LARGE`,
 *    `PLACEHOLDERS_MISSING`, `PLACEHOLDER_COUNT_EXCEEDED`,
 *    `UNKNOWN_PLACEHOLDER`, `MODEL_NOT_ALLOWED`, `MODEL_FORBIDS_KEY`,
 *    `INFERENCE_PARAMETER_OUT_OF_BOUNDS`, `DRY_RENDER_FAILED`,
 *    `RESET_CONFIRMATION_REQUIRED`, `VERSION_CONFLICT`).
 *  - Untyped 4xx responses (no `code` field) propagate as the base
 *    {@link ApiClientError} so 401/redirect-to-login semantics are
 *    preserved.
 *  - 5xx responses propagate as `ApiClientError` (not `PromptApiError`)
 *    so the global flash-notification dispatch from `client.ts` keeps
 *    its current contract.
 *
 * Validates: Requirements 13.2, 14.1, 14.3, 14.4
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

vi.mock('../../../src/frontend/src/auth', () => ({
  getAccessToken: vi.fn(async () => 'test-token'),
  getStoredUserEmail: vi.fn(() => null),
  redirectToLogin: vi.fn(),
}));

vi.mock('../../../src/frontend/src/api/config', () => ({
  getConfig: vi.fn(() => ({
    apiEndpoint: 'https://example.test/prod',
    cognitoUserPoolId: 'us-east-1_TEST',
    cognitoClientId: 'test-client-id',
    cognitoDomain: 'test.auth.us-east-1.amazoncognito.com',
    region: 'us-east-1',
    instanceMode: 'development',
  })),
}));

vi.mock('../../../src/frontend/src/api/notifications', () => ({
  notifyError: vi.fn(),
}));

import {
  ApiClientError,
  PromptApiError,
  listPrompts,
  getPrompt,
  updatePrompt,
  resetPrompt,
  getHistory,
  getActiveRuns,
  type PromptErrorCode,
} from '../../../src/frontend/src/api';

const mockFetch = vi.fn();
// Cast through unknown so vitest's mock typings don't collide with the
// global `fetch` declaration.
(globalThis as unknown as { fetch: typeof fetch }).fetch = mockFetch as unknown as typeof fetch;

function jsonResponse(status: number, body: unknown): Response {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: '',
    json: async () => body,
  } as unknown as Response;
}

beforeEach(() => {
  mockFetch.mockReset();
});

afterEach(() => {
  vi.clearAllMocks();
});

// ---------------------------------------------------------------------------
// Happy-path: each wrapper hits the right path/method and returns the body
// ---------------------------------------------------------------------------

describe('Prompts API client — happy paths', () => {
  it('listPrompts() issues GET /prompts and returns the typed body', async () => {
    const body = {
      prompts: [
        {
          promptKey: 'failure_analysis',
          name: 'Failure Analysis',
          category: 'analysis',
          description: 'Analyses failed cases.',
          defaultModelKey: 'claude_sonnet_4_6',
          currentModelKey: 'claude_sonnet_4_6',
          defaultModelDisplayName: 'Claude Sonnet 4.6',
          currentModelDisplayName: 'Claude Sonnet 4.6',
          lastModifiedAt: null,
          lastModifiedBy: null,
          version: 0,
          isOverridden: false,
        },
      ],
    };
    mockFetch.mockResolvedValueOnce(jsonResponse(200, body));

    const result = await listPrompts();

    expect(mockFetch).toHaveBeenCalledTimes(1);
    const [url, init] = mockFetch.mock.calls[0];
    expect(url).toBe('https://example.test/prod/prompts');
    expect((init as RequestInit).method).toBe('GET');
    expect(result).toEqual(body);
  });

  it('getPrompt(key) URL-encodes the path parameter and returns the typed body', async () => {
    const body = { promptKey: 'suite_recommendation' };
    mockFetch.mockResolvedValueOnce(jsonResponse(200, body));

    await getPrompt('suite_recommendation');

    const [url, init] = mockFetch.mock.calls[0];
    expect(url).toBe('https://example.test/prod/prompts/suite_recommendation');
    expect((init as RequestInit).method).toBe('GET');
  });

  it('updatePrompt(key, body) issues PUT with a JSON body', async () => {
    const body = {
      promptKey: 'failure_analysis',
      version: 1,
      lastModifiedAt: '2024-01-01T00:00:00Z',
      lastModifiedBy: 'sub-123',
    };
    mockFetch.mockResolvedValueOnce(jsonResponse(200, body));

    await updatePrompt('failure_analysis', { text: 'hello {failureSummary}' });

    const [url, init] = mockFetch.mock.calls[0];
    expect(url).toBe('https://example.test/prod/prompts/failure_analysis');
    expect((init as RequestInit).method).toBe('PUT');
    expect(JSON.parse((init as RequestInit).body as string)).toEqual({
      text: 'hello {failureSummary}',
    });
  });

  it('resetPrompt(key) injects { confirm: true } automatically (R6.6)', async () => {
    mockFetch.mockResolvedValueOnce(
      jsonResponse(200, {
        promptKey: 'failure_analysis',
        version: 0,
        resetAt: '2024-01-01T00:00:00Z',
      }),
    );

    await resetPrompt('failure_analysis');

    const [url, init] = mockFetch.mock.calls[0];
    expect(url).toBe('https://example.test/prod/prompts/failure_analysis/reset');
    expect((init as RequestInit).method).toBe('POST');
    expect(JSON.parse((init as RequestInit).body as string)).toEqual({
      confirm: true,
    });
  });

  it('getHistory(key) issues GET /prompts/{key}/history', async () => {
    mockFetch.mockResolvedValueOnce(jsonResponse(200, { history: [] }));

    await getHistory('comparison_summary');

    const [url, init] = mockFetch.mock.calls[0];
    expect(url).toBe(
      'https://example.test/prod/prompts/comparison_summary/history',
    );
    expect((init as RequestInit).method).toBe('GET');
  });

  it('getActiveRuns() issues GET /prompts/active-runs', async () => {
    mockFetch.mockResolvedValueOnce(jsonResponse(200, { count: 2 }));

    const result = await getActiveRuns();

    const [url, init] = mockFetch.mock.calls[0];
    expect(url).toBe('https://example.test/prod/prompts/active-runs');
    expect((init as RequestInit).method).toBe('GET');
    expect(result).toEqual({ count: 2 });
  });
});

// ---------------------------------------------------------------------------
// Error mapping: every PromptErrorCode rethrows as PromptApiError
// ---------------------------------------------------------------------------

describe('Prompts API client — structured error mapping', () => {
  const errorTable: Array<{
    code: PromptErrorCode;
    httpStatus: number;
    details?: Record<string, unknown>;
  }> = [
    { code: 'PROMPT_NOT_FOUND', httpStatus: 404 },
    {
      code: 'PROMPT_TEXT_TOO_LARGE',
      httpStatus: 400,
      details: { observedBytes: 70_000, limitBytes: 65_536 },
    },
    {
      code: 'PLACEHOLDERS_MISSING',
      httpStatus: 400,
      details: { missing: ['failureSummary'] },
    },
    {
      code: 'PLACEHOLDER_COUNT_EXCEEDED',
      httpStatus: 400,
      details: { placeholder: 'failureSummary', observed: 3, max: 1 },
    },
    {
      code: 'UNKNOWN_PLACEHOLDER',
      httpStatus: 400,
      details: { token: '{rogue}', offset: 42 },
    },
    {
      code: 'MODEL_NOT_ALLOWED',
      httpStatus: 400,
      details: { requested: 'nova_pro', allowed: ['claude_sonnet_4_6'] },
    },
    {
      code: 'MODEL_FORBIDS_KEY',
      httpStatus: 400,
      details: { key: 'temperature', profile: 'anthropic_claude_4x' },
    },
    {
      code: 'INFERENCE_PARAMETER_OUT_OF_BOUNDS',
      httpStatus: 400,
      details: { key: 'topP', value: 2, range: { min: 0, max: 1 } },
    },
    {
      code: 'DRY_RENDER_FAILED',
      httpStatus: 400,
      details: { step: 'fillTemplate', message: 'unbalanced brace' },
    },
    { code: 'RESET_CONFIRMATION_REQUIRED', httpStatus: 400 },
    {
      code: 'VERSION_CONFLICT',
      httpStatus: 409,
      details: { promptKey: 'failure_analysis' },
    },
  ];

  for (const { code, httpStatus, details } of errorTable) {
    it(`maps ${code} (HTTP ${httpStatus}) to PromptApiError`, async () => {
      mockFetch.mockResolvedValueOnce(
        jsonResponse(httpStatus, {
          error: `the ${code} message`,
          code,
          ...(details ? { details } : {}),
        }),
      );

      // Use a wrapper that exercises the right path for the code so the
      // path itself is irrelevant to the mapping logic (we test mapping,
      // not routing). `getPrompt` covers GET; the mapping is shared across
      // wrappers.
      let caught: unknown;
      try {
        await getPrompt('failure_analysis');
      } catch (err) {
        caught = err;
      }

      expect(caught).toBeInstanceOf(PromptApiError);
      const err = caught as PromptApiError;
      expect(err.code).toBe(code);
      expect(err.httpStatus).toBe(httpStatus);
      if (details) {
        expect(err.details).toEqual(details);
      } else {
        expect(err.details).toBeUndefined();
      }
      expect(err.message).toBe(`the ${code} message`);
    });
  }

  it('leaves untyped 4xx responses (no code) as ApiClientError', async () => {
    mockFetch.mockResolvedValueOnce(
      jsonResponse(400, { error: 'Request body must be a JSON object' }),
    );

    let caught: unknown;
    try {
      await updatePrompt('failure_analysis', {});
    } catch (err) {
      caught = err;
    }

    expect(caught).toBeInstanceOf(ApiClientError);
    expect(caught).not.toBeInstanceOf(PromptApiError);
    expect((caught as ApiClientError).status).toBe(400);
  });

  it('leaves 5xx responses as ApiClientError so notifyError still fires', async () => {
    mockFetch.mockResolvedValueOnce(
      jsonResponse(500, { error: 'Internal server error', code: 'INTERNAL_ERROR' }),
    );

    let caught: unknown;
    try {
      await listPrompts();
    } catch (err) {
      caught = err;
    }

    // INTERNAL_ERROR isn't in the prompts-typed error union, so the
    // base client's notifyError dispatch keeps its 5xx contract.
    expect(caught).toBeInstanceOf(ApiClientError);
    expect(caught).not.toBeInstanceOf(PromptApiError);
    expect((caught as ApiClientError).status).toBe(500);
    expect((caught as ApiClientError).retryable).toBe(true);
  });

  it('does NOT misclassify a non-prompt code as a PromptApiError', async () => {
    // A 400 with a code that isn't in the closed `PromptErrorCode` union
    // (e.g. a future audit-resource code) must surface as ApiClientError
    // so other wrappers can map it themselves.
    mockFetch.mockResolvedValueOnce(
      jsonResponse(400, {
        error: 'unrelated resource error',
        code: 'AUDIT_INVALID_FILTER',
      }),
    );

    let caught: unknown;
    try {
      await listPrompts();
    } catch (err) {
      caught = err;
    }

    expect(caught).toBeInstanceOf(ApiClientError);
    expect(caught).not.toBeInstanceOf(PromptApiError);
    expect((caught as ApiClientError).code).toBe('AUDIT_INVALID_FILTER');
  });
});
