/**
 * Evaluation result assembly — pure mapping module.
 *
 * Consumes the output of `aggregateScores` (`src/shared/utils/evaluation-scoring.ts`)
 * plus an optional failure context describing why the AgentCore submission
 * could not produce a complete, mappable result, and emits the score-shaped
 * fields that get persisted on a `TestCaseResult`.
 *
 * The output is one of two mutually-exclusive shapes:
 *
 * 1. **Scored:** all three score fields (`goalSuccessScore`,
 *    `helpfulnessScore`, `toolAccuracyScore`) are present and `evaluationError`
 *    is unset. This is only emitted when no failure context is supplied AND
 *    `aggregated.missingEvaluators` is empty.
 *
 * 2. **Error state:** `evaluationError` is set with a typed `code` and a
 *    human-readable `reason` (Req 10.4) — and **all three score fields are
 *    left unset** (Req 10.3 / Property 12), even when the underlying
 *    `AggregatedScores` contained partial scores. This intentionally favours
 *    the strict invariant from Requirement 10.3 ("WHEN the
 *    Evaluation_Error_State is set... THE Platform SHALL leave
 *    `goalSuccessScore`, `helpfulnessScore`, and `toolAccuracyScore` unset")
 *    over the partial-store wording in Requirement 8.7. Property 12 codifies
 *    this resolution: an evaluation error state leaves all three scores
 *    unset, period.
 *
 * Failure precedence (when multiple signals are present):
 *
 *   `insufficient-trace` > `timeout` > `agentcore-error` > `unmappable-result`
 *   > `missing-evaluator` (derived from `AggregatedScores.missingEvaluators`)
 *
 * Whichever signal applies first wins; any explicit failure passed by the
 * caller takes precedence over the derived missing-evaluator state because
 * the caller has more context (e.g. a timeout for goal-success makes the
 * "missing helpfulness" diagnosis less useful).
 *
 * **No local-scoring fallback (Req 10.6).** This module does not import,
 * call, or reference `calculateToolAccuracy` or any other local scoring
 * helper. `toolAccuracyScore` is set only from `AggregatedScores`, which is
 * itself derived only from AgentCore evaluator outcomes.
 *
 * Pure / standalone — no AWS SDK imports, no I/O, no side effects.
 *
 * @module evaluation-result
 */

import type { AggregatedScores } from "./evaluation-scoring";
import type { TestCaseResult, EvaluationErrorCode } from "../types";

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/**
 * Re-exported from `../types` for backward compatibility with existing imports.
 */
export type { EvaluationErrorCode } from "../types";

/**
 * Discriminated union describing why the AgentCore submission could not
 * yield a complete, mappable evaluation for this test case. Each variant
 * maps to exactly one `EvaluationErrorCode`.
 *
 * The caller (the Evaluation Lambda or the local harness) constructs a
 * `FailureContext` from observed conditions:
 *
 * - `insufficient-trace`: `buildOtelSession` threw `InsufficientTraceError`
 *   (Req 9.5). No AgentCore call was made.
 * - `timeout`: at least one evaluator's `Evaluate` call exceeded the 60 s
 *   timeout (Req 10.1).
 * - `agentcore-error`: AgentCore returned an error response for at least
 *   one evaluator (Req 10.2 first clause).
 * - `unmappable-result`: AgentCore returned a result that cannot be mapped
 *   to valid scores (Req 10.2 second clause). This is distinct from
 *   missing-evaluator: the response was present but malformed.
 *
 * When **none** of these apply, the caller passes `undefined` (or omits the
 * argument) and the function falls back to checking `missingEvaluators`.
 */
export type FailureContext =
  | { kind: "insufficient-trace"; message?: string }
  | { kind: "timeout"; message?: string }
  | { kind: "agentcore-error"; message: string }
  | { kind: "unmappable-result"; message: string };

/**
 * Subset of `TestCaseResult` populated by this module — the three score
 * fields and the `evaluationError` object. Either the three scores are
 * fully populated **or** `evaluationError` is set; the two are mutually
 * exclusive (Req 10.3).
 *
 * The persisted `TestCaseResult` shape (`src/shared/types.ts`) makes all
 * four fields optional, so this type is structurally a sub-record of
 * `TestCaseResult` and can be spread into one without loss.
 */
export type CaseEvaluation = Pick<
  TestCaseResult,
  | "goalSuccessScore"
  | "helpfulnessScore"
  | "toolAccuracyScore"
  | "evaluationError"
>;

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

/**
 * Maps a `FailureContext` to the corresponding `EvaluationErrorCode` and a
 * default human-readable reason. The caller may override the default via
 * the optional `message` field.
 *
 * The default reasons are written for the results-view audience (Req 10.4)
 * and intentionally avoid stack traces or low-level SDK error names.
 */
function failureToError(
  failure: FailureContext
): { code: EvaluationErrorCode; reason: string } {
  switch (failure.kind) {
    case "insufficient-trace":
      return {
        code: "INSUFFICIENT_TRACE",
        reason:
          failure.message ??
          "Captured trace contained no tool calls and no assistant turns; nothing to evaluate.",
      };
    case "timeout":
      return {
        code: "TIMEOUT",
        reason:
          failure.message ??
          "AgentCore Evaluate did not return a result within 60 seconds.",
      };
    case "agentcore-error":
      return {
        code: "JUDGE_ERROR",
        reason: failure.message,
      };
    case "unmappable-result":
      return {
        code: "UNMAPPABLE_RESULT",
        reason: failure.message,
      };
  }
}

/**
 * Builds the `MISSING_EVALUATOR` error state from a non-empty list of
 * evaluator ids that did not return a usable numeric result.
 *
 * The list is preserved verbatim on `evaluationError.missingEvaluators`
 * (Req 8.7); the human-readable `reason` enumerates the names so the
 * results view can show the omitted evaluator(s) without re-computing.
 */
function missingEvaluatorError(
  missing: readonly string[]
): { code: EvaluationErrorCode; reason: string; missingEvaluators: string[] } {
  // Defensive copy so the caller cannot mutate the persisted record.
  const list = [...missing];
  const joined = list.join(", ");
  return {
    code: "MISSING_EVALUATOR",
    reason: `AgentCore Evaluate did not return a usable result for: ${joined}.`,
    missingEvaluators: list,
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Assembles the `TestCaseResult` evaluation fields from an `AggregatedScores`
 * value (task 12.1) and an optional failure context.
 *
 * Output rules (mutually exclusive):
 *
 * 1. **Failure context supplied** — return `{ evaluationError: { code, reason } }`
 *    with all three score fields unset. The `code` is derived from the
 *    failure variant; the `reason` is the caller-supplied `message` when
 *    present, otherwise a documented default.
 *
 * 2. **`aggregated.missingEvaluators` non-empty** — return
 *    `{ evaluationError: { code: "MISSING_EVALUATOR", reason, missingEvaluators } }`
 *    with all three score fields unset. Even when `aggregated` carries
 *    partial scores for the evaluators that *did* return, those scores are
 *    intentionally dropped so the evaluation-error invariant
 *    (Property 12 / Req 10.3) holds: an error state never coexists with
 *    score values on the same record.
 *
 * 3. **Otherwise** — return `{ goalSuccessScore, helpfulnessScore,
 *    toolAccuracyScore }` taken directly from `aggregated`. `evaluationError`
 *    is unset. All three scores are guaranteed to be defined in this branch
 *    because they are sourced from an `AggregatedScores` whose
 *    `missingEvaluators` list is empty (the aggregator only leaves a score
 *    unset when the corresponding evaluator id is added to that list).
 *
 * The function is **total** with respect to the input space: every
 * combination of `aggregated` + `failure` produces exactly one of the
 * three output shapes above, and the three shapes are disjoint.
 *
 * Requirement 10.6 is enforced *structurally*: this function only consumes
 * `AggregatedScores` (which itself is built only from AgentCore evaluator
 * outcomes in `aggregateScores`). It does not import or reference
 * `calculateToolAccuracy` or any other local-scoring helper, so
 * `toolAccuracyScore` cannot originate from anywhere except an AgentCore
 * `Builtin.ToolSelectionAccuracy` result.
 *
 * @param aggregated - The aggregator output for this case, or `undefined`
 *                     when no submission was made (e.g. on insufficient
 *                     trace, the caller passes a failure context and may
 *                     omit `aggregated`)
 * @param failure - Optional explicit failure context taking precedence over
 *                  any missing-evaluator state
 * @returns The score / error-state slice of the `TestCaseResult` to persist
 */
export function assembleCaseEvaluation(
  aggregated: AggregatedScores | null | undefined,
  failure?: FailureContext
): CaseEvaluation {
  // -------------------------------------------------------------------------
  // 1. Explicit failure context wins — score fields are unset (Req 10.3).
  // -------------------------------------------------------------------------
  if (failure) {
    const { code, reason } = failureToError(failure);
    return { evaluationError: { code, reason } };
  }

  // -------------------------------------------------------------------------
  // 2. Derived missing-evaluator state — score fields are unset (Req 10.3).
  //    A defensive `aggregated == null` check produces an
  //    `UNMAPPABLE_RESULT` so the function remains total even when called
  //    without either argument; in normal use the caller passes either a
  //    failure context or a real `AggregatedScores`.
  // -------------------------------------------------------------------------
  if (!aggregated) {
    return {
      evaluationError: {
        code: "UNMAPPABLE_RESULT",
        reason:
          "AgentCore Evaluate produced no aggregated scores for this case.",
      },
    };
  }

  if (aggregated.missingEvaluators.length > 0) {
    const { code, reason, missingEvaluators } = missingEvaluatorError(
      aggregated.missingEvaluators
    );
    return {
      evaluationError: {
        code,
        reason,
        missingEvaluators,
      },
    };
  }

  // -------------------------------------------------------------------------
  // 3. Fully scored — all three evaluators returned usable values.
  //    By the contract of `aggregateScores`, all three score fields are
  //    defined in this branch; we narrow with non-null assertions backed by
  //    the empty-`missingEvaluators` guard above.
  // -------------------------------------------------------------------------
  return {
    goalSuccessScore: aggregated.goalSuccessScore!,
    helpfulnessScore: aggregated.helpfulnessScore!,
    toolAccuracyScore: aggregated.toolAccuracyScore!,
  };
}
