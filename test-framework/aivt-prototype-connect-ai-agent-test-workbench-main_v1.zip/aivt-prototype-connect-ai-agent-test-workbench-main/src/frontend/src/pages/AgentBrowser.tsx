import { useCallback, useEffect, useState } from 'react';
import ContentLayout from '@cloudscape-design/components/content-layout';
import Header from '@cloudscape-design/components/header';
import Table, { type TableProps } from '@cloudscape-design/components/table';
import Box from '@cloudscape-design/components/box';
import Button from '@cloudscape-design/components/button';
import SpaceBetween from '@cloudscape-design/components/space-between';
import Alert from '@cloudscape-design/components/alert';
import Spinner from '@cloudscape-design/components/spinner';
import Container from '@cloudscape-design/components/container';
import ColumnLayout from '@cloudscape-design/components/column-layout';
import ExpandableSection from '@cloudscape-design/components/expandable-section';
import Textarea from '@cloudscape-design/components/textarea';
import Badge from '@cloudscape-design/components/badge';
import { apiClient, ApiClientError } from '../api';
import type { AgentSummary, AgentDetail } from '../../../shared/types';
import { extractFriendlyModelName } from '../../../shared/utils/model-naming';

interface ListAgentsResponse {
  agents: AgentSummary[];
}

export function AgentBrowser() {
  const [agents, setAgents] = useState<AgentSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedAgent, setSelectedAgent] = useState<AgentSummary | null>(null);
  const [agentDetail, setAgentDetail] = useState<AgentDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);

  const fetchAgents = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await apiClient.get<ListAgentsResponse>('/agents');
      setAgents(response.agents);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred while loading agents.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAgents();
  }, [fetchAgents]);

  const fetchAgentDetail = useCallback(async (agentId: string) => {
    setDetailLoading(true);
    setDetailError(null);
    setAgentDetail(null);
    try {
      const detail = await apiClient.get<AgentDetail>(`/agents/${agentId}`);
      setAgentDetail(detail);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setDetailError(err.message);
      } else {
        setDetailError('Failed to load agent details.');
      }
    } finally {
      setDetailLoading(false);
    }
  }, []);

  const handleSelectionChange: TableProps['onSelectionChange'] = (event) => {
    const selected = (event.detail.selectedItems[0] as AgentSummary) || null;
    setSelectedAgent(selected);
    if (selected) {
      fetchAgentDetail(selected.agentId);
    } else {
      setAgentDetail(null);
      setDetailError(null);
    }
  };

  const columnDefinitions: TableProps.ColumnDefinition<AgentSummary>[] = [
    {
      id: 'name',
      header: 'Agent Name',
      cell: (item) => item.name,
      sortingField: 'name',
    },
    {
      id: 'agentId',
      header: 'Agent ID',
      cell: (item) => item.agentId,
    },
    {
      id: 'toolCount',
      header: 'Tools',
      cell: (item) => item.toolCount,
      sortingField: 'toolCount',
    },
    {
      id: 'modelId',
      header: 'Model',
      cell: (item) => extractFriendlyModelName(item.modelId),
    },
  ];

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description="Discover and inspect AI Agents on your Connect instance"
          actions={
            <Button iconName="refresh" onClick={fetchAgents} loading={loading}>
              Refresh
            </Button>
          }
        >
          Agent Browser
        </Header>
      }
    >
      <SpaceBetween size="l">
        {error && (
          <Alert
            type="error"
            dismissible
            onDismiss={() => setError(null)}
            header="Failed to load agents"
            action={<Button onClick={fetchAgents}>Retry</Button>}
          >
            {error}
          </Alert>
        )}

        <Table
          columnDefinitions={columnDefinitions}
          items={agents}
          loading={loading}
          loadingText="Loading agents..."
          selectionType="single"
          selectedItems={selectedAgent ? [selectedAgent] : []}
          onSelectionChange={handleSelectionChange}
          trackBy="agentId"
          variant="full-page"
          header={
            <Header counter={`(${agents.length})`}>
              AI Agents
            </Header>
          }
          empty={
            <Box textAlign="center" color="inherit" padding="l">
              <SpaceBetween size="m">
                <b>No agents available</b>
                <Box variant="p" color="inherit">
                  No ORCHESTRATION-type AI Agents were found on the configured assistant.
                  Ensure your Connect instance has agents configured.
                </Box>
                <Button onClick={fetchAgents}>Refresh</Button>
              </SpaceBetween>
            </Box>
          }
        />

        {selectedAgent && (
          <AgentDetailPanel
            agent={selectedAgent}
            detail={agentDetail}
            loading={detailLoading}
            error={detailError}
            onRetry={() => fetchAgentDetail(selectedAgent.agentId)}
          />
        )}
      </SpaceBetween>
    </ContentLayout>
  );
}

interface AgentDetailPanelProps {
  agent: AgentSummary;
  detail: AgentDetail | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}

function AgentDetailPanel({ agent, detail, loading, error, onRetry }: AgentDetailPanelProps) {
  if (loading) {
    return (
      <Container header={<Header variant="h2">{agent.name}</Header>}>
        <Box textAlign="center" padding="l">
          <Spinner size="large" />
          <Box variant="p" margin={{ top: 's' }}>Loading agent details...</Box>
        </Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Container header={<Header variant="h2">{agent.name}</Header>}>
        <Alert
          type="error"
          header="Failed to load agent details"
          action={<Button onClick={onRetry}>Retry</Button>}
        >
          {error}
        </Alert>
      </Container>
    );
  }

  if (!detail) {
    return null;
  }

  return (
    <Container header={<Header variant="h2">{detail.name}</Header>}>
      <SpaceBetween size="l">
        <ColumnLayout columns={3} variant="text-grid">
          <div>
            <Box variant="awsui-key-label">Agent ID</Box>
            <Box>{detail.agentId}</Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Model</Box>
            <Box>{extractFriendlyModelName(detail.modelId)}</Box>
            <Box variant="small" color="text-status-inactive">
              {detail.modelId}
            </Box>
          </div>
          <div>
            <Box variant="awsui-key-label">Tools configured</Box>
            <Box>{detail.tools.length}</Box>
          </div>
        </ColumnLayout>

        <ExpandableSection
          headerText={`Tools (${detail.tools.length})`}
          defaultExpanded={true}
        >
          {detail.tools.length === 0 ? (
            <Box color="text-status-inactive">No tools configured for this agent.</Box>
          ) : (
            <SpaceBetween size="m">
              {detail.tools.map((tool) => (
                <Container
                  key={tool.toolName}
                  header={
                    <Header variant="h3" description={tool.description}>
                      <SpaceBetween direction="horizontal" size="xs">
                        {tool.toolName}
                        <Badge color="blue">{tool.toolType}</Badge>
                      </SpaceBetween>
                    </Header>
                  }
                >
                  <SpaceBetween size="s">
                    {tool.instruction && (
                      <div>
                        <Box variant="awsui-key-label">Instruction</Box>
                        <Box variant="code">{tool.instruction}</Box>
                      </div>
                    )}
                    <div>
                      <SpaceBetween direction="horizontal" size="xs">
                        <Box variant="awsui-key-label">Examples</Box>
                        <Badge>{String(tool.examples.length)}</Badge>
                        {tool.examples.length === 0 && (
                          <Box color="text-status-inactive">No examples configured</Box>
                        )}
                      </SpaceBetween>
                      {tool.examples.length > 0 && (
                        <ol style={{ margin: '4px 0 0 0', paddingLeft: 20 }}>
                          {tool.examples.map((example, idx) => (
                            <li key={idx} style={{ marginBottom: 4 }}>
                              <pre
                                style={{
                                  margin: 0,
                                  whiteSpace: 'pre-wrap',
                                  wordBreak: 'break-word',
                                  fontFamily:
                                    'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
                                  backgroundColor: '#f4f4f4',
                                  padding: '6px 8px',
                                  borderRadius: 4,
                                }}
                              >
                                {example}
                              </pre>
                            </li>
                          ))}
                        </ol>
                      )}
                    </div>
                    <div>
                      <Box variant="awsui-key-label">Input Schema</Box>
                      <Box variant="code">
                        <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                          {JSON.stringify(tool.inputSchema, null, 2)}
                        </pre>
                      </Box>
                    </div>
                  </SpaceBetween>
                </Container>
              ))}
            </SpaceBetween>
          )}
        </ExpandableSection>

        <ExpandableSection
          headerText="System Prompt"
          defaultExpanded={false}
          headerDescription={
            detail.systemPrompt
              ? 'YAML prompt template currently configured for this agent'
              : undefined
          }
        >
          {detail.systemPrompt ? (
            <Textarea
              value={detail.systemPrompt}
              readOnly
              rows={20}
              onChange={() => {}}
            />
          ) : (
            <Box color="text-status-inactive">No system prompt configured.</Box>
          )}
        </ExpandableSection>
      </SpaceBetween>
    </Container>
  );
}
