/**
 * CheckRagJobStatus Lambda — Step Functions sub-workflow step 2 (poll).
 *
 * Simple Lambda that calls GetEvaluationJob and returns the status.
 * Called repeatedly via the SFN Wait/Choice loop until the job
 * reaches a terminal state or the poll count exceeds the cap.
 *
 * @module rag-check-status
 */

import {
  BedrockClient,
  GetEvaluationJobCommand,
} from "@aws-sdk/client-bedrock";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";

/**
 * Maximum number of polls before declaring timeout.
 * 60 polls × 30s Wait = 30 min cap (matches the old RAG_JOB_TIMEOUT_MS).
 */
const MAX_POLL_COUNT = 60;

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

let bedrockClient: BedrockClient | null = null;

function getBedrockClient(): BedrockClient {
  if (!bedrockClient) bedrockClient = new BedrockClient({ region: REGION });
  return bedrockClient;
}

/** @internal Test-only injector. */
export function _setBedrockClient(client: BedrockClient | null): void {
  bedrockClient = client as BedrockClient | null;
}

// ---------------------------------------------------------------------------
// Input / Output interfaces
// ---------------------------------------------------------------------------

/** Input from Step Functions (SubmitRagJob output flowing through the loop). */
export interface CheckRagJobStatusInput {
  jobArn: string;
  /** Incremented each iteration by the SFN state (or defaulted to 1). */
  pollCount?: number;
  // Pass-through fields preserved on the SFN state:
  runId?: string;
  suiteId?: string;
  indexMap?: Record<number, string>;
  ragThresholds?: Record<string, number>;
  startedAt?: string;
  judgeModelId?: string;
  inputS3Uri?: string;
  submittedCaseCount?: number;
}

/** Output returned to Step Functions for the Choice state. */
export interface CheckRagJobStatusOutput {
  status: "InProgress" | "Completed" | "Failed" | "Stopped" | "Stopping" | "Timeout";
  outputPath?: string;
  jobArn: string;
  pollCount: number;
  // Pass-through fields:
  runId?: string;
  suiteId?: string;
  indexMap?: Record<number, string>;
  ragThresholds?: Record<string, number>;
  startedAt?: string;
  judgeModelId?: string;
  inputS3Uri?: string;
  submittedCaseCount?: number;
}

// ---------------------------------------------------------------------------
// Lambda handler
// ---------------------------------------------------------------------------

export async function handler(event: CheckRagJobStatusInput): Promise<CheckRagJobStatusOutput> {
  // Extract jobArn from the SFN state. On first poll it's at
  // ragJobState.Payload.jobArn; on subsequent polls it's at
  // ragCheckResult.Payload.jobArn (from our own previous output).
  const ragJobPayload = (event as any).ragJobState?.Payload;
  const prevCheckPayload = (event as any).ragCheckResult?.Payload;

  const jobArn = event.jobArn
    ?? prevCheckPayload?.jobArn
    ?? ragJobPayload?.jobArn
    ?? "";

  const pollCount = (prevCheckPayload?.pollCount ?? event.pollCount ?? 0) + 1;

  // Pass-through fields for downstream steps (ReadRagResults needs these)
  const passThrough = {
    runId: event.runId ?? prevCheckPayload?.runId ?? ragJobPayload?.runId,
    suiteId: event.suiteId ?? prevCheckPayload?.suiteId ?? ragJobPayload?.suiteId,
    indexMap: event.indexMap ?? prevCheckPayload?.indexMap ?? ragJobPayload?.indexMap,
    ragThresholds: event.ragThresholds ?? prevCheckPayload?.ragThresholds ?? ragJobPayload?.ragThresholds,
    startedAt: event.startedAt ?? prevCheckPayload?.startedAt ?? ragJobPayload?.startedAt,
    judgeModelId: event.judgeModelId ?? prevCheckPayload?.judgeModelId ?? ragJobPayload?.judgeModelId,
    inputS3Uri: event.inputS3Uri ?? prevCheckPayload?.inputS3Uri ?? ragJobPayload?.inputS3Uri,
    submittedCaseCount: event.submittedCaseCount ?? prevCheckPayload?.submittedCaseCount ?? ragJobPayload?.submittedCaseCount,
  };

  // Check poll cap
  if (pollCount > MAX_POLL_COUNT) {
    console.error("[rag-check-status] Poll count exceeded cap", { pollCount, jobArn });
    return {
      status: "Timeout",
      jobArn,
      pollCount,
      ...passThrough,
    };
  }

  try {
    const response = await getBedrockClient().send(
      new GetEvaluationJobCommand({ jobIdentifier: jobArn }),
    );

    const rawStatus = (response.status ?? "InProgress") as string;
    console.info("[rag-check-status] GetEvaluationJob", { jobArn, status: rawStatus, pollCount });

    if (rawStatus === "Completed") {
      return {
        status: "Completed",
        outputPath: response.outputDataConfig?.s3Uri,
        jobArn,
        pollCount,
        ...passThrough,
      };
    }

    if (rawStatus === "Failed" || rawStatus === "Stopped" || rawStatus === "Stopping" || rawStatus === "Deleting") {
      return {
        status: rawStatus as "Failed" | "Stopped" | "Stopping",
        jobArn,
        pollCount,
        ...passThrough,
      };
    }

    // InProgress
    return {
      status: "InProgress",
      jobArn,
      pollCount,
      ...passThrough,
    };
  } catch (err) {
    console.error("[rag-check-status] GetEvaluationJob error:", err instanceof Error ? err.message : err);
    // Transient error — report InProgress so the loop retries
    return {
      status: "InProgress",
      jobArn,
      pollCount,
      ...passThrough,
    };
  }
}
