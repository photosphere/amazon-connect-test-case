/**
 * Frontend bucket security CDK assertions.
 *
 * Feature: platform-hosting-and-evaluations, Property 16: Frontend bucket is
 * private and ACL-free by construction
 *
 * Asserts the already-applied bucket-level hardening in `lib/storage-construct.ts`
 * is materialized in the synthesized CloudFormation template, so the guarantee
 * holds regardless of any account-level S3 Public Access Block configuration.
 *
 * The hardening checked here:
 *  - PublicAccessBlockConfiguration with all four flags set to `true`
 *    (BlockPublicAcls, IgnorePublicAcls, BlockPublicPolicy, RestrictPublicBuckets)
 *  - OwnershipControls rule `ObjectOwnership: BucketOwnerEnforced` (ACLs disabled)
 *  - A bucket-policy Deny statement on `aws:SecureTransport=false` (TLS-only)
 *  - Server-side encryption enabled (SSE-S3 / AES256)
 *  - No bucket-policy `Allow` statement (and no ACL grant) granting a public
 *    principal — `AllUsers`, `AuthenticatedUsers`, the wildcard `"*"`, or the
 *    `{ AWS: "*" }` principal form
 *
 * Validates: Requirements 12, 13
 */
import { describe, it, expect, vi } from 'vitest';
import * as cdk from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';

// Mock NodejsFunction to avoid esbuild bundling during tests (mirrors
// tests/infrastructure/cdk-stack.test.ts so the construct's synth path runs
// without invoking the bundler).
vi.mock('aws-cdk-lib/aws-lambda-nodejs', () => {
  const lambda = require('aws-cdk-lib/aws-lambda');

  class NodejsFunction extends lambda.Function {
    constructor(scope: any, id: string, props: any) {
      super(scope, id, {
        ...props,
        code: lambda.Code.fromInline('exports.handler = async () => {}'),
        handler: 'index.handler',
        runtime: props?.runtime ?? lambda.Runtime.NODEJS_20_X,
      });
    }
  }

  return { NodejsFunction };
});

import { ConnectAgentTestPlatformStack } from '../../lib/connect-agent-test-platform-stack';

const MOCK_CONNECT_INSTANCE_ID = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890';

function createTestTemplate(): Template {
  const app = new cdk.App();
  const stack = new ConnectAgentTestPlatformStack(app, 'TestStack', {
    connectInstanceId: MOCK_CONNECT_INSTANCE_ID,
    callbackUrls: ['http://localhost:5173'],
    env: { account: '123456789012', region: 'us-east-1' },
  });
  return Template.fromStack(stack);
}

/**
 * Locate the frontend bucket in the template by its construct path. The stack
 * declares exactly one `AWS::S3::Bucket` (the FrontendBucket inside the
 * StorageConstruct); the BucketDeployment's staging is delivered via the CDK
 * asset bucket, not a stack-level S3::Bucket. We still scope by logical id
 * prefix to be explicit about which bucket is being asserted.
 */
function findFrontendBucket(template: Template): { logicalId: string; resource: any } {
  const buckets = template.findResources('AWS::S3::Bucket');
  const entries = Object.entries(buckets);
  const match = entries.find(([logicalId]) => logicalId.startsWith('StorageFrontendBucket'));
  expect(match, 'expected a Storage/FrontendBucket S3 bucket in the synthesized template').toBeDefined();
  const [logicalId, resource] = match!;
  return { logicalId, resource };
}

function findFrontendBucketPolicy(
  template: Template,
  bucketLogicalId: string
): { logicalId: string; resource: any } {
  const policies = template.findResources('AWS::S3::BucketPolicy');
  const entries = Object.entries(policies);
  const match = entries.find(([, resource]) => {
    const ref = (resource as any).Properties?.Bucket;
    // CDK emits `{ Ref: "<bucketLogicalId>" }` for the policy's Bucket prop.
    return ref && typeof ref === 'object' && ref.Ref === bucketLogicalId;
  });
  expect(
    match,
    `expected a BucketPolicy referencing bucket ${bucketLogicalId} in the synthesized template`
  ).toBeDefined();
  const [logicalId, resource] = match!;
  return { logicalId, resource };
}

/**
 * Recursively walk an arbitrary value and collect every string at any depth.
 * Used to scan a policy statement for any forbidden public-principal token
 * regardless of where (or how deeply) it appears in the JSON.
 */
function collectStrings(value: unknown, out: string[] = []): string[] {
  if (typeof value === 'string') {
    out.push(value);
  } else if (Array.isArray(value)) {
    for (const v of value) collectStrings(v, out);
  } else if (value && typeof value === 'object') {
    for (const v of Object.values(value as Record<string, unknown>)) collectStrings(v, out);
  }
  return out;
}

describe('Frontend bucket security (Property 16)', () => {
  const template = createTestTemplate();
  const { logicalId: bucketLogicalId, resource: bucket } = findFrontendBucket(template);
  const bucketProps = bucket.Properties ?? {};

  // -------------------------------------------------------------------------
  // PublicAccessBlockConfiguration: all four flags true
  // Validates: Requirements 12, 13
  // -------------------------------------------------------------------------
  it('frontend bucket has PublicAccessBlockConfiguration with all four flags true', () => {
    const pab = bucketProps.PublicAccessBlockConfiguration;
    expect(pab, 'PublicAccessBlockConfiguration must be set on the frontend bucket').toBeDefined();
    expect(pab.BlockPublicAcls).toBe(true);
    expect(pab.IgnorePublicAcls).toBe(true);
    expect(pab.BlockPublicPolicy).toBe(true);
    expect(pab.RestrictPublicBuckets).toBe(true);
  });

  // -------------------------------------------------------------------------
  // OwnershipControls: BucketOwnerEnforced (ACLs disabled)
  // Validates: Requirements 12, 13
  // -------------------------------------------------------------------------
  it('frontend bucket has OwnershipControls rule ObjectOwnership=BucketOwnerEnforced', () => {
    const oc = bucketProps.OwnershipControls;
    expect(oc, 'OwnershipControls must be set on the frontend bucket').toBeDefined();
    expect(Array.isArray(oc.Rules)).toBe(true);
    expect(oc.Rules.length).toBeGreaterThanOrEqual(1);

    const ownerships: string[] = oc.Rules.map((r: any) => r.ObjectOwnership);
    expect(ownerships).toContain('BucketOwnerEnforced');
  });

  // -------------------------------------------------------------------------
  // SSE: server-side encryption enabled (SSE-S3 / AES256)
  // Validates: Requirements 12, 13
  // -------------------------------------------------------------------------
  it('frontend bucket has SSE encryption enabled', () => {
    const enc = bucketProps.BucketEncryption;
    expect(enc, 'BucketEncryption must be set on the frontend bucket').toBeDefined();
    expect(Array.isArray(enc.ServerSideEncryptionConfiguration)).toBe(true);
    expect(enc.ServerSideEncryptionConfiguration.length).toBeGreaterThanOrEqual(1);

    const algorithms = enc.ServerSideEncryptionConfiguration.map(
      (rule: any) => rule.ServerSideEncryptionByDefault?.SSEAlgorithm
    );
    // `AES256` is the SSE-S3 default emitted by `BucketEncryption.S3_MANAGED`;
    // accept `aws:kms` as well so the assertion remains valid if the construct
    // is ever upgraded to KMS, which would not weaken the security posture.
    const hasSse = algorithms.some((a: string) => a === 'AES256' || a === 'aws:kms');
    expect(hasSse, `expected SSE-S3 (AES256) or aws:kms encryption, got ${JSON.stringify(algorithms)}`).toBe(true);
  });

  // -------------------------------------------------------------------------
  // No public ACL on the bucket itself (accept absent ACL or PRIVATE).
  // BucketOwnerEnforced disables ACLs entirely; we additionally assert the
  // bucket does not declare a public canned ACL.
  // Validates: Requirements 12, 13
  // -------------------------------------------------------------------------
  it('frontend bucket declares no public ACL', () => {
    const acl: string | undefined = bucketProps.AccessControl;
    if (acl !== undefined) {
      expect(['Private', 'BucketOwnerFullControl']).toContain(acl);
      // Defensive: explicitly forbid the canned public ACL values.
      expect(acl).not.toBe('PublicRead');
      expect(acl).not.toBe('PublicReadWrite');
      expect(acl).not.toBe('AuthenticatedRead');
    }
  });

  // -------------------------------------------------------------------------
  // The frontend bucket policy includes a Deny on aws:SecureTransport=false.
  // Validates: Requirements 12, 13
  // -------------------------------------------------------------------------
  it('frontend bucket policy denies non-TLS access (aws:SecureTransport=false)', () => {
    const { resource: policy } = findFrontendBucketPolicy(template, bucketLogicalId);
    const statements: any[] = policy.Properties?.PolicyDocument?.Statement ?? [];
    expect(statements.length).toBeGreaterThan(0);

    const denyTlsStatement = statements.find((s) => {
      if (s.Effect !== 'Deny') return false;
      const condition = s.Condition?.Bool?.['aws:SecureTransport'];
      // CDK serializes the boolean condition value as the string "false".
      return condition === 'false' || condition === false;
    });

    expect(
      denyTlsStatement,
      'expected a Deny statement on aws:SecureTransport=false in the frontend bucket policy'
    ).toBeDefined();

    // The Deny must apply to s3:* (or at minimum cover all S3 actions) on the
    // bucket and its objects so plaintext access is fully blocked.
    const action = denyTlsStatement.Action;
    const actions = Array.isArray(action) ? action : [action];
    expect(actions).toContain('s3:*');
  });

  // -------------------------------------------------------------------------
  // No Allow statement on the frontend bucket policy grants a public principal
  // (AllUsers / AuthenticatedUsers / "*"). The TLS-Deny statement legitimately
  // uses Principal "*" because it denies everyone; only Allow statements are
  // checked here.
  // Validates: Requirements 12, 13
  // -------------------------------------------------------------------------
  it('frontend bucket policy has no Allow statement granting a public principal', () => {
    const { resource: policy } = findFrontendBucketPolicy(template, bucketLogicalId);
    const statements: any[] = policy.Properties?.PolicyDocument?.Statement ?? [];

    const forbiddenPrincipalTokens = [
      '*',
      'arn:aws:iam::*:root',
      'http://acs.amazonaws.com/groups/global/AllUsers',
      'http://acs.amazonaws.com/groups/global/AuthenticatedUsers',
    ];

    for (const statement of statements) {
      if (statement.Effect !== 'Allow') continue;

      // A bare `Principal: "*"` (string) is unambiguously public.
      if (statement.Principal === '*') {
        throw new Error(
          `Found Allow statement with public Principal "*": ${JSON.stringify(statement)}`
        );
      }

      // For object-form Principals, scan all string leaves for forbidden tokens.
      // This catches { AWS: "*" }, { Service: "*" }, nested arrays, etc.
      const principalStrings = collectStrings(statement.Principal);
      for (const token of forbiddenPrincipalTokens) {
        expect(
          principalStrings,
          `Allow statement contains forbidden public principal token "${token}": ${JSON.stringify(statement.Principal)}`
        ).not.toContain(token);
      }
    }
  });

  // -------------------------------------------------------------------------
  // Defense-in-depth: no top-level CORS rule on the frontend bucket exposes
  // the assets to arbitrary origins. (CloudFront fronts the bucket; the bucket
  // itself should not need a permissive CORS policy.) An absent CorsConfiguration
  // is the expected case; if one is present, assert no `*` AllowedOrigin.
  // Validates: Requirements 12, 13
  // -------------------------------------------------------------------------
  it('frontend bucket does not expose a wildcard CORS origin', () => {
    const cors = bucketProps.CorsConfiguration;
    if (cors === undefined) return;

    const rules: any[] = cors.CorsRules ?? [];
    for (const rule of rules) {
      const origins: string[] = rule.AllowedOrigins ?? [];
      expect(origins, `CORS rule must not allow wildcard origin: ${JSON.stringify(rule)}`).not.toContain('*');
    }
  });
});
