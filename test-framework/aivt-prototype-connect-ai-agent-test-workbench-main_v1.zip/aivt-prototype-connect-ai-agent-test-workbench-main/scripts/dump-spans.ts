#!/usr/bin/env node
/**
 * One-off diagnostic: dump every raw span from ListSpans for a given
 * (assistantId, sessionId) so we can inspect what attributes Q in
 * Connect actually emits on `escalate_agent` / `complete_agent` spans
 * for RETURN_TO_CONTROL tool invocations.
 *
 * Usage:
 *   npx tsx scripts/dump-spans.ts <assistantId> <sessionId>
 */

import {
  QConnectClient,
  ListSpansCommand,
} from "@aws-sdk/client-qconnect";

async function main() {
  const [, , assistantId, sessionId] = process.argv;
  if (!assistantId || !sessionId) {
    console.error("usage: npx tsx scripts/dump-spans.ts <assistantId> <sessionId>");
    process.exit(1);
  }
  const client = new QConnectClient({ region: process.env.AWS_REGION ?? "us-east-1" });
  const all: unknown[] = [];
  let nextToken: string | undefined;
  do {
    const resp = await client.send(
      new ListSpansCommand({ assistantId, sessionId, nextToken, maxResults: 100 })
    );
    for (const s of resp.spans ?? []) all.push(s);
    nextToken = resp.nextToken;
  } while (nextToken);
  // Pretty-print every span — full attribute tree, no stripping.
  console.log(JSON.stringify(all, null, 2));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
