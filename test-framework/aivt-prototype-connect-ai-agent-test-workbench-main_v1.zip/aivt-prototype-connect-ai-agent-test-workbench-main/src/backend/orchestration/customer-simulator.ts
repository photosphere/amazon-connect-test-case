/**
 * Customer Simulator — generates realistic customer responses via Bedrock Converse API.
 *
 * Uses the prompt registered as `customer_simulator` in the
 * Prompt_Registry (resolved via `resolvePromptForRun(...)` so the
 * run's pinned snapshot — written by `prepare-run.ts` at run start —
 * supplies the `(text, modelId, inferenceParameters)` triple the
 * simulator runs against). Implements the proven role-flipping pattern:
 * customer messages become "assistant" role and agent messages become
 * "user" role, so the model generates responses as the customer.
 *
 * Migrated from a hardcoded inline `SYSTEM_PROMPT` literal and a
 * `SIMULATOR_MODEL_ID` env-var fallback to the registry
 * (Wave 2 — Task 17.3 of the prompt-management spec). The legacy
 * `SIMULATOR_MODEL_ID` env var is still set in `lib/orchestration-construct.ts`
 * as a Wave-1/Wave-2 safety net and is removed in Wave 3.
 *
 * @module customer-simulator
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ConverseCommandInput,
  type Message,
  type SystemContentBlock,
} from "@aws-sdk/client-bedrock-runtime";
import { CommunicationStyle } from "../../shared/enums";
import type { TranscriptTurn, ToolSequenceTestCase } from "../../shared/types";
import { fillTemplate } from "./bedrock-judge-client";
import {
  buildInferenceConfig,
  PROMPT_REGISTRY,
  type ResolvedPrompt,
} from "./prompt-registry";
import { resolvePromptForRun } from "./prompt-registry/runtime";

// --- Constants ---

const REGION = process.env.AWS_REGION ?? "us-east-1";
const FALLBACK_RESPONSE = "Yes, please proceed";

// --- Style Mapping ---

/**
 * Maps each CommunicationStyle to a descriptive instruction that constrains
 * the model's tone and phrasing to match that style.
 */
export const STYLE_INSTRUCTIONS: Record<CommunicationStyle, string> = {
  [CommunicationStyle.DIRECT]:
    "You are clear and to-the-point. You state exactly what you want without extra explanation.",
  [CommunicationStyle.INDIRECT]:
    "You describe your situation without naming the exact action you need. You hint at what you want rather than stating it directly.",
  [CommunicationStyle.COLLOQUIAL]:
    "You speak casually with slang and informal language. You are not formal at all.",
  [CommunicationStyle.QUESTION]:
    "You tend to phrase things as questions rather than commands. You ask rather than tell.",
  [CommunicationStyle.COMPLAINT]:
    "You are frustrated and complaining about the situation. You express dissatisfaction while still wanting help.",
};

// --- Role Flipping ---

/**
 * Flips conversation roles for the Bedrock Converse API call.
 *
 * The Converse API generates "assistant" role responses. To make it generate
 * customer responses, we flip:
 * - Customer messages → assistant role (the model "said" these)
 * - Agent messages → user role (these are what the model responds to)
 *
 * Text content is preserved unchanged.
 */
export function flipConversationRoles(history: TranscriptTurn[]): Message[] {
  return history.map((turn) => {
    if (turn.role === "customer") {
      return {
        role: "assistant" as const,
        content: [{ text: turn.text }],
      };
    } else {
      // agent → user
      return {
        role: "user" as const,
        content: [{ text: turn.text }],
      };
    }
  });
}

// --- System Prompt Construction ---

/**
 * Builds the variables map fed to the registry's `customer_simulator`
 * template. The four placeholders match the registry's
 * {@link PromptDefinition.placeholders} declaration:
 *
 *   - `{scenario}`         — customer goal text (resolved via the
 *                            `goalDescription || description ||
 *                            initialUtterance` fallback chain)
 *   - `{opening_line}`     — verbatim opening utterance
 *   - `{style_instruction}` — style-mapped instruction text
 *   - `{customer_details}` — formatted personal-details block
 *
 * Pure helper exported so unit and property tests can verify the
 * variable values without exercising Bedrock.
 */
export function buildSimulatorVariables(
  testCase: ToolSequenceTestCase,
): Record<string, string> {
  const openingLine = testCase.initialUtterance;
  // Resolution order for the simulator's "scenario / goal" line:
  //   1. `goalDescription` — the dedicated field captured from the
  //      "Goal description" textarea, also fed to the Suggest-Tools
  //      scaffold endpoint. Preferred when set so a single typed goal
  //      drives both tool suggestion and the runtime simulator.
  //   2. `description` — the long-form scenario textarea. Used as a
  //      fallback to preserve behaviour for test cases authored before
  //      `goalDescription` existed.
  //   3. `initialUtterance` — last-resort fallback when neither field is
  //      populated; keeps the prompt rendering non-degenerate.
  const scenario =
    testCase.goalDescription?.trim() ||
    testCase.description?.trim() ||
    openingLine;
  const styleInstruction =
    STYLE_INSTRUCTIONS[testCase.style] ??
    STYLE_INSTRUCTIONS[CommunicationStyle.DIRECT];

  // Format customer knowledge as personal details
  const knowledgeEntries = Object.entries(testCase.customerKnowledge);
  let customerDetails: string;
  if (knowledgeEntries.length > 0) {
    const lines = knowledgeEntries.map(([key, value]) => `- ${key}: ${value}`);
    customerDetails = lines.join("\n");
  } else {
    customerDetails = "- No specific personal details provided";
  }

  return {
    scenario,
    opening_line: openingLine,
    style_instruction: styleInstruction,
    customer_details: customerDetails,
  };
}

/**
 * Render the simulator system prompt for `testCase` against an
 * already-resolved {@link ResolvedPrompt}. The caller resolves the
 * prompt once per call (typically via {@link resolvePromptForRun}); the
 * helper substitutes the four declared placeholders using
 * `bedrock-judge-client`'s `fillTemplate`.
 *
 * Pure function — no I/O, no side effects.
 */
export function renderSimulatorPrompt(
  prompt: ResolvedPrompt,
  testCase: ToolSequenceTestCase,
): string {
  return fillTemplate(prompt.text, buildSimulatorVariables(testCase));
}

/**
 * Render the simulator system prompt against the registry's bundled
 * `customer_simulator` default text. Used by unit and property tests
 * that exercise the rendering logic without a live registry / DDB
 * dependency. Production callers SHALL go through {@link simulateCustomer}
 * (which resolves the prompt via the run snapshot per R11.2) rather
 * than calling this helper directly.
 */
export function buildSimulatorPrompt(testCase: ToolSequenceTestCase): string {
  return fillTemplate(
    PROMPT_REGISTRY.customer_simulator.defaultText,
    buildSimulatorVariables(testCase),
  );
}

// --- Customer Simulation ---

/** Bedrock client singleton (lazy-initialized). */
let bedrockClient: BedrockRuntimeClient | null = null;

function getBedrockClient(): BedrockRuntimeClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

/**
 * Allows injection of a custom Bedrock client for testing.
 * @internal
 */
export function _setBedrockClient(client: BedrockRuntimeClient | null): void {
  bedrockClient = client;
}

/**
 * Simulates a customer response to an agent message using Bedrock Converse API.
 *
 * Resolves the `customer_simulator` prompt for the executing run via
 * {@link resolvePromptForRun} (R11.2 — the run's pinned snapshot is the
 * source of truth, falling back to the live registry for pre-feature
 * runs), substitutes the four declared placeholders into the prompt
 * text, and issues a Converse call against the resolved model with the
 * resolved inference parameters shaped by {@link buildInferenceConfig}.
 *
 * The runtime helper caches the snapshot read per Lambda warm so
 * invoking the simulator on every turn of a multi-turn conversation
 * issues at most one DynamoDB read per `runId` (R11.3 — once per call
 * or once at the start of a multi-turn loop, never per Converse turn).
 *
 * On Bedrock failure the function logs the cause and re-throws; the
 * test cannot proceed without a working simulator. Empty model output
 * returns the fixed affirmative {@link FALLBACK_RESPONSE}.
 *
 * @param agentMessage - The latest message from the AI agent
 * @param testCase - The test case defining persona, style, and knowledge
 * @param history - The conversation history so far (all prior turns)
 * @param runId - The run id whose pinned snapshot supplies the prompt
 *               (empty string falls back to the live registry — used by
 *               unit tests and the rare pre-feature run path)
 * @returns The simulated customer response text
 */
export async function simulateCustomer(
  agentMessage: string,
  testCase: ToolSequenceTestCase,
  history: TranscriptTurn[],
  runId: string,
): Promise<string> {
  // R11.2 / R11.3: resolve the prompt once per call. The runtime helper
  // caches the snapshot read per warm so a multi-turn conversation
  // issues at most one DDB read regardless of turn count. A failure
  // here propagates naturally as a `PromptResolutionError` (R16.3) — we
  // intentionally do NOT catch it inside the Bedrock try/catch below
  // so the error surfaces with its structured shape rather than being
  // re-wrapped as "Bedrock Converse call failed".
  const prompt = await resolvePromptForRun("customer_simulator", runId);

  try {
    const client = getBedrockClient();

    // Build system prompt by substituting the four declared placeholders
    // into the resolved prompt text.
    const systemPrompt = renderSimulatorPrompt(prompt, testCase);
    const system: SystemContentBlock[] = [{ text: systemPrompt }];

    // Build messages with flipped roles from history.
    const messages: Message[] = flipConversationRoles(history);

    // Add the latest agent message as the final "user" turn (the model
    // needs to respond to this).
    messages.push({
      role: "user",
      content: [{ text: agentMessage }],
    });

    // The wire-shape helper places the resolved inference parameters
    // into the exact arguments the Converse SDK expects for the
    // resolved model's capability profile. For Anthropic Claude 4.x
    // (the default `customer_simulator` model) this emits
    // `{ inferenceConfig: { maxTokens } }` with no `temperature` /
    // `topP` / `topK` / `stopSequences` — those keys are forbidden by
    // the profile (R17.4) and are silently dropped here even when the
    // prompt's `defaultInferenceValues` carries `temperature: 0.7` for
    // the Nova-friendly variants. Same pattern as
    // `comparison-summary.ts`, `analysis.ts`, etc.
    const built = buildInferenceConfig(prompt);

    // The casts on `inferenceConfig` and `additionalModelRequestFields`
    // bridge the SDK's strict types (`InferenceConfiguration` for the
    // top-level config, `DocumentType` for the additional fields) and
    // our runtime payload — `buildInferenceConfig` already enforced
    // the exact key set against the resolved capability profile, so
    // the values are guaranteed JSON-encodable at runtime.
    const command = new ConverseCommand({
      modelId: prompt.modelId,
      system,
      messages,
      inferenceConfig:
        built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
      ...(built.additionalModelRequestFields
        ? {
            additionalModelRequestFields:
              built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
          }
        : {}),
    });

    const response = await client.send(command);

    // Extract response text
    const content = response.output?.message?.content;
    if (content && content.length > 0 && content[0].text) {
      return content[0].text.trim();
    }

    // Empty content — model declined to respond
    return FALLBACK_RESPONSE;
  } catch (error) {
    // Bedrock failure means the test cannot proceed — halt execution with a clear error
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(
      "[customer-simulator] Bedrock Converse call failed — halting test:",
      errorMessage
    );
    throw new Error(
      `Customer simulator failed: ${errorMessage}. ` +
      `The test cannot proceed without a working customer simulator. ` +
      `Check Bedrock IAM permissions and model availability.`
    );
  }
}
