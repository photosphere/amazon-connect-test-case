# Implement recommendations

How the platform turns a recommendation into a real change to the live agent — safely.

## Two paths

| Path | When to use | What it does |
|---|---|---|
| **Direct Apply** | You're confident in the recommendation; want to write to the agent now. | Confirmation-gated `UpdateAIAgent` / `UpdateAIPrompt` call with drift detection. |
| **Multi-Variant Experiment** | You want to compare alternatives before committing. | Generates 3 diverse rewrites, runs the suite against each on temporary cloned agents, presents a tournament. |

Both paths are disabled when the platform runs in production mode. See [operations.md](../operations.md#instance-modes).

## Direct Apply

### Flow

1. User clicks **Implement Recommendations** → **Apply directly** on the run dashboard.
2. The platform shows a **confirmation dialog** with:
   - The agent name and ID being modified.
   - A side-by-side diff per change, grouped by tool and surface.
   - A warning: "This will make changes to your configured agent. Do you want to proceed?".
3. User picks which recommendations to include and clicks **Confirm and Apply**.
4. **Drift detection** runs (see below). If detected → 409 with a [conflict resolution](#drift-detection) dialog.
5. If clean → atomic write: one `UpdateAIAgent` call for tool surfaces, one `UpdateAIPrompt` call for system prompt changes.
6. Audit + apply records persisted.
7. Success notification with the new agent version ID and a **Re-run Suite** prompt to validate the improvement.

Endpoint: `POST /runs/{runId}/apply-recommendations`. Source: `src/backend/handlers/apply-recommendations.ts`.

### What "atomic" means here

For tool-surface changes (`tool_description`, `tool_instruction`, `tool_examples`), the platform clones the current `tools[]` array, applies all selected changes, and submits **one** `UpdateAIAgent` call. Either all tool changes succeed together or none do — no partial state.

For `system_prompt` changes, **one** `UpdateAIPrompt` call. Multiple system_prompt recommendations are handled by applying the last one's `suggestedText` (this can occur when multiple analyses produce overlapping suggestions; the engine deduplicates upstream, so this is a defensive behavior).

If both kinds of changes are selected, two API calls are made — order: `UpdateAIAgent` first, then `UpdateAIPrompt`. A failure on the prompt call after a successful agent call leaves the agent partially updated; the response surfaces both `newAgentVersionId` and the error message so the user knows what to revert.

Both calls produce **new agent versions**. Old versions remain accessible via the Q in Connect API (`ListAIAgentVersions`) for rollback.

### Drift detection

Recommendations are generated against a snapshot of the agent at run start. Between then and the apply attempt, someone else (or the user themselves) may have edited the agent. The platform refuses to silently overwrite intervening edits.

Source: `src/backend/orchestration/drift-detection.ts` (pure function, property-tested).

For each recommendation, before writing:

1. Call `GetAIAgent` to fetch the current live config.
2. Compare each recommendation's `currentText` against the live agent's corresponding field **character-for-character** — no trimming, no normalization.
3. If any field has drifted, abort the write.

The response is a 409 with the drifted fields:

```json
{
  "success": false,
  "error": "drift_detected",
  "driftedFields": [
    {
      "targetField": "tool_instruction",
      "targetName": "verifyIdentity",
      "expectedText": "Use only after greeting.",
      "actualText": "Use only after greeting the customer warmly."
    }
  ]
}
```

The frontend renders this as a **conflict resolution** dialog with three options:

| Option | Effect |
|---|---|
| **Apply anyway** | Force-write, overwriting the drifted field. Audit record carries `userDecision: "apply_anyway"`. |
| **Cancel** | Abort. Nothing changes. |
| **Re-analyze** | Trigger a fresh analysis against the current agent state. New recommendations may differ from the original. |

### Audit and apply records

Every successful direct apply writes two records:

**Audit record** at `PK=TENANT#{tenantId}, SK=AUDIT#{timestamp}`:

```typescript
{
  tenantId, timestamp, runId, agentId,
  source: "direct_apply",
  previousVersionId, newVersionId,
  recommendations: Recommendation[],     // full objects, not just indices
  driftDetected: boolean,
  driftedFields?: DriftedField[],
  userDecision: "normal" | "apply_anyway",
}
```

**Apply record** at `PK=RUN#{runId}, SK=APPLY#DIRECT#{timestamp}`:

```typescript
{
  runId, timestamp, agentId,
  recommendationIndices: number[],       // indices into the run's per-suite recommendation array
  newVersionId,
  source: "direct_apply",
}
```

The audit record is the canonical compliance record. The apply record is the per-run "what got applied to this run's recommendations" log, useful for the run dashboard's "this run had recommendation 0, 2, 4 applied" history.

### Post-apply re-run

When apply succeeds, the frontend shows a Flashbar success message: "Changes applied successfully (version: vN). Re-run the test suite to validate the improvements?" with a **Re-run Suite** button. Clicking it triggers a new test run for the same suite. This closes the loop — change → validate → know whether the change worked.

## Multi-Variant Experiments

Source: `src/backend/handlers/experiment-create.ts`, `src/backend/handlers/experiment-apply.ts`, `src/backend/orchestration/variant-generator.ts`, `src/backend/orchestration/experiment-state-machine.ts`.

### When to use

You have a recommendation and you're not sure if it's the *right* fix. Maybe a more concise rewrite would work better. Maybe an example-heavy version would be more robust. Maybe a restructured version is what's actually needed. Instead of guessing, generate three variants, test all three against your suite, and let the data pick the winner.

### Flow

1. User clicks **Implement Recommendations** → **Advanced: Multi-variant experiment**.
2. The experiment endpoint generates an `experimentId`, persists the experiment record with status `generating_variants`, and starts the experiment state machine.
3. **Variant generation** — Bedrock Converse (temperature 0.7, no `topP`) produces 3 variants using distinct rewrite strategies:
   - **Variant A** — conciseness: shorter, more direct, redundancy removed.
   - **Variant B** — example-heavy: concrete examples added to `tool_examples`, instructions made more specific.
   - **Variant C** — restructured: instruction flow reorganized, logical grouping clarified.
4. **Variant validation** (see [Safety rules](#safety-rules)) — each variant validated against structural constraints, surface scope containment, and system prompt safety. Up to 1 retry per failed variant before marking it failed.
5. **Temporary agent creation** — for each surviving variant, `CreateAIAgent` clones the target agent's full configuration and applies the variant's changes. Temporary agents are named `{original}-experiment-{id}-variant-{A|B|C}`.
6. **Parallel test execution** — three independent test runs against the temporary agents, in parallel.
7. **Tournament summary generation** — Bedrock Converse (temperature 0, no `topP`) explains the deterministic winner.
8. **Cleanup** — `DeleteAIAgent` for every temporary agent. Runs unconditionally regardless of variant outcomes. Up to 1 retry per agent.
9. Experiment status → `completed`. The user navigates to the **Tournament View** via the run dashboard's **Experiment Results** link.

### Tournament View

A 4-column comparison: Baseline, Variant A, Variant B, Variant C. Per column:

- **Aggregate scores** — pass rate, average goal success, average helpfulness, average tool accuracy.
- **Per-case status** with change highlighting — failed→passed = green, passed→failed = red.
- **AI-generated summary** explaining the winner.
- **Recommended badge** on the deterministic winner — highest pass rate, ties broken by average goal success score.
- **Apply to Agent** button per variant column — applies that variant's changes to the live agent (same drift detection + audit flow as Direct Apply, but the audit record's `source` is `experiment_apply` and the variant letter is recorded).

### Winner selection

Source: `src/backend/orchestration/variant-selection.ts` — pure, deterministic, idempotent, property-tested.

```
function selectWinningVariant(scores: VariantScore[]): "A" | "B" | "C" | null:
  eligible = scores.filter(s => s.status === "completed")
  if eligible is empty: return null
  sort eligible by passRate (descending),
              then by avgGoalSuccessScore (descending) for tiebreak
  return eligible[0].variant
```

The AI-generated summary explains the result; it never determines the winner. This separation means the summary can fail (Bedrock outage) without affecting the deterministic outcome — the tournament still has a recommended variant.

### Safety rules

System prompts are particularly sensitive — small changes can break agent functionality or invalidate prompt caching. The `system-prompt-safety.ts` module enforces three rules on every variant that modifies `system_prompt`:

**Rule 1 — Dynamic parameters preserved at end.**

Q in Connect injects placeholders like `{{$.Custom.Foo}}`, `{{agent.bar}}`, `{{session.baz}}` at inference time. These must remain in their original positions at the **end** of the prompt. Relocating them earlier invalidates prompt cache entries and increases latency.

The validator extracts dynamic parameters with regex and verifies the modified prompt has them all in the trailing region.

**Rule 2 — Thinking/messaging blocks immutable.**

Sections delimited by `<thinking>...</thinking>` or `<messaging>...</messaging>` (the Q in Connect orchestration prompt template's required structural blocks) must be **byte-for-byte unchanged**. The agent's internal reasoning format and tool-calling behavior depend on these.

The validator extracts blocks and compares character-for-character.

**Rule 3 — No new examples in system prompt body.**

Bedrock-generated variants commonly try to add helpful examples directly into the system prompt. The platform rejects this — new examples belong in the appropriate tool's `tool_examples` field. The validator detects example-like patterns (`Customer:`/`Agent:` pairs, `Q:`/`A:` lines, `Example N:` markers, `<example>` tags) and flags any introduced into the modified prompt body that weren't in the original.

When no `<thinking>` or `<messaging>` markers are detected in the original prompt, the validator falls back to treating the entire prompt as editable except for trailing dynamic parameters.

Variant generation includes these rules in the Bedrock system prompt so the model is constrained upstream. The post-generation validator is a defense-in-depth check — variants that violate any rule are regenerated once. If still failing, the variant is marked failed and the experiment proceeds with fewer variants (minimum 2).

### Variant scope containment

In addition to the system prompt safety rules, every variant's `targetField` set must be a **subset** of the source recommendations' `targetField` set. If the source recommended only `tool_description` and `tool_instruction` changes, the variant cannot introduce a `system_prompt` recommendation.

Source: variant-generator's per-variant validation. Property-tested in `tests/property/variant-scope.property.test.ts`.

### Production safety

**Temporary agents are never routed to by production traffic.** They're separate Q in Connect AI Agent resources with their own IDs, never associated with the assistant's default routing. The only thing that uses them is the platform's test runner, which sends `aiAgentId` overrides on `SendMessage`. Customer-facing traffic goes to the original agent unchanged.

This is why experiments work safely against live agents: the customer's experience is unaffected, and the experiment's results predict what would happen if you applied the variant to the original.

### Cleanup contract

Cleanup runs **unconditionally** after the parallel variant runs complete:

- Even if all variants errored.
- Even if the tournament summary call failed.
- Even if the user navigated away.

Source: the `Cleanup` step in the experiment state machine has `resultPath: "$.cleanupResult"` capture and a `Catch` handler ensuring it always runs.

If `DeleteAIAgent` fails for an agent, the cleanup retries once with backoff. After the retry, failed agent IDs are persisted to `experimentRecord.failedCleanupAgentIds` and `cleanupStatus` is set to `partial_failure`. Operators can manually delete these orphans (see [troubleshooting](../operations.md#experiment-cleanup-left-orphaned-agents)).

The 90-day TTL on experiment records (`ttl` attribute set to 90 days post-completion) cleans up the metadata in DynamoDB automatically. The associated variant run results are not TTL'd — they're keyed by `runId` and live alongside the baseline run.

### Cost

A multi-variant experiment runs the suite **3 times** (once per variant) plus the baseline run already costs whatever it costs. Plus 1 Bedrock call for variant generation, plus 1 for tournament summary. Plus 3 `CreateAIAgent` and 3 `DeleteAIAgent` calls (which are free in the platform's pricing — Q in Connect API calls are minimal).

For a 50-case suite at ~$0.05 per case judged, an experiment is roughly **$8 of Bedrock cost on top of the baseline run**.

### Graceful degradation

The experiment state machine isolates per-step failures so partial results are usable:

- **Variant generation fails entirely** → experiment status `failed`, no temporary agents created. User sees an error and can fall back to Direct Apply.
- **One variant fails generation, two succeed** → experiment proceeds with 2 variants. Tournament view marks the failed variant column as errored.
- **One variant's test run fails** → other two complete normally. Tournament view shows results for the successful variants and an error indicator for the failed one. The failed variant is excluded from "Recommended" calculation.
- **Tournament summary call fails** → the experiment record carries the deterministic winner and per-variant highlights, but `summary` is the fallback string "Summary generation failed. See quantitative results above." The frontend shows a **Retry summary** button.
- **Cleanup fails on one or more agents** → experiment status still `completed`; `cleanupStatus` is `partial_failure` with `failedCleanupAgentIds` populated. Operators clean up manually.

## Apply variant flow

When the user clicks **Apply to Agent** on a tournament variant column:

Endpoint: `POST /runs/{runId}/experiments/{experimentId}/apply` with body `{ "variant": "B" }`.

The handler:
1. Loads the experiment record and finds the variant config.
2. Same drift detection / audit / write flow as Direct Apply (the underlying logic is shared).
3. Updates the experiment record with `appliedVariant: "B"` and `appliedAt: <timestamp>`.
4. Audit record's `source` is `experiment_apply` with `experimentId` and `appliedVariant` populated.

Each variant column has its own button — the user can apply any variant, not just the recommended one. Maybe Variant A's strategy fits the team's style better even though Variant B scored higher; the platform doesn't constrain the choice.

## Frontend components

| Component | Purpose | Source |
|---|---|---|
| `ImplementButton` | Entry-point button. Opens the mode selector. Hidden in production mode, hidden when no recommendations, hidden during running runs. | `src/frontend/src/components/ImplementRecommendations/ImplementButton.tsx` |
| `ModeSelector` | Modal: "Apply directly" vs "Advanced: Multi-variant experiment". | `ModeSelector.tsx` |
| `ConfirmationDialog` | Side-by-side diff per change, grouped by surface. | `ConfirmationDialog.tsx` |
| `ConflictResolution` | Drift detected dialog with Apply anyway / Cancel / Re-analyze. | `ConflictResolution.tsx` |
| `ExperimentProgress` | Status indicator during experiment lifecycle (generating_variants → creating_agents → running → completed). | `ExperimentProgress.tsx` |
| `TournamentView` | The 4-column comparison page. | `TournamentView.tsx` |
| `PostApplyPrompt` | Success Flashbar with "Re-run Suite" action. | `PostApplyPrompt.tsx` |
| `InstanceModeBadge` | Header badge: "Production (read-only)" or "Development". | `InstanceModeBadge.tsx` |

All wired into the existing pages (Run Dashboard, Failure Analysis, app header, routing for `/runs/:runId/experiments/:experimentId`).

## Backend modules

| Module | Purpose |
|---|---|
| `apply-recommendations.ts` | Direct apply handler. |
| `experiment-create.ts` | Creates experiment record, starts state machine. |
| `experiment-get.ts` | Returns full experiment state. |
| `experiment-apply.ts` | Applies a winning variant. |
| `experiment-cleanup.ts` | State-machine task: deletes temp agents. |
| `audit.ts` | `GET /audit` listing tenant audit records. |
| `drift-detection.ts` | Pure: character-for-character drift check. |
| `config-writer.ts` | Builds `UpdateAIAgent` / `UpdateAIPrompt` payloads, executes writes. |
| `variant-generator.ts` | Bedrock Converse for variant rewrites with retry. |
| `system-prompt-safety.ts` | Pure: validates the three system prompt safety rules. |
| `validation.ts` | Pure: structural validation of recommendation records. |
| `variant-selection.ts` | Pure: deterministic winner selection. |
| `tournament-summary.ts` | Bedrock Converse for the natural-language summary. |
| `experiment-state-machine.ts` | CDK construct defining the state machine. |
| `score-aggregation.ts` | Pure: computes aggregate scores from `TestCaseResult[]`. |

Pure modules are property-tested with fast-check at 100+ iterations per property. See `tests/property/`.
