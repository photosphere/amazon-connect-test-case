# Requirements Document

## Introduction

This feature surfaces two pivotal pieces of data the Q in Connect `ListSpans` API already returns but the Connect Agent Test Platform currently discards: the agent's true chain-of-thought **reasoning** (distinct from the customer-facing `text` value the agent speaks) and per-step **wall-clock latency** computed from each span's `startTimestamp` / `endTimestamp` pair. While extending the parser, the feature also captures the inference metadata Q in Connect surfaces alongside the reasoning block — token usage, model id, time-to-first-token, finish reason, prompt id / version, AI Agent version, and the system instructions the model actually saw on that turn.

The single largest motivation is downstream of the transcript view. The existing `actionable-recommendations` spec (see `.kiro/specs/actionable-recommendations/requirements.md`) drives the Bedrock-backed failure analysis and per-suite recommendation engine. Today that engine consumes the parsed `ExecutionTrace` (tool args / results plus the latency-mask `text` from inference spans). It does NOT see the agent's actual reasoning — and the reasoning is the single most pivotal signal for why a test failed (it tells you whether the agent misunderstood the goal, picked the wrong tool, hallucinated a constraint, or got tripped up by the system prompt). The new spec plumbs reasoning into both the per-case and per-suite analysis prompts so recommendations improve in quality, while preserving every existing persisted artifact — `ANALYSIS#CASE#{caseId}` records, the `Prompt_Registry` versioned overrides, and the existing `TRACE` row shape — so already-shipped data never silently changes meaning.

Reasoning is deliberately NOT plumbed into the three pass/fail Bedrock judges (`Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, `Builtin.ToolSelectionAccuracy`). LLM judges anchor heavily on whatever rationale appears in their context window, so feeding them the agent's own self-narrated reason for an action would shift the rubric from "was the right tool called / was this helpful" to "did the agent claim a coherent reason" — a different and easier question. The post-failure analysis path is the right home for reasoning because a human reviews each recommendation before any change ships; the per-turn judges score under no such human-in-the-loop guarantee. Requirement 13 captures this as an explicit non-goal.

The spec also corrects a separate, pre-existing Helpfulness-judge defect surfaced during requirements review: the per-assistant-turn `{context}` the renderer builds today excludes tool calls that fired in the same turn as the assistant utterance being graded. This causes the judge to score "Let me transfer you" replies as low-helpfulness when an `Escalate` tool actually fired immediately after the reply — the judge sees the promise but never sees the action. Requirement 14 closes that gap without changing the rubric or the Builtin template's input shape.

The verified evidence ground-truth for this spec is the captured ListSpans payload at `tmp/spans-mortgage-rate.json` (14 spans for run `d3d2beea0e7e3e7f2b4e9671`, case `1e986d14baa9f7d1e94c803e`, session `b324a670-d71b-4c4e-a77f-4fb53d071890`). Every attribute key referenced in the requirements below was confirmed present in that payload — no speculation about Q in Connect's emission shape.

## Glossary

- **Platform**: The Connect Agent Test Platform (the existing system this feature extends).
- **Span_Parser**: The pure parser at `src/backend/orchestration/span-parser.ts` whose `parseSpansToTrace` function converts raw Q in Connect `ListSpans` output into a structured `Execution_Trace`.
- **Raw_Span**: One element of the `ListSpans` response. Fields read by this feature: `spanName`, `startTimestamp`, `endTimestamp`, and the `attributes` block (`inputMessages[].values[].{text, toolUse, toolResult, reasoning}`, `outputMessages[].values[].{text, toolUse, toolResult, reasoning}`, `usageInputTokens`, `usageOutputTokens`, `usageTotalTokens`, `requestModel`, `requestMaxTokens`, `temperature`, `responseFinishReasons[]`, `promptArn`, `promptId`, `promptName`, `promptVersion`, `aiAgentVersion`, `timeToFirstTokenMs`, `systemInstructions[].text.value`).
- **Execution_Step**: A single element of `Execution_Trace.steps[]` (defined in `src/shared/types.ts`). Already carries `index`, `type`, `spanName`, `text`, `tool`, `aiAgentName`, `aiAgentType`, `timestamp`. This feature adds `durationMs`, `reasoning`, and an optional `inferenceMetadata` block.
- **Execution_Trace**: The persisted per-case structured trace at `PK=RUN#{runId}#CASE#{caseId}, SK=TRACE` produced by `Span_Parser`.
- **Inference_Metadata**: The new optional sub-object on an `Execution_Step` of type `inference`. Carries `usageInputTokens`, `usageOutputTokens`, `usageTotalTokens`, `requestModel`, `requestMaxTokens`, `temperature`, `timeToFirstTokenMs`, `responseFinishReasons[]`, `promptArn`, `promptId`, `promptName`, `promptVersion`, `aiAgentVersion`, `systemInstructions`. Every field is optional — Q in Connect omits some on partial spans.
- **Reasoning**: A free-text string extracted from a `Raw_Span`'s `outputMessages[].values[].reasoning.value`. Distinct from the `text.value` the same span may also carry. The reasoning is the agent's true chain-of-thought ("The customer is asking for their mortgage rate. This requires account-specific information, so I must verify their identity first..."). The `text.value` is the agent's customer-facing utterance for that turn.
- **Latency_Mask**: A short customer-facing utterance the agent speaks while a tool call or a slow inference is in flight ("Let me verify your information.", "One moment.", "..."). It lives in the inference span's `outputMessages[].values[].text.value` field. It is NOT the agent's reasoning — but the existing UI surfaces it on inference rows in a way that has been mistaken for reasoning.
- **Trace_Persistence**: The DynamoDB single-table TRACE-row write/read path in `src/backend/services/dynamodb.ts` (`writeExecutionTrace` / `getExecutionTrace`).
- **Timeline_Transcript**: The frontend component at `src/frontend/src/components/Transcript/TimelineTranscript.tsx` and its consumers (the per-case detail page and the run results expandable transcript).
- **Recommendation_Engine**: The Bedrock-backed analysis handler family. Encompasses the per-case path in `src/backend/handlers/analysis.ts` and the per-suite sibling in `src/backend/handlers/suite-recommend.ts`. Defined and reused from the `actionable-recommendations` spec.
- **Judge_Prompt_Renderer**: The shared utility at `src/shared/utils/judge-prompt-rendering.ts` that builds the `{context}`, `{assistant_turn}`, and `{tool_turn}` substitutions for the three Bedrock judge templates (`Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, `Builtin.ToolSelectionAccuracy`). Today's renderer omits same-turn tool calls from the per-assistant-turn Helpfulness `{context}`, which is the bug Requirement 14 corrects.
- **Failure_Analysis_Prompt**: The `failure_analysis` entry in the `Prompt_Registry` (`src/backend/orchestration/prompt-registry/prompts/failure-analysis.ts`) whose `defaultText` is the system instruction the `Recommendation_Engine` sends to Bedrock for per-case analysis.
- **Suite_Recommendation_Prompt**: The `suite_recommendation` entry in the `Prompt_Registry` whose `defaultText` is the system instruction sent to Bedrock for per-suite consolidation.
- **Prompt_Registry**: The closed-set, versioned prompt store at `src/backend/orchestration/prompt-registry/`. Adds and version bumps are persisted as overrides; in-place edits to `defaultText` would silently invalidate already-persisted recommendations.
- **Pre_Feature_Trace**: A TRACE row written before this feature deployed. Its `steps[]` JSON has no `durationMs`, no `reasoning`, and no `inferenceMetadata` field on any element.

## Requirements

### Requirement 1: Extract Reasoning From Inference Spans

**User Story:** As a tester debugging a failed case, I want the agent's actual chain-of-thought reasoning rendered in the timeline, so that I can tell whether the agent misunderstood the goal versus picked the wrong tool versus got tripped up by the system prompt.

#### Acceptance Criteria

1. WHEN the Span_Parser processes a Raw_Span whose `attributes.outputMessages[].values[]` contains exactly one entry with `reasoning.value` of type string with non-zero length, THE Span_Parser SHALL set the resulting Execution_Step's `reasoning` field to that string verbatim — preserving every whitespace character, newline, tab, and embedded punctuation, performing no truncation, no Unicode normalization, no escape replacement, and no length cap up to a 1 MiB upper bound — and SHALL surface the same string by strict equality (`===`) when the Execution_Step is read back from the Trace_Persistence layer.
2. WHEN a single inference span's `outputMessages[]` carries two or more `values[]` entries each with `reasoning.value` of type string and non-zero trimmed length, THE Span_Parser SHALL concatenate those values in array-encounter order separated by a single newline character (`"\n"`), skip any `reasoning.value` whose value is null, undefined, non-string, the empty string, or whitespace-only without emitting the separator for the skipped entry (so the concatenation never starts with, ends with, or contains adjacent duplicate separators), and assign the resulting string to the Execution_Step's `reasoning` field.
3. IF a Raw_Span's `outputMessages[].values[].reasoning.value` is absent, the empty string, whitespace-only, or of any non-string type (null, number, boolean, object, or array), THEN THE Span_Parser SHALL leave the Execution_Step's `reasoning` field strictly undefined (NOT set it to an empty string, NOT set it to null), and SHALL NOT throw an error or abort processing of the remaining spans.
4. WHEN a Raw_Span yields both a populated `text` value and a populated `reasoning` value on the same Execution_Step, THE Span_Parser SHALL populate both fields verbatim and independently, such that mutating either source value (in a hypothetical second invocation) only mutates the corresponding output field on the Execution_Step.
5. THE Platform SHALL extend the `RawSpanValue` interface in `src/backend/orchestration/span-parser.ts` to model `reasoning?: { value?: string }` alongside the existing `text`, `toolUse`, and `toolResult` fields, and SHALL NOT remove or rename any field that the interface already declares.
6. THE Platform SHALL extend the `ExecutionStep` interface in `src/shared/types.ts` to include `reasoning?: string` as an optional field, and SHALL NOT remove or rename any field that the interface already declares.
7. WHEN `parseSpansToTrace([span])` is invoked with a single inference span whose `outputMessages[].values[]` contains exactly one entry with `reasoning.value` of type string, THE Span_Parser SHALL produce a result for which `parseSpansToTrace([span]).steps[0].reasoning === span.attributes.outputMessages[i].values[j].reasoning.value` holds by strict equality, where the indexes `i, j` are those of the populated entry.

### Requirement 2: Compute Per-Step Wall-Clock Duration

**User Story:** As a tester triaging slow cases, I want every inference step and every tool call rendered with its wall-clock duration, so that I can see at a glance which step was the bottleneck without cross-referencing CloudWatch.

#### Acceptance Criteria

1. WHEN the Span_Parser processes a Raw_Span for which `Date.parse(startTimestamp)` and `Date.parse(endTimestamp)` both return finite, non-NaN numbers AND `Date.parse(endTimestamp) - Date.parse(startTimestamp) >= 0`, THE Span_Parser SHALL compute `durationMs = Date.parse(endTimestamp) - Date.parse(startTimestamp)` and assign the result, rounded to the nearest non-negative integer, to the resulting Execution_Step's `durationMs` field.
2. WHEN `Date.parse(startTimestamp)` and `Date.parse(endTimestamp)` both return finite, non-NaN numbers AND their difference is strictly less than zero, THE Span_Parser SHALL set the resulting Execution_Step's `durationMs` to 0 and SHALL emit exactly one console warning per affected span naming the span's `spanName`, `startTimestamp`, and `endTimestamp`.
3. IF a Raw_Span has `startTimestamp` absent (undefined, null, missing field, or empty string), has `endTimestamp` absent under the same definition, or has either field set to a value for which `Date.parse(value)` returns NaN, THEN THE Span_Parser SHALL leave the Execution_Step's `durationMs` field strictly undefined (NOT set it to 0, NOT set it to null) and SHALL NOT throw.
4. THE Platform SHALL extend the `ExecutionStep` interface in `src/shared/types.ts` to include `durationMs?: number` as an optional non-negative integer representing whole milliseconds.
5. WHEN the Span_Parser emits a synthetic `inference_tool_use` step (extracted from an inference span's `outputMessages.toolUse` per the existing dedup logic), THE Span_Parser SHALL set that synthetic step's `durationMs` to undefined; the synthetic step represents a RETURN_TO_CONTROL handoff with no observable execution duration.
6. WHEN the Span_Parser emits a synthetic `synthetic_control_tool` step (via the existing `augmentTraceWithControlTools` fallback path), THE Span_Parser SHALL set that synthetic step's `durationMs` to undefined.
7. WHEN both timestamps are present and `Date.parse` of each returns a finite, non-NaN number, THE Span_Parser SHALL produce a `durationMs` that is either (a) exactly equal to the rounded non-negative difference `Date.parse(endTimestamp) - Date.parse(startTimestamp)` for the non-negative-difference case, or (b) exactly 0 for the negative-difference case; in no case SHALL the emitted `durationMs` be a negative number.

### Requirement 3: Capture Inference Metadata

**User Story:** As a tester reviewing an inference step, I want to see how many tokens it consumed, which model produced it, what the time-to-first-token was, and which prompt version drove it, so that I can correlate cost, latency, and prompt-registry changes against agent behavior.

#### Acceptance Criteria

1. WHEN the Span_Parser processes a Raw_Span with `spanName === "inference"` AND at least one Inference_Metadata source field on `attributes` is present (not null, not undefined) and matches its expected type as defined in criterion 2, THE Span_Parser SHALL build an Inference_Metadata object on the resulting Execution_Step's `inferenceMetadata` field carrying every present, type-matching source field.
2. THE Inference_Metadata object SHALL include the following optional fields, each populated only when the corresponding `attributes.*` source is present (not null, not undefined) and matches the expected type: `usageInputTokens` (number), `usageOutputTokens` (number), `usageTotalTokens` (number), `requestModel` (string), `requestMaxTokens` (number), `temperature` (number), `timeToFirstTokenMs` (number), `responseFinishReasons` (array whose every element is a string), `promptArn` (string), `promptId` (string), `promptName` (string), `promptVersion` (number), `aiAgentVersion` (number), `systemInstructions` (string — built by filtering `attributes.systemInstructions[]` to entries whose `text.value` is a string, preserving original array order, and joining the survivor strings with the two-character separator `"\n\n"`; the field is omitted entirely when the filtered list is empty rather than set to the empty string).
3. IF none of the Inference_Metadata source fields enumerated in criterion 2 are present and type-matching on a Raw_Span with `spanName === "inference"`, THEN THE Span_Parser SHALL leave the Execution_Step's `inferenceMetadata` field strictly undefined (NOT set it to an empty object, NOT set it to null).
4. THE Span_Parser SHALL leave `inferenceMetadata` strictly undefined on every Execution_Step whose `type` is not `inference` (no `inferenceMetadata` on `tool`, `agent`, `other`, or any synthetic step type).
5. THE Platform SHALL extend the `ExecutionStep` interface in `src/shared/types.ts` to include `inferenceMetadata?: InferenceMetadata` as an optional field, and SHALL declare a new `InferenceMetadata` interface in the same `src/shared/types.ts` file carrying every field listed in criterion 2 with each field marked optional and typed exactly as criterion 2 specifies.
6. THE Span_Parser SHALL preserve each captured `systemInstructions` source string and the joined result byte-for-byte without truncation, escape replacement, Unicode normalization, case change, or whitespace trim, so that a downstream consumer can reproduce the exact prompt the model received on that turn.
7. IF a source field on `attributes` is present but does not match the expected type declared in criterion 2 (e.g. `usageInputTokens` is a string instead of a number, `responseFinishReasons` contains a non-string element), THEN THE Span_Parser SHALL omit that single field from the resulting Inference_Metadata object, SHALL NOT throw, and SHALL continue populating the remaining type-matching fields.

### Requirement 4: Persist The New Fields Without Breaking Old TRACE Rows

**User Story:** As a tester opening a case from a run that completed before this feature shipped, I want the timeline to render without errors, so that historical runs remain inspectable.

#### Acceptance Criteria

1. WHEN Trace_Persistence writes a TRACE row produced by the new Span_Parser, THE Trace_Persistence SHALL serialize the `steps[]` array to JSON exactly as today, with the new fields (`durationMs`, `reasoning`, `inferenceMetadata`) embedded inside each step object and absent on steps where they are undefined.
2. WHEN Trace_Persistence reads a Pre_Feature_Trace row (one whose persisted `steps[]` JSON contains no `durationMs`, no `reasoning`, no `inferenceMetadata` on any element), THE Trace_Persistence SHALL return an Execution_Trace whose steps[] elements are structurally identical to the persisted shape PLUS the three new fields each set to undefined, and SHALL NOT throw, log an error, or attempt a re-fetch.
3. WHEN Trace_Persistence reads a TRACE row written under this feature, the round-trip property SHALL hold: writing an Execution_Trace via `writeExecutionTrace` and reading it back via `getExecutionTrace` SHALL produce an Execution_Trace whose every step's `durationMs`, `reasoning`, and `inferenceMetadata` fields are deep-equal to the input (including absence on steps where the input had them undefined).
4. THE Trace_Persistence SHALL NOT change the existing top-level TRACE row attributes (`PK`, `SK`, `sessionId`, `aiAgentName`, `aiAgentType`, `toolSequence`, `steps`, `capturedAt`); the new fields live exclusively inside the JSON-serialized `steps` blob.
5. IF an Execution_Trace passed to `writeExecutionTrace` carries an `Inference_Metadata.systemInstructions` value larger than 350 KB after JSON serialization (the practical headroom under DynamoDB's 400 KB item limit), THEN THE Trace_Persistence SHALL truncate that field to 350 KB, append the literal suffix `"\n…[truncated]"`, and emit a single console warning naming the runId, caseId, and span index, so that an unusually large system prompt cannot prevent the TRACE row from being written.
6. IF the truncation step in 4.5 itself fails (e.g. the truncation routine throws), THEN THE Trace_Persistence SHALL NOT write the TRACE row, SHALL surface the failure to the caller, and SHALL NOT silently persist a row carrying the oversized value; the write is treated as a hard failure rather than a degraded success.

### Requirement 5: Render Reasoning As A Distinct Row In The Transcript

**User Story:** As a tester scanning the timeline, I want the agent's reasoning to be visually obvious as reasoning (not the customer-facing utterance and not a tool result), so that I can follow the agent's thought process turn by turn.

#### Acceptance Criteria

1. WHEN the Timeline_Transcript renders an Execution_Step of type `inference` whose `reasoning` field is a non-empty string, THE Timeline_Transcript SHALL render the reasoning text in a row visually differentiated from the existing inference row by both a distinct left-border color and a distinct row label reading `Reasoning`.
2. WHEN an Execution_Step of type `inference` carries both a `text` value and a `reasoning` value, THE Timeline_Transcript SHALL render two rows in the order reasoning-first then agent-reply, both anchored to the inference step's timestamp; the reasoning row SHALL always precede the agent-reply row in the rendered DOM regardless of which value Q in Connect emitted first within the span.
3. THE Timeline_Transcript SHALL preserve whitespace and newlines in the reasoning text by rendering it inside a CSS `white-space: pre-wrap` container (or the Cloudscape equivalent that does the same).
4. WHERE an Execution_Step of type `inference` has `reasoning` undefined, THE Timeline_Transcript SHALL NOT render a reasoning row for that step, and SHALL NOT render an empty-state placeholder; the row simply does not appear. WHERE an Execution_Step of type `inference` has `reasoning` defined but equal to the empty string, THE Timeline_Transcript SHALL render the reasoning row with a `(empty)` placeholder body so that the presence of an empty-string reasoning value is observable to the tester.
5. THE Timeline_Transcript SHALL update the existing inference row's label to read `Agent reply` (replacing the current `Inference` label) so that the customer-facing utterance is no longer mistaken for the agent's reasoning.

### Requirement 6: Render Per-Step Duration On Every Step

**User Story:** As a tester triaging a slow case, I want every step in the timeline to display its wall-clock duration, so that I can see which step was the bottleneck without leaving the page.

#### Acceptance Criteria

1. WHEN the Timeline_Transcript renders an Execution_Step whose `durationMs` is a defined non-negative integer in the closed range `[0, 86400000]` (0 ms through 24 hours inclusive), THE Timeline_Transcript SHALL display a duration label of the form `<integer value> ms` for values strictly less than 1000 (rendering 0 as exactly `0 ms`, with no decimal places and no leading zeros), and `<value with one decimal place, half-up rounding> s` for values greater than or equal to 1000 (e.g. `725 ms`, `1.6 s`, `3.8 s`; a `durationMs` of 1550 rounds to `1.6 s`, 1549 rounds to `1.5 s`).
2. THE Timeline_Transcript SHALL render the duration label in the row's existing key-label header strip alongside the existing `step <index>` and `<timestamp>` annotations, in the strict order `step <index> · <timestamp> · <duration label>`, separated by the existing `·` delimiter with one space on each side of each delimiter.
3. IF an Execution_Step has `durationMs` undefined, null, negative, non-numeric (e.g. a string), or strictly greater than 86,400,000, THEN THE Timeline_Transcript SHALL omit the duration label entirely (NOT render `— ms`, NOT render `unknown ms`, NOT render an empty placeholder), and SHALL NOT throw or fail to render the surrounding row.
4. THE Timeline_Transcript SHALL apply the duration-rendering rule from criterion 1 uniformly to inference steps, tool steps, and any other step type that carries a defined `durationMs` value, with no per-step-type formatting variation.
5. WHEN an Execution_Step of type `inference` carries an Inference_Metadata `timeToFirstTokenMs` value that is a defined non-negative integer in the closed range `[0, 600000]` (0 ms through 10 minutes inclusive), THE Timeline_Transcript SHALL display a secondary label of the form `ttft <integer value> ms` adjacent to the duration label on the same row, separated from the duration label by the existing `·` delimiter.
6. IF Inference_Metadata.timeToFirstTokenMs is undefined, null, negative, non-numeric, or strictly greater than 600,000, THEN THE Timeline_Transcript SHALL omit the ttft label entirely (NOT render a placeholder), and SHALL NOT throw or fail to render the surrounding row.

### Requirement 7: Render Inference Metadata As A Collapsed Detail Block

**User Story:** As a tester investigating model behavior, I want to see the model id, token usage, and prompt version that produced an inference step, so that I can correlate behavior with prompt-registry edits and Bedrock model changes.

#### Acceptance Criteria

1. WHEN the Timeline_Transcript renders an Execution_Step of type `inference` whose `inferenceMetadata` is defined, THE Timeline_Transcript SHALL render a collapsed-by-default disclosure (Cloudscape `ExpandableSection`) labeled `Inference details` directly underneath the step's main rows.
2. WHEN a user expands the `Inference details` disclosure, THE Timeline_Transcript SHALL render every Inference_Metadata field that is defined on the step, formatted as a key-value list whose values are taken verbatim from the per-step `Inference_Metadata` object captured by the Span_Parser (NOT from any hardcoded constant in the rendering layer). Field formatting follows the patterns below, with the per-step value substituted for the parenthesised sample text:
    - `Model: <inferenceMetadata.requestModel>` (sample: `Model: us.anthropic.claude-haiku-4-5-20251001-v1:0`; the actual rendered value depends on which model the AI Agent's prompt configuration resolved at inference time and MAY vary turn-by-turn within a single case)
    - `Tokens: <usageInputTokens> in / <usageOutputTokens> out / <usageTotalTokens> total` (sample: `Tokens: 5240 in / 131 out / 5371 total`)
    - `Finish reason: <responseFinishReasons[0]>` (sample: `Finish reason: end_turn`); when `responseFinishReasons` carries multiple entries the renderer SHALL join them with `", "`
    - `Prompt: <promptName> v<promptVersion> (<promptId>)` (sample: `Prompt: AnyBank v2 (197e301f-3217-48a8-8359-43bf16519f7b)`); when any of the three sub-fields is undefined, render only the defined sub-fields and omit the parenthesised id when `promptId` is undefined
    - `AI Agent version: <aiAgentVersion>` (sample: `AI Agent version: 14`)
    - `Temperature: <temperature>` (sample: `Temperature: 0`)
    - `Max tokens: <requestMaxTokens>` (sample: `Max tokens: 2048`)
    - `Time to first token: <timeToFirstTokenMs> ms` (sample: `Time to first token: 725 ms`)
3. WHERE Inference_Metadata is undefined on an inference step, THE Timeline_Transcript SHALL NOT render the disclosure at all (no empty disclosure).
4. WHEN Inference_Metadata.systemInstructions is defined, THE Timeline_Transcript SHALL render the system-instructions text inside a nested collapsed-by-default disclosure labeled `System prompt`, with whitespace and newlines preserved (`white-space: pre-wrap`).
5. THE Timeline_Transcript SHALL render the `Inference details` disclosure on every consumer of the component (the per-case detail page and the run results expandable transcript), so the two surfaces stay in sync.

### Requirement 8: Label The Latency Mask Distinctly From Reasoning

**User Story:** As a tester reading the timeline, I want short customer-facing fillers like "Let me verify your information." to be visually distinguishable from the agent's reasoning, so that I do not confuse a latency mask for chain-of-thought.

#### Acceptance Criteria

1. WHERE an Execution_Step of type `inference` carries a `text` value but no `reasoning` value, THE Timeline_Transcript SHALL render the row with the label `Agent reply` and SHALL NOT add any "reasoning" annotation.
2. WHERE an Execution_Step of type `inference` carries a `text` value AND a `reasoning` value, THE Timeline_Transcript SHALL render the `Agent reply` row in the existing inference row visual style (light blue background) and the `Reasoning` row in a visually distinct style (e.g. lavender background with a left border colored differently from the agent reply row). IF the distinct visual styling cannot be applied (e.g. a downstream theme override strips the custom background), THEN THE Timeline_Transcript SHALL still render the reasoning content; visual distinction is a best-effort presentation property, never a gate on whether the content appears.
3. THE Timeline_Transcript SHALL NOT alter the rule by which the conversation driver decides whether a turn is a latency mask versus a substantive reply (that filtering lives in `conversation-driver.ts` and is out of scope).
4. THE Timeline_Transcript SHALL render the reasoning row with a label that includes the agent name when present (`Reasoning · AnyBank`), matching the existing inference row's pattern.

### Requirement 9: Plumb Reasoning Into The Per-Case Failure Analysis Prompt

**User Story:** As a platform owner running failure analysis, I want the Bedrock prompt to include the agent's actual reasoning for every inference step in the failed trace, so that recommendations are grounded in why the agent failed (not just what the agent said and which tool it called).

#### Acceptance Criteria

1. WHEN the Recommendation_Engine builds the Failure_Analysis_Prompt for a case whose Execution_Trace contains at least one Execution_Step with a non-empty `reasoning` value, THE Recommendation_Engine SHALL include a `## Reasoning trace` section in the rendered user message that enumerates each inference step's reasoning text in chronological order, prefixed by the step's index and timestamp.
2. WHEN the Recommendation_Engine builds the Failure_Analysis_Prompt for a case whose Execution_Trace contains no Execution_Step with a `reasoning` value (a Pre_Feature_Trace or a trace where Q in Connect did not surface any reasoning), THE Recommendation_Engine SHALL render the user message byte-for-byte identical to the message rendered by the prior version of `buildAnalysisPrompt` for the same input, so that already-persisted `ANALYSIS#CASE#{caseId}` records produced from such traces remain reproducible.
3. THE Recommendation_Engine SHALL render the reasoning section using the same byte-stable formatting rules across runs (deterministic separator, no trailing whitespace divergence) so that two invocations on the same trace produce byte-identical prompts.
4. THE Recommendation_Engine SHALL preserve each reasoning string verbatim in the rendered prompt, including whitespace, newlines, and embedded punctuation; no truncation or normalization.
5. THE Recommendation_Engine SHALL register the new Failure_Analysis_Prompt rendering as a versioned `defaultText` change in the Prompt_Registry for the `failure_analysis` entry, with the new `defaultText` reflecting the reasoning-trace section that the user message will now interpolate. The registry entry SHALL be a forward version, not an in-place edit; persisted overrides keyed against the prior version SHALL continue to resolve to the prior text. The new version SHALL be the resolved version for every analysis call after this feature deploys, including calls on traces that carry no reasoning, so that the persisted `failureAnalysisPromptVersion` field is uniformly populated and the registry's version monotonicity invariant is preserved.
6. WHEN persistence-on-success writes a per-case analysis record at `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}`, THE Recommendation_Engine SHALL store the resolved `failure_analysis` prompt version on the persisted record so that subsequent reads can tell which prompt produced the recommendation.

### Requirement 10: Plumb Reasoning Into The Per-Suite Recommendation Prompt

**User Story:** As a platform owner running the per-suite consolidation, I want the Bedrock prompt to include the agent's actual reasoning across every failed case in the run, so that consolidated recommendations are grounded in the reasoning patterns shared across failures.

#### Acceptance Criteria

1. WHEN the Recommendation_Engine builds the Suite_Recommendation_Prompt for a run, THE Recommendation_Engine SHALL include each failed case's reasoning trace (the same chronologically-ordered enumeration described in Requirement 9.1) inside the per-case section of the suite prompt, when at least one step in that case carries a non-empty `reasoning` value.
2. WHEN the Recommendation_Engine builds the Suite_Recommendation_Prompt for a run in which no failed case carries any non-empty `reasoning` value on any Execution_Step (regardless of whether the underlying TRACE row predates this feature), THE Recommendation_Engine SHALL render the suite prompt byte-for-byte identical to the prompt produced by the prior version of the suite handler.
3. THE Recommendation_Engine SHALL register the new Suite_Recommendation_Prompt rendering as a versioned `defaultText` change in the Prompt_Registry for the `suite_recommendation` entry, with the same versioning semantics as Requirement 9.5.
4. WHEN persistence-on-success writes the per-suite analysis record at `PK=RUN#{runId}, SK=ANALYSIS#SUITE`, THE Recommendation_Engine SHALL store the resolved `suite_recommendation` prompt version on the persisted record.

### Requirement 11: Migration Policy For Pre-Feature Traces

**User Story:** As a tester opening an old run, I want the platform to either show me the new fields if Q in Connect can still produce them, or tell me clearly when they are unavailable, so that I am not silently looking at incomplete data.

#### Acceptance Criteria

1. THE Platform SHALL accept that Pre_Feature_Trace rows render in the Timeline_Transcript without `durationMs`, `reasoning`, or `inferenceMetadata` shown — the empty states defined in Requirements 5.4, 6.3, and 7.3 are the contract for those rows.
2. WHEN a user opens the per-case detail page for a Pre_Feature_Trace AND the case carries a `sessionId` AND the run's `startTime` is less than the Q in Connect session-data retention window (TODO.md flags this window as not yet empirically known — Requirement 11.7 below resolves the window value), THE Platform SHALL attempt a best-effort lazy re-fetch by calling ListSpans for the recorded `sessionId`, re-parsing through the new Span_Parser, and overwriting the persisted TRACE row with the result.
3. WHEN the lazy re-fetch in 11.2 succeeds AND the re-parsed Execution_Trace is structurally deep-equal to the persisted Pre_Feature_Trace (i.e. Q in Connect did not surface any reasoning, durationMs, or inferenceMetadata for that session — re-fetch yielded the same data already on disk), THE Platform SHALL leave the persisted TRACE row unchanged and SHALL NOT issue an overwrite write to DynamoDB; this avoids unnecessary table writes and preserves the original `capturedAt` timestamp.
4. WHEN the lazy re-fetch in 11.2 succeeds with new data AND the subsequent overwrite write to DynamoDB fails (transient throttling, conditional-write failure, or other DDB error), THE Platform SHALL retry the overwrite once with exponential backoff; IF the retry also fails, THEN THE Platform SHALL surface a non-blocking inline notice on the per-case detail page reading `Could not save refreshed reasoning data for this case.` AND SHALL render the timeline using the freshly re-parsed in-memory trace for the current page view, so that the user still sees the new fields even when persistence could not be updated.
5. IF the lazy re-fetch in 11.2 returns zero spans (the session has aged out of Q in Connect's retention window) OR returns an error, THEN THE Platform SHALL leave the persisted TRACE row unchanged and SHALL render the timeline with the existing pre-feature data; the failure SHALL be logged AND SHALL NOT surface as an error to the user. IF the logging call itself throws or otherwise fails, THEN THE Platform SHALL surface a non-blocking inline notice on the per-case detail page reading `Could not refresh reasoning data for this case.`, so that the user is informed when even the diagnostic record could not be written.
6. THE Platform SHALL NOT perform a one-shot bulk backfill against historical runs at deploy time; lazy on-demand re-fetch (per 11.2) is the only re-fetch path.
7. THE Platform SHALL configure the lazy-re-fetch retention threshold via a single environment variable `LISTSPANS_RETENTION_DAYS` on the per-case detail handler, with a default value of 7. THE handler SHALL skip the re-fetch attempt when `(now - run.startTime) > LISTSPANS_RETENTION_DAYS * 24 * 60 * 60 * 1000`. The empirical retention window MAY be tuned over time without requiring a code change.

### Requirement 12: Backward Compatibility Of Persisted Recommendations

**User Story:** As a platform operator, I want already-persisted `ANALYSIS#CASE#{caseId}` and `ANALYSIS#SUITE` records to remain valid after this feature deploys, so that historical recommendations are not silently invalidated.

#### Acceptance Criteria

1. WHEN the Recommendation_Engine reads a persisted `ANALYSIS#CASE#{caseId}` record written before this feature deployed (a record carrying no `failure_analysis` prompt version field), THE Recommendation_Engine SHALL return the record unchanged in the response and SHALL NOT silently regenerate it.
2. WHEN the Recommendation_Engine reads a persisted `ANALYSIS#SUITE` record written before this feature deployed (a record carrying no `suite_recommendation` prompt version field), THE Recommendation_Engine SHALL return the record unchanged and SHALL NOT silently regenerate it.
3. THE Recommendation_Engine SHALL NOT change the persisted `Recommendation` shape (`targetField`, `targetName`, `currentText`, `suggestedText`, `rationale`) defined by the `actionable-recommendations` spec; the only addition is the optional `failureAnalysisPromptVersion` / `suiteRecommendationPromptVersion` field on the wrapping persisted record.
4. WHEN a client invokes the analysis endpoint with `force: true` on a run whose persisted records predate this feature, THE Recommendation_Engine SHALL regenerate using the new prompt rendering (Requirements 9 and 10) and SHALL overwrite the persisted records with the new rendering; the per-case `ANALYSIS#CASE#{caseId}` records SHALL gain only the `failureAnalysisPromptVersion` field, and the per-suite `ANALYSIS#SUITE` record SHALL gain only the `suiteRecommendationPromptVersion` field. Neither record type SHALL gain the other type's prompt-version field.

### Requirement 13: Out Of Scope Non-Goals

**User Story:** As a reviewer reading this requirements document, I want the explicit non-goals captured, so that I know which adjacent surfaces this feature deliberately does not touch.

#### Acceptance Criteria

1. THE Platform SHALL NOT modify the conversation driver's polling logic, latency-mask filtering, or `MAX_TURNS` / `QUIET_THRESHOLD` heuristics in `src/backend/orchestration/conversation-driver.ts`; those concerns belong to the connect-agent-test-platform spec.
2. THE Platform SHALL NOT capture reasoning from non-Q-in-Connect agents (e.g. AgentCore Runtime traces); that scope belongs to the platform-hosting-and-evaluations spec.
3. THE Platform SHALL NOT add reasoning content to the `Builtin.GoalSuccessRate`, `Builtin.Helpfulness`, or `Builtin.ToolSelectionAccuracy` judge prompts in this spec. The platform owner pushed back on this addition citing LLM-judge sycophancy risk: a judge that sees the agent's self-narrated rationale would shift from grading "was the right tool called / was this helpful" to grading "was the agent's stated reason coherent" — a different and easier question. Reasoning belongs to the failure-analysis path (Requirements 9 and 10), where the post-failure diagnostic is reviewed by a human before any change ships, not to the per-turn / per-tool / per-session pass-fail judges. A future spec MAY revisit this with an opt-in experimental flag and judge-human-agreement measurement, but THIS spec SHALL NOT make the change.
4. THE Platform SHALL NOT add a UI surface for editing the `failure_analysis` or `suite_recommendation` prompt overrides in this spec; the prompt-management spec already owns that capability and the new prompt versions registered here SHALL be reachable through the existing prompt-management UI without changes.

### Requirement 14: Surface Same-Turn Tool Calls To The Helpfulness Judge

**User Story:** As a tester reviewing a Helpfulness score, I want the judge to see the tool calls the agent made in the same turn as the customer-facing reply being graded, so that the judge does not penalise the agent for a promise the agent actually fulfilled (e.g. "Let me transfer you" followed by an `Escalate` tool call) just because the tool call lived "after" the reply in the rendered context.

#### Acceptance Criteria

1. WHEN the Recommendation_Engine renderer at `src/shared/utils/judge-prompt-rendering.ts` builds the per-assistant-turn `{context}` substitution for one Helpfulness evaluator unit, THE renderer SHALL include the `Action:` and `Tool:` lines for every tool call recorded on that same `ConversationTurn` as the assistant text being graded, in the chronological order the trace recorded them, immediately after the `Assistant:` line for that turn AND before the `(beginning of conversation)` sentinel substitution rule applies.
2. THE renderer SHALL preserve the existing `Action:` / `Tool:` line shape produced by `renderToolCallLines` byte-for-byte; the new behavior is purely an inclusion rule on the per-turn context, NOT a re-formatting of the lines themselves.
3. THE renderer SHALL apply the inclusion in criterion 1 ONLY to the Helpfulness evaluator unit's `{context}` (built today by `renderContextBefore` plus the current turn's `User:` line). The renderer SHALL NOT change the `{context}` rendered for `Builtin.GoalSuccessRate` (already includes the full conversation including all tool calls) or for `Builtin.ToolSelectionAccuracy` (which uses a strictly-prefix context that excludes the tool call being graded — including same-turn tool calls there would leak the answer into the question and SHALL NOT be done).
4. THE renderer SHALL preserve the existing rule that an inference step with no recoverable text yields no Helpfulness Converse call (the empty `{assistant_turn}` skip rule). Same-turn tool calls SHALL NOT be promoted into a standalone Helpfulness unit just because they exist; tool-call-only turns continue to be skipped by the Helpfulness pipeline.
5. THE renderer SHALL register the change as a versioned `defaultText` change in the Prompt_Registry for the `judge_helpfulness` entry IF AND ONLY IF the change to the `{context}` rendering produces a byte-different prompt for the same trace; if the rendering rule produces byte-identical prompts on every existing fixture (i.e. no run in the test corpus had same-turn tool calls), the registry version SHALL NOT be bumped. The test fixtures the platform SHALL re-render against, before deciding whether to bump, are every fixture under `tests/fixtures/spans/` plus the verified-evidence fixture at `tmp/spans-mortgage-rate.json`.
6. WHEN the rendering change requires a Prompt_Registry version bump per criterion 5, THE Recommendation_Engine SHALL apply the same forward-versioning semantics defined in Requirement 9.5 (the registry entry SHALL be a forward version, not an in-place edit; persisted overrides keyed against the prior version SHALL continue to resolve to the prior text; the new version SHALL be the resolved version for every Helpfulness call after this feature deploys).
7. THE Platform SHALL preserve every persisted `TestCaseResult.evaluationDetails` record produced before this feature deploys; the new context-rendering rule SHALL NOT cause re-grading of historical runs unless the user explicitly invokes the Bedrock judge against a re-fetched run.
8. FOR ANY trace whose Helpfulness `{context}` rendered under the prior renderer was non-empty AND whose new `{context}` differs from the prior, the difference SHALL be exactly the addition of the `Action:` and `Tool:` lines for same-turn tool calls; no other text additions, deletions, or reorderings SHALL occur. This is the byte-stability invariant for Requirement 14 and it complements Requirement 9.3.
