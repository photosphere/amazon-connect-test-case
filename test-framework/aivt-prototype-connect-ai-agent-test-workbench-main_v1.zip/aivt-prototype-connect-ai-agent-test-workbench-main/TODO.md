# Connect Agent Test Platform — TODO / Follow-ups

Running list of known gaps, findings, and planned work. Updated as we go.

---

## 1. Frontend not deployed (CloudFront returns NoSuchKey)

**Symptom:** The CloudFront URL (`https://d353l70t9ml83.cloudfront.net`) returns
`<Error><Code>NoSuchKey</Code>...<Key>index.html</Key>` instead of a login page.

**Root cause:** `lib/storage-construct.ts` provisions the S3 bucket + CloudFront
distribution but **never uploads the frontend build** into the bucket. There is no
`BucketDeployment`, so the bucket is empty and CloudFront can't find `index.html`.

**What's needed to fix:**
1. Build the frontend (Vite): `npm install && npm run build` in `src/frontend/`
   (output dir is `src/frontend/dist`).
2. Add an `s3deploy.BucketDeployment` to the stack that uploads `src/frontend/dist`
   to the frontend bucket and invalidates the CloudFront distribution
   (`distributionPaths: ['/*']`).
3. **Runtime config injection:** the app loads `/config.json` at startup
   (`src/frontend/src/api/config.ts`). The deploy must write a `config.json` into the
   bucket with these exact fields:
   ```json
   {
     "apiEndpoint": "https://c0vqju093c.execute-api.us-east-1.amazonaws.com/prod",
     "cognitoUserPoolId": "us-east-1_QcpKIpn9F",
     "cognitoClientId": "6c6jfb3rggkmr9fq9lsfh1hbte",
     "cognitoDomain": "connectagenttestplatformstack-104220062740.auth.us-east-1.amazoncognito.com",
     "region": "us-east-1"
   }
   ```
   Note: `cognitoClientId` here must be the **web/user-pool client** (`AuthUserPoolClientId`,
   `6c6jfb3rggkmr9fq9lsfh1hbte`), NOT the M2M machine client. The config can be generated
   from stack outputs and deployed via a second `BucketDeployment` using
   `s3deploy.Source.jsonData('config.json', {...})`.
4. **CloudFront SPA fallback already exists** (403/404 → /index.html), so client-side
   routing should work once assets are present.
5. Add callback URLs: the Cognito hosted-UI redirect must include the CloudFront URL.
   Currently `callbackUrls` defaults to `['http://localhost:5173']` — the deployed
   CloudFront origin needs to be added (and the frontend's `VITE_COGNITO_REDIRECT_URI` /
   `window.location.origin` must match a registered callback URL).

**Validation after fix:** load the CloudFront URL, confirm the Cloudscape UI renders,
the hosted-UI login round-trips, and the app can list agents/suites/runs through the API.

---

## 2. First user creation on deploy (open question)

**Idea:** prompt for an admin email at deploy time and auto-create the first Cognito
user for the web interface (so there's a usable login without manual console steps).

**Approach to evaluate:**
- Add a CDK context param / stack prop `adminEmail`.
- Create a `Cognito UserPoolUser` (or a custom resource calling `AdminCreateUser`) in the
  user pool, which emails a temporary password via the hosted UI.
- Decide whether to gate on presence of the param (skip if not provided) so CI deploys
  don't fail.
- Confirm the user pool is configured for email as username/alias and that hosted-UI
  sign-in works with the temp-password → force-change flow.

**Decision needed:** is auto-creating a user the right UX, or do we prefer a documented
post-deploy `aws cognito-idp admin-create-user` one-liner? Lower blast radius, but less
turnkey for demos.

---

## 3. Real AgentCore Evaluations integration (option b)

**Current state:** `src/backend/orchestration/evaluation.ts` is a **stub**.
`callAgentCoreEvaluation()` throws `"AgentCore evaluation not yet integrated"`, so every
case falls back to local scoring. Result: no `goalSuccessScore` / `helpfulnessScore`,
only a local `toolAccuracyScore`. IAM already grants `bedrock-agent-runtime:*` to the
Evaluation Lambda, so permissions are largely in place.

**Goal:** wire the real AgentCore Evaluations API so runs produce managed scores.

**Reference:** https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/evaluators.html
- Built-in evaluators are referenced as `Builtin.EvaluatorName` (e.g. `Builtin.Helpfulness`).
  Built-in configs (model + prompt template) are **not** modifiable.
- Built-in capabilities cover end-to-end **goal attainment (task completion)** and
  **tool-call accuracy**, plus helpfulness.
- **Custom evaluators** (two kinds):
  - *LLM-as-a-judge* — your own model + instructions + scoring schema.
  - *Code-based* — your own Lambda for deterministic checks (regex, business rules).
    This is a natural fit for our ordered tool-subsequence accuracy metric.
- Works for agents hosted outside AgentCore Runtime (our case) and consumes traces.
  We already capture spans via ListSpans — investigate whether AgentCore can ingest
  our session traces directly or whether we submit a formatted transcript.

**Work items:**
- Confirm the exact API/SDK surface (AgentCore CLI / Python SDK / AWS SDK) and which
  `@aws-sdk` client (if any) exposes Evaluations; pin + bundle it like we did for qconnect.
- Replace the stub `callAgentCoreEvaluation()` with the real call (`Builtin.GoalSuccessRate`,
  `Builtin.Helpfulness`, custom tool-accuracy).
- Keep the local fallback path for when AgentCore is unavailable.
- Map returned scores into `goalSuccessScore` / `helpfulnessScore` / `toolAccuracyScore`
  on `TestCaseResult`.
- Decide region/cross-region inference for the evaluator models.

---

## 4. (DONE) Tool-sequence capture from ListSpans + structured execution trace

**Finding:** `conversationSessionData["Tool"]` only reports RETURN_TO_CONTROL tools
(Complete, Escalate). MODEL_CONTEXT_PROTOCOL (MCP) tools (verifyIdentity, getAccounts,
getLoanDetails) are **only** visible as `execute_tool` spans in ListSpans. So the original
session-data-based detection scored tool accuracy = 0 even on perfect runs.

**Fix (shipped & validated in prod):**
- `src/backend/orchestration/span-parser.ts` — pure `parseSpansToTrace()` builds a
  structured `ExecutionTrace` (ordered reasoning + tool calls w/ args, results,
  success/error) and the authoritative `toolSequence` from `execute_tool` spans.
- `conversation-driver.ts` — `fetchExecutionTrace()` pulls spans at conversation end;
  `mergeToolSequences()` merges span tools (authoritative) with control tools. All return
  paths finalize `toolsInvoked` from spans. Driver now returns `executionTrace` + `sessionId`.
- `record-transcript.ts` + `dynamodb.ts` — persist the structured trace (SK="TRACE").
- `analysis.ts` — consumes the new `ExecutionTrace` shape (tool args/results + reasoning)
  for failure analysis.
- Removed the dead `FetchReasoningTrace` Lambda + state-machine step (was a no-op —
  missing sessionId — since deploy; driver now supersedes it).
- **Verified in prod:** stored result shows
  `["verifyIdentity","getAccounts","getLoanDetails","Complete"]`, toolAccuracyScore = 1,
  and the TRACE item holds the full 14-step turn-by-turn trace.

---

## 5. Cleanup (do whenever)

Local investigation helpers created during debugging — safe to delete once no longer needed:
- `trace.mjs` — ListSpans dumper (handy; consider keeping as a debug tool).
- `probe.mjs`, `probe2.mjs`, `probe3.mjs`, `probe4.mjs` — routing / contact-binding probes.
- `prompt.mjs` — dumps the AnyBank system prompt + tool configs.
- `scratch/dummy-flow.json` — early contact-flow experiment (the real flow is now in
  `lib/contact-creator-flow.ts`).

---

## 6. Contact Lens transcript on the CTR (deferred)

We now mint real contacts, so the transcript-on-CTR idea is more viable than before.
Currently the minimal contact-creator flow does NOT enable Contact Lens. If we want test
transcripts visible in Connect:
- Add the analytics action to the flow (Contact Lens for Chat).
- Empirically verify whether transcripts from the **Q in Connect session API path**
  (SendMessage/GetNextMessage) actually land on the contact's CTR — not guaranteed, since
  our conversation doesn't flow through the chat participant connection. Validate before
  promising.

---

## 7. Production Traffic Analysis — Agent Quality from Real Contacts (future feature)

**Vision:** Deploy the platform in `production` mode against a live Connect instance, analyze real customer-agent conversations, and export improvement recommendations that can be imported into a `development` instance for implementation.

**What it does:**
- Queries Amazon Connect SearchContacts API or CTR event stream for contacts that involved self-service interactions with the orchestration agent.
- For each qualifying contact, calls `ListSpans` on the Q in Connect session to retrieve the full execution trace (tool calls, reasoning, agent responses).
- Runs the same Bedrock judge evaluation pipeline (Goal Success, Helpfulness, Tool Selection Accuracy) against real conversations — scoring live agent quality without needing synthetic test cases.
- Surfaces a "Production Insights" dashboard showing aggregate quality metrics, failure patterns, and per-conversation drill-downs.
- Generates the same actionable recommendations (current text → suggested text) based on patterns found in production failures.

**The export/import bridge between prod and dev stacks:**
- In production mode: an "Export Analysis" button produces a portable JSON package containing the recommendations, scored conversations (redacted of PII), failure patterns, and suggested test cases.
- In development mode: an "Import Production Analysis" feature ingests the exported package, creates test cases that reproduce the production failures, and makes the recommendations available for Direct_Apply or Multi-Variant Experiment.
- This closes the full loop: prod traffic → quality analysis → export → import into dev → implement changes → re-test → deploy to prod → monitor.

**Key design considerations:**
- **PII handling:** Production conversations contain customer data. The export must redact or generalize PII (names, account numbers, phone numbers) before the package leaves the production stack. The Bedrock judge sees the full transcript (same as Contact Lens) but persisted/exported summaries use redacted versions.
- **Sampling strategy:** Production instances may handle thousands of contacts daily. The platform should support: random sampling (N contacts per day/week), failure-focused sampling (contacts that ended in escalation or customer dissatisfaction), and agent-filtered sampling (only contacts routed to a specific orchestration agent).
- **No ground truth:** Unlike test suites with `successCriteria` or `groundTruthAnswer`, production contacts don't have a known-good answer. The judge evaluates on general quality rubrics (helpfulness, groundedness, tool selection) and detects patterns across conversations rather than asserting per-case correctness.
- **Continuous vs on-demand:** Could be event-driven (analyze each contact as it completes via EventBridge) or batch (analyze the last N contacts on demand). Event-driven gives real-time quality dashboards; batch is simpler to implement first.
- **Q in Connect session access window:** ListSpans data may have a retention window. Need to validate how long session data persists after the contact ends — if it's short (24-48h), the analysis must run soon after the contact.

**Suggested phasing:**
1. On-demand batch analysis: user clicks "Analyze recent contacts," platform queries last N contacts and scores them.
2. Scheduled batch: CloudWatch Events triggers daily analysis of the previous day's contacts.
3. Export/import: portable analysis packages between prod and dev stacks.
4. Event-driven: real-time quality scoring as contacts complete.
5. Auto-generated test cases: production failure patterns → synthetic test cases added to regression suites.

**Dependencies:** Requires the `INSTANCE_MODE` flag from the implement-recommendations spec (R19) so that production stacks are read-only for agent writes. The export format needs to be designed as a stable contract between prod and dev stacks.

---

## 8. Agent Config Export — JSON + CloudFormation for Dev-to-Prod Promotion (future feature)

**Vision:** After tuning an agent in a development instance (via implement-recommendations, multi-variant experiments, or manual iteration), export the full agent configuration as a portable artifact that can be deployed to a production account deterministically — no manual console work.

**Two export formats:**

### Format A: JSON Config File (human-readable, version-controllable)
- Captures the complete logical configuration: system prompt text, each tool's description/instruction/examples, model ID, Knowledge Base binding identifiers, agent name, agent type.
- Importable by another platform instance via a future "Import Agent Config" endpoint.
- Useful for: git-based version control of agent configs, diffing dev vs prod, review workflows (PR for agent config changes), audit trail.
- Does NOT include infrastructure — just the agent's logical state.

### Format B: CloudFormation Template (deployable cross-account)
- Generates a parameterized CF template containing:
  - `AWS::QConnect::AIAgent` resource (or equivalent custom resource wrapping the Q in Connect management APIs if native CF support is incomplete)
  - `AWS::QConnect::AIPrompt` resource for the system prompt with the tuned text
  - Connect Security Profile resource granting the MCP tool permissions the agent depends on (so the agent can invoke its tools in the target account without manual security profile configuration)
  - Parameters: `AssistantId`, `ConnectInstanceId`, `SecurityProfileName` (so the template is reusable across accounts without editing)
  - Outputs: agent ID, prompt ID, security profile ARN (for downstream wiring)
- Useful for: CI/CD pipelines, cross-account deployments, reproducible infrastructure, change management workflows.

**The Security Profile problem:**
- Q in Connect orchestration agents need their MCP tools registered in a Connect security profile for invocation permissions.
- If you tune an agent in dev to use 5 tools, but deploy to a prod account whose security profile only grants 3, the agent will escalate on the missing 2.
- The export MUST capture the tool dependency set and the CF template MUST include the security profile resource (or at minimum emit a validation warning listing required tool permissions).

**UI entry point:**
- "Export Agent Config" button on the agent detail page, or on the Run Dashboard after a successful tuned run.
- Options: "Export as JSON" (downloads a `.json` file) and "Export as CloudFormation" (downloads a `.yaml` template).
- Both formats include metadata: which run produced this config, what score it achieved, when it was exported.

**Import flow (future):**
- In a production platform instance (INSTANCE_MODE=production): "Import Agent Config" button accepts either format.
- JSON format: updates the existing agent via UpdateAIAgent/UpdateAIPrompt (same as Direct_Apply but sourced from a file rather than recommendations).
- CF format: user deploys via `aws cloudformation deploy` or through their CI pipeline.

**Key design considerations:**
- The export captures the agent state at a specific point in time (like a snapshot). It should reference the run ID and scores that validated this config so the operator has confidence in what they're deploying.
- CF template generation needs to handle the Q in Connect API's idiosyncrasies (version qualifiers, ARN formats, the wisdom/qconnect dual-namespace).
- Security profile export needs to enumerate the tools from the agent config and map them to the Connect security profile permission format.
- Consider generating a CDK construct in addition to raw CF — many teams using this platform are already CDK users (the platform itself is CDK).

**Suggested phasing:**
1. JSON export (simplest, immediate value for version control and review workflows)
2. JSON import in dev instances (allows dev→prod via file transfer + import)
3. CF template export (for teams with CF-based deployment pipelines)
4. CDK construct export (for teams already using CDK)
5. Security profile export/validation (ensures tool permissions transfer correctly)

---

## 9. System Prompt Optimizer — Reduce Bloat and Latency (future feature)

**Vision:** Many customers accumulate examples and repetitive instructions in their system prompts over time, leading to bloated prompts that add latency (more tokens = longer time-to-first-token) without proportional quality improvement. A prompt optimizer would analyze the current system prompt, identify redundancy and examples that belong in `tool_examples` rather than the prompt body, and produce a compressed version that maintains or improves quality while reducing token count.

**What it does:**
- Analyzes the system prompt structure: identifies thinking/messaging blocks (immutable), dynamic parameters (must stay at end), custom instructions, and inline examples.
- Identifies optimization opportunities: redundant instructions, examples that could move to `tool_examples`, verbose phrasing that can be tightened, dead instructions for tools that no longer exist.
- Generates an optimized prompt that preserves semantics while reducing token count.
- Validates the optimization: runs the test suite against both the original and optimized prompt, compares scores.
- Reports: token count reduction, latency improvement (estimated from token delta), quality delta.

**Connection to existing features:**
- Uses the Multi-Variant Experiment infrastructure to test the optimized prompt vs the original.
- Respects the same system prompt safety rules (R20): dynamic parameters at end, thinking/messaging blocks immutable.
- Could integrate with the existing prompt optimizer from the separate project as a backend service.

**Key insight:** This is a "refactoring" operation rather than a "feature improvement" operation. The goal is to produce the same behavior with fewer tokens, not to change what the agent does. The test suite acts as the regression gate: if the optimized prompt produces the same scores, it's a safe optimization.

**Entry point:** "Optimize Prompt" button on the agent detail page, next to "Export Agent Config." Shows a before/after token count and a confidence score before the user commits.

- API: `https://c0vqju093c.execute-api.us-east-1.amazonaws.com/prod/`
- CloudFront: `https://d353l70t9ml83.cloudfront.net`
- Assistant: `5664eea5-381d-468e-bfba-302b69ae6dec`
- AnyBank ORCHESTRATION agent: `d54d3dee-b9ec-415a-9a4b-b4769426f365`
- Contact-creator flow: `fdddd12a-8f20-4599-a548-e6a92941991c`
- Test suite: `8973008350767692fdc59f30` (case `39135557386361de1f6f2f4c`)
- Deploy: `rm -rf cdk.out && AWS_DEFAULT_REGION=us-east-1 npx cdk deploy -c connectInstanceId=46837cc7-8562-4b3f-92b2-1bae0ede624b --require-approval never`


---

## AgentCore Evaluate → Bedrock-judge pivot (validated)

**Finding (June 2026):** The `platform-hosting-and-evaluations` spec assumed AgentCore Evaluate (`bedrock-agentcore:Evaluate`) as the scoring backend. That assumption is wrong for this platform's use case.

- AgentCore Evaluate's `sessionSpans` input is the post-CloudWatch-ingestion log format produced by AgentCore Runtime + ADOT, NOT raw OTLP/JSON we can hand-craft from Q in Connect data. 9 live probes confirmed every hand-crafted variant fails with `LogEventMissingException`.
- Reading the `bedrock-agentcore-starter-toolkit` source confirmed the toolkit fetches spans from `aws/spans` CloudWatch log group and submits the raw `@message` text verbatim to Evaluate.
- Transaction Search is OFF in this account (X-Ray destination, not CloudWatch). Even with an AgentCore Runtime agent, the ingestion pipeline would be off.

**Resolution:** AWS publishes the exact prompt templates the built-in evaluators use at <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/prompt-templates-builtin.html>. Calling `bedrock:Converse` directly with those templates produces equivalent scoring. End-to-end validated by `scripts/bedrock-judge-probe.ts` against both checked-in `Span_Fixtures`:

| Fixture | goalSuccessScore | helpfulnessScore | toolAccuracyScore |
|---|---|---|---|
| `multi-tool-success` | 1.0000 | 0.7500 | 0.5000 |
| `failure-escalation` | 0.0000 | 0.6667 | 0.3333 |

**Spec**: `.kiro/specs/bedrock-judge-evaluations/` (design-first, high-level design committed). When the spec ships:

1. `platform-hosting-and-evaluations` Workstream 1 (Tasks 1–9, hosting/bootstrap) stays as-is.
2. `platform-hosting-and-evaluations` Workstream 2 (Tasks 10–21) is superseded.
3. `scripts/agentcore-shape-probe.ts` and `scripts/strands-tracer-probe.py` can be deleted (kept for now as referenced evidence in the design doc).

**Diagnostic artifacts produced (kept for evidence):**
- `scripts/bedrock-judge-probe.ts` — working reference implementation, becomes the production code paths.
- `scripts/agentcore-shape-probe.ts` — 9 hand-crafted variants, all rejected by AgentCore Evaluate.
- `scripts/strands-tracer-probe.py` — captured the actual Strands tracer output shape for comparison.


---

## 10. YAML Test Data Import + Auto-Generated Test Coverage (future feature)

**Vision:** Remove the manual test case authoring friction by letting users upload a YAML file with customer personas and test data, then auto-generating a comprehensive test suite from the agent's tool configuration.

**Two-part feature:**

### Part A: YAML Test Data Import
- User uploads a structured YAML file containing customer personas with their data (phone numbers, SSN last-four, account numbers, loan IDs, payment methods, etc.)
- Platform validates the YAML against the agent's tool input schemas — confirms the data fields align with what each tool expects
- Parsed data becomes the `customerKnowledge` and `sessionData` for generated test cases
- YAML schema supports multiple personas, each with different data profiles (successful auth, failed auth, multiple accounts, etc.)

**Example YAML:**
```yaml
personas:
  - name: "Thomas — verified homeowner"
    style: direct
    phone: "+14074629069"
    ssn_last_four: "1234"
    accounts:
      - loan_number: "HL-2024-004"
        type: "30-Year Fixed"
    goals:
      - "check mortgage rate"
      - "get payoff quote"
      - "make a payment"

  - name: "Sandra — frustrated customer"
    style: confrontational
    phone: "+15551234567"
    ssn_last_four: "9999"
    accounts: []  # auth will fail — no matching record
    goals:
      - "check balance"  # should escalate after failed auth
```

### Part B: Auto-Generated Test Coverage
- Given the agent's tool configuration (from snapshot) + uploaded personas, use an LLM to generate a test suite covering:
  - **Happy paths**: each tool invoked correctly with valid data
  - **Error paths**: tool failures, auth failures, escalations
  - **Edge cases**: missing data, invalid inputs, ambiguous requests
  - **Multi-tool sequences**: complex flows that chain multiple tools
  - **Persona-driven variations**: same goal with different customer styles (direct, confused, angry)
  - **Guardrail tests**: requests the agent should refuse (rate advice, investment guidance)
- The LLM sees: tool descriptions, system prompt constraints, available test data, and the agent's escalation rules
- User reviews generated cases, adjusts, and runs

**Key design considerations:**
- Schema validation: YAML fields must map to tool `inputSchema` — validate upfront and report which tools have insufficient test data
- Coverage model: define coverage in terms of tool combinations × persona variants × outcome types (success/failure/escalation)
- Deduplication: don't generate 5 cases that all test the same tool path with different wording
- The generated suite should include both the test cases AND the `goalDescription` explaining what each case validates
- Export: support exporting the generated suite as YAML (round-trip — enables version control of test definitions)

**Connection to existing features:**
- Uses the existing `POST /suites/{suiteId}/cases` endpoint to persist generated cases
- Leverages the agent snapshot (tools, system prompt) already captured at run time
- Feeds directly into the test-case-validity-analysis feature — auto-generated cases can still be flagged as defective if the generator was too aggressive

---

## Reference: deployed resources (account 104220062740, us-east-1)

- API: `https://c0vqju093c.execute-api.us-east-1.amazonaws.com/prod/`
- CloudFront: `https://d353l70t9ml83.cloudfront.net`
- Assistant: `5664eea5-381d-468e-bfba-302b69ae6dec`
- AnyBank ORCHESTRATION agent: `d54d3dee-b9ec-415a-9a4b-b4769426f365`
- Contact-creator flow: `fdddd12a-8f20-4599-a548-e6a92941991c`
- Test suite: `8973008350767692fdc59f30` (case `39135557386361de1f6f2f4c`)
- Deploy: `rm -rf cdk.out && AWS_DEFAULT_REGION=us-east-1 npx cdk deploy -c connectInstanceId=46837cc7-8562-4b3f-92b2-1bae0ede624b --require-approval never`


---

## Zombie run records — `status=running` rows that never reach a terminal state

**Symptom:** `GET /prompts/active-runs` reported 48 in-progress runs on 2026-06-10
even though no run had been launched in the past 4+ days. Every record's
`startTime` was 4-7 days old. The Prompts page surfaced "48 runs in progress" on
every prompt detail click, frightening the user into thinking a prompt edit
would affect mid-flight runs.

**Immediate fix (landed):** `handleActiveRuns` now adds a 2-hour `startTime`
cutoff to the DDB scan, so the count reflects only plausibly-active runs. The
platform's longest legitimate run is well under an hour even on a worst-case
suite (see jsdoc on `handleActiveRuns`); 2 hours is a generous ceiling.

**Root cause (not yet addressed):** When a run errors out abnormally — Lambda
crash, Step Functions abort, manual stop, deployment mid-run — the
`PK=SUITE#{suiteId}, SK=RUN#{startTime}` record stays at `status=running`
forever. The Run Dashboard still surfaces these zombies, and any future
endpoint that filters on `status` will hit the same problem. The 48-row
backlog in the dev account is sitting there today.

**What's needed to fix:**
1. Reconciliation janitor that takes each `status ∈ {running, pending}` record,
   looks up its `sfnExecutionArn`, calls `DescribeExecution`, and rewrites the
   record's status to match the SFn execution outcome (`FAILED` / `ABORTED` /
   `TIMED_OUT` → `error`; `SUCCEEDED` → `passed/failed` based on case results).
   Run on a daily EventBridge schedule plus on-demand from a `POST /runs/reconcile`
   endpoint for operators.
2. One-shot cleanup script for the existing 48 zombies in dev. Most likely the
   janitor itself, run once with `--force` or `--all-history` flag.
3. Optional: change the run-status state machine so a Lambda crash inside
   `PrepareRun` / `ConversationDriver` / `WriteResults` writes the terminal
   error status before the function exits. Defense in depth — the janitor still
   handles infra-level failures (instance termination, OOM kills) where the
   Lambda has no chance to write.

This is not a launch blocker for prompt-management Wave 3, but it should be
its own spec.
