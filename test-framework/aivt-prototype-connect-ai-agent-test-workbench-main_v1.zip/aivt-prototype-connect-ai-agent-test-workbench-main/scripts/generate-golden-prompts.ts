#!/usr/bin/env node
/**
 * Golden-prompt snapshot generator — for each `Span_Fixture` under
 * `tests/fixtures/spans/`, renders the four Judge_Prompt_Context surfaces
 * via {@link renderJudgePromptContext} and writes one `.txt` file per
 * rendered string under `tests/fixtures/golden-prompts/{fixture-name}/`.
 *
 * Output layout (Requirement 11.2):
 *
 *     tests/fixtures/golden-prompts/{fixture-name}/
 *       context.txt                  ← session-level GoalSuccessRate {context}
 *       available-tools.txt          ← {available_tools} numbered list
 *       assistant-turn-0.txt         ← Helpfulness {assistant_turn}, 0-based
 *       assistant-turn-0.context.txt ← Helpfulness prefix-only {context}
 *       assistant-turn-1.txt
 *       assistant-turn-1.context.txt
 *       tool-turn-0.txt              ← ToolSelectionAccuracy {tool_turn}
 *       tool-turn-0.context.txt      ← ToolSelectionAccuracy prefix-only {context}
 *       tool-turn-1.txt
 *       tool-turn-1.context.txt
 *       …
 *
 * Both the per-unit `{...}` substitution string AND its accompanying
 * prefix-only `{context}` are written so the conformance test (task 8.2)
 * can byte-equality-assert every input the Bedrock_Judge sees, not just
 * the substitution token (Requirements 11.2 / 11.6 / 2.4).
 *
 * Run:
 *
 *     npx tsx scripts/generate-golden-prompts.ts
 *     npx tsx scripts/generate-golden-prompts.ts tests/fixtures/spans/multi-tool-success.json
 *
 * No CLI arg → regenerates every fixture under `tests/fixtures/spans/`.
 * One or more fixture paths → regenerates only those.
 *
 * Idempotent: running the generator twice with no source changes produces
 * byte-identical output. A run is reported as "unchanged" or "wrote N
 * files" so a CI guard can grep the output if desired.
 *
 * No AWS calls — purely an in-process render of the pure prompt-rendering
 * module against checked-in fixtures.
 *
 * @module generate-golden-prompts
 */

import { readFileSync, mkdirSync, readdirSync, writeFileSync, existsSync } from "node:fs";
import * as path from "node:path";

import { parseSpansToTrace, type RawSpan } from "../src/backend/orchestration/span-parser";
import { renderJudgePromptContext } from "../src/shared/utils/judge-prompt-rendering";
import type {
  AgentSnapshot,
  ToolDefinition,
  TranscriptTurn,
} from "../src/shared/types";

// ---------------------------------------------------------------------------
// Span fixture shape (matches tests/fixtures/spans/README.md)
// ---------------------------------------------------------------------------

interface SpanFixture {
  name: string;
  description?: string;
  sessionId: string;
  rawSpans: RawSpan[];
  expectedToolSequence?: string[];
  availableTools: ToolDefinition[];
  expectedToolNames: string[];
}

// ---------------------------------------------------------------------------
// Paths
// ---------------------------------------------------------------------------

const REPO_ROOT = path.resolve(__dirname, "..");
const SPANS_DIR = path.join(REPO_ROOT, "tests", "fixtures", "spans");
const GOLDEN_DIR = path.join(REPO_ROOT, "tests", "fixtures", "golden-prompts");

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Pulls the customer-side utterances from a Span_Fixture's raw `inference`
 * spans into a `TranscriptTurn[]` whose `role:"customer"` entries align
 * positionally with the assistant turns the rendering module groups out
 * of the trace. The first non-empty `inputMessages.values[].text.value`
 * on each `inference` span is treated as the customer text that opened
 * that turn (matching the convention used by `scripts/bedrock-judge-probe.ts`
 * and `scripts/evaluation-harness.ts` so the rendered context stays
 * byte-compatible with the validated reference behaviour).
 *
 * Inference spans without a customer-text input contribute no transcript
 * entry, so the i-th customer slot still pairs with the i-th assistant
 * turn rather than silently shifting.
 */
function extractCustomerTranscript(fixture: SpanFixture): TranscriptTurn[] {
  const turns: TranscriptTurn[] = [];
  let turnNumber = 0;
  for (const span of fixture.rawSpans) {
    if (span.spanName !== "inference") continue;
    const text = firstInputText(span);
    if (text === undefined) continue;
    turns.push({
      turnNumber: turnNumber++,
      role: "customer",
      text,
      timestamp: span.startTimestamp ?? new Date(0).toISOString(),
      elapsedMs: 0,
    });
  }
  return turns;
}

/** Returns the first `inputMessages[].values[].text.value` on a raw span, if any. */
function firstInputText(span: RawSpan): string | undefined {
  const inputs = span.attributes?.inputMessages ?? [];
  for (const m of inputs) {
    for (const v of m.values ?? []) {
      const text = v.text?.value;
      if (typeof text === "string" && text.length > 0) return text;
    }
  }
  return undefined;
}

/**
 * Builds an `AgentSnapshot` from a fixture's `availableTools`. The
 * rendering module reads only `snapshot.tools`; the other fields are
 * placeholders so they cannot leak into a prompt.
 */
function makeSnapshot(tools: ToolDefinition[]): AgentSnapshot {
  return {
    tools,
    systemPrompt: "",
    modelId: "",
    capturedAt: new Date(0).toISOString(),
  };
}

/**
 * Writes `text` to `filePath`, creating parent directories as needed,
 * and returns whether the file's contents changed (`true`) or were
 * already byte-identical (`false`). Used for idempotent reporting.
 */
function writeIfChanged(filePath: string, text: string): boolean {
  mkdirSync(path.dirname(filePath), { recursive: true });
  if (existsSync(filePath)) {
    const existing = readFileSync(filePath, "utf8");
    if (existing === text) return false;
  }
  writeFileSync(filePath, text, "utf8");
  return true;
}

/**
 * Generates the golden-prompt files for a single fixture and returns the
 * count of files that changed.
 */
function generateForFixture(fixturePath: string): { written: number; total: number } {
  const raw = readFileSync(fixturePath, "utf8");
  const fixture = JSON.parse(raw) as SpanFixture;

  if (!fixture.sessionId || !Array.isArray(fixture.rawSpans)) {
    throw new Error(
      `Fixture "${fixturePath}" is missing required "sessionId" or "rawSpans" fields.`,
    );
  }

  const trace = parseSpansToTrace(fixture.sessionId, fixture.rawSpans);
  const transcript = extractCustomerTranscript(fixture);
  const snapshot = makeSnapshot(fixture.availableTools ?? []);
  const expectedToolNames = fixture.expectedToolNames ?? [];

  const rendered = renderJudgePromptContext({
    trace,
    transcript,
    snapshot,
    expectedToolNames,
  });

  const fixtureName = path.basename(fixturePath, ".json");
  const outDir = path.join(GOLDEN_DIR, fixtureName);

  let written = 0;
  let total = 0;

  // Session-level GoalSuccessRate {context}
  total += 1;
  if (writeIfChanged(path.join(outDir, "context.txt"), rendered.context)) written += 1;

  // {available_tools}
  total += 1;
  if (
    writeIfChanged(
      path.join(outDir, "available-tools.txt"),
      rendered.availableTools,
    )
  )
    written += 1;

  // Helpfulness — one {assistant_turn} + its prefix-only {context} per turn
  for (const at of rendered.assistantTurns) {
    total += 2;
    if (
      writeIfChanged(
        path.join(outDir, `assistant-turn-${at.index}.txt`),
        at.assistantTurn,
      )
    )
      written += 1;
    if (
      writeIfChanged(
        path.join(outDir, `assistant-turn-${at.index}.context.txt`),
        at.context,
      )
    )
      written += 1;
  }

  // ToolSelectionAccuracy — one {tool_turn} + its prefix-only {context} per call
  for (const tt of rendered.toolTurns) {
    total += 2;
    if (
      writeIfChanged(
        path.join(outDir, `tool-turn-${tt.index}.txt`),
        tt.toolTurn,
      )
    )
      written += 1;
    if (
      writeIfChanged(
        path.join(outDir, `tool-turn-${tt.index}.context.txt`),
        tt.context,
      )
    )
      written += 1;
  }

  return { written, total };
}

/** Returns the full path of every `*.json` Span_Fixture in `SPANS_DIR`. */
function discoverFixtures(): string[] {
  return readdirSync(SPANS_DIR)
    .filter((entry) => entry.endsWith(".json"))
    .sort()
    .map((entry) => path.join(SPANS_DIR, entry));
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

function main(): void {
  const args = process.argv.slice(2);
  const fixturePaths =
    args.length > 0
      ? args.map((a) => path.resolve(REPO_ROOT, a))
      : discoverFixtures();

  if (fixturePaths.length === 0) {
    console.error(`No Span_Fixtures found under ${SPANS_DIR}`);
    process.exit(1);
  }

  let totalWritten = 0;
  let totalFiles = 0;
  for (const fixturePath of fixturePaths) {
    const fixtureName = path.basename(fixturePath, ".json");
    const { written, total } = generateForFixture(fixturePath);
    totalWritten += written;
    totalFiles += total;
    const status = written === 0 ? "unchanged" : `${written} updated`;
    console.log(`  ${fixtureName}: ${total} file(s), ${status}`);
  }

  if (totalWritten === 0) {
    console.log(`Done. ${totalFiles} golden-prompt file(s) checked, all unchanged.`);
  } else {
    console.log(
      `Done. ${totalWritten} of ${totalFiles} golden-prompt file(s) updated under ${path.relative(REPO_ROOT, GOLDEN_DIR)}/.`,
    );
  }
}

main();
