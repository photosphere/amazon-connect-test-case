/**
 * Unit / example tests for the rewritten Evaluation Lambda
 * (`src/backend/orchestration/evaluation.ts`, task 5.1).
 *
 * The rewritten Lambda composes the pure prompt-rendering module with the
 * Bedrock judge client. These tests exercise the full per-case pipeline
 * with the Bedrock client mocked through the `_setBedrockClient` test
 * seam and DynamoDB mocked through `aws-sdk-client-mock`. No real AWS
 * SDK is invoked.
 *
 * Validates:
 *   - Requirement 1.1: exactly one `judge` call per evaluator unit
 *     (1 GSR + N Helpfulness + M ToolSelection) per case, with the
 *     correct rendered prompt vars.
 *   - Requirement 1.7: persisted to PK=`RUN#{runId}`, SK=`CASE#{caseId}`.
 *   - Requirement 2.8: `INSUFFICIENT_TRACE` short-circuits before any
 *     judge call (and before any DynamoDB write of an evaluator outcome).
 *   - Requirement 7.1: the `1 + N + M` Converse calls are dispatched
 *     concurrently — every call is fired before any of them resolves.
 *   - Requirement 7.3: per-case 90s wall-clock budget cancels in-flight
 *     calls and persists `TIMEOUT`.
 *   - Requirement 8.1: per-call timeout (`JudgeTimeoutError`) → `TIMEOUT`.
 *   - Requirement 8.2: SDK error → `JUDGE_ERROR`.
 *   - Requirement 8.3: parse failure / unmappable label → `UNMAPPABLE_RESULT`.
 *   - Requirement 8.4: a partial-success batch surfaces the produced
 *     evaluator outcomes (visible on the `evaluateCaseSession` return
 *     value's `aggregated` / `rawOutcomes`) plus the dominant error
 *     code on the persisted record.
 *   - Requirement 8.5: per the structural invariant (Property 12) the
 *     persisted record leaves all three scores unset whenever
 *     `evaluationError` is set; the Lambda never substitutes a local-
 *     scoring helper.
 *   - Requirement 8.7: a mixed batch persists every case and does not
 *     fail the run.
 *   - Requirement 8.8: no local-scoring substitution path — every
 *     produced score equals the Score_Scale value of the mocked judge
 *     label, and an unrecognized label never yields a numeric score.
 *
 * @module tests/unit/evaluation.test
 */

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { mockClient } from "aws-sdk-client-mock";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { ConverseCommand } from "@aws-sdk/client-bedrock-runtime";

import {
  evaluateCaseSession,
  handler,
  _setDynamoService,
  type EvaluationInput,
} from "../../src/backend/orchestration/evaluation";
import {
  _setBedrockClient,
  _resetBedrockClient,
  JudgeTimeoutError,
} from "../../src/backend/orchestration/bedrock-judge-client";
import { HELPFULNESS_SCALE } from "../../src/shared/utils/evaluation-scoring";
import { createDynamoDBService } from "../../src/backend/services/dynamodb";
import { CaseStatus, CommunicationStyle } from "../../src/shared/enums";
import {
  _clearCaches as _clearPromptRegistryCaches,
  _setPromptStore as _setPromptRegistryStore,
} from "../../src/backend/orchestration/prompt-registry/runtime";
import {
  PROMPT_REGISTRY,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";
import type {
  AgentSnapshot,
  ExecutionTrace,
  TestCaseResult,
  ToolDefinition,
  ToolSequenceTestCase,
  TranscriptTurn,
} from "../../src/shared/types";

// ---------------------------------------------------------------------------
// Fixtures — minimal shapes that drive 1 + N + M = 1 + 2 + 2 = 5 judge calls
// ---------------------------------------------------------------------------

const RUN_ID = "run-eval-1";
const CASE_ID_A = "case-a";
const CASE_ID_B = "case-b";
const SESSION_ID = "session-xyz";

function makeTools(): ToolDefinition[] {
  return [
    {
      toolName: "AuthenticateUser",
      toolType: "LAMBDA",
      description: "Authenticate the customer.",
      inputSchema: { type: "object" },
      examples: [],
    },
    {
      toolName: "SearchFlights",
      toolType: "LAMBDA",
      description: "Search for flights.",
      inputSchema: { type: "object" },
      examples: [],
    },
  ];
}

function makeSnapshot(): AgentSnapshot {
  return {
    tools: makeTools(),
    systemPrompt: "You are a travel assistant.",
    modelId: "claude-3-haiku",
    capturedAt: "2024-01-01T00:00:00Z",
  };
}

function makeTestCase(overrides: Partial<ToolSequenceTestCase> = {}): ToolSequenceTestCase {
  return {
    type: "tool_sequence",
    suiteId: "suite-1",
    caseId: CASE_ID_A,
    name: "Booking",
    description: "Customer wants to book a flight.",
    persona: "frequent traveler",
    style: CommunicationStyle.DIRECT,
    customerKnowledge: { name: "Jane" },
    initialUtterance: "Book me a flight.",
    successCriteria: [
      { toolName: "AuthenticateUser", required: true },
      { toolName: "SearchFlights", required: true },
    ],
    ...overrides,
  };
}

function makeResult(overrides: Partial<TestCaseResult> = {}): TestCaseResult {
  return {
    runId: RUN_ID,
    caseId: CASE_ID_A,
    status: CaseStatus.PASSED,
    toolsInvoked: ["AuthenticateUser", "SearchFlights"],
    turnCount: 4,
    latencyMs: 2500,
    ...overrides,
  };
}

/**
 * Builds a trace with TWO assistant inference steps and TWO `execute_tool`
 * steps so each per-case call to the judge fans out as
 * `1 + 2 + 2 = 5` Converse calls. This is large enough to assert
 * concurrent fan-out (Req 7.1), per-evaluator dispatch (Req 1.1), and
 * mixed partial-success batching (Req 8.4) without being noisy.
 */
function makeTrace(): ExecutionTrace {
  return {
    sessionId: SESSION_ID,
    aiAgentName: "TravelAgent",
    aiAgentType: "ORCHESTRATION",
    capturedAt: "2024-01-01T00:00:01Z",
    toolSequence: ["AuthenticateUser", "SearchFlights"],
    steps: [
      {
        index: 0,
        type: "inference",
        spanName: "inference",
        text: "I can help you book a flight.",
        timestamp: "2024-01-01T00:00:00.500Z",
      },
      {
        index: 1,
        type: "tool",
        spanName: "execute_tool",
        timestamp: "2024-01-01T00:00:00.700Z",
        tool: {
          toolName: "AuthenticateUser",
          arguments: { id: "u-42" },
          result: { authenticated: true },
          success: true,
          timestamp: "2024-01-01T00:00:00.700Z",
        },
      },
      {
        index: 2,
        type: "inference",
        spanName: "inference",
        text: "Searching now.",
        timestamp: "2024-01-01T00:00:01.000Z",
      },
      {
        index: 3,
        type: "tool",
        spanName: "execute_tool",
        timestamp: "2024-01-01T00:00:01.200Z",
        tool: {
          toolName: "SearchFlights",
          arguments: { destination: "NYC" },
          result: { flights: 3 },
          success: true,
          timestamp: "2024-01-01T00:00:01.200Z",
        },
      },
    ],
  };
}

function makeTranscript(): TranscriptTurn[] {
  return [
    {
      turnNumber: 1,
      role: "customer",
      text: "Find a flight to NYC.",
      timestamp: "2024-01-01T00:00:00.000Z",
      elapsedMs: 0,
    },
    {
      turnNumber: 2,
      role: "agent",
      text: "I can help you book a flight.",
      timestamp: "2024-01-01T00:00:00.500Z",
      elapsedMs: 500,
    },
  ];
}

// ---------------------------------------------------------------------------
// Bedrock Converse-mock helpers
// ---------------------------------------------------------------------------

type EvaluatorClass =
  | "Builtin.GoalSuccessRate"
  | "Builtin.Helpfulness"
  | "Builtin.ToolSelectionAccuracy"
  | "Unknown";

/** A captured per-Converse call detail used for assertions. */
interface CapturedJudgeCall {
  /** The exact, fully-rendered prompt the model received. */
  prompt: string;
  /** Which evaluator template the prompt matches (heuristically). */
  evaluatorId: EvaluatorClass;
}

/**
 * Identifies which template a fully-rendered judge prompt was built from.
 * The three AWS-published templates open with unique sentences so a
 * substring check is sufficient. Defensive against future template
 * additions: an unknown shape is reported as `"Unknown"` rather than
 * silently bucketed into one of the three.
 */
function classifyJudgePrompt(prompt: string): EvaluatorClass {
  if (
    prompt.includes(
      "evaluating the quality of an AI assistant as to whether",
    )
  ) {
    return "Builtin.GoalSuccessRate";
  }
  if (prompt.includes("evaluating the helpfulness of an AI assistant")) {
    return "Builtin.Helpfulness";
  }
  if (
    prompt.includes(
      "evaluating if an AI assistant's action is justified",
    )
  ) {
    return "Builtin.ToolSelectionAccuracy";
  }
  return "Unknown";
}

/** Builds a Converse response carrying a single text content block. */
function makeConverseResponse(text: string): unknown {
  return {
    output: { message: { content: [{ text }] }, stopReason: "end_turn" },
  };
}

/** Wraps `payload` as a fenced ```json block, the shape every template asks for. */
function fencedJson(payload: object): string {
  return "```json\n" + JSON.stringify(payload) + "\n```";
}

type FactoryDecision =
  | { reasoning: string; score: string }
  | Error
  | "abort-on-signal";

/**
 * Bedrock-judge-client test seam. Returns the mock object shape expected
 * by `_setBedrockClient`: a duck-typed `{ send }` matching
 * `Pick<BedrockRuntimeClient, "send">`.
 *
 * Tests pass a per-evaluator response factory: based on the prompt's
 * detected template family, the factory returns either a parsed-JSON
 * object to be wrapped in a fenced block, an `Error` to be rejected, or
 * the sentinel `"abort-on-signal"` to hold the call open until the
 * caller's per-case AbortController fires.
 */
function makeBedrockMock(
  factory: (
    evaluatorId: EvaluatorClass,
    callIndex: number,
  ) => FactoryDecision,
): {
  client: Parameters<typeof _setBedrockClient>[0];
  calls: CapturedJudgeCall[];
  send: ReturnType<typeof vi.fn>;
} {
  const calls: CapturedJudgeCall[] = [];
  const send = vi.fn().mockImplementation(
    (
      command: unknown,
      opts?: { abortSignal?: AbortSignal },
    ): Promise<unknown> => {
      const cmd = command as InstanceType<typeof ConverseCommand>;
      const text =
        cmd.input.messages?.[0]?.content
          ?.map((b) => ("text" in b ? b.text ?? "" : ""))
          .join("") ?? "";
      const evaluatorId = classifyJudgePrompt(text);
      const callIndex = calls.length;
      calls.push({ prompt: text, evaluatorId });

      const decision = factory(evaluatorId, callIndex);
      if (decision === "abort-on-signal") {
        // Hold the call open until the per-case AbortController fires.
        return new Promise<never>((_, reject) => {
          const signal = opts?.abortSignal;
          if (!signal) {
            const err = new Error("aborted");
            err.name = "AbortError";
            reject(err);
            return;
          }
          if (signal.aborted) {
            const err = new Error("aborted");
            err.name = "AbortError";
            reject(err);
            return;
          }
          signal.addEventListener("abort", () => {
            const err = new Error("aborted");
            err.name = "AbortError";
            reject(err);
          });
        });
      }
      if (decision instanceof Error) {
        return Promise.reject(decision);
      }
      return Promise.resolve(makeConverseResponse(fencedJson(decision)));
    },
  );
  return {
    client: { send } as unknown as Parameters<typeof _setBedrockClient>[0],
    calls,
    send,
  };
}

// ---------------------------------------------------------------------------
// DynamoDB mock — `aws-sdk-client-mock` over the doc client used by the
// `DynamoDBService`. The Lambda's per-case path issues:
//   - `GetCommand` for the run-level `SNAPSHOT` (PK=RUN#…, SK=SNAPSHOT)
//   - `GetCommand` for the per-case `TRACE`    (PK=RUN#…#CASE#…, SK=TRACE)
//   - `QueryCommand` for the per-case transcript items
//   - `PutCommand` to write the merged TestCaseResult
// We program the mock with the in-memory store so each test is end-to-end
// over the real `DynamoDBService` code path.
// ---------------------------------------------------------------------------

interface DynamoFixtureInput {
  runId: string;
  caseId: string;
  trace: ExecutionTrace | null;
  transcript: TranscriptTurn[];
  snapshot: AgentSnapshot | null;
}

/**
 * Wires a `DynamoDBDocumentClient` against `aws-sdk-client-mock` to
 * service the four read/write commands the Evaluation Lambda issues.
 * Returns the ddb mock + a `written` array of every `PutCommand` `Item`
 * that landed on the doc client, so tests can assert on the persisted
 * `PK`/`SK` shape (Req 1.7) and on the merged `TestCaseResult` shape.
 */
function setupDynamoMock(fixtures: readonly DynamoFixtureInput[]): {
  ddbMock: ReturnType<typeof mockClient>;
  written: Array<Record<string, unknown>>;
} {
  const written: Array<Record<string, unknown>> = [];
  const ddbMock = mockClient(DynamoDBDocumentClient);

  // Per-case lookup tables keyed by composite `PK|SK` strings.
  const snapshotByRunPk = new Map<string, AgentSnapshot>();
  const traceByCasePk = new Map<string, ExecutionTrace>();
  const transcriptByCasePk = new Map<string, TranscriptTurn[]>();
  for (const f of fixtures) {
    if (f.snapshot) {
      snapshotByRunPk.set(`RUN#${f.runId}`, f.snapshot);
    }
    if (f.trace) {
      traceByCasePk.set(`RUN#${f.runId}#CASE#${f.caseId}`, f.trace);
    }
    transcriptByCasePk.set(`RUN#${f.runId}#CASE#${f.caseId}`, f.transcript);
  }

  ddbMock.on(GetCommand).callsFake((input: { Key?: Record<string, string> }) => {
    const pk = input.Key?.PK ?? "";
    const sk = input.Key?.SK ?? "";
    if (sk === "SNAPSHOT") {
      const snap = snapshotByRunPk.get(pk);
      return snap
        ? { Item: { PK: pk, SK: sk, ...snap } }
        : { Item: undefined };
    }
    if (sk === "TRACE") {
      const trace = traceByCasePk.get(pk);
      if (!trace) return { Item: undefined };
      return {
        Item: {
          PK: pk,
          SK: sk,
          sessionId: trace.sessionId,
          aiAgentName: trace.aiAgentName,
          aiAgentType: trace.aiAgentType,
          toolSequence: trace.toolSequence,
          steps: JSON.stringify(trace.steps),
          capturedAt: trace.capturedAt,
        },
      };
    }
    return { Item: undefined };
  });

  ddbMock
    .on(QueryCommand)
    .callsFake(
      (input: {
        ExpressionAttributeValues?: Record<string, string>;
      }) => {
        const pk = input.ExpressionAttributeValues?.[":pk"] ?? "";
        const turns = transcriptByCasePk.get(pk) ?? [];
        return {
          Items: turns.map((t) => ({
            PK: pk,
            SK: `TURN#${String(t.turnNumber).padStart(4, "0")}`,
            ...t,
          })),
        };
      },
    );

  ddbMock
    .on(PutCommand)
    .callsFake((input: { Item?: Record<string, unknown> }) => {
      const item = input.Item ?? {};
      written.push(item);
      return {};
    });

  return { ddbMock, written };
}

/**
 * Constructs a `DynamoDBService` that talks through the `aws-sdk-client-mock`
 * interception. The mock wraps every `DynamoDBDocumentClient.send` call
 * globally, so a fresh `DocumentClient.from(new DynamoDBClient({}))` is
 * sufficient to route through the test fixture data.
 */
function makeServiceForMockedDynamo() {
  const docClient = DynamoDBDocumentClient.from(new DynamoDBClient({}));
  return createDynamoDBService("TestTable", docClient);
}

// ---------------------------------------------------------------------------
// Setup / teardown
// ---------------------------------------------------------------------------

const originalEnv = { ...process.env };

beforeEach(() => {
  process.env = {
    ...originalEnv,
    AWS_REGION: "us-east-1",
  };
  _resetBedrockClient();
  // Wire a stub Prompts_Store so `resolvePromptForRun(...)` returns the
  // registry's bundled defaults without touching DynamoDB. Same pattern
  // as `tests/unit/customer-simulator.test.ts`. Empty-overrides + no
  // snapshot ⇒ resolver yields the bundled judge prompt for every key.
  _clearPromptRegistryCaches();
  const promptStore = {
    getSnapshot: vi.fn().mockResolvedValue(null),
    listPromptOverrides: vi.fn().mockResolvedValue(new Map()),
  } as unknown as Parameters<typeof _setPromptRegistryStore>[0];
  _setPromptRegistryStore(promptStore);
});

afterEach(() => {
  _setBedrockClient(null);
  _setDynamoService(null);
  _setPromptRegistryStore(null);
  _clearPromptRegistryCaches();
  process.env = { ...originalEnv };
  vi.useRealTimers();
});

// ---------------------------------------------------------------------------
// Req 1.1 — exactly one judge call per evaluator unit with the rendered vars
// ---------------------------------------------------------------------------

describe("evaluateCaseSession — one judge call per evaluator unit (Req 1.1)", () => {
  it("dispatches 1 GoalSuccessRate + N Helpfulness + M ToolSelection calls with correctly rendered prompt vars", async () => {
    const mock = makeBedrockMock((id) =>
      id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "g", score: "Yes" },
    );
    _setBedrockClient(mock.client);

    const out = await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    // 1 GSR + 2 Helpfulness (two assistant turns) + 2 ToolSelection (two tool calls).
    expect(mock.calls).toHaveLength(5);

    const byEvaluator = new Map<EvaluatorClass, number>();
    for (const c of mock.calls) {
      byEvaluator.set(
        c.evaluatorId,
        (byEvaluator.get(c.evaluatorId) ?? 0) + 1,
      );
    }
    expect(byEvaluator.get("Builtin.GoalSuccessRate")).toBe(1);
    expect(byEvaluator.get("Builtin.Helpfulness")).toBe(2);
    expect(byEvaluator.get("Builtin.ToolSelectionAccuracy")).toBe(2);
    expect(byEvaluator.get("Unknown") ?? 0).toBe(0);

    // Each rendered prompt has every relevant placeholder substituted.
    for (const c of mock.calls) {
      expect(c.prompt).not.toContain("{available_tools}");
      expect(c.prompt).not.toContain("{context}");
      expect(c.prompt).not.toContain("{assistant_turn}");
      expect(c.prompt).not.toContain("{tool_turn}");
    }

    // The rendered context references the customer turn and the
    // assistant text from the trace — proving the prompt-rendering
    // module was actually exercised (not stubbed).
    const goalCall = mock.calls.find(
      (c) => c.evaluatorId === "Builtin.GoalSuccessRate",
    )!;
    expect(goalCall.prompt).toContain("Find a flight to NYC.");
    expect(goalCall.prompt).toContain("I can help you book a flight.");
    // GoalSuccessRate carries the expected-tools annotation (Req 2.6).
    expect(goalCall.prompt).toMatch(/Expected tools:[^\n]*AuthenticateUser/);

    // The two ToolSelection prompts carry the tool turn lines for the
    // two execute_tool steps (rendered as `name(JSON.args)` per Req 2.5).
    const toolPrompts = mock.calls
      .filter((c) => c.evaluatorId === "Builtin.ToolSelectionAccuracy")
      .map((c) => c.prompt);
    expect(toolPrompts.some((p) => p.includes("AuthenticateUser"))).toBe(true);
    expect(toolPrompts.some((p) => p.includes("SearchFlights"))).toBe(true);

    // The aggregator emitted three numeric scores and no error state.
    expect(out.caseEvaluation.evaluationError).toBeUndefined();
    expect(out.caseEvaluation.goalSuccessScore).toBe(1.0);
    expect(out.caseEvaluation.toolAccuracyScore).toBe(1.0);
    // Helpfulness mean of two `Very Helpful` (5/6) labels.
    expect(out.caseEvaluation.helpfulnessScore).toBeCloseTo(
      HELPFULNESS_SCALE["Very Helpful"],
      12,
    );
  });

  it("dispatches all 1 + N + M calls before any of them resolves (concurrent fan-out, Req 7.1)", async () => {
    // Capture the order: every send increments `dispatchCount`; only
    // after every call has been dispatched do we resolve them all. If
    // the Lambda were serialising the calls the first send would fire,
    // its response would never arrive (release runs only at count=5),
    // and the test would hang. Test passing ⇒ concurrent fan-out.
    let dispatchCount = 0;
    let release: () => void = () => {};
    const allDispatched = new Promise<void>((res) => {
      release = res;
    });

    const send = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as InstanceType<typeof ConverseCommand>;
      const text =
        cmd.input.messages?.[0]?.content
          ?.map((b) => ("text" in b ? b.text ?? "" : ""))
          .join("") ?? "";
      dispatchCount += 1;
      // 1 GSR + 2 Helpfulness + 2 ToolSelection = 5 calls expected.
      if (dispatchCount === 5) release();
      return allDispatched.then(() => {
        const score =
          classifyJudgePrompt(text) === "Builtin.Helpfulness"
            ? "Very Helpful"
            : "Yes";
        return makeConverseResponse(fencedJson({ reasoning: "r", score }));
      });
    });
    _setBedrockClient(
      { send } as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    expect(dispatchCount).toBe(5);
    expect(send).toHaveBeenCalledTimes(5);
  });
});

// ---------------------------------------------------------------------------
// Req 2.8 — INSUFFICIENT_TRACE short-circuits without any judge call
// ---------------------------------------------------------------------------

describe("evaluateCaseSession — INSUFFICIENT_TRACE short-circuit (Req 2.8)", () => {
  it("records INSUFFICIENT_TRACE without invoking the judge when the trace has zero turns and zero tool calls", async () => {
    const mock = makeBedrockMock(() => ({ reasoning: "n/a", score: "Yes" }));
    _setBedrockClient(mock.client);

    const emptyTrace: ExecutionTrace = {
      sessionId: SESSION_ID,
      capturedAt: "2024-01-01T00:00:00Z",
      toolSequence: [],
      steps: [],
    };

    const out = await evaluateCaseSession({
      trace: emptyTrace,
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser"],
    });

    expect(mock.send).not.toHaveBeenCalled();
    expect(out.caseEvaluation.evaluationError?.code).toBe(
      "INSUFFICIENT_TRACE",
    );
    expect(out.caseEvaluation.goalSuccessScore).toBeUndefined();
    expect(out.caseEvaluation.helpfulnessScore).toBeUndefined();
    expect(out.caseEvaluation.toolAccuracyScore).toBeUndefined();
    // No raw outcomes, no per-call detail — proof the pipeline
    // short-circuited before rendering the prompts.
    expect(out.rawOutcomes).toEqual([]);
    expect(out.rawJudgeResults).toEqual([]);
  });

  it("does NOT short-circuit when the trace has at least one assistant turn (Req 2.8 second clause)", async () => {
    // A submittable trace per Req 2.8 has at least one assistant turn
    // OR at least one execute_tool entry. We exercise the assistant-
    // turn-only path here (the multi-step case is covered by the
    // Req 1.1 happy-path test above).
    const traceInferenceOnly: ExecutionTrace = {
      sessionId: SESSION_ID,
      capturedAt: "2024-01-01T00:00:00Z",
      toolSequence: [],
      steps: [
        {
          index: 0,
          type: "inference",
          spanName: "inference",
          text: "I can help.",
          timestamp: "2024-01-01T00:00:00.500Z",
        },
      ],
    };
    const mock = makeBedrockMock((id) =>
      id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "g", score: "Yes" },
    );
    _setBedrockClient(mock.client);

    const out = await evaluateCaseSession({
      trace: traceInferenceOnly,
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["SearchFlights"],
    });

    // 1 GSR + 1 Helpfulness + 0 ToolSelection = 2 calls. The trace had
    // an assistant turn so it is submittable; the case is NOT
    // INSUFFICIENT_TRACE.
    expect(mock.send).toHaveBeenCalledTimes(2);
    expect(out.caseEvaluation.evaluationError?.code).not.toBe(
      "INSUFFICIENT_TRACE",
    );
  });
});

// ---------------------------------------------------------------------------
// Req 7.3 — per-case 90s budget cancels in-flight calls and persists TIMEOUT
// ---------------------------------------------------------------------------

describe("evaluateCaseSession — per-case 90s budget (Req 7.3)", () => {
  it("aborts in-flight Converse calls and persists TIMEOUT when the per-case budget elapses", async () => {
    const mock = makeBedrockMock(() => "abort-on-signal");
    _setBedrockClient(mock.client);

    // A small budget so the test completes quickly. Per-call timeout
    // is intentionally larger than the budget so the per-call timer
    // is NOT what surfaces — only the per-case budget can. After the
    // budget fires (30ms), the judge's internal abort timer also
    // fires shortly thereafter (200ms) so the mock's "abort-on-signal"
    // promise resolves and the units fold into a TIMEOUT failure
    // well within vitest's default 5000ms test timeout.
    const out = await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
      budgetMs: 30,
      timeoutMs: 200,
    });

    expect(mock.send).toHaveBeenCalledTimes(5);
    // Every call's abortSignal fired (the budget did its job).
    for (const call of mock.send.mock.calls) {
      const opts = call[1] as { abortSignal?: AbortSignal } | undefined;
      expect(opts?.abortSignal?.aborted).toBe(true);
    }

    expect(out.caseEvaluation.evaluationError?.code).toBe("TIMEOUT");
    expect(out.caseEvaluation.evaluationError?.reason).toMatch(
      /budget|90|30/i,
    );
    // No score survives — every call was cancelled mid-flight.
    expect(out.caseEvaluation.goalSuccessScore).toBeUndefined();
    expect(out.caseEvaluation.helpfulnessScore).toBeUndefined();
    expect(out.caseEvaluation.toolAccuracyScore).toBeUndefined();
    // Every per-call detail is an error of `kind: "timeout"` — no
    // local-scoring substitution (Req 8.8).
    expect(out.rawJudgeResults).toHaveLength(5);
    for (const detail of out.rawJudgeResults) {
      expect(detail.error?.kind).toBe("timeout");
      expect(detail.mappedValue).toBeUndefined();
    }
  });
});

// ---------------------------------------------------------------------------
// Reqs 8.1, 8.2, 8.3, 8.5 — per-call error code mapping with no local-sub
// ---------------------------------------------------------------------------

describe("evaluateCaseSession — per-call error code mapping (Reqs 8.1, 8.2, 8.3, 8.5, 8.8)", () => {
  it("maps a per-call JudgeTimeoutError to TIMEOUT (Req 8.1)", async () => {
    const mock = makeBedrockMock((id) => {
      if (id === "Builtin.GoalSuccessRate") {
        return new JudgeTimeoutError(60_000);
      }
      return id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "t", score: "Yes" };
    });
    _setBedrockClient(mock.client);

    const out = await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    expect(out.caseEvaluation.evaluationError?.code).toBe("TIMEOUT");
    expect(out.caseEvaluation.evaluationError?.reason).toContain(
      "Builtin.GoalSuccessRate",
    );
    // Property 12: error state ⇒ all three scores unset.
    expect(out.caseEvaluation.goalSuccessScore).toBeUndefined();
    expect(out.caseEvaluation.helpfulnessScore).toBeUndefined();
    expect(out.caseEvaluation.toolAccuracyScore).toBeUndefined();
  });

  it("maps a non-timeout SDK error to JUDGE_ERROR (Req 8.2)", async () => {
    const sdkError = Object.assign(
      new Error("Validation failed: bad input"),
      { name: "ValidationException" },
    );
    const mock = makeBedrockMock((id) => {
      if (id === "Builtin.GoalSuccessRate") return sdkError;
      return id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "t", score: "Yes" };
    });
    _setBedrockClient(mock.client);

    const out = await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    expect(out.caseEvaluation.evaluationError?.code).toBe("JUDGE_ERROR");
    // Reason names the operation and carries the underlying error
    // class/name so downstream operators can see what failed.
    expect(out.caseEvaluation.evaluationError?.reason).toContain(
      "Builtin.GoalSuccessRate",
    );
    expect(out.caseEvaluation.evaluationError?.reason).toMatch(
      /ValidationException/,
    );
    // Scores unset.
    expect(out.caseEvaluation.goalSuccessScore).toBeUndefined();
    expect(out.caseEvaluation.helpfulnessScore).toBeUndefined();
    expect(out.caseEvaluation.toolAccuracyScore).toBeUndefined();
  });

  it("maps an unmappable label to UNMAPPABLE_RESULT (Req 8.3)", async () => {
    // Emit a label that is NOT in any Score_Scale — the judge client
    // returns it unchanged, the Lambda's mapping step fails, and the
    // outcome surfaces as UNMAPPABLE_RESULT (Requirement 4.4 / 8.3).
    const mock = makeBedrockMock((id) => {
      if (id === "Builtin.GoalSuccessRate") {
        return { reasoning: "r", score: "Maybe" };
      }
      return id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "t", score: "Yes" };
    });
    _setBedrockClient(mock.client);

    const out = await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    expect(out.caseEvaluation.evaluationError?.code).toBe(
      "UNMAPPABLE_RESULT",
    );
    expect(out.caseEvaluation.evaluationError?.reason).toContain("Maybe");
    // Property 12: error state ⇒ all three scores unset.
    expect(out.caseEvaluation.goalSuccessScore).toBeUndefined();
    expect(out.caseEvaluation.helpfulnessScore).toBeUndefined();
    expect(out.caseEvaluation.toolAccuracyScore).toBeUndefined();
  });

  it("never substitutes a local-scoring helper when scoring fails (Req 8.5, 8.8)", async () => {
    // Every call returns an unmappable label — there is no fallback
    // numeric score; toolAccuracyScore in particular MUST NOT be
    // synthesized from the local `calculateToolAccuracy` heuristic
    // (Req 8.8).
    const mock = makeBedrockMock(() => ({
      reasoning: "r",
      score: "Definitely Maybe",
    }));
    _setBedrockClient(mock.client);

    const out = await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    expect(out.caseEvaluation.evaluationError?.code).toBe(
      "UNMAPPABLE_RESULT",
    );
    expect(out.caseEvaluation.goalSuccessScore).toBeUndefined();
    expect(out.caseEvaluation.helpfulnessScore).toBeUndefined();
    expect(out.caseEvaluation.toolAccuracyScore).toBeUndefined();
    // Per-call diagnostics: every detail records `kind:
    // "unmappable-result"`; no entry has `mappedValue` set.
    expect(out.rawJudgeResults).toHaveLength(5);
    for (const detail of out.rawJudgeResults) {
      expect(detail.error?.kind).toBe("unmappable-result");
      expect(detail.mappedValue).toBeUndefined();
    }
  });
});

// ---------------------------------------------------------------------------
// Req 8.4 — partial success surfaces the produced outcomes
// ---------------------------------------------------------------------------

describe("evaluateCaseSession — partial success preserves produced outcomes (Req 8.4)", () => {
  it("when only one evaluator times out the others' raw outcomes are still produced", async () => {
    // Time out the second Helpfulness call (the one for the second
    // assistant turn) — every other evaluator unit succeeds. Index by
    // evaluator family so the test is stable to call-dispatch order.
    let helpfulnessCalls = 0;
    const mock = makeBedrockMock((id) => {
      if (id === "Builtin.Helpfulness") {
        helpfulnessCalls += 1;
        if (helpfulnessCalls === 2) {
          return new JudgeTimeoutError(60_000);
        }
        return { reasoning: "h", score: "Very Helpful" };
      }
      return { reasoning: "g", score: "Yes" };
    });
    _setBedrockClient(mock.client);

    const out = await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    // The persisted record has the dominant failure set (Property 12 /
    // Req 8.5 — scores stay unset on error state).
    expect(out.caseEvaluation.evaluationError?.code).toBe("TIMEOUT");
    expect(out.caseEvaluation.goalSuccessScore).toBeUndefined();

    // But the in-memory aggregator output still shows what each
    // evaluator family produced — every successful unit's mapped value
    // is on the corresponding outcome (Req 8.4: "the Platform SHALL
    // persist the produced score(s)..."). Our representation of the
    // produced scores lives on `out.aggregated` and `out.rawOutcomes`.
    expect(out.aggregated).toBeDefined();
    expect(out.aggregated!.goalSuccessScore).toBe(1.0);
    expect(out.aggregated!.toolAccuracyScore).toBe(1.0);

    // One Helpfulness unit succeeded; one timed out.
    const helpfulnessOutcome = out.rawOutcomes.find(
      (o) => o.evaluatorId === "Builtin.Helpfulness",
    )!;
    expect(helpfulnessOutcome.results).toHaveLength(1);
    expect(helpfulnessOutcome.results[0].value).toBeCloseTo(
      HELPFULNESS_SCALE["Very Helpful"],
      12,
    );
    // Both ToolSelection units succeeded.
    const toolOutcome = out.rawOutcomes.find(
      (o) => o.evaluatorId === "Builtin.ToolSelectionAccuracy",
    )!;
    expect(toolOutcome.results).toHaveLength(2);
    // Per-call diagnostic detail names exactly one timeout failure.
    const timeoutDetails = out.rawJudgeResults.filter(
      (d) => d.error?.kind === "timeout",
    );
    expect(timeoutDetails).toHaveLength(1);
    expect(timeoutDetails[0].evaluatorId).toBe("Builtin.Helpfulness");
  });
});

// ---------------------------------------------------------------------------
// Req 1.7 — handler persists to PK=RUN#{runId}, SK=CASE#{caseId}
// ---------------------------------------------------------------------------

describe("Evaluation Lambda handler — persistence layout (Req 1.7)", () => {
  it("writes each TestCaseResult to PK=RUN#{runId}, SK=CASE#{caseId}", async () => {
    const mock = makeBedrockMock((id) =>
      id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "g", score: "Yes" },
    );
    _setBedrockClient(mock.client);

    const { written } = setupDynamoMock([
      {
        runId: RUN_ID,
        caseId: CASE_ID_A,
        trace: makeTrace(),
        transcript: makeTranscript(),
        snapshot: makeSnapshot(),
      },
    ]);
    _setDynamoService(makeServiceForMockedDynamo());

    const event: EvaluationInput = {
      runId: RUN_ID,
      caseResults: [makeResult({ caseId: CASE_ID_A })],
      testCases: [makeTestCase({ caseId: CASE_ID_A })],
    };

    const output = await handler(event);

    expect(output.evaluated).toBe(1);
    expect(output.evaluationErrors).toBe(0);
    expect(output.errors).toBe(0);

    expect(written).toHaveLength(1);
    expect(written[0].PK).toBe(`RUN#${RUN_ID}`);
    expect(written[0].SK).toBe(`CASE#${CASE_ID_A}`);
    // Persisted record carries the runId from the event.
    expect(written[0].runId).toBe(RUN_ID);
    expect(written[0].caseId).toBe(CASE_ID_A);
    // Three score fields are present and no evaluationError is set.
    expect(written[0].goalSuccessScore).toBe(1.0);
    expect(written[0].toolAccuracyScore).toBe(1.0);
    expect(written[0].helpfulnessScore).toBeCloseTo(
      HELPFULNESS_SCALE["Very Helpful"],
      12,
    );
    expect(written[0].evaluationError).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// Req 8.7 — mixed batch persists every case and does not fail the run
// ---------------------------------------------------------------------------

describe("Evaluation Lambda handler — mixed batch (Req 8.7)", () => {
  it("persists every case and does not fail the run when some cases error", async () => {
    // Case A scores cleanly. Case B's GoalSuccessRate call throws an
    // SDK error; the case ends up with a JUDGE_ERROR persisted record.
    let goalCalls = 0;
    const send = vi.fn().mockImplementation((command: unknown) => {
      const cmd = command as InstanceType<typeof ConverseCommand>;
      const text =
        cmd.input.messages?.[0]?.content
          ?.map((b) => ("text" in b ? b.text ?? "" : ""))
          .join("") ?? "";
      const evaluatorId = classifyJudgePrompt(text);
      if (evaluatorId === "Builtin.GoalSuccessRate") {
        goalCalls += 1;
        if (goalCalls === 2) {
          // Second case (B) fails on the goal call.
          const err = Object.assign(
            new Error("Throttled, please retry"),
            { name: "ThrottlingException" },
          );
          return Promise.reject(err);
        }
      }
      const score =
        evaluatorId === "Builtin.Helpfulness" ? "Very Helpful" : "Yes";
      return Promise.resolve(
        makeConverseResponse(fencedJson({ reasoning: "r", score })),
      );
    });
    _setBedrockClient(
      { send } as unknown as Parameters<typeof _setBedrockClient>[0],
    );

    const { written } = setupDynamoMock([
      {
        runId: RUN_ID,
        caseId: CASE_ID_A,
        trace: makeTrace(),
        transcript: makeTranscript(),
        snapshot: makeSnapshot(),
      },
      {
        runId: RUN_ID,
        caseId: CASE_ID_B,
        trace: makeTrace(),
        transcript: makeTranscript(),
        snapshot: makeSnapshot(),
      },
    ]);
    _setDynamoService(makeServiceForMockedDynamo());

    const output = await handler({
      runId: RUN_ID,
      caseResults: [
        makeResult({ caseId: CASE_ID_A }),
        makeResult({ caseId: CASE_ID_B }),
      ],
      testCases: [
        makeTestCase({ caseId: CASE_ID_A }),
        makeTestCase({ caseId: CASE_ID_B }),
      ],
    });

    // Both cases got persisted (Req 8.7).
    expect(written).toHaveLength(2);
    const a = written.find((r) => r.caseId === CASE_ID_A)!;
    const b = written.find((r) => r.caseId === CASE_ID_B)!;
    expect(a.PK).toBe(`RUN#${RUN_ID}`);
    expect(a.SK).toBe(`CASE#${CASE_ID_A}`);
    expect(b.PK).toBe(`RUN#${RUN_ID}`);
    expect(b.SK).toBe(`CASE#${CASE_ID_B}`);

    // Case A scored cleanly.
    expect(a.evaluationError).toBeUndefined();
    expect(a.goalSuccessScore).toBe(1.0);

    // Case B errored — JUDGE_ERROR persisted, scores unset (Property 12).
    expect((b.evaluationError as { code: string }).code).toBe("JUDGE_ERROR");
    expect((b.evaluationError as { reason: string }).reason).toMatch(
      /ThrottlingException|Throttled/,
    );
    expect(b.goalSuccessScore).toBeUndefined();
    expect(b.helpfulnessScore).toBeUndefined();
    expect(b.toolAccuracyScore).toBeUndefined();

    // The Lambda's summary distinguishes scored vs error cases without
    // marking the run as failed (Req 8.7).
    expect(output.evaluated).toBe(2);
    expect(output.evaluationErrors).toBe(1);
    expect(output.errors).toBe(0);
  });

  it("counts an unmatched caseId as an error and skips it without writing or invoking the judge", async () => {
    const mock = makeBedrockMock(() => ({ reasoning: "r", score: "Yes" }));
    _setBedrockClient(mock.client);

    const { written } = setupDynamoMock([
      {
        runId: RUN_ID,
        caseId: CASE_ID_A,
        trace: makeTrace(),
        transcript: makeTranscript(),
        snapshot: makeSnapshot(),
      },
    ]);
    _setDynamoService(makeServiceForMockedDynamo());

    const output = await handler({
      runId: RUN_ID,
      caseResults: [makeResult({ caseId: "unknown-case" })],
      testCases: [makeTestCase({ caseId: CASE_ID_A })],
    });

    expect(mock.send).not.toHaveBeenCalled();
    expect(written).toHaveLength(0);
    expect(output.evaluated).toBe(0);
    expect(output.errors).toBe(1);
  });

  it("reads from the legacy `results` field for direct invocations", async () => {
    const mock = makeBedrockMock((id) =>
      id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "g", score: "Yes" },
    );
    _setBedrockClient(mock.client);

    const { written } = setupDynamoMock([
      {
        runId: RUN_ID,
        caseId: CASE_ID_A,
        trace: makeTrace(),
        transcript: makeTranscript(),
        snapshot: makeSnapshot(),
      },
    ]);
    _setDynamoService(makeServiceForMockedDynamo());

    await handler({
      runId: RUN_ID,
      results: [makeResult({ caseId: CASE_ID_A })],
      testCases: [makeTestCase({ caseId: CASE_ID_A })],
    } as EvaluationInput);

    expect(written).toHaveLength(1);
    expect(written[0].caseId).toBe(CASE_ID_A);
  });
});

// ---------------------------------------------------------------------------
// Wave-2 (Task 17.6 / 17.8) — every Converse the Lambda dispatches carries
// the registry-resolved `(modelId, inferenceConfig)` shape.
//
// The legacy `process.env.JUDGE_MODEL_ID ?? "..."` fallback and the
// inline `inferenceConfig: { maxTokens: 1024, temperature: 0 }` literal
// were retired in Wave 2. The judge client now resolves its model id
// and inference parameters via `resolvePromptForRun(promptKey, runId)`
// against the run's pinned snapshot (or the live override store when
// the snapshot lacks a `prompts` field). The Anthropic Claude 4.x
// capability profile forbids `temperature`, `topP`, `topK`, and
// `stopSequences` (R17.4), so every Converse the Evaluation Lambda
// dispatches carries `inferenceConfig.maxTokens` only — no other
// inference keys, no `additionalModelRequestFields`.
//
// _Validates: Requirements 10.1, 11.2, 17.4_
// ---------------------------------------------------------------------------

describe("Evaluation Lambda — registry-resolved (modelId, inferenceConfig) on every judge Converse (R10.1, R11.2, R17.4)", () => {
  /**
   * The four judge promptKeys the Lambda fans out across. Every one
   * defaults to `claude_sonnet_4_6` (Anthropic Claude 4.x profile) and
   * `maxTokens: 2048`; the build-invariants test in
   * `tests/unit/prompt-registry.test.ts` keeps these expectations in
   * sync with the registry definitions.
   */
  const JUDGE_PROMPT_KEYS = [
    "judge_goal_success_rate",
    "judge_helpfulness",
    "judge_tool_selection",
  ] as const;

  it("dispatches every Converse with modelId = registry-resolved Sonnet 4.6 inference profile", async () => {
    const mock = makeBedrockMock((id) =>
      id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "g", score: "Yes" },
    );
    _setBedrockClient(mock.client);

    await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    // 1 GSR + 2 Helpfulness + 2 ToolSelection = 5 calls, each with the
    // resolved Anthropic Claude Sonnet 4.6 inference profile id.
    expect(mock.send).toHaveBeenCalledTimes(5);
    const expectedModelId = SUPPORTED_MODELS.claude_sonnet_4_6.inferenceProfileId;
    for (const call of mock.send.mock.calls) {
      const cmd = call[0] as InstanceType<typeof ConverseCommand>;
      expect(cmd).toBeInstanceOf(ConverseCommand);
      expect(cmd.input.modelId).toBe(expectedModelId);
      // Sanity: matches the Anthropic US cross-region prefix.
      expect(cmd.input.modelId).toMatch(/^us\.anthropic\.claude-sonnet/);
    }

    // Sanity-check the registry default for every judge promptKey is the
    // model whose id we just asserted above. If the registry's
    // `defaultModelKey` ever drifts, this assertion catches it before
    // the wider conformance probe runs.
    for (const key of JUDGE_PROMPT_KEYS) {
      expect(PROMPT_REGISTRY[key].defaultModelKey).toBe("claude_sonnet_4_6");
    }
  });

  it("emits an inferenceConfig whose key set matches the Anthropic Claude 4.x profile (maxTokens only)", async () => {
    const mock = makeBedrockMock((id) =>
      id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "g", score: "Yes" },
    );
    _setBedrockClient(mock.client);

    await evaluateCaseSession({
      trace: makeTrace(),
      transcript: makeTranscript(),
      snapshot: makeSnapshot(),
      expectedToolNames: ["AuthenticateUser", "SearchFlights"],
    });

    expect(mock.send).toHaveBeenCalledTimes(5);
    for (const call of mock.send.mock.calls) {
      const cmd = call[0] as InstanceType<typeof ConverseCommand>;
      const inferenceConfig = cmd.input.inferenceConfig ?? {};
      // R17.4: Anthropic Claude 4.x accepts `maxTokens` only. The other
      // four Converse keys (`temperature`, `topP`, `topK`,
      // `stopSequences`) are forbidden by the profile and silently
      // dropped by `buildInferenceConfig`.
      expect(Object.keys(inferenceConfig).sort()).toEqual(["maxTokens"]);
      expect(inferenceConfig.maxTokens).toBe(2048);
      expect(inferenceConfig.temperature).toBeUndefined();
      expect(inferenceConfig.topP).toBeUndefined();
      // No `additionalModelRequestFields` for Anthropic — only Nova
      // carries `topK` under that field.
      expect(cmd.input.additionalModelRequestFields).toBeUndefined();
    }
  });

  it("propagates the runId through the handler so the resolver consults the run-pinned snapshot", async () => {
    // The Lambda is invoked through the `handler(event)` entrypoint.
    // The `runId` field on the event must reach the judge client (and
    // therefore `resolvePromptForRun(promptKey, runId)`) on every
    // Converse call. We assert this indirectly by inspecting the
    // injected Prompts_Store: its `getSnapshot` mock receives the same
    // `runId` the handler was called with.
    const mock = makeBedrockMock((id) =>
      id === "Builtin.Helpfulness"
        ? { reasoning: "h", score: "Very Helpful" }
        : { reasoning: "g", score: "Yes" },
    );
    _setBedrockClient(mock.client);

    // Wire a fresh promptStore so we can spy on its `getSnapshot` calls
    // — the suite-wide `beforeEach` already installed one, but we want
    // the spy on a stable handle for these assertions.
    _clearPromptRegistryCaches();
    const getSnapshotSpy = vi.fn().mockResolvedValue(null);
    const listOverridesSpy = vi.fn().mockResolvedValue(new Map());
    const promptStore = {
      getSnapshot: getSnapshotSpy,
      listPromptOverrides: listOverridesSpy,
    } as unknown as Parameters<typeof _setPromptRegistryStore>[0];
    _setPromptRegistryStore(promptStore);

    setupDynamoMock([
      {
        runId: RUN_ID,
        caseId: CASE_ID_A,
        trace: makeTrace(),
        transcript: makeTranscript(),
        snapshot: makeSnapshot(),
      },
    ]);
    _setDynamoService(makeServiceForMockedDynamo());

    await handler({
      runId: RUN_ID,
      caseResults: [makeResult({ caseId: CASE_ID_A })],
      testCases: [makeTestCase({ caseId: CASE_ID_A })],
    });

    // The runtime resolver caches the snapshot lookup per Lambda warm
    // invocation, so a single `getSnapshot(RUN_ID)` services every
    // judge call within this case. The important invariant is that
    // every consultation used the same runId the handler was called
    // with — proof the runId plumbed through `evaluateCaseSession` →
    // `runUnit` → `judge` → `resolvePromptForRun` without being
    // dropped or substituted.
    expect(getSnapshotSpy.mock.calls.length).toBeGreaterThan(0);
    for (const args of getSnapshotSpy.mock.calls) {
      expect(args[0]).toBe(RUN_ID);
    }
  });
});
