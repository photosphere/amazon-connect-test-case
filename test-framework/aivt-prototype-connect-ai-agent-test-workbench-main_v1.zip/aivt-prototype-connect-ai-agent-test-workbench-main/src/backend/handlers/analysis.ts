/**
 * Analysis Lambda — POST /runs/{runId}/analyze
 *
 * Gathers failed test cases, their transcripts, reasoning traces (from ListSpans),
 * and the agent configuration snapshot. Calls Bedrock to determine root causes and
 * generate actionable recommendations (proposed edits in diff format).
 *
 * Behavior added by the actionable-recommendations feature (task 6):
 *   - Persisted-read shortcut at `PK=RUN#{runId}, SK begins_with ANALYSIS#CASE#`:
 *     when N persisted records exist for N failed cases AND `force !== true`,
 *     return the persisted records without invoking Bedrock (R6.2, R10.9).
 *   - `force: true` request flag bypasses the shortcut and overwrites every
 *     persisted record with new `generatedAt` timestamps (R6.3).
 *   - The `Examples:` block is rendered after `Instruction:` in the formatted
 *     tool definitions, with the literal string `Examples: (none)` for empty
 *     arrays (R5.7, R14.1, R14.2). The instructions block enumerates all four
 *     valid `targetField` values and the three `tool_examples` operations
 *     (R14.3).
 *   - Recommendations whose `targetField` is not one of the four `ToolSurface`
 *     values, whose `targetName` is empty, or whose `currentText`/`suggestedText`
 *     pair encodes a no-op are dropped before persistence (R5.9, R13.3).
 *   - Each surviving per-case analysis is persisted to
 *     `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` with `generatedAt` and
 *     `modelId`. On DDB write failure, the response still carries the
 *     analysis and surfaces the failed case IDs on `partialFailures` (R6.6).
 *   - Snapshot reads with a malformed `examples` field (present but not a
 *     JSON array) abort with HTTP 500 `{ error: "snapshot_examples_malformed",
 *     toolName }` (R5.8).
 *   - Bedrock calls are wrapped in {@link withThrottleRetry} with
 *     `(baseMs: 1000, capMs: 10000, maxRetries: 2)` for `ThrottlingException`;
 *     on terminal throttle the handler returns HTTP 503 with `retryable: true`
 *     (R12.1, R12.2).
 *   - Response shape is the flat `caseAnalyses[]` form (the legacy
 *     `individualAnalyses` / `groupedAnalyses` split is retired; the frontend
 *     re-groups for display via `src/shared/utils/failure-grouping.ts`).
 *
 * @module analysis
 */

import {
  BedrockRuntimeClient,
  ConverseCommand,
  type ConverseCommandInput,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PK_PATTERNS, SK_PATTERNS } from "../../shared/constants";
import { CaseStatus } from "../../shared/enums";
import type {
  AgentSnapshot,
  ExecutionTrace,
  ExecutionStep,
  Recommendation,
  RecommendationTarget,
  TestCaseResult,
  TestCaseTargetField,
  ToolDefinition,
  ToolSequenceTestCase,
  TranscriptTurn,
} from "../../shared/types";
import {
  groupFailuresByRootCause,
  type FailureCaseAnalysis,
  type FailureGroup,
} from "../../shared/utils/failure-grouping";
import { withThrottleRetry } from "../../shared/utils/backoff";
import {
  buildInferenceConfig,
  type ResolvedPrompt,
} from "../orchestration/prompt-registry";
import { resolvePromptLive } from "../orchestration/prompt-registry/runtime";

// Re-export the shared grouping helpers and types so existing callers (the
// unit tests in `tests/unit/analysis.test.ts`, the property test in
// `tests/unit/properties/failure-grouping.test.ts`, and any other module
// that has been importing them from this handler) continue to resolve. The
// canonical implementation lives in `src/shared/utils/failure-grouping.ts`
// (extracted in task 5 of the actionable-recommendations spec) so the
// frontend can consume the same code without pulling in this Lambda's
// AWS SDK dependencies.
export { groupFailuresByRootCause };
export type { FailureCaseAnalysis, FailureGroup, Recommendation };

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";
const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";
// The model id, system prompt text, and `maxTokens` cap for this Lambda
// all come from the Prompt_Registry via `resolvePromptLive("failure_analysis")`.
// The legacy `ANALYSIS_MODEL_ID` env var is still set in
// `lib/api-construct.ts` as a Wave-1 safety net and is removed in Wave 3
// (per the prompt-management migration plan).

/**
 * SK prefix for persisted per-case analyses. Records live at
 * `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` (R6.1).
 */
const ANALYSIS_CASE_SK_PREFIX = "ANALYSIS#CASE#";

/**
 * The five `RecommendationTarget` values a recommendation may target.
 * Recommendations whose `targetField` is not in this set are dropped before
 * persistence per R5.9 / R6.5 and the dropped record is logged for diagnostics.
 */
const VALID_TARGET_FIELDS: ReadonlySet<RecommendationTarget> = new Set<RecommendationTarget>([
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
  "test_case",
]);

/**
 * The five valid `TestCaseTargetField` values that a `test_case`
 * recommendation must carry. Recommendations with `targetField === "test_case"`
 * whose `testCaseField` is not in this set are dropped before persistence.
 */
const VALID_TEST_CASE_FIELDS: ReadonlySet<TestCaseTargetField> = new Set<TestCaseTargetField>([
  "successCriteria",
  "initialUtterance",
  "persona",
  "customerKnowledge",
  "goalDescription",
]);

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/**
 * Per-case analysis result persisted under
 * `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}` and returned in the response
 * `caseAnalyses[]` array.
 */
export interface PerCaseAnalysis {
  caseId: string;
  rootCauseCategory: string;
  explanation: string;
  traceAvailable: boolean;
  recommendations: Recommendation[];
  /** ISO 8601 timestamp the analysis was generated. */
  generatedAt: string;
  /** Bedrock model id that produced the analysis. */
  modelId: string;
  /**
   * Resolved `failure_analysis` prompt version that produced this analysis.
   * `0` means the bundled default was used (no override in effect).
   * Absent on records persisted before the trace-reasoning-and-latency
   * feature deployed (R12.1).
   */
  failureAnalysisPromptVersion?: number;
  /**
   * Convenience boolean for UI consumers: `true` when
   * `rootCauseCategory === "test_case_defect"`. Absent (treated as `false`)
   * on records persisted before the test-case-validity-analysis feature
   * deployed (R8.5).
   */
  testCaseDefect?: boolean;
}

/**
 * Response shape for the analysis endpoint (R5/R6 redesign).
 *
 * The legacy `individualAnalyses` / `groupedAnalyses` split has been retired.
 * Grouping by root cause is a frontend concern handled via the shared
 * `failure-grouping` util.
 */
export interface AnalysisResponse {
  /** Flat list of per-case analyses, one entry per failed case. */
  caseAnalyses: PerCaseAnalysis[];
  /** Newest of `caseAnalyses[].generatedAt`, or the response time on empty. */
  generatedAt: string;
  /** Bedrock model id used. Consistent across cases in one call. */
  modelId: string;
  /**
   * Case IDs whose analysis succeeded but whose persistence to DDB failed
   * (R6.6). Absent when every persistence attempt succeeded.
   */
  partialFailures?: string[];
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

let bedrockClient: BedrockRuntimeClient | null = null;
let ddbDocClient: DynamoDBDocumentClient | null = null;

function getBedrockClient(): BedrockRuntimeClient {
  if (!bedrockClient) {
    bedrockClient = new BedrockRuntimeClient({ region: REGION });
  }
  return bedrockClient;
}

function getDDBClient(): DynamoDBDocumentClient {
  if (!ddbDocClient) {
    const ddbClient = new DynamoDBClient({});
    ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return ddbDocClient;
}

/** @internal — allows test injection */
export function _setBedrockClient(client: BedrockRuntimeClient | null): void {
  bedrockClient = client;
}

/** @internal — allows test injection */
export function _setDDBClient(client: DynamoDBDocumentClient | null): void {
  ddbDocClient = client;
}

// ---------------------------------------------------------------------------
// Sentinel errors used to propagate handler-level HTTP responses
// ---------------------------------------------------------------------------

/**
 * Raised when a snapshot record carries an `examples` field that is present
 * but is not a JSON array. Surfaces as HTTP 500 `{ error:
 * "snapshot_examples_malformed", toolName }` per R5.8.
 */
class SnapshotExamplesMalformedError extends Error {
  constructor(public readonly toolName: string) {
    super(`Snapshot tool "${toolName}" has a malformed examples field`);
    this.name = "SnapshotExamplesMalformedError";
  }
}

// ---------------------------------------------------------------------------
// DynamoDB access helpers
// ---------------------------------------------------------------------------

/**
 * Get all failed test case results for a run.
 */
async function getFailedResults(runId: string): Promise<TestCaseResult[]> {
  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}`,
        ":skPrefix": SK_PATTERNS.CASE,
      },
    })
  );

  const allResults = (result.Items || []) as TestCaseResult[];
  return allResults.filter((r) => r.status === CaseStatus.FAILED);
}

/**
 * Get the transcript for a specific case within a run.
 */
async function getTranscript(
  runId: string,
  caseId: string
): Promise<TranscriptTurn[]> {
  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
        ":skPrefix": SK_PATTERNS.TURN,
      },
      ScanIndexForward: true,
    })
  );
  return (result.Items || []) as TranscriptTurn[];
}

/**
 * Get the execution trace for a specific case within a run.
 * Returns null if no trace is stored (ListSpans failed or returned empty).
 */
async function getReasoningTrace(
  runId: string,
  caseId: string
): Promise<ExecutionTrace | null> {
  const client = getDDBClient();
  try {
    const result = await client.send(
      new GetCommand({
        TableName: TABLE_NAME,
        Key: {
          PK: `${PK_PATTERNS.RUN}${runId}#${SK_PATTERNS.CASE}${caseId}`,
          SK: SK_PATTERNS.TRACE,
        },
      })
    );
    if (!result.Item) return null;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { PK, SK, ...data } = result.Item;
    // `steps` is stored as a JSON string to keep the item compact.
    const steps =
      typeof data.steps === "string"
        ? (JSON.parse(data.steps) as ExecutionStep[])
        : ((data.steps as ExecutionStep[]) ?? []);
    return {
      sessionId: (data.sessionId as string) ?? "",
      steps,
      toolSequence: (data.toolSequence as string[]) ?? [],
      aiAgentName: data.aiAgentName as string | undefined,
      aiAgentType: data.aiAgentType as string | undefined,
      capturedAt: (data.capturedAt as string) ?? "",
    };
  } catch {
    // If trace retrieval fails, proceed without it per Req 12.7
    return null;
  }
}

/**
 * Fetch the full test case definition from DynamoDB for prompt inclusion.
 * Key: PK=SUITE#{suiteId}, SK=CASE#{caseId}.
 *
 * Returns the full ToolSequenceTestCase record or null if not found
 * (case deleted between run and analysis) or if the case is a RAG type.
 */
export async function getTestCaseDefinition(
  suiteId: string,
  caseId: string,
): Promise<ToolSequenceTestCase | null> {
  const client = getDDBClient();
  const result = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.SUITE}${suiteId}`,
        SK: `${SK_PATTERNS.CASE}${caseId}`,
      },
    }),
  );
  if (!result.Item) return null;
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { PK, SK, ...data } = result.Item as Record<string, unknown>;
  // Return null for RAG-type cases — only tool_sequence cases are relevant
  if (data.type === "rag") return null;
  return data as unknown as ToolSequenceTestCase;
}

/**
 * Get the agent snapshot for a run, normalizing each tool's `examples`
 * field on read (R3.3 — pre-feature snapshots have no `examples` field
 * and the normalization treats absence as `[]`).
 *
 * When a snapshot record carries an `examples` field that is present but
 * is not a JSON array, throws {@link SnapshotExamplesMalformedError} so
 * the handler can map it to HTTP 500 `{ error:
 * "snapshot_examples_malformed", toolName }` per R5.8.
 */
async function getAgentSnapshot(runId: string): Promise<AgentSnapshot | null> {
  const client = getDDBClient();
  const result = await client.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: SK_PATTERNS.SNAPSHOT,
      },
    })
  );
  if (!result.Item) return null;
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { PK, SK, ...data } = result.Item;
  const snapshot = data as unknown as AgentSnapshot;

  // Normalize each tool's `examples` field. When the field is present but
  // not an array, abort with R5.8's malformed error.
  const tools = (snapshot.tools ?? []) as Array<
    ToolDefinition & { examples?: unknown }
  >;
  const normalizedTools: ToolDefinition[] = tools.map((tool) => {
    const raw = (tool as { examples?: unknown }).examples;
    if (raw === undefined || raw === null) {
      return { ...tool, examples: [] };
    }
    if (!Array.isArray(raw)) {
      throw new SnapshotExamplesMalformedError(tool.toolName ?? "(unknown)");
    }
    return { ...tool, examples: raw as string[] };
  });

  return { ...snapshot, tools: normalizedTools };
}

/**
 * Read all persisted per-case analyses for a run. Strips the `PK`/`SK`
 * keys and returns the records in DDB Query order (which is sorted on the
 * sort key, so deterministic across reads).
 */
async function getPersistedCaseAnalyses(
  runId: string
): Promise<PerCaseAnalysis[]> {
  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.RUN}${runId}`,
        ":skPrefix": ANALYSIS_CASE_SK_PREFIX,
      },
    })
  );
  return (result.Items ?? []).map((item) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { PK, SK, ...rest } = item as Record<string, unknown>;
    return rest as unknown as PerCaseAnalysis;
  });
}

/**
 * Persist a single per-case analysis to
 * `PK=RUN#{runId}, SK=ANALYSIS#CASE#{caseId}`.
 *
 * Returns `true` on success, `false` on any DDB write failure. Failures are
 * logged but never throw — the caller continues so a transient DDB error
 * does not block the user from seeing recommendations (R6.6). The failed
 * case ID is then surfaced on the response's `partialFailures` array.
 */
async function persistCaseAnalysis(
  runId: string,
  analysis: PerCaseAnalysis
): Promise<boolean> {
  const client = getDDBClient();
  try {
    await client.send(
      new PutCommand({
        TableName: TABLE_NAME,
        Item: {
          PK: `${PK_PATTERNS.RUN}${runId}`,
          SK: `${ANALYSIS_CASE_SK_PREFIX}${analysis.caseId}`,
          ...analysis,
        },
      })
    );
    return true;
  } catch (error) {
    console.error(
      `[analysis] Persistence failed for case ${analysis.caseId}:`,
      error instanceof Error ? error.message : error
    );
    return false;
  }
}

// ---------------------------------------------------------------------------
// Bedrock prompt construction
// ---------------------------------------------------------------------------

/**
 * Format a transcript into a readable conversation log.
 */
function formatTranscript(turns: TranscriptTurn[]): string {
  if (turns.length === 0) return "(empty transcript)";
  return turns
    .map((t) => {
      const toolInfo = t.toolSelected ? ` [Tool: ${t.toolSelected}]` : "";
      return `[Turn ${t.turnNumber}] ${t.role.toUpperCase()}${toolInfo}: ${t.text}`;
    })
    .join("\n");
}

/**
 * Format an execution trace into a readable, analysis-friendly summary.
 *
 * Surfaces the agent's reasoning/output text alongside each tool call's
 * arguments, result, and success/failure — the evidence the analyzer uses to
 * pinpoint why a tool was (or wasn't) selected and why it failed.
 */
function formatReasoningTrace(trace: ExecutionTrace): string {
  if (!trace.steps || trace.steps.length === 0) {
    return "(no reasoning steps available)";
  }

  const header =
    `Handled by: ${trace.aiAgentName ?? "unknown"} (${trace.aiAgentType ?? "unknown"})\n` +
    `Tool sequence: ${trace.toolSequence.join(" → ") || "(none)"}\n`;

  const truncate = (s: string, n: number) =>
    s.length > n ? s.slice(0, n) + "…" : s;

  const body = trace.steps
    .map((step) => {
      if (step.type === "tool" && step.tool) {
        const t = step.tool;
        const args = t.arguments !== undefined ? truncate(JSON.stringify(t.arguments), 300) : "(none)";
        const result = t.result !== undefined ? truncate(JSON.stringify(t.result), 400) : "(none)";
        const outcome = t.success ? "SUCCESS" : "ERROR";
        return [
          `Step ${step.index} — TOOL: ${t.toolName} [${outcome}]`,
          `  Arguments: ${args}`,
          `  Result: ${result}`,
        ].join("\n");
      }
      if (step.type === "inference" && step.text) {
        return `Step ${step.index} — AGENT: ${truncate(step.text, 400)}`;
      }
      return null;
    })
    .filter((line): line is string => line !== null)
    .join("\n\n");

  return `${header}\n${body}`;
}

/**
 * Format tool definitions for inclusion in the analysis prompt.
 *
 * Renders each tool as:
 *
 *     Tool: <name>
 *       Description: <text>
 *       Instruction: <text>           // omitted when absent
 *       Examples:
 *         1. <example 1>
 *         2. <example 2>
 *
 * When `tool.examples.length === 0`, renders `  Examples: (none)` on a
 * single line so the model receives an explicit no-examples marker rather
 * than the section being silently absent (R5.7, R14.1, R14.2).
 *
 * The Examples block is rendered immediately after `Instruction:` (R14.1).
 * When `instruction` is absent the Examples block follows `Description:`
 * directly. The literal `(none)` is the empty marker — distinguishable from
 * a real example with text `(none)` because the latter would render as
 * `1. (none)` with the numbered prefix.
 */
function formatTools(tools: ToolDefinition[]): string {
  return tools
    .map((t) => {
      const parts = [`Tool: ${t.toolName}`, `  Description: ${t.description}`];
      if (t.instruction) parts.push(`  Instruction: ${t.instruction}`);
      const examples = Array.isArray(t.examples) ? t.examples : [];
      if (examples.length === 0) {
        parts.push(`  Examples: (none)`);
      } else {
        parts.push(`  Examples:`);
        examples.forEach((ex, i) => {
          parts.push(`    ${i + 1}. ${ex}`);
        });
      }
      return parts.join("\n");
    })
    .join("\n\n");
}

/**
 * Build the `## Reasoning trace` section from an execution trace.
 *
 * Returns the formatted section string (including the heading) when at least
 * one step carries a non-empty `reasoning` field, or `undefined` when no step
 * qualifies — ensuring byte-identical output to the prior renderer for
 * pre-feature traces.
 *
 * Format per entry:
 *   [step N · timestamp]
 *   reasoning text verbatim
 *
 * Entries are in chronological order (sorted by index), separated by blank
 * lines. Reasoning text is preserved verbatim (no truncation, no
 * normalization).
 */
function buildReasoningTraceSection(
  trace: ExecutionTrace | null,
): string | undefined {
  if (!trace || !trace.steps || trace.steps.length === 0) return undefined;

  const stepsWithReasoning = trace.steps
    .filter(
      (step): step is ExecutionStep & { reasoning: string } =>
        typeof step.reasoning === "string" && step.reasoning.length > 0,
    )
    .sort((a, b) => a.index - b.index);

  if (stepsWithReasoning.length === 0) return undefined;

  const entries = stepsWithReasoning.map(
    (step) =>
      `[step ${step.index} · ${step.timestamp ?? ""}]\n${step.reasoning}`,
  );

  return `## Reasoning trace\n${entries.join("\n\n")}`;
}

/**
 * Render the `## Test Case Definition` section for inclusion in the
 * per-case analysis prompt. Placed immediately after `## Test Case: {caseId}`
 * and before `## Conversation Transcript`.
 *
 * When the test case record is null (deleted between run execution and
 * analysis), renders a fallback message per Requirement 1.7.
 */
export function renderTestCaseDefinition(
  testCase: ToolSequenceTestCase | null,
): string {
  if (!testCase) {
    return "## Test Case Definition\n(Test case record not found — analysis will proceed without test case context)";
  }

  const lines: string[] = ["## Test Case Definition"];
  lines.push(`Name: ${testCase.name}`);
  lines.push(`Description: ${testCase.description}`);
  lines.push(`Persona: ${testCase.persona}`);
  lines.push(`Style: ${testCase.style}`);
  lines.push(`Initial Utterance: ${testCase.initialUtterance}`);
  lines.push(
    `Goal: ${testCase.goalDescription?.trim() || "(not specified)"}`,
  );

  // Customer Knowledge
  const entries = Object.entries(testCase.customerKnowledge ?? {});
  if (entries.length === 0) {
    lines.push("Customer Knowledge: (none)");
  } else {
    lines.push("Customer Knowledge:");
    for (const [key, value] of entries) {
      lines.push(`  - ${key}: ${value}`);
    }
  }

  // Success Criteria
  lines.push("Success Criteria:");
  const criteria = testCase.successCriteria ?? [];
  criteria.forEach((step, idx) => {
    lines.push(
      `  ${idx + 1}. ${step.toolName} (required: ${step.required})`,
    );
    if (step.parameterChecks && step.parameterChecks.length > 0) {
      for (const pc of step.parameterChecks) {
        lines.push(`    - ${pc.paramName} = ${pc.expectedValue}`);
      }
    }
  });

  return lines.join("\n");
}

/**
 * Build the Bedrock analysis prompt for a failed test case.
 *
 * The `testCaseDefinition` parameter (added by the test-case-validity-analysis
 * feature) enables the LLM to evaluate whether the test case's expectations
 * are reasonable. When non-null, a `## Test Case Definition` section is
 * rendered between the `## Test Case:` header and `## Conversation Transcript`.
 */
export function buildAnalysisPrompt(params: {
  caseId: string;
  testCaseDefinition: ToolSequenceTestCase | null;
  transcript: TranscriptTurn[];
  reasoningTrace: ExecutionTrace | null;
  expectedTools: string[];
  actualTools: string[];
  agentTools: ToolDefinition[];
  systemPrompt: string;
}): string {
  const {
    caseId,
    testCaseDefinition,
    transcript,
    reasoningTrace,
    expectedTools,
    actualTools,
    agentTools,
    systemPrompt,
  } = params;

  const traceSection = reasoningTrace
    ? formatReasoningTrace(reasoningTrace)
    : "(Reasoning trace unavailable — ListSpans returned no data or failed. Analyze using transcript and tool sequences only.)";

  const traceNote = reasoningTrace
    ? "Use evidence from the reasoning trace to support your explanation."
    : "NOTE: Reasoning trace is unavailable. Base your analysis on the transcript and tool sequences. Mention that trace evidence was unavailable in your explanation.";

  let userMessage = `Analyze the following failed test case and determine the root cause.

## Test Case: ${caseId}

${renderTestCaseDefinition(testCaseDefinition)}

## Conversation Transcript
${formatTranscript(transcript)}

## Agent Reasoning Trace
${traceSection}

## Expected Tool Sequence
${expectedTools.length > 0 ? expectedTools.join(" → ") : "(none specified)"}

## Actual Tool Sequence
${actualTools.length > 0 ? actualTools.join(" → ") : "(no tools invoked)"}

## Agent Configuration — Tool Descriptions
${formatTools(agentTools)}

## Agent System Prompt
${systemPrompt}

## Instructions
${traceNote}

Analyze why this test case failed. Determine:
1. The root cause category (choose ONE from: overlapping_tool_descriptions, missing_disambiguation, incorrect_tool_prioritization, incomplete_tool_description, system_prompt_gap, missing_tool_instruction, parameter_mismatch, test_case_defect, other)

   - test_case_defect: The agent's reasoning trace shows it made a correct decision based on its instructions, but the test case expected different behavior. The test case's expectations are unreasonable, contradictory, or impossible. Prefer this over "other" when the reasoning trace provides clear evidence that the agent deliberately chose not to invoke an expected tool because its instructions prohibit that action without a prerequisite the test did not arrange.

   - When the reasoning trace is unavailable, test_case_defect MAY still be assigned if the test case definition alone provides sufficient evidence (e.g., success criteria requiring a tool not in the agent's configuration, persona contradicting expected behavior), but note reduced confidence in the explanation.

   - When uncertain, default to an agent-deficiency category rather than test_case_defect.

2. A plain-language explanation of what went wrong, citing specific evidence from the reasoning trace (if available) or transcript
3. Between 1 and 5 actionable recommendations, each proposing a specific text edit to fix the issue

The five valid \`targetField\` values are \`tool_description\`, \`tool_instruction\`, \`tool_examples\`, \`system_prompt\`, and \`test_case\`.

For agent-targeted recommendations: the \`targetName\` is the tool name for any \`tool_*\` recommendation, or the literal string \`system_prompt\` for a \`system_prompt\` recommendation.

For \`test_case\` recommendations:
- Set \`targetName\` to the caseId of the test case.
- Include a \`testCaseField\` property with one of: \`successCriteria\`, \`initialUtterance\`, \`persona\`, \`customerKnowledge\`, \`goalDescription\`.
  - successCriteria: when the expected tool sequence is wrong or too strict
  - initialUtterance: when the opening message doesn't align with the expected path
  - persona: when the persona makes the expected behavior impossible
  - customerKnowledge: when missing/wrong context prevents the expected tool invocations
  - goalDescription: when the goal statement contradicts the success criteria
- \`test_case\` recommendations are ONLY valid when rootCauseCategory is \`test_case_defect\`.
- Produce at most ONE \`test_case\` recommendation per case (the single most impactful edit).

For \`tool_examples\` recommendations, structure each one as exactly one of three operations: (1) **add** — set \`currentText\` to the empty string and \`suggestedText\` to the new example; (2) **remove** — set \`currentText\` to the exact existing example string and \`suggestedText\` to the empty string; (3) **replace** — set \`currentText\` to the exact existing example string and \`suggestedText\` to its replacement.

For \`tool_examples\` remove and replace operations, the value of \`currentText\` MUST match an entry in that tool's \`Examples:\` block character-for-character (no trimming, no quote-stripping, no case folding). Do not invent example text that is not present in the snapshot.

## Sound Decision Signal Detection

Compare the agent's reasoning trace against the test case's success criteria. Look for these patterns:
  (a) Agent cites its instructions as the reason for not invoking a tool
  (b) Agent cites safety or compliance guardrails
  (c) Agent cites missing prerequisite information that the persona/session data did not provide
  (d) Agent cites ambiguity requiring clarification before acting

When the reasoning trace contains a Sound Decision Signal that directly conflicts with a \`required: true\` tool in the success criteria, classify as \`test_case_defect\` UNLESS there is stronger evidence that the agent's reasoning was itself flawed (e.g., hallucinated a constraint not in its system prompt).

Include a direct quote from the reasoning trace in the explanation to let the reviewer verify the classification.

When the success criteria contain a tool name that does not appear in the agent's tool configuration, flag this as a strong \`test_case_defect\` signal.

Respond in the following JSON format ONLY (no markdown code fences):
{
  "rootCauseCategory": "category_name",
  "explanation": "Plain language explanation with evidence...",
  "recommendations": [
    {
      "targetField": "tool_description|tool_instruction|tool_examples|system_prompt|test_case",
      "targetName": "tool name, system_prompt, or case_id",
      "currentText": "the current text that should be changed",
      "suggestedText": "the suggested replacement",
      "rationale": "why this change helps",
      "testCaseField": "successCriteria|initialUtterance|persona|customerKnowledge|goalDescription"
    }
  ]
}

Note: The \`testCaseField\` property is ONLY present on recommendations where \`targetField\` is \`test_case\`. Omit it for all other recommendation types.`;

  // Append the reasoning trace section when at least one step carries
  // non-empty reasoning. When absent, the output is byte-identical to the
  // prior renderer (backward compatibility for pre-feature traces).
  const reasoningSection = buildReasoningTraceSection(reasoningTrace);
  if (reasoningSection) {
    userMessage += `\n\n${reasoningSection}`;
  }

  return userMessage;
}

// ---------------------------------------------------------------------------
// Bedrock invocation
// ---------------------------------------------------------------------------

/**
 * Call Bedrock to analyze a single failed test case.
 *
 * Wraps the Converse call in {@link withThrottleRetry} with the retry
 * posture mandated by R12.1 (`baseMs: 1000`, `capMs: 10000`, `maxRetries: 2`).
 * On terminal `ThrottlingException` the error is re-thrown so the handler
 * can map it to HTTP 503 with `retryable: true` (R12.2).
 *
 * Other Bedrock errors (parse failure, AccessDenied, etc.) return `null`
 * so the handler can record an "analysis_unavailable" fallback for that
 * case rather than failing the whole run.
 *
 * The `prompt` argument is the {@link ResolvedPrompt} returned by
 * `resolvePromptLive("failure_analysis")` once per handler invocation:
 * its `text` is the system prompt, its `modelId` selects the inference
 * profile, and `buildInferenceConfig(prompt)` builds the wire-shape
 * `inferenceConfig` (and any `additionalModelRequestFields`) the
 * Converse SDK expects against the model's capability profile.
 */
async function analyzeFailure(
  prompt: ResolvedPrompt,
  userPrompt: string,
): Promise<{
  rootCauseCategory: string;
  explanation: string;
  recommendations: Recommendation[];
} | null> {
  const messages: Message[] = [
    { role: "user", content: [{ text: userPrompt }] },
  ];

  // The wire-shape helper places `maxTokens` (and any future
  // capability-profile-accepted keys) into the exact arguments the
  // Converse SDK expects. For the `anthropic_claude_4x` profile this
  // emits `{ inferenceConfig: { maxTokens } }` with no `temperature`,
  // `topP`, `topK`, or `stopSequences` — those keys are forbidden by
  // the profile (R17.4), so the legacy literal `temperature: 0.2`
  // value is intentionally dropped at migration time. Same pattern as
  // `comparison-summary.ts` and `suite-recommend.ts`.
  const built = buildInferenceConfig(prompt);

  // The casts on `inferenceConfig` and `additionalModelRequestFields`
  // bridge the SDK's strict types (`InferenceConfiguration` for the
  // top-level config, `DocumentType` for the additional fields) and
  // our runtime payload — `buildInferenceConfig` already enforced the
  // exact key set against the resolved capability profile, so the
  // values are guaranteed JSON-encodable at runtime.
  const command = new ConverseCommand({
    modelId: prompt.modelId,
    system: [{ text: prompt.text }],
    messages,
    inferenceConfig:
      built.inferenceConfig as ConverseCommandInput["inferenceConfig"],
    ...(built.additionalModelRequestFields
      ? {
          additionalModelRequestFields:
            built.additionalModelRequestFields as unknown as ConverseCommandInput["additionalModelRequestFields"],
        }
      : {}),
  });

  // ThrottlingException retries are bounded by the wrapper. Other errors
  // (parse failure, network) are caught below and return null so the
  // handler records an analysis_unavailable fallback for the case.
  let response;
  try {
    response = await withThrottleRetry(
      () => getBedrockClient().send(command),
      { baseMs: 1000, capMs: 10000, maxRetries: 2 },
    );
  } catch (error) {
    const errName = (error as { name?: string } | null)?.name ?? "";
    if (errName === "ThrottlingException" || errName === "TooManyRequestsException") {
      // Re-throw so the handler can return HTTP 503 retryable=true (R12.2).
      throw error;
    }
    console.error(
      "[analysis] Bedrock analysis call failed:",
      error instanceof Error ? error.message : error,
    );
    return null;
  }

  const content = response.output?.message?.content;
  if (!content || content.length === 0 || !content[0].text) {
    return null;
  }

  const responseText = content[0].text.trim();
  return parseAnalysisResponse(responseText);
}

/**
 * Parse the Bedrock response into structured analysis data.
 * Handles both raw JSON and markdown-fenced JSON.
 *
 * Drops malformed recommendations defensively (per R5.9 / R13.3) but is
 * tolerant on the parse path — the caller (the handler) re-applies the
 * canonical filter via {@link sanitizeRecommendations} before persistence
 * so the rules cannot be bypassed by a quirk of the parser. The fallback
 * "system_prompt review" recommendation is preserved so simple tests that
 * supply zero recommendations still receive a non-empty list.
 */
export function parseAnalysisResponse(responseText: string): {
  rootCauseCategory: string;
  explanation: string;
  recommendations: Recommendation[];
} | null {
  try {
    // Strip markdown code fences if present
    let jsonStr = responseText;
    const fenceMatch = responseText.match(/```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/);
    if (fenceMatch) {
      jsonStr = fenceMatch[1];
    }

    const parsed = JSON.parse(jsonStr);

    // Validate required fields
    if (
      typeof parsed.rootCauseCategory !== "string" ||
      typeof parsed.explanation !== "string" ||
      !Array.isArray(parsed.recommendations)
    ) {
      return null;
    }

    // Clamp recommendations to 1–5. Type-shape validation only here —
    // canonical drop rules (R5.9, R13.3) are enforced separately by
    // `sanitizeRecommendations` so the same logic is applied to both
    // freshly-parsed and cached payloads.
    const recommendations: Recommendation[] = parsed.recommendations
      .slice(0, 5)
      .filter(
        (r: Record<string, unknown>) =>
          typeof r.targetField === "string" &&
          typeof r.targetName === "string" &&
          typeof r.currentText === "string" &&
          typeof r.suggestedText === "string",
      )
      .map((r: Record<string, unknown>) => {
        const rec: Recommendation = {
          targetField: r.targetField as RecommendationTarget,
          targetName: r.targetName as string,
          currentText: r.currentText as string,
          suggestedText: r.suggestedText as string,
          rationale: (r.rationale as string) ?? "",
        };
        // Include testCaseField when present (for test_case recommendations)
        if (typeof r.testCaseField === "string" && r.testCaseField) {
          rec.testCaseField = r.testCaseField as TestCaseTargetField;
        }
        return rec;
      });

    // Ensure at least 1 recommendation
    if (recommendations.length === 0) {
      recommendations.push({
        targetField: "system_prompt",
        targetName: "system_prompt",
        currentText: "(unable to identify specific text)",
        suggestedText: "(review agent configuration for the identified root cause)",
        rationale: parsed.explanation || "Root cause identified but specific edit unclear",
      });
    }

    return {
      rootCauseCategory: parsed.rootCauseCategory,
      explanation: parsed.explanation,
      recommendations,
    };
  } catch {
    return null;
  }
}

/**
 * Validate and sanitize an array of Recommendation records before persistence.
 *
 * Drops recommendations that fail any of these rules (R5.9, R13.3, R3.3–3.5):
 *   - `targetField` is not one of the five valid RecommendationTarget values.
 *   - `targetName` is empty.
 *   - Both `currentText` and `suggestedText` are empty (no-op recommendation).
 *   - `targetField === "test_case"` but `testCaseField` is missing or invalid.
 *   - `targetField === "test_case"` but `rootCauseCategory` is not `test_case_defect`.
 *
 * Additionally, strips `testCaseField` from non-`test_case` recommendations
 * (model hallucination cleanup).
 *
 * Returns the surviving recommendations in input order. Pure: no I/O
 * other than `console.warn` for the dropped records (a logging call,
 * not a state mutation).
 */
export function sanitizeRecommendations(
  caseId: string,
  recommendations: Recommendation[],
  rootCauseCategory: string,
): Recommendation[] {
  const survivors: Recommendation[] = [];
  for (const rec of recommendations) {
    if (!VALID_TARGET_FIELDS.has(rec.targetField as RecommendationTarget)) {
      console.warn(
        `[analysis] Dropped recommendation with invalid targetField "${String(rec.targetField)}" for case ${caseId}:`,
        JSON.stringify(rec),
      );
      continue;
    }
    if (!rec.targetName || rec.targetName.trim().length === 0) {
      console.warn(
        `[analysis] Dropped recommendation with empty targetName for case ${caseId}:`,
        JSON.stringify(rec),
      );
      continue;
    }
    if (
      (rec.currentText ?? "").length === 0 &&
      (rec.suggestedText ?? "").length === 0
    ) {
      console.warn(
        `[analysis] Dropped no-op recommendation (both currentText and suggestedText empty) for case ${caseId}:`,
        JSON.stringify(rec),
      );
      continue;
    }
    // test_case recommendations require a valid testCaseField
    if (rec.targetField === "test_case") {
      if (!rec.testCaseField || !VALID_TEST_CASE_FIELDS.has(rec.testCaseField)) {
        console.warn(
          `[analysis] Dropped test_case recommendation with missing/invalid testCaseField for case ${caseId}:`,
          JSON.stringify(rec),
        );
        continue;
      }
      // test_case recommendations are only valid when rootCauseCategory is test_case_defect
      if (rootCauseCategory !== "test_case_defect") {
        console.warn(
          `[analysis] Dropped test_case recommendation with non-defect rootCauseCategory "${rootCauseCategory}" for case ${caseId}:`,
          JSON.stringify(rec),
        );
        continue;
      }
    }
    // Non-test_case recommendations must NOT carry testCaseField (model hallucination cleanup)
    if (rec.targetField !== "test_case" && rec.testCaseField) {
      rec.testCaseField = undefined;
    }
    survivors.push(rec);
  }
  return survivors;
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

/** Request body for the analysis endpoint. */
export interface AnalysisRequest {
  /** The suite ID that owns this run (needed to fetch test case definitions). */
  suiteId?: string;
  /**
   * When `true`, bypass the persisted-read shortcut and re-invoke Bedrock
   * for every failed case in the run. Each persisted record is overwritten
   * and `generatedAt` is updated (R6.3).
   */
  force?: boolean;
}

/**
 * Get all test cases for a suite (to access success criteria / expected tools).
 */
async function getTestCases(
  suiteId: string
): Promise<Map<string, { expectedTools: string[] }>> {
  const client = getDDBClient();
  const result = await client.send(
    new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :skPrefix)",
      ExpressionAttributeValues: {
        ":pk": `${PK_PATTERNS.SUITE}${suiteId}`,
        ":skPrefix": SK_PATTERNS.CASE,
      },
    })
  );

  const caseMap = new Map<string, { expectedTools: string[] }>();
  for (const item of result.Items || []) {
    const caseId = item.caseId as string;
    const successCriteria = (item.successCriteria || []) as Array<{
      toolName: string;
      required: boolean;
    }>;
    // Expected tool sequence: required tools in order
    const expectedTools = successCriteria
      .filter((step) => step.required !== false)
      .map((step) => step.toolName);
    caseMap.set(caseId, { expectedTools });
  }
  return caseMap;
}

/**
 * Pick the newest `generatedAt` timestamp from a non-empty list of analyses.
 * When the list is empty, returns the current time.
 */
function newestGeneratedAt(analyses: PerCaseAnalysis[]): string {
  if (analyses.length === 0) return new Date().toISOString();
  let newest = analyses[0].generatedAt;
  for (const a of analyses) {
    if (a.generatedAt > newest) newest = a.generatedAt;
  }
  return newest;
}

/**
 * Lambda handler for POST /runs/{runId}/analyze.
 *
 * Orchestrates failure analysis with the persistence-aware flow:
 *  1. Fetch failed results and the agent snapshot. Snapshot examples-malformed
 *     short-circuits to HTTP 500 (R5.8). Missing snapshot returns HTTP 404.
 *  2. Read any persisted per-case analyses. When N persisted records exist
 *     for N failed cases AND `force !== true`, return them without invoking
 *     Bedrock (R6.2, R10.9).
 *  3. Otherwise, for each failed case, gather transcript and trace, build the
 *     prompt, call Bedrock (with retry), and parse the response.
 *  4. Drop malformed recommendations (R5.9, R13.3). Persist the surviving
 *     analysis. On DDB write failure, log and surface the case ID via
 *     `partialFailures` (R6.6).
 *  5. Return the flat `caseAnalyses[]` response.
 */
export async function handler(event: {
  pathParameters?: { runId?: string };
  body?: string;
}): Promise<{ statusCode: number; body: string; headers: Record<string, string> }> {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  };

  // Extract runId from path parameters
  const runId = event.pathParameters?.runId;
  if (!runId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Missing runId path parameter" }),
      headers,
    };
  }

  // Parse request body for suiteId / force flag
  let suiteId: string | undefined;
  let force = false;
  if (event.body) {
    try {
      const parsed = JSON.parse(event.body) as Partial<AnalysisRequest>;
      suiteId = parsed.suiteId;
      force = parsed.force === true;
    } catch {
      // Body parsing failure is non-fatal — we'll proceed without expected tools
    }
  }

  try {
    // 1. Gather failed results and the snapshot in parallel. The snapshot
    //    read normalizes per-tool `examples` and throws
    //    SnapshotExamplesMalformedError on a malformed field (R5.8).
    const [failedResults, snapshot] = await Promise.all([
      getFailedResults(runId),
      getAgentSnapshot(runId),
    ]);

    // 2. Persisted-read shortcut. When every failed case already has a
    //    persisted analysis AND `force` is not set, return the cached
    //    records without invoking Bedrock — and without paying the
    //    Prompt_Registry round-trip below — since the persisted records
    //    carry their own `modelId` and the response text is already
    //    sealed (R6.2, R10.9).
    const persisted = await getPersistedCaseAnalyses(runId);
    const failedIdSet = new Set(failedResults.map((r) => r.caseId));
    const persistedById = new Map<string, PerCaseAnalysis>();
    for (const p of persisted) {
      if (failedIdSet.has(p.caseId)) {
        persistedById.set(p.caseId, p);
      }
    }
    if (
      !force &&
      failedResults.length > 0 &&
      persistedById.size === failedResults.length
    ) {
      // Order the response in failed-results order so callers see a stable
      // ordering tied to the run's case list rather than DDB sort order.
      const ordered = failedResults
        .map((r) => persistedById.get(r.caseId))
        .filter((a): a is PerCaseAnalysis => a !== undefined);
      const response: AnalysisResponse = {
        caseAnalyses: ordered,
        generatedAt: newestGeneratedAt(ordered),
        // Both `ordered` and `failedResults` are non-empty here so
        // `ordered[0].modelId` is always defined; the fallback is
        // defensive for type narrowing.
        modelId: ordered[0]?.modelId ?? "",
      };
      return {
        statusCode: 200,
        body: JSON.stringify(response),
        headers,
      };
    }

    // 3. Resolve the live prompt (system text, model id, and `maxTokens`)
    //    from the registry. Fail-closed: if the override store read fails
    //    the resolver throws `PromptResolutionError` and the catch below
    //    maps it to a 500. Done after the persisted-read shortcut so we
    //    don't pay the registry round-trip on the cache-hit fast path.
    const prompt = await resolvePromptLive("failure_analysis");

    if (failedResults.length === 0) {
      const emptyResponse: AnalysisResponse = {
        caseAnalyses: [],
        generatedAt: new Date().toISOString(),
        modelId: prompt.modelId,
      };
      return {
        statusCode: 200,
        body: JSON.stringify(emptyResponse),
        headers,
      };
    }

    if (!snapshot) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          error: "snapshot_missing",
          message: "Agent snapshot not found for run. Cannot perform analysis.",
        }),
        headers,
      };
    }

    // 4. Fetch test case definitions to get expected tool sequences (best
    //    effort — the prompt still works without them).
    let testCaseExpectedTools = new Map<string, { expectedTools: string[] }>();
    if (suiteId) {
      testCaseExpectedTools = await getTestCases(suiteId);
    }

    // 5. For each failed case, gather transcript and reasoning trace, then
    //    analyze. ThrottlingException after retries propagates out and is
    //    mapped to HTTP 503 below.
    const caseAnalyses: PerCaseAnalysis[] = [];
    const partialFailures: string[] = [];

    for (const result of failedResults) {
      const [transcript, reasoningTrace] = await Promise.all([
        getTranscript(runId, result.caseId),
        getReasoningTrace(runId, result.caseId),
      ]);

      const expectedTools =
        testCaseExpectedTools.get(result.caseId)?.expectedTools ?? [];

      // Fetch the test case definition for inclusion in the prompt (if suiteId
      // is available). Returns null if not found or case is RAG type.
      const testCaseDefinition = suiteId
        ? await getTestCaseDefinition(suiteId, result.caseId)
        : null;

      const userPrompt = buildAnalysisPrompt({
        caseId: result.caseId,
        testCaseDefinition,
        transcript,
        reasoningTrace,
        expectedTools,
        actualTools: result.toolsInvoked,
        agentTools: snapshot.tools,
        systemPrompt: snapshot.systemPrompt,
      });

      const analysisResult = await analyzeFailure(prompt, userPrompt);

      let analysis: PerCaseAnalysis;
      if (analysisResult) {
        // Drop malformed recommendations before persistence (R5.9, R13.3).
        const sanitized = sanitizeRecommendations(
          result.caseId,
          analysisResult.recommendations,
          analysisResult.rootCauseCategory,
        );

        // Enforce targetName = caseId for validated test_case recommendations
        // (R3.2). The prompt instructs the LLM to do this, but we guarantee
        // correctness server-side regardless of model output.
        for (const rec of sanitized) {
          if (rec.targetField === "test_case") {
            rec.targetName = result.caseId;
          }
        }

        // RAG-case scoping: for RAG cases, only keep recommendations that
        // target the Retrieve tool (instruction/examples) or system_prompt.
        // Other tools' recommendations are noise — the RAG failure is about
        // retrieval quality, not tool-selection for non-RAG tools.
        let finalRecs = sanitized;
        if (result.caseType === "rag") {
          const retrieveToolName = snapshot.tools.find(
            (t) => t.toolName.toLowerCase() === "retrieve" ||
                   (t.toolType && t.toolType.toUpperCase().includes("RETRIEVE")),
          )?.toolName ?? "Retrieve";

          finalRecs = sanitized.filter((rec) => {
            if (rec.targetField === "system_prompt") return true;
            if (rec.targetField === "test_case") return true;
            // Only keep tool-targeted recs for the Retrieve tool
            return rec.targetName === retrieveToolName;
          });

          // If all recs were filtered out, add a default Retrieve instruction suggestion
          if (finalRecs.length === 0) {
            finalRecs.push({
              targetField: "tool_instruction",
              targetName: retrieveToolName,
              currentText: snapshot.tools.find((t) => t.toolName === retrieveToolName)?.instruction ?? "",
              suggestedText: "Use this tool to answer ANY informational question about mortgage products, policies, rates, fees, or account-related topics. Always retrieve from the knowledge base before generating a response from general knowledge.",
              rationale: "The agent did not invoke the Retrieve tool for an informational question, answering from general knowledge or escalating instead of searching the KB.",
            });
          }
        }

        const isTestCaseDefect =
          analysisResult.rootCauseCategory === "test_case_defect";

        analysis = {
          caseId: result.caseId,
          rootCauseCategory: analysisResult.rootCauseCategory,
          explanation: analysisResult.explanation,
          traceAvailable: reasoningTrace !== null,
          recommendations: finalRecs,
          generatedAt: new Date().toISOString(),
          modelId: prompt.modelId,
          failureAnalysisPromptVersion: prompt.version,
          // Convenience boolean for UI consumers (R8.5). Only persisted as
          // `true`; absent/undefined when false for backward compat.
          ...(isTestCaseDefect ? { testCaseDefect: true } : {}),
        };
      } else {
        // Bedrock call failed (non-throttle) — provide a fallback analysis.
        // Still persist so the user sees the same fallback on revisit
        // rather than retriggering Bedrock every time (R6.2 semantics).
        analysis = {
          caseId: result.caseId,
          rootCauseCategory: "analysis_unavailable",
          explanation: `Automated analysis could not be completed for this test case.${
            reasoningTrace === null
              ? " Additionally, reasoning trace evidence was unavailable."
              : ""
          }`,
          traceAvailable: reasoningTrace !== null,
          recommendations: [],
          generatedAt: new Date().toISOString(),
          modelId: prompt.modelId,
          failureAnalysisPromptVersion: prompt.version,
        };
      }

      caseAnalyses.push(analysis);

      // Persist on success. Failures log and continue (R6.6).
      const persistedOk = await persistCaseAnalysis(runId, analysis);
      if (!persistedOk) {
        partialFailures.push(result.caseId);
      }
    }

    // 6. Build and return the flat response.
    const response: AnalysisResponse = {
      caseAnalyses,
      generatedAt: newestGeneratedAt(caseAnalyses),
      modelId: prompt.modelId,
      ...(partialFailures.length > 0 ? { partialFailures } : {}),
    };

    return {
      statusCode: 200,
      body: JSON.stringify(response),
      headers,
    };
  } catch (error) {
    if (error instanceof SnapshotExamplesMalformedError) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "snapshot_examples_malformed",
          toolName: error.toolName,
        }),
        headers,
      };
    }
    const errName = (error as { name?: string } | null)?.name ?? "";
    if (
      errName === "ThrottlingException" ||
      errName === "TooManyRequestsException"
    ) {
      console.error(
        "[analysis] Bedrock terminal throttle:",
        error instanceof Error ? error.message : error,
      );
      return {
        statusCode: 503,
        body: JSON.stringify({
          error: "ThrottlingException",
          message: "Bedrock rate limit hit after retries. Retry shortly.",
          retryable: true,
        }),
        headers,
      };
    }
    console.error(
      "[analysis] Handler error:",
      error instanceof Error ? error.message : error
    );
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal server error during failure analysis",
        message: error instanceof Error ? error.message : "Unknown error",
      }),
      headers,
    };
  }
}
