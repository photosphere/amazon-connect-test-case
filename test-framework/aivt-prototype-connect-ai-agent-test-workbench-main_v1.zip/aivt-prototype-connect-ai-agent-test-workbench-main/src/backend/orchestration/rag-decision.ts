import type { RagMetrics, RagThresholds } from "../../shared/types";
import { DEFAULT_RAG_THRESHOLDS } from "../../shared/types";

// Re-export for downstream convenience
export type { RagMetrics, RagThresholds };
export { DEFAULT_RAG_THRESHOLDS };

/**
 * Pure, total decision function for RAG case pass/fail determination.
 *
 * Rules (R6.3):
 * 1. If faithfulness < threshold.faithfulness → "failed" (hard gate)
 * 2. If correctness >= threshold AND completeness >= threshold AND helpfulness >= threshold → "passed"
 * 3. Otherwise → "failed"
 */
export function computeRagCaseStatus(
  metrics: RagMetrics,
  thresholds: RagThresholds,
): "passed" | "failed" {
  // Rule 1: Faithfulness hard gate (dominant)
  if (metrics.faithfulness < thresholds.faithfulness) {
    return "failed";
  }
  // Rule 2: AND semantics — all remaining thresholds must be met
  if (
    metrics.correctness >= thresholds.correctness &&
    metrics.completeness >= thresholds.completeness &&
    metrics.helpfulness >= thresholds.helpfulness
  ) {
    return "passed";
  }
  // Rule 3: At least one non-faithfulness threshold not met
  return "failed";
}
