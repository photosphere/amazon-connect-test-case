/**
 * Registry build invariants for the Prompt_Registry.
 *
 * Pins five build-time invariants (R1.1, R1.2, R3.3, R17.6) so the registry
 * cannot drift from what the codebase actually executes:
 *
 *   1. **Catalog completeness.** Every member of the closed `PromptKey`
 *      union has exactly one entry, and the entry's `promptKey` matches
 *      the map key.
 *
 *   2. **Self-consistent defaults.** Every `defaultText` is non-empty and
 *      contains every declared placeholder at least once, so the
 *      stale-placeholder fallback in the resolver never fires for the
 *      bundled defaults.
 *
 *   3. **Default model membership.** Every `defaultModelKey` is in the
 *      prompt's `allowedModels[]` so the validation pipeline cannot
 *      reject the bundled default.
 *
 *   4. **Allowed-model validity.** Every `modelKey` mentioned in any
 *      prompt's `allowedModels[]` is declared in `SUPPORTED_MODELS`.
 *
 *   5. **Byte-for-byte legacy equivalence.** For every prompt whose
 *      legacy callsite carries an extractable literal, the registry's
 *      `defaultText` is byte-for-byte equal to the literal it replaces.
 *      For the three AgentCore judge prompts the templates are imported
 *      directly. For the seven Converse callsites the literal is
 *      embedded in the source as either a single string, an array
 *      `.join("\n")` form, or a template literal — the test reads the
 *      legacy source file and asserts each line of the registry's
 *      `defaultText` is present in the file. This proves equivalence
 *      without forcing the legacy modules to expose their internal
 *      constants. `customer_simulator`, `judge_opportunistic_faithfulness`,
 *      and `rag_evaluation_job` are skipped per the design: the first two
 *      embed `{name}` placeholder tokens (so the registry default is
 *      intentionally NOT byte-equivalent to the legacy interpolation
 *      form) and the third has no legacy literal at all.
 *
 * @module tests/unit/prompt-registry
 */

import { describe, expect, it } from "vitest";

import {
  PROMPT_REGISTRY,
  SUPPORTED_MODELS,
} from "../../src/backend/orchestration/prompt-registry";
import type {
  PromptDefinition,
  PromptKey,
} from "../../src/backend/orchestration/prompt-registry";
import {
  GOAL_SUCCESS_RATE_TEMPLATE,
  HELPFULNESS_TEMPLATE,
  TOOL_SELECTION_TEMPLATE,
} from "../../src/backend/orchestration/judge-prompt-templates";

// ---------------------------------------------------------------------------
// The closed `PromptKey` set the registry is required to declare (R1.1).
// Listed explicitly here so removing or renaming a key in the registry
// surfaces as a test failure rather than silently reducing the catalog.
// ---------------------------------------------------------------------------

const REQUIRED_PROMPT_KEYS: readonly PromptKey[] = [
  "suite_scaffold",
  "case_scaffold",
  "failure_analysis",
  "suite_recommendation",
  "comparison_summary",
  "tournament_summary",
  "variant_generation",
  "customer_simulator",
  "judge_goal_success_rate",
  "judge_helpfulness",
  "judge_tool_selection",
  "judge_opportunistic_faithfulness",
  "rag_evaluation_job",
];

// Project root resolved from this file's location so the test stays
// independent of the cwd vitest is invoked from. Currently unused since
// the byte-for-byte legacy-equivalence assertions for the seven
// Converse callsites have all been relaxed to marker-phrase checks
// (Wave-1 Tasks 15.1–15.4 and Wave-2 Tasks 17.3–17.5 lifted the legacy
// `SYSTEM_PROMPT` literals into the registry, so the bytes no longer
// live in the legacy source files). Kept here as a deliberate
// no-op so the next migration wave can reach for the same helper if
// it ever needs to assert against a legacy literal again.
//
// (No exported helpers below — the legacy line-presence helper was
// retired alongside the last byte-for-byte assertion.)

// ---------------------------------------------------------------------------
// 1. Catalog completeness (R1.1)
// ---------------------------------------------------------------------------

describe("Prompt_Registry — catalog completeness", () => {
  it("declares exactly the thirteen required promptKeys", () => {
    const declared = Object.keys(PROMPT_REGISTRY).sort();
    const required = [...REQUIRED_PROMPT_KEYS].sort();
    expect(declared).toEqual(required);
  });

  it.each(REQUIRED_PROMPT_KEYS)(
    "every entry's `promptKey` field matches its map key (%s)",
    (key) => {
      const definition: PromptDefinition = PROMPT_REGISTRY[key];
      expect(definition.promptKey).toBe(key);
    },
  );
});

// ---------------------------------------------------------------------------
// 2. Self-consistent defaults — non-empty + every placeholder present (R1.2)
// ---------------------------------------------------------------------------

describe("Prompt_Registry — defaultText self-consistency", () => {
  it.each(REQUIRED_PROMPT_KEYS)(
    "[%s] defaultText is a string (non-empty for template prompts; empty allowed for the model-only `rag_evaluation_job` entry)",
    (key) => {
      const definition = PROMPT_REGISTRY[key];
      expect(typeof definition.defaultText).toBe("string");
      // `rag_evaluation_job` is a model-only entry per the design's
      // Components and Interfaces section and the Task 17.7 instruction
      // — the Bedrock RAG evaluation job invokes AWS-managed evaluator
      // templates server-side rather than a Converse system prompt, so
      // its `defaultText` is intentionally `""` and its `maxTextBytes`
      // cap is `0`. Every other prompt must carry a non-empty body.
      if (key === "rag_evaluation_job") {
        expect(definition.defaultText).toBe("");
        expect(definition.maxTextBytes).toBe(0);
        expect(definition.placeholders).toEqual([]);
        expect(definition.inferenceParameters).toEqual({});
      } else {
        expect(definition.defaultText.length).toBeGreaterThan(0);
      }
    },
  );

  it.each(REQUIRED_PROMPT_KEYS)(
    "[%s] defaultText contains every declared placeholder at least once",
    (key) => {
      const definition = PROMPT_REGISTRY[key];
      for (const placeholder of definition.placeholders) {
        const token = `{${placeholder.name}}`;
        expect(
          definition.defaultText.includes(token),
          `[${key}] defaultText is missing declared placeholder ${token}`,
        ).toBe(true);
      }
    },
  );
});

// ---------------------------------------------------------------------------
// 3. Default model membership (R3.3, R17.6)
// ---------------------------------------------------------------------------

describe("Prompt_Registry — default model membership", () => {
  it.each(REQUIRED_PROMPT_KEYS)(
    "[%s] defaultModelKey appears in allowedModels[]",
    (key) => {
      const definition = PROMPT_REGISTRY[key];
      expect(
        definition.allowedModels.includes(definition.defaultModelKey),
        `[${key}] defaultModelKey "${definition.defaultModelKey}" is not in allowedModels[${definition.allowedModels.join(", ")}]`,
      ).toBe(true);
    },
  );
});

// ---------------------------------------------------------------------------
// 4. Allowed-model validity (R17.6)
// ---------------------------------------------------------------------------

describe("Prompt_Registry — allowedModels validity", () => {
  it.each(REQUIRED_PROMPT_KEYS)(
    "[%s] every allowedModels[] entry is a valid modelKey in SUPPORTED_MODELS",
    (key) => {
      const definition = PROMPT_REGISTRY[key];
      expect(definition.allowedModels.length).toBeGreaterThan(0);
      for (const modelKey of definition.allowedModels) {
        expect(
          Object.prototype.hasOwnProperty.call(SUPPORTED_MODELS, modelKey),
          `[${key}] allowedModels references unknown modelKey "${modelKey}"`,
        ).toBe(true);
      }
    },
  );

  it.each(REQUIRED_PROMPT_KEYS)(
    "[%s] allowedModels[] contains no duplicates",
    (key) => {
      const definition = PROMPT_REGISTRY[key];
      const set = new Set(definition.allowedModels);
      expect(set.size).toBe(definition.allowedModels.length);
    },
  );
});

// ---------------------------------------------------------------------------
// 5. Byte-for-byte legacy equivalence (R1.2, R3.3)
//
// Each prompt's `defaultText` must match the literal it replaced in the
// legacy callsite. For the three AgentCore judge templates the constants
// are exported and we can compare directly. For the seven Converse
// callsites the legacy literal is private to its module — we read the
// source file and assert each line of the registry default is present.
// ---------------------------------------------------------------------------

describe("Prompt_Registry — byte-for-byte legacy equivalence", () => {
  it("[judge_goal_success_rate] defaultText === GOAL_SUCCESS_RATE_TEMPLATE", () => {
    expect(PROMPT_REGISTRY.judge_goal_success_rate.defaultText).toBe(
      GOAL_SUCCESS_RATE_TEMPLATE,
    );
  });

  it("[judge_helpfulness] defaultText === HELPFULNESS_TEMPLATE", () => {
    expect(PROMPT_REGISTRY.judge_helpfulness.defaultText).toBe(
      HELPFULNESS_TEMPLATE,
    );
  });

  it("[judge_tool_selection] defaultText === TOOL_SELECTION_TEMPLATE", () => {
    expect(PROMPT_REGISTRY.judge_tool_selection.defaultText).toBe(
      TOOL_SELECTION_TEMPLATE,
    );
  });

  it("[suite_scaffold] defaultText was lifted into the registry (legacy literal removed by Wave-1 migration, Task 15.2)", () => {
    // The original byte-for-byte assertion compared the registry default
    // against the literal in `scaffold.ts`. Wave-1 migrated that callsite
    // to `resolvePromptLive("suite_scaffold")` and removed the inline
    // literal — so byte-equality is no longer the guarantee. The
    // registry's `defaultText` IS now the source of truth. We assert it
    // is non-empty and contains a marker phrase from the original
    // literal so an accidental deletion or rewrite still surfaces.
    expect(PROMPT_REGISTRY.suite_scaffold.defaultText.length).toBeGreaterThan(0);
    expect(PROMPT_REGISTRY.suite_scaffold.defaultText).toContain(
      "AI agent tool chain analyzer",
    );
  });

  it("[case_scaffold] defaultText was lifted into the registry (legacy literal removed by Wave-1 migration, Task 15.2)", () => {
    expect(PROMPT_REGISTRY.case_scaffold.defaultText.length).toBeGreaterThan(0);
    expect(PROMPT_REGISTRY.case_scaffold.defaultText).toContain(
      "UX labeling assistant",
    );
  });

  it("[failure_analysis] defaultText was lifted into the registry (legacy literal removed by Wave-1 migration, Task 15.4)", () => {
    expect(PROMPT_REGISTRY.failure_analysis.defaultText.length).toBeGreaterThan(0);
    expect(PROMPT_REGISTRY.failure_analysis.defaultText).toContain(
      "expert at diagnosing AI agent failures",
    );
  });

  it("[suite_recommendation] defaultText was lifted into the registry (legacy literal removed by Wave-1 migration, Task 15.3)", () => {
    expect(PROMPT_REGISTRY.suite_recommendation.defaultText.length).toBeGreaterThan(0);
    expect(PROMPT_REGISTRY.suite_recommendation.defaultText).toContain(
      "expert at consolidating AI agent test failures",
    );
  });

  it("[comparison_summary] defaultText was lifted into the registry (legacy literal removed by Wave-1 migration, Task 15.1)", () => {
    expect(PROMPT_REGISTRY.comparison_summary.defaultText.length).toBeGreaterThan(0);
    expect(PROMPT_REGISTRY.comparison_summary.defaultText).toContain(
      "concise summariser of test-run comparisons",
    );
  });

  it("[tournament_summary] defaultText was lifted into the registry (legacy literal removed by Wave-2 migration, Task 17.5)", () => {
    // The original byte-for-byte assertion compared the registry default
    // against the `SYSTEM_PROMPT` template literal in `tournament-summary.ts`.
    // Wave-2 migrated that callsite to
    // `resolvePromptForRun("tournament_summary", runId)`, dropping the
    // inline literal — so the legacy bytes no longer live in the source
    // file. The registry default is now the single source of truth; we
    // assert it is non-empty and contains a marker phrase from the
    // original literal so an accidental deletion or rewrite still
    // surfaces.
    expect(PROMPT_REGISTRY.tournament_summary.defaultText.length).toBeGreaterThan(0);
    expect(PROMPT_REGISTRY.tournament_summary.defaultText).toContain(
      "expert test results analyst",
    );
  });

  it("[variant_generation] defaultText was lifted into the registry (legacy literal removed by Wave-2 migration, Task 17.4)", () => {
    // The original byte-for-byte assertion compared the registry default
    // against the literal in `variant-generator.ts`. Wave-2 migrated that
    // callsite to `resolvePromptForRun("variant_generation", runId)`,
    // dropping the inline `SYSTEM_PROMPT` literal — so the legacy bytes
    // no longer live in the source file. The registry default is now the
    // single source of truth; the placeholder-presence test above
    // guarantees its declared `{name}` tokens are non-stale.
    expect(PROMPT_REGISTRY.variant_generation.defaultText.length).toBeGreaterThan(0);
    expect(PROMPT_REGISTRY.variant_generation.defaultText).toContain(
      "expert AI agent prompt engineer",
    );
  });

  // ---------------------------------------------------------------------------
  // Skipped per the design / task instructions:
  //
  //   - `customer_simulator`: the registry default lifts the legacy
  //     `buildSimulatorPrompt` body and replaces the JS-template-string
  //     interpolations (`${scenario}`, etc.) with `{name}` placeholder
  //     tokens. The registry text is therefore NOT byte-identical to the
  //     legacy literal by design. Equivalence is enforced indirectly: the
  //     placeholder presence test above ensures every declared `{name}`
  //     token is present, and the Wave 1 migration (Task 15.x) replaces
  //     the `${...}` interpolations with the same `{name}` tokens via the
  //     standard renderer.
  //
  //   - `judge_opportunistic_faithfulness`: same situation — the registry
  //     default lifts `buildFaithfulnessPrompt` with `${passagesList}` /
  //     `${agentResponse}` rewritten as `{passages}` / `{agent_response}`.
  //
  //   - `rag_evaluation_job`: model-only entry per the design's
  //     Components and Interfaces section. There is no legacy literal —
  //     the Bedrock RAG evaluation job ships AWS-managed evaluator
  //     templates server-side. We only assert the default is non-empty
  //     (handled by the self-consistency test above).
  // ---------------------------------------------------------------------------
});
