# Bedrock judge evaluations

How test cases are scored using Amazon's published evaluator rubrics over Bedrock Converse.

## Background

Originally the platform planned to use Amazon Bedrock AgentCore Evaluations for managed scoring. Empirical validation showed AgentCore's `Evaluate` API requires records produced by the AgentCore Runtime + ADOT ingestion pipeline (which the platform doesn't use) and CloudWatch Transaction Search enabled in the account. Every input shape we tried returned `LogEventMissingException`.

The platform pivoted to **Bedrock Converse with the AWS-published built-in evaluator templates as scoring rubric**. This keeps every observable contract identical (same three score fields, same `[0, 1]` range, same error semantics, same DynamoDB shape) and replaces only the scoring backend.

## What gets scored

Three score fields on every `TestCaseResult`, each in `[0, 1]`:

| Field | Source rubric | Semantics |
|---|---|---|
| `goalSuccessScore` | `Builtin.GoalSuccessRate` (session-level) | Did the agent achieve the customer's goal? Binary Yes/No mapped to 1.0/0.0. |
| `helpfulnessScore` | `Builtin.Helpfulness` (per assistant turn) | How helpful was each turn? 7-level scale, mean across turns. |
| `toolAccuracyScore` | `Builtin.ToolSelectionAccuracy` (per tool call) | Was each tool call justified? Binary Yes/No mapped to 1.0/0.0, mean across calls. |

For one test case with N assistant turns and M tool calls, evaluation makes `1 + N + M` Bedrock Converse calls.

## The judge model

Default: `us.anthropic.claude-sonnet-4-6`. Configured via the `judgeModelId` CDK context parameter.

The IAM grant on the evaluation Lambda role is derived deterministically from `judgeModelId` at synth time:

- For an inference profile (e.g. `us.anthropic.claude-sonnet-4-6`), the grant covers all routing regions in the profile family (`us-east-1`, `us-east-2`, `us-west-2` for `us.` prefix).
- For a bare foundation model ID (e.g. `anthropic.claude-3-5-sonnet-20241022-v2:0`), the grant covers only the deploy region.

Resolved at synth via `resolveJudgeModelGrants` in `lib/orchestration-construct.ts`. An empty or unrecognized `judgeModelId` fails synth so misconfiguration is caught early.

## Prompt templates

Three AWS-published templates are committed verbatim in `.kiro/steering/bedrock-judge-prompts.md` and matched byte-for-byte by constants in `src/backend/orchestration/judge-prompt-templates.ts`. The steering file is the **single source of truth** — when AWS publishes a revision, both the steering file and the code constant must update in the same PR.

### GoalSuccessRate

Session-level. Inputs: `{available_tools}` (the agent's tool catalog) and `{context}` (the full conversation transcript with User:/Assistant:/Action:/Tool: lines).

Output schema (parsed from the model's fenced JSON):
```json
{
  "reasoning": "step by step reasoning, max 250 words",
  "score": "Yes" | "No"
}
```

### Helpfulness

Per assistant turn. Inputs: `{context}` (prefix-only — only steps strictly preceding this turn) and `{assistant_turn}` (the turn under evaluation).

Output schema:
```json
{
  "reasoning": "...",
  "score": "Not Helpful At All" | "Very Unhelpful" | "Somewhat Unhelpful"
         | "Neutral/Mixed" | "Somewhat Helpful" | "Very Helpful" | "Above And Beyond"
}
```

### ToolSelectionAccuracy

Per tool call. Inputs: `{available_tools}`, `{context}` (prefix-only), and `{tool_turn}` (the tool call as `name(args_json)`).

Output schema:
```json
{
  "reasoning": "...",
  "score": "Yes" | "No"
}
```

## Score_Scale tables

Categorical labels are mapped to fixed decimals via committed lookup tables in `src/shared/utils/evaluation-scoring.ts`.

### GoalSuccessRate scale

| Label | Value |
|---|---|
| `Yes` | `1.0` |
| `No` | `0.0` |

### ToolSelectionAccuracy scale

| Label | Value |
|---|---|
| `Yes` | `1.0` |
| `No` | `0.0` |

### Helpfulness scale (uniform spacing in steps of 1/6)

| Label | Value |
|---|---|
| `Not Helpful At All` | `0/6 = 0.0` |
| `Very Unhelpful` | `1/6 ≈ 0.1667` |
| `Somewhat Unhelpful` | `2/6 ≈ 0.3333` |
| `Neutral/Mixed` | `3/6 = 0.5` |
| `Somewhat Helpful` | `4/6 ≈ 0.6667` |
| `Very Helpful` | `5/6 ≈ 0.8333` |
| `Above And Beyond` | `6/6 = 1.0` |

Any label not in the scale → `Evaluation_Error_State` with code `UNMAPPABLE_RESULT`. The platform never silently substitutes 0 or any default.

## Aggregation

Per case:

```
goalSuccessScore = scale(GoalSuccessRate.score)              // single value
helpfulnessScore = mean(scale(h.score) for h in helpfulnessUnits)
toolAccuracyScore = mean(scale(t.score) for t in toolUnits)
```

All values clamped to `[0, 1]`. Implementation: `src/backend/orchestration/score-aggregation.ts` (pure, property-tested).

## Prompt rendering

The Prompt_Rendering_Module produces the four prompt-context strings the templates expect:

- `{context}` — for session-level (full transcript) or per-unit (prefix-only).
- `{available_tools}` — numbered list of all tools with name, description, input schema.
- `{assistant_turn}` — for per-turn Helpfulness.
- `{tool_turn}` — for per-call ToolSelectionAccuracy, formatted as `toolName(args_json)`.

The renderer:
- Preserves chronological order of customer turns, assistant turns, and tool calls from the execution trace and transcript.
- Uses `User:`, `Assistant:`, `Action:`, `Tool:` line prefixes.
- Includes the test case's **expected tool names** (from `successCriteria`) in `{context}` for GoalSuccessRate and ToolSelectionAccuracy so the rubric can be assessed against the case's intended behavior.
- Has zero AWS SDK imports — fully unit-testable.

Golden prompt snapshots in `tests/fixtures/golden-prompts/` are byte-asserted against captured Span_Fixtures (`tests/fixtures/spans/`). Any rendering change requires a snapshot update reviewed in the same PR.

## Per-case error states

When evaluation fails, the result carries a typed `evaluationError` field instead of (or in addition to) score fields:

| Code | Meaning |
|---|---|
| `INSUFFICIENT_TRACE` | The execution trace has zero assistant turns and zero `execute_tool` entries. The judge isn't invoked at all. |
| `TIMEOUT` | A Converse call exceeded the per-call timeout (default 60s). |
| `JUDGE_ERROR` | A non-throttle Bedrock error (AccessDenied, ResourceNotFoundException, etc.). |
| `UNMAPPABLE_RESULT` | The model returned a label not in the corresponding Score_Scale. |
| `MISSING_EVALUATOR` | One evaluator type produced results but another didn't. The produced scores are persisted; the absent ones are flagged. |

The frontend renders these in place of the scores so users see exactly what failed and why, rather than mistaking missing data for low scores.

## Per-evaluator detail

Beyond the aggregated scores, each `TestCaseResult` carries `evaluationDetails: EvaluationCallDetail[]` — one entry per Converse call:

```typescript
interface EvaluationCallDetail {
  evaluator: "Builtin.GoalSuccessRate" | "Builtin.Helpfulness" | "Builtin.ToolSelectionAccuracy";
  index: number;             // 0 for GoalSuccessRate; 0..N-1 for Helpfulness; 0..M-1 for ToolSelectionAccuracy
  label?: string;            // raw rubric label
  mappedValue?: number;      // [0,1] after Score_Scale mapping
  reasoning?: string;        // judge's natural-language explanation, max 250 words
  error?: { kind: ...; message: string };
}
```

The case detail page surfaces these so testers can answer "why did the judge score this 0.5 on Helpfulness?" without re-running the evaluation.

## Cost

At default judge model and typical per-call volumes (~3K input tokens, ~500 output tokens):

- Per case: ~$0.03–$0.05.
- 100-case run: ~$3–$5 of judge cost.

Switch to a smaller model (Haiku) via `judgeModelId` to drop this. The IAM grant tightens automatically.

## Validating prompt template drift

When AWS publishes a new revision of any built-in template, the refresh procedure (from `.kiro/steering/bedrock-judge-prompts.md`):

1. Diff each template against the live AWS docs at the source URL listed in the steering file.
2. Open a PR that:
   - Updates the template in the steering file verbatim.
   - Updates the source code constant byte-for-byte.
   - Updates the corresponding Score_Scale entry in `evaluation-scoring.ts` if any rubric label moved.
   - Bumps the **Date of copy** above the affected template.
3. Re-run the golden-prompt snapshot tests; accept the snapshot diff in the same PR.

This procedure surfaces drift as a code-review event rather than a silent change.

## Local harness

`scripts/evaluation-harness.ts` runs the full Bedrock judge integration locally against:
- A captured Span_Fixture (under `tests/fixtures/spans/`), or
- A real Q in Connect session by ID.

Useful for iterating on prompt template changes or debugging Score_Scale mappings without a full deploy. Uses local AWS credentials with the same Bedrock grants the deployed Lambda has.
