// Feature: connect-agent-test-platform, Property 1: Entity Field Validation
import { describe, it, expect } from "vitest";
import fc from "fast-check";
import { validateTestSuite, validateTestCase } from "@shared/validation";
import {
  SUITE_NAME_MAX,
  SUITE_DESCRIPTION_MAX,
  CASE_DESCRIPTION_MAX,
  INITIAL_UTTERANCE_MAX,
  CUSTOMER_KNOWLEDGE_MAX_PAIRS,
  CUSTOMER_KNOWLEDGE_KEY_MAX,
  CUSTOMER_KNOWLEDGE_VALUE_MAX,
  SUCCESS_CRITERIA_MAX_STEPS,
  PARAMETER_CHECKS_MAX,
} from "@shared/constants";

/**
 * **Validates: Requirements 4.1, 4.3, 4.5, 5.1, 5.2, 5.4**
 *
 * Property 1: Entity Field Validation
 * Verifies that validation accepts all inputs within bounds and rejects inputs
 * violating any constraint, using randomly generated strings and collection sizes.
 */

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/**
 * Generates a non-whitespace-only string within the given bounds.
 * The validation trims strings and rejects empty results, so we need at least
 * one non-whitespace character in required fields.
 */
function nonBlankString(minLength: number, maxLength: number) {
  return fc
    .string({ minLength, maxLength })
    .filter((s) => s.trim().length > 0);
}

/** Generates a non-whitespace-only tool name. */
const nonBlankToolName = fc
  .string({ minLength: 1, maxLength: 50 })
  .filter((s) => s.trim().length > 0);

/** Generates a valid ToolStep with a non-empty toolName and bounded parameterChecks. */
const toolStepArb = fc.record({
  toolName: nonBlankToolName,
  required: fc.boolean(),
  parameterChecks: fc.option(
    fc.array(
      fc.record({
        paramName: fc.string({ minLength: 1, maxLength: 50 }),
        expectedValue: fc.string({ maxLength: 100 }),
      }),
      { minLength: 0, maxLength: PARAMETER_CHECKS_MAX }
    ),
    { nil: undefined }
  ),
});

// ---------------------------------------------------------------------------
// Suite validation properties
// ---------------------------------------------------------------------------

describe("Property 1: Entity Field Validation — Test Suite", () => {
  it("valid inputs within bounds always pass", () => {
    fc.assert(
      fc.property(
        nonBlankString(1, SUITE_NAME_MAX),
        nonBlankString(1, 50),
        fc.option(fc.string({ maxLength: SUITE_DESCRIPTION_MAX }), { nil: undefined }),
        (name, agentId, description) => {
          const input: Record<string, unknown> = { name, agentId };
          if (description !== undefined) {
            input.description = description;
          }
          const result = validateTestSuite(input);
          expect(result.valid).toBe(true);
          expect(result.errors).toHaveLength(0);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("name exceeding max is always rejected", () => {
    fc.assert(
      fc.property(
        fc.string({ minLength: SUITE_NAME_MAX + 1, maxLength: 500 }),
        nonBlankString(1, 50),
        (name, agentId) => {
          const result = validateTestSuite({ name, agentId });
          expect(result.valid).toBe(false);
          expect(result.errors.some((e) => e.field === "name")).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });
});

// ---------------------------------------------------------------------------
// Case validation properties
// ---------------------------------------------------------------------------

describe("Property 1: Entity Field Validation — Test Case", () => {
  it("valid inputs within ALL bounds always pass", () => {
    fc.assert(
      fc.property(
        nonBlankString(1, CASE_DESCRIPTION_MAX),
        nonBlankString(1, INITIAL_UTTERANCE_MAX),
        fc.array(toolStepArb, { minLength: 1, maxLength: SUCCESS_CRITERIA_MAX_STEPS }),
        fc.dictionary(
          fc.string({ minLength: 1, maxLength: CUSTOMER_KNOWLEDGE_KEY_MAX }),
          fc.string({ maxLength: CUSTOMER_KNOWLEDGE_VALUE_MAX }),
          { minKeys: 0, maxKeys: CUSTOMER_KNOWLEDGE_MAX_PAIRS }
        ),
        (description, initialUtterance, successCriteria, customerKnowledge) => {
          const result = validateTestCase({
            description,
            initialUtterance,
            successCriteria,
            customerKnowledge,
          });
          expect(result.valid).toBe(true);
          expect(result.errors).toHaveLength(0);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("description exceeding max is always rejected", () => {
    fc.assert(
      fc.property(
        fc.string({ minLength: CASE_DESCRIPTION_MAX + 1, maxLength: 5000 }),
        fc.string({ minLength: 1, maxLength: INITIAL_UTTERANCE_MAX }),
        fc.array(toolStepArb, { minLength: 1, maxLength: SUCCESS_CRITERIA_MAX_STEPS }),
        (description, initialUtterance, successCriteria) => {
          const result = validateTestCase({
            description,
            initialUtterance,
            successCriteria,
          });
          expect(result.valid).toBe(false);
          expect(result.errors.some((e) => e.field === "description")).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("too many success criteria steps always rejected", () => {
    fc.assert(
      fc.property(
        fc.string({ minLength: 1, maxLength: CASE_DESCRIPTION_MAX }),
        fc.string({ minLength: 1, maxLength: INITIAL_UTTERANCE_MAX }),
        fc.array(toolStepArb, {
          minLength: SUCCESS_CRITERIA_MAX_STEPS + 1,
          maxLength: SUCCESS_CRITERIA_MAX_STEPS + 20,
        }),
        (description, initialUtterance, successCriteria) => {
          const result = validateTestCase({
            description,
            initialUtterance,
            successCriteria,
          });
          expect(result.valid).toBe(false);
          expect(result.errors.some((e) => e.field === "successCriteria")).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });

  it("too many customer knowledge pairs always rejected", () => {
    fc.assert(
      fc.property(
        fc.string({ minLength: 1, maxLength: CASE_DESCRIPTION_MAX }),
        fc.string({ minLength: 1, maxLength: INITIAL_UTTERANCE_MAX }),
        fc.array(toolStepArb, { minLength: 1, maxLength: SUCCESS_CRITERIA_MAX_STEPS }),
        fc.uniqueArray(
          fc.string({ minLength: 1, maxLength: CUSTOMER_KNOWLEDGE_KEY_MAX }).filter(
            (s) => s !== "__proto__" && s !== "constructor" && s !== "toString"
          ),
          {
            minLength: CUSTOMER_KNOWLEDGE_MAX_PAIRS + 1,
            maxLength: CUSTOMER_KNOWLEDGE_MAX_PAIRS + 10,
          }
        ),
        (description, initialUtterance, successCriteria, keys) => {
          const customerKnowledge: Record<string, string> = {};
          for (const key of keys) {
            customerKnowledge[key] = "value";
          }
          const result = validateTestCase({
            description,
            initialUtterance,
            successCriteria,
            customerKnowledge,
          });
          expect(result.valid).toBe(false);
          expect(
            result.errors.some((e) => e.field === "customerKnowledge")
          ).toBe(true);
        }
      ),
      { numRuns: 100 }
    );
  });
});
