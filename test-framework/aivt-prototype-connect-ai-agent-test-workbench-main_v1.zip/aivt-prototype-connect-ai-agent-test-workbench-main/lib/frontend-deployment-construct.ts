import * as path from 'path';
import * as fs from 'fs';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as s3deploy from 'aws-cdk-lib/aws-s3-deployment';
import { Construct } from 'constructs';
import { buildRuntimeConfig, RuntimeConfigInputs } from './runtime-config';

/**
 * Default frontend build output directory, relative to the directory `cdk`
 * is invoked from (the project root). The Vite build emits `dist/` here.
 */
const DEFAULT_BUILD_DIR = 'src/frontend/dist';

/**
 * Props for {@link FrontendDeploymentConstruct}.
 */
export interface FrontendDeploymentProps {
  /**
   * The S3 bucket CloudFront serves the frontend from (the `Frontend_Bucket`,
   * defined in `StorageConstruct`). Assets and `config.json` are uploaded here.
   */
  frontendBucket: s3.IBucket;

  /**
   * The CloudFront distribution that serves the `Frontend_Bucket`. Passing it
   * (together with `distributionPaths`) makes the deployment custom resource
   * create and wait for a `/*` cache invalidation before reporting success.
   */
  distribution: cloudfront.IDistribution;

  /**
   * The resolved stack outputs used to build the `/config.json` document. These
   * are re-validated here (via {@link buildRuntimeConfig}) so an incomplete
   * config can never be uploaded.
   */
  runtimeConfig: RuntimeConfigInputs;

  /**
   * The frontend build output directory to upload. Defaults to
   * `src/frontend/dist`. Injectable so synth tests can supply a fixture dir.
   */
  buildDir?: string;
}

/**
 * Owns the single `BucketDeployment` that uploads the frontend build and the
 * generated `config.json` to the `Frontend_Bucket`, then invalidates the
 * CloudFront cache.
 *
 * Design (see design.md §1.1, §1.2):
 *  - A single {@link s3deploy.BucketDeployment} carries two sources — the build
 *    asset (recursive, structure-preserving) and a `Source.jsonData` for
 *    `config.json` — so both survive `prune` and the asset upload does not
 *    delete the generated config (Req 3.5).
 *  - `prune: true` makes unchanged deploys no-ops on object content (Req 12.1,
 *    12.2).
 *  - `distribution` + `distributionPaths: ['/*']` create and wait for a cache
 *    invalidation covering the whole site on every asset change (Req 2.1).
 *
 * Synth-time guard (Req 1.4): if the resolved build directory does not exist or
 * lacks an `index.html` at its root, the constructor throws during synth so no
 * `BucketDeployment` is created and the bucket is never mutated on failure.
 *
 * Requirements: 1.1, 1.2, 1.4, 2.1, 3.1, 3.5, 12.1, 12.2
 */
export class FrontendDeploymentConstruct extends Construct {
  /** The deployment that uploads the build + `config.json` and invalidates CloudFront. */
  public readonly deployment: s3deploy.BucketDeployment;

  constructor(scope: Construct, id: string, props: FrontendDeploymentProps) {
    super(scope, id);

    // Resolve the build dir relative to the cwd so the default and any
    // injected (e.g. fixture) path are checked and uploaded consistently.
    const buildDir = path.resolve(props.buildDir ?? DEFAULT_BUILD_DIR);

    // --- Synth-time precondition guard (Req 1.4) ---
    // Throw during synth if the build output is missing or lacks index.html at
    // its root, BEFORE any BucketDeployment is created, so the bucket is never
    // mutated on failure.
    if (!fs.existsSync(buildDir) || !fs.statSync(buildDir).isDirectory()) {
      throw new Error(
        `Frontend build output directory not found at '${buildDir}'. ` +
          `Run 'npm install && npm run build' in 'src/frontend' before deploying.`
      );
    }
    const indexHtml = path.join(buildDir, 'index.html');
    if (!fs.existsSync(indexHtml) || !fs.statSync(indexHtml).isFile()) {
      throw new Error(
        `Frontend build output at '${buildDir}' is missing 'index.html' at its root. ` +
          `Run 'npm install && npm run build' in 'src/frontend' before deploying.`
      );
    }

    // Re-validate the runtime config here so an incomplete/empty config.json is
    // never uploaded (Req 3.6); buildRuntimeConfig emits exactly the five
    // non-secret fields (Req 3.1-3.4, 13.1, 13.2).
    const resolvedConfig = buildRuntimeConfig(props.runtimeConfig);

    // --- Single BucketDeployment: build asset + config.json, with invalidation ---
    this.deployment = new s3deploy.BucketDeployment(this, 'FrontendDeploy', {
      destinationBucket: props.frontendBucket,
      // Cache invalidation on every asset change (Req 2.1).
      distribution: props.distribution,
      distributionPaths: ['/*'],
      // Both sources are merged into one deployment so prune operates over the
      // union — the build and config.json both survive (Req 3.5).
      prune: true,
      sources: [
        // Build asset: recursive, structure-preserving upload (Req 1.1, 1.2).
        s3deploy.Source.asset(buildDir),
        // Runtime config served at /config.json (Req 3.1).
        s3deploy.Source.jsonData('config.json', resolvedConfig),
      ],
    });
  }
}
