import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './auth/AuthContext';
import { ProtectedRoute } from './auth/ProtectedRoute';
import { AppLayout } from './layout';
import { ActiveRunsProvider } from './hooks/ActiveRunsContext';
import { AgentBrowser, TestSuites, SuiteDetail, RunDashboard, ResultsViewer, CaseDetail, Comparison, TournamentViewPage, PromptsListPage, PromptDetailPage } from './pages';

export function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ProtectedRoute>
          {/*
            ActiveRunsProvider wraps the entire authenticated surface so the
            persistent "running" banner in AppLayout and the run-launching
            buttons (per-case in SuiteDetail, suite-level in TestSuites)
            share one polling source. Mounted INSIDE ProtectedRoute so we
            don't poll while the user is unauthenticated.
          */}
          <ActiveRunsProvider>
            <AppLayout>
              <Routes>
                <Route path="/agents" element={<AgentBrowser />} />
                <Route path="/suites" element={<TestSuites />} />
                <Route path="/suites/:suiteId" element={<SuiteDetail />} />
                <Route path="/runs/new" element={<RunDashboard />} />
                <Route path="/runs/:runId" element={<RunDashboard />} />
                {/*
                  Per-case detail page reachable via a click on a case
                  row in the Run Dashboard or Results Viewer. Suite-aware
                  via the `?suiteId=` query param so the page's "Back to
                  run" navigation preserves the dashboard's lookup hint.
                */}
                <Route
                  path="/runs/:runId/cases/:caseId"
                  element={<CaseDetail />}
                />
                {/*
                  Tournament View page — displays the 4-column experiment
                  comparison (baseline vs 3 variants). Accessible via the
                  "Experiment Results" link on the Run Dashboard (R8.7).
                */}
                <Route
                  path="/runs/:runId/experiments/:experimentId"
                  element={<TournamentViewPage />}
                />
                <Route path="/runs/:runId/results" element={<ResultsViewer />} />
                <Route path="/compare" element={<Comparison />} />
                {/*
                  Prompts catalog (R13.1) and per-prompt detail/edit page
                  (R14.1). The list page is the sidebar entry's
                  destination; the detail page is reached by clicking a
                  row on the list page. Both are protected behind the
                  same Cognito ProtectedRoute as the rest of the app.
                */}
                <Route path="/prompts" element={<PromptsListPage />} />
                <Route
                  path="/prompts/:promptKey"
                  element={<PromptDetailPage />}
                />
                <Route path="*" element={<Navigate to="/agents" replace />} />
              </Routes>
            </AppLayout>
          </ActiveRunsProvider>
        </ProtectedRoute>
      </AuthProvider>
    </BrowserRouter>
  );
}
