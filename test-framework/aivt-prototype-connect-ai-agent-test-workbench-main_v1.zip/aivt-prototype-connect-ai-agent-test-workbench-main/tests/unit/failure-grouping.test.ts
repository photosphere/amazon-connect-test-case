/**
 * Unit tests for the shared `failure-grouping` util.
 *
 * Coverage moved here from `tests/unit/analysis.test.ts` after task 5 of the
 * actionable-recommendations spec extracted `groupFailuresByRootCause` and
 * `deduplicateRecommendations` into the shared util at
 * `src/shared/utils/failure-grouping.ts` so the per-case Analysis Lambda,
 * the Recommended_Changes_Panel, the Failure_Analysis page, and the
 * Case_Detail page all consume the same canonical implementation.
 *
 * Validates: Requirements 11.1
 */

import { describe, it, expect } from "vitest";
import {
  groupFailuresByRootCause,
  deduplicateRecommendations,
  type FailureCaseAnalysis,
} from "../../src/shared/utils/failure-grouping";
import type { Recommendation, ToolSurface } from "../../src/shared/types";

describe("failure-grouping shared util", () => {
  describe("groupFailuresByRootCause", () => {
    it("returns empty individual and grouped arrays for empty input", () => {
      const { individual, grouped } = groupFailuresByRootCause([]);
      expect(individual).toEqual([]);
      expect(grouped).toEqual([]);
    });

    it("keeps single-occurrence categories as individual (not grouped)", () => {
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "case-1",
          rootCauseCategory: "overlapping_tool_descriptions",
          explanation: "Tools A and B overlap",
          traceAvailable: true,
          recommendations: [makeRec("tool_description", "ToolA")],
        },
        {
          caseId: "case-2",
          rootCauseCategory: "system_prompt_gap",
          explanation: "System prompt missing X",
          traceAvailable: true,
          recommendations: [makeRec("system_prompt", "system_prompt")],
        },
      ];

      const { individual, grouped } = groupFailuresByRootCause(analyses);
      expect(individual).toHaveLength(2);
      expect(grouped).toHaveLength(0);
      expect(individual.map((a) => a.caseId)).toContain("case-1");
      expect(individual.map((a) => a.caseId)).toContain("case-2");
    });

    it("tolerates a single-case category (regression: renders as individual, not grouped)", () => {
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "only-case",
          rootCauseCategory: "lonely_category",
          explanation: "Just one failure in this bucket",
          traceAvailable: true,
          recommendations: [makeRec("tool_instruction", "ToolX")],
        },
      ];

      const { individual, grouped } = groupFailuresByRootCause(analyses);
      expect(grouped).toEqual([]);
      expect(individual).toHaveLength(1);
      expect(individual[0].caseId).toBe("only-case");
      expect(individual[0].rootCauseCategory).toBe("lonely_category");
    });

    it("groups 2+ failures with the same root cause category", () => {
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "case-1",
          rootCauseCategory: "overlapping_tool_descriptions",
          explanation: "Overlap between ToolA and ToolB",
          traceAvailable: true,
          recommendations: [makeRec("tool_description", "ToolA")],
        },
        {
          caseId: "case-2",
          rootCauseCategory: "overlapping_tool_descriptions",
          explanation: "Overlap between ToolA and ToolC",
          traceAvailable: false,
          recommendations: [makeRec("tool_description", "ToolA")],
        },
        {
          caseId: "case-3",
          rootCauseCategory: "system_prompt_gap",
          explanation: "Unique failure",
          traceAvailable: true,
          recommendations: [makeRec("system_prompt", "system_prompt")],
        },
      ];

      const { individual, grouped } = groupFailuresByRootCause(analyses);
      expect(individual).toHaveLength(1);
      expect(individual[0].caseId).toBe("case-3");
      expect(grouped).toHaveLength(1);
      expect(grouped[0].rootCauseCategory).toBe("overlapping_tool_descriptions");
      expect(grouped[0].caseIds).toEqual(["case-1", "case-2"]);
    });

    it("deduplicates recommendations within a group by targetField+targetName", () => {
      const sharedRec = makeRec("tool_description", "ToolA");
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "case-1",
          rootCauseCategory: "same_category",
          explanation: "Explanation 1",
          traceAvailable: true,
          recommendations: [sharedRec, makeRec("system_prompt", "system_prompt")],
        },
        {
          caseId: "case-2",
          rootCauseCategory: "same_category",
          explanation: "Explanation 2",
          traceAvailable: true,
          recommendations: [sharedRec],
        },
      ];

      const { grouped } = groupFailuresByRootCause(analyses);
      expect(grouped).toHaveLength(1);
      // Should deduplicate the shared rec
      expect(grouped[0].recommendations).toHaveLength(2);
      expect(grouped[0].recommendations[0].targetName).toBe("ToolA");
      expect(grouped[0].recommendations[1].targetName).toBe("system_prompt");
    });

    it("caps recommendations at 5 per group", () => {
      const analyses: FailureCaseAnalysis[] = [
        {
          caseId: "case-1",
          rootCauseCategory: "same",
          explanation: "...",
          traceAvailable: true,
          recommendations: [
            makeRec("tool_description", "T1"),
            makeRec("tool_description", "T2"),
            makeRec("tool_description", "T3"),
          ],
        },
        {
          caseId: "case-2",
          rootCauseCategory: "same",
          explanation: "...",
          traceAvailable: true,
          recommendations: [
            makeRec("tool_description", "T4"),
            makeRec("tool_description", "T5"),
            makeRec("tool_description", "T6"),
          ],
        },
      ];

      const { grouped } = groupFailuresByRootCause(analyses);
      expect(grouped[0].recommendations.length).toBeLessThanOrEqual(5);
    });
  });

  describe("deduplicateRecommendations", () => {
    it("returns an empty array for an empty input", () => {
      expect(deduplicateRecommendations([])).toEqual([]);
    });

    it("preserves a list with no duplicates", () => {
      const recs = [
        makeRec("tool_description", "ToolA"),
        makeRec("tool_instruction", "ToolA"),
        makeRec("tool_examples", "ToolA"),
        makeRec("system_prompt", "system_prompt"),
      ];

      const deduped = deduplicateRecommendations(recs);
      expect(deduped).toHaveLength(4);
      expect(deduped.map((r) => `${r.targetField}::${r.targetName}`)).toEqual([
        "tool_description::ToolA",
        "tool_instruction::ToolA",
        "tool_examples::ToolA",
        "system_prompt::system_prompt",
      ]);
    });

    it("removes duplicates by targetField+targetName, keeping the first occurrence", () => {
      const first = makeRec("tool_description", "ToolA");
      const dupSameKey: Recommendation = {
        ...makeRec("tool_description", "ToolA"),
        currentText: "different current",
        suggestedText: "different suggestion",
        rationale: "different rationale",
      };
      const other = makeRec("system_prompt", "system_prompt");

      const deduped = deduplicateRecommendations([first, dupSameKey, other]);
      expect(deduped).toHaveLength(2);
      // First occurrence wins — currentText/suggestedText/rationale should
      // come from `first`, not from `dupSameKey`.
      expect(deduped[0]).toEqual(first);
      expect(deduped[1]).toEqual(other);
    });

    it("treats different targetFields with the same targetName as distinct", () => {
      const recs = [
        makeRec("tool_description", "ToolA"),
        makeRec("tool_instruction", "ToolA"),
      ];

      const deduped = deduplicateRecommendations(recs);
      expect(deduped).toHaveLength(2);
    });

    it("caps the result at 5 recommendations", () => {
      const recs = Array.from({ length: 10 }, (_, i) =>
        makeRec("tool_description", `Tool${i}`)
      );

      const deduped = deduplicateRecommendations(recs);
      expect(deduped).toHaveLength(5);
      // Should keep the first 5 in order.
      expect(deduped.map((r) => r.targetName)).toEqual([
        "Tool0",
        "Tool1",
        "Tool2",
        "Tool3",
        "Tool4",
      ]);
    });
  });
});

// Helper to create a recommendation fixture
function makeRec(targetField: ToolSurface, targetName: string): Recommendation {
  return {
    targetField,
    targetName,
    currentText: `current text for ${targetName}`,
    suggestedText: `suggested text for ${targetName}`,
    rationale: `Fix ${targetName}`,
  };
}
