// Fetch the AnyBank ORCHESTRATION agent's system prompt + tool configs so we can
// see which session attributes (ContactARN, ANI, ContactId, etc.) it references.
import {
  QConnectClient,
  GetAIAgentCommand,
  GetAIPromptCommand,
} from "@aws-sdk/client-qconnect";

const REGION = "us-east-1";
const ASSISTANT_ID = "5664eea5-381d-468e-bfba-302b69ae6dec";
const AGENT_ID = "d54d3dee-b9ec-415a-9a4b-b4769426f365";

const client = new QConnectClient({ region: REGION });

const agentResp = await client.send(
  new GetAIAgentCommand({ assistantId: ASSISTANT_ID, aiAgentId: AGENT_ID })
);
const agent = agentResp.aiAgent;
const orch = agent?.configuration?.orchestrationAIAgentConfiguration;

console.log("=== AGENT ===");
console.log("name:", agent?.name, "| type:", agent?.type, "| version:", agent?.visibilityStatus, agentResp.versionNumber ?? "");
console.log("orchestrationAIPromptId:", orch?.orchestrationAIPromptId);
console.log("locale:", orch?.locale);
console.log();

// Tool configs (names + descriptions)
console.log("=== TOOLS ===");
for (const t of orch?.toolConfigurations ?? []) {
  console.log(`- ${t.toolName} [${t.toolType}]`);
}
console.log();

// Full config for verifyIdentity to see how ContactARN is sourced
console.log("=== verifyIdentity FULL CONFIG ===");
const vi = (orch?.toolConfigurations ?? []).find((t) => t.toolName === "verifyIdentity");
console.log(JSON.stringify(vi, null, 2));
console.log();

// Fetch the orchestration prompt content
const promptId = orch?.orchestrationAIPromptId;
if (promptId) {
  try {
    const p = await client.send(
      new GetAIPromptCommand({ assistantId: ASSISTANT_ID, aiPromptId: promptId })
    );
    const tpl = p.aiPrompt?.templateConfiguration;
    console.log("=== ORCHESTRATION PROMPT ===");
    console.log("promptId:", promptId, "| type:", p.aiPrompt?.type);
    console.log("templateConfiguration keys:", Object.keys(tpl ?? {}).join(", "));
    console.log(JSON.stringify(tpl, null, 2));
  } catch (e) {
    console.log("GetAIPrompt error:", e.name, e.message);
  }
}
