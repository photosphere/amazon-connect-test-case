import { describe, it, expect } from 'vitest';

describe('Project setup', () => {
  it('should have vitest configured correctly', () => {
    expect(true).toBe(true);
  });

  it('should resolve @shared path alias', async () => {
    const shared = await import('@shared/index');
    expect(shared).toBeDefined();
  });
});
