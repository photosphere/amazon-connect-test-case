/**
 * Pure partition of recommendations by their {@link ToolSurface} target field.
 *
 * Used by three call sites with one tested implementation:
 *   - The Recommended Changes Panel on the Run Dashboard.
 *   - The per-case detail page recommendations section.
 *   - The Failure Analysis View.
 *
 * The function is pure: no I/O, no clock, no globals. This is what lets the
 * property test in task 13.1 target it as a finite-state predicate
 * (R5.1, R7.1, R13.1, R15.1).
 *
 * @module recommendation-bucketing
 */

import type { Recommendation, ToolSurface } from "../types";

/**
 * Four-key partition of recommendations keyed by {@link ToolSurface}. Each
 * input recommendation appears in exactly one of the four arrays; the union
 * (with duplicates preserved) equals the input multiset; order within each
 * bucket matches input order.
 *
 * The generic parameter `T` lets callers bucket either a base
 * {@link Recommendation} or any extension (e.g. `PerSuiteRecommendation`)
 * without losing the extension's extra fields.
 */
export interface BucketedRecommendations<
  T extends Pick<Recommendation, "targetField">,
> {
  tool_description: T[];
  tool_instruction: T[];
  tool_examples: T[];
  system_prompt: T[];
}

/** The four valid {@link ToolSurface} values, used for membership checks. */
const VALID_TARGET_FIELDS: ReadonlySet<ToolSurface> = new Set<ToolSurface>([
  "tool_description",
  "tool_instruction",
  "tool_examples",
  "system_prompt",
]);

/**
 * Partition `recommendations` into four arrays keyed by `targetField`.
 *
 * Contract (R15.1):
 *   - Each input recommendation appears in exactly one output array — the
 *     one keyed by its `targetField`.
 *   - The concatenation of the four output arrays equals the input as a
 *     multiset (no records added, dropped, or duplicated).
 *   - Order within each bucket matches input order (stable partition).
 *
 * Throws on any recommendation whose `targetField` is not one of the four
 * valid {@link ToolSurface} values. Callers (`analysis.ts`,
 * `suite-recommend.ts`) are responsible for filtering invalid records
 * before bucketing per R5.9 and R6.5; this function refuses to silently
 * drop them so a contract violation upstream is visible rather than hidden.
 *
 * Pure: no I/O, no clock, no globals. Safe to property-test as a finite
 * predicate over its input array.
 *
 * @param recommendations Records to partition. Must have a valid
 *   {@link ToolSurface} on every entry's `targetField`.
 * @returns A four-key {@link BucketedRecommendations} with stable ordering.
 * @throws Error When any `recommendations[i].targetField` is not one of the
 *   four valid {@link ToolSurface} values.
 */
export function bucketByTargetField<
  T extends Pick<Recommendation, "targetField">,
>(recommendations: T[]): BucketedRecommendations<T> {
  const buckets: BucketedRecommendations<T> = {
    tool_description: [],
    tool_instruction: [],
    tool_examples: [],
    system_prompt: [],
  };

  for (let i = 0; i < recommendations.length; i++) {
    const rec = recommendations[i];
    const field = rec.targetField as ToolSurface;
    if (!VALID_TARGET_FIELDS.has(field)) {
      throw new Error(
        `bucketByTargetField: invalid targetField "${String(
          rec.targetField,
        )}" at index ${i}; expected one of ${Array.from(VALID_TARGET_FIELDS).join(
          ", ",
        )}`,
      );
    }
    buckets[field].push(rec);
  }

  return buckets;
}

/**
 * Partition recommendations into agent-targeted and test-case-targeted groups.
 *
 * Every input record appears in exactly one output group; the union of both
 * arrays equals the input (Property 4 / Requirement 11.1). Order within each
 * group matches input order (stable partition).
 *
 * Agent-targeted: `targetField` is one of the four {@link ToolSurface} values.
 * Test-case-targeted: `targetField` is `"test_case"`.
 *
 * The generic parameter allows callers to pass any record shape that contains
 * at least a `targetField` string, preserving the extension's extra fields.
 *
 * Pure: no I/O, no clock, no globals.
 *
 * @param recommendations Records to partition.
 * @returns An object with `agent` (ToolSurface-targeted) and `testCase`
 *   (`test_case`-targeted) arrays.
 */
export function partitionByTargetType<T extends { targetField: string }>(
  recommendations: T[],
): { agent: T[]; testCase: T[] } {
  const agent: T[] = [];
  const testCase: T[] = [];
  for (const rec of recommendations) {
    if (rec.targetField === "test_case") {
      testCase.push(rec);
    } else {
      agent.push(rec);
    }
  }
  return { agent, testCase };
}
