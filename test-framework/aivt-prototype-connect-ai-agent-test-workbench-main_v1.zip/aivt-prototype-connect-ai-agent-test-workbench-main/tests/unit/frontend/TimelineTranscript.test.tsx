// @vitest-environment jsdom
/**
 * Component tests for the shared {@link TimelineTranscript} component
 * (`src/frontend/src/components/Transcript/TimelineTranscript.tsx`),
 * which renders the chronological customer ↔ agent timeline interleaved
 * with the agent's reasoning steps and tool calls captured from
 * ListSpans. Both `CaseDetail.tsx` and `ResultsViewer.tsx` consume this
 * component, so its rendering invariants are the structural contract
 * those two surfaces share.
 *
 * Three rendering invariants are exercised here:
 *
 *   1. Scaffolding / handoff marker spans (`invoke_agent` and
 *      `escalate_agent`) MUST NOT render `(no text recorded for this
 *      span)` rows. The {@link isNoiseStep} predicate is the single
 *      source of truth for which span types the timeline filters out.
 *
 *   2. Synthetic control-tool steps (`spanName === "synthetic_control_tool"`)
 *      MUST render the explanatory `RETURN_TO_CONTROL — call arguments
 *      and result not surfaced by ListSpans` parenthetical instead of
 *      misleading `args {}` / `result {}` blocks. The borderLeft is
 *      neutral grey (`#5f6b7a`), not the tool-execution green.
 *
 *   3. Real tool steps (`spanName === "execute_tool"` or
 *      `spanName === "inference_tool_use"`) — both of which carry real
 *      arguments and (for execute_tool) results — MUST keep their
 *      existing rendering: `args {...}` / `result {...}` code blocks,
 *      green border on success.
 *
 * The targeted invariants above live entirely inside the pure helpers
 * `isNoiseStep` and `ReasoningStepRow`, so we exercise those directly
 * without bringing the full page under test.
 */

import React from 'react';
import { describe, it, expect, beforeAll, afterEach } from 'vitest';
import { render, screen, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

// The shared component module exports both `ReasoningStepRow` (the row
// renderer) and `isNoiseStep` (the filter predicate). Importing the
// module is safe from a test environment because its top-level only
// declares functions / constants and registers no side-effects until a
// component itself mounts.
import {
  ReasoningStepRow,
  isNoiseStep,
} from '../../../src/frontend/src/components/Transcript/TimelineTranscript';
import type { ExecutionStep } from '../../../src/shared/types';

// jsdom polyfills mirror the other component tests in this directory
// (see PromptDetailPage.test.tsx). Cloudscape's components rely on
// ResizeObserver and matchMedia even for small surface renders.
beforeAll(() => {
  const g = globalThis as unknown as {
    ResizeObserver?: unknown;
    IntersectionObserver?: unknown;
  };
  if (typeof g.ResizeObserver === 'undefined') {
    g.ResizeObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
    };
  }
  if (typeof g.IntersectionObserver === 'undefined') {
    g.IntersectionObserver = class {
      observe(): void {}
      unobserve(): void {}
      disconnect(): void {}
      takeRecords(): unknown[] {
        return [];
      }
      readonly root = null;
      readonly rootMargin = '';
      readonly thresholds: ReadonlyArray<number> = [];
    };
  }
  if (typeof window.matchMedia !== 'function') {
    window.matchMedia = (query: string) =>
      ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => {},
        removeListener: () => {},
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => false,
      }) as MediaQueryList;
  }
});

afterEach(() => {
  cleanup();
});

// ---------------------------------------------------------------------------
// Fixture builders
// ---------------------------------------------------------------------------

/** Builds a fixture `ExecutionStep` with reasonable defaults. */
function makeStep(overrides: Partial<ExecutionStep>): ExecutionStep {
  return {
    index: 0,
    type: 'inference',
    spanName: 'inference',
    timestamp: '2024-01-01T00:00:00.000Z',
    ...overrides,
  } as ExecutionStep;
}

// ---------------------------------------------------------------------------
// isNoiseStep — the source of truth for which spans are filtered out
// before the Transcript timeline is rendered.
// ---------------------------------------------------------------------------

describe('isNoiseStep', () => {
  it('classifies invoke_agent (type: "agent") as noise', () => {
    expect(
      isNoiseStep(
        makeStep({ type: 'agent', spanName: 'invoke_agent' }),
      ),
    ).toBe(true);
  });

  it('classifies escalate_agent (type: "other") as noise', () => {
    expect(
      isNoiseStep(
        makeStep({ type: 'other', spanName: 'escalate_agent' }),
      ),
    ).toBe(true);
  });

  it('classifies complete_agent (type: "other") as noise', () => {
    expect(
      isNoiseStep(
        makeStep({ type: 'other', spanName: 'complete_agent' }),
      ),
    ).toBe(true);
  });

  it('does not classify inference steps as noise', () => {
    expect(
      isNoiseStep(
        makeStep({
          type: 'inference',
          spanName: 'inference',
          text: 'I will help you with that.',
        }),
      ),
    ).toBe(false);
  });

  it('does not classify execute_tool steps as noise', () => {
    expect(
      isNoiseStep(
        makeStep({
          type: 'tool',
          spanName: 'execute_tool',
          tool: {
            toolName: 'verifyIdentity',
            arguments: { ani: '+15555550100' },
            result: { status: 'success' },
            success: true,
          },
        }),
      ),
    ).toBe(false);
  });

  it('does not classify inference_tool_use steps as noise', () => {
    expect(
      isNoiseStep(
        makeStep({
          type: 'tool',
          spanName: 'inference_tool_use',
          tool: {
            toolName: 'Escalate',
            arguments: { reason: 'identity check failed' },
            result: undefined,
            success: true,
          },
        }),
      ),
    ).toBe(false);
  });

  it('does not classify synthetic_control_tool steps as noise', () => {
    // Synthetic control tools are filtered through to the renderer so
    // the user sees the explanatory parenthetical — they are NOT
    // dropped from the timeline.
    expect(
      isNoiseStep(
        makeStep({
          type: 'tool',
          spanName: 'synthetic_control_tool',
          tool: {
            toolName: 'Escalate',
            arguments: {},
            result: {},
            success: true,
          },
        }),
      ),
    ).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// ReasoningStepRow — render branches for the three tool-step shapes plus
// inference text.
// ---------------------------------------------------------------------------

describe('ReasoningStepRow', () => {
  it('renders an execute_tool step with args / result blocks (real MCP tool)', () => {
    const step = makeStep({
      index: 4,
      type: 'tool',
      spanName: 'execute_tool',
      tool: {
        toolName: 'verifyIdentity',
        arguments: { ani: '+15555550100' },
        result: { status: 'success' },
        success: true,
      },
    });

    const { container } = render(<ReasoningStepRow step={step} />);

    // Header carries the tool name.
    expect(
      screen.getByText(/Tool · verifyIdentity/),
    ).toBeInTheDocument();
    // The args / result blocks render as `<pre>` content. JSON.stringify
    // produces line-wrapped JSON, so we assert on the rendered HTML
    // rather than text-node matching (which would match every ancestor
    // up to <body>).
    const html = container.innerHTML;
    expect(html).toMatch(/args\s+\{[\s\S]*"ani"/);
    expect(html).toMatch(/result\s+\{[\s\S]*"status"/);
    // Real tool branch must NOT show the synthetic explanatory copy.
    expect(
      screen.queryByText(/RETURN_TO_CONTROL/i),
    ).not.toBeInTheDocument();
    // Border colour is the success green (`#2e7d32` →
    // `rgb(46, 125, 50)` after jsdom's CSS normalisation).
    const root = container.firstChild as HTMLElement;
    expect(root.style.borderLeft).toMatch(/rgb\(46,\s*125,\s*50\)/);
  });

  it('renders an inference_tool_use step with full args (control tool with observable payload)', () => {
    const step = makeStep({
      index: 7,
      type: 'tool',
      spanName: 'inference_tool_use',
      tool: {
        toolName: 'Escalate',
        arguments: { reason: 'authentication failed' },
        result: undefined,
        success: true,
      },
    });

    const { container } = render(<ReasoningStepRow step={step} />);

    expect(screen.getByText(/Tool · Escalate/)).toBeInTheDocument();
    // `arguments` is defined and non-empty → the args block must render
    // with the real payload. `result` is `undefined` so the result
    // block is intentionally suppressed.
    const html = container.innerHTML;
    expect(html).toMatch(/args\s+\{[\s\S]*"reason"/);
    // No result block rendered (the conditional in the page only
    // emits one when `step.tool.result !== undefined`).
    expect(html).not.toMatch(/result\s+\{/);
    expect(
      screen.queryByText(/RETURN_TO_CONTROL/i),
    ).not.toBeInTheDocument();
  });

  it('renders a synthetic_control_tool step with the RETURN_TO_CONTROL parenthetical and no args / result blocks', () => {
    // Synthetic control tools are produced by
    // `augmentTraceWithControlTools` when ListSpans did not surface the
    // toolUse on the inference span. Their `arguments` and `result` are
    // empty placeholders; rendering them as `args {}` / `result {}`
    // would mislead the user. The judge prompt-rendering layer
    // already substitutes an explanatory parenthetical (see
    // `SYNTHETIC_CONTROL_TOOL_NOTE` in
    // `src/shared/utils/judge-prompt-rendering.ts`); the Transcript
    // view matches.
    const step = makeStep({
      index: 12,
      type: 'tool',
      spanName: 'synthetic_control_tool',
      tool: {
        toolName: 'Escalate',
        arguments: {},
        result: {},
        success: true,
      },
    });

    const { container } = render(<ReasoningStepRow step={step} />);

    // Header label still names the tool.
    expect(screen.getByText(/Tool · Escalate/)).toBeInTheDocument();
    // The explanatory parenthetical is present and matches the
    // wording the judge prompt-rendering layer emits.
    expect(
      screen.getByText(
        /RETURN_TO_CONTROL — call arguments and result not surfaced by ListSpans\./i,
      ),
    ).toBeInTheDocument();

    // Crucially, the misleading `args {}` and `result {}` placeholder
    // lines must NOT appear.
    const html = container.innerHTML;
    expect(html).not.toMatch(/args\s*\{/);
    expect(html).not.toMatch(/result\s*\{/);

    // The borderLeft is neutral grey, not the green / red of a real
    // tool step. jsdom normalises the hex colour `#5f6b7a` to its rgb
    // form `rgb(95, 107, 122)` when reading back the inline style.
    const root = container.firstChild as HTMLElement;
    expect(root.style.borderLeft).toMatch(/rgb\(95,\s*107,\s*122\)/);
  });

  it('renders an inference step text (not the noise placeholder) when text is present', () => {
    const step = makeStep({
      index: 1,
      type: 'inference',
      spanName: 'inference',
      text: 'I will look up the account now.',
    });

    render(<ReasoningStepRow step={step} />);

    expect(
      screen.getByText('I will look up the account now.'),
    ).toBeInTheDocument();
    // The `(no text recorded ...)` placeholder is the fallback for an
    // inference step without text — the noise-span rows that previously
    // rendered this placeholder are filtered out before they reach
    // ReasoningStepRow (see the `isNoiseStep` filter in TimelineTranscript).
    expect(
      screen.queryByText(/no text recorded for this span/i),
    ).not.toBeInTheDocument();
  });
});
