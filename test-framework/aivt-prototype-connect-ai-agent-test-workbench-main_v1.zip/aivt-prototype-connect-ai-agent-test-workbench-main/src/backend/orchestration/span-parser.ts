/**
 * Span Parser — converts raw Q in Connect ListSpans output into a structured,
 * turn-by-turn ExecutionTrace.
 *
 * WHY THIS EXISTS: GetNextMessage's `conversationSessionData["Tool"]` only
 * reports RETURN_TO_CONTROL tools (Complete/Escalate); the real MODEL_CONTEXT_
 * PROTOCOL tools (verifyIdentity, getAccounts, ...) are ONLY visible as
 * `execute_tool` spans in ListSpans. This parser is therefore the authoritative
 * source for the tool sequence, and it also captures the agent's reasoning
 * (inference span output) and each tool's arguments/results — the data needed
 * to debug failed cases and to drive prompt/tool-description recommendations.
 *
 * @module span-parser
 */

import type {
  ExecutionStep,
  ExecutionTrace,
  InferenceMetadata,
  ToolInvocation,
} from "../../shared/types";

/** Minimal shape of a raw span from ListSpans (only the fields we read). */
export interface RawSpan {
  spanName?: string;
  startTimestamp?: string;
  /**
   * Wall-clock timestamp of when the span ended, if Q in Connect supplied
   * one. We use it to give synthetic `inference_tool_use` steps (extracted
   * from an inference span's `outputMessages.toolUse`) a timestamp that
   * sorts strictly after the inference's own `startTimestamp` and any
   * preceding span — falling back to `startTimestamp` when `endTimestamp`
   * is absent.
   */
  endTimestamp?: string;
  attributes?: RawSpanAttributes;
}

interface RawSpanAttributes {
  aiAgentName?: string;
  aiAgentType?: string;
  inputMessages?: RawSpanMessage[];
  outputMessages?: RawSpanMessage[];
  usageInputTokens?: unknown;
  usageOutputTokens?: unknown;
  usageTotalTokens?: unknown;
  requestModel?: unknown;
  requestMaxTokens?: unknown;
  temperature?: unknown;
  timeToFirstTokenMs?: unknown;
  responseFinishReasons?: unknown;
  promptArn?: unknown;
  promptId?: unknown;
  promptName?: unknown;
  promptVersion?: unknown;
  aiAgentVersion?: unknown;
  systemInstructions?: Array<{ text?: { value?: unknown } }>;
}

interface RawSpanMessage {
  values?: RawSpanValue[];
}

interface RawSpanValue {
  text?: { value?: string };
  toolUse?: { name?: string; arguments?: unknown };
  toolResult?: { values?: Array<{ text?: { value?: string } }> };
  reasoning?: { value?: string };
}

/** Best-effort JSON parse: returns parsed object or the original string. */
function tryParseJson(raw: unknown): unknown {
  if (typeof raw !== "string") return raw;
  const trimmed = raw.trim();
  if (!trimmed) return raw;
  try {
    return JSON.parse(trimmed);
  } catch {
    return raw;
  }
}

/**
 * Determines whether a tool result represents success.
 *
 * Tool results commonly look like {"status":"success",...} or
 * {"status":"error","message":"..."}. We treat an explicit "error" status (or
 * the substring "error") as failure; everything else defaults to success.
 */
export function isToolResultSuccess(result: unknown): boolean {
  if (result == null) return true;

  if (typeof result === "object") {
    const status = (result as Record<string, unknown>).status;
    if (typeof status === "string") {
      return status.toLowerCase() !== "error";
    }
    // Nested { output: "{...}" } or { status, ... } — fall through to string scan
    const serialized = JSON.stringify(result).toLowerCase();
    return !serialized.includes('"status":"error"') && !serialized.includes('"status": "error"');
  }

  if (typeof result === "string") {
    const lower = result.toLowerCase();
    return !lower.includes('"status":"error"') && !lower.includes('"status": "error"');
  }

  return true;
}

/**
 * Extracts and concatenates valid reasoning strings from a span's output messages.
 *
 * Iterates through all `outputMessages[].values[]` entries, collecting each
 * `reasoning.value` that is a string with non-zero trimmed length. Valid entries
 * are joined with a single `"\n"` separator. Invalid entries (null, undefined,
 * non-string, empty string, whitespace-only) are silently skipped without
 * emitting a separator.
 *
 * Returns `undefined` (not empty string, not null) when no valid entries exist.
 *
 * Pure function — no I/O, no side effects.
 */
export function extractReasoning(outputMessages: RawSpanMessage[] | undefined): string | undefined {
  const valid: string[] = [];
  for (const msg of outputMessages ?? []) {
    for (const v of msg.values ?? []) {
      const r = v.reasoning?.value;
      if (typeof r === "string" && r.trim().length > 0) {
        valid.push(r);
      }
    }
  }
  return valid.length > 0 ? valid.join("\n") : undefined;
}

/**
 * Computes the wall-clock duration in milliseconds between two ISO timestamps.
 *
 * Returns `undefined` if either timestamp is missing, empty, or unparseable.
 * Returns `0` (with a console.warn) if the difference is negative.
 * Otherwise returns `Math.round(end - start)`.
 *
 * Pure function — no I/O, no side effects beyond the one console.warn for
 * negative durations.
 */
export function computeDurationMs(
  startTimestamp: string | undefined | null,
  endTimestamp: string | undefined | null,
  spanName?: string,
): number | undefined {
  if (!startTimestamp || !endTimestamp) return undefined;

  const start = Date.parse(startTimestamp);
  const end = Date.parse(endTimestamp);

  if (Number.isNaN(start) || Number.isNaN(end)) return undefined;

  const diff = end - start;

  if (diff < 0) {
    console.warn(
      `Negative span duration for "${spanName ?? "unknown"}": start=${startTimestamp}, end=${endTimestamp}`,
    );
    return 0;
  }

  return Math.round(diff);
}

/**
 * Extracts inference metadata from a span's attributes by type-checking each
 * of the 14 source fields against its expected type.
 *
 * Builds `systemInstructions` by filtering `attributes.systemInstructions[]`
 * to entries whose `text.value` is a string, joining valid strings with "\n\n".
 * Omits `systemInstructions` entirely when the filtered list is empty.
 *
 * Returns `undefined` when zero fields pass type validation (NOT an empty
 * object, NOT null). Never throws — silently skips fields that don't match
 * expected types.
 *
 * Pure function — no I/O, no side effects.
 */
export function extractInferenceMetadata(attributes: RawSpanAttributes): InferenceMetadata | undefined {
  const result: InferenceMetadata = {};
  let fieldCount = 0;

  // Number fields
  if (typeof attributes.usageInputTokens === "number") {
    result.usageInputTokens = attributes.usageInputTokens;
    fieldCount++;
  }
  if (typeof attributes.usageOutputTokens === "number") {
    result.usageOutputTokens = attributes.usageOutputTokens;
    fieldCount++;
  }
  if (typeof attributes.usageTotalTokens === "number") {
    result.usageTotalTokens = attributes.usageTotalTokens;
    fieldCount++;
  }
  if (typeof attributes.requestMaxTokens === "number") {
    result.requestMaxTokens = attributes.requestMaxTokens;
    fieldCount++;
  }
  if (typeof attributes.temperature === "number") {
    result.temperature = attributes.temperature;
    fieldCount++;
  }
  if (typeof attributes.timeToFirstTokenMs === "number") {
    result.timeToFirstTokenMs = attributes.timeToFirstTokenMs;
    fieldCount++;
  }
  if (typeof attributes.promptVersion === "number") {
    result.promptVersion = attributes.promptVersion;
    fieldCount++;
  }
  if (typeof attributes.aiAgentVersion === "number") {
    result.aiAgentVersion = attributes.aiAgentVersion;
    fieldCount++;
  }

  // String fields
  if (typeof attributes.requestModel === "string") {
    result.requestModel = attributes.requestModel;
    fieldCount++;
  }
  if (typeof attributes.promptArn === "string") {
    result.promptArn = attributes.promptArn;
    fieldCount++;
  }
  if (typeof attributes.promptId === "string") {
    result.promptId = attributes.promptId;
    fieldCount++;
  }
  if (typeof attributes.promptName === "string") {
    result.promptName = attributes.promptName;
    fieldCount++;
  }

  // Array field: responseFinishReasons — must be an array with every element a string
  if (
    Array.isArray(attributes.responseFinishReasons) &&
    attributes.responseFinishReasons.every((el: unknown) => typeof el === "string")
  ) {
    result.responseFinishReasons = attributes.responseFinishReasons as string[];
    fieldCount++;
  }

  // systemInstructions: filter to valid text.value strings, join with "\n\n"
  if (Array.isArray(attributes.systemInstructions)) {
    const validInstructions: string[] = [];
    for (const entry of attributes.systemInstructions) {
      if (typeof entry?.text?.value === "string") {
        validInstructions.push(entry.text.value as string);
      }
    }
    if (validInstructions.length > 0) {
      result.systemInstructions = validInstructions.join("\n\n");
      fieldCount++;
    }
  }

  return fieldCount > 0 ? result : undefined;
}

/** Extracts the first non-empty text value from a span's message list. */
function extractText(messages: RawSpanMessage[] | undefined): string | undefined {
  for (const msg of messages ?? []) {
    for (const v of msg.values ?? []) {
      const t = v.text?.value;
      if (t && t.trim() && !["...", "......", "\u2026"].includes(t.trim())) {
        return t.trim();
      }
    }
  }
  return undefined;
}

/** Extracts a tool invocation (name + args + result + success) from a span. */
function extractToolInvocation(
  attrs: RawSpanAttributes,
  timestamp?: string
): ToolInvocation | undefined {
  let toolName: string | undefined;
  let args: unknown;
  for (const msg of attrs.inputMessages ?? []) {
    for (const v of msg.values ?? []) {
      if (v.toolUse?.name) {
        toolName = v.toolUse.name;
        args = tryParseJson(v.toolUse.arguments);
      }
    }
  }
  if (!toolName) return undefined;

  let result: unknown;
  for (const msg of attrs.outputMessages ?? []) {
    for (const v of msg.values ?? []) {
      const text = v.toolResult?.values?.[0]?.text?.value;
      if (text !== undefined) {
        result = tryParseJson(text);
      }
    }
  }

  return {
    toolName,
    arguments: args,
    result,
    success: isToolResultSuccess(result),
    timestamp,
  };
}

/**
 * Extract every `toolUse` block from a span's `outputMessages`. Q in
 * Connect emits RETURN_TO_CONTROL tools (Escalate, Complete, custom
 * control tools) as `toolUse` entries on the `inference` span's
 * `outputMessages` rather than as separate `execute_tool` spans (the
 * platform consumes the call directly via the RETURN_TO_CONTROL
 * channel; the `escalate_agent` / `complete_agent` span is just a
 * marker that orchestration handed off control).
 *
 * MCP tools, by contrast, ALSO surface a `toolUse` entry on the
 * inference span (as part of the agent's reasoning output) AND on a
 * separate `execute_tool` span (when the tool actually executes). To
 * avoid recording MCP tools twice (once from inference and once from
 * execute_tool) the caller passes `executeToolNames` — a set of every
 * tool name observed on an `execute_tool` span across the trace —
 * and this helper skips any toolUse whose name is in that set. The
 * `execute_tool` span is the authoritative record (it has full
 * arguments AND result). RETURN_TO_CONTROL tools never appear on an
 * `execute_tool` span (Q in Connect consumes them upstream), so they
 * are NOT in the set and are preserved as `inference_tool_use` steps
 * here.
 *
 * Returns an array because a single inference span can in principle
 * carry multiple toolUse entries (the model emitted multiple tool
 * calls in one turn before the orchestrator dispatched any of them).
 * In practice we observe one per inference, but supporting N is
 * trivial here.
 */
function extractToolUsesFromOutputMessages(
  attrs: RawSpanAttributes,
  timestamp: string | undefined,
  executeToolNames: ReadonlySet<string>,
): ToolInvocation[] {
  const out: ToolInvocation[] = [];
  for (const msg of attrs.outputMessages ?? []) {
    for (const v of msg.values ?? []) {
      const name = v.toolUse?.name;
      if (!name) continue;
      // Skip MCP tools that are also recorded on a dedicated
      // execute_tool span — the execute_tool path is authoritative.
      if (executeToolNames.has(name)) continue;
      out.push({
        toolName: name,
        arguments: tryParseJson(v.toolUse?.arguments),
        // RETURN_TO_CONTROL tool calls don't carry a result on the
        // inference span — the result, if any, is delivered out-of-
        // band via the conversation handoff. Mark success: true so
        // the trace's tool-success metric is consistent with the
        // case row's `toolsInvoked` (which records the tool as
        // having fired).
        result: undefined,
        success: true,
        timestamp,
      });
    }
  }
  return out;
}

/**
 * Walk all spans once and collect the name of every tool observed on
 * an `execute_tool` span. Used to deduplicate MCP toolUses that also
 * show up on the inference span's `outputMessages` — see
 * `extractToolUsesFromOutputMessages` for the rationale.
 *
 * Keying by tool name only (not name + args) is intentional: it's
 * the simpler invariant and matches the most common shape (one tool
 * call per inference turn). If an agent calls the same tool twice in
 * one session with different args, the second `execute_tool` span
 * still records it with full arguments, so the trace's `toolSequence`
 * and `steps[]` remain correct — we only lose the (redundant)
 * inference-span echo of the second call.
 */
function collectExecuteToolNames(spans: readonly RawSpan[]): Set<string> {
  const names = new Set<string>();
  for (const span of spans) {
    if (span.spanName !== "execute_tool") continue;
    for (const msg of span.attributes?.inputMessages ?? []) {
      for (const v of msg.values ?? []) {
        if (v.toolUse?.name) names.add(v.toolUse.name);
      }
    }
  }
  return names;
}

/** Maps a span name to an ExecutionStep type. */
function stepType(spanName: string): ExecutionStep["type"] {
  if (spanName === "execute_tool") return "tool";
  if (spanName === "inference") return "inference";
  if (spanName === "invoke_agent") return "agent";
  return "other";
}

/**
 * Parses raw ListSpans output into a structured ExecutionTrace.
 *
 * Steps are sorted chronologically by startTimestamp. The authoritative tool
 * sequence is derived from `execute_tool` spans (in order). Agent identity is
 * taken from the first span that carries it.
 *
 * @param sessionId - The session the spans came from
 * @param rawSpans - Raw spans from ListSpans
 * @returns A structured ExecutionTrace
 */
export function parseSpansToTrace(
  sessionId: string,
  rawSpans: RawSpan[]
): ExecutionTrace {
  const sorted = rawSpans
    .slice()
    .sort((a, b) => {
      const ta = a.startTimestamp ?? "";
      const tb = b.startTimestamp ?? "";
      return ta < tb ? -1 : ta > tb ? 1 : 0;
    });

  // Pre-pass: collect every tool name observed on an `execute_tool`
  // span. Used below to deduplicate MCP toolUses that also appear on
  // the inference span's outputMessages — see
  // `extractToolUsesFromOutputMessages` for the rationale.
  const executeToolNames = collectExecuteToolNames(sorted);

  const steps: ExecutionStep[] = [];
  const toolSequence: string[] = [];
  let aiAgentName: string | undefined;
  let aiAgentType: string | undefined;

  let index = 0;
  for (const span of sorted) {
    const spanName = span.spanName ?? "unknown";
    const attrs = span.attributes ?? {};

    if (!aiAgentName && attrs.aiAgentName) aiAgentName = attrs.aiAgentName;
    if (!aiAgentType && attrs.aiAgentType) aiAgentType = attrs.aiAgentType;

    const type = stepType(spanName);

    if (type === "tool") {
      const tool = extractToolInvocation(attrs, span.startTimestamp);
      if (tool) {
        toolSequence.push(tool.toolName);
        steps.push({
          index: index++,
          type,
          spanName,
          tool,
          aiAgentName: attrs.aiAgentName,
          aiAgentType: attrs.aiAgentType,
          timestamp: span.startTimestamp,
          durationMs: computeDurationMs(span.startTimestamp, span.endTimestamp, spanName),
        });
      }
      continue;
    }

    if (type === "inference") {
      // Capture the agent's output text (reasoning / customer-facing message).
      const text = extractText(attrs.outputMessages) ?? extractText(attrs.inputMessages);
      steps.push({
        index: index++,
        type,
        spanName,
        text,
        aiAgentName: attrs.aiAgentName,
        aiAgentType: attrs.aiAgentType,
        timestamp: span.startTimestamp,
        durationMs: computeDurationMs(span.startTimestamp, span.endTimestamp, spanName),
        reasoning: extractReasoning(attrs.outputMessages),
        inferenceMetadata: attrs ? extractInferenceMetadata(attrs) : undefined,
      });

      // Q in Connect surfaces RETURN_TO_CONTROL tool calls (Escalate,
      // Complete, custom control tools) as `toolUse` entries on the
      // inference span's `outputMessages`. Emit a distinct `tool` step
      // for each so the rendering layer sees the call with full
      // arguments. Use `endTimestamp` (falling back to `startTimestamp`)
      // so these synthesised steps sort strictly after the inference
      // they were emitted by — and before any subsequent
      // `execute_tool` / `escalate_agent` span.
      const toolUseTimestamp = span.endTimestamp ?? span.startTimestamp;
      const toolUses = extractToolUsesFromOutputMessages(
        attrs,
        toolUseTimestamp,
        executeToolNames,
      );
      for (const tool of toolUses) {
        toolSequence.push(tool.toolName);
        steps.push({
          index: index++,
          type: "tool",
          spanName: "inference_tool_use",
          tool,
          aiAgentName: attrs.aiAgentName,
          aiAgentType: attrs.aiAgentType,
          timestamp: toolUseTimestamp,
          durationMs: undefined,
        });
      }
      continue;
    }

    // invoke_agent / other — keep a lightweight marker for completeness.
    steps.push({
      index: index++,
      type,
      spanName,
      aiAgentName: attrs.aiAgentName,
      aiAgentType: attrs.aiAgentType,
      timestamp: span.startTimestamp,
      durationMs: computeDurationMs(span.startTimestamp, span.endTimestamp, spanName),
    });
  }

  return {
    sessionId,
    steps,
    toolSequence,
    aiAgentName,
    aiAgentType,
    capturedAt: new Date().toISOString(),
  };
}

/**
 * Fallback augmenter — appends synthetic `type: "tool"` steps for any
 * RETURN_TO_CONTROL tool the conversation driver observed via
 * `conversationSessionData["Tool"]` that does NOT already appear in
 * `trace.toolSequence`.
 *
 * Most of the time this is a no-op. The primary path is now
 * {@link parseSpansToTrace}, which extracts RETURN_TO_CONTROL tool
 * calls (with full arguments) from the `inference` span's
 * `outputMessages.toolUse` entries and emits them as
 * `inference_tool_use` steps with real `ToolInvocation` payloads. By
 * the time this augmenter runs the call is almost always already in
 * `trace.toolSequence` and we skip it.
 *
 * The augmenter only synthesises a step when:
 *   - The control tool name in `controlToolsInvoked` is NOT already
 *     in `trace.toolSequence` (the inference extraction did not pick
 *     it up — possible if Q in Connect ever surfaces a control tool
 *     somewhere other than `inference.outputMessages`), AND
 *   - The polling loop did capture the name via
 *     `conversationSessionData["Tool"]`.
 *
 * In that fallback case the synthetic step's arguments and result
 * are empty (`{}`) — Q in Connect did not surface them on any span we
 * can read. The rendering layer recognises the
 * `synthetic_control_tool` spanName and emits an explanatory
 * parenthetical instead of a misleading `Action: <Tool>({})` line.
 *
 * Implementation: walk `controlToolsInvoked` in order, and for each
 * entry not already present in `trace.toolSequence`, append a
 * synthetic step at the END of `trace.steps[]` with `type: "tool"`,
 * a synthesised `ToolInvocation` (`arguments: {}`, `result: {}`,
 * `success: true`), and the timestamp of the last span we observed
 * (or the trace's `capturedAt` if no span had a timestamp). Append
 * the tool name to `toolSequence` in the same order.
 *
 * The "append at end" placement is intentional: RETURN_TO_CONTROL
 * tools by construction terminate the agent's turn, so they always
 * come AFTER the model's last `inference` span.
 *
 * Pure function — no I/O. Returns a new trace; does not mutate
 * inputs.
 *
 * @param trace - The structured execution trace from `parseSpansToTrace`
 * @param controlToolsInvoked - Names of RETURN_TO_CONTROL tools captured
 *   from `conversationSessionData["Tool"]`, in chronological order
 * @returns A new ExecutionTrace whose `steps[]` and `toolSequence`
 *   include synthetic entries for every control tool not already covered
 *   by an `execute_tool` or `inference_tool_use` step
 */
export function augmentTraceWithControlTools(
  trace: ExecutionTrace,
  controlToolsInvoked: readonly string[],
): ExecutionTrace {
  // Resolve the timestamp the synthetic steps will carry — use the last
  // observed span's timestamp so the synthetic steps sort chronologically
  // after every real span. Fall back to the trace's `capturedAt`.
  let lastTimestamp: string | undefined;
  for (const step of trace.steps) {
    if (step.timestamp) lastTimestamp = step.timestamp;
  }
  const syntheticTimestamp = lastTimestamp ?? trace.capturedAt;

  const existingTools = new Set(trace.toolSequence);
  const newSteps: ExecutionStep[] = [...trace.steps];
  const newToolSequence: string[] = [...trace.toolSequence];

  let nextIndex =
    newSteps.length > 0 ? newSteps[newSteps.length - 1].index + 1 : 0;

  for (const toolName of controlToolsInvoked) {
    if (existingTools.has(toolName)) continue;

    const tool: ToolInvocation = {
      toolName,
      arguments: {},
      result: {},
      success: true,
      timestamp: syntheticTimestamp,
    };

    newSteps.push({
      index: nextIndex++,
      type: "tool",
      // Use a distinct synthesised spanName so a downstream consumer that
      // distinguishes real `execute_tool` spans from this augmentation can
      // tell them apart without re-deriving from the controlToolsInvoked
      // list.
      spanName: "synthetic_control_tool",
      tool,
      aiAgentName: trace.aiAgentName,
      aiAgentType: trace.aiAgentType,
      timestamp: syntheticTimestamp,
      durationMs: undefined,
    });
    newToolSequence.push(toolName);
    existingTools.add(toolName);
  }

  return {
    ...trace,
    steps: newSteps,
    toolSequence: newToolSequence,
  };
}
