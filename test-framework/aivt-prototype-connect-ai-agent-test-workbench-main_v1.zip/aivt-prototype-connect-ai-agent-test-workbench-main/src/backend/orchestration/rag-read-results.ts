/**
 * ReadRagResults Lambda — Step Functions sub-workflow step 3.
 *
 * Extracted from the monolithic rag-evaluate.ts. This handler:
 * - On success path (status === "Completed"):
 *   1. Reads per-prompt output from S3.
 *   2. Parses metrics using the same format the old handler used.
 *   3. Applies pass/fail thresholds via computeRagCaseStatus.
 *   4. Writes ragMetrics to DDB per case.
 *   5. Persists RAGJOB record with COMPLETED status.
 * - On error path (status in Failed, Stopped, Stopping, Timeout):
 *   1. Writes appropriate error codes to all cases.
 *   2. Persists RAGJOB record with failure status.
 *
 * @module rag-read-results
 */

import { S3Client, GetObjectCommand, ListObjectsV2Command } from "@aws-sdk/client-s3";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, UpdateCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import { computeRagCaseStatus } from "./rag-decision";
import { PK_PATTERNS } from "../../shared/constants";
import type { RagMetrics, RagThresholds, EvaluationErrorCode } from "../../shared/types";
import { DEFAULT_RAG_THRESHOLDS } from "../../shared/types";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION ?? "us-east-1";
const RAG_JOB_BUCKET = process.env.RAG_JOB_BUCKET ?? "";
const TABLE_NAME = process.env.TABLE_NAME ?? "ConnectAgentTestPlatform";

// ---------------------------------------------------------------------------
// Clients (lazy singletons; injectable for tests)
// ---------------------------------------------------------------------------

let s3Client: S3Client | null = null;
let docClient: DynamoDBDocumentClient | null = null;

function getS3Client(): S3Client {
  if (!s3Client) s3Client = new S3Client({ region: REGION });
  return s3Client;
}

function getDocClient(): DynamoDBDocumentClient {
  if (!docClient) {
    const ddbClient = new DynamoDBClient({ region: REGION });
    docClient = DynamoDBDocumentClient.from(ddbClient, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }
  return docClient;
}

/** @internal Test-only injectors. */
export function _setS3Client(client: S3Client | null): void { s3Client = client as S3Client | null; }
export function _setDocClient(client: DynamoDBDocumentClient | null): void { docClient = client as DynamoDBDocumentClient | null; }

// ---------------------------------------------------------------------------
// Input / Output interfaces
// ---------------------------------------------------------------------------

/** Input from Step Functions — merged SubmitRagJob output + CheckRagJobStatus output. */
export interface ReadRagResultsInput {
  runId: string;
  suiteId?: string;
  jobArn: string;
  indexMap: Record<number, string>;
  ragThresholds?: RagThresholds;
  startedAt: string;
  judgeModelId: string;
  inputS3Uri: string;
  submittedCaseCount: number;
  /** From CheckRagJobStatus — determines success vs error path. */
  status: "Completed" | "Failed" | "Stopped" | "Stopping" | "Timeout" | "SKIPPED";
  /** S3 output path from GetEvaluationJob (on Completed). */
  outputPath?: string;
  pollCount?: number;
}

/** Output returned to Step Functions. */
export interface ReadRagResultsOutput {
  runId: string;
  evaluatedCount: number;
  errorCount: number;
  status: "COMPLETED" | "FAILED" | "TIMEOUT" | "SKIPPED";
}

// ---------------------------------------------------------------------------
// Helpers: per-prompt result parsing
// ---------------------------------------------------------------------------

interface PerPromptResult {
  lineIndex: number;
  metrics: {
    faithfulness?: number;
    correctness?: number;
    completeness?: number;
    helpfulness?: number;
  };
}

async function readPerPromptResults(_outputPath: string, runId: string): Promise<PerPromptResult[]> {
  const outputPrefix = `${runId}/output/`;

  const listResponse = await getS3Client().send(
    new ListObjectsV2Command({
      Bucket: RAG_JOB_BUCKET,
      Prefix: outputPrefix,
    }),
  );

  const objects = listResponse.Contents ?? [];
  const perPromptObject = objects.find(
    (obj) => obj.Key && (obj.Key.includes("per_prompt") || obj.Key.includes("per-prompt") || obj.Key.endsWith(".jsonl")),
  );

  if (!perPromptObject?.Key) {
    console.error("[rag-read-results] No per-prompt output file found under", outputPrefix);
    return [];
  }

  const getResponse = await getS3Client().send(
    new GetObjectCommand({
      Bucket: RAG_JOB_BUCKET,
      Key: perPromptObject.Key,
    }),
  );

  const bodyStr = await getResponse.Body?.transformToString("utf-8");
  if (!bodyStr) {
    console.error("[rag-read-results] Empty per-prompt output file:", perPromptObject.Key);
    return [];
  }

  const results: PerPromptResult[] = [];
  const lines = bodyStr.trim().split("\n");

  for (let i = 0; i < lines.length; i++) {
    try {
      const parsed = JSON.parse(lines[i]);
      const metrics: PerPromptResult["metrics"] = {};

      // Bedrock RAG evaluation output format:
      // { conversationTurns: [{ inputRecord, output, results: [{ metricName, result }] }] }
      const turns = parsed.conversationTurns;
      if (Array.isArray(turns) && turns.length > 0) {
        const turnResults = turns[0].results;
        if (Array.isArray(turnResults)) {
          for (const mr of turnResults) {
            const name = (mr.metricName ?? "").toLowerCase();
            const score = mr.result !== undefined ? Number(mr.result) : undefined;
            if (name.includes("faithfulness") && score !== undefined) metrics.faithfulness = score;
            if (name.includes("correctness") && score !== undefined) metrics.correctness = score;
            if (name.includes("completeness") && score !== undefined) metrics.completeness = score;
            if (name.includes("helpfulness") && score !== undefined) metrics.helpfulness = score;
          }
        }
      }

      // Fallback: legacy flat format
      if (metrics.faithfulness === undefined && metrics.correctness === undefined) {
        const scoreSource = parsed.scores ?? parsed.metrics ?? parsed.evaluationResults;
        if (scoreSource && typeof scoreSource === "object") {
          if (scoreSource.faithfulness !== undefined) metrics.faithfulness = Number(scoreSource.faithfulness);
          if (scoreSource.correctness !== undefined) metrics.correctness = Number(scoreSource.correctness);
          if (scoreSource.completeness !== undefined) metrics.completeness = Number(scoreSource.completeness);
          if (scoreSource.helpfulness !== undefined) metrics.helpfulness = Number(scoreSource.helpfulness);
          if (scoreSource.Faithfulness !== undefined) metrics.faithfulness = Number(scoreSource.Faithfulness);
          if (scoreSource.Correctness !== undefined) metrics.correctness = Number(scoreSource.Correctness);
          if (scoreSource.Completeness !== undefined) metrics.completeness = Number(scoreSource.Completeness);
          if (scoreSource.Helpfulness !== undefined) metrics.helpfulness = Number(scoreSource.Helpfulness);
        }
      }

      const lineIndex = parsed.promptIndex ?? parsed.index ?? i;
      results.push({ lineIndex, metrics });
    } catch (parseErr) {
      console.error("[rag-read-results] Failed to parse line", i);
      results.push({ lineIndex: i, metrics: {} });
    }
  }

  return results;
}

// ---------------------------------------------------------------------------
// DDB write helpers
// ---------------------------------------------------------------------------

async function writeRagMetrics(
  runId: string,
  caseId: string,
  ragMetrics: RagMetrics,
  status: "passed" | "failed",
  toolAccuracyScore: number,
  goalSuccessScore: number,
): Promise<void> {
  const client = getDocClient();
  await client.send(
    new UpdateCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `CASE#${caseId}`,
      },
      UpdateExpression: "SET ragMetrics = :rm, #s = :st, caseType = :ct, toolAccuracyScore = :ta, goalSuccessScore = :gs",
      ExpressionAttributeNames: { "#s": "status" },
      ExpressionAttributeValues: {
        ":rm": ragMetrics,
        ":st": status,
        ":ct": "rag",
        ":ta": toolAccuracyScore,
        ":gs": goalSuccessScore,
      },
    }),
  );
}

async function writeErrorToCase(
  runId: string,
  caseId: string,
  code: EvaluationErrorCode,
  reason: string,
): Promise<void> {
  const client = getDocClient();
  await client.send(
    new UpdateCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `${PK_PATTERNS.RUN}${runId}`,
        SK: `CASE#${caseId}`,
      },
      UpdateExpression: "SET evaluationError = :ee, #s = :st, caseType = :ct",
      ExpressionAttributeNames: { "#s": "status" },
      ExpressionAttributeValues: {
        ":ee": { code, reason },
        ":st": "error",
        ":ct": "rag",
      },
    }),
  );
}

async function persistRagJobRecord(record: {
  runId: string;
  jobArn: string;
  judgeModelId: string;
  inputS3Uri: string;
  outputS3Uri?: string;
  submittedCaseCount: number;
  indexMap: Record<number, string>;
  status: string;
  startedAt: string;
  completedAt?: string;
}): Promise<void> {
  const client = getDocClient();
  await client.send(
    new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        PK: `${PK_PATTERNS.RUN}${record.runId}`,
        SK: "RAGJOB",
        ...record,
      },
    }),
  );
}

// ---------------------------------------------------------------------------
// Lambda handler
// ---------------------------------------------------------------------------

export async function handler(event: ReadRagResultsInput): Promise<ReadRagResultsOutput> {
  // Extract input from the SFN state. The relevant data is in
  // ragCheckResult.Payload (from CheckRagJobStatus) or ragJobState.Payload
  // (from SubmitRagJob if routed directly on error).
  const checkPayload = (event as any).ragCheckResult?.Payload ?? event;
  const jobPayload = (event as any).ragJobState?.Payload ?? {};

  const runId = event.runId ?? checkPayload.runId ?? jobPayload.runId ?? "";
  const jobArn = event.jobArn ?? checkPayload.jobArn ?? jobPayload.jobArn ?? "";
  const indexMap = event.indexMap ?? checkPayload.indexMap ?? jobPayload.indexMap ?? {};
  const startedAt = event.startedAt ?? checkPayload.startedAt ?? jobPayload.startedAt ?? "";
  const judgeModelId = event.judgeModelId ?? checkPayload.judgeModelId ?? jobPayload.judgeModelId ?? "";
  const inputS3Uri = event.inputS3Uri ?? checkPayload.inputS3Uri ?? jobPayload.inputS3Uri ?? "";
  const submittedCaseCount = event.submittedCaseCount ?? checkPayload.submittedCaseCount ?? jobPayload.submittedCaseCount ?? 0;
  const status = event.status ?? checkPayload.status ?? "Failed";
  const outputPath = event.outputPath ?? checkPayload.outputPath;
  const ragThresholds: RagThresholds = event.ragThresholds ?? checkPayload.ragThresholds ?? jobPayload.ragThresholds ?? DEFAULT_RAG_THRESHOLDS;
  const caseIds = Object.values(indexMap) as string[];

  // SKIPPED path — SubmitRagJob already handled (zero survivors or create failed)
  if (status === "SKIPPED") {
    return { runId, evaluatedCount: 0, errorCount: 0, status: "SKIPPED" };
  }

  // Error path: Failed, Stopped, Stopping, Timeout
  if (status !== "Completed") {
    const isTimeout = status === "Timeout";
    const errorCode: EvaluationErrorCode = isTimeout ? "RAG_JOB_TIMEOUT" : "RAG_JOB_FAILED";
    const reason = isTimeout
      ? "Bedrock evaluation job did not complete within 30 minutes"
      : `Bedrock evaluation job ended with status: ${status}`;

    for (const caseId of caseIds) {
      await writeErrorToCase(runId, caseId, errorCode, reason);
    }

    await persistRagJobRecord({
      runId,
      jobArn,
      judgeModelId,
      inputS3Uri,
      outputS3Uri: `s3://${RAG_JOB_BUCKET}/${runId}/output/`,
      submittedCaseCount,
      indexMap,
      status: isTimeout ? "TIMEOUT" : "FAILED",
      startedAt,
      completedAt: new Date().toISOString(),
    });

    return {
      runId,
      evaluatedCount: 0,
      errorCount: caseIds.length,
      status: isTimeout ? "TIMEOUT" : "FAILED",
    };
  }

  // Success path: Completed
  let evaluatedCount = 0;
  let errorCount = 0;
  let finalStatus: ReadRagResultsOutput["status"] = "COMPLETED";

  try {
    const perPromptResults = await readPerPromptResults(outputPath ?? "", runId);
    const resultsByIndex = new Map<number, PerPromptResult>();
    for (const r of perPromptResults) {
      resultsByIndex.set(r.lineIndex, r);
    }

    for (const [lineIdx, caseId] of Object.entries(indexMap)) {
      const idx = Number(lineIdx);
      const perPrompt = resultsByIndex.get(idx);

      if (!perPrompt) {
        console.error("[rag-read-results] No result for lineIndex", idx, "caseId", caseId);
        await writeErrorToCase(runId, caseId, "MISSING_EVALUATOR", "Bedrock did not return a result for this prompt");
        errorCount++;
        continue;
      }

      const metrics = perPrompt.metrics;

      if (
        metrics.faithfulness === undefined ||
        metrics.correctness === undefined ||
        metrics.completeness === undefined ||
        metrics.helpfulness === undefined ||
        isNaN(metrics.faithfulness) ||
        isNaN(metrics.correctness) ||
        isNaN(metrics.completeness) ||
        isNaN(metrics.helpfulness)
      ) {
        console.error("[rag-read-results] Malformed metrics for lineIndex", idx, "caseId", caseId);
        await writeErrorToCase(runId, caseId, "MALFORMED_RESULT", "Bedrock returned incomplete or non-numeric metric scores");
        errorCount++;
        continue;
      }

      const ragMetrics: RagMetrics = {
        faithfulness: metrics.faithfulness,
        correctness: metrics.correctness,
        completeness: metrics.completeness,
        helpfulness: metrics.helpfulness,
      };

      const caseStatus = computeRagCaseStatus(ragMetrics, ragThresholds);

      // Compute Tool Accuracy: did the agent invoke the Retrieve tool?
      // Check if retrievedChunks is non-empty on the persisted case result.
      let toolAccuracyScore = 0.0;
      try {
        const caseResult = await getDocClient().send(
          new GetCommand({
            TableName: TABLE_NAME,
            Key: { PK: `${PK_PATTERNS.RUN}${runId}`, SK: `CASE#${caseId}` },
            ProjectionExpression: "retrievedChunks",
          }),
        );
        const chunks = caseResult.Item?.retrievedChunks;
        toolAccuracyScore = Array.isArray(chunks) && chunks.length > 0 ? 1.0 : 0.0;
      } catch {
        // If read fails, leave at 0.0
      }

      // Goal Success: use Correctness score directly (closest analog to
      // "did the agent achieve the goal of answering correctly")
      const goalSuccessScore = metrics.correctness;

      await writeRagMetrics(runId, caseId, ragMetrics, caseStatus, toolAccuracyScore, goalSuccessScore);
      evaluatedCount++;
    }
  } catch (readErr) {
    console.error("[rag-read-results] Failed to read/process output:", readErr instanceof Error ? readErr.message : readErr);
    for (const caseId of caseIds) {
      try {
        await writeErrorToCase(runId, caseId, "MALFORMED_RESULT", "Failed to read or parse Bedrock evaluation output");
        errorCount++;
      } catch {
        // Swallow DDB write errors on the error path
      }
    }
    finalStatus = "FAILED";
  }

  // Persist final RAGJOB record
  await persistRagJobRecord({
    runId,
    jobArn,
    judgeModelId,
    inputS3Uri,
    outputS3Uri: `s3://${RAG_JOB_BUCKET}/${runId}/output/`,
    submittedCaseCount,
    indexMap,
    status: finalStatus,
    startedAt,
    completedAt: new Date().toISOString(),
  });

  return { runId, evaluatedCount, errorCount, status: finalStatus };
}
