/**
 * Unit tests for the recommendations API wrapper module.
 *
 * Mocks `apiClient` to verify correct URL construction and payload shape
 * for each function exported by `api/recommendations.ts`.
 *
 * **Validates: Requirements 1.2, 2.1, 4.1, 6.2**
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('../client', () => ({
  apiClient: {
    get: vi.fn(),
    post: vi.fn(),
  },
}));

import { apiClient } from '../client';
import {
  fetchRecommendations,
  applyRecommendations,
  createExperiment,
  getExperiment,
  applyVariant,
  listExperiments,
} from '../recommendations';

const mockGet = apiClient.get as ReturnType<typeof vi.fn>;
const mockPost = apiClient.post as ReturnType<typeof vi.fn>;

beforeEach(() => {
  mockGet.mockReset();
  mockPost.mockReset();
});

// ---------------------------------------------------------------------------
// fetchRecommendations
// ---------------------------------------------------------------------------

describe('fetchRecommendations', () => {
  it('calls apiClient.post with the correct URL and suiteId in body', async () => {
    const mockResponse = { recommendations: [], generatedAt: '2024-01-01T00:00:00Z', modelId: 'test' };
    mockPost.mockResolvedValue(mockResponse);

    const result = await fetchRecommendations('run-123', 'suite/with spaces');

    expect(mockPost).toHaveBeenCalledTimes(1);
    expect(mockPost).toHaveBeenCalledWith(
      '/runs/run-123/recommend-suite',
      { suiteId: 'suite/with spaces' },
    );
    expect(result).toEqual(mockResponse);
  });

  it('passes suiteId with special characters in the body', async () => {
    mockPost.mockResolvedValue({ recommendations: [], generatedAt: '', modelId: '' });

    await fetchRecommendations('run-1', 'suite&id=test#hash');

    expect(mockPost).toHaveBeenCalledWith(
      '/runs/run-1/recommend-suite',
      { suiteId: 'suite&id=test#hash' },
    );
  });
});

// ---------------------------------------------------------------------------
// applyRecommendations
// ---------------------------------------------------------------------------

describe('applyRecommendations', () => {
  it('calls apiClient.post with correct URL and payload (no force)', async () => {
    const mockResponse = { newVersionId: 'v2' };
    mockPost.mockResolvedValue(mockResponse);

    const result = await applyRecommendations('run-123', 'agent-1', [0, 2, 5]);

    expect(mockPost).toHaveBeenCalledTimes(1);
    expect(mockPost).toHaveBeenCalledWith(
      '/runs/run-123/apply-recommendations',
      { mode: 'direct', agentId: 'agent-1', recommendationIndices: [0, 2, 5] },
    );
    expect(result).toEqual(mockResponse);
  });

  it('includes force: true when force parameter is true', async () => {
    mockPost.mockResolvedValue({ newVersionId: 'v3' });

    await applyRecommendations('run-456', 'agent-2', [1, 3], true);

    expect(mockPost).toHaveBeenCalledWith(
      '/runs/run-456/apply-recommendations',
      { mode: 'direct', agentId: 'agent-2', recommendationIndices: [1, 3], force: true },
    );
  });

  it('does not include force key when force is false', async () => {
    mockPost.mockResolvedValue({ newVersionId: 'v4' });

    await applyRecommendations('run-789', 'agent-3', [0], false);

    const payload = mockPost.mock.calls[0][1];
    expect(payload).not.toHaveProperty('force');
  });

  it('does not include force key when force is undefined', async () => {
    mockPost.mockResolvedValue({ newVersionId: 'v5' });

    await applyRecommendations('run-100', 'agent-4', [2]);

    const payload = mockPost.mock.calls[0][1];
    expect(payload).not.toHaveProperty('force');
  });
});

// ---------------------------------------------------------------------------
// createExperiment
// ---------------------------------------------------------------------------

describe('createExperiment', () => {
  it('calls apiClient.post with correct URL and payload containing mode: multi_variant', async () => {
    const mockResponse = { experimentId: 'exp-001', status: 'generating_variants' };
    mockPost.mockResolvedValue(mockResponse);

    const result = await createExperiment('run-abc', 'agent-xyz');

    expect(mockPost).toHaveBeenCalledTimes(1);
    expect(mockPost).toHaveBeenCalledWith(
      '/runs/run-abc/experiments',
      { mode: 'multi_variant', agentId: 'agent-xyz' },
    );
    expect(result).toEqual(mockResponse);
  });
});

// ---------------------------------------------------------------------------
// getExperiment
// ---------------------------------------------------------------------------

describe('getExperiment', () => {
  it('calls apiClient.get with the correct URL construction', async () => {
    const mockRecord = { experimentId: 'exp-002', status: 'running' };
    mockGet.mockResolvedValue(mockRecord);

    const result = await getExperiment('run-def', 'exp-002');

    expect(mockGet).toHaveBeenCalledTimes(1);
    expect(mockGet).toHaveBeenCalledWith('/runs/run-def/experiments/exp-002');
    expect(result).toEqual(mockRecord);
  });
});

// ---------------------------------------------------------------------------
// applyVariant
// ---------------------------------------------------------------------------

describe('applyVariant', () => {
  it('calls apiClient.post with the correct URL and variant in payload', async () => {
    const mockResponse = { newVersionId: 'v10' };
    mockPost.mockResolvedValue(mockResponse);

    const result = await applyVariant('run-ghi', 'exp-003', 'B');

    expect(mockPost).toHaveBeenCalledTimes(1);
    expect(mockPost).toHaveBeenCalledWith(
      '/runs/run-ghi/experiments/exp-003/apply',
      { variant: 'B' },
    );
    expect(result).toEqual(mockResponse);
  });

  it('handles all variant letters (A, B, C)', async () => {
    mockPost.mockResolvedValue({ newVersionId: 'v11' });

    await applyVariant('run-1', 'exp-1', 'A');
    expect(mockPost).toHaveBeenLastCalledWith(
      '/runs/run-1/experiments/exp-1/apply',
      { variant: 'A' },
    );

    await applyVariant('run-1', 'exp-1', 'C');
    expect(mockPost).toHaveBeenLastCalledWith(
      '/runs/run-1/experiments/exp-1/apply',
      { variant: 'C' },
    );
  });
});

// ---------------------------------------------------------------------------
// listExperiments
// ---------------------------------------------------------------------------

describe('listExperiments', () => {
  it('calls apiClient.get with the correct URL construction', async () => {
    const mockResponse = { experiments: [] };
    mockGet.mockResolvedValue(mockResponse);

    const result = await listExperiments('run-jkl');

    expect(mockGet).toHaveBeenCalledTimes(1);
    expect(mockGet).toHaveBeenCalledWith('/runs/run-jkl/experiments');
    expect(result).toEqual(mockResponse);
  });
});
