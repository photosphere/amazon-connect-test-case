# Design Document: Connect Agent Test Platform

## Overview

The Connect Agent Test Platform is a serverless web application for automated testing of Amazon Connect AI Agents. It bridges Q in Connect's session-based API with Bedrock AgentCore evaluation capabilities, enabling users to create test suites, run multi-turn conversational tests against live ORCHESTRATION-type AI agents, and score results using AgentCore evaluators.

The platform is deployed as a CDK (TypeScript) application with a React + Cloudscape frontend served via CloudFront/S3, Cognito for authentication, API Gateway + Lambda for the backend, Step Functions for test orchestration, DynamoDB for storage, and Bedrock for customer simulation and LLM-based scoring.

### Design Rationale

The architecture follows a hybrid approach validated by the prototype: our own Conversation Driver handles the Q in Connect API quirks (aiAgentId override on SendMessage, filler response handling, tool extraction from conversationSessionData), while AgentCore Evaluations provides managed post-conversation scoring. This split leverages AgentCore's strengths (standardized evaluators) without requiring it to understand Q in Connect session semantics.

Key technical constraints proven by the prototype:
- `aiAgentId` must be on `SendMessage`, NOT `CreateSession`
- Filler responses ("...", "......", "…") must be detected and skipped
- Tool name lives in `conversationSessionData` under key `"Tool"`
- `CreateSession` requires a `name` parameter; `sessionId` is nested in response
- 9 concurrent sessions stay within the 10 TPS limit with exponential backoff
- Both `wisdom:` and `qconnect:` ARN prefixes are needed for IAM

## Architecture

```mermaid
graph TB
    subgraph Frontend["Frontend (React + Cloudscape)"]
        AB[Agent Browser]
        TSE[Test Suite Editor]
        RD[Run Dashboard]
        RV[Results Viewer]
        HC[Historical Comparison]
        FA[Failure Analysis]
    end

    subgraph Auth["Authentication"]
        CUP[Cognito User Pool]
        CIP[Cognito Identity Pool]
        RS[Resource Server]
        M2M[Machine Client]
    end

    subgraph API["API Layer"]
        APIGW[API Gateway]
    end

    subgraph Backend["Backend (Lambda)"]
        DiscL[Discovery Lambda]
        SuiteL[Suite CRUD Lambda]
        RunL[Run Trigger Lambda]
        ResultsL[Results Lambda]
        ScaffoldL[Scaffold Lambda]
        AnalysisL[Analysis Lambda]
    end

    subgraph Orchestration["Test Orchestration"]
        SF[Step Functions State Machine]
        CD[Conversation Driver Lambda]
        CS[Customer Simulator]
        EV[Evaluation Lambda]
    end

    subgraph Storage["Storage"]
        DDB[(DynamoDB)]
        S3B[S3 - Frontend]
        CF[CloudFront]
    end

    subgraph External["External Services"]
        QiC[Q in Connect APIs]
        BR[Bedrock Converse]
        AC[AgentCore Evaluations]
    end

    Frontend --> APIGW
    APIGW --> CUP
    APIGW --> Backend
    CF --> S3B
    Frontend -.-> CF

    DiscL --> QiC
    RunL --> SF
    SF --> CD
    CD --> QiC
    CD --> CS
    CS --> BR
    EV --> AC
    ScaffoldL --> BR
    AnalysisL --> BR

    Backend --> DDB
    SF --> DDB
```

### Request Flow

**Interactive (Browser) Flow:**
1. User authenticates via Cognito hosted UI → receives JWT tokens
2. Frontend calls API Gateway with Cognito authorizer validation
3. API Gateway routes to specific Lambda functions
4. For test execution: Lambda starts Step Functions execution
5. Step Functions runs test cases in parallel via Map state (concurrency=9)
6. Each Conversation Driver Lambda manages one test case session lifecycle
7. Post-conversation: Evaluation Lambda submits transcripts to AgentCore
8. Results written to DynamoDB, frontend polls for updates

**Machine-to-Machine (CI/CD) Flow:**
1. CI/CD pipeline calls Cognito token endpoint with client ID + secret (`grant_type=client_credentials`)
2. Cognito returns an access token with `test-platform/run` scope
3. Pipeline calls API Gateway with `Authorization: Bearer <token>`
4. API Gateway Cognito authorizer validates the token (same authorizer handles both user and machine tokens)
5. Lambda extracts tenant ID from token claims (client ID used as tenant for machine clients)
6. Same backend logic executes — trigger runs, poll results, retrieve transcripts

```typescript
// CI/CD usage example:
// 1. Get token
// POST https://<cognito-domain>/oauth2/token
// Content-Type: application/x-www-form-urlencoded
// Authorization: Basic base64(clientId:clientSecret)
// Body: grant_type=client_credentials&scope=test-platform/run

// 2. Trigger test run
// POST https://<api-gw>/runs
// Authorization: Bearer <access_token>
// Body: { "suiteId": "...", "concurrency": 9 }

// 3. Poll results
// GET https://<api-gw>/runs/<runId>
// Authorization: Bearer <access_token>
```

## Components and Interfaces

### Frontend Components

#### Agent Browser
- Calls `GET /agents` to list all agents (ORCHESTRATION type) on the configured assistant
- Displays agent name, ID, tool count, and model ID in a Cloudscape Table
- Agent detail panel shows tools (name, description, input schema) and system prompt (read-only)
- Error state with retry button on API failure

#### Test Suite Editor
- Form-based CRUD for test suites and test cases
- Cloudscape Form components with validation
- Test case editor includes: persona, style, customer knowledge (key-value editor), initial utterance, success criteria (ordered tool sequence builder)
- "Suggest Tools" button triggers scaffolding Lambda

#### Run Dashboard
- Start button triggers `POST /runs`
- Polls `GET /runs/{runId}` every 3 seconds for progress updates
- Displays progress bar, pass/fail/error counts, elapsed timer (MM:SS)
- Abort button calls `POST /runs/{runId}/abort`
- Streams completed test case results as they arrive

#### Results Viewer
- Sorted table: errors first, then failed, then passed
- Expandable rows showing full transcript with role labels, tool selections, timestamps
- Filter controls: status, tool invoked
- Scores displayed: goal success (0–1), helpfulness (0–1), tool accuracy (0–1)

#### Historical Comparison
- Run history list (descending by timestamp, paginated at 50/page)
- Side-by-side comparison view for two selected runs
- Status change indicators (passed→failed, failed→passed, etc.)
- Configuration diff view highlighting tool/prompt/model changes

#### Failure Analysis Panel
- Per-failed-test-case root cause explanation with reasoning trace evidence
- Recommendations as diff views (current text vs suggested replacement)
- Grouped recommendations when multiple failures share root cause

### Backend Lambda Functions

#### Discovery Lambda (`GET /agents`, `GET /agents/{agentId}`)

```typescript
interface ListAgentsResponse {
  agents: AgentSummary[];
}

interface AgentSummary {
  agentId: string;
  name: string;
  type: "ORCHESTRATION";
  toolCount: number;
  modelId: string;
}

interface AgentDetail {
  agentId: string;
  name: string;
  type: "ORCHESTRATION";
  systemPrompt: string;
  modelId: string;
  tools: ToolDefinition[];
}

interface ToolDefinition {
  toolName: string;
  toolType: string;
  description: string;
  instruction?: string;
  inputSchema: Record<string, unknown>;
}
```

**Implementation**: Calls `ListAIAgents` with the configured assistant ID, filters to agents with type=ORCHESTRATION (excluding SELF_SERVICE system agents), then maps to response shape. For detail view, calls `GetAIAgent` and extracts tool configurations and prompt text.

#### Suite CRUD Lambda (`/suites`, `/suites/{suiteId}`, `/suites/{suiteId}/cases`)

Standard CRUD operations against DynamoDB. Validates:
- Suite name: required, max 128 chars
- Description: optional, max 500 chars
- Agent ID: required, must be a valid discovered agent
- Test case fields per Requirement 5 acceptance criteria

#### Run Trigger Lambda (`POST /runs`)

Starts a Step Functions execution with input:
```typescript
interface RunInput {
  suiteId: string;
  tenantId: string;
  concurrency: number; // default 9
  agentSnapshot: AgentDetail; // captured at trigger time
}
```

Returns `runId` immediately (the Step Functions execution ARN serves as run ID).

#### Results Lambda (`GET /runs/{runId}`, `GET /runs/{runId}/cases/{caseId}`)

Reads from DynamoDB. Returns partial results while run is in progress (completed cases only). Includes progress metadata from Step Functions execution status.

#### Scaffold Lambda (`POST /suites/{suiteId}/cases/scaffold`)

```typescript
interface ScaffoldRequest {
  goalDescription: string;
  agentId: string;
}

interface ScaffoldResponse {
  suggestedTools: { toolName: string; position: number; required: boolean }[];
  customerKnowledgeTemplate: { key: string; label: string; toolGroup: string }[];
}
```

Uses Bedrock to analyze agent tools against the goal description, infers the tool chain, then analyzes input schemas to generate the knowledge template.

#### Analysis Lambda (`POST /runs/{runId}/analyze`)

Takes failed test cases, their transcripts, reasoning traces (from ListSpans), and agent configuration. Calls Bedrock to produce root cause explanations and actionable recommendations.

### Step Functions State Machine

```mermaid
stateDiagram-v2
    [*] --> PrepareRun
    PrepareRun --> ParallelTestCases

    state ParallelTestCases {
        [*] --> ConversationDriver
        ConversationDriver --> RecordTranscript
        RecordTranscript --> FetchReasoningTrace
        FetchReasoningTrace --> [*]
    }

    ParallelTestCases --> EvaluateResults
    EvaluateResults --> WriteResults
    WriteResults --> [*]
```

- **PrepareRun**: Writes initial run record to DDB, snapshots agent config
- **ParallelTestCases**: Map state with `maxConcurrency=9`, one iteration per test case
- **ConversationDriver**: Lambda that runs the full multi-turn conversation
- **RecordTranscript**: Writes transcript to DDB
- **FetchReasoningTrace**: Calls ListSpans API, stores reasoning data
- **EvaluateResults**: Submits all transcripts to AgentCore for scoring
- **WriteResults**: Writes final scores and run summary to DDB

### Conversation Driver Lambda

The core test execution component. Implements the proven prototype logic:

```typescript
async function executeTestCase(testCase: TestCase, agentId: string, assistantId: string): Promise<TestCaseResult> {
  const sessionId = await createSession(assistantId, `test-${randomHex(8)}`);
  let nextToken = await sendMessage(assistantId, sessionId, agentId, testCase.initialUtterance);

  const transcript: Turn[] = [];
  const toolsInvoked: string[] = [];

  for (let turn = 0; turn < maxTurns; turn++) {
    const { toolName, agentText, timedOut } = await pollForResponse(assistantId, sessionId, nextToken);

    if (timedOut) return markTimedOut(testCase, transcript, toolsInvoked);

    if (toolName) {
      toolsInvoked.push(toolName);
      transcript.push({ role: 'agent', text: agentText, tool: toolName, timestamp: now() });
      nextToken = await sendMessage(assistantId, sessionId, agentId, "continue");
    } else if (agentText) {
      transcript.push({ role: 'agent', text: agentText, timestamp: now() });
      const customerResponse = await simulateCustomer(agentText, testCase, transcript);
      transcript.push({ role: 'customer', text: customerResponse, timestamp: now() });
      nextToken = await sendMessage(assistantId, sessionId, agentId, customerResponse);
    } else {
      break;
    }
  }

  return { status: 'completed', transcript, toolsInvoked, sessionId };
}
```

**Critical implementation details**:
- Poll interval: 300ms
- Poll timeout: 60s per cycle
- Filler detection: text is "...", "......", or "…" AND nextMessageToken hasn't advanced
- Throttle retry: exponential backoff starting at 2s, cap 30s, max 3 retries
- Tool extraction: `conversationSessionData` array, find entry with `key === "Tool"`, read `value.stringValue`

### Customer Simulator

Reuses the proven role-flipping pattern from the prototype:

- Calls Bedrock Converse API (Claude Haiku) with max 150 tokens
- System prompt includes: goal, style description, customer knowledge as "personal details to reveal only when asked"
- Role flip: customer messages → assistant role, agent messages → user role
- Fallback on error: returns "Yes, please proceed" without failing the test

### Evaluation Integration

**AgentCore Evaluators used**:
- `Builtin.GoalSuccessRate` — did the customer's goal get achieved?
- `Builtin.Helpfulness` — was the agent helpful and professional?
- Custom `ToolSelectionAccuracy` — ordered subsequence matching of expected tools

**ToolSelectionAccuracy scoring logic**:
```
score = (matched_required_steps / total_required_steps)
```
Where "matched" means the tool appears in the invoked sequence in the correct relative order. Optional steps don't affect the denominator.

**Fallback**: If AgentCore is unavailable (timeout >60s or error), local scoring applies:
- Tool accuracy: 1.0 if all required tools are an ordered subsequence, 0.0 otherwise
- Goal success and helpfulness: left empty with a warning indicator

## Data Models

### DynamoDB Single-Table Design

| Entity | PK | SK | Attributes |
|--------|----|----|------------|
| TestSuite | `TENANT#{tenantId}` | `SUITE#{suiteId}` | name, description, agentId, assistantId, createdAt, updatedAt |
| TestCase | `SUITE#{suiteId}` | `CASE#{caseId}` | name, description, persona, style, customerKnowledge, initialUtterance, successCriteria |
| TestRun | `SUITE#{suiteId}` | `RUN#{timestamp}` | status, totalCases, passed, failed, errors, concurrency, startTime, endTime, sfnExecutionArn |
| TestResult | `RUN#{runId}` | `CASE#{caseId}` | status, toolsInvoked[], turnCount, latencyMs, goalSuccessScore, helpfulnessScore, toolAccuracyScore |
| Transcript | `RUN#{runId}#CASE#{caseId}` | `TURN#{turnNumber}` | role, text, toolSelected, timestamp, elapsedMs |
| ReasoningTrace | `RUN#{runId}#CASE#{caseId}` | `TRACE` | spans[], rawResponse |
| AgentSnapshot | `RUN#{runId}` | `SNAPSHOT` | tools[], systemPrompt, modelId, capturedAt |

### Key Data Types

```typescript
interface TestCase {
  suiteId: string;
  caseId: string;
  name: string;                     // max 100 chars
  description: string;              // max 2000 chars
  persona: string;
  style: "direct" | "indirect" | "colloquial" | "question" | "complaint";
  customerKnowledge: Record<string, string>;  // max 20 pairs
  initialUtterance: string;         // max 1000 chars
  successCriteria: ToolStep[];      // 1–30 steps
}

interface ToolStep {
  toolName: string;
  required: boolean;     // default true
  parameterChecks?: { paramName: string; expectedValue: string }[];  // max 10
}

interface TestCaseResult {
  runId: string;
  caseId: string;
  status: "passed" | "failed" | "error" | "timed_out";
  toolsInvoked: string[];
  turnCount: number;
  latencyMs: number;
  goalSuccessScore?: number;    // 0.0–1.0
  helpfulnessScore?: number;    // 0.0–1.0
  toolAccuracyScore?: number;   // 0.0–1.0
  errorMessage?: string;
}

interface TranscriptTurn {
  turnNumber: number;
  role: "customer" | "agent";
  text: string;
  toolSelected?: string;
  timestamp: string;    // ISO 8601
  elapsedMs: number;
}
```

### GSI Patterns

| GSI Name | PK | SK | Purpose |
|----------|----|----|---------|
| GSI1 | `TENANT#{tenantId}` | `updatedAt` | List suites for a tenant, sorted by last update |
| GSI2 | `AGENT#{agentId}` | `createdAt` | Find all suites targeting a specific agent |

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Entity Field Validation

*For any* input to the test suite or test case creation/edit forms, the validation logic SHALL accept inputs where all required fields are present and within their specified bounds (suite name ≤128 chars, description ≤500 chars, case name ≤100 chars, case description ≤2000 chars, initial utterance ≤1000 chars, customer knowledge ≤20 pairs with key ≤100 and value ≤500, success criteria 1–30 steps with ≤10 parameter checks per step), and SHALL reject inputs that violate any of these constraints.

**Validates: Requirements 4.1, 4.3, 4.5, 5.1, 5.2, 5.4**

### Property 2: Entity Persistence Round-Trip

*For any* valid test suite, test case, test result, or evaluation score object, persisting it to DynamoDB and then retrieving it by its composite key SHALL produce an object equal to the original (all fields preserved, no data loss or corruption during serialization/deserialization).

**Validates: Requirements 4.2, 5.5, 9.3, 10.8**

### Property 3: Cascade Delete Completeness

*For any* test suite containing N test cases, deleting the suite SHALL remove exactly N+1 DynamoDB records (the suite record plus all N case records), and subsequent queries for the suite or any of its cases SHALL return no results.

**Validates: Requirements 4.6**

### Property 4: Parameter Deduplication in Knowledge Template

*For any* ordered tool sequence where multiple tools share input parameters with the same name, the generated customer knowledge template SHALL contain exactly one entry per unique parameter name, and that entry SHALL be grouped under the first tool in the sequence that requires it.

**Validates: Requirements 6.3**

### Property 5: Filler Response Detection

*For any* GetNextMessage response containing text that is solely "...", "......", or "…", if the nextMessageToken has advanced from the previous poll, the conversation driver SHALL classify it as a filler response and continue polling rather than treating it as substantive agent output.

**Validates: Requirements 7.4**

### Property 6: Conversation Flow Control

*For any* multi-turn conversation state: (a) if the agent responds with a tool selection, the driver SHALL record the tool and continue the conversation (not terminate); (b) if the agent responds with non-filler text and no tool selection, the driver SHALL invoke the customer simulator and send the response back. The conversation terminates only when max turns is reached or the agent produces a final text response with no further tool selection after all tools in the journey are invoked.

**Validates: Requirements 7.5, 7.6**

### Property 7: Tool Extraction from conversationSessionData

*For any* GetNextMessage response containing a `conversationSessionData` array, if an entry exists with `key === "Tool"`, the extraction function SHALL return the `stringValue` of that entry's `value` object. If no such entry exists, it SHALL return null.

**Validates: Requirements 7.7**

### Property 8: Tool Sequence Ordering and Completeness

*For any* multi-turn conversation where the agent selects tools on turns t₁, t₂, ..., tₖ (where t₁ < t₂ < ... < tₖ), the recorded tool sequence SHALL contain exactly k elements in the order they were invoked, with no omissions or reorderings.

**Validates: Requirements 7.8**

### Property 9: Exponential Backoff Bounds

*For any* retry attempt number n (0-indexed), the computed backoff delay SHALL be a value in the range [0, min(2 × 2ⁿ, 30)] seconds. The maximum number of retries SHALL be 3, after which the error propagates.

**Validates: Requirements 7.9**

### Property 10: Error Isolation

*For any* test run containing N test cases, if case Cᵢ encounters a non-throttling API error (CreateSession or SendMessage failure), the driver SHALL mark Cᵢ as status "error" with a failure reason, and all other cases C₁...Cᵢ₋₁, Cᵢ₊₁...Cₙ SHALL proceed to execution unaffected.

**Validates: Requirements 7.12**

### Property 11: Customer Simulator Role Flipping

*For any* conversation history of N turns where each turn has a role (customer or agent) and text content, the role flipping transformation for the Bedrock Converse call SHALL produce N messages where every "customer" turn becomes `role: "assistant"` and every "agent" turn becomes `role: "user"`, with text content preserved unchanged.

**Validates: Requirements 8.2**

### Property 12: Customer Simulator System Prompt Construction

*For any* test case with a goal description, communication style, and set of customer knowledge key-value pairs, the constructed system prompt SHALL contain (a) the goal text, (b) a style-appropriate instruction derived from the communication style, and (c) all customer knowledge values formatted as personal details the model may reveal only when asked.

**Validates: Requirements 8.6, 5.6**

### Property 13: Tool Selection Accuracy — Ordered Subsequence

*For any* expected tool sequence (where each step is marked required or optional) and any actual tool invocation list, the tool accuracy score SHALL be computed as: count of matched required steps appearing in correct relative order as a subsequence of the actual list, divided by total required steps. Optional steps do not affect the score negatively if absent, but are counted positively if present in any position.

**Validates: Requirements 9.2, 9.5, 9.6**

### Property 14: Accuracy Computation

*For any* set of test results with statuses (passed, failed, error), the overall accuracy percentage SHALL equal (passed_count / total_count) × 100, rounded to one decimal place.

**Validates: Requirements 10.1**

### Property 15: Results Sorting

*For any* set of test results, the sorted output SHALL place all "error" status results first, then all "failed" results, then all "passed" results, with results within each status group sorted alphabetically by test case name (case-insensitive).

**Validates: Requirements 10.3, 13.3**

### Property 16: Results Filtering

*For any* set of test results and a filter predicate (by status and/or by tool invoked), the filtered output SHALL contain exactly those results that match all applied filter criteria, and no results that fail to match.

**Validates: Requirements 10.5**

### Property 17: Progress Display Computation

*For any* in-progress run state with completed count, total count, pass/fail/error tallies, and elapsed seconds, the formatted progress display SHALL show elapsed time in MM:SS format (zero-padded minutes and seconds) and integer counts that sum correctly (pass + fail + error = completed).

**Validates: Requirements 11.1, 11.5**

### Property 18: Failure Grouping by Root Cause

*For any* set of failed test cases with assigned root cause categories, if 2 or more cases share the same root cause category string, they SHALL be consolidated into a single group with one set of recommendations. Cases with unique categories SHALL remain as individual entries.

**Validates: Requirements 12.6**

### Property 19: Run Comparison — Status Change Detection

*For any* two test run result sets R₁ and R₂ for the same suite, the comparison function SHALL correctly identify: (a) cases present in both with a status change (e.g., passed→failed), (b) cases present in R₂ but not R₁ as "added", (c) cases present in R₁ but not R₂ as "removed", and (d) cases with unchanged status.

**Validates: Requirements 13.4**

### Property 20: Agent Config Snapshot Fidelity

*For any* AI Agent configuration (tools, system prompt, model ID) captured at test run time, the stored snapshot SHALL be byte-for-byte equivalent to the configuration retrieved via GetAIAgent at that moment, ensuring reproducibility of results.

**Validates: Requirements 13.5**

### Property 21: Config Diff Computation

*For any* two agent configuration snapshots, the diff function SHALL identify: (a) tools added in the second snapshot, (b) tools removed from the first snapshot, (c) tools with modified descriptions or instructions, and (d) changes to the system prompt or model ID.

**Validates: Requirements 13.6**

## Machine-to-Machine Authentication (CI/CD)

### Architecture

The platform supports both interactive (browser) and programmatic (CI/CD) access using the same Cognito User Pool and API Gateway authorizer:

```
┌──────────────┐     client_credentials      ┌──────────────────┐
│  CI/CD Tool  │ ──────────────────────────── │ Cognito Token    │
│  (CodePipe,  │     POST /oauth2/token       │ Endpoint         │
│   GitHub     │ ◄─────────────────────────── │                  │
│   Actions)   │     access_token             └──────────────────┘
└──────┬───────┘
       │ Authorization: Bearer <token>
       ▼
┌──────────────────┐      validates token      ┌──────────────────┐
│  API Gateway     │ ─────────────────────────►│ Cognito          │
│  (same endpoint) │                           │ Authorizer       │
└──────┬───────────┘                           └──────────────────┘
       │
       ▼
┌──────────────────┐
│  Lambda Handlers │ (same backend, tenant derived from client_id)
└──────────────────┘
```

### Cognito Configuration

```typescript
// Resource Server — defines custom scopes for M2M access
const resourceServer = userPool.addResourceServer('TestPlatformResourceServer', {
  identifier: 'test-platform',
  scopes: [
    { scopeName: 'run', scopeDescription: 'Execute test runs and retrieve results' },
  ],
});

// Machine App Client — client_credentials grant only
const machineClient = userPool.addClient('MachineClient', {
  generateSecret: true,
  oAuth: {
    flows: { clientCredentials: true },
    scopes: [
      OAuthScope.custom('test-platform/run'),
    ],
  },
});
```

### Tenant Derivation for Machine Clients

Machine clients don't have a `sub` (user identity) claim. The Lambda handlers derive the tenant ID from the access token:

```typescript
function extractTenantId(event: APIGatewayProxyEvent): string {
  const claims = event.requestContext.authorizer?.claims;

  // Interactive user: use Cognito sub as tenant
  if (claims?.sub) {
    return claims.sub;
  }

  // Machine client: use client_id as tenant
  if (claims?.client_id) {
    return `machine:${claims.client_id}`;
  }

  throw new Error('Unable to determine tenant identity from token');
}
```

### CDK Stack Outputs

```typescript
new CfnOutput(this, 'MachineClientId', { value: machineClient.userPoolClientId });
new CfnOutput(this, 'TokenEndpoint', { value: `https://${domain.domainName}.auth.${region}.amazoncognito.com/oauth2/token` });
new CfnOutput(this, 'MachineClientSecretArn', { value: secret.secretArn });
```

### CI/CD Integration Example

```bash
# In a CodePipeline/GitHub Actions step:
TOKEN=$(curl -s -X POST "https://${COGNITO_DOMAIN}/oauth2/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -u "${CLIENT_ID}:${CLIENT_SECRET}" \
  -d "grant_type=client_credentials&scope=test-platform/run" \
  | jq -r '.access_token')

# Trigger a test run
RUN_ID=$(curl -s -X POST "${API_ENDPOINT}/runs" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"suiteId": "my-regression-suite"}' \
  | jq -r '.runId')

# Poll until complete
while true; do
  STATUS=$(curl -s "${API_ENDPOINT}/runs/${RUN_ID}" \
    -H "Authorization: Bearer ${TOKEN}" | jq -r '.status')
  [ "$STATUS" != "running" ] && break
  sleep 5
done
```

## Error Handling

### API Error Categories

| Error Type | Source | Handling Strategy |
|-----------|--------|-------------------|
| **ThrottlingException / 429** | Q in Connect APIs | Exponential backoff with jitter (base 2s, cap 30s, max 3 retries) |
| **Non-throttling API error** | CreateSession, SendMessage | Mark individual test case as "error", continue other cases |
| **Poll timeout (60s)** | GetNextMessage loop | Mark test case as "timeout", proceed to next |
| **Bedrock Converse failure** | Customer Simulator | Return fixed affirmative response, log error, continue |
| **AgentCore timeout/error** | Evaluator scoring | Fall back to local subsequence scoring, display warning |
| **ListSpans failure** | Reasoning trace retrieval | Proceed with analysis using transcript only, note trace unavailable |
| **DynamoDB write failure** | Any persistence operation | Retry with exponential backoff (3 attempts), then propagate error to caller |
| **Step Functions timeout** | State machine execution | Mark run as FAILED, store partial results for completed cases |

### Error Propagation Rules

1. **Test case isolation**: An error in one test case NEVER aborts other cases in the same run. Each case executes independently in the Step Functions Map state.

2. **Graceful degradation**: Failures in optional components (AgentCore scoring, ListSpans, failure analysis) degrade the output quality but do not fail the overall operation.

3. **User-facing errors**: All errors surfaced to the frontend include a human-readable message, the error category, and a suggested action (retry, check configuration, contact support).

4. **Run state machine**:
   ```
   RUNNING → COMPLETED (all cases finished, scores stored)
   RUNNING → FAILED (Step Functions execution error)
   RUNNING → ABORTED (user-initiated StopExecution)
   ```

### Retry Strategy

```typescript
const RETRY_CONFIG = {
  throttle: {
    baseDelay: 2000,    // ms
    maxDelay: 30000,    // ms
    maxRetries: 3,
    jitter: true,       // random [0, computedDelay]
  },
  dynamodb: {
    baseDelay: 100,
    maxDelay: 1000,
    maxRetries: 3,
    jitter: false,
  },
  bedrock: {
    baseDelay: 1000,
    maxDelay: 10000,
    maxRetries: 2,
    jitter: true,
  },
};
```

### Frontend Error Handling

| Scenario | User Experience |
|----------|---------------|
| API 401 | Redirect to Cognito login, preserve current URL |
| API 5xx | Display error flash with retry button |
| Network timeout | Display "Connection lost" banner with auto-retry countdown |
| Validation error | Inline field errors on forms, prevent submission |
| Run abort | Confirm dialog → display partial results with "aborted" status |
| Stale data (optimistic update conflict) | Display "Data changed" notification, offer to reload |

## Testing Strategy

### Unit Tests (Example-Based)

Unit tests cover specific scenarios, edge cases, and integration points:

- **Authentication flows**: Token validation, refresh, redirect preservation
- **API route handlers**: Request/response mapping, error responses
- **UI components**: Rendering with specific data, empty states, loading states
- **CDK constructs**: Snapshot tests for infrastructure (resource presence, IAM policies)
- **Error scenarios**: Bedrock failures, ListSpans unavailable, AgentCore timeouts

### Property-Based Tests (fast-check)

Property-based tests verify universal properties across randomized inputs. The platform uses **fast-check** (TypeScript) for property-based testing.

**Configuration:**
- Minimum 100 iterations per property test
- Each test references its design property number
- Tag format: `Feature: connect-agent-test-platform, Property {N}: {title}`
- Runner: Vitest with fast-check integration

**Properties to implement:**

| Property | Module Under Test | Generator Strategy |
|----------|------------------|-------------------|
| 1: Entity Field Validation | Validation module | Random strings of varying lengths, random counts |
| 2: Persistence Round-Trip | DynamoDB service layer | Random entity objects with all field types |
| 3: Cascade Delete | DynamoDB service layer | Suites with 0–50 random cases |
| 4: Parameter Deduplication | Scaffold service | Random tool schemas with overlapping params |
| 5: Filler Detection | Conversation driver | Random responses with filler/non-filler text + token states |
| 6: Conversation Flow | Conversation driver | Random sequences of (tool, text, filler) responses |
| 7: Tool Extraction | Conversation driver | Random conversationSessionData arrays |
| 8: Tool Sequence | Conversation driver | Multi-turn conversations with 0–20 tool selections |
| 9: Backoff Bounds | Retry utility | Attempt numbers 0–10 |
| 10: Error Isolation | Step Functions mock | N test cases with random error injection |
| 11: Role Flipping | Customer simulator | Random conversation histories 1–30 turns |
| 12: System Prompt | Customer simulator | Random test cases with varying persona/knowledge |
| 13: Tool Accuracy | Evaluator | Random expected (required/optional) + actual tool sequences |
| 14: Accuracy Computation | Results service | Random result sets 1–200 items |
| 15: Results Sorting | Results service | Random result sets with mixed statuses |
| 16: Results Filtering | Results service | Random result sets + random filter combinations |
| 17: Progress Display | Run progress | Random progress states (counts, seconds) |
| 18: Failure Grouping | Analysis service | Random failure sets with 1–10 root cause categories |
| 19: Run Comparison | Comparison service | Random pairs of result sets |
| 20: Config Snapshot | Snapshot service | Random agent configs |
| 21: Config Diff | Diff utility | Random pairs of agent configs |

### Integration Tests

Integration tests verify end-to-end flows against real (or locally-mocked) services:

- **Q in Connect session lifecycle**: CreateSession → SendMessage → GetNextMessage with live API
- **Step Functions execution**: Full state machine run with mock conversation responses
- **AgentCore scoring**: Submit transcript, verify score retrieval
- **DynamoDB access patterns**: All query patterns with real table
- **CDK deployment**: Full `cdk synth` produces valid CloudFormation template

### CDK Infrastructure Tests

- Snapshot tests for CloudFormation output
- Assertion tests for IAM policy scoping (both `wisdom:` and `qconnect:` prefixes)
- Assertion tests for Lambda environment variables
- Assertion tests for DynamoDB table configuration (TTL enabled for 90-day retention)
- Assertion tests for API Gateway Cognito authorizer
- Assertion tests for per-Lambda IAM role isolation

### Test Organization

```
tests/
├── unit/
│   ├── properties/              # Property-based tests (fast-check)
│   │   ├── validation.test.ts
│   │   ├── persistence.test.ts
│   │   ├── cascade-delete.test.ts
│   │   ├── parameter-dedup.test.ts
│   │   ├── filler-detection.test.ts
│   │   ├── conversation-flow.test.ts
│   │   ├── tool-extraction.test.ts
│   │   ├── sequence-tracking.test.ts
│   │   ├── backoff.test.ts
│   │   ├── error-isolation.test.ts
│   │   ├── role-flipping.test.ts
│   │   ├── prompt-construction.test.ts
│   │   ├── tool-accuracy.test.ts
│   │   ├── accuracy-calculation.test.ts
│   │   ├── results-sorting.test.ts
│   │   ├── results-filtering.test.ts
│   │   ├── progress-display.test.ts
│   │   ├── failure-grouping.test.ts
│   │   ├── run-comparison.test.ts
│   │   ├── config-snapshot.test.ts
│   │   └── config-diff.test.ts
│   └── examples/                # Example-based unit tests
│       ├── auth-redirect.test.ts
│       ├── agent-browser.test.ts
│       ├── suite-editor.test.ts
│       ├── run-dashboard.test.ts
│       └── results-viewer.test.ts
├── integration/
│   ├── connect-apis.test.ts
│   ├── dynamodb.test.ts
│   ├── step-functions.test.ts
│   └── bedrock.test.ts
└── infrastructure/
    ├── stack.test.ts            # CDK snapshot + assertion tests
    └── iam-policies.test.ts
```

### Testing Pyramid

```
        ╱╲
       ╱  ╲       E2E (1-2 full run scenarios against live Connect instance)
      ╱────╲
     ╱      ╲     Integration (API routes, DDB patterns, Step Functions)
    ╱────────╲
   ╱          ╲   Property (21 properties × 100+ iterations each)
  ╱────────────╲
 ╱              ╲  Unit (specific examples, edge cases, error paths)
╱────────────────╲
```

### Test Environment

- **Local**: DynamoDB Local for persistence tests, mocked AWS SDK for API tests
- **CI**: Full CDK synth validation, property tests, unit tests
- **Integration**: Deployed test stack with real Q in Connect instance (scheduled, not per-commit)
