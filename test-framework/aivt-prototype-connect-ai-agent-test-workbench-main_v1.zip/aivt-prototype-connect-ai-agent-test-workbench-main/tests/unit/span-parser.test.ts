/**
 * Unit tests for the span-parser module.
 *
 * Covers:
 * - parseSpansToTrace: ordered steps, authoritative tool sequence, agent identity
 * - isToolResultSuccess: success/error classification
 * - chronological ordering by startTimestamp
 * - tool argument/result extraction
 */

import { describe, it, expect } from "vitest";
import {
  parseSpansToTrace,
  isToolResultSuccess,
  augmentTraceWithControlTools,
  type RawSpan,
} from "../../src/backend/orchestration/span-parser";
import type { ExecutionTrace } from "../../src/shared/types";

describe("isToolResultSuccess", () => {
  it("treats explicit error status as failure", () => {
    expect(isToolResultSuccess({ status: "error", message: "boom" })).toBe(false);
  });

  it("treats success status as success", () => {
    expect(isToolResultSuccess({ status: "success" })).toBe(true);
  });

  it("detects error status inside a string payload", () => {
    expect(isToolResultSuccess('{"status":"error","message":"ContactARN not found"}')).toBe(false);
  });

  it("defaults to success for null/undefined", () => {
    expect(isToolResultSuccess(null)).toBe(true);
    expect(isToolResultSuccess(undefined)).toBe(true);
  });
});

describe("parseSpansToTrace", () => {
  const spans: RawSpan[] = [
    {
      spanName: "invoke_agent",
      startTimestamp: "2024-01-01T00:00:00.000Z",
      attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
    },
    {
      spanName: "inference",
      startTimestamp: "2024-01-01T00:00:01.000Z",
      attributes: {
        aiAgentName: "AnyBank",
        aiAgentType: "ORCHESTRATION",
        outputMessages: [{ values: [{ text: { value: "Let me verify your identity." } }] }],
      },
    },
    {
      spanName: "execute_tool",
      startTimestamp: "2024-01-01T00:00:02.000Z",
      attributes: {
        aiAgentName: "AnyBank",
        aiAgentType: "ORCHESTRATION",
        inputMessages: [
          {
            values: [
              {
                toolUse: {
                  name: "verifyIdentity",
                  arguments: '{"ani":"+14074629069","ssn_last_four":"1234"}',
                },
              },
            ],
          },
        ],
        outputMessages: [
          {
            values: [
              { toolResult: { values: [{ text: { value: '{"status":"success"}' } }] } },
            ],
          },
        ],
      },
    },
    {
      spanName: "execute_tool",
      startTimestamp: "2024-01-01T00:00:03.000Z",
      attributes: {
        inputMessages: [{ values: [{ toolUse: { name: "getLoanDetails", arguments: "{}" } }] }],
        outputMessages: [
          {
            values: [
              {
                toolResult: {
                  values: [{ text: { value: '{"status":"error","message":"no auth"}' } }],
                },
              },
            ],
          },
        ],
      },
    },
  ];

  it("derives the authoritative tool sequence in execution order", () => {
    const trace = parseSpansToTrace("session-1", spans);
    expect(trace.toolSequence).toEqual(["verifyIdentity", "getLoanDetails"]);
  });

  it("captures agent identity from spans", () => {
    const trace = parseSpansToTrace("session-1", spans);
    expect(trace.aiAgentName).toBe("AnyBank");
    expect(trace.aiAgentType).toBe("ORCHESTRATION");
  });

  it("parses tool arguments and results, classifying success/error", () => {
    const trace = parseSpansToTrace("session-1", spans);
    const toolSteps = trace.steps.filter((s) => s.type === "tool");
    expect(toolSteps).toHaveLength(2);

    const verify = toolSteps[0].tool!;
    expect(verify.toolName).toBe("verifyIdentity");
    expect(verify.arguments).toEqual({ ani: "+14074629069", ssn_last_four: "1234" });
    expect(verify.success).toBe(true);

    const loan = toolSteps[1].tool!;
    expect(loan.toolName).toBe("getLoanDetails");
    expect(loan.success).toBe(false);
  });

  it("captures inference reasoning text", () => {
    const trace = parseSpansToTrace("session-1", spans);
    const inference = trace.steps.find((s) => s.type === "inference");
    expect(inference?.text).toContain("verify your identity");
  });

  it("sorts steps chronologically even when input is out of order", () => {
    const shuffled = [spans[3], spans[1], spans[0], spans[2]];
    const trace = parseSpansToTrace("session-1", shuffled);
    expect(trace.toolSequence).toEqual(["verifyIdentity", "getLoanDetails"]);
    // indexes are reassigned in chronological order
    expect(trace.steps.map((s) => s.index)).toEqual([0, 1, 2, 3]);
  });

  it("returns an empty trace for no spans", () => {
    const trace = parseSpansToTrace("session-1", []);
    expect(trace.steps).toEqual([]);
    expect(trace.toolSequence).toEqual([]);
  });
});

describe("parseSpansToTrace — inference outputMessages.toolUse extraction", () => {
  // Q in Connect emits RETURN_TO_CONTROL tool calls (Escalate, Complete,
  // custom control tools) as `toolUse` entries on the `inference` span's
  // `outputMessages` rather than as separate `execute_tool` spans. The
  // parser now extracts each `toolUse` entry and emits an additional
  // `type: "tool"` step with `spanName: "inference_tool_use"`, preserving
  // the agent's actual arguments.
  const ESCALATE_ARGS_JSON =
    '{"escalationReason":"Customer requested human","customerIntent":"speak with agent","sentiment":"Neutral","escalationSummary":"summary","customerFirstName":"Unknown","ProfileId":"Unknown"}';

  it("extracts a single toolUse alongside the inference text", () => {
    const trace = parseSpansToTrace("session-inference-toolUse-1", [
      {
        spanName: "inference",
        startTimestamp: "2024-06-02T18:30:01.000Z",
        endTimestamp: "2024-06-02T18:30:01.500Z",
        attributes: {
          aiAgentName: "AnyBank",
          aiAgentType: "ORCHESTRATION",
          outputMessages: [
            {
              values: [
                {
                  text: {
                    value:
                      "<message>I'll get you to a specialist.</message>",
                  },
                },
                {
                  toolUse: {
                    name: "Escalate",
                    arguments: ESCALATE_ARGS_JSON,
                  },
                },
              ],
            },
          ],
        },
      },
    ]);

    const inference = trace.steps.find((s) => s.type === "inference");
    expect(inference).toBeDefined();
    expect(inference?.text).toContain("I'll get you to a specialist");

    const toolSteps = trace.steps.filter((s) => s.type === "tool");
    expect(toolSteps).toHaveLength(1);
    expect(toolSteps[0].spanName).toBe("inference_tool_use");
    expect(toolSteps[0].tool?.toolName).toBe("Escalate");
    // Arguments JSON is best-effort parsed.
    expect(toolSteps[0].tool?.arguments).toEqual({
      escalationReason: "Customer requested human",
      customerIntent: "speak with agent",
      sentiment: "Neutral",
      escalationSummary: "summary",
      customerFirstName: "Unknown",
      ProfileId: "Unknown",
    });
    // RETURN_TO_CONTROL has no observable result; the step is marked successful.
    expect(toolSteps[0].tool?.result).toBeUndefined();
    expect(toolSteps[0].tool?.success).toBe(true);
    expect(trace.toolSequence).toEqual(["Escalate"]);

    // Inference step comes first; tool step gets the inference's
    // endTimestamp so it sorts strictly after.
    expect(inference?.timestamp).toBe("2024-06-02T18:30:01.000Z");
    expect(toolSteps[0].timestamp).toBe("2024-06-02T18:30:01.500Z");
    // Indices are sequential.
    expect(inference?.index).toBe(0);
    expect(toolSteps[0].index).toBe(1);
  });

  it("extracts multiple toolUse entries on a single inference span in order", () => {
    const trace = parseSpansToTrace("session-inference-toolUse-2", [
      {
        spanName: "inference",
        startTimestamp: "2024-06-02T18:30:01.000Z",
        attributes: {
          outputMessages: [
            {
              values: [
                { text: { value: "Calling two tools." } },
                {
                  toolUse: {
                    name: "ToolA",
                    arguments: '{"x":1}',
                  },
                },
                {
                  toolUse: {
                    name: "ToolB",
                    arguments: '{"y":2}',
                  },
                },
              ],
            },
          ],
        },
      },
    ]);

    const toolSteps = trace.steps.filter((s) => s.type === "tool");
    expect(toolSteps).toHaveLength(2);
    expect(toolSteps[0].tool?.toolName).toBe("ToolA");
    expect(toolSteps[0].tool?.arguments).toEqual({ x: 1 });
    expect(toolSteps[1].tool?.toolName).toBe("ToolB");
    expect(toolSteps[1].tool?.arguments).toEqual({ y: 2 });
    expect(trace.toolSequence).toEqual(["ToolA", "ToolB"]);
    // Each tool step gets its own sequential index after the inference.
    expect(trace.steps.map((s) => s.index)).toEqual([0, 1, 2]);
  });

  it("preserves text-only inference (no toolUse) as a single inference step", () => {
    const trace = parseSpansToTrace("session-inference-toolUse-3", [
      {
        spanName: "inference",
        startTimestamp: "2024-06-02T18:30:01.000Z",
        attributes: {
          outputMessages: [
            {
              values: [{ text: { value: "Just a text response." } }],
            },
          ],
        },
      },
    ]);

    expect(trace.steps).toHaveLength(1);
    expect(trace.steps[0].type).toBe("inference");
    expect(trace.steps[0].text).toBe("Just a text response.");
    expect(trace.toolSequence).toEqual([]);
  });

  it("does not double-count when an `escalate_agent` marker follows the inference toolUse", () => {
    const trace = parseSpansToTrace("session-inference-toolUse-4", [
      {
        spanName: "invoke_agent",
        startTimestamp: "2024-06-02T18:30:00.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
      {
        spanName: "inference",
        startTimestamp: "2024-06-02T18:30:01.000Z",
        endTimestamp: "2024-06-02T18:30:01.500Z",
        attributes: {
          outputMessages: [
            {
              values: [
                { text: { value: "Escalating now." } },
                {
                  toolUse: {
                    name: "Escalate",
                    arguments: '{"escalationReason":"need human"}',
                  },
                },
              ],
            },
          ],
        },
      },
      // The marker span Q in Connect emits after the agent hands off
      // control. It carries no toolUse attributes; the parser maps it
      // to type "other" and does NOT add it to toolSequence.
      {
        spanName: "escalate_agent",
        startTimestamp: "2024-06-02T18:30:02.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
    ]);

    // toolSequence reflects exactly one Escalate (from inference toolUse),
    // not two — the escalate_agent marker is preserved as type "other".
    expect(trace.toolSequence).toEqual(["Escalate"]);
    const escalateAgent = trace.steps.find(
      (s) => s.spanName === "escalate_agent",
    );
    expect(escalateAgent?.type).toBe("other");

    const toolSteps = trace.steps.filter((s) => s.type === "tool");
    expect(toolSteps).toHaveLength(1);
    expect(toolSteps[0].spanName).toBe("inference_tool_use");
    expect(toolSteps[0].tool?.toolName).toBe("Escalate");
  });

  // Regression: the helper used to emit `inference_tool_use` for
  // EVERY toolUse on an inference span, including MCP tools that
  // also surface on a separate execute_tool span. That double-counted
  // every MCP call (once from inference, once from execute_tool).
  // See run 88110f95a7adc0bcea8c51b8 / case 1e986d14baa9f7d1e94c803e.
  it("does NOT double-count an MCP tool that surfaces on both inference.outputMessages and a separate execute_tool span", () => {
    const trace = parseSpansToTrace("session-dedup-mcp-1", [
      {
        spanName: "inference",
        startTimestamp: "2026-06-11T03:24:36.000Z",
        endTimestamp: "2026-06-11T03:24:36.328Z",
        attributes: {
          aiAgentName: "AnyBank",
          aiAgentType: "ORCHESTRATION",
          outputMessages: [
            {
              values: [
                { text: { value: "Verifying identity now." } },
                {
                  toolUse: {
                    name: "verifyIdentity",
                    arguments:
                      '{"ani":"+14074629069","ssn_last_four":"1234"}',
                  },
                },
              ],
            },
          ],
        },
      },
      {
        spanName: "execute_tool",
        startTimestamp: "2026-06-11T03:24:36.328Z",
        attributes: {
          inputMessages: [
            {
              values: [
                {
                  toolUse: {
                    name: "verifyIdentity",
                    arguments:
                      '{"ani":"+14074629069","ssn_last_four":"1234"}',
                  },
                },
              ],
            },
          ],
          outputMessages: [
            {
              values: [
                {
                  toolResult: {
                    values: [
                      { text: { value: '{"status":"success"}' } },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    ]);

    expect(trace.toolSequence).toEqual(["verifyIdentity"]);
    const toolSteps = trace.steps.filter((s) => s.type === "tool");
    expect(toolSteps).toHaveLength(1);
    // The surviving step is the execute_tool entry (authoritative; has
    // both arguments AND result), not the inference echo.
    expect(toolSteps[0].spanName).toBe("execute_tool");
    expect(toolSteps[0].tool?.toolName).toBe("verifyIdentity");
    expect(toolSteps[0].tool?.result).toEqual({ status: "success" });
  });

  it("counts the same MCP tool called twice in a session as TWO entries — one per execute_tool span", () => {
    // Mirrors a real session shape: agent calls verifyIdentity twice
    // (e.g., wrong SSN first, then right SSN). Each call is observable
    // on its own inference + execute_tool pair. The trace should
    // record exactly two verifyIdentity entries — one per
    // execute_tool. Inference echoes are skipped.
    const trace = parseSpansToTrace("session-dedup-mcp-2", [
      {
        spanName: "inference",
        startTimestamp: "2026-06-11T03:24:36.000Z",
        endTimestamp: "2026-06-11T03:24:36.328Z",
        attributes: {
          outputMessages: [
            {
              values: [
                {
                  toolUse: {
                    name: "verifyIdentity",
                    arguments: '{"ssn_last_four":"0000"}',
                  },
                },
              ],
            },
          ],
        },
      },
      {
        spanName: "execute_tool",
        startTimestamp: "2026-06-11T03:24:36.500Z",
        attributes: {
          inputMessages: [
            {
              values: [
                {
                  toolUse: {
                    name: "verifyIdentity",
                    arguments: '{"ssn_last_four":"0000"}',
                  },
                },
              ],
            },
          ],
          outputMessages: [
            {
              values: [
                {
                  toolResult: {
                    values: [
                      {
                        text: {
                          value:
                            '{"status":"error","message":"identity not verified"}',
                        },
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
      {
        spanName: "inference",
        startTimestamp: "2026-06-11T03:24:37.000Z",
        endTimestamp: "2026-06-11T03:24:37.328Z",
        attributes: {
          outputMessages: [
            {
              values: [
                {
                  toolUse: {
                    name: "verifyIdentity",
                    arguments: '{"ssn_last_four":"1234"}',
                  },
                },
              ],
            },
          ],
        },
      },
      {
        spanName: "execute_tool",
        startTimestamp: "2026-06-11T03:24:37.500Z",
        attributes: {
          inputMessages: [
            {
              values: [
                {
                  toolUse: {
                    name: "verifyIdentity",
                    arguments: '{"ssn_last_four":"1234"}',
                  },
                },
              ],
            },
          ],
          outputMessages: [
            {
              values: [
                {
                  toolResult: {
                    values: [{ text: { value: '{"status":"success"}' } }],
                  },
                },
              ],
            },
          ],
        },
      },
    ]);

    expect(trace.toolSequence).toEqual(["verifyIdentity", "verifyIdentity"]);
    const toolSteps = trace.steps.filter((s) => s.type === "tool");
    expect(toolSteps).toHaveLength(2);
    // Both entries are from execute_tool spans (the inference-side
    // echoes were filtered out).
    expect(toolSteps.every((s) => s.spanName === "execute_tool")).toBe(true);
    // Per-call args are preserved on each execute_tool entry.
    expect(toolSteps[0].tool?.arguments).toEqual({ ssn_last_four: "0000" });
    expect(toolSteps[0].tool?.success).toBe(false);
    expect(toolSteps[1].tool?.arguments).toEqual({ ssn_last_four: "1234" });
    expect(toolSteps[1].tool?.success).toBe(true);
  });

  it("preserves a RETURN_TO_CONTROL toolUse when no execute_tool span carries the same name (regression guard)", () => {
    // The opposite case from the dedup tests: the agent ends a turn
    // with `Complete` (a RETURN_TO_CONTROL tool). Q in Connect does
    // NOT emit an execute_tool span for it — the inference toolUse
    // is the sole record. The fix must not over-correct and drop it.
    const trace = parseSpansToTrace("session-dedup-rtc-1", [
      {
        spanName: "inference",
        startTimestamp: "2026-06-11T03:25:00.000Z",
        endTimestamp: "2026-06-11T03:25:00.500Z",
        attributes: {
          outputMessages: [
            {
              values: [
                { text: { value: "Anything else?" } },
                {
                  toolUse: {
                    name: "Complete",
                    arguments: '{"summary":"resolved"}',
                  },
                },
              ],
            },
          ],
        },
      },
      // Mirrors the production shape: a `complete_agent` marker span
      // with no toolUse. It must NOT add another entry to toolSequence.
      {
        spanName: "complete_agent",
        startTimestamp: "2026-06-11T03:25:01.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
    ]);

    expect(trace.toolSequence).toEqual(["Complete"]);
    const toolSteps = trace.steps.filter((s) => s.type === "tool");
    expect(toolSteps).toHaveLength(1);
    expect(toolSteps[0].spanName).toBe("inference_tool_use");
    expect(toolSteps[0].tool?.toolName).toBe("Complete");
    expect(toolSteps[0].tool?.arguments).toEqual({ summary: "resolved" });
  });
});

describe("augmentTraceWithControlTools — inference toolUse interaction", () => {
  it("is a no-op when the inference parser already extracted the control tool", () => {
    // Reproduces the production shape: inference span carrying an
    // Escalate toolUse on outputMessages, plus an escalate_agent marker.
    // The parser puts Escalate in toolSequence; the augmenter must skip.
    const trace = parseSpansToTrace("session-aug-prod-1", [
      {
        spanName: "invoke_agent",
        startTimestamp: "2024-06-02T18:30:00.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
      {
        spanName: "inference",
        startTimestamp: "2024-06-02T18:30:01.000Z",
        endTimestamp: "2024-06-02T18:30:01.500Z",
        attributes: {
          outputMessages: [
            {
              values: [
                { text: { value: "Connecting you to a specialist." } },
                {
                  toolUse: {
                    name: "Escalate",
                    arguments:
                      '{"escalationReason":"customer requested human"}',
                  },
                },
              ],
            },
          ],
        },
      },
      {
        spanName: "escalate_agent",
        startTimestamp: "2024-06-02T18:30:02.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
    ]);

    expect(trace.toolSequence).toEqual(["Escalate"]);
    const stepsBefore = trace.steps.length;

    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    // Augmenter is a fallback path; it adds nothing because Escalate is
    // already in toolSequence from inference toolUse extraction.
    expect(augmented.steps).toHaveLength(stepsBefore);
    expect(augmented.toolSequence).toEqual(["Escalate"]);
    // No synthetic_control_tool span was added.
    expect(
      augmented.steps.find((s) => s.spanName === "synthetic_control_tool"),
    ).toBeUndefined();
    // The real entry from inference extraction is preserved.
    const realEntry = augmented.steps.find(
      (s) => s.spanName === "inference_tool_use",
    );
    expect(realEntry?.tool?.toolName).toBe("Escalate");
    expect(realEntry?.tool?.arguments).toEqual({
      escalationReason: "customer requested human",
    });
  });

  it("falls back to a synthetic step when the inference span had only text (no toolUse)", () => {
    // Synthetic test data: the model emitted only text on the inference
    // span — no toolUse — yet the polling loop still saw Escalate via
    // conversationSessionData["Tool"]. The augmenter must add a
    // synthetic step in this fallback case.
    const trace = parseSpansToTrace("session-aug-fallback-1", [
      {
        spanName: "inference",
        startTimestamp: "2024-06-02T18:30:01.000Z",
        attributes: {
          outputMessages: [
            { values: [{ text: { value: "Let me transfer you." } }] },
          ],
        },
      },
      {
        spanName: "escalate_agent",
        startTimestamp: "2024-06-02T18:30:02.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
    ]);

    expect(trace.toolSequence).toEqual([]);

    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    expect(augmented.toolSequence).toEqual(["Escalate"]);
    const synthetic = augmented.steps.find(
      (s) => s.spanName === "synthetic_control_tool",
    );
    expect(synthetic).toBeDefined();
    expect(synthetic?.tool?.toolName).toBe("Escalate");
  });
});

describe("augmentTraceWithControlTools", () => {
  function makeEmptyTrace(): ExecutionTrace {
    return {
      sessionId: "session-aug-1",
      steps: [],
      toolSequence: [],
      capturedAt: "2024-06-02T18:30:10.000Z",
    };
  }

  function makeEscalationTrace(): ExecutionTrace {
    return parseSpansToTrace("session-aug-2", [
      {
        spanName: "invoke_agent",
        startTimestamp: "2024-06-02T18:30:00.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
      {
        spanName: "inference",
        startTimestamp: "2024-06-02T18:30:01.000Z",
        attributes: {
          outputMessages: [
            { values: [{ text: { value: "Let me get you to a specialist." } }] },
          ],
        },
      },
      // The escalate_agent span Q in Connect emits for a RETURN_TO_CONTROL
      // tool. The parser maps this to type "other", so it is NOT in
      // toolSequence — exactly the bug condition this augmentation fixes.
      {
        spanName: "escalate_agent",
        startTimestamp: "2024-06-02T18:30:02.000Z",
        attributes: { aiAgentName: "AnyBank", aiAgentType: "ORCHESTRATION" },
      },
    ]);
  }

  it("appends a synthetic tool step when the trace has zero steps and one control tool was captured", () => {
    const trace = makeEmptyTrace();

    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    expect(augmented.steps).toHaveLength(1);
    expect(augmented.toolSequence).toEqual(["Escalate"]);
    const synthetic = augmented.steps[0];
    expect(synthetic.type).toBe("tool");
    expect(synthetic.spanName).toBe("synthetic_control_tool");
    expect(synthetic.tool).toEqual({
      toolName: "Escalate",
      arguments: {},
      result: {},
      success: true,
      timestamp: trace.capturedAt,
    });
    // Falls back to the trace's `capturedAt` when no span carried a timestamp.
    expect(synthetic.timestamp).toBe(trace.capturedAt);
    expect(synthetic.index).toBe(0);
  });

  it("appends a synthetic tool step at the end when the original trace has an `escalate_agent` span tagged `other`", () => {
    const trace = makeEscalationTrace();
    // Sanity: the parser places the escalate_agent span as type "other"
    // (NOT "tool") and does NOT include it in toolSequence — the bug.
    expect(trace.steps).toHaveLength(3);
    expect(trace.steps[2].spanName).toBe("escalate_agent");
    expect(trace.steps[2].type).toBe("other");
    expect(trace.toolSequence).toEqual([]);

    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    expect(augmented.steps).toHaveLength(4);
    // The original escalate_agent step at index 2 is preserved as-is —
    // the augmenter does not edit existing steps.
    expect(augmented.steps[2]).toEqual(trace.steps[2]);
    // The synthetic step is appended at the end.
    const synthetic = augmented.steps[3];
    expect(synthetic.type).toBe("tool");
    expect(synthetic.spanName).toBe("synthetic_control_tool");
    expect(synthetic.tool?.toolName).toBe("Escalate");
    // The synthetic step inherits the LAST observed span timestamp, so it
    // sorts chronologically after every real span.
    expect(synthetic.timestamp).toBe("2024-06-02T18:30:02.000Z");
    expect(augmented.toolSequence).toEqual(["Escalate"]);
  });

  it("does not double-count a tool name already present in trace.toolSequence", () => {
    // A trace where some tool with name `someTool` came through as an
    // execute_tool span (and is therefore already in toolSequence). If the
    // controlToolsInvoked list also reports it, we must NOT add a synthetic
    // duplicate.
    const trace = parseSpansToTrace("session-aug-3", [
      {
        spanName: "execute_tool",
        startTimestamp: "2024-06-02T18:30:00.000Z",
        attributes: {
          inputMessages: [
            { values: [{ toolUse: { name: "someTool", arguments: "{}" } }] },
          ],
          outputMessages: [
            {
              values: [
                {
                  toolResult: {
                    values: [{ text: { value: '{"status":"success"}' } }],
                  },
                },
              ],
            },
          ],
        },
      },
    ]);
    expect(trace.toolSequence).toEqual(["someTool"]);

    const augmented = augmentTraceWithControlTools(trace, ["someTool"]);

    expect(augmented.steps).toHaveLength(1);
    expect(augmented.toolSequence).toEqual(["someTool"]);
  });

  it("handles a custom RETURN_TO_CONTROL tool name generically (no hardcoded list)", () => {
    const trace = makeEmptyTrace();

    const augmented = augmentTraceWithControlTools(trace, [
      "TransferToFraudDept",
    ]);

    expect(augmented.toolSequence).toEqual(["TransferToFraudDept"]);
    expect(augmented.steps).toHaveLength(1);
    expect(augmented.steps[0].tool?.toolName).toBe("TransferToFraudDept");
  });

  it("appends multiple control tools in the order given", () => {
    const trace = makeEmptyTrace();

    const augmented = augmentTraceWithControlTools(trace, [
      "Escalate",
      "Complete",
    ]);

    expect(augmented.toolSequence).toEqual(["Escalate", "Complete"]);
    expect(augmented.steps.map((s) => s.tool?.toolName)).toEqual([
      "Escalate",
      "Complete",
    ]);
    expect(augmented.steps.map((s) => s.index)).toEqual([0, 1]);
  });

  it("returns a new trace without mutating the input", () => {
    const trace = makeEscalationTrace();
    const stepsBefore = trace.steps.length;
    const sequenceBefore = trace.toolSequence.slice();

    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);

    expect(augmented).not.toBe(trace);
    expect(trace.steps.length).toBe(stepsBefore);
    expect(trace.toolSequence).toEqual(sequenceBefore);
  });

  it("is a no-op when controlToolsInvoked is empty", () => {
    const trace = makeEscalationTrace();

    const augmented = augmentTraceWithControlTools(trace, []);

    expect(augmented.steps).toEqual(trace.steps);
    expect(augmented.toolSequence).toEqual(trace.toolSequence);
  });

  it("produces a judgeable trace whose only tool steps are synthetic control-tool entries", () => {
    // The evaluation Lambda's INSUFFICIENT_TRACE guard counts steps where
    // `type === "tool"` as a tool call. A trace whose only steps are
    // synthetic control-tool entries should be deemed judgeable.
    const trace = makeEmptyTrace();
    const augmented = augmentTraceWithControlTools(trace, ["Escalate"]);
    const toolCount = augmented.steps.filter((s) => s.type === "tool").length;
    expect(toolCount).toBeGreaterThan(0);
  });
});
