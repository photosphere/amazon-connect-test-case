"""Simulated customer using Bedrock for multi-turn conversations.

When the AI Agent asks a clarifying question, this module calls Bedrock
(Claude Haiku) to generate a realistic customer response based on the
scenario context — account type, last 4 SSN, personal details, etc.

The Converse API always generates "assistant" role responses. So we flip:
- The simulated customer's messages → assistant role (model generates these)
- The AI Agent's messages → user role (these are the "questions" to respond to)

The system prompt sets up the customer persona with their scenario context.
"""

import json

import boto3

# --- Constants ---
REGION = "us-east-1"
MODEL_ID = "us.anthropic.claude-haiku-4-5-20251001-v1:0"
MAX_TOKENS = 150  # Customer responses should be short

SYSTEM_PROMPT_TEMPLATE = """You are a bank customer on the phone with an automated banking assistant. Stay in character throughout.

Your scenario:
- What you want to do: {goal}
- Your communication style: {style_description}

Your personal details (provide ONLY when the assistant asks for them):
{customer_context}

Rules:
- Respond naturally as a real customer would — short and conversational
- Only provide information the assistant specifically asks for
- Do NOT volunteer extra information unprompted
- Do NOT mention tool names, system internals, or that you are a test
- Keep responses to 1-2 sentences maximum
- If asked which account type, pick one from your details
- If asked to confirm an action, say yes naturally
- Match the communication style described above"""

STYLE_DESCRIPTIONS = {
    "direct": "You are clear and to-the-point. You state exactly what you want.",
    "indirect": "You describe your situation without naming the exact action you need.",
    "colloquial": "You speak casually with slang. Not formal at all.",
    "question": "You tend to phrase things as questions rather than commands.",
    "complaint": "You are frustrated and complaining about the situation.",
}


class CustomerSimulator:
    """Generates customer responses to agent clarifying questions via Bedrock."""

    def __init__(self, region: str = REGION, model_id: str = MODEL_ID):
        self.client = boto3.client("bedrock-runtime", region_name=region)
        self.model_id = model_id

    def generate_response(
        self,
        agent_message: str,
        utterance: dict,
        conversation_history: list[dict] | None = None,
    ) -> str:
        """Generate a customer response to the agent's clarifying question.

        Args:
            agent_message: The text the AI Agent sent (the clarifying question).
            utterance: The utterance record with text, style, and customer_context.
            conversation_history: Prior turns as sent to the AI Agent (user=customer,
                assistant=agent). We flip these for the Bedrock call.

        Returns:
            A natural customer response string.
        """
        goal = utterance.get("text", "")
        style = utterance.get("style", "direct")
        customer_context = utterance.get("customer_context", "")
        style_description = STYLE_DESCRIPTIONS.get(style, STYLE_DESCRIPTIONS["direct"])

        # Format the customer context
        if isinstance(customer_context, dict):
            context_lines = [f"- {k}: {v}" for k, v in customer_context.items()]
            context_str = "\n".join(context_lines)
        elif isinstance(customer_context, str) and customer_context:
            context_str = customer_context
        else:
            # Default context for tools that don't need specific data
            context_str = "- Account types: checking and savings\n- You can pick either when asked"

        system_prompt = SYSTEM_PROMPT_TEMPLATE.format(
            goal=goal,
            style_description=style_description,
            customer_context=context_str,
        )

        # Build messages for Bedrock — FLIPPED roles:
        # Customer's words → assistant (model generated these)
        # Agent's words → user (model responds to these)
        messages = []

        if conversation_history:
            for turn in conversation_history:
                role = turn.get("role", "")
                content = turn.get("content", [])
                if role == "user":
                    # Customer said this → becomes assistant in Bedrock
                    messages.append({"role": "assistant", "content": content})
                elif role == "assistant":
                    # Agent said this → becomes user in Bedrock
                    messages.append({"role": "user", "content": content})
        else:
            # No history — just the initial utterance as context
            messages.append(
                {"role": "assistant", "content": [{"text": goal}]}
            )

        # Add the agent's latest message as the final "user" turn
        # (what the model needs to respond to)
        messages.append({"role": "user", "content": [{"text": agent_message}]})

        try:
            response = self.client.converse(
                modelId=self.model_id,
                system=[{"text": system_prompt}],
                messages=messages,
                inferenceConfig={
                    "maxTokens": MAX_TOKENS,
                    "temperature": 0.7,
                },
            )

            # Extract the response text
            output = response.get("output", {})
            message = output.get("message", {})
            content = message.get("content", [])

            if content and "text" in content[0]:
                return content[0]["text"].strip()

            # Empty content — model declined to respond
            return "Yes, go ahead"

        except Exception as e:
            # Fallback if Bedrock call fails — don't block the test
            print(f"    [simulator] Bedrock call failed: {e}")
            return "Yes, please proceed with that"
