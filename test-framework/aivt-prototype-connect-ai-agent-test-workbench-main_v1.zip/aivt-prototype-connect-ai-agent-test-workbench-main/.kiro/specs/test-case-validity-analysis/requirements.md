# Requirements Document

## Introduction

This feature extends the Connect Agent Test Platform's Recommendation_Engine to detect and surface **test case defects** — situations where a test case fails not because the agent misbehaved but because the test case's expectations are unreasonable, contradictory, or impossible given the agent's instructions. Today the analysis engine assumes every failure is an agent problem. In practice, a significant class of failures stems from test cases that expect tool invocations the agent correctly refuses (e.g., processing a payment without user confirmation), personas that make the expected behavior impossible (e.g., an angry persona told to politely provide an account number on the first turn), overly strict success criteria (e.g., requiring an exact 5-tool sequence when a 3-tool sequence achieves the same goal), or initial utterances that don't align with the expected tool path.

The feature adds:

1. A new root cause category `test_case_defect` for when the agent's reasoning trace shows it made a sound decision but the test expected otherwise.
2. A new recommendation target type `test_case` (alongside existing `tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`) for recommending edits to the test case itself.
3. Inclusion of the full test case definition in the analysis prompt so the LLM can evaluate whether expectations are reasonable.
4. Test-case-specific recommendation fields (which test case field to edit: `successCriteria`, `initialUtterance`, `persona`, `customerKnowledge`).
5. Distinct UI treatment for test case recommendations (visually separated from agent recommendations).
6. Separate aggregation of test case defects in the per-suite consolidation path.

The reasoning trace (shipped in the `trace-reasoning-and-latency` feature) is the critical signal: when the agent's chain-of-thought shows sound decision-making ("I cannot process a payment without user confirmation per my instructions") but the test expected that tool to be called, the analysis should flag the test case as defective rather than blaming the agent.

## Glossary

- **Platform**: The Connect Agent Test Platform (the existing system this feature extends).
- **Recommendation_Engine**: The backend handler family that produces per-case and per-suite recommendations by calling Bedrock and persisting results. Encompasses `src/backend/handlers/analysis.ts` and `src/backend/handlers/suite-recommend.ts`.
- **Test_Case_Definition**: The full stored definition of a test case including `caseId`, `name`, `description`, `initialUtterance`, `persona`, `style`, `customerKnowledge`, `successCriteria`, `goalDescription`, `sessionData`, and `primingMessage`.
- **Test_Case_Defect**: A root cause classification indicating the agent behaved correctly according to its instructions but the test case's expectations are flawed — the test case is the thing that needs fixing, not the agent.
- **Test_Case_Recommendation**: A recommendation whose `targetField` is `test_case`, proposing an edit to a specific field of the test case definition rather than to the agent's configuration.
- **Test_Case_Target_Field**: One of the editable fields on a test case definition that a `Test_Case_Recommendation` may target: `successCriteria`, `initialUtterance`, `persona`, `customerKnowledge`, `goalDescription`.
- **Agent_Recommendation**: A recommendation whose `targetField` is one of the four existing agent surfaces (`tool_description`, `tool_instruction`, `tool_examples`, `system_prompt`).
- **Reasoning_Trace**: The agent's chain-of-thought reasoning captured from Q in Connect `ListSpans` and persisted on each `ExecutionStep`. The agent's internal rationale for its decisions, distinct from its customer-facing utterance.
- **Sound_Decision_Signal**: Evidence in the reasoning trace that the agent deliberately chose not to invoke a tool based on its instructions, safety guardrails, or correct interpretation of the conversation state.
- **Recommended_Changes_Panel**: The UI block on the Run Dashboard that renders persisted recommendations above the test case results table.
- **Suite_Consolidation**: The per-suite recommendation path (`POST /runs/{runId}/recommend-suite`) that consolidates per-case failures into prioritized recommendations.
- **ToolSurface**: The existing type union of recommendation targets: `tool_description | tool_instruction | tool_examples | system_prompt`. This feature extends the concept to include `test_case` as a fifth target type.
- **RecommendationTarget**: The extended type union that includes both agent surfaces and the new `test_case` target: `tool_description | tool_instruction | tool_examples | system_prompt | test_case`.

## Requirements

### Requirement 1: Include Test Case Definition in the Analysis Prompt

**User Story:** As a platform owner running failure analysis, I want the Bedrock prompt to include the full test case definition (success criteria, persona, initial utterance, customer knowledge, goal description), so that the LLM can evaluate whether the test expectations themselves are reasonable given the agent's configuration and instructions.

#### Acceptance Criteria

1. WHEN the Recommendation_Engine builds the per-case analysis prompt for a failed test case, THE Recommendation_Engine SHALL include a `## Test Case Definition` section in the rendered user message that contains the test case's `name`, `description`, `initialUtterance`, `persona`, `style`, `customerKnowledge` (formatted as key-value pairs), `goalDescription` (when present), and `successCriteria` (formatted as an ordered list of tool steps with their `required` flag and any `parameterChecks`).
2. THE Recommendation_Engine SHALL render the `## Test Case Definition` section immediately after the `## Test Case: {caseId}` header and before the `## Conversation Transcript` section, so that the LLM evaluates expectations before seeing what actually happened.
3. IF the test case's `goalDescription` field is absent or empty, THEN THE Recommendation_Engine SHALL render `Goal: (not specified)` rather than omitting the field, so that the LLM is aware the test case lacks an explicit goal statement.
4. THE Recommendation_Engine SHALL render `customerKnowledge` as a bulleted list of `key: value` pairs preserving the exact key and value strings from the persisted test case. WHERE `customerKnowledge` is empty (zero key-value pairs), THE Recommendation_Engine SHALL render `Customer Knowledge: (none)`.
5. THE Recommendation_Engine SHALL render `successCriteria` as a numbered list in the format `N. toolName (required: true/false)` with any `parameterChecks` listed as indented sub-items in the format `  - paramName = expectedValue`.
6. WHEN loading the test case definition for prompt construction, THE Recommendation_Engine SHALL fetch the test case record from DynamoDB using the `caseId` from the failed result and the `suiteId` from the request context.
7. IF the test case record cannot be loaded (deleted between run execution and analysis), THEN THE Recommendation_Engine SHALL render `## Test Case Definition\n(Test case record not found — analysis will proceed without test case context)` and SHALL continue with analysis rather than aborting.

### Requirement 2: New Root Cause Category for Test Case Defects

**User Story:** As a tester reviewing analysis results, I want a distinct root cause category that tells me "the agent was right, the test is wrong," so that I can fix the test case rather than spending time debugging agent configuration that is already correct.

#### Acceptance Criteria

1. THE Recommendation_Engine SHALL add `test_case_defect` to the set of valid root cause categories, extending the existing set (`overlapping_tool_descriptions`, `missing_disambiguation`, `incorrect_tool_prioritization`, `incomplete_tool_description`, `system_prompt_gap`, `missing_tool_instruction`, `parameter_mismatch`, `other`).
2. WHEN the Recommendation_Engine's per-case analysis prompt instructs the LLM to choose a root cause category, THE prompt SHALL include `test_case_defect` in the enumerated list with the description: "The agent's reasoning trace shows it made a correct decision based on its instructions, but the test case expected different behavior. The test case's expectations are unreasonable, contradictory, or impossible."
3. WHEN the Recommendation_Engine parses a Bedrock response with `rootCauseCategory` equal to `test_case_defect`, THE Recommendation_Engine SHALL persist the category as-is and SHALL NOT reclassify it into `other`.
4. THE Recommendation_Engine's per-case analysis prompt SHALL instruct the LLM to prefer `test_case_defect` over `other` when the reasoning trace provides clear evidence that the agent deliberately chose not to invoke an expected tool because its instructions prohibit that action without a prerequisite the test did not arrange.
5. WHEN the reasoning trace is unavailable for a case, THE Recommendation_Engine's prompt SHALL instruct the LLM that `test_case_defect` MAY still be assigned if the test case definition alone provides sufficient evidence of unreasonable expectations (e.g., success criteria requiring a tool that does not exist in the agent's configuration, or a persona description that contradicts the expected behavior), but SHALL note that confidence is lower without trace evidence.

### Requirement 3: New Recommendation Target Type for Test Cases

**User Story:** As a tester receiving a recommendation, I want recommendations that target the test case itself (not the agent) to be clearly identified as such, so that I know to edit the test case rather than the agent's configuration.

#### Acceptance Criteria

1. THE Platform SHALL extend the `RecommendationTarget` type to include `test_case` alongside the existing four `ToolSurface` values, resulting in the union: `tool_description | tool_instruction | tool_examples | system_prompt | test_case`.
2. WHEN the Recommendation_Engine generates a recommendation with `targetField` equal to `test_case`, THE Recommendation_Engine SHALL set `targetName` to the `caseId` of the test case being recommended for edit.
3. THE Recommendation_Engine SHALL constrain `test_case` recommendations to cases where the `rootCauseCategory` is `test_case_defect`. WHERE the root cause is any other category, THE Recommendation_Engine SHALL NOT produce a recommendation with `targetField` equal to `test_case`.
4. THE Recommendation_Engine SHALL validate that a recommendation with `targetField` equal to `test_case` carries a non-empty `testCaseField` property (see Requirement 4). WHERE `testCaseField` is absent or empty, THE Recommendation_Engine SHALL drop the recommendation before persistence and SHALL log the malformed recommendation.
5. THE Platform SHALL extend the persistence-time validation (R13.3 from actionable-recommendations) to accept `test_case` as a valid `targetField` value alongside the four existing ToolSurface values.

### Requirement 4: Test Case Recommendation Specifies Target Field

**User Story:** As a tester applying a test case recommendation, I want the recommendation to tell me exactly which field of the test case to edit (success criteria, persona, initial utterance, etc.) and what the suggested change is, so that I can make a precise fix.

#### Acceptance Criteria

1. THE Platform SHALL extend the `Recommendation` interface with an optional `testCaseField` property of type `TestCaseTargetField` that is present when `targetField` equals `test_case` and absent otherwise.
2. THE `TestCaseTargetField` type SHALL be a union of: `successCriteria`, `initialUtterance`, `persona`, `customerKnowledge`, `goalDescription`.
3. WHEN the Recommendation_Engine generates a `test_case` recommendation targeting `successCriteria`, THE Recommendation_Engine SHALL set `currentText` to the current success criteria formatted as the numbered tool-step list (matching the prompt rendering format from Requirement 1.5) and `suggestedText` to the proposed replacement criteria in the same format.
4. WHEN the Recommendation_Engine generates a `test_case` recommendation targeting `initialUtterance`, `persona`, or `goalDescription`, THE Recommendation_Engine SHALL set `currentText` to the exact current field value and `suggestedText` to the proposed replacement value.
5. WHEN the Recommendation_Engine generates a `test_case` recommendation targeting `customerKnowledge`, THE Recommendation_Engine SHALL set `currentText` to the current key-value pairs formatted as `key: value` (one per line) and `suggestedText` to the proposed replacement in the same format. WHERE the recommendation adds a new key, `currentText` SHALL be the empty string for that key's line. WHERE it removes a key, `suggestedText` SHALL be the empty string for that key's line.
6. THE Recommendation_Engine's per-case analysis prompt SHALL instruct the LLM to specify the `testCaseField` value when recommending a `test_case` edit, and SHALL enumerate the five valid values with brief descriptions of when each applies.
7. THE Recommendation_Engine's per-case analysis prompt SHALL instruct the LLM to produce at most one `test_case` recommendation per failed case (the single most impactful test case edit), so that recommendations remain focused and actionable.

### Requirement 5: Reasoning Trace Drives Test Case Defect Detection

**User Story:** As a platform owner, I want the analysis to use the agent's reasoning trace as the primary signal for detecting test case defects — when the agent's chain-of-thought shows it made a sound decision that conflicts with the test's expectations, the analysis should flag the test rather than the agent.

#### Acceptance Criteria

1. WHEN the Recommendation_Engine's per-case analysis prompt includes both a reasoning trace and a test case definition, THE prompt SHALL include an explicit instruction block directing the LLM to compare the agent's stated reasoning against the test case's success criteria and persona constraints, looking for Sound_Decision_Signals.
2. THE prompt SHALL define Sound_Decision_Signal patterns including: (a) the agent citing its instructions as the reason for not invoking a tool, (b) the agent citing safety or compliance guardrails, (c) the agent citing missing prerequisite information that the customer persona or session data did not provide, (d) the agent citing ambiguity in the customer utterance that requires clarification before acting.
3. WHEN the reasoning trace contains a Sound_Decision_Signal that directly conflicts with a `required: true` tool in `successCriteria`, THE prompt SHALL instruct the LLM to classify the case as `test_case_defect` unless there is stronger evidence that the agent's reasoning was itself flawed (e.g., hallucinated a constraint that does not exist in the system prompt).
4. THE prompt SHALL instruct the LLM to include in the `explanation` field a direct quote from the reasoning trace that demonstrates the Sound_Decision_Signal, so that the human reviewer can verify the classification without reading the full trace.
5. WHEN the reasoning trace is unavailable, THE prompt SHALL instruct the LLM to rely on structural signals from the test case definition alone (e.g., success criteria requiring tools absent from the agent's configuration, persona constraints incompatible with expected behavior) and to note reduced confidence in the explanation.

### Requirement 6: Suite-Level Aggregation Separates Test Case Defects

**User Story:** As a tester reviewing suite-level consolidated recommendations, I want test case defects aggregated separately from agent deficiencies, so that a cluster of tests failing because of unreasonable expectations is clearly distinguished from a cluster failing because of a shared agent problem.

#### Acceptance Criteria

1. WHEN the Suite_Consolidation builds its per-suite prompt, THE Suite_Consolidation SHALL partition per-case failures into two groups: (a) cases with `rootCauseCategory === "test_case_defect"` and (b) all other cases, and SHALL present them in distinct labeled sections (`## Agent Deficiency Failures` and `## Test Case Defect Failures`).
2. THE Suite_Consolidation's prompt SHALL instruct the LLM to produce agent-targeted recommendations (targeting `tool_description`, `tool_instruction`, `tool_examples`, or `system_prompt`) only from the agent-deficiency group, and test-case-targeted recommendations (targeting `test_case`) only from the test-case-defect group.
3. WHEN the Suite_Consolidation produces `Per_Suite_Recommendation` records with `targetField === "test_case"`, THE Suite_Consolidation SHALL set `predictedImpact.liftedCaseIds` to the case IDs from the test-case-defect group that the test case edit would fix, and SHALL NOT include agent-deficiency case IDs in that array.
4. THE Suite_Consolidation's suite-level recommendations SHALL maintain the existing priority ordering across both recommendation types (agent-targeted and test-case-targeted) so that the overall prioritization reflects relative impact regardless of target type.
5. WHEN all failed cases in a run are classified as `test_case_defect`, THE Suite_Consolidation SHALL produce only test-case-targeted recommendations and SHALL NOT produce agent-targeted recommendations.
6. WHEN no failed cases in a run are classified as `test_case_defect`, THE Suite_Consolidation SHALL produce only agent-targeted recommendations (existing behavior unchanged).

### Requirement 7: UI Visual Distinction for Test Case Recommendations

**User Story:** As a tester scanning the Recommended Changes Panel, I want test case recommendations to be visually distinct from agent recommendations, so that I immediately know which ones require me to fix my tests versus fix the agent.

#### Acceptance Criteria

1. WHEN the Recommended_Changes_Panel renders a recommendation with `targetField === "test_case"`, THE panel SHALL display a blue badge labeled "Fix test" alongside the recommendation, visually distinct from the existing orange badge used for agent recommendations.
2. WHEN the Recommended_Changes_Panel renders a recommendation with `targetField` in `[tool_description, tool_instruction, tool_examples, system_prompt]`, THE panel SHALL display an orange badge labeled "Fix agent" alongside the recommendation.
3. THE Recommended_Changes_Panel SHALL group recommendations into two visual sections: "Agent recommendations" (rendered first) and "Test case recommendations" (rendered second), each with a section header and distinct background tint (light orange for agent, light blue for test case).
4. WHEN the run has recommendations of only one type (all agent or all test case), THE Recommended_Changes_Panel SHALL render only the relevant section without the other section's header or empty state.
5. WHEN the Failure_Analysis_View renders per-case recommendations that include a `test_case` recommendation, THE Failure_Analysis_View SHALL render the test case recommendation with the same blue "Fix test" badge and SHALL display the `testCaseField` value as a sub-label (e.g., "Fix test · successCriteria").
6. THE per-case detail page SHALL render `test_case` recommendations with a link to the test case editor pre-populated with the recommended field and suggested value, so that applying the fix requires minimal navigation.

### Requirement 8: Backward Compatibility with Existing Analyses

**User Story:** As a tester viewing a run analyzed before this feature shipped, I want the existing persisted analyses to render without errors, so that historical data remains accessible.

#### Acceptance Criteria

1. WHEN the Platform reads a persisted per-case analysis whose `rootCauseCategory` is not `test_case_defect` and whose recommendations array contains no `test_case` entries, THE Platform SHALL render the analysis identically to the pre-feature behavior.
2. WHEN the Platform reads a persisted per-case analysis that lacks the `testCaseField` property on any recommendation, THE Platform SHALL treat such recommendations as agent-targeted and render them with the existing orange "Fix agent" badge.
3. THE Recommendation_Engine SHALL NOT retroactively re-analyze persisted results when this feature ships. Existing `ANALYSIS#CASE#{caseId}` records remain unchanged until a user explicitly triggers "Re-analyze" with `force: true`.
4. WHEN a user triggers "Re-analyze" on a run after this feature ships, THE Recommendation_Engine SHALL use the new prompt (including test case definition and `test_case_defect` category) and MAY reclassify cases that were previously categorized as `other` into `test_case_defect`.
5. THE Platform SHALL extend the `PerCaseAnalysis` response type to include an optional `testCaseDefect` boolean flag that is `true` when `rootCauseCategory === "test_case_defect"`, so that UI consumers can switch rendering without string-comparing the category value.

### Requirement 9: Per-Case Analysis Prompt Extension

**User Story:** As a platform engineer maintaining the analysis prompt, I want the prompt changes for test case validity analysis to be additive and isolated, so that the existing per-case analysis quality is not degraded for cases that are genuine agent deficiencies.

#### Acceptance Criteria

1. THE Recommendation_Engine SHALL extend the per-case analysis prompt's JSON response schema to include the optional `testCaseField` property on recommendations and SHALL add `test_case` to the valid `targetField` enumeration in the prompt's instructions block.
2. THE Recommendation_Engine's prompt SHALL instruct the LLM that `test_case_defect` classification and `test_case` recommendations are reserved for cases where the reasoning trace or structural evidence clearly shows the agent was correct — the prompt SHALL explicitly state that uncertain cases should default to an agent-deficiency category rather than `test_case_defect`.
3. THE Recommendation_Engine's prompt SHALL instruct the LLM to produce both agent-targeted and test-case-targeted recommendations for the same case when evidence supports both (e.g., the test case expectations are too strict AND the agent's description could also be improved), limited to a maximum of 5 total recommendations per case.
4. THE Recommendation_Engine's prompt SHALL maintain the existing instruction quality for the eight original root cause categories — adding `test_case_defect` SHALL NOT weaken the LLM's ability to correctly identify agent-configuration problems.
5. WHEN a test case's `successCriteria` contains a tool name that does not appear in the agent's tool configuration, THE prompt SHALL instruct the LLM to flag this as a strong `test_case_defect` signal (the test expects a tool the agent does not have).

### Requirement 10: Test Case Recommendation Persistence

**User Story:** As a tester re-opening a run's recommendations, I want test case recommendations persisted alongside agent recommendations in the same analysis record, so that revisits show the complete picture without re-invoking Bedrock.

#### Acceptance Criteria

1. THE Recommendation_Engine SHALL persist `test_case` recommendations in the same `ANALYSIS#CASE#{caseId}` record alongside agent recommendations, within the existing `recommendations[]` array.
2. THE Recommendation_Engine SHALL persist the `testCaseField` property on recommendations where `targetField === "test_case"`, as a top-level property of the recommendation object in the persisted JSON.
3. FOR ANY persisted per-case analysis containing `test_case` recommendations, the round-trip property SHALL hold: writing the analysis to DynamoDB and reading it back SHALL produce a record whose `test_case` recommendations carry identical `targetField`, `targetName`, `testCaseField`, `currentText`, `suggestedText`, and `rationale` values.
4. THE Suite_Consolidation SHALL persist `test_case` per-suite recommendations in the same `ANALYSIS#SUITE` record alongside agent per-suite recommendations, within the existing `recommendations[]` array, maintaining the unified priority ordering.
5. WHEN the Recommended_Changes_Panel reads persisted recommendations, THE panel SHALL partition by `targetField` at render time (client-side) rather than requiring separate persistence keys.

### Requirement 11: Property-Testable Behaviors

**User Story:** As a maintainer, I want the test-case-defect classification logic, the prompt rendering, and the UI partitioning to be expressible as property tests, so that regressions are caught automatically.

#### Acceptance Criteria

1. FOR ANY set of `Recommendation` records, the UI partitioning function SHALL split the records into exactly two groups: (a) those with `targetField === "test_case"` and (b) those with `targetField` in the four existing `ToolSurface` values, where every record appears in exactly one group and the union equals the input.
2. FOR ANY `PerCaseAnalysis` with `rootCauseCategory === "test_case_defect"`, the recommendations array SHALL contain at least one recommendation with `targetField === "test_case"` and a non-empty `testCaseField` value.
3. FOR ANY recommendation with `targetField === "test_case"`, the `testCaseField` property SHALL be one of the five valid `TestCaseTargetField` values (`successCriteria`, `initialUtterance`, `persona`, `customerKnowledge`, `goalDescription`).
4. FOR ANY persisted per-suite analysis, the `test_case` recommendations in the array SHALL have `predictedImpact.liftedCaseIds` entries that are a subset of the case IDs classified as `test_case_defect` in the per-case analyses for that run.
5. FOR ANY per-case analysis prompt rendered with a test case definition, the rendered prompt SHALL contain the literal strings `## Test Case Definition`, the test case's `initialUtterance` value, and every tool name from the test case's `successCriteria` array.
6. FOR ANY `Recommendation` with `targetField === "test_case"` and `testCaseField === "successCriteria"`, the `currentText` SHALL be a non-empty string (the test case always has at least one success criterion tool step).
