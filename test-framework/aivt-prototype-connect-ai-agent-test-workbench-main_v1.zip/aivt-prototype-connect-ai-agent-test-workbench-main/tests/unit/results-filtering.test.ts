import { describe, it, expect } from "vitest";
import { filterResults } from "../../src/shared/utils/results-filtering";
import { CaseStatus } from "../../src/shared/enums";

describe("filterResults", () => {
  const sampleResults = [
    { status: CaseStatus.PASSED, toolsInvoked: ["SearchFlights", "BookFlight"] },
    { status: CaseStatus.FAILED, toolsInvoked: ["Authenticate", "SearchFlights"] },
    { status: CaseStatus.ERROR, toolsInvoked: ["Authenticate"] },
    { status: CaseStatus.PASSED, toolsInvoked: ["GetBalance"] },
  ];

  it("returns empty array for empty input", () => {
    expect(filterResults([], { status: [CaseStatus.PASSED] })).toEqual([]);
  });

  it("returns all results when no criteria provided", () => {
    const result = filterResults(sampleResults);
    expect(result).toHaveLength(4);
  });

  it("returns all results when criteria is empty object", () => {
    const result = filterResults(sampleResults, {});
    expect(result).toHaveLength(4);
  });

  it("does not mutate the original array", () => {
    const original = [...sampleResults];
    filterResults(sampleResults, { status: [CaseStatus.PASSED] });
    expect(sampleResults).toEqual(original);
  });

  it("filters by single status", () => {
    const result = filterResults(sampleResults, { status: [CaseStatus.PASSED] });
    expect(result).toHaveLength(2);
    expect(result.every((r) => r.status === CaseStatus.PASSED)).toBe(true);
  });

  it("filters by multiple statuses", () => {
    const result = filterResults(sampleResults, {
      status: [CaseStatus.FAILED, CaseStatus.ERROR],
    });
    expect(result).toHaveLength(2);
    expect(result[0].status).toBe(CaseStatus.FAILED);
    expect(result[1].status).toBe(CaseStatus.ERROR);
  });

  it("filters by tool invoked", () => {
    const result = filterResults(sampleResults, { toolInvoked: "SearchFlights" });
    expect(result).toHaveLength(2);
    expect(
      result.every((r) =>
        r.toolsInvoked.some((t) => t.toLowerCase() === "searchflights"),
      ),
    ).toBe(true);
  });

  it("filters by tool invoked case-insensitively", () => {
    const result = filterResults(sampleResults, { toolInvoked: "searchflights" });
    expect(result).toHaveLength(2);
  });

  it("applies both status and tool filters as AND", () => {
    const result = filterResults(sampleResults, {
      status: [CaseStatus.PASSED],
      toolInvoked: "SearchFlights",
    });
    expect(result).toHaveLength(1);
    expect(result[0].status).toBe(CaseStatus.PASSED);
    expect(result[0].toolsInvoked).toContain("SearchFlights");
  });

  it("returns empty when no results match criteria", () => {
    const result = filterResults(sampleResults, { toolInvoked: "NonExistentTool" });
    expect(result).toEqual([]);
  });

  it("handles results with empty toolsInvoked arrays", () => {
    const results = [
      { status: CaseStatus.ERROR, toolsInvoked: [] },
      { status: CaseStatus.PASSED, toolsInvoked: ["ToolA"] },
    ];
    const result = filterResults(results, { toolInvoked: "ToolA" });
    expect(result).toHaveLength(1);
    expect(result[0].toolsInvoked).toContain("ToolA");
  });

  it("handles empty status array in criteria as no filter", () => {
    const result = filterResults(sampleResults, { status: [] });
    expect(result).toHaveLength(4);
  });

  it("preserves additional properties on result objects", () => {
    const results = [
      { status: CaseStatus.PASSED, toolsInvoked: ["A"], extra: "data" },
    ];
    const filtered = filterResults(results, { status: [CaseStatus.PASSED] });
    expect(filtered[0]).toHaveProperty("extra", "data");
  });
});
