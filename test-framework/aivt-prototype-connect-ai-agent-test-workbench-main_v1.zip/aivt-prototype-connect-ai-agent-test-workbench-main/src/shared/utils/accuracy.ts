/**
 * Accuracy calculation utility for test run results.
 *
 * Computes the overall accuracy percentage from a set of test case results.
 * Accuracy is defined as (passed / total) * 100, rounded to one decimal place.
 *
 * @module accuracy
 */

/**
 * Calculates the accuracy percentage from test results.
 *
 * Counts results with status "passed" and divides by the total number of results.
 * Returns 0 if the results array is empty.
 *
 * @param results - Array of result objects with a `status` field
 * @returns Accuracy percentage rounded to one decimal place (0.0–100.0)
 *
 * @example
 * calculateAccuracy([{ status: "passed" }, { status: "failed" }, { status: "passed" }])
 * // Returns 66.7
 */
export function calculateAccuracy(results: { status: string }[]): number {
  if (!results || results.length === 0) {
    return 0;
  }

  const passedCount = results.filter((r) => r.status === "passed").length;
  const accuracy = (passedCount / results.length) * 100;

  return Math.round(accuracy * 10) / 10;
}
