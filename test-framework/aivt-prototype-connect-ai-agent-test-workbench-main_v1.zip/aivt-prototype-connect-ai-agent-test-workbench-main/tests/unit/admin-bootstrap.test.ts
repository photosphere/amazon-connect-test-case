/**
 * Unit tests for the admin user bootstrap custom-resource handler.
 *
 * Backs task 3.2 (Workstream 1 — Hosting & Bootstrap). The handler under test is
 * `src/backend/bootstrap/admin-user-bootstrap.ts`, created in task 3.1. These
 * tests mock the AWS SDK v3 Cognito client (via the handler's `_setCognitoClient`
 * injection seam, matching the repo's existing convention in
 * `contact-manager.test.ts`/`evaluation.test.ts`) and assert the create-path
 * contract:
 *
 *  - Exactly one `AdminCreateUser` call on the create path.
 *  - `MessageAction` is NOT `SUPPRESS` so Cognito sends the temp-password email (Req 6.2).
 *  - The email is used as both `Username` and the `email` user attribute (Req 6.4).
 *  - The user is created in the force-change-password flow — the handler enforces
 *    this by relying on the default `MessageAction` (no `SUPPRESS`, no
 *    `TemporaryPassword`), which yields the `FORCE_CHANGE_PASSWORD` state (Req 6.7).
 *  - `UsernameExistsException` is treated as success WITHOUT a second mutating
 *    call (no credential/password reset) (Req 6.5).
 *
 * Requirements: 6.2, 6.4, 6.5, 6.7
 */

import { describe, it, expect, vi, afterEach } from "vitest";
import {
  AdminCreateUserCommand,
  UsernameExistsException,
  type CognitoIdentityProviderClient,
} from "@aws-sdk/client-cognito-identity-provider";
import {
  handler,
  _setCognitoClient,
  type CustomResourceEvent,
} from "../../src/backend/bootstrap/admin-user-bootstrap";

const ADMIN_EMAIL = "admin@example.com";
const USER_POOL_ID = "us-east-1_ABC123";
const PHYSICAL_ID = "admin-user-bootstrap-deadbeefdeadbeef";

/** Inject a mock Cognito client whose `send` is the supplied spy. */
function mockCognito(send: ReturnType<typeof vi.fn>) {
  _setCognitoClient({ send } as unknown as CognitoIdentityProviderClient);
}

/** Build a custom-resource event for the given lifecycle type. */
function makeEvent(
  requestType: CustomResourceEvent["RequestType"] = "Create",
  overrides: Partial<CustomResourceEvent["ResourceProperties"]> = {}
): CustomResourceEvent {
  return {
    RequestType: requestType,
    PhysicalResourceId: requestType === "Create" ? undefined : PHYSICAL_ID,
    ResourceProperties: {
      UserPoolId: USER_POOL_ID,
      AdminEmail: ADMIN_EMAIL,
      PhysicalResourceId: PHYSICAL_ID,
      ...overrides,
    },
  };
}

/** Return the single AdminCreateUserCommand input the handler sent. */
function singleAdminCreateUserInput(send: ReturnType<typeof vi.fn>) {
  expect(send).toHaveBeenCalledTimes(1);
  const command = send.mock.calls[0][0];
  expect(command).toBeInstanceOf(AdminCreateUserCommand);
  return command.input as AdminCreateUserCommand["input"];
}

describe("admin-user-bootstrap handler — create path", () => {
  afterEach(() => {
    _setCognitoClient(null);
    vi.restoreAllMocks();
  });

  it("makes exactly one AdminCreateUser call on a Create event", async () => {
    const send = vi.fn().mockResolvedValue({});
    mockCognito(send);

    const result = await handler(makeEvent("Create"));

    // Req 6.1 — exactly one create call, no second mutating call.
    const input = singleAdminCreateUserInput(send);
    expect(input.UserPoolId).toBe(USER_POOL_ID);
    // Handler echoes back the stable, email-derived physical resource id.
    expect(result.PhysicalResourceId).toBe(PHYSICAL_ID);
  });

  it("makes exactly one AdminCreateUser call on an Update event (create path)", async () => {
    const send = vi.fn().mockResolvedValue({});
    mockCognito(send);

    await handler(makeEvent("Update"));

    // The create path covers both Create and Update; still exactly one call.
    singleAdminCreateUserInput(send);
  });

  it("does NOT set MessageAction to SUPPRESS so Cognito sends the temp-password email (Req 6.2)", async () => {
    const send = vi.fn().mockResolvedValue({});
    mockCognito(send);

    await handler(makeEvent("Create"));

    const input = singleAdminCreateUserInput(send);
    // The temp-password invitation email only goes out when MessageAction is NOT
    // SUPPRESS. The handler enforces this by omitting MessageAction (default).
    expect(input.MessageAction).not.toBe("SUPPRESS");
    expect(input.MessageAction).toBeUndefined();
  });

  it("uses the email as both the Username and the email user attribute (Req 6.4)", async () => {
    const send = vi.fn().mockResolvedValue({});
    mockCognito(send);

    await handler(makeEvent("Create"));

    const input = singleAdminCreateUserInput(send);
    // Username == email (sign-in alias is email).
    expect(input.Username).toBe(ADMIN_EMAIL);
    // The email attribute also equals the email, pre-verified.
    const emailAttr = input.UserAttributes?.find((a) => a.Name === "email");
    expect(emailAttr?.Value).toBe(ADMIN_EMAIL);
    const verifiedAttr = input.UserAttributes?.find(
      (a) => a.Name === "email_verified"
    );
    expect(verifiedAttr?.Value).toBe("true");
  });

  it("creates the user in the force-change-password flow (Req 6.7)", async () => {
    const send = vi.fn().mockResolvedValue({});
    mockCognito(send);

    await handler(makeEvent("Create"));

    const input = singleAdminCreateUserInput(send);
    // The handler relies on AdminCreateUser's default behavior to enforce the
    // FORCE_CHANGE_PASSWORD state on first sign-in: it neither suppresses the
    // invitation (which sends a temp password) nor supplies its own
    // TemporaryPassword. Asserting against that actual implementation:
    expect(input.MessageAction).not.toBe("SUPPRESS");
    expect(input.TemporaryPassword).toBeUndefined();
  });
});

describe("admin-user-bootstrap handler — idempotency (UsernameExistsException)", () => {
  afterEach(() => {
    _setCognitoClient(null);
    vi.restoreAllMocks();
  });

  it("treats UsernameExistsException as success without a second mutating call (Req 6.5)", async () => {
    const existsError = new UsernameExistsException({
      message: "User account already exists",
      $metadata: {},
    });
    const send = vi.fn().mockRejectedValue(existsError);
    mockCognito(send);

    const result = await handler(makeEvent("Create"));

    // Success: returns a well-formed response and echoes the stable id.
    expect(result.PhysicalResourceId).toBe(PHYSICAL_ID);
    expect(result.Data).toEqual({});

    // No reset/overwrite: the only call was the (failed) AdminCreateUser, and
    // there is no second mutating call (e.g. AdminSetUserPassword).
    expect(send).toHaveBeenCalledTimes(1);
    expect(send.mock.calls[0][0]).toBeInstanceOf(AdminCreateUserCommand);
  });

  it("treats a name-tagged UsernameExistsException as success without a second call (Req 6.5)", async () => {
    // The handler also accepts an error whose `name` is "UsernameExistsException"
    // (defensive fallback for non-instanceof SDK error shapes).
    const send = vi
      .fn()
      .mockRejectedValue(
        Object.assign(new Error("already exists"), {
          name: "UsernameExistsException",
        })
      );
    mockCognito(send);

    const result = await handler(makeEvent("Create"));

    expect(result.PhysicalResourceId).toBe(PHYSICAL_ID);
    expect(send).toHaveBeenCalledTimes(1);
  });

  it("rethrows non-existence errors so the deploy fails", async () => {
    const send = vi
      .fn()
      .mockRejectedValue(
        Object.assign(new Error("boom"), { name: "InternalErrorException" })
      );
    mockCognito(send);

    await expect(handler(makeEvent("Create"))).rejects.toThrow(/boom/);
    // Still no second mutating call.
    expect(send).toHaveBeenCalledTimes(1);
  });
});
