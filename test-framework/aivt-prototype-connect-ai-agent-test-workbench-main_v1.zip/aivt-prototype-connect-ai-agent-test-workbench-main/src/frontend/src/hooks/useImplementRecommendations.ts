/**
 * useImplementRecommendations — centralized state machine hook for the
 * implement-recommendations workflow. Manages the complete lifecycle of both
 * the Direct Apply and Multi-Variant Experiment flows.
 *
 * Instantiated once per page that needs the implement flow (RunDashboard,
 * TournamentViewPage). Uses `useReducer` for predictable state transitions
 * enforced by the VALID_TRANSITIONS map.
 *
 * @module frontend/hooks/useImplementRecommendations
 */

import { useCallback, useEffect, useReducer, useRef } from 'react';
import {
  fetchRecommendations,
  applyRecommendations,
  createExperiment,
  getExperiment,
  applyVariant as applyVariantApi,
  ApiClientError,
} from '../api';
import type {
  ApplyRecommendationsResponse,
  DriftedField,
  ExperimentStatus,
  PerSuiteRecommendation,
  Recommendation,
} from '../api';

// ---------------------------------------------------------------------------
// State Machine Types
// ---------------------------------------------------------------------------

export type ImplementState =
  | 'idle'
  | 'loading_recommendations'
  | 'confirming'
  | 'applying'
  | 'conflict'
  | 'success'
  | 'experiment_starting'
  | 'experiment_polling'
  | 'experiment_completed'
  | 'experiment_failed'
  | 'error';

export interface ImplementContext {
  recommendations: PerSuiteRecommendation[];
  selectedIndices: number[];
  driftedFields: DriftedField[];
  experimentId: string | null;
  experimentStatus: ExperimentStatus | null;
  newVersionId: string | null;
  errorMessage: string | null;
  /** Variant letter when applying from TournamentView */
  applyingVariant: 'A' | 'B' | 'C' | null;
  /** Variant-specific recommendations when applying from TournamentView */
  variantRecommendations: Recommendation[] | null;
  /** Tracks elapsed polling time for 30-minute warning */
  pollingStartedAt: number | null;
}

export interface UseImplementRecommendationsProps {
  runId: string;
  suiteId: string;
  agentId: string;
}

export interface UseImplementRecommendationsReturn {
  // State
  state: ImplementState;
  context: ImplementContext;
  isLoading: boolean;

  // Actions
  startDirectApply: () => void;
  startExperiment: () => void;
  confirmApply: () => void;
  cancelDialog: () => void;
  forceApply: () => void;
  reAnalyze: () => void;
  reRunSuite: () => void;
  dismissSuccess: () => void;
  retryExperiment: () => void;
  fallbackToDirectApply: () => void;
  setSelectedIndices: (indices: number[]) => void;

  // TournamentView-specific
  applyVariant: (variant: 'A' | 'B' | 'C', recommendations: Recommendation[], experimentId?: string) => void;
}

// ---------------------------------------------------------------------------
// Valid Transitions Map
// ---------------------------------------------------------------------------

export const VALID_TRANSITIONS: Record<ImplementState, ImplementState[]> = {
  idle: ['loading_recommendations', 'experiment_starting'],
  loading_recommendations: ['confirming', 'error'],
  confirming: ['applying', 'idle', 'experiment_starting'],
  applying: ['success', 'conflict', 'error'],
  conflict: ['applying', 'idle', 'loading_recommendations'],
  success: ['idle'],
  experiment_starting: ['experiment_polling', 'error'],
  experiment_polling: ['experiment_completed', 'experiment_failed'],
  experiment_completed: ['idle', 'applying'],
  // experiment_failed allows loading_recommendations so the "Use Direct
  // Apply" fallback (R4.5) can recover from a failed experiment.
  experiment_failed: ['idle', 'experiment_starting', 'loading_recommendations'],
  error: ['idle', 'loading_recommendations'],
};

// ---------------------------------------------------------------------------
// Initial Context
// ---------------------------------------------------------------------------

export const INITIAL_CONTEXT: ImplementContext = {
  recommendations: [],
  selectedIndices: [],
  driftedFields: [],
  experimentId: null,
  experimentStatus: null,
  newVersionId: null,
  errorMessage: null,
  applyingVariant: null,
  variantRecommendations: null,
  pollingStartedAt: null,
};

// ---------------------------------------------------------------------------
// Terminal Experiment Statuses
// ---------------------------------------------------------------------------

const TERMINAL_STATUSES: ExperimentStatus[] = ['completed', 'failed', 'cleaned_up'];

// ---------------------------------------------------------------------------
// Polling Configuration
// ---------------------------------------------------------------------------

/** Polling interval for the active experiment flow (ms). */
const EXPERIMENT_POLL_INTERVAL_MS = 5_000;

/** 30-minute warning threshold (ms). */
export const POLLING_WARNING_THRESHOLD_MS = 30 * 60 * 1_000;

// ---------------------------------------------------------------------------
// Reducer Actions
// ---------------------------------------------------------------------------

export type ReducerAction =
  | { type: 'TRANSITION'; to: ImplementState; context?: Partial<ImplementContext> }
  | { type: 'SET_SELECTED_INDICES'; indices: number[] }
  | { type: 'UPDATE_CONTEXT'; context: Partial<ImplementContext> };

export interface ReducerState {
  state: ImplementState;
  context: ImplementContext;
}

export function isValidTransition(from: ImplementState, to: ImplementState): boolean {
  return VALID_TRANSITIONS[from].includes(to);
}

export function reducer(current: ReducerState, action: ReducerAction): ReducerState {
  switch (action.type) {
    case 'TRANSITION': {
      if (!isValidTransition(current.state, action.to)) {
        // Invalid transition — silently ignored
        return current;
      }
      return {
        state: action.to,
        context: action.context
          ? { ...current.context, ...action.context }
          : current.context,
      };
    }
    case 'SET_SELECTED_INDICES': {
      return {
        ...current,
        context: { ...current.context, selectedIndices: action.indices },
      };
    }
    case 'UPDATE_CONTEXT': {
      return {
        ...current,
        context: { ...current.context, ...action.context },
      };
    }
    default:
      return current;
  }
}

// ---------------------------------------------------------------------------
// Apply Result Helper (handles 409 conflict specially)
// ---------------------------------------------------------------------------

type ApplyResult =
  | { ok: true; response: ApplyRecommendationsResponse }
  | { ok: false; conflict: true; driftedFields: DriftedField[] }
  | { ok: false; conflict: false; message: string };

/**
 * Wraps an apply call and classifies the result into success/conflict/error.
 * The apiClient throws on non-2xx, so we catch 409 specially to extract
 * driftedFields from the error details.
 */
async function executeApply(
  applyFn: () => Promise<ApplyRecommendationsResponse>,
): Promise<ApplyResult> {
  try {
    const response = await applyFn();
    // The response might still signal conflict via the response body
    // (for cases where the backend returns 200 with driftedFields)
    if (response.driftedFields && response.driftedFields.length > 0) {
      return { ok: false, conflict: true, driftedFields: response.driftedFields };
    }
    return { ok: true, response };
  } catch (err) {
    if (err instanceof ApiClientError && err.status === 409) {
      // Extract driftedFields from error details if available
      const details = err.details;
      const driftedFields: DriftedField[] =
        Array.isArray(details?.driftedFields)
          ? (details.driftedFields as DriftedField[])
          : [];
      return { ok: false, conflict: true, driftedFields };
    }
    const message =
      err instanceof ApiClientError
        ? err.message
        : err instanceof Error
          ? err.message
          : 'An unexpected error occurred';
    return { ok: false, conflict: false, message };
  }
}

// ---------------------------------------------------------------------------
// Hook Implementation
// ---------------------------------------------------------------------------

export function useImplementRecommendations(
  props: UseImplementRecommendationsProps,
): UseImplementRecommendationsReturn {
  const { runId, suiteId, agentId } = props;

  const [{ state, context }, dispatch] = useReducer(reducer, {
    state: 'idle' as ImplementState,
    context: INITIAL_CONTEXT,
  });

  // Ref to track whether the component is still mounted
  const mountedRef = useRef(true);
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  // -------------------------------------------------------------------
  // Action: startDirectApply
  // -------------------------------------------------------------------
  const startDirectApply = useCallback(async () => {
    dispatch({ type: 'TRANSITION', to: 'loading_recommendations' });
    try {
      const response = await fetchRecommendations(runId, suiteId);
      if (!mountedRef.current) return;
      dispatch({
        type: 'TRANSITION',
        to: 'confirming',
        context: {
          recommendations: response.recommendations,
          selectedIndices: response.recommendations.map((_, i) => i),
        },
      });
    } catch (err) {
      if (!mountedRef.current) return;
      const message =
        err instanceof ApiClientError
          ? err.message
          : err instanceof Error
            ? err.message
            : 'Failed to fetch recommendations';
      dispatch({
        type: 'TRANSITION',
        to: 'error',
        context: { errorMessage: message },
      });
    }
  }, [runId, suiteId]);

  // -------------------------------------------------------------------
  // Action: startExperiment
  // -------------------------------------------------------------------
  const startExperiment = useCallback(async () => {
    dispatch({ type: 'TRANSITION', to: 'experiment_starting' });
    try {
      const response = await createExperiment(runId, agentId);
      if (!mountedRef.current) return;
      dispatch({
        type: 'TRANSITION',
        to: 'experiment_polling',
        context: {
          experimentId: response.experimentId,
          experimentStatus: response.status,
          pollingStartedAt: Date.now(),
        },
      });
    } catch (err) {
      if (!mountedRef.current) return;
      const message =
        err instanceof ApiClientError
          ? err.message
          : err instanceof Error
            ? err.message
            : 'Failed to create experiment';
      dispatch({
        type: 'TRANSITION',
        to: 'error',
        context: { errorMessage: message },
      });
    }
  }, [runId, agentId]);

  // -------------------------------------------------------------------
  // Action: confirmApply
  // -------------------------------------------------------------------
  const confirmApply = useCallback(async () => {
    // Guard: at least one recommendation must be selected
    if (context.selectedIndices.length === 0) return;

    dispatch({ type: 'TRANSITION', to: 'applying' });

    // Determine whether this is a direct apply or a variant apply
    const result = await executeApply(() => {
      if (context.applyingVariant && context.experimentId) {
        // TournamentView variant apply
        return applyVariantApi(runId, context.experimentId, context.applyingVariant);
      }
      // Standard direct apply
      return applyRecommendations(runId, agentId, context.selectedIndices);
    });
    if (!mountedRef.current) return;

    if (result.ok) {
      dispatch({
        type: 'TRANSITION',
        to: 'success',
        context: { newVersionId: result.response.newVersionId ?? null },
      });
    } else if (result.conflict) {
      dispatch({
        type: 'TRANSITION',
        to: 'conflict',
        context: { driftedFields: result.driftedFields },
      });
    } else {
      dispatch({
        type: 'TRANSITION',
        to: 'error',
        context: { errorMessage: result.message },
      });
    }
  }, [runId, agentId, context.selectedIndices, context.applyingVariant, context.experimentId]);

  // -------------------------------------------------------------------
  // Action: forceApply
  // -------------------------------------------------------------------
  const forceApply = useCallback(async () => {
    dispatch({ type: 'TRANSITION', to: 'applying' });

    const result = await executeApply(() =>
      applyRecommendations(runId, agentId, context.selectedIndices, true),
    );
    if (!mountedRef.current) return;

    if (result.ok) {
      dispatch({
        type: 'TRANSITION',
        to: 'success',
        context: {
          newVersionId: result.response.newVersionId ?? null,
          driftedFields: [],
        },
      });
    } else if (result.conflict) {
      // Unlikely but handle gracefully
      dispatch({
        type: 'TRANSITION',
        to: 'conflict',
        context: { driftedFields: result.driftedFields },
      });
    } else {
      dispatch({
        type: 'TRANSITION',
        to: 'error',
        context: { errorMessage: result.message },
      });
    }
  }, [runId, agentId, context.selectedIndices]);

  // -------------------------------------------------------------------
  // Action: cancelDialog
  // -------------------------------------------------------------------
  const cancelDialog = useCallback(() => {
    dispatch({
      type: 'TRANSITION',
      to: 'idle',
      context: INITIAL_CONTEXT,
    });
  }, []);

  // -------------------------------------------------------------------
  // Action: reAnalyze
  // -------------------------------------------------------------------
  const reAnalyze = useCallback(() => {
    dispatch({
      type: 'TRANSITION',
      to: 'loading_recommendations',
      context: {
        driftedFields: [],
      },
    });
  }, []);

  // -------------------------------------------------------------------
  // Action: reRunSuite
  // -------------------------------------------------------------------
  const reRunSuite = useCallback(() => {
    // Transitions to idle; the caller (RunDashboard) handles the actual
    // POST /runs call and navigation. This action just resets state.
    dispatch({
      type: 'TRANSITION',
      to: 'idle',
      context: INITIAL_CONTEXT,
    });
  }, []);

  // -------------------------------------------------------------------
  // Action: dismissSuccess
  // -------------------------------------------------------------------
  const dismissSuccess = useCallback(() => {
    dispatch({
      type: 'TRANSITION',
      to: 'idle',
      context: INITIAL_CONTEXT,
    });
  }, []);

  // -------------------------------------------------------------------
  // Action: retryExperiment
  // -------------------------------------------------------------------
  const retryExperiment = useCallback(async () => {
    dispatch({ type: 'TRANSITION', to: 'experiment_starting' });
    try {
      const response = await createExperiment(runId, agentId);
      if (!mountedRef.current) return;
      dispatch({
        type: 'TRANSITION',
        to: 'experiment_polling',
        context: {
          experimentId: response.experimentId,
          experimentStatus: response.status,
          pollingStartedAt: Date.now(),
        },
      });
    } catch (err) {
      if (!mountedRef.current) return;
      const message =
        err instanceof ApiClientError
          ? err.message
          : err instanceof Error
            ? err.message
            : 'Failed to create experiment';
      dispatch({
        type: 'TRANSITION',
        to: 'error',
        context: { errorMessage: message },
      });
    }
  }, [runId, agentId]);

  // -------------------------------------------------------------------
  // Action: fallbackToDirectApply
  // -------------------------------------------------------------------
  const fallbackToDirectApply = useCallback(async () => {
    // From error state, transition to loading_recommendations (Direct Apply)
    dispatch({ type: 'TRANSITION', to: 'loading_recommendations' });
    try {
      const response = await fetchRecommendations(runId, suiteId);
      if (!mountedRef.current) return;
      dispatch({
        type: 'TRANSITION',
        to: 'confirming',
        context: {
          recommendations: response.recommendations,
          selectedIndices: response.recommendations.map((_, i) => i),
          experimentId: null,
          experimentStatus: null,
        },
      });
    } catch (err) {
      if (!mountedRef.current) return;
      const message =
        err instanceof ApiClientError
          ? err.message
          : err instanceof Error
            ? err.message
            : 'Failed to fetch recommendations';
      dispatch({
        type: 'TRANSITION',
        to: 'error',
        context: { errorMessage: message },
      });
    }
  }, [runId, suiteId]);

  // -------------------------------------------------------------------
  // Action: setSelectedIndices
  // -------------------------------------------------------------------
  const setSelectedIndices = useCallback((indices: number[]) => {
    dispatch({ type: 'SET_SELECTED_INDICES', indices });
  }, []);

  // -------------------------------------------------------------------
  // Action: applyVariant (TournamentView-specific)
  // -------------------------------------------------------------------
  const applyVariant = useCallback(
    async (variant: 'A' | 'B' | 'C', recommendations: Recommendation[], experimentId?: string) => {
      // Set variant context and transition to confirming.
      // Include experimentId so confirmApply routes to the correct endpoint
      // (POST /experiments/{id}/apply rather than POST /apply-recommendations).
      dispatch({
        type: 'TRANSITION',
        to: 'loading_recommendations',
        context: {
          applyingVariant: variant,
          variantRecommendations: recommendations,
          experimentId: experimentId ?? null,
        },
      });
      // Immediately transition to confirming (variant recommendations are already loaded)
      dispatch({
        type: 'TRANSITION',
        to: 'confirming',
        context: {
          applyingVariant: variant,
          variantRecommendations: recommendations,
          selectedIndices: recommendations.map((_, i) => i),
          experimentId: experimentId ?? null,
        },
      });
    },
    [],
  );

  // -------------------------------------------------------------------
  // Polling: 5-second interval for experiment_polling state
  // -------------------------------------------------------------------
  const experimentIdRef = useRef(context.experimentId);
  experimentIdRef.current = context.experimentId;

  useEffect(() => {
    if (state !== 'experiment_polling' || !context.experimentId) return;

    const poll = async () => {
      const currentExperimentId = experimentIdRef.current;
      if (!currentExperimentId) return;

      try {
        const record = await getExperiment(runId, currentExperimentId);
        if (!mountedRef.current) return;

        // Update experiment status in context
        dispatch({
          type: 'UPDATE_CONTEXT',
          context: { experimentStatus: record.status },
        });

        // Check for terminal statuses
        if (TERMINAL_STATUSES.includes(record.status)) {
          if (record.status === 'failed') {
            dispatch({
              type: 'TRANSITION',
              to: 'experiment_failed',
              context: {
                experimentStatus: record.status,
                errorMessage: 'Experiment failed',
              },
            });
          } else {
            // completed or cleaned_up
            dispatch({
              type: 'TRANSITION',
              to: 'experiment_completed',
              context: { experimentStatus: record.status },
            });
          }
        }
      } catch (err) {
        if (!mountedRef.current) return;
        const message =
          err instanceof ApiClientError
            ? err.message
            : err instanceof Error
              ? err.message
              : 'Experiment polling failed';
        dispatch({
          type: 'TRANSITION',
          to: 'experiment_failed',
          context: { errorMessage: message },
        });
      }
    };

    // Initial poll
    void poll();

    // Set up interval
    const intervalId = setInterval(() => {
      void poll();
    }, EXPERIMENT_POLL_INTERVAL_MS);

    return () => {
      clearInterval(intervalId);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state, context.experimentId, runId]);

  // -------------------------------------------------------------------
  // Derived state
  // -------------------------------------------------------------------
  const isLoading =
    state === 'loading_recommendations' ||
    state === 'applying' ||
    state === 'experiment_starting';

  return {
    state,
    context,
    isLoading,
    startDirectApply,
    startExperiment,
    confirmApply,
    cancelDialog,
    forceApply,
    reAnalyze,
    reRunSuite,
    dismissSuccess,
    retryExperiment,
    fallbackToDirectApply,
    setSelectedIndices,
    applyVariant,
  };
}
