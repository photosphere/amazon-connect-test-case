import { QConnectClient, GetAIAgentCommand, GetAIPromptCommand, UpdateAIAgentCommand, UpdateAIPromptCommand } from "@aws-sdk/client-qconnect";
const A = "5664eea5-381d-468e-bfba-302b69ae6dec", AG = "d54d3dee-b9ec-415a-9a4b-b4769426f365", P = "197e301f-3217-48a8-8359-43bf16519f7b";
const c = new QConnectClient({ region: "us-east-1" });
function san(tools: any[]) { return tools.map(t => { if (t.toolType==="RETURN_TO_CONTROL") return t; const {inputSchema,description,title,outputSchema,...r}=t; return r; }); }
function ok(cond: boolean, msg: string) { if (!cond) throw new Error(msg); }
async function main() {
  console.log("1. Reading baseline...");
  const b = await c.send(new GetAIAgentCommand({assistantId:A,aiAgentId:AG}));
  const cfg = (b.aiAgent?.configuration as any)?.orchestrationAIAgentConfiguration;
  const bt: any[] = cfg?.toolConfigurations??[]; const bp = cfg?.orchestrationAIPromptId;
  const vis = (b.aiAgent as any)?.visibilityStatus??"PUBLISHED";
  console.log(`   Prompt=${bp} Tools=${bt.length}`);

  console.log("\n2. Adding examples to verifyIdentity(MCP) + Escalate(RTC)...");
  const we = san(bt).map((t:any) => {
    if (t.toolName==="verifyIdentity") return {...t, instruction:{instruction:"Use phone if available",examples:["phone in session, use directly"]}};
    if (t.toolName==="Escalate") return {...t, instruction:{...t.instruction,examples:["Customer wants manager -> Escalate"]}};
    return t;
  });
  await c.send(new UpdateAIAgentCommand({assistantId:A,aiAgentId:AG,visibilityStatus:vis,configuration:{orchestrationAIAgentConfiguration:{orchestrationAIPromptId:bp,toolConfigurations:we}}}));
  console.log("   Done.");

  console.log("\n3. Verifying examples persisted...");
  const a2 = await c.send(new GetAIAgentCommand({assistantId:A,aiAgentId:AG}));
  const t2: any[] = (a2.aiAgent?.configuration as any)?.orchestrationAIAgentConfiguration?.toolConfigurations??[];
  ok(t2.find((t:any)=>t.toolName==="verifyIdentity")?.instruction?.examples?.length===1, "verifyIdentity examples not persisted");
  ok(t2.find((t:any)=>t.toolName==="Escalate")?.instruction?.examples?.length===1, "Escalate examples not persisted");
  console.log("   ✓ Both have examples");

  console.log("\n4. Prompt-repoint (config-writer path)...");
  const pr = await c.send(new GetAIPromptCommand({assistantId:A,aiPromptId:P}));
  const ot = (pr.aiPrompt?.templateConfiguration as any)?.textFullAIPromptEditTemplateConfiguration?.text??"";
  const nt = ot.trimEnd()+"\n  # marker-"+Date.now()+"\n";
  const up = await c.send(new UpdateAIPromptCommand({assistantId:A,aiPromptId:P,visibilityStatus:"PUBLISHED",templateConfiguration:{textFullAIPromptEditTemplateConfiguration:{text:nt}}}));
  const npv = up.aiPrompt?.aiPromptId; console.log(`   New version: ${npv}`);
  const cur = await c.send(new GetAIAgentCommand({assistantId:A,aiAgentId:AG}));
  const ct: any[] = (cur.aiAgent?.configuration as any)?.orchestrationAIAgentConfiguration?.toolConfigurations??[];
  await c.send(new UpdateAIAgentCommand({assistantId:A,aiAgentId:AG,visibilityStatus:vis,configuration:{orchestrationAIAgentConfiguration:{orchestrationAIPromptId:npv,toolConfigurations:san(ct)}}}));
  console.log("   Re-pointed.");

  console.log("\n5. Verifying post-repoint...");
  const f = await c.send(new GetAIAgentCommand({assistantId:A,aiAgentId:AG}));
  const ft: any[] = (f.aiAgent?.configuration as any)?.orchestrationAIAgentConfiguration?.toolConfigurations??[];
  ok(ft.length===bt.length, `Tool count ${ft.length}!=${bt.length}`);
  const fv = ft.find((t:any)=>t.toolName==="verifyIdentity");
  ok(!!fv?.instruction?.instruction, "verifyIdentity instruction DROPPED");
  ok(!!fv?.instruction?.examples, "verifyIdentity examples DROPPED");
  ok(fv.instruction.examples.length===1, "verifyIdentity examples count wrong");
  ok(!!fv?.overrideInputValues, "verifyIdentity overrideInputValues DROPPED");
  ok(!!fv?.userInteractionConfiguration, "verifyIdentity userInteractionConfig DROPPED");
  ok(!!fv?.toolId, "verifyIdentity toolId DROPPED");
  console.log("   ✓ verifyIdentity: instruction, examples, overrideInputValues, userInteractionConfig, toolId ALL preserved");
  const fe = ft.find((t:any)=>t.toolName==="Escalate");
  ok(!!fe?.instruction?.examples, "Escalate examples DROPPED");
  ok(!!fe?.inputSchema, "Escalate inputSchema DROPPED");
  console.log("   ✓ Escalate(RTC): examples, inputSchema preserved");
  const fc = ft.find((t:any)=>t.toolName==="Complete");
  ok(!!fc?.inputSchema, "Complete inputSchema DROPPED");
  console.log("   ✓ Complete(RTC): inputSchema preserved");
  console.log("\n✅ ALL PASSED");

  console.log("\n6. Restoring...");
  await c.send(new UpdateAIAgentCommand({assistantId:A,aiAgentId:AG,visibilityStatus:vis,configuration:{orchestrationAIAgentConfiguration:{orchestrationAIPromptId:bp,toolConfigurations:san(bt)}}}));
  await c.send(new UpdateAIPromptCommand({assistantId:A,aiPromptId:P,visibilityStatus:"PUBLISHED",templateConfiguration:{textFullAIPromptEditTemplateConfiguration:{text:ot}}}));
  console.log("   Done.");
}
main().catch(e=>{console.error("\n❌ FAILED:",e.message);process.exit(1)});
