// Feature: implement-recommendations, Property 6: System prompt safety validation
import { describe, it, expect } from "vitest";
import fc from "fast-check";

import { validateSystemPromptSafety } from "@backend/orchestration/system-prompt-safety";

// ---------------------------------------------------------------------------
// Arbitraries
// ---------------------------------------------------------------------------

/** Non-empty printable text that avoids dynamic param patterns and structural markers. */
const safeTextArb: fc.Arbitrary<string> = fc
  .string({ minLength: 1, maxLength: 100 })
  .filter(
    (s) =>
      !s.includes("{{") &&
      !s.includes("<thinking>") &&
      !s.includes("</thinking>") &&
      !s.includes("<messaging>") &&
      !s.includes("</messaging>") &&
      !s.includes("Customer:") &&
      !s.includes("Agent:") &&
      !s.includes("Q:") &&
      !s.includes("A:") &&
      !/Example\s*\d*\s*:/i.test(s) &&
      !s.includes("<example>"),
  );

/** Generates a dynamic parameter placeholder. */
const dynamicParamArb: fc.Arbitrary<string> = fc.oneof(
  fc
    .string({ minLength: 1, maxLength: 15, unit: fc.constantFrom(...'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'.split('')) })
    .map((name) => `{{$.Custom.${name}}}`),
  fc
    .string({ minLength: 1, maxLength: 15, unit: fc.constantFrom(...'abcdefghijklmnopqrstuvwxyz_'.split('')) })
    .map((name) => `{{agent.${name}}}`),
  fc
    .string({ minLength: 1, maxLength: 15, unit: fc.constantFrom(...'abcdefghijklmnopqrstuvwxyz_'.split('')) })
    .map((name) => `{{session.${name}}}`),
);

/** Generates content for a thinking block (avoids nested markers). */
const thinkingContentArb: fc.Arbitrary<string> = safeTextArb.map(
  (content) => `<thinking>${content}</thinking>`,
);

/** Generates content for a messaging block (avoids nested markers). */
const messagingContentArb: fc.Arbitrary<string> = safeTextArb.map(
  (content) => `<messaging>${content}</messaging>`,
);

/**
 * Generates a system prompt with structural markers and trailing dynamic params.
 * Structure: body + thinking block + messaging block + trailing params
 */
const structuredPromptArb: fc.Arbitrary<{
  prompt: string;
  body: string;
  thinkingBlock: string;
  messagingBlock: string;
  trailingParams: string[];
}> = fc
  .tuple(
    safeTextArb,
    thinkingContentArb,
    messagingContentArb,
    fc.array(dynamicParamArb, { minLength: 1, maxLength: 3 }),
  )
  .map(([body, thinkingBlock, messagingBlock, params]) => {
    const trailingSection = "\n" + params.join("\n");
    const prompt = `${body}\n${thinkingBlock}\n${messagingBlock}${trailingSection}`;
    return {
      prompt,
      body,
      thinkingBlock,
      messagingBlock,
      trailingParams: params,
    };
  });

/**
 * Generates a system prompt WITHOUT structural markers but WITH trailing dynamic params.
 */
const unstructuredPromptWithParamsArb: fc.Arbitrary<{
  prompt: string;
  body: string;
  trailingParams: string[];
}> = fc
  .tuple(
    safeTextArb,
    fc.array(dynamicParamArb, { minLength: 1, maxLength: 3 }),
  )
  .map(([body, params]) => {
    const trailingSection = "\n" + params.join("\n");
    const prompt = `${body}${trailingSection}`;
    return {
      prompt,
      body,
      trailingParams: params,
    };
  });

// ---------------------------------------------------------------------------
// Property 6: System prompt safety validation
// ---------------------------------------------------------------------------

/**
 * **Validates: Requirements 20.1, 20.2, 20.3, 20.5, 20.6**
 *
 * Property 6: System prompt safety validation
 *
 * For any generated variant that modifies `system_prompt`, the validation
 * function SHALL reject the variant if it: (a) moves any dynamic parameter
 * away from its original position at the end of the prompt, OR (b) modifies
 * any byte within a thinking/messaging instruction block, OR (c) introduces
 * new example content into the system prompt body that was not present in the
 * source prompt. A variant passing validation guarantees all three rules are
 * satisfied.
 */
describe("Feature: implement-recommendations, Property 6: System prompt safety validation", () => {
  describe("Property 6.1: Preserving the original prompt unchanged always passes (identity is safe)", () => {
    it("structured prompt: identity transformation always passes", () => {
      fc.assert(
        fc.property(structuredPromptArb, ({ prompt }) => {
          const result = validateSystemPromptSafety(prompt, prompt);
          expect(result.valid).toBe(true);
          expect(result.violations).toHaveLength(0);
        }),
        { numRuns: 100 },
      );
    });

    it("unstructured prompt with params: identity transformation always passes", () => {
      fc.assert(
        fc.property(unstructuredPromptWithParamsArb, ({ prompt }) => {
          const result = validateSystemPromptSafety(prompt, prompt);
          expect(result.valid).toBe(true);
          expect(result.violations).toHaveLength(0);
        }),
        { numRuns: 100 },
      );
    });

    it("plain text prompt without params or markers: identity always passes", () => {
      fc.assert(
        fc.property(safeTextArb, (prompt) => {
          const result = validateSystemPromptSafety(prompt, prompt);
          expect(result.valid).toBe(true);
          expect(result.violations).toHaveLength(0);
        }),
        { numRuns: 100 },
      );
    });
  });

  describe("Property 6.2: Moving a dynamic parameter from end to beginning always fails (rule a)", () => {
    it("moving a trailing param to the start of the prompt fails validation", () => {
      fc.assert(
        fc.property(structuredPromptArb, ({ prompt, trailingParams }) => {
          // Move the first trailing param to the very beginning
          const paramToMove = trailingParams[0];
          // Remove it from the end section and prepend it
          const modifiedPrompt = paramToMove + "\n" + prompt.replace(paramToMove, "");

          const result = validateSystemPromptSafety(prompt, modifiedPrompt);
          expect(result.valid).toBe(false);
          expect(result.violations.length).toBeGreaterThan(0);
          // Should mention dynamic parameter positioning
          expect(
            result.violations.some(
              (v) => v.includes("Dynamic parameter") || v.includes("trailing"),
            ),
          ).toBe(true);
        }),
        { numRuns: 100 },
      );
    });

    it("unstructured prompt: moving param to beginning fails", () => {
      fc.assert(
        fc.property(
          unstructuredPromptWithParamsArb,
          ({ prompt, trailingParams }) => {
            const paramToMove = trailingParams[0];
            const modifiedPrompt =
              paramToMove + "\n" + prompt.replace(paramToMove, "");

            const result = validateSystemPromptSafety(prompt, modifiedPrompt);
            expect(result.valid).toBe(false);
            expect(result.violations.length).toBeGreaterThan(0);
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("Property 6.3: Modifying content within <thinking> blocks always fails (rule b)", () => {
    it("changing any character within a thinking block fails validation", () => {
      fc.assert(
        fc.property(
          structuredPromptArb,
          safeTextArb,
          ({ prompt, thinkingBlock }, replacement) => {
            // Ensure the replacement creates a different thinking block
            const newThinkingBlock = `<thinking>${replacement}_modified</thinking>`;
            fc.pre(newThinkingBlock !== thinkingBlock);

            const modifiedPrompt = prompt.replace(thinkingBlock, newThinkingBlock);
            fc.pre(modifiedPrompt !== prompt);

            const result = validateSystemPromptSafety(prompt, modifiedPrompt);
            expect(result.valid).toBe(false);
            expect(result.violations.length).toBeGreaterThan(0);
            expect(
              result.violations.some(
                (v) =>
                  v.includes("<thinking>") ||
                  v.includes("Structural block") ||
                  v.includes("byte-for-byte"),
              ),
            ).toBe(true);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("removing a thinking block entirely fails validation", () => {
      fc.assert(
        fc.property(structuredPromptArb, ({ prompt, thinkingBlock }) => {
          const modifiedPrompt = prompt.replace(thinkingBlock, "");
          fc.pre(modifiedPrompt !== prompt);

          const result = validateSystemPromptSafety(prompt, modifiedPrompt);
          expect(result.valid).toBe(false);
          expect(result.violations.length).toBeGreaterThan(0);
          expect(
            result.violations.some(
              (v) => v.includes("<thinking>") || v.includes("removed"),
            ),
          ).toBe(true);
        }),
        { numRuns: 100 },
      );
    });
  });

  describe("Property 6.4: Modifying content within <messaging> blocks always fails (rule b)", () => {
    it("changing any character within a messaging block fails validation", () => {
      fc.assert(
        fc.property(
          structuredPromptArb,
          safeTextArb,
          ({ prompt, messagingBlock }, replacement) => {
            const newMessagingBlock = `<messaging>${replacement}_modified</messaging>`;
            fc.pre(newMessagingBlock !== messagingBlock);

            const modifiedPrompt = prompt.replace(
              messagingBlock,
              newMessagingBlock,
            );
            fc.pre(modifiedPrompt !== prompt);

            const result = validateSystemPromptSafety(prompt, modifiedPrompt);
            expect(result.valid).toBe(false);
            expect(result.violations.length).toBeGreaterThan(0);
            expect(
              result.violations.some(
                (v) =>
                  v.includes("<messaging>") ||
                  v.includes("Structural block") ||
                  v.includes("byte-for-byte"),
              ),
            ).toBe(true);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("removing a messaging block entirely fails validation", () => {
      fc.assert(
        fc.property(structuredPromptArb, ({ prompt, messagingBlock }) => {
          const modifiedPrompt = prompt.replace(messagingBlock, "");
          fc.pre(modifiedPrompt !== prompt);

          const result = validateSystemPromptSafety(prompt, modifiedPrompt);
          expect(result.valid).toBe(false);
          expect(result.violations.length).toBeGreaterThan(0);
          expect(
            result.violations.some(
              (v) => v.includes("<messaging>") || v.includes("removed"),
            ),
          ).toBe(true);
        }),
        { numRuns: 100 },
      );
    });
  });

  describe("Property 6.5: Adding new example patterns to a prompt that had none always fails (rule c)", () => {
    it("structured prompt: introducing Customer:/Agent: pairs where none existed fails", () => {
      fc.assert(
        fc.property(structuredPromptArb, ({ prompt, body, thinkingBlock, messagingBlock, trailingParams }) => {
          // Ensure original body has no example patterns
          fc.pre(
            !/^Customer:/m.test(body) &&
            !/^Agent:/m.test(body) &&
            !/^Q:/m.test(body) &&
            !/^A:/m.test(body) &&
            !/Example\s*\d*\s*:/mi.test(body) &&
            !/<example>/i.test(body),
          );

          // Insert example content into the body
          const exampleContent = "\nCustomer: Hello, I need help\nAgent: Sure, how can I assist?\n";
          const modifiedBody = body + exampleContent;
          const trailingSection = "\n" + trailingParams.join("\n");
          const modifiedPrompt = `${modifiedBody}\n${thinkingBlock}\n${messagingBlock}${trailingSection}`;

          const result = validateSystemPromptSafety(prompt, modifiedPrompt);
          expect(result.valid).toBe(false);
          expect(result.violations.length).toBeGreaterThan(0);
          expect(
            result.violations.some(
              (v) =>
                v.includes("example") || v.includes("Example"),
            ),
          ).toBe(true);
        }),
        { numRuns: 100 },
      );
    });

    it("unstructured prompt: introducing example patterns where none existed fails", () => {
      fc.assert(
        fc.property(
          unstructuredPromptWithParamsArb,
          ({ prompt, body, trailingParams }) => {
            // Ensure original body has no example patterns
            fc.pre(
              !/^Customer:/m.test(body) &&
              !/^Agent:/m.test(body) &&
              !/^Q:/m.test(body) &&
              !/^A:/m.test(body) &&
              !/Example\s*\d*\s*:/mi.test(body) &&
              !/<example>/i.test(body),
            );

            // Insert example content into the body
            const exampleContent = "\nCustomer: Hello\nAgent: Hi there\n";
            const modifiedBody = body + exampleContent;
            const trailingSection = "\n" + trailingParams.join("\n");
            const modifiedPrompt = `${modifiedBody}${trailingSection}`;

            const result = validateSystemPromptSafety(prompt, modifiedPrompt);
            expect(result.valid).toBe(false);
            expect(result.violations.length).toBeGreaterThan(0);
            expect(
              result.violations.some(
                (v) => v.includes("example") || v.includes("Example"),
              ),
            ).toBe(true);
          },
        ),
        { numRuns: 100 },
      );
    });
  });

  describe("Property 6.6: Prompts without structural markers — only dynamic param position and no-new-examples rules apply", () => {
    it("modifying body text is valid when no structural markers exist and params stay at end", () => {
      fc.assert(
        fc.property(
          unstructuredPromptWithParamsArb,
          safeTextArb,
          ({ prompt, body, trailingParams }, newBody) => {
            // Ensure the new body is different and doesn't introduce examples
            fc.pre(newBody !== body);
            fc.pre(
              !/^Customer:/m.test(newBody) &&
              !/^Agent:/m.test(newBody) &&
              !/^Q:/m.test(newBody) &&
              !/^A:/m.test(newBody) &&
              !/Example\s*\d*\s*:/mi.test(newBody) &&
              !/<example>/i.test(newBody),
            );

            // Keep trailing params at the end
            const trailingSection = "\n" + trailingParams.join("\n");
            const modifiedPrompt = `${newBody}${trailingSection}`;

            const result = validateSystemPromptSafety(prompt, modifiedPrompt);
            expect(result.valid).toBe(true);
            expect(result.violations).toHaveLength(0);
          },
        ),
        { numRuns: 100 },
      );
    });

    it("plain prompt without params or markers: any modification that avoids examples is valid", () => {
      fc.assert(
        fc.property(safeTextArb, safeTextArb, (original, modified) => {
          fc.pre(original !== modified);
          // Neither has params or markers, so any safe modification passes
          const result = validateSystemPromptSafety(original, modified);
          expect(result.valid).toBe(true);
          expect(result.violations).toHaveLength(0);
        }),
        { numRuns: 100 },
      );
    });
  });
});
