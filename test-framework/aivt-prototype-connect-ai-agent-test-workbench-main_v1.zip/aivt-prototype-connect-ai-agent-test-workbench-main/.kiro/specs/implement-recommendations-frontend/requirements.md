# Requirements Document

## Introduction

This feature wires the existing scaffolded "Implement Recommendations" frontend components to the fully-built backend API endpoints. The backend (5 Lambda handlers: apply-recommendations, experiment-create, experiment-get, experiment-apply, experiment-cleanup) is deployed with API routes. The frontend components exist as shells (ImplementButton, ModeSelector, ConfirmationDialog, ExperimentProgress, TournamentView, PostApplyPrompt, ConflictResolution) but their callbacks are not connected to actual API calls, and there is no state management for the async experiment lifecycle.

The scope is purely frontend: connecting UI component shells to API endpoints, adding state management for async flows (direct apply, experiment creation, experiment polling), implementing a persistent progress banner for experiments that survive page navigation, and surfacing completion with a re-run prompt.

## Glossary

- **Frontend_Orchestrator**: The container component (or hook) responsible for managing the implement-recommendations workflow state, dispatching API calls, and coordinating transitions between sub-components (ModeSelector → ConfirmationDialog → PostApplyPrompt, or ModeSelector → ExperimentProgress → TournamentView).
- **API_Client**: The existing authenticated HTTP client (`apiClient`) at `src/frontend/src/api/client.ts` that handles Cognito JWT injection, 401/403 re-auth, 5xx notifications, and network timeout retry.
- **Direct_Apply_Flow**: The frontend workflow triggered when the user selects "Apply directly" — fetches recommendations, opens ConfirmationDialog with diff, calls POST /apply-recommendations, handles success/failure/conflict.
- **Experiment_Flow**: The frontend workflow triggered when the user selects "Advanced: Multi-variant experiment" — calls POST /experiments, shows ExperimentProgress with status polling on GET /experiments/{id}, transitions to TournamentView on completion.
- **Progress_Banner**: A persistent UI element displayed on the Run Dashboard (and optionally other pages) when an experiment is actively running for the current run, surviving page navigation since the experiment persists server-side.
- **Polling_Interval**: The time between successive GET /experiments/{id} requests while an experiment is in a non-terminal status.
- **Terminal_Status**: An experiment status value indicating the experiment lifecycle is complete: `completed`, `failed`, or `cleaned_up`.
- **Run_Dashboard**: The existing page at `/runs/{runId}` that displays run progress, results, and recommendations.
- **Tournament_View_Page**: The existing routed page at `/runs/{runId}/experiments/{experimentId}` that displays experiment comparison results.

## Requirements

### Requirement 1: Direct Apply Flow — API Wiring

**User Story:** As a tester who clicks "Apply directly" in the ModeSelector, I want the platform to fetch the recommendations diff, show me a confirmation dialog, and execute the write when I confirm, so that I can apply changes without leaving the platform.

#### Acceptance Criteria

1. WHEN the user selects "Apply directly" in the ModeSelector, THE Frontend_Orchestrator SHALL display a loading indicator on the ModeSelector, fetch the run's per-suite recommendations from the API, and upon successful response open the ConfirmationDialog populated with the recommendation diffs, agent name, and agent ID.
2. WHEN the user activates "Confirm and Apply" in the ConfirmationDialog, THE Frontend_Orchestrator SHALL call `POST /runs/{runId}/apply-recommendations` with `mode: "direct"`, the selected recommendation indices (minimum 1 required), and the agent ID.
3. IF the POST /apply-recommendations response returns success with a `newVersionId`, THEN THE Frontend_Orchestrator SHALL dismiss the ConfirmationDialog and display the PostApplyPrompt with the new version ID.
4. IF the POST /apply-recommendations response returns HTTP 409 with `driftedFields`, THEN THE Frontend_Orchestrator SHALL dismiss the ConfirmationDialog and display the ConflictResolution dialog with the drifted field details.
5. IF the POST /apply-recommendations response returns a non-409 error, THEN THE Frontend_Orchestrator SHALL display an error notification with the error message and keep the ConfirmationDialog open for retry.
6. WHILE the POST /apply-recommendations request is in flight, THE ConfirmationDialog SHALL display a loading state on the "Confirm and Apply" button and disable both the "Cancel" and "Confirm and Apply" actions to prevent double-submission.
7. IF the recommendation fetch triggered by selecting "Apply directly" fails (network error, HTTP 4xx, or HTTP 5xx), THEN THE Frontend_Orchestrator SHALL dismiss the loading indicator and display an inline error notification with a "Retry" action, without opening the ConfirmationDialog.
8. IF the user attempts to activate "Confirm and Apply" with zero recommendation indices selected, THEN THE Frontend_Orchestrator SHALL keep the "Confirm and Apply" button disabled and display an inline validation message indicating at least one recommendation must be selected.

### Requirement 2: Conflict Resolution Actions

**User Story:** As a tester facing a drift conflict, I want to choose between forcing the apply, canceling, or re-analyzing, so that I can handle conflicts without starting over.

#### Acceptance Criteria

1. WHEN the user activates "Apply anyway" in the ConflictResolution dialog, THE Frontend_Orchestrator SHALL call `POST /runs/{runId}/apply-recommendations` with an additional `force: true` parameter, disable all dialog actions until a response is received, and on success navigate to the PostApplyPrompt view; IF the force-apply call returns an error, THEN THE Frontend_Orchestrator SHALL dismiss the ConflictResolution dialog and display a notification containing the error reason returned by the API.
2. WHEN the user activates "Cancel" in the ConflictResolution dialog, THE Frontend_Orchestrator SHALL dismiss the dialog and return to the recommendations view without making any API calls or modifying application state.
3. WHEN the user activates "Re-analyze" in the ConflictResolution dialog, THE Frontend_Orchestrator SHALL dismiss the dialog, disable the "Re-analyze" action until a response is received, and call `POST /runs` with the same suiteId to trigger a fresh recommendation analysis run, then navigate to the new run's Run Dashboard.
4. IF the `POST /runs` call triggered by "Re-analyze" fails, THEN THE Frontend_Orchestrator SHALL display a notification containing the error reason and remain on the current recommendations view without navigating away.
5. WHILE a force-apply or re-analyze API call is in progress, THE Frontend_Orchestrator SHALL disable the "Apply anyway", "Cancel", and "Re-analyze" actions in the ConflictResolution dialog to prevent duplicate submissions.

### Requirement 3: Post-Apply Re-Run Prompt

**User Story:** As a tester who just successfully applied changes, I want to be prompted to re-run the suite to validate improvements, so that I can confirm my changes work.

#### Acceptance Criteria

1. WHEN the PostApplyPrompt is displayed and the user activates "Re-run Suite", THE Frontend_Orchestrator SHALL disable the "Re-run Suite" button immediately to prevent duplicate submissions, call `POST /runs` with the same suiteId to start a new run, and upon receiving a successful response navigate to the new run's Run Dashboard.
2. WHEN the user dismisses the PostApplyPrompt by activating the "Dismiss" button, THE Frontend_Orchestrator SHALL hide the prompt and return the user to the existing Run Dashboard view without triggering any API calls.
3. IF the `POST /runs` call triggered by "Re-run Suite" fails, THEN THE Frontend_Orchestrator SHALL re-enable the "Re-run Suite" button and display an error message indicating the failure reason, without dismissing the PostApplyPrompt.

### Requirement 4: Experiment Flow — Creation and Progress

**User Story:** As a tester who selects "Advanced: Multi-variant experiment", I want the platform to start the experiment, show real-time progress, and let me navigate away without losing track, so that I do not have to keep the page open during long-running experiments.

#### Acceptance Criteria

1. WHEN the user selects "Advanced: Multi-variant experiment" in the ModeSelector, THE Frontend_Orchestrator SHALL call `POST /runs/{runId}/experiments` with `mode: "multi_variant"` and the agent ID, and transition to the ExperimentProgress view with the returned experiment ID and initial status.
2. IF the POST /experiments request fails, THEN THE Frontend_Orchestrator SHALL display an error notification containing the error reason from the API response and present two actions: a "Retry" button that re-sends the same POST request, and a "Use Direct Apply" button that transitions to the Direct_Apply_Flow.
3. WHILE the experiment status is not a Terminal_Status, THE Frontend_Orchestrator SHALL poll `GET /runs/{runId}/experiments/{experimentId}` at a Polling_Interval of 5 seconds and update the ExperimentProgress component with the latest status value and any progress metadata returned by the API (such as variant statuses or step descriptions).
4. WHEN the experiment status transitions to `completed` or `cleaned_up`, THE Frontend_Orchestrator SHALL stop polling and navigate to the Tournament_View_Page at `/runs/{runId}/experiments/{experimentId}`.
5. WHEN the experiment status transitions to `failed`, THE Frontend_Orchestrator SHALL stop polling and display the ExperimentProgress component in its failed state showing the failure reason from the API response, with a "Retry" button that calls `POST /runs/{runId}/experiments` to create a new experiment, and a "Use Direct Apply" button that transitions to the Direct_Apply_Flow.
6. THE Frontend_Orchestrator SHALL stop polling when the component unmounts (user navigates away) to prevent memory leaks and unnecessary network requests.
7. WHEN the ExperimentProgress component mounts and an experiment ID exists in the Frontend_Orchestrator state (user navigated back), THE Frontend_Orchestrator SHALL immediately call `GET /runs/{runId}/experiments/{experimentId}` to fetch the current status and resume polling if the status is not a Terminal_Status, or transition to the appropriate terminal view if it is.
8. IF the experiment status has not reached a Terminal_Status after 30 minutes of polling, THEN THE Frontend_Orchestrator SHALL continue polling but display a warning indicator on the ExperimentProgress component stating the experiment is taking longer than expected.

### Requirement 5: Persistent Experiment Progress Banner

**User Story:** As a tester who starts an experiment and navigates away, I want to see a progress banner when I return to the Run Dashboard, so that I know the experiment is still running and can navigate to results when ready.

#### Acceptance Criteria

1. WHEN the Run Dashboard loads, THE Run_Dashboard SHALL call `GET /runs/{runId}/experiments` to determine whether an experiment exists for the run, and if an active experiment is found (status is `generating_variants`, `creating_agents`, `running`, or `cleanup_in_progress`), SHALL display a Progress_Banner showing the current experiment status text and a link to the ExperimentProgress page at `/runs/{runId}/experiments/{experimentId}`.
2. WHEN the Run Dashboard loads for a run that has a completed experiment (status is `completed` or `cleaned_up`), THE Run_Dashboard SHALL display a Progress_Banner with a "View Experiment Results" link navigating to the TournamentView page at `/runs/{runId}/experiments/{experimentId}`.
3. WHILE the experiment is in a non-terminal status, THE Progress_Banner SHALL poll `GET /runs/{runId}/experiments/{experimentId}` at a Polling_Interval of 10 seconds and update the displayed status text within one polling cycle of the status changing on the server.
4. WHEN the Progress_Banner detects that the experiment status has transitioned to `completed` or `cleaned_up`, THE Progress_Banner SHALL stop polling and update its content to show a completion message with a "View Experiment Results" link navigating to the TournamentView page.
5. WHEN the Progress_Banner detects that the experiment status has transitioned to `failed`, THE Progress_Banner SHALL stop polling and update its content to display a failed state indicator with an option to retry by navigating to the ExperimentProgress page.
6. IF a poll request to `GET /runs/{runId}/experiments/{experimentId}` fails due to a network error or non-2xx response, THEN THE Progress_Banner SHALL retain the last known status, skip the failed poll cycle, and retry on the next Polling_Interval without displaying an error unless 3 consecutive poll failures occur, at which point it SHALL display an inline error message indicating that status updates are unavailable.

### Requirement 6: Tournament View — Apply Variant Action

**User Story:** As a tester viewing tournament results, I want to apply any variant's changes to my real agent with one click (via the same confirmation flow as Direct Apply), so that I can promote the best variant.

#### Acceptance Criteria

1. WHEN the user activates "Apply to Agent" on a variant column in the TournamentView, THE Frontend_Orchestrator SHALL open the ConfirmationDialog populated with the selected variant's recommendation diffs, the variant letter, the agent name, and the agent ID.
2. WHEN the user confirms the apply in the ConfirmationDialog, THE Frontend_Orchestrator SHALL call `POST /runs/{runId}/experiments/{experimentId}/apply` with the selected variant letter and handle the response as follows: success with `newVersionId` → display PostApplyPrompt with the new version ID, HTTP 409 with `driftedFields` → display ConflictResolution with drifted field details, non-409 error → display error notification and keep the ConfirmationDialog open for retry.
3. WHILE the POST /experiments/{experimentId}/apply request is in flight, THE ConfirmationDialog SHALL display a loading state on the confirm button and disable both the "Cancel" and "Confirm and Apply" actions to prevent double-submission.
4. IF the POST /experiments/{experimentId}/apply response indicates the experiment resources have been cleaned up or are unavailable, THEN THE Frontend_Orchestrator SHALL dismiss the ConfirmationDialog and display an error notification indicating the experiment must be re-run before applying.

### Requirement 7: State Management and Component Integration

**User Story:** As a frontend developer, I want a clear state machine governing the implement-recommendations flow, so that transitions between components are predictable and the UI never shows inconsistent state.

#### Acceptance Criteria

1. THE Frontend_Orchestrator SHALL maintain a state machine with the following states: `idle`, `loading_recommendations`, `confirming`, `applying`, `conflict`, `success`, `experiment_starting`, `experiment_polling`, `experiment_completed`, `experiment_failed`, and `error`.
2. THE Frontend_Orchestrator SHALL expose the current state and relevant context (recommendations, driftedFields, experimentId, experimentStatus, newVersionId, errorMessage) to child components via props or React context.
3. THE Frontend_Orchestrator SHALL enforce the following valid state transitions and reject all others: `idle` → `loading_recommendations`; `loading_recommendations` → `confirming` or `error`; `confirming` → `applying` or `idle` or `experiment_starting`; `applying` → `success` or `conflict` or `error`; `conflict` → `applying` or `idle` or `loading_recommendations`; `success` → `idle`; `experiment_starting` → `experiment_polling` or `error`; `experiment_polling` → `experiment_completed` or `experiment_failed`; `experiment_completed` → `idle` or `applying`; `experiment_failed` → `idle` or `experiment_starting`; `error` → `idle` or `loading_recommendations`.
4. IF the Frontend_Orchestrator receives a transition request that is not in the valid transition map, THEN THE Frontend_Orchestrator SHALL ignore the request and retain the current state without side effects.
5. WHEN the user dismisses any dialog via "Cancel" or closes the PostApplyPrompt, THE Frontend_Orchestrator SHALL transition to `idle` state and clear all transient context fields (recommendations, driftedFields, experimentId, experimentStatus, newVersionId, errorMessage) to their initial empty values.

### Requirement 8: Error Handling and Loading States

**User Story:** As a tester using the implement-recommendations flow, I want clear feedback when operations are in progress or when errors occur, so that I know what is happening and can take corrective action.

#### Acceptance Criteria

1. WHILE any API request in the implement-recommendations flow is in flight, THE Frontend_Orchestrator SHALL disable the triggering button and replace its label with an inline spinner, and SHALL disable all other interactive actions in the active dialog or component to prevent concurrent submissions.
2. IF an API request returns a non-success response that is not handled by a specific flow step (not 401/403 which trigger re-auth, and not HTTP 409 which triggers ConflictResolution), THEN THE Frontend_Orchestrator SHALL display the error message from the response body via the Flashbar notification system and SHALL transition the state machine back to the last user-interactive state (`idle`, `confirming`, or `experiment_polling`) without discarding any user selections or recommendation data that was already loaded.
3. IF a network timeout occurs and the API_Client begins its built-in retry sequence (up to 2 retries with exponential backoff), THEN THE Frontend_Orchestrator SHALL remain in its current state (not reset or re-trigger the action) and SHALL allow the API_Client's retry notifications to display in the Flashbar until either the retry succeeds (flow continues normally) or all retries are exhausted (at which point criterion 2 applies).
4. IF the experiment polling request (`GET /runs/{runId}/experiments/{experimentId}`) fails with a non-retryable error, THEN THE Frontend_Orchestrator SHALL stop polling, display the error in the Flashbar, and transition to the `experiment_failed` state with a "Retry" option that restarts polling from the last known experiment status.
